# Alineación del proceso de Ordenamiento ante el cambio FULL → DELTA (Tarea 10.3)

Este documento cubre el **Requisito 11** (Alineación de Ordenamiento aguas abajo) de la
funcionalidad `unificacion-full-delta`. Documenta el impacto del cambio de modalidad FULL a
DELTA de la Unificación sobre el consumo de la tabla destino `bdm_datos.unificacion_direccion`
por parte del proceso de **Ordenamiento**, **sin modificar** su implementación (el Ordenamiento
queda explícitamente fuera del alcance de implementación de esta especificación).

- Req 11.1: la Tabla_Destino_Real sigue siendo una fuente consistente y consultable para
  Ordenamiento cuando la persistencia pasa a UPSERT en DELTA en lugar de reseteo.
- Req 11.2: se documenta el impacto del cambio FULL → DELTA sobre el consumo por Ordenamiento.
- Req 11.3: no se modifica la implementación de Ordenamiento dentro de este alcance.

## 1. Contexto: cómo consume Ordenamiento la tabla de Unificación

El proceso de Ordenamiento (scoring de contactabilidad, aguas abajo) lee la salida de la
Unificación desde `bdm_datos.unificacion_direccion` para construir el ranking de direcciones por
persona. La Unificación produce, por la **Clave_Unificacion** `(cod_dw_persona_ubic,
cod_dw_direccion_unificada)`, el atributo `unifica_atributos` (1=R1 | 2=R2 | 3=R3), la
`fecha_unificacion`, el `lote` y la `severidad`. Ordenamiento no forma parte del Motor_Unificacion;
solo es consumidor de esa tabla.

## 2. Qué cambia con FULL → DELTA

| Aspecto | Modo FULL (comportamiento actual) | Modo DELTA (nuevo) |
|---------|-----------------------------------|--------------------|
| Reseteo de la tabla | `TRUNCATE` al inicio + `INSERT` append de las 3 reglas | **No** hay `TRUNCATE`; persistencia por `UPSERT` por la Clave_Unificacion |
| Contenido tras la corrida | Reconstruye todo el universo unificado | Inserta/actualiza solo las parejas del delta; conserva el resto |
| Unificaciones obsoletas | Se eliminan (por el reseteo) | **Se conservan** (DELTA no des-unifica, Req 15) |
| Campo `lote` | Lote_Corrida externo (antes fijo `1`) | Lote_Corrida externo por corrida |
| Unicidad por clave | Garantizada por `SELECT DISTINCT` | Garantizada por `SELECT DISTINCT` + `UPSERT`/`MERGE` |

El punto clave para Ordenamiento: **la tabla deja de vaciarse en cada corrida**. En DELTA la
tabla es acumulativa/incremental y refleja el estado vigente más las parejas que aún no han sido
reconciliadas por un FULL.

## 3. Impacto sobre el consumo por Ordenamiento (Req 11.2)

1. **Consistencia y consultabilidad (Req 11.1).** La tabla sigue teniendo el mismo esquema
   (la DDL de `unificacion_direccion` **no cambia**) y sigue garantizando **una única fila por
   Clave_Unificacion** tras cualquier corrida (Req 5.5, 5.6), por el `SELECT DISTINCT` intra-corrida
   y el `UPSERT`/`MERGE` entre corridas. Ordenamiento puede seguir leyéndola sin cambios de contrato
   de datos: no hay columnas nuevas ni tipos distintos, no hay filas duplicadas ni huérfanas.

2. **Ventana de lectura de Ordenamiento.** En FULL, Ordenamiento veía siempre el universo completo
   recién reconstruido. En DELTA, Ordenamiento verá el estado **acumulado** (unificaciones previas
   + delta de la última corrida). Si Ordenamiento asume implícitamente que la tabla fue reseteada
   por la corrida inmediatamente anterior (por ejemplo, para "ver solo lo de hoy"), esa suposición
   deja de ser válida en DELTA. **Recomendación operativa:** que Ordenamiento se ancle a la corrida
   mediante el `lote` (Lote_Corrida) y/o la `fecha_unificacion`, y no a la premisa de "tabla vacía
   antes de la corrida".

3. **Unificaciones obsoletas.** En DELTA, una pareja que dejó de aplicar **permanece** hasta que
   un FULL de reconciliación la elimine (Req 15, Req 9.5/9.6). Ordenamiento podría ver, transitoriamente,
   parejas que un FULL sí habría eliminado. Esto es coherente con la semántica legada de Teradata
   (UPSERT sin des-unificación) y se resuelve con la cadencia de FULL de reconciliación (backfill),
   no con un cambio en Ordenamiento.

4. **Frescura por lote y fecha.** El `lote` pasa a ser el Lote_Corrida externo provisto por la
   Orquestacion (ya no el fijo `1`). Si Ordenamiento filtraba o agrupaba por `lote = 1`, debe dejar
   de asumir ese valor fijo. La `fecha_unificacion` sigue registrándose por fila y permite acotar por
   fecha si Ordenamiento lo requiere.

5. **Volumen y rendimiento.** En régimen DELTA el volumen escrito por corrida es menor (solo el
   delta), pero la tabla crece de forma acumulativa entre FULL de reconciliación. El `DISTKEY/SORTKEY`
   por `cod_dw_persona_ubic` de la tabla favorece las lecturas de Ordenamiento por persona; no cambia.

## 4. Qué NO cambia (Req 11.3)

- La **implementación de Ordenamiento no se modifica** en esta especificación.
- El **esquema** de `bdm_datos.unificacion_direccion` no cambia (misma DDL, mismas columnas/tipos).
- El **contrato de datos** hacia Ordenamiento se mantiene: misma granularidad (una fila por
  Clave_Unificacion), mismos campos, sin duplicados ni huérfanas.

## 5. Recomendaciones para el equipo de Ordenamiento (no bloqueantes)

Estas recomendaciones son de alineación; su adopción corresponde al equipo de Ordenamiento y no
forma parte del alcance de implementación de esta funcionalidad:

- No asumir que `unificacion_direccion` se vacía antes de cada corrida (ya no ocurre en DELTA).
- No asumir `lote = 1` fijo; usar el Lote_Corrida real y/o `fecha_unificacion` para acotar por corrida.
- Programar corridas FULL de reconciliación (backfill) con la cadencia acordada para eliminar
  unificaciones obsoletas que el DELTA conserva por diseño.
- Para monitoreo, `bdm_datos.unif_control` (histórico por corrida) y `bdm_datos.unif_control_etapa`
  (traza por etapa) permiten saber qué corrida y qué modo produjeron el estado actual de la tabla.

## 6. Trazabilidad

| Requisito | Cubierto por |
|-----------|--------------|
| 11.1 Fuente consistente/consultable | Sección 3.1 (unicidad por clave, esquema sin cambios) |
| 11.2 Documentar impacto FULL → DELTA | Secciones 2 y 3 (tabla comparativa e impactos) |
| 11.3 No modificar Ordenamiento | Sección 4 (qué no cambia) + Sección 5 (recomendaciones no bloqueantes) |
