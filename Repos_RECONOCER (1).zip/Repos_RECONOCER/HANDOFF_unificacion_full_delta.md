# Handoff — Unificación FULL/DELTA + GEO + Tablas de Control

Documento de traspaso para el ingeniero de datos que continuará con **despliegue, pruebas, paso a producción y alineación de Ordenamiento** de la funcionalidad `unificacion-full-delta`.

Spec de referencia: `.kiro/specs/unificacion-full-delta/` (requirements.md, design.md, tasks.md).
Cluster consumidor: `reconocerbatch` / DB `dba_rncr_batch`. Motor: SQL / PLpgSQL sobre Amazon Redshift.

---

## 1. Qué se construyó (resumen funcional)

La Unificación de direcciones ahora soporta **dos modos de carga que coexisten en el mismo código**:

- **FULL** (comportamiento actual, por defecto): `TRUNCATE` de `bdm_datos.unificacion_direccion` + `INSERT` append. Reprocesa todo el universo. Es el mecanismo de reconciliación / backfill.
- **DELTA** (restaura el diseño original de Teradata): procesa solo las relaciones con fecha `>= Watermark` (frontera inclusiva por día) más las de fecha nula, y persiste por **UPSERT** por la Clave_Unificacion `(cod_dw_persona_ubic, cod_dw_direccion_unificada)`. No trunca, no des-unifica.

El **modo se resuelve una sola vez por corrida** en el orquestador maestro `sp_unificacion_ciclo`, a partir de los 6 parámetros del Framework_Batch, y se propaga a R1 → R2 → Ciclo_GEO → R3. Se añadió una capa aditiva de **control/traza/histórico** que no altera la lógica de unificación.

Bloques principales:

1. **Tablas de control** (`bdm_datos.unif_control`, `bdm_datos.unif_control_etapa`): histórico por corrida y traza por etapa.
2. **FULL/DELTA** en las reglas (vía Generadores_SP): ventana delta en `preparar_insumo` y persistencia condicional (UPSERT en DELTA / append en FULL); `lote` = Lote_Corrida externo (ya no fijo `1`).
3. **GEO alineado al modo**: en DELTA el Exportador_GEO intersecta candidatos "sin coordenadas" con el universo del delta (`bdm_tempo.stg_unif_delta_ubic`); en FULL barrido completo. El `lote` del Ciclo_GEO sigue siendo independiente del Lote_Corrida.

---

## 2. Estado del código y PROMOCIÓN ya realizada

Los fuentes se desarrollaron en el workspace `ws-unificacion/src/redshift/` y **ya fueron promovidos a los repos desplegables** (Jenkins lee el `deploy.par`/`rollback.par` de cada repo). Paridad `deploy.par` = `rollback.par` verificada y sin BOM.

### Repo `strct` (db_rcncr_btch_rdshft_strct) — DDL de control
- `SQL/11_ddl_unif_control.sql` (añadido al final de `deploy.par`)
- `RevSQL/11_rollback_ddl_unif_control.sql` (añadido al inicio de `rollback.par`)

### Repo `pgm` (db_rcncr_btch_rdshft_pgm) — función, control/traza, orquestador
Añadidos al final de `deploy.par` en este orden (dependencias):
- `SQL/12_fn_unif_resolver_param.sql`   (función helper de parámetros)
- `SQL/14_traza_procedures.sql`         (unif_traza_inicio / unif_traza_fin)
- `SQL/15_sp_unif_control_abrir_cerrar.sql` (unif_control_abrir / cerrar)
- `SQL/16_sp_unificacion_ciclo.sql`     (orquestador maestro — va de último)
Y sus rollbacks en `RevSQL/` (12/14/15/16), añadidos al inicio de `rollback.par` en orden inverso (16 → 15 → 14 → 12).

Los `sp_unificacion_*` (real y mock) y `sp_geo_*` ya estaban en el repo y se regeneraron vía Generadores_SP con la lógica FULL/DELTA.

### Repo `dt` (db_rcncr_btch_rdshft_dt) — malla y scripts CALL
- `run_unificacion_ejecucion_secuencial.sql` (se retiró el TRUNCATE incondicional)
- `run_unificacion_full.sql` / `run_unificacion_delta.sql` (scripts CALL de prueba)

> Nota: los `.jenkins.yml` de los 3 repos ya declaran `application: dba_rncr_batch` y el orden `strct(1) → pgm(2) → dt(3)`.

---

## 3. Orden de despliegue (Jenkins)

Despliegue MANUAL y OBLIGATORIO en este orden (cada repo dispara su pipeline):

1. **strct** → crea las tablas de control.
2. **pgm** → crea función, procedimientos de control/traza y el orquestador (dependen de las tablas de strct).
3. **dt** → malla y scripts CALL (dependen de los procedimientos de pgm).

Restricciones que el pipeline valida (ya cumplidas en los artefactos):
- UTF-8 **sin BOM** en todos los `.sql`/`.par`.
- **NONATOMIC consistente** en toda la cadena de CALL (mezclar modos → `P0001`).
- Rollback: **FUNCIONES** con `DROP FUNCTION nombre(<firma>)` sin `IF EXISTS`; **PROCEDIMIENTOS** con `DROP PROCEDURE nombre(<firma>)` sin `IF EXISTS` (Redshift no soporta `IF EXISTS` en function/procedure).
- Idempotencia: `CREATE TABLE IF NOT EXISTS`, `CREATE OR REPLACE`.
- Sin `GRANT ... TO PUBLIC`. Grants al rol `reconocer_batch_role` (ajustar al rol real del ambiente).

> Antes de desplegar `pgm`, confirmar que la tabla base `bdm_datos.relacion_persona_ubicacion` (o la vista EDF equivalente) existe: el orquestador la usa para materializar el universo delta y calcular el Watermark.

---

## 4. FIRMAS — cómo se invoca todo (usar SIEMPRE desde las firmas)

Todos los procedimientos invocables por el Framework_Batch llevan **6 parámetros VARCHAR**. El `CALL` DEBE respetar la firma exacta o Redshift responde `procedure ... does not exist`. **Invocar siempre por la firma completa, no por variantes.**

### Orquestador maestro (punto de entrada único)
```
bdm_datos.sp_unificacion_ciclo(
  in_solicitud       VARCHAR,   -- Framework_Batch (no usado)
  in_nit_suscriptor  VARCHAR,   -- Framework_Batch (no usado)
  in_path_archivo    VARCHAR,   -- Framework_Batch (no usado)
  in_nemotecnico     VARCHAR,   -- MODO  = FULL | DELTA | '' (default FULL)
  in_id_facturacion  VARCHAR,   -- LOTE  = Lote_Corrida (entero; obligatorio)
  in_fecha_ejecucion VARCHAR    -- FECHA = Fecha_Proceso YYYY-MM-DD | '' (default CURRENT_DATE)
)
```

### Orquestadores de regla y GEO (los invoca el maestro, no invocar sueltos)
Misma firma de 6 VARCHAR. El maestro **re-emite** en los slots 4/5/6:
`in_nemotecnico = Modo_Corrida`, `in_id_facturacion = Lote_Corrida`, `in_fecha_ejecucion = Watermark` (frontera inferior inclusiva de la ventana DELTA — NO es la Fecha_Proceso).
```
bdm_datos.sp_unificacion_regla1(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR)
bdm_datos.sp_unificacion_regla2(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR)
bdm_datos.sp_unificacion_regla3(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR)
bdm_datos.sp_geo_exportar_insumo(VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR,VARCHAR)
```

### Función y procedimientos de control/traza (firmas exactas para rollback)
```
bdm_datos.unif_resolver_param(VARCHAR, VARCHAR)                              -- FUNCTION (STABLE, LANGUAGE sql)
bdm_datos.unif_control_abrir(VARCHAR, INTEGER, DATE, DATE, BOOLEAN, BIGINT)  -- INOUT corrida_id
bdm_datos.unif_control_cerrar(BIGINT, VARCHAR, DATE, BIGINT, BIGINT, BIGINT)
bdm_datos.unif_traza_inicio(BIGINT, INTEGER, VARCHAR)
bdm_datos.unif_traza_fin(BIGINT, VARCHAR, VARCHAR, BIGINT, BIGINT, BIGINT, BIGINT, BIGINT)
```

> El Framework_Batch (YML de proceso) lo configura el ingeniero según el estándar del equipo. Solo hay que garantizar que el step que invoca `sp_unificacion_ciclo` pase los 6 argumentos respetando la firma, mapeando MODO/LOTE/FECHA a los slots 4/5/6.

---

## 5. Cómo probar (QA)

1. **Pruebas de propiedad (PBT)** — lógica de correctitud, ya pasan en stand-in:
   `python -m pytest ws-unificacion/tests/pbt/unificacion_full_delta/ -q` → 16 passed.
   En QA, configurar la conexión Redshift por entorno para que el arnés ejercite el SQL real (deja de usar el stand-in en memoria).

2. **Pruebas de integración/smoke** — requieren cluster vivo (hoy hacen skip):
   `python -m pytest ws-unificacion/tests/integration/ -q`
   Verifican existencia de tablas de control, granularidad de traza, transiciones de estado, conteos GEO e histórico por Fecha_Proceso.

3. **Corrida FULL de humo**: ejecutar `sp_unificacion_ciclo('','','','FULL','<lote>','<fecha>')` y validar que `unificacion_direccion` se reconstruye y que `unif_control` registra la corrida `completado` con Watermark sembrado.

4. **Corrida DELTA de humo** (tras un FULL): ejecutar en DELTA y validar UPSERT idempotente (reejecutar la misma ventana no duplica ni des-unifica) y avance del Watermark.

5. **Verificar `MERGE`**: los Generadores_SP emiten `MERGE` nativo como estrategia primaria y `DELETE`+`INSERT` como fallback (bandera `usar_merge`). Confirmar en el bring-up si el cluster soporta `MERGE`; si no, regenerar con el fallback (mismo estado final por la Clave_Unificacion).

---

## 6. Alineación de Ordenamiento (el "pedacito" a sumar)

Documento base: `docs/tecnico/alineacion_ordenamiento_full_delta.md`. La implementación de Ordenamiento NO se tocó; el ingeniero debe ajustarla con estos puntos:

- **La tabla ya no se vacía en cada corrida** (solo en FULL/Bootstrap). En DELTA `unificacion_direccion` es **acumulativa/incremental**. Ordenamiento no debe asumir "tabla reseteada antes de la corrida".
- **No asumir `lote = 1`**: ahora `lote` es el Lote_Corrida externo. Si Ordenamiento filtraba por `lote = 1`, debe anclarse al Lote_Corrida real y/o a `fecha_unificacion`.
- **Unificaciones obsoletas**: en DELTA se conservan hasta que un FULL de reconciliación las elimine (por diseño, no es un defecto). Programar la cadencia de FULL de backfill.
- **Contrato de datos intacto**: misma DDL, misma granularidad (una fila por Clave_Unificacion, sin duplicados). No hay cambios de esquema para Ordenamiento.
- **Monitoreo**: `unif_control` (histórico por corrida) y `unif_control_etapa` (traza por etapa) permiten saber qué corrida y modo produjeron el estado actual.

---

## 7. Notas / riesgos de seguimiento

- El arnés PBT corrió en **stand-in** (réplica en memoria) por falta de cluster en el entorno de desarrollo; la validación contra Redshift real es parte del bring-up de QA.
- El Ciclo_GEO real (ArcGIS + I/O S3) está fuera del alcance de este spec (ver spec `geo-enriquecimiento-regla3`); aquí solo se alineó la selección de candidatos por modo.
- Ajustar el nombre del rol de los `GRANT` (`reconocer_batch_role`) al rol real del ambiente destino.
- La primera corrida siempre es **Bootstrap FULL** automático: si no hay Watermark previo `completado`, el orquestador fuerza FULL aunque se pida DELTA.

---

## 8. Referencias

- `docs/tecnico/verificacion_despliegue_unificacion_full_delta.md` — checks de despliegue (Req 12).
- `docs/tecnico/alineacion_ordenamiento_full_delta.md` — impacto en Ordenamiento (Req 11).
- `.kiro/specs/unificacion-full-delta/design.md` — diseño, modelos de datos y estrategia de pruebas.
- `.kiro/specs/unificacion-full-delta/requirements.md` — requisitos y glosario.
