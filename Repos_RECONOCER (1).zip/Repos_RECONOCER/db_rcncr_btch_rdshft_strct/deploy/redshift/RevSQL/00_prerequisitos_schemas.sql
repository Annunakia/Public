-- Rollback 00: prerrequisitos (funcion + schemas locales)
-- Revierte 00_prerequisitos_schemas.sql
-- Redshift NO soporta 'DROP FUNCTION IF EXISTS'; se usa DROP SCHEMA ... CASCADE
-- que elimina el schema junto con la funcion y demas objetos dependientes.
DROP SCHEMA IF EXISTS bdm_tempo CASCADE;
DROP SCHEMA IF EXISTS bdm_datos CASCADE;
