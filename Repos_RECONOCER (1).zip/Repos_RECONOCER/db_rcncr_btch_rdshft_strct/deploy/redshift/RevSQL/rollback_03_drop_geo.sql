-- Rollback 03: objetos GEO (Enriquecimiento Regla 3)
-- Revierte 03_ddl_geo.sql en orden inverso a la creacion.
-- Redshift NO soporta DROP FUNCTION IF EXISTS: se usa la firma exacta.
DROP FUNCTION bdm_datos.geo_get_config(VARCHAR, VARCHAR);
DROP TABLE IF EXISTS bdm_datos.geo_distancias;
DROP TABLE IF EXISTS bdm_datos.geo_atributos;
DROP TABLE IF EXISTS bdm_datos.geo_lote_control;
DROP TABLE IF EXISTS bdm_datos.geo_config;
