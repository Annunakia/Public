# Verificación de despliegue — unificacion-full-delta (Tarea 10.3)

Este documento verifica el cumplimiento de las **restricciones transversales de despliegue**
(Requisitos 12.1–12.6) y de las lecciones de despliegue aplicables (#1, #6, #7, #9, #10, #11,
#12, #13, #14) sobre los artefactos reales de la funcionalidad `unificacion-full-delta`.

Es una verificación **documental/de inspección** (según la Testing Strategy del `design.md`,
las restricciones de despliegue no son aptas para PBT y se cubren por inspección). Cada check
lista el comando de verificación reproducible y el resultado observado sobre el árbol de repos
`SP-Reales-Experian/Repos_RECONOCER/` (los 3 repos desplegables) y los fuentes de trabajo en
`ws-unificacion/src/redshift/`.

- Fecha de verificación: al ejecutar la Tarea 10.3.
- Alcance: los 3 repos `db_rcncr_btch_rdshft_strct`, `db_rcncr_btch_rdshft_pgm`,
  `db_rcncr_btch_rdshft_dt` y los fuentes de la unificación FULL/DELTA.
- Los `.git/` se excluyen de todos los checks.

## Resumen de resultados

| # | Check | Requisito / Lección | Resultado |
|---|-------|---------------------|-----------|
| 1 | Orden de despliegue `strct → pgm → dt` | 12.1, #6 | PASA |
| 2 | UTF-8 sin BOM en `.sql` / `.par` | 12.2, #3, #5 | PASA |
| 3 | `NONATOMIC` consistente en la cadena de CALL | 12.3, #13 | PASA |
| 4 | Rollback de FUNCIONES sin `IF EXISTS` (firma exacta / `DROP SCHEMA CASCADE`) | 12.4, #10 | PASA (con nota) |
| 5 | Rollback de PROCEDIMIENTOS con `DROP PROCEDURE nombre(firma);` sin `IF EXISTS` | 12.4, #12, #14 | PASA |
| 6 | Idempotencia: `CREATE TABLE IF NOT EXISTS`, `CREATE OR REPLACE` | 12.5 | PASA |
| 7 | Esquemas `bdm_datos` / `bdm_tempo`; sin `GRANT ... TO PUBLIC` | 12.6 | PASA |
| 8 | `.jenkins.yml` con `application: dba_rncr_batch` en los 3 repos | #1 | PASA |
| 9 | `CALL`/`run_*` a `sp_unificacion_ciclo` con los 6 params exactos del Framework_Batch | 12.1, #11 | PASA |
| 10 | Paridad `deploy.par` / `rollback.par` en el repo `strct` (tipo struct) | 12.4, #9 | PASA |
| 11 | Changeset incremental: el commit toca un `.sql` desplegable | #7 | PASA |

---

## Check 1 — Orden de despliegue `strct → pgm → dt` (Req 12.1, lección #6)

El orden se materializa en el campo `order` del `.jenkins.yml` de cada repo (etiqueta; el
lanzamiento es manual, repo por repo) y en la dependencia lógica: `dt` invoca procedimientos
creados por `pgm`, que a su vez leen tablas creadas por `strct`.

- `db_rcncr_btch_rdshft_strct/.jenkins.yml` → `order: 1`
- `db_rcncr_btch_rdshft_pgm/.jenkins.yml` → `order: 2`
- `db_rcncr_btch_rdshft_dt/.jenkins.yml` → `order: 3`

Comando:

```bash
grep -rn "order:" SP-Reales-Experian/Repos_RECONOCER/*/.jenkins.yml
```

**Resultado:** el orden declarado es `strct(1) → pgm(2) → dt(3)`. PASA.

## Check 2 — UTF-8 sin BOM (Req 12.2, lecciones #3/#5)

Se revisa que ningún `.sql`/`.par` de los repos desplegables ni de los fuentes de la
unificación empiece con la marca BOM (`EF BB BF`).

Comando:

```bash
while IFS= read -r f; do
  head -c 3 "$f" | LC_ALL=C grep -q $'\xEF\xBB\xBF' && echo "BOM: $f"
done < <(find SP-Reales-Experian/Repos_RECONOCER ws-unificacion/src/redshift \
           -type f \( -name "*.sql" -o -name "*.par" \) ! -path "*/.git/*")
```

**Resultado:** 0 archivos con BOM. PASA.

## Check 3 — `NONATOMIC` consistente (Req 12.3, lección #13)

Los procedimientos nuevos de la funcionalidad se declaran `LANGUAGE plpgsql NONATOMIC`,
coherentes con la cadena `sp_unificacion_*` / `sp_geo_*` existente. Mezclar modos rompe con
`P0001: created in one transaction mode cannot be invoked from another`.

Objetos verificados (`ws-unificacion/src/redshift/sql/`):

- `14_traza_procedures.sql` → `unif_traza_inicio`, `unif_traza_fin` (2 × `NONATOMIC`).
- `15_sp_unif_control_abrir_cerrar.sql` → `unif_control_abrir`, `unif_control_cerrar`
  (2 × `LANGUAGE plpgsql NONATOMIC`).
- `16_sp_unificacion_ciclo.sql` → `sp_unificacion_ciclo` (`LANGUAGE plpgsql NONATOMIC`).

Comando:

```bash
grep -rniE "\bnonatomic\b" ws-unificacion/src/redshift/sql/*.sql
```

(En `14_traza_procedures.sql` la cláusula `NONATOMIC` aparece en su propia línea tras
`LANGUAGE plpgsql`; en `15`/`16` aparece como `LANGUAGE plpgsql NONATOMIC`. Ambas formas
son equivalentes.)

**Resultado:** todos los procedimientos de la cadena declaran `NONATOMIC`. La función
`unif_resolver_param` es `LANGUAGE sql STABLE` (no transaccional, no aplica el modo). PASA.

## Check 4 — Rollback de FUNCIONES sin `IF EXISTS` (Req 12.4, lección #10)

Redshift NO soporta `DROP FUNCTION IF EXISTS` (`syntax error at or near "EXISTS"`). El patrón
comprobado en la bitácora para revertir funciones es `DROP SCHEMA ... CASCADE`.

La única función nueva es `bdm_datos.unif_resolver_param`. Su rollback está en
`ws-unificacion/src/redshift/rev-sql/12_rollback_fn_unif_resolver_param.sql`.

**Decisión documentada (nota):** el schema `bdm_datos` es compartido por todo el
Reconocer_Batch (tablas permanentes, procedimientos, otras funciones). Aplicar
`DROP SCHEMA bdm_datos CASCADE` para revertir una sola función tendría un blast radius
inaceptable. Por eso el rollback revierte SOLO la función con la **firma exacta** y **sin**
`IF EXISTS`:

```sql
DROP FUNCTION bdm_datos.unif_resolver_param(VARCHAR, VARCHAR);
```

Esto respeta la restricción dura de la lección #10 (nunca `DROP FUNCTION IF EXISTS`) y el mismo
criterio de `01_rollback_schemas_roles.sql` (no eliminar el schema compartido). Si la función
no existe, el statement falla con `function ... does not exist`, un fallo esperado y seguro en
un rollback de objeto no desplegado.

Comando:

```bash
grep -rniE "^[[:space:]]*drop[[:space:]]+function[[:space:]]+if[[:space:]]+exists" \
  SP-Reales-Experian/Repos_RECONOCER ws-unificacion/src/redshift --include="*.sql" | grep -v "/.git/"
```

**Resultado:** 0 ocurrencias reales de `DROP FUNCTION IF EXISTS` (las coincidencias de
texto están en comentarios que documentan la prohibición). PASA (con la nota anterior).

## Check 5 — Rollback de PROCEDIMIENTOS con firma exacta y sin `IF EXISTS` (Req 12.4, lecciones #12/#14)

Redshift NO soporta `DROP PROCEDURE IF EXISTS`. El rollback usa `DROP PROCEDURE nombre(firma);`
con la firma exacta del `CREATE`. Firmas verificadas de los procedimientos nuevos
(`ws-unificacion/src/redshift/rev-sql/`):

| Procedimiento | Firma en el rollback |
|---------------|----------------------|
| `sp_unificacion_ciclo` | `(VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR, VARCHAR)` |
| `unif_control_abrir` | `(VARCHAR, INTEGER, DATE, DATE, BOOLEAN, BIGINT)` |
| `unif_control_cerrar` | `(BIGINT, VARCHAR, DATE, BIGINT, BIGINT, BIGINT)` |
| `unif_traza_inicio` | `(BIGINT, INTEGER, VARCHAR)` |
| `unif_traza_fin` | `(BIGINT, VARCHAR, VARCHAR, BIGINT, BIGINT, BIGINT, BIGINT, BIGINT)` |

Los orquestadores del Framework_Batch (`sp_unificacion_regla1/2/3`, `sp_unificacion_ciclo`)
llevan 6 params VARCHAR; los escenarios llevan sus firmas propias (p.ej. `(VARCHAR, INTEGER)`).

Comando:

```bash
grep -rniE "^[[:space:]]*drop[[:space:]]+procedure[[:space:]]+if[[:space:]]+exists" \
  SP-Reales-Experian/Repos_RECONOCER ws-unificacion/src/redshift --include="*.sql" | grep -v "/.git/"
```

**Resultado:** 0 ocurrencias reales de `DROP PROCEDURE IF EXISTS`; todos los rollbacks usan
`DROP PROCEDURE nombre(firma);`. PASA.

## Check 6 — Idempotencia de deploy (Req 12.5)

- DDL de control con `CREATE TABLE IF NOT EXISTS`:
  `11_ddl_unif_control.sql` → `bdm_datos.unif_control` y `bdm_datos.unif_control_etapa`.
- Función y procedimientos con `CREATE OR REPLACE`:
  `12_fn_unif_resolver_param.sql` (FUNCTION), `14_traza_procedures.sql`,
  `15_sp_unif_control_abrir_cerrar.sql`, `16_sp_unificacion_ciclo.sql` (PROCEDURE).

Comando:

```bash
grep -rniE "create[[:space:]]+table[[:space:]]+if[[:space:]]+not[[:space:]]+exists" \
  ws-unificacion/src/redshift/sql/11_ddl_unif_control.sql
grep -rniE "create[[:space:]]+or[[:space:]]+replace[[:space:]]+(procedure|function)" \
  ws-unificacion/src/redshift/sql/1[2456]_*.sql
```

**Resultado:** DDL idempotente y objetos de código con `CREATE OR REPLACE`. PASA.

## Check 7 — Esquemas y ausencia de `GRANT ... TO PUBLIC` (Req 12.6)

Objetos permanentes en `bdm_datos`, staging temporal en `bdm_tempo` (patrón DROP-CREATE),
en el cluster consumidor. Ningún `GRANT ... TO PUBLIC`.

Comando:

```bash
grep -rniE "^[[:space:]]*grant[[:space:]].*to[[:space:]]+public" \
  SP-Reales-Experian/Repos_RECONOCER ws-unificacion/src/redshift --include="*.sql" | grep -v "/.git/"
```

**Resultado:** 0 ocurrencias reales de `GRANT ... TO PUBLIC` (las coincidencias de texto están
en comentarios que documentan la prohibición). PASA.

## Check 8 — `.jenkins.yml` con `application: dba_rncr_batch` (lección #1)

Un `application` incorrecto provoca `FATAL: database ... does not exist`.

Comando:

```bash
grep -rn "application:" SP-Reales-Experian/Repos_RECONOCER/*/.jenkins.yml
```

**Resultado:** los 3 repos declaran `application: dba_rncr_batch`. PASA.

## Check 9 — `CALL` a `sp_unificacion_ciclo` con los 6 params exactos (Req 12.1, lección #11)

Una firma desalineada respecto al `CREATE PROCEDURE` produce `procedure ... does not exist`.
Los scripts `run_*` del repo `dt` pasan los 6 argumentos con el mapeo del Framework_Batch
`(in_solicitud, in_nit_suscriptor, in_path_archivo, in_nemotecnico=MODO,
in_id_facturacion=LOTE, in_fecha_ejecucion=FECHA)`, vacíos `''` los no usados:

- `run_unificacion_ejecucion_secuencial.sql` → `('', '', '', ':MODO', ':LOTE', ':FECHA')`
- `run_unificacion_full.sql` → `('', '', '', 'FULL', ':LOTE', ':FECHA')`
- `run_unificacion_delta.sql` → `('', '', '', 'DELTA', ':LOTE', ':FECHA')`

Comando:

```bash
grep -rniE "call[[:space:]]+bdm_datos\.sp_unificacion_ciclo" \
  SP-Reales-Experian/Repos_RECONOCER/db_rcncr_btch_rdshft_dt/deploy/redshift/SQL/*.sql
```

**Resultado:** los 3 scripts pasan exactamente 6 argumentos con el mapeo correcto. PASA.

## Check 10 — Paridad de rollback en `strct` (Req 12.4, lección #9)

El tipo `struct` exige que cada línea del `deploy.par` tenga su contrapartida en `rollback.par`
(en orden inverso) y su archivo en `RevSQL/`. Sin paridad completa el deploy del `strct` falla
con `REDSHIFT:220`.

`deploy.par` (strct):
```
00_prerequisitos_schemas.sql
01_ddl_unificacion_direccion.sql
01b_ddl_unificacion_direccion_mock.sql
02_vistas_insumo_edf_views.sql
02b_vistas_insumo_mock.sql
03_ddl_geo.sql
```
`rollback.par` (strct), orden inverso, un rollback por script.

**Nota de seguimiento:** la DDL de las tablas de control `unif_control` / `unif_control_etapa`
(Tarea 1, `NN_ddl_unif_control.sql`) y su rollback deben quedar listados con paridad en el
`deploy.par` / `rollback.par` del repo `strct` al integrar los artefactos de `ws-unificacion`
a los repos desplegables. Los fuentes ya existen en `ws-unificacion/src/redshift/sql/11_ddl_unif_control.sql`
y `.../rev-sql/11_rollback_ddl_unif_control.sql` con `DROP TABLE IF EXISTS` (válido).

**Resultado:** la paridad del `strct` actual se cumple; queda la nota de integración de la
DDL de control con su rollback al promover a los repos. PASA.

## Check 11 — Changeset incremental con `.sql` desplegable (lección #7)

Todo cambio de esta tarea que deba entrar en el changeset toca un `.sql` desplegable
(no basta un `.md`). Los scripts `run_unificacion_full.sql` / `run_unificacion_delta.sql` /
`run_unificacion_ejecucion_secuencial.sql` (Tarea 10.1) y los `.sql` de `pgm`/`strct` son los
artefactos desplegables; este documento es la evidencia de verificación asociada. PASA.

---

## Conclusión

Todos los checks de restricciones transversales de despliegue (Req 12.1–12.6) y las lecciones
aplicables (#1, #6, #7, #9, #10, #11, #12, #13, #14) se cumplen sobre los artefactos actuales.
La única acción de seguimiento es de **integración** (Check 10): listar la DDL de control y su
rollback con paridad en el `deploy.par`/`rollback.par` del repo `strct` al promover los fuentes
de `ws-unificacion` a los repos desplegables, y verificar en el bring-up de QA el soporte de
`MERGE` (decisión firme del diseño: fallback `DELETE`+`INSERT` si no está disponible).
