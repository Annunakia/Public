#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
_bootstrap_catalog.py — utilidad interna (one-shot) para sembrar el catalogo
verbatim de los cuerpos SQL reales de la Unificacion en _catalog_seed.py.

NO forma parte del pipeline de generacion. Se ejecuta una unica vez para capturar
byte-a-byte los cuerpos reales actuales (los mismos que hoy estan desplegados) y
embeberlos como fuente unica. A partir de ahi, los generadores
gen_unificacion_sps_por_escenario.py (real) y gen_unificacion_mock_sps.py (mock)
emiten el SQL desde ese catalogo, aplicando el predicado condicional FULL/DELTA
en preparar_insumo.

Uso (solo si se necesita re-sembrar desde los SQL reales actuales):
    python3 tools/_bootstrap_catalog.py
"""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SQL_DIR = os.path.normpath(os.path.join(HERE, "..", "deploy", "redshift", "SQL"))

# Orden estable de los archivos REALES (los mock se derivan por transform).
REAL_FILES = [
    "sp_unificacion_cleanup.sql",
    "sp_unificacion_r1_preparar_insumo.sql",
    "sp_unificacion_r1_esc1_ciiu10_mismo_texto_padre_lab_crr.sql",
    "sp_unificacion_r1_esc2_ciiu81_90_mismo_texto_padre_res_crr.sql",
    "sp_unificacion_r1_esc3_otros_ciiu_mayor_entidades_reportan.sql",
    "sp_unificacion_regla1.sql",
    "sp_unificacion_r2_preparar_insumo.sql",
    "sp_unificacion_r2_esc1_complemento_vacio_esc2_substring_complemento.sql",
    "sp_unificacion_r2_esc3_sin_nit_misma_nomenclatura.sql",
    "sp_unificacion_r2_esc4_diccionario_frecuencia_complemento.sql",
    "sp_unificacion_r2_esc5_nomenclatura_menor_nivel_pierde.sql",
    "sp_unificacion_r2_esc6_frecuencia_complemento_gana.sql",
    "sp_unificacion_r2_motor_nit_empates_nuevas_direcciones.sql",
    "sp_unificacion_regla2.sql",
    "sp_unificacion_r3_esc1_geo_misma_via_puerta_cercana.sql",
    "sp_unificacion_regla3.sql",
]

# Archivos MOCK espejo (mismo orden logico que los reales, sin el cleanup, que es
# unico y comun). El mock NO tiene sp_unificacion_mock_cleanup.
MOCK_FILES = [
    "sp_unificacion_mock_r1_preparar_insumo.sql",
    "sp_unificacion_mock_r1_esc1_ciiu10_mismo_texto_padre_lab_crr.sql",
    "sp_unificacion_mock_r1_esc2_ciiu81_90_mismo_texto_padre_res_crr.sql",
    "sp_unificacion_mock_r1_esc3_otros_ciiu_mayor_entidades_reportan.sql",
    "sp_unificacion_mock_regla1.sql",
    "sp_unificacion_mock_r2_preparar_insumo.sql",
    "sp_unificacion_mock_r2_esc1_complemento_vacio_esc2_substring_complemento.sql",
    "sp_unificacion_mock_r2_esc3_sin_nit_misma_nomenclatura.sql",
    "sp_unificacion_mock_r2_esc4_diccionario_frecuencia_complemento.sql",
    "sp_unificacion_mock_r2_esc5_nomenclatura_menor_nivel_pierde.sql",
    "sp_unificacion_mock_r2_esc6_frecuencia_complemento_gana.sql",
    "sp_unificacion_mock_r2_motor_nit_empates_nuevas_direcciones.sql",
    "sp_unificacion_mock_regla2.sql",
    "sp_unificacion_mock_r3_esc1_geo_misma_via_puerta_cercana.sql",
    "sp_unificacion_mock_regla3.sql",
]


import subprocess

REPO_ROOT = os.path.normpath(os.path.join(HERE, ".."))
REL_SQL = "deploy/redshift/SQL"


def _read_lf(fname):
    # Sembramos desde el blob versionado en git (forma canonica LF, sin BOM),
    # no del working tree (que en esta maquina quedo con CRLF). Asi la
    # regeneracion reproduce byte-a-byte lo que esta bajo control de versiones.
    rel = "%s/%s" % (REL_SQL, fname)
    raw = subprocess.check_output(["git", "show", ":" + rel], cwd=REPO_ROOT)
    assert raw[:3] != b"\xef\xbb\xbf", "BOM inesperado en %s" % fname
    return raw.decode("utf-8").replace("\r\n", "\n")


def main():
    real = [(f, _read_lf(f)) for f in REAL_FILES]
    mock = [(f, _read_lf(f)) for f in MOCK_FILES]

    out = os.path.join(HERE, "_catalog_seed.py")
    with open(out, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("# -*- coding: utf-8 -*-\n")
        fh.write("# Semilla verbatim (LF) de los cuerpos SQL reales y mock.\n")
        fh.write("# Generada por _bootstrap_catalog.py — NO editar a mano.\n")
        fh.write("REAL_SEED = {\n")
        for fname, text_lf in real:
            fh.write("    %r:\n" % fname)
            fh.write("        %r,\n" % text_lf)
        fh.write("}\n\n")
        fh.write("MOCK_SEED = {\n")
        for fname, text_lf in mock:
            fh.write("    %r:\n" % fname)
            fh.write("        %r,\n" % text_lf)
        fh.write("}\n")
    print("Escrito", out, "con", len(real), "reales y", len(mock), "mock")


if __name__ == "__main__":
    main()
