# -*- coding: utf-8 -*-
"""
gen_unificacion_common.py — fuente unica de la logica FULL/DELTA de la Unificacion.

Los generadores gen_unificacion_sps_por_escenario.py (Variante_Real) y
gen_unificacion_mock_sps.py (Variante_Mock) emiten el SQL desde este modulo, de
modo que ambas variantes NO divergen (Req 7.4). En particular, la transformacion
de preparar_insumo (predicado condicional FULL/DELTA) se define UNA sola vez aqui y
se aplica identica a los cuatro archivos preparar_insumo (R1/R2, real y mock).

Semilla verbatim:
  - _catalog_seed.py contiene REAL_SEED y MOCK_SEED: los cuerpos SQL tal cual estan
    hoy desplegados (LF-normalizados). Son la base que los generadores reproducen
    byte-a-byte, salvo los cambios explicitos de logica aplicados en este modulo.
  - MOCK es un espejo determinista del REAL: el cuerpo de cada escenario mock se
    obtiene del real por reemplazos (v_xpm_->v_mock_, staging->stg_mock_, catalogos
    bdm_datos->bdm_stage, destino unificacion_direccion->unificacion_direccion_mock),
    mientras que bdm_datos.geo_atributos permanece comun. Por eso, aplicar el mismo
    cambio de preparar_insumo a ambas semillas mantiene la paridad exigida por 7.4.

Transversal (lecciones aprendidas): UTF-8 sin BOM, CRLF, NONATOMIC consistente.

Extension 6.1 (IMPLEMENTADA): la persistencia condicional al modo se emite
transformando en este mismo modulo, y de forma identica para real y mock:
  - apply_persistencia_modo: cada bloque INSERT legado de un escenario pasa a
    materializar el resultado en un staging y luego persistir con
    IF p_modo='FULL' THEN <INSERT append> ELSE <UPSERT> END IF. El UPSERT emite
    MERGE nativo (estrategia primaria) o DELETE-por-parejas-del-staging + INSERT
    (fallback), seleccionable por la bandera USAR_MERGE (env GEN_USAR_MERGE).
    El Lote_Corrida externo (p_lote) reemplaza el 1 hardcodeado; unifica_atributos
    (1|2|3) sigue siendo atributo, NO clave.
  - apply_regla_orquestador_modo: los orquestadores de regla propagan
    (p_modo, p_lote, p_watermark) a preparar_insumo y a cada escenario. Los reales
    los derivan de los params 4/5/6 del Framework_Batch (in_nemotecnico=modo,
    in_id_facturacion=lote, in_fecha_ejecucion=fecha) que re-emite el orquestador
    maestro; los mock los reciben por firma directa.
  - verify_upsert_equivalence: comprueba en generacion que usar_merge on/off
    persisten el MISMO conjunto de parejas Clave_Unificacion (mismo staging y
    mismas columnas clave).
Ambos caminos son semanticamente equivalentes e idempotentes (mismo estado final
por la Clave_Unificacion). La reconstruccion verbatim de la semilla no se rompe.
"""
import os

from _catalog_seed import REAL_SEED, MOCK_SEED

HERE = os.path.dirname(os.path.abspath(__file__))
SQL_DIR = os.path.normpath(os.path.join(HERE, "..", "deploy", "redshift", "SQL"))

GEN_REAL_TAG = "tools/gen_unificacion_sps_por_escenario.py"
GEN_MOCK_TAG = "tools/gen_unificacion_mock_sps.py (espejo mock)"

# ----------------------------------------------------------------------------
# Bandera de estrategia UPSERT del generador (Tarea 6.1 — decision firme)
# ----------------------------------------------------------------------------
# usar_merge = True  -> estrategia PRIMARIA: MERGE nativo (una sola sentencia
#                       atomica; menos I/O; sin ventana DELETE->INSERT).
# usar_merge = False -> FALLBACK determinista: DELETE por el conjunto de parejas
#                       del staging del resultado + INSERT. Se usa si el cluster
#                       consumidor no soporta MERGE (se verifica en el bring-up
#                       de QA). Mismo estado final por la Clave_Unificacion.
#
# Ambos caminos son semanticamente equivalentes e idempotentes: persisten el
# MISMO conjunto de parejas Clave_Unificacion desde el MISMO staging del
# resultado. La logica de negocio (FULL/DELTA) NO depende de cual se emita.
#
# Override por entorno para regenerar con el fallback sin tocar el codigo:
#   GEN_USAR_MERGE=0  (o "false"/"no")  -> fallback DELETE+INSERT
#   GEN_USAR_MERGE=1  (o ausente)       -> MERGE primario (default)
def _usar_merge_default():
    val = os.environ.get("GEN_USAR_MERGE")
    if val is None:
        return True
    return val.strip().lower() not in ("0", "false", "no", "off")


USAR_MERGE = _usar_merge_default()

# ----------------------------------------------------------------------------
# Predicado condicional FULL/DELTA en preparar_insumo
#   Tarea 5.1 — Req 3.1, 3.2, 3.3, 7.4
# ----------------------------------------------------------------------------
# DELTA: ventana inclusiva por dia (frontera inferior '>=') mas relaciones de
#        fecha nula.
# FULL : sin frontera de fecha; el predicado colapsa a TRUE por p_modo='FULL'.
# Se retira el no-op historico "rpu.ind_unificacion IS NULL" (la vista define
# ind_unificacion como constante NULL, por lo que nunca acotaba el universo).
_WHERE_NOOP = "  WHERE rpu.ind_unificacion IS NULL\n"
_WHERE_MODO = (
    "  WHERE 1 = 1\n"
    "    -- FULL: sin frontera de fecha (Req 3.3)\n"
    "    -- DELTA: ventana inclusiva por dia + nulos (Req 3.1, 3.2)\n"
    "    AND ( p_modo = 'FULL'\n"
    "          OR rpu.fecha_relacion_persona_ubicaci >= p_watermark\n"
    "          OR rpu.fecha_relacion_persona_ubicaci IS NULL )\n"
)

# Firma: preparar_insumo pasa de () a (p_modo VARCHAR, p_watermark DATE).
_SIG_MODO_PARAMS = (
    "(\n"
    "    p_modo      VARCHAR,   -- FULL | DELTA (modo efectivo de la corrida)\n"
    "    p_watermark DATE       -- frontera inferior inclusiva (solo aplica en DELTA)\n"
    ")"
)

# Procedimientos preparar_insumo (real y mock) sobre los que aplica el cambio.
_PREPARAR_INSUMO_PROCS = (
    "sp_unificacion_r1_preparar_insumo",
    "sp_unificacion_r2_preparar_insumo",
    "sp_unificacion_mock_r1_preparar_insumo",
    "sp_unificacion_mock_r2_preparar_insumo",
)


def _proc_of(fname):
    return fname[: -len(".sql")] if fname.endswith(".sql") else fname


def apply_preparar_insumo_modo(fname, text):
    """Inyecta p_modo/p_watermark y el predicado condicional en preparar_insumo.

    Se aplica identico a la variante real y mock (Req 7.4). En cualquier otro
    archivo es un no-op.
    """
    proc = _proc_of(fname)
    if proc not in _PREPARAR_INSUMO_PROCS:
        return text

    # 1) Firma: () -> (p_modo VARCHAR, p_watermark DATE)
    old_sig = "CREATE OR REPLACE PROCEDURE bdm_datos.%s()" % proc
    new_sig = "CREATE OR REPLACE PROCEDURE bdm_datos.%s%s" % (proc, _SIG_MODO_PARAMS)
    if old_sig not in text:
        raise AssertionError("firma () no encontrada en %s" % fname)
    text = text.replace(old_sig, new_sig)

    # 2) WHERE no-op -> predicado condicional al modo.
    if _WHERE_NOOP not in text:
        raise AssertionError("WHERE no-op no encontrado en %s" % fname)
    text = text.replace(_WHERE_NOOP, _WHERE_MODO)

    return text


# ----------------------------------------------------------------------------
# Persistencia condicional al modo en los escenarios
#   Tarea 6.1 — Req 5.1..5.6, 6.2, 6.3, 7.1, 7.3, 15.1, 15.3
# ----------------------------------------------------------------------------
# Columnas de la Tabla_Destino (mismo orden en real y mock). El INSERT legado es
# posicional (sin lista de columnas); aqui la explicitamos para poder emitir el
# MERGE por la Clave_Unificacion y un INSERT/DELETE deterministas.
#   Clave_Unificacion = (cod_dw_persona_ubic, cod_dw_direccion_unificada).
#   unifica_atributos (1|2|3) es ATRIBUTO, NO parte de la clave (Req 5.4).
_DEST_COLS = (
    "cod_dw_persona_ubic",
    "cod_dw_direccion_unificada",
    "unifica_atributos",
    "fecha_unificacion",
    "lote",
    "severidad",
    "usuario_bd",
)
_KEY_COLS = ("cod_dw_persona_ubic", "cod_dw_direccion_unificada")
_NONKEY_COLS = tuple(c for c in _DEST_COLS if c not in _KEY_COLS)

# Indice (0-based) de la columna 'lote' en la proyeccion legada del SELECT.
_LOTE_COL_IDX = _DEST_COLS.index("lote")  # 4

# Escenarios (real y mock) que persisten en la Tabla_Destino y por tanto reciben
# el par (p_modo, p_lote). El motor R2 no persiste (solo materializa staging)
# pero tambien pasa a (p_modo, p_lote) para que el orquestador lo invoque de
# forma uniforme. preparar_insumo usa (p_modo, p_watermark) (Tarea 5.1).
_SCENARIO_PROCS = (
    "sp_unificacion_r1_esc1_ciiu10_mismo_texto_padre_lab_crr",
    "sp_unificacion_r1_esc2_ciiu81_90_mismo_texto_padre_res_crr",
    "sp_unificacion_r1_esc3_otros_ciiu_mayor_entidades_reportan",
    "sp_unificacion_r2_esc1_complemento_vacio_esc2_substring_complemento",
    "sp_unificacion_r2_esc3_sin_nit_misma_nomenclatura",
    "sp_unificacion_r2_esc4_diccionario_frecuencia_complemento",
    "sp_unificacion_r2_esc5_nomenclatura_menor_nivel_pierde",
    "sp_unificacion_r2_esc6_frecuencia_complemento_gana",
    "sp_unificacion_r2_motor_nit_empates_nuevas_direcciones",
    "sp_unificacion_r3_esc1_geo_misma_via_puerta_cercana",
    # espejo mock
    "sp_unificacion_mock_r1_esc1_ciiu10_mismo_texto_padre_lab_crr",
    "sp_unificacion_mock_r1_esc2_ciiu81_90_mismo_texto_padre_res_crr",
    "sp_unificacion_mock_r1_esc3_otros_ciiu_mayor_entidades_reportan",
    "sp_unificacion_mock_r2_esc1_complemento_vacio_esc2_substring_complemento",
    "sp_unificacion_mock_r2_esc3_sin_nit_misma_nomenclatura",
    "sp_unificacion_mock_r2_esc4_diccionario_frecuencia_complemento",
    "sp_unificacion_mock_r2_esc5_nomenclatura_menor_nivel_pierde",
    "sp_unificacion_mock_r2_esc6_frecuencia_complemento_gana",
    "sp_unificacion_mock_r2_motor_nit_empates_nuevas_direcciones",
    "sp_unificacion_mock_r3_esc1_geo_misma_via_puerta_cercana",
)

# Nueva firma comun de los escenarios: (p_modo VARCHAR, p_lote INTEGER).
_SIG_ESC_PARAMS = (
    "(\n"
    "    p_modo VARCHAR,   -- FULL | DELTA (modo efectivo de la corrida)\n"
    "    p_lote INTEGER    -- Lote_Corrida externo (reemplaza el 1 hardcodeado)\n"
    ")"
)


def _split_top_level_commas(s):
    """Divide en comas de primer nivel (respeta parentesis). Sin comas en
    strings dentro de la proyeccion legada, basta con balancear parentesis."""
    parts, depth, cur = [], 0, []
    for ch in s:
        if ch == "(":
            depth += 1
            cur.append(ch)
        elif ch == ")":
            depth -= 1
            cur.append(ch)
        elif ch == "," and depth == 0:
            parts.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    parts.append("".join(cur))
    return parts


def _parse_insert_block(block):
    """Parsea un bloque INSERT legado:

        INSERT INTO bdm_datos.<dest>
        SELECT [DISTINCT] <proj7>
        FROM <tail...>;

    Devuelve (dest, proj_items[7], tail) donde tail incluye 'FROM ...' sin el ';'
    final. Reemplaza el literal de lote (5a columna) por 'p_lote'.
    """
    m_dest = block.split("\n", 1)
    header = m_dest[0].strip()
    assert header.startswith("INSERT INTO "), "header inesperado: %r" % header
    dest = header[len("INSERT INTO "):].strip()

    rest = m_dest[1]
    # Localizar 'SELECT' (posiblemente con DISTINCT) y el 'FROM' de nivel superior.
    idx_select = rest.index("SELECT")
    after_select = rest[idx_select + len("SELECT"):]
    # 'FROM' que abre la fuente: primer '\n  FROM ' o ' FROM ' de nivel superior.
    # Los SELECT legados no anidan FROM en la proyeccion, asi que el primer FROM
    # que aparece como palabra separada delimita la proyeccion.
    idx_from = _find_top_level_from(after_select)
    proj_raw = after_select[:idx_from]
    tail = after_select[idx_from:]  # 'FROM ...;'
    tail = tail.rstrip()
    assert tail.endswith(";"), "no termina en ';': %r" % tail[-40:]
    tail = tail[:-1].rstrip()  # sin ';'

    # DISTINCT lo aplicamos siempre nosotros (Req 5.5); lo quitamos de proj_raw.
    proj_stripped = proj_raw.strip()
    if proj_stripped.upper().startswith("DISTINCT"):
        proj_stripped = proj_stripped[len("DISTINCT"):].strip()

    items = [p.strip() for p in _split_top_level_commas(proj_stripped)]
    assert len(items) == len(_DEST_COLS), (
        "proyeccion con %d items (esperados %d): %r" % (len(items), len(_DEST_COLS), items)
    )
    # Reemplazar el Lote_Corrida hardcodeado por el parametro externo (Req 6.2/6.3).
    assert items[_LOTE_COL_IDX] == "1", (
        "lote esperado '1', hallado %r" % items[_LOTE_COL_IDX]
    )
    items[_LOTE_COL_IDX] = "p_lote /* Lote_Corrida externo */"
    return dest, items, tail


def _find_top_level_from(s):
    """Indice del primer 'FROM' de nivel superior (parentesis balanceados)."""
    depth = 0
    i = 0
    n = len(s)
    while i < n:
        ch = s[i]
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif depth == 0 and s[i:i + 4] == "FROM" and (i == 0 or not s[i - 1].isalnum()):
            nxt = s[i + 4] if i + 4 < n else " "
            if not nxt.isalnum():
                return i
        i += 1
    raise AssertionError("FROM de nivel superior no encontrado")


def _stg_name(proc):
    """Tabla de staging del resultado de la regla para este escenario."""
    return "bdm_tempo.%s_persist" % proc


def _render_persistencia(proc, dest, items, tail, usar_merge):
    """Emite: staging del resultado + IF p_modo='FULL' <append> ELSE <UPSERT>.

    El staging materializa el resultado de la regla con nombres de columna
    canonicos (_DEST_COLS) para poder aplicar tanto el INSERT append (FULL) como
    el UPSERT por la Clave_Unificacion (DELTA). unifica_atributos queda como
    atributo, NO como clave (Req 5.4).
    """
    stg = _stg_name(proc)
    proj_lines = ",\n".join(
        "    %s AS %s" % (expr, col) for expr, col in zip(items, _DEST_COLS)
    )
    cols_csv = ", ".join(_DEST_COLS)
    src_cols_csv = ", ".join("s.%s" % c for c in _DEST_COLS)

    lines = []
    lines.append("  -- Persistencia condicional al modo (Tarea 6.1, Req 5.1..5.6).")
    lines.append("  -- 1) Materializar el resultado de la regla (SELECT DISTINCT, Req 5.5).")
    lines.append("  DROP TABLE IF EXISTS %s;" % stg)
    lines.append("  CREATE TABLE %s" % stg)
    lines.append("  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)")
    lines.append("  AS")
    lines.append("  SELECT DISTINCT")
    lines.append(proj_lines)
    lines.append("  %s;" % tail)
    lines.append("")
    lines.append("  IF p_modo = 'FULL' THEN")
    lines.append("    -- FULL: append (el TRUNCATE lo hizo el orquestador una vez).")
    lines.append("    INSERT INTO %s" % dest)
    lines.append("      (%s)" % cols_csv)
    lines.append("    SELECT DISTINCT %s" % cols_csv)
    lines.append("    FROM %s;" % stg)
    lines.append("  ELSE")
    if usar_merge:
        set_lines = ",\n".join(
            "          %s = s.%s" % (c, c) for c in _NONKEY_COLS
        )
        on_lines = "\n".join(
            "      %st.%s = s.%s"
            % ("AND " if i else "ON  ", c, c)
            for i, c in enumerate(_KEY_COLS)
        )
        lines.append("    -- DELTA (estrategia PRIMARIA usar_merge=ON): MERGE nativo,")
        lines.append("    -- UPSERT por la Clave_Unificacion, sin truncar (Req 5.1, 5.2, 5.6).")
        lines.append("    MERGE INTO %s t" % dest)
        lines.append("    USING %s s" % stg)
        lines.append(on_lines)
        lines.append("    WHEN MATCHED THEN UPDATE SET")
        lines.append(set_lines)
        lines.append("    WHEN NOT MATCHED THEN INSERT")
        lines.append("      (%s)" % cols_csv)
        lines.append("      VALUES (%s);" % src_cols_csv)
    else:
        where_lines = "\n".join(
            "    %st.%s = s.%s"
            % ("WHERE " if i == 0 else "  AND ", c, c)
            for i, c in enumerate(_KEY_COLS)
        )
        lines.append("    -- DELTA (FALLBACK usar_merge=OFF): DELETE por el conjunto de")
        lines.append("    -- parejas del staging + INSERT; idempotente y equivalente al")
        lines.append("    -- MERGE (mismo estado final por la Clave_Unificacion, Req 5.6, 15.1).")
        lines.append("    DELETE FROM %s t" % dest)
        lines.append("    USING %s s" % stg)
        lines.append(where_lines + ";")
        lines.append("    INSERT INTO %s" % dest)
        lines.append("      (%s)" % cols_csv)
        lines.append("    SELECT DISTINCT %s" % cols_csv)
        lines.append("    FROM %s;" % stg)
    lines.append("  END IF;")
    lines.append("")
    lines.append("  DROP TABLE IF EXISTS %s;" % stg)
    return "\n".join(lines)


def apply_persistencia_modo(fname, text, usar_merge=None):
    """Transforma el/los bloque(s) INSERT de un escenario en persistencia
    condicional al modo, y cambia su firma a (p_modo, p_lote). No-op fuera de
    los escenarios."""
    if usar_merge is None:
        usar_merge = USAR_MERGE
    proc = _proc_of(fname)
    if proc not in _SCENARIO_PROCS:
        return text

    # 1) Firma: () -> (p_modo VARCHAR, p_lote INTEGER)
    old_sig = "CREATE OR REPLACE PROCEDURE bdm_datos.%s()" % proc
    new_sig = "CREATE OR REPLACE PROCEDURE bdm_datos.%s%s" % (proc, _SIG_ESC_PARAMS)
    if old_sig not in text:
        raise AssertionError("firma () no encontrada en %s" % fname)
    text = text.replace(old_sig, new_sig)

    # 2) Transformar cada bloque INSERT INTO <dest> ... ; (el motor no tiene).
    marker = "  INSERT INTO bdm_datos.unificacion_direccion"
    out = []
    i = 0
    while True:
        j = text.find(marker, i)
        if j == -1:
            out.append(text[i:])
            break
        out.append(text[i:j])
        # Capturar el bloque completo hasta el primer ';' que cierra el INSERT.
        end = text.find(";", j)
        assert end != -1, "INSERT sin ';' en %s" % fname
        block = text[j:end + 1].strip()  # sin indentacion inicial
        dest, items, tail = _parse_insert_block(block)
        out.append(_render_persistencia(proc, dest, items, tail, usar_merge))
        i = end + 1
    return "".join(out)


def _scenario_clave_pairs_signature(fname, text):
    """Firma canonica del conjunto de parejas Clave_Unificacion que el escenario
    persiste: (dest, key_cols, staging SELECT sin el bloque de persistencia).

    Es INDEPENDIENTE de usar_merge on/off porque ambas estrategias parten del
    MISMO staging y aplican las MISMAS claves. Sirve para verificar (Req 6.1)
    que los dos caminos producen el mismo conjunto de parejas.
    """
    proc = _proc_of(fname)
    if proc not in _SCENARIO_PROCS:
        return None
    sig = []
    # Anclamos en el CREATE del staging (fuente comun de parejas) y capturamos
    # hasta el IF p_modo, que es donde empieza la parte que SI depende de la
    # estrategia (MERGE vs DELETE+INSERT).
    anchor = "  CREATE TABLE %s\n" % _stg_name(proc)
    i = 0
    while True:
        j = text.find(anchor, i)
        if j == -1:
            break
        if_idx = text.find("  IF p_modo = 'FULL' THEN", j)
        assert if_idx != -1, "IF p_modo no hallado tras staging en %s" % fname
        sig.append(text[j:if_idx])
        i = if_idx + 1
    return (proc, _KEY_COLS, tuple(sig))


# ----------------------------------------------------------------------------
# Orquestadores de regla (real y mock): propagacion de (p_modo, p_lote, watermark)
#   Tarea 6.1 (coordina con 5.1 y el orquestador maestro 16_sp_unificacion_ciclo)
# ----------------------------------------------------------------------------
# El orquestador maestro invoca las reglas REALES con la firma Framework_Batch de
# 6 params VARCHAR, re-emitiendo in_nemotecnico=modo, in_id_facturacion=lote,
# in_fecha_ejecucion=fecha. Las reglas reales derivan de ahi (p_modo, p_lote,
# p_watermark) y los propagan a preparar_insumo(p_modo, p_watermark) y a cada
# escenario(p_modo, p_lote). Las reglas MOCK (firma directa, sin Framework_Batch)
# reciben (p_modo, p_lote, p_watermark) para el mismo proposito (paridad Req 7.4).
_REGLA_REAL_PROCS = (
    "sp_unificacion_regla1",
    "sp_unificacion_regla2",
    "sp_unificacion_regla3",
)
_REGLA_MOCK_PROCS = (
    "sp_unificacion_mock_regla1",
    "sp_unificacion_mock_regla2",
    "sp_unificacion_mock_regla3",
)

# Prologo (real): deriva p_modo/p_lote/p_watermark de los params Framework_Batch.
_REGLA_REAL_DECLARE = (
    "AS $$\n"
    "DECLARE\n"
    "  -- (Tarea 6.1) El orquestador maestro re-emite en los slots 4/5/6 del\n"
    "  -- Framework_Batch: in_nemotecnico=Modo_Corrida, in_id_facturacion=Lote_Corrida,\n"
    "  -- in_fecha_ejecucion=Watermark (frontera inferior inclusiva de la ventana\n"
    "  -- DELTA; NO es la Fecha_Proceso). Se derivan aqui y se propagan a\n"
    "  -- preparar_insumo(p_modo, p_watermark) y a cada escenario(p_modo, p_lote);\n"
    "  -- ningun escenario re-parsea el Framework_Batch.\n"
    "  p_modo      VARCHAR := NULLIF(UPPER(TRIM(COALESCE(in_nemotecnico, ''))), '');\n"
    "  p_lote      INTEGER := CAST(NULLIF(TRIM(COALESCE(in_id_facturacion, '')), '') AS INTEGER);\n"
    "  p_watermark DATE    := CAST(NULLIF(TRIM(COALESCE(in_fecha_ejecucion, '')), '') AS DATE);\n"
    "BEGIN\n"
    "\n"
    "  IF p_modo IS NULL THEN\n"
    "    p_modo := 'FULL';   -- FULL por defecto (no romper lo desplegado, Req 10.1).\n"
    "  END IF;\n"
)
_REGLA_REAL_OLD_HEAD = "AS $$\nBEGIN\n"

# Prologo (mock): firma directa (p_modo, p_lote, p_watermark).
_SIG_REGLA_MOCK = (
    "(\n"
    "    p_modo      VARCHAR,   -- FULL | DELTA (modo efectivo de la corrida)\n"
    "    p_lote      INTEGER,   -- Lote_Corrida externo\n"
    "    p_watermark DATE       -- frontera inferior inclusiva (solo aplica en DELTA)\n"
    ")"
)


def apply_regla_orquestador_modo(fname, text):
    """Propaga (p_modo, p_lote, p_watermark) desde el orquestador de regla a
    preparar_insumo y a cada escenario. Real: deriva de Framework_Batch; Mock:
    firma directa. No-op fuera de los orquestadores de regla."""
    proc = _proc_of(fname)
    is_real = proc in _REGLA_REAL_PROCS
    is_mock = proc in _REGLA_MOCK_PROCS
    if not (is_real or is_mock):
        return text

    if is_real:
        # Insertar el DECLARE que deriva modo/lote/watermark.
        assert _REGLA_REAL_OLD_HEAD in text, "cabecera AS $$ BEGIN no hallada en %s" % fname
        text = text.replace(_REGLA_REAL_OLD_HEAD, _REGLA_REAL_DECLARE, 1)
    else:
        # Mock: cambiar firma () -> (p_modo, p_lote, p_watermark).
        old_sig = "CREATE OR REPLACE PROCEDURE bdm_datos.%s()" % proc
        new_sig = "CREATE OR REPLACE PROCEDURE bdm_datos.%s%s" % (proc, _SIG_REGLA_MOCK)
        assert old_sig in text, "firma () no hallada en %s" % fname
        text = text.replace(old_sig, new_sig)

    # preparar_insumo(): -> preparar_insumo(p_modo, p_watermark)
    text = text.replace(
        "_preparar_insumo();",
        "_preparar_insumo(p_modo, p_watermark);",
    )
    # Cada escenario/motor CALL ...(); -> CALL ...(p_modo, p_lote);
    # Solo afectan a los procs de escenario (r1_esc*, r2_esc*, r2_motor, r3_esc*).
    for esc in _SCENARIO_PROCS:
        text = text.replace(
            "CALL bdm_datos.%s();" % esc,
            "CALL bdm_datos.%s(p_modo, p_lote);" % esc,
        )
    return text


# ----------------------------------------------------------------------------
# Catalogos finales (semilla + transformaciones de logica)
# ----------------------------------------------------------------------------
def _apply_all(fname, text, usar_merge=None):
    text = apply_preparar_insumo_modo(fname, text)          # Tarea 5.1
    text = apply_persistencia_modo(fname, text, usar_merge)  # Tarea 6.1 (escenarios)
    text = apply_regla_orquestador_modo(fname, text)         # Tarea 6.1 (orquestadores)
    return text


def build_real_catalog(usar_merge=None):
    """dict {fname: text_lf} de la Variante_Real (cambios 5.1 + 6.1 aplicados)."""
    return {f: _apply_all(f, t, usar_merge) for f, t in REAL_SEED.items()}


def build_mock_catalog(usar_merge=None):
    """dict {fname: text_lf} de la Variante_Mock (mismos cambios 5.1 + 6.1)."""
    return {f: _apply_all(f, t, usar_merge) for f, t in MOCK_SEED.items()}


# ----------------------------------------------------------------------------
# Verificacion de generacion: equivalencia usar_merge ON == OFF (Req 6.1)
# ----------------------------------------------------------------------------
def verify_upsert_equivalence():
    """Comprueba que ambos caminos (usar_merge on/off) persisten el MISMO
    conjunto de parejas Clave_Unificacion en cada escenario, real y mock.

    La equivalencia se demuestra a nivel de generacion: ambas estrategias parten
    del MISMO staging del resultado (mismo SELECT DISTINCT) y aplican las MISMAS
    columnas clave (cod_dw_persona_ubic, cod_dw_direccion_unificada). Se comparan
    las firmas canonicas (staging + claves) entre las dos regeneraciones.

    Devuelve (ok, detalles). Lanza AssertionError si difieren.
    """
    for builder, variante in ((build_real_catalog, "real"), (build_mock_catalog, "mock")):
        cat_on = builder(usar_merge=True)
        cat_off = builder(usar_merge=False)
        for fname in cat_on:
            sig_on = _scenario_clave_pairs_signature(fname, cat_on[fname])
            sig_off = _scenario_clave_pairs_signature(fname, cat_off[fname])
            if sig_on != sig_off:
                raise AssertionError(
                    "usar_merge on/off divergen en el conjunto de parejas "
                    "Clave_Unificacion de %s (%s)" % (fname, variante)
                )
    return True, "usar_merge ON == OFF: mismo conjunto de parejas Clave_Unificacion"


# ----------------------------------------------------------------------------
# Rollback (RevSQL): DROP PROCEDURE con la firma EXACTA del CREATE emitido.
#   Redshift NO soporta DROP PROCEDURE IF EXISTS y exige la firma exacta
#   (lecciones #12/#14). Al derivar la firma del propio CREATE generado, el
#   rollback nunca diverge del deploy aunque cambien las firmas (Tarea 5.1/6.1).
# ----------------------------------------------------------------------------
REVSQL_DIR = os.path.normpath(os.path.join(HERE, "..", "deploy", "redshift", "RevSQL"))

_KNOWN_TYPES = ("VARCHAR", "INTEGER", "DATE", "BOOLEAN", "TIMESTAMP", "BIGINT", "INT")


def _extract_create_signature(text):
    """Devuelve (proc, [tipos]) del primer CREATE OR REPLACE PROCEDURE del texto."""
    key = "CREATE OR REPLACE PROCEDURE bdm_datos."
    i = text.index(key) + len(key)
    j = text.index("(", i)
    proc = text[i:j].strip()
    # Bloque de parametros: desde '(' hasta el ')' que lo cierra (balanceado).
    depth = 0
    k = j
    while k < len(text):
        if text[k] == "(":
            depth += 1
        elif text[k] == ")":
            depth -= 1
            if depth == 0:
                break
        k += 1
    params_blob = text[j + 1:k]
    # Quitar comentarios de linea ANTES de separar por comas: la coma que separa
    # parametros va antes del comentario, y el texto del comentario podria tener
    # comas. Se limpia linea a linea y luego se une.
    clean_lines = []
    for ln in params_blob.split("\n"):
        clean_lines.append(ln.split("--", 1)[0])
    clean_blob = " ".join(clean_lines)
    tipos = []
    for raw in clean_blob.split(","):
        line = raw.strip()
        if not line:
            continue
        tipo = None
        for tok in line.split():
            up = tok.upper().rstrip(",")
            if up in _KNOWN_TYPES:
                tipo = up
                break
        assert tipo is not None, "tipo no reconocido en parametro: %r" % line
        tipos.append(tipo)
    return proc, tipos


def build_revsql(catalog):
    """dict {fname: rollback_text_lf} con DROP PROCEDURE de firma exacta, por cada
    archivo del catalogo que sea un CREATE PROCEDURE."""
    out = {}
    for fname, text in catalog.items():
        if "CREATE OR REPLACE PROCEDURE bdm_datos." not in text:
            continue
        proc, tipos = _extract_create_signature(text)
        sig = ",".join(tipos)
        body = (
            "-- Rollback de %s (Redshift no soporta IF EXISTS en DROP PROCEDURE)\n"
            "DROP PROCEDURE bdm_datos.%s(%s);\n" % (proc, proc, sig)
        )
        out[fname] = body
    return out


def write_revsql_file(fname, text_lf):
    """Escribe el rollback en REVSQL_DIR en UTF-8 sin BOM, con LF y newline final."""
    path = os.path.join(REVSQL_DIR, fname)
    with open(path, "wb") as fh:
        fh.write(text_lf.encode("utf-8"))
    return path


# ----------------------------------------------------------------------------
# Escritura de archivos: UTF-8 sin BOM, CRLF, newline final.
# ----------------------------------------------------------------------------
def write_sql_file(fname, text_lf):
    """Escribe el archivo en SQL_DIR en UTF-8 sin BOM, con LF y newline final.

    LF es la convencion canonica versionada del repo (los blobs en git son LF sin
    BOM); emitir LF evita churn espurio de fin de linea al regenerar.
    """
    path = os.path.join(SQL_DIR, fname)
    data = text_lf.encode("utf-8")
    with open(path, "wb") as fh:
        fh.write(data)
    return path
