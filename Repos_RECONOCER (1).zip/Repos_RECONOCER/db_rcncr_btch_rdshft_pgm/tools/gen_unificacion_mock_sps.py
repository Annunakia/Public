#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_unificacion_mock_sps.py — Generador de la Variante_Mock de la Unificacion
(procedimientos sp_unificacion_mock_* espejo).

Emite los .sql mock en deploy/redshift/SQL desde el catalogo unico definido en
gen_unificacion_common.py. El mock es el espejo determinista del real (v_mock_*
sobre bdm_stage, staging stg_mock_*, catalogos bdm_stage, destino
unificacion_direccion_mock) y comparte la MISMA transformacion de preparar_insumo
que la Variante_Real, por lo que la logica FULL/DELTA de ambas variantes proviene
de una unica fuente y no diverge (Req 7.4).

Salida: bdm_datos.unificacion_direccion_mock (via vistas v_mock_* sobre bdm_stage).
Archivos UTF-8 sin BOM, CRLF, NONATOMIC consistente.

Uso:
    python3 tools/gen_unificacion_mock_sps.py          # regenera mock
    python3 tools/gen_unificacion_mock_sps.py --check  # solo verifica
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gen_unificacion_common import (
    build_mock_catalog,
    build_revsql,
    write_sql_file,
    write_revsql_file,
    SQL_DIR,
    REVSQL_DIR,
    USAR_MERGE,
    verify_upsert_equivalence,
)


def _sync(catalog, target_dir, writer, check_only):
    changed = []
    for fname, text_lf in catalog.items():
        expected = text_lf.encode("utf-8")
        path = os.path.join(target_dir, fname)
        current = None
        if os.path.exists(path):
            with open(path, "rb") as fh:
                current = fh.read()
        if current != expected:
            changed.append(fname)
            if not check_only:
                writer(fname, text_lf)
    return changed


def generate(check_only=False):
    catalog = build_mock_catalog()
    changed = _sync(catalog, SQL_DIR, write_sql_file, check_only)
    # Rollback (RevSQL) con firma exacta del CREATE emitido (lecciones #12/#14).
    revsql = build_revsql(catalog)
    changed += _sync(revsql, REVSQL_DIR, write_revsql_file, check_only)
    return catalog, changed


def main():
    check_only = "--check" in sys.argv
    # Verificacion de generacion (Req 6.1): ambos caminos usar_merge on/off
    # producen el mismo conjunto de parejas Clave_Unificacion.
    ok, detalle = verify_upsert_equivalence()
    print("Equivalencia UPSERT: %s" % detalle)
    catalog, changed = generate(check_only=check_only)
    estrategia = "MERGE" if USAR_MERGE else "DELETE+INSERT (fallback)"
    verb = "difieren" if check_only else "regenerados"
    print("Variante_Mock [usar_merge=%s -> %s]: %d archivos, %d %s"
          % (USAR_MERGE, estrategia, len(catalog), len(changed), verb))
    for f in changed:
        print("  -", f)
    if check_only and changed:
        sys.exit(1)


if __name__ == "__main__":
    main()
