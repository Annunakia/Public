-- ============================================================
-- 12_fn_unif_resolver_param.sql
-- Funcion helper de resolucion/normalizacion de parametros del
-- Framework_Batch para la coexistencia FULL/DELTA de la Unificacion.
-- (repo pgm / db_rcncr_btch_rdshft_pgm)
-- Cluster consumidor: reconocerbatch / dba_rncr_batch
-- Objeto permanente en bdm_datos. Idempotente (CREATE OR REPLACE).
-- Codificacion: UTF-8 sin BOM. Nunca GRANT ... TO PUBLIC.
-- Spec: unificacion-full-delta (Task 3.1)
-- Requirements: 1.1, 1.2, 6.1, 14.1, 14.2
-- ------------------------------------------------------------
-- Centraliza y normaliza la convencion de parametros del Framework_Batch
-- (in_nemotecnico=MODO, in_id_facturacion=LOTE, in_fecha_ejecucion=FECHA) para
-- que ni los orquestadores ni las reglas dupliquen el parseo:
--   MODO  : vacio/NULL -> 'FULL'; si no, UPPER(TRIM(...)). La validacion de
--           dominio (abortar si no es FULL/DELTA) la hace el orquestador maestro.
--   LOTE  : NULLIF(TRIM(...), '') tal cual; el orquestador valida presencia y
--           que sea entero.
--   FECHA : vacio/NULL -> TO_CHAR(CURRENT_DATE,'YYYY-MM-DD'); si no, TRIM(...).
-- STABLE: el resultado no depende del contenido de la base para una misma
-- entrada dentro de una sentencia (CURRENT_DATE es estable por sentencia).
-- ============================================================

CREATE OR REPLACE FUNCTION bdm_datos.unif_resolver_param(
    p_clave     VARCHAR,   -- 'MODO' | 'LOTE' | 'FECHA'
    p_valor_in  VARCHAR    -- valor crudo del parametro Framework_Batch
)
RETURNS VARCHAR
STABLE
AS $$
    SELECT CASE UPPER(TRIM(p_clave))
        -- MODO: default FULL; validacion de dominio la hace el orquestador
        WHEN 'MODO' THEN
            CASE
                WHEN p_valor_in IS NULL OR TRIM(p_valor_in) = '' THEN 'FULL'
                ELSE UPPER(TRIM(p_valor_in))
            END
        -- LOTE: se devuelve tal cual (trim); el orquestador valida presencia y que sea entero
        WHEN 'LOTE' THEN NULLIF(TRIM(p_valor_in), '')
        -- FECHA: default CURRENT_DATE si vacio/NULL
        WHEN 'FECHA' THEN
            CASE
                WHEN p_valor_in IS NULL OR TRIM(p_valor_in) = '' THEN TO_CHAR(CURRENT_DATE, 'YYYY-MM-DD')
                ELSE TRIM(p_valor_in)
            END
    END
$$ LANGUAGE sql;

-- Grants al rol autorizado del batch (NUNCA a PUBLIC).
-- Ajustar el nombre del rol al definido en el ambiente destino (dba_rncr_batch).
GRANT EXECUTE ON FUNCTION bdm_datos.unif_resolver_param(VARCHAR, VARCHAR) TO ROLE reconocer_batch_role;
