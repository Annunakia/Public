# Evidencias tiempos — Unificación vía datashare (consumidor DEV)

**Fecha medición:** 2026-08-26T16:19:21

## Tiempos medidos (2da corrida independiente)

| Paso | Segundos |
|------|----------:|
| CALL R1 | **9.24** |
| CALL R2 | **23.9** |
| CALL R3 | **3.33** |
| **Total** | **36.47** |

## Volúmenes

```json
{
  "fecha": "2026-08-26T16:19:21",
  "entorno": "eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com / dba_rncr_batch",
  "volumenes_lectura": [
    {
      "src": "xpm",
      "n": 538235
    },
    {
      "src": "rpu_vista",
      "n": 591166
    }
  ],
  "timings": [
    {
      "paso": "CALL R1",
      "segundos": 9.24,
      "inicio": "2026-08-26T16:18:42"
    },
    {
      "paso": "CALL R2",
      "segundos": 23.9,
      "inicio": "2026-08-26T16:18:52"
    },
    {
      "paso": "CALL R3",
      "segundos": 3.33,
      "inicio": "2026-08-26T16:19:16"
    }
  ],
  "total_seg": 36.47,
  "salida_post_r2": [
    {
      "unifica_atributos": 2,
      "n": 72448
    }
  ],
  "salida_final": [
    {
      "unifica_atributos": 2,
      "n": 72448
    }
  ],
  "stl_query_calls": [
    {
      "query": 2103100,
      "querytxt": " SELECT paso, total FROM ( SELECT 'D_v_rpu' AS paso, COUNT(*)::BIGINT AS total FROM bdm_tempo.v_xpm_relacion_persona_ubicacion UNION ALL SELECT 'D_v_reportes', COUNT(*) FROM bdm_tempo.v_xpm_reporte_relacion_persona_ubica UNION ALL SELECT 'D_v_ciiu', COUNT(*) FROM bdm_tempo.v_xpm_ciiu_persona UNION ALL SELECT 'E_tipo_ubicacion_dir', COUNT(*) FROM bdm_datos.tipo_ubicacion_dir UNION ALL SELECT 'E_nomenclatura', COUNT(*) FROM bdm_datos.nomenclatura UNION ALL SELECT 'F_insumo_r1_potencial', COUNT(DISTINCT rpu.cod_dw_persona_ubic) FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic JOIN bdm_tempo.v_xpm_reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic WHERE rpu.ind_unificacion IS NULL UNION ALL SELECT 'G_sp_r1', CASE WHEN COUNT(*)>0 THEN 1 ELSE 0 END FROM pg_proc p JOIN pg_namespace n ON p.pronamespace=n.oid WHERE n.nspname='bdm_datos' AND p.proname='sp_unificacion_regla1' UNION ALL SELECT 'G_sp_r2', CASE WHEN COUNT(*)>0 THEN 1 ELSE 0 END FROM pg_proc p JOIN pg_namespace n ON p.pronamespace=n.oid WHERE n.nspname='bdm_datos' AND p.proname='sp_unificacion_regla2' UNION ALL SELECT 'G_sp_r3', CASE WHEN COUNT(*)>0 THEN 1 ELSE 0 END FROM pg_proc p JOIN pg_namespace n ON p.pronamespace=n.oid WHERE n.nspname='bdm_datos' AND p.proname='sp_unificacion_regla3' ) q ORDER BY paso                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ",
      "starttime": "2026-08-26 20:54:48.469874",
      "endtime": "2026-08-26 20:54:52.353450",
      "ms": 3884,
      "aborted": 0
    }
  ],
  "nota_r2": "R2 procesa ~591K RPUs de insumo (vistas/datashare); escribe 72.448 filas en salida local"
}
```
