# Ordenamiento — guía sesión Negocio (Edgar)

> **Objetivo:** entender la lógica en minucia y cerrar alcance (Opción A vs B).  
> **Visual:** abrir canvas `canvases/ordenamiento-negocio.canvas.tsx` en Cursor.

---

## 1. Qué ya está probado (DEV mock)

| Prueba | Resultado |
|--------|-----------|
| Smoke 9 personas | 15 scores, consolidación OK |
| Mock 20K post-unificación | 237.514 scores, ~50 s |
| SPs | scoring DIR/TEL/CEL/EMA + consolidación |

---

## 2. Respuestas internas (acordadas)

| Tema | Respuesta |
|------|-----------|
| TEL/CEL/EMA | Vienen de **XPM** (`edf_views` / `ifr_data`), filtrar **contactType** |
| DIR | Solo **RPUs ganadoras** post-unificación |
| Deploy SPs | **Pipeline** o ticket DBA |
| sector_financiero | Hay **catálogo oficial** (reemplazar mock >= 901) |
| Betas | **Pendiente validar** — ver §4 |

---

## 3. Paridad Teradata — preguntar a Negocio

### Opción A (mínimo) — ya probado mock

```
XPM → vistas insumo → SPs scoring 02-06 → orden_prioridad
```

### Opción B (paridad Control-M)

```
ORD_CU24.2 (12 PRO_ORD) → CARACTERISTICA → BTEQ cursor → P0027 → P0029
```

| Paso Teradata | ¿Incluir? | Estado Redshift |
|---------------|-----------|-----------------|
| PRO_ORD fases 1-3 | ? | SQL Public-main, no E2E |
| Scoring 4 canales | Sí | SPs OK mock |
| P0027 persistencia | Parcial | solo orden_prioridad |
| P0029 movilidad | ? | No migrado |

---

## 4. Betas — dónde están (validar con IFR/DBA)

| Uso hoy (mock) | Producción documentada (QA) |
|----------------|---------------------------|
| `bdm_datos.beta_ordenamiento` (47 filas estáticas) | `ifr_data.v_beta_ordenamiento_dir` |
| | `ifr_data.v_beta_ordenamiento_tel` |
| | `ifr_data.v_beta_ordenamiento_cel` |
| | `ifr_data.v_beta_ordenamiento_email` |

**Datashare:** si betas están en productor IFR, van en el mismo share que XPM (`db_ifr_shared`) o se replican local en Reconocer — **confirmar con DBA/IFR**.

Catálogos adicionales ordenamiento (doc QA):

- `ifr_data.v_operador_ord_cel`
- `ifr_data.v_tipo_cuenta_ord`

---

## 5. contactType → canal (insumos desde XPM)

| contactType | Canal |
|:-----------:|:-----:|
| 1, 2, 3, 7 | DIR |
| 4, 5, 8 | TEL |
| 9 | CEL |
| 10 | EMA |

En **edf_views** la dirección unificación usa type 8; para ordenamiento TEL hay que mapear types 4/5/8 explícitamente en vistas insumo.

---

## 6. Preguntas para Edgar (prioridad)

1. ¿Alcance **A o B**?
2. ¿Regla **cross-canal** o ranking solo dentro de canal?
3. ¿Mock 20K basta para sign-off?
4. ¿Campos P0027 obligatorios además de `orden_prioridad`?
5. ¿Betas siempre desde IFR o snapshot en `bdm_datos`?

---

## 7. Demo sugerida en sesión (persona 20002 smoke)

Mostrar en pantalla:

1. Filas `insumo_direccion` vs `insumo_tel/cel/ema`
2. Métricas agregadas (ej. meses_reporte, sector_financiero)
3. `score_ordenamiento` por canal + `lugar`
4. `orden_prioridad` final en RPU
