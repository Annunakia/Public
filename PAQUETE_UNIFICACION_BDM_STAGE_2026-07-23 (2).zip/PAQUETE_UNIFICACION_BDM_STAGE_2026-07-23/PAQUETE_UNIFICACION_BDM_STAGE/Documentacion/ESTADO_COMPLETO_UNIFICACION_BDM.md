# Estado completo — Unificación de Direcciones BDM

> **Proyecto:** MT-EXP-005-MAP-RECONOCER  
> **Paquete:** `PAQUETE_UNIFICACION_BDM_STAGE`  
> **Última actualización:** 2026-08-11  
> **Ambiente:** Redshift `dba_batch` (develop / QA)  
> **Documento único de referencia** — hecho, pendiente, mapping, pipeline y artefactos.

---

## 1. Objetivo del proyecto

Migrar y operar la **Unificación de Direcciones** (Reglas 1, 2 y 3) en Amazon Redshift:

1. Validar lógica en **mock/sintético** (`bdm_stage`).
2. Conectar a **datos reales XPM** (`ifr_data`) en QA, abandonando mock.
3. Entregar SQL plano + SPs + validaciones, ejecutables vía **pipeline** (no DBeaver directo en QA Spectrum).

**Referencias:** `configuracion_ifr_data_qa.md`, *Modelo de Datos XPM Redshift* (Confluence/PDF), SPEC sintético 20K.

---

## 2. Qué se ha hecho

### 2.1 Paquete base (`sql/` — mock / develop)

| Entregable | Estado |
|------------|--------|
| `02_unificacion_sql_plano.sql` — R1+R2+R3 SQL plano | Hecho |
| `03_validaciones_unificacion.sql` | Hecho |
| `05`–`07_sp_regla*.sql` — SPs en `bdm_stage` | Hecho |
| `08_ejecucion_secuencial.sql` — CALL R1→R2→R3 | Hecho |
| `09_diagnostico_r2_r3.sql` | Hecho |
| Fix Regla 1 (empate score LAB vs CRR) | Hecho — padre `orden=1`, hijo `orden>1` |
| Adaptación develop: salida `bdm_stage`, sin mock `01`, sin `ANALYZE` | Hecho |
| `rev-sql/` rollbacks | Hecho |

### 2.2 Benchmark sintético 20K (`sql/benchmark_20k/`)

| Entregable | Estado |
|------------|--------|
| `A_data_load_sintetico.sql` — carga 20K personas | Hecho |
| `B_queries_tiempos_y_clasificacion.sql` | Hecho |
| `C_cleanup_post_pruebas.sql` | Hecho |
| Corrida R1+R2+R3 sobre sintético | Hecho |

**Resultado benchmark (bdm_stage):**

| Regla | Absorciones |
|------:|------------:|
| R1 | 1.800 |
| R2 | 7.200 |
| R3 | 600 |
| **Total** | **9.600** |

Validaciones: sin huérfanos ni auto-referencias.

### 2.3 Develop con extracto real en `bdm_stage`

| Métrica | Valor |
|---------|------:|
| RPU | ~42.000 (luego reemplazado por sintético 20K en QA) |
| Unificaciones totales | **400** |
| R1 | 400 |
| R2 | 0 |
| R3 | 0 |

**Causa R2/R3 = 0:** extracto develop sin `complemento` / lat-long suficientes (~96% sin geo). El SQL corre; faltan datos, no lógica.

### 2.4 Frente QA datos reales XPM (`sql/qa_ifr_data/`)

| Entregable | Estado |
|------------|--------|
| Mapping XPM (`ifr_data`) → columnas BDM | Hecho |
| `00_vistas_insumo_bdm.sql` — vistas `bdm_tempo.v_xpm_*` | Hecho (no ejecutado en QA) |
| `01_ddl_unificacion_direccion.sql` | Hecho |
| SPs `bdm_datos.sp_unificacion_regla1/2/3` leyendo vistas | Hecho |
| `08_ejecucion_secuencial.sql`, validaciones, smoke | Hecho |
| Propuesta orquestación pipeline (6 etapas) | Documentada abajo |
| `sql/qa_xpm/` | Alias histórico — mismo contenido, usar `qa_ifr_data/` |

### 2.5 Hallazgos en Redshift QA (exploración)

| Hallazgo | Detalle |
|----------|---------|
| Esquema fuente QA | **`ifr_data`** — tablas `xpm_*` con campos tokenizados `val.*` |
| No existen tablas BDM planas | No hay `ifr_data.relacion_persona_ubicacion`; se mapean vía vistas |
| Catálogos en QA | `tipo_ubicacion_dir`, `nomenclatura` en **`bdm_stage`**, no en `bdm_datos` |
| Ejecución QA real | Por **pipeline** con rol autorizado sobre `ifr_data` |

---

## 3. Qué está pendiente

### 3.1 Bloqueantes

| # | Pendiente | Impacto |
|---|-----------|---------|
| 1 | Validar FKs `xpm.location`, `loc."val.contactinformations"`, `xpm.counterparties` | Bloquea vistas |
| 2 | Confirmar columnas `val.*` en tablas `ifr_data.xpm_*` | Bloquea mapping |
| 3 | Rol/pipeline con permiso sobre `ifr_data` | Bloquea ejecución QA |
| 4 | Confirmar schema salida (`bdm_datos` vs `bdm_stage`) y catálogos | Bloquea deploy |

### 3.2 Funcionales / datos

| # | Pendiente | Impacto |
|---|-----------|---------|
| 5 | Ejecutar pipeline QA (etapas 1–6) | Sin corrida real XPM |
| 6 | Georreferenciación (lat/long) | R3 geo limitado |
| 7 | Regla `id_buro_persona` (`FNV_HASH(pin)` vs pipeline BDM) | IDs persona |
| 8 | Validar FK `xpm.counterparties` → `xpm_counterparties` | Reportes R1/R2 |
| 9 | `via_generadora` VARCHAR en reales | Ajuste R3 ±2 |

### 3.3 Opcionales

| # | Pendiente |
|---|-----------|
| 10 | Smoke subset 1.000 PINs antes de full (~65–70M) |
| 11 | Re-probar SPs `bdm_stage` tras fix R1 en develop (si aplica) |
| 12 | Definir pipeline real del cliente (herramienta, rol, WLM) |

---

## 4. Preguntas de validación técnica

1. ¿`ifr_data.xpm_location` es la hija de `location[]` en `xpm`?
2. ¿`ifr_data.xpm_location_val_contactinformations` expone los campos `val.standardized*`?
3. ¿`ifr_data.xpm_counterparties` es la fuente correcta de reportes (FK `xpm.counterparties`)?
4. ¿Las FKs `xpm.location`, `loc."val.contactinformations"` y `xpm.counterparties` son correctas?
5. ¿Las columnas `val.*` en el catálogo Glue coinciden con el mapping?
6. ¿La regla `id_buro_persona` = `FNV_HASH(pin)` es correcta o hay otra regla en el pipeline BDM?
7. ¿El schema de salida `bdm_datos.unificacion_direccion` es el correcto en QA?
8. ¿Los catálogos van en `bdm_datos` o debemos usar `bdm_stage` en QA?

---

## 5. Mapping tablas — origen XPM → destino BDM

### 5.1 Tabla origen → tabla destino

| Tabla origen (`ifr_data`) | Tabla destino BDM | Vista SQL |
|----------------------------|-------------------|-----------|
| `xpm` + `xpm_location` + `xpm_location_val_contactinformations` | `relacion_persona_ubicacion` | `bdm_tempo.v_xpm_relacion_persona_ubicacion` |
| `xpm_location` + `xpm_location_val_contactinformations` | `ubicacion_estandarizada` | `bdm_tempo.v_xpm_ubicacion_estandarizada` |
| `xpm_location_val_contactinformations` | `direccion_fisica` | `bdm_tempo.v_xpm_direccion_fisica` |
| `xpm_counterparties` | `reporte_relacion_persona_ubica` | `bdm_tempo.v_xpm_reporte_relacion_persona_ubica` |
| `xpm` (`bestpersonalinformation.mainisiccodeforproduct`) | `ciiu_persona` | `bdm_tempo.v_xpm_ciiu_persona` |
| catálogo estático | `nomenclatura`, `tipo_ubicacion_dir` | `bdm_datos.*` |
| salida proceso | `unificacion_direccion` | `bdm_datos.unificacion_direccion` |

**Regla JOIN XPM:** incluir `relationalizelastupdate` en **todos** los JOINs entre tablas XPM.

**JOINs base:**
```text
ifr_data.xpm
  JOIN ifr_data.xpm_location loc
    ON xpm.location = loc.id
   AND xpm.relationalizelastupdate = loc.relationalizelastupdate
  JOIN ifr_data.xpm_location_val_contactinformations ci
    ON loc."val.contactinformations" = ci.id
   AND loc.relationalizelastupdate = ci.relationalizelastupdate
  JOIN ifr_data.xpm_counterparties cp  -- reportes
    ON xpm.counterparties = cp.id
   AND xpm.relationalizelastupdate = cp.relationalizelastupdate
```

Filtro direcciones: `contacttype IN (1, 2, 3, 7)`.

### 5.2 Mapping columnas principales

**`relacion_persona_ubicacion`**

| Columna BDM | Origen |
|-------------|--------|
| `cod_dw_persona_ubic` | `ci.id` |
| `cod_dw_ubic` | `loc.id` |
| `cod_dw_direccion_fisica` | `ci.id` |
| `cod_pin_persona` | `CAST(xpm.pin AS BIGINT)` |
| `id_buro_persona` | `FNV_HASH(xpm.pin)` |
| `cod_dw_tipo_ubicacion_dir` | `ci."val.contacttype"` |
| `fecha_relacion_persona_ubicaci` | `convert_epoch_to_date(ci."val.contacteventlastupdated")` |

**`ubicacion_estandarizada` / `direccion_fisica`**

| Columna BDM | Origen |
|-------------|--------|
| `texto_ubicacion` | `ci."val.standardizedtextoubicacion"` |
| `complemento` | `ci."val.standardizedcomplemento"` |
| `tipo_via_principal` | `ci."val.standardizedtipoviaprincipal"` |
| `via_principal` | `ci."val.standardizedviaprincipal"` |
| `via_generadora` | `ci."val.standardizedviageneradora"` |
| `numero_puerta` | `ci."val.standardizednumeropuerta"` |
| `cod_dw_ciudad` | `ci."val.standardizeddanecode"` |
| `latitud` / `longitud` | `NULL` (pendiente geo) |

**`reporte_relacion_persona_ubica`**

| Columna BDM | Origen |
|-------------|--------|
| `id_buro_suscriptor` | `cp."val.counterpartyidnumber"` |
| `fecha_reporte` | `convert_epoch_to_date(cp."val.cutoffdate")` |

**`ciiu_persona`**

| Columna BDM | Origen |
|-------------|--------|
| `cod_act_econo_ciiu_fte` | `xpm."bestpersonalinformation.mainisiccodeforproduct"` |

---

## 6. Arquitectura QA (propuesta)

```
ifr_data.xpm + xpm_location*     (XPM real, campos tokenizados)
        ↓  00_vistas_insumo_bdm.sql
bdm_tempo.v_xpm_*                 (insumo BDM)
        ↓  bdm_datos.sp_unificacion_regla1/2/3
bdm_datos.unificacion_direccion   (salida)
```

| SP | Lee de | Escribe en |
|----|--------|------------|
| `bdm_datos.sp_unificacion_regla1` | `v_xpm_*`, `tipo_ubicacion_dir` | `unificacion_direccion` |
| `bdm_datos.sp_unificacion_regla2` | idem + `nomenclatura` | idem |
| `bdm_datos.sp_unificacion_regla3` | idem | idem |

---

## 7. Pipeline propuesto (orquestación simple asumida)

**Supuestos:** job batch (Airflow / Step Functions / runner SQL interno), rol con permiso `ifr_data` + `bdm_tempo` + `bdm_datos`, XPM ya cargado.

```
START → DDL → Vistas → Smoke (gate) → Deploy SPs → Ejecutar R1R2R3 → Validaciones (gate) → SUCCESS
                ↓ fail                              ↓ fail
              ABORT                               ABORT
```

| Etapa | Script | Acción |
|------:|--------|--------|
| 0 | Pre-check SQL | Verificar 3 tablas `xpm_location*` en catálogo |
| 1 | `01_ddl_unificacion_direccion.sql` | DDL salida + catálogos |
| 2 | `00_vistas_insumo_bdm.sql` | Vistas `v_xpm_*` |
| 3 | `00_smoke_xpm.sql` | Gate: conteos > 0 |
| 4 | `05` → `06` → `07` | Deploy SPs |
| 5 | `08_ejecucion_secuencial.sql` | TRUNCATE + CALL R1→R2→R3 |
| 6 | `03_validaciones_unificacion.sql` | Gate: huérfanos=0, auto-ref=0 |

**Modos:** `SMOKE` (etapas 0–3) | `FULL` (0–6)

**Parámetros sugeridos:** `ENV=QA`, `DB=dba_batch`, `MODO=FULL|SMOKE`, `PIN_LIMIT` (opcional subset).

**No hacer:** SELECT directo sobre `ifr_data` desde DBeaver en QA.

---

## 8. Rutas SQL del paquete

### Mock / develop (`bdm_stage`)

| Script | Uso |
|--------|-----|
| `sql/02_unificacion_sql_plano.sql` | Corrida plana R1+R2+R3 |
| `sql/05`–`08` | SPs + orquestación |
| `sql/03_validaciones_unificacion.sql` | Validaciones |
| `sql/09_diagnostico_r2_r3.sql` | Diagnóstico R2/R3 |

### Sintético 20K

| Script | Uso |
|--------|-----|
| `sql/benchmark_20k/A_*.sql` | Carga |
| `sql/benchmark_20k/B_*.sql` | Revisión |
| `sql/benchmark_20k/C_*.sql` | Cleanup |

### QA XPM real

| Script | Uso |
|--------|-----|
| `sql/qa_ifr_data/00_vistas_insumo_bdm.sql` | Mapping XPM→BDM |
| `sql/qa_ifr_data/01_ddl_unificacion_direccion.sql` | DDL |
| `sql/qa_ifr_data/00_smoke_ifr_data.sql` | Smoke |
| `sql/qa_ifr_data/05`–`07` | SPs QA |
| `sql/qa_ifr_data/08_ejecucion_secuencial.sql` | Ejecución |
| `sql/qa_ifr_data/03_validaciones_unificacion.sql` | Validaciones |
| `sql/qa_ifr_data/00_EJECUTAR_QA_IFR_DATA.sql` | Índice orden pipeline |

---

## 9. Cómo ejecutar hoy (según frente)

| Frente | Dónde | Cómo |
|--------|-------|------|
| Mock/sintético | `bdm_stage` | DBeaver: `sql/` o `benchmark_20k/` |
| Develop extracto | `bdm_stage` | `sql/02` o SPs `sql/05`–`08` |
| QA datos reales | `ifr_data` | **Pipeline** + `sql/qa_ifr_data/` |

---

## 10. Resumen ejecutivo

| Tema | Estado |
|------|--------|
| SQL + SPs R1/R2/R3 | **Listos** (lógica validada en sintético 9.600) |
| R1 en develop real | **Validada** (400) |
| R2/R3 en develop real | **0 por calidad de datos**, no por SQL |
| Conexión XPM QA | **Preparada en código** (`qa_ifr_data/`), **no ejecutada** |
| Mapping XPM→BDM | **Propuesto**, pendiente confirmación catálogo |
| Pipeline | **Propuesto**, pendiente definición cliente |

---

*Documento único de referencia del paquete PAQUETE_UNIFICACION_BDM_STAGE.*
