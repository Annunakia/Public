# Evidencias — Ordenamiento Smoke DEV

* **Ejecutado:** 2026-08-26
* **Entorno:** Productor DEV — `eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com` / `dba_batch`
* **Usuario:** `c32525e`
* **Pipeline:** deploy SPs 10–16 + mock 9 personas + CALL scoring DIR/TEL/CEL/EMA + consolidación

## Resultado

| Métrica | Valor | Esperado Kidar |
|---------|------:|----------------|
| Scores DIR | 6 | ~6 direcciones rankeadas |
| Scores TEL | 3 | 2 personas |
| Scores CEL | 3 | 2 personas |
| Scores EMA | 3 | 2 personas |
| **Total scores** | **15** | **15** |
| RPU con `orden_prioridad` | **15** | OK |

## Scores por canal

| canal | filas | min_score | max_score |
|-------|------:|----------:|----------:|
| DIR | 6 | 0.6783 | 0.8000 |
| TEL | 3 | 0.4250 | 0.6900 |
| CEL | 3 | 0.5825 | 0.6875 |
| EMA | 3 | 0.3967 | 0.6042 |

## Comandos

```powershell
py tools/ordenamiento_mock_run.py --smoke --deploy-sps
```

## SPs desplegados

- `bdm_datos.sp_ordenamiento_preparar_insumos`
- `bdm_datos.sp_ordenamiento_scoring_dir`
- `bdm_datos.sp_ordenamiento_scoring_tel`
- `bdm_datos.sp_ordenamiento_scoring_cel`
- `bdm_datos.sp_ordenamiento_scoring_ema`
- `bdm_datos.sp_ordenamiento_consolidacion`
- `bdm_datos.sp_ordenamiento_ejecucion(BOOLEAN)`

## Notas

- `CREATE SCHEMA` comentado en `01_schemas.sql` — esquemas ya existen en DEV.
- Orquestador: `CALL bdm_datos.sp_ordenamiento_ejecucion(FALSE)` smoke / `(TRUE)` mock 20K.

## Siguiente paso

Mock alto post-unificación:

```sql
CALL bdm_datos.sp_ordenamiento_ejecucion(TRUE);
```
