# Evidencias — Credenciales consumidor + re-score Ordenamiento (2026-09-18)

**Usuario:** `c32525e` · **Puerto:** 5440  
**Claves:** enviadas por ops (no versionar en git; usar variables de entorno).

| Ambiente | Host | DB | Auth |
|----------|------|-----|------|
| **DEV consumidor** | `…reconocerbatch-dev…cz7jl1sn7m8z…` | `dba_rncr_batch` | **OK** (desbloqueado) |
| **QA consumidor** | `…reconocerbatch-qa…csxybrl2itvu…` | `dba_rncr_batch` | **OK auth** · sin schemas `bdm_*` aún |

Vars sugeridas: `REDSHIFT_CONSUMER_PASSWORD` (DEV) · `REDSHIFT_CONSUMER_QA_PASSWORD` (QA).

---

## 1. DEV consumidor — inventario

| Pieza | Resultado |
|-------|-----------|
| CREATE `bdm_datos` / `bdm_tempo` / `bdm_stage` | **True** |
| Vistas `v_xpm_*` | Presentes (`v_xpm_relacion_persona_ubicacion` ≈ 593.411) |
| SPs unificación reales | Sí (Esc4 **HAS_FIX**); **0** mock |
| SPs ordenamiento `_edf` | Sí (`ejecucion_edf`, scoring×4, etc.) |
| Unificación gates | R2=**72.549** · C03=**0** · C04=**0** |

---

## 2. Ordenamiento — carga RITM + re-corrida

Antes: betas placeholder (~0.1).  
Acción: `02_carga_betas_ritm5226589.sql` + `CALL bdm_datos.sp_ordenamiento_ejecucion_edf(TRUE)` (~36 s).

### Betas post-RITM (47)

| Canal | n | min β | max β |
|-------|--:|------:|------:|
| CEL | 11 | 41.49 | 203.32 |
| DIR | 12 | -51.61 | 135.48 |
| EMA | 13 | -130.8 | 180.31 |
| TEL | 11 | -130.4 | 179.3 |

### Scores post-corrida

| Canal | Scores | min | max |
|-------|-------:|----:|----:|
| CEL | 258 | 574.69 | 971.99 |
| DIR | 410.455 | 453.55 | 796.99 |
| EMA | 408.683 | 94.59 | 467.73 |
| TEL | 408.498 | 211.90 | 551.75 |

| Gate | Valor |
|------|------:|
| `rpu_orden_prioridad` | 410.100 |
| Hijas con orden | **0** |

Magnitud de score sube (coeficientes Teradata reales); ranking = `ORDER BY score DESC`.

---

## 3. QA consumidor

- Login OK en `dba_rncr_batch`.
- Solo schemas `public` / `catalog_history` → **aún no desplegado** pipeline `qa/SLCOPRBA-1284` (o falta crear `bdm_*` / datashare).
- Sin SPs / vistas / tablas Unificación u Ordenamiento.

**Siguiente QA:** confirmar Jenkins strct→pgm→dt sobre promo 1284; luego Modo A reales.

---

## 4. Pendiente

| Ítem | Estado |
|-------|--------|
| Re-evidencia ordenamiento DEV post-RITM | **Hecho** (esta nota) |
| Path mock en consumidor | No desplegado |
| QA schemas + deploy Alpha | Pendiente ops/pipeline |
| Ordenamiento PRs merge | Seguir aparte |

*No incluir contraseñas en commits.*
