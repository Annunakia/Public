# Evidencias QA — JOINs/columnas SPs 05/06/07 (ifr_data, solo lectura)

**Fecha:** 2026-08-19  
**Ambiente:** QA Redshift `dba_batch`  
**Usuario validación:** `c32525e` (sin permiso `CREATE` en `bdm_tempo` / `bdm_datos`)  
**Alcance:** Garantizar que los **3 stored procedures** (`sp_unificacion_regla1/2/3`) tienen **columnas y JOINs correctos** contra XPM real. No incluye deploy de vistas ni ejecución de SPs.

---

## Metodología

1. Validación **inline** (CTE `contacto` + `reporte`) = mismo grafo que `00_vistas_insumo_bdm.sql` → `v_xpm_*`.
2. Script: `sql/qa_ifr_data/00_validar_sp_joins_inline.sql` (solo `SELECT`, ejecutable en DBeaver).
3. Runner: `tools/qa_ifr_inline_validation.py` (mismos checks automatizados).

Los SPs **no escriben en `ifr_data`**; leen `bdm_tempo.v_xpm_*` y escriben solo en `bdm_datos` + staging `bdm_tempo` (eso lo ejecuta el pipeline con rol de servicio).

---

## Resultados QA (datos reales)

| Check | SP | Resultado | Estado |
|-------|-----|-----------|--------|
| JOIN base contactos | 05/06/07 | **1.285** | OK |
| Insumo común (RPU + reporte) | 05/06/07 | **699** RPU distintos con reporte | OK |
| JOIN reportes | 05/06/07 | **1.897** filas | OK |
| CIIU (`bestpersonalinformation.mainisiccodeforproduct`) | 05 | **412** personas | OK |
| `cod_tipo_ident_fte` ← `location.val.personidtype` | 06 | **1.285** informados, divergente **0** | OK |
| NIT (`personidtype = 3`) | 06 motor | **6** RPU; **2** con complemento | OK |
| Complemento R2 | 06 | **130** no vacíos | OK |
| Geo lat/long | 07 | **NULL** en XPM (R3 no dispara; JOIN válido) | OK * |
| Catálogo `tipo_ubicacion_dir` código **7** | 05 | **1** faltante (DIR) | Pipeline * |

\* No es fallo de mapeo SQL: falta fila `7='DIR'` en catálogo del ambiente; el pipeline debe cargarla antes de producción.

---

## Mapeo SP → vistas → IFR

| SP | Vistas leídas | Columnas críticas validadas |
|----|---------------|----------------------------|
| **05 R1** | `v_xpm_relacion_persona_ubicacion`, `v_xpm_ubicacion_estandarizada`, `v_xpm_direccion_fisica`, `v_xpm_reporte_*`, `v_xpm_ciiu_persona` | `texto_ubicacion`, `cod_dw_ciudad`, `complemento`, `id_buro_suscriptor`, `cod_act_econo_ciiu_fte`, `cod_dw_tipo_ubicacion_dir` |
| **06 R2** | Igual + `cod_tipo_ident_fte`, `complemento`, motor → `v_xpm_direccion_fisica` | Esc3: `COALESCE(cod_tipo_ident_fte,0)=3`; complemento desde `standardizedcomplemento` |
| **07 R3** | Igual + `latitud`/`longitud` (NULL hoy) | JOINs OK; sin geo en IFR → 0 unificaciones R3 esperado |

---

## Deploy pipeline (fuera de tu alcance)

| Item | Responsable pipeline |
|------|---------------------|
| `CREATE VIEW bdm_tempo.v_xpm_*` con **`WITH NO SCHEMA BINDING`** | Admin (tablas externas Spectrum) |
| Catálogo `tipo_ubicacion_dir` incl. **7=DIR** | Admin / carga catálogos |
| `CREATE PROCEDURE` + `CALL` SPs | Rol batch |

Tu entregable: **`sql/qa_ifr_data/05_sp_regla1.sql`**, **`06_sp_regla2.sql`**, **`07_sp_regla3.sql`** + **`00_vistas_insumo_bdm.sql`** alineados y validados en lectura.

---

## Cómo repetir en DBeaver (sin permisos CREATE)

```sql
\i sql/qa_ifr_data/00_validar_sp_joins_inline.sql
```

Esperado: conteos > 0 en filas SP_*; `personidtype_coherente.divergente = 0`; `catalogo_tipo7_faltante = 1` hasta que pipeline agregue DIR.
