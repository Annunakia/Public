# Reporte QA — Unificación datos reales (Reconocer / edf_views)

> **Nota:** El reporte histórico con TC-R1-01…TC-R2-14 sobre **mocks** (`bdm_stage` / `perf_persona_meta`) ya no aplica a este entregable.
>
> **Documento vigente de revisión:** [`CHECKLIST_REVISION_MANUEL_DATOS_REALES.md`](CHECKLIST_REVISION_MANUEL_DATOS_REALES.md)
>
> **Evidencia QA DEV (corrida fresca):** [`Evidencias_QA_UNIFICACION_ESCENARIOS_DEV.md`](Evidencias_QA_UNIFICACION_ESCENARIOS_DEV.md)

## Resumen datos reales (2026-09-04)

| Métrica | Valor |
|---------|------:|
| Ambiente | `dba_rncr_batch` — Reconocer consumidor DEV |
| Fuentes | `bdm_tempo.v_xpm_*` (datashare `edf_views`) |
| Salida | `bdm_datos.unificacion_direccion` |
| R2 | **72.448** (paridad baseline) |
| R1 / R3 | 0 (esperado en DEV por datos fuente) |
| C03 / C04 | 0 |
| Universo RPU | 591.166 |

Validación: `tools/dev_unificacion_escenarios_qa_run.py` + `sql/qa_ifr_data/03_validaciones_unificacion.sql`
