# Guia de Instalacion

## Objetivo

Este paquete arma una prueba local de unificacion de direcciones en un solo Redshift.

La distribucion usada es:

- `bdm_stage`: fuentes y tabla de salida `unificacion_direccion`.
- `bdm_tempo`: tablas temporales de proceso.

## Orden de ejecucion

Ejecutar los scripts en el orden definido en `deploy_order.par`.

### En develop del cliente (fuentes ya existentes)

No ejecutar `01_bdm_stage_mock_setup.sql` (reemplazaria datos reales).

Camino A - SQL plano:

1. `sql/02_unificacion_sql_plano.sql`  (hace TRUNCATE de `bdm_stage.unificacion_direccion`)
2. `sql/03_validaciones_unificacion.sql`

Camino B - Stored procedures:

1. `sql/05_sp_regla1.sql`
2. `sql/06_sp_regla2.sql`
3. `sql/07_sp_regla3.sql`
4. `sql/08_ejecucion_secuencial.sql`
5. `sql/03_validaciones_unificacion.sql`

### Sandbox / prueba con mock

1. `sql/01_bdm_stage_mock_setup.sql`
2. Luego Camino A o B como arriba.

`sql/04_cleanup.sql` se usa cuando se quiera reiniciar la prueba mock.

## Benchmark 20K (cierre SPs R1/R2/R3 con datos sinteticos)

Usar solo en sandbox / cuando se autorice reemplazar tablas de `bdm_stage`:

1. `sql/benchmark_20k/A_data_load_sintetico.sql`
2. `sql/02_unificacion_sql_plano.sql` (o SPs `05`–`08`)
3. `sql/benchmark_20k/B_queries_tiempos_y_clasificacion.sql`
4. Opcional: `sql/benchmark_20k/C_cleanup_post_pruebas.sql`

Spec: `Documentacion/SPEC_IA_DATOS_SINTETICOS_20K.md`.

