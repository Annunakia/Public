# Spec para IA — Datos sintéticos Benchmark 20K + tiempos + clasificación + cleanup

> **Audiencia:** cualquier IA / desarrollador que deba **regenerar el SQL** de carga sintética, medir tiempos por regla/escenario y consultar dónde quedó clasificada cada persona.  
> **Producto:** Reconocer Unificación (R1 → R2 Esc 1–6 → Motor → R3) en Amazon Redshift, esquema `bdm_stage`.  
> **Fuente canónica de DML:** [`inc_data_load.sql`](inc_data_load.sql) · monolito: [`00_run_benchmark_20k_batch.sql`](00_run_benchmark_20k_batch.sql) · validación: [`Optimizado/01_validate_benchmark_20k_dev.sql`](Optimizado/01_validate_benchmark_20k_dev.sql).

---

## 0. Instrucciones para la IA (contrato de salida)

Cuando te pidan “generar los datos sintéticos 20K”, debes producir **SQL Redshift** que cumpla:

1. **Parámetro:** `N = 20000` personas (configurable; default 20000).
2. **Volumen post-carga:** `N` personas, `2N` RPU, `2N` ubicaciones, `2N` direcciones físicas.
3. **Volumen post-motor (pipeline completo):** `N` personas, **`2N + personas_motor`** RPU ≈ **42000** si N=20000 (motor añade ~1 RPU nueva por persona de escenarios `R2_ESC3_NIT`, `R2_ESC5_MOTOR`, `R2_ESC6_MOTOR`).
4. **22 `scenario_code`** vía `persona_seq % 100` + tabla `perf_scenario_seed` (ver §3).
5. **IDs deterministas** (ver §2).
6. Separar entregables en **tres scripts SQL** (o un solo archivo con secciones claras):
   - `A_data_load_sintetico.sql` — DROP/CREATE + INSERT sintético + ANALYZE + DROP auxiliares.
   - `B_queries_tiempos_y_clasificacion.sql` — medición `perf_timings` + clasificación padre/hijo por regla/escenario.
   - `C_cleanup_post_pruebas.sql` — DROP de staging + tablas mock + instrumentación (NO borrar el esquema `bdm_stage`).

**No inventes columnas.** Usa exactamente los DDL de §4.  
**No omitas** el seed de 22 escenarios ni los INSERT de `diccionario_complementos` / `diccionario_via` filtrados por escenario.

---

## 1. Qué estamos midiendo (contexto mínimo)

Pipeline de unificación (batch):

```
DATA_LOAD → R1 → R2_ESC1_2 → R2_ESC4 → R2_ESC3_SIN_NIT
  → R2_MOTOR_BATCH_PREP → R2_MOTOR_BATCH_RUN → R2_MOTOR_BATCH_FIN
  → R3 → VALIDATION
```

| Regla | Qué prueba el sintético |
|-------|-------------------------|
| **R1** | Misma puerta + distinto tipo uso (RES/LAB/CRR); padre por CIIU + entidades |
| **R2** | Misma puerta + mismo tipo uso + **complementos** distintos (Esc 1–6, diccionario, motor, empate) |
| **R3** | Distinta vía generadora / puerta ±2; desempate geo → fecha → diccionario de vías |

Los datos sintéticos **ya vienen “parseados”**: `texto_ubicacion` + `complemento` + columnas de vía/puerta pobladas. No generan parseo desde texto crudo.

---

## 2. Fórmulas de identidad (obligatorias)

Para cada `persona_seq` ∈ `{1..N}`:

| Entidad | Fórmula |
|---------|---------|
| `id_buro_persona` | `100000 + persona_seq` |
| `cod_pin_persona` | `900000 + persona_seq` |
| `bucket` | `persona_seq % 100` |
| Ubic A `cod_dw_ubic` | `id_buro_persona * 1000 + 1` |
| Ubic B `cod_dw_ubic` | `id_buro_persona * 1000 + 2` |
| Dir física A | `id_buro_persona * 1000 + 101` |
| Dir física B | `id_buro_persona * 1000 + 102` |
| RPU A `cod_dw_persona_ubic` | `id_buro_persona * 1000 + 1` |
| RPU B `cod_dw_persona_ubic` | `id_buro_persona * 1000 + 2` |
| `via_num` | `via_base + (persona_seq % 500)` |

Rango @ N=20000: `id_buro_persona` **100001–120000**.

**Asignación de escenario:**

```sql
JOIN perf_scenario_seed s
  ON (persona_seq % 100) BETWEEN s.bucket_lo AND s.bucket_hi
```

Cada valor de bucket 0–99 cae en **exactamente un** escenario. Con N=20000 → **200 personas por unidad de bucket**.

---

## 3. Catálogo de escenarios (22 códigos)

Personas @20K = `(bucket_hi - bucket_lo + 1) * (N/100)`.

| bucket_lo–hi | % | scenario_code | Personas@20K | Regla / subcaso | Resultado esperado típico |
|-------------:|---|---------------|-------------:|-----------------|---------------------------|
| 0–2 | 3 | `R1_ESC1` | 600 | R1: RES vs LAB, CIIU 10 | Unifica → LAB padre |
| 3–4 | 2 | `R1_ESC2` | 400 | R1: LAB vs RES, CIIU 81 | Unifica → RES padre |
| 5–6 | 2 | `R1_ESC3` | 400 | R1: RES vs CRR, CIIU 55 | Unifica → CRR padre |
| 7–8 | 2 | `R1_EMPATE` | 400 | R1: empate entidades | **Sin** unificación |
| 9–11 | 3 | `R1_HIJA` | 600 | R1: RPU A ya hija (`hijo_a=1`) | Sin unificación nueva |
| 12–14 | 3 | `R2_ESC1` | 600 | R2 Esc1: vacío vs `AP 802` | Gana informado |
| 15–17 | 3 | `R2_ESC2` | 600 | R2 Esc2: inclusión | Gana más completo |
| 18–20 | 3 | `R2_ESC3_SIN_NIT` | 600 | R2 Esc3 sin NIT | Gana más entidades |
| 21–23 | 3 | `R2_ESC4` | 600 | R2 Esc4 dicc mismo nivel | Gana mayor freq |
| 24–29 | 6 | `R2_EMPATE` | 1200 | R2 Esc4 empate freq | **Sin** unificación |
| 30–32 | 3 | `R2_ESC3_NIT` | 600 | R2 Esc3 + NIT → **motor** | Nueva dir enriquecida |
| 33–36 | 4 | `R2_ESC5_MOTOR` | 800 | R2 Esc5 sub1 motor | Nueva dir combinada |
| 37–39 | 3 | `R2_ESC6_MOTOR` | 600 | R2 Esc6 sub1 motor | Nueva dir cruzada |
| 40–42 | 3 | `R2_ESC4_DIC` | 600 | R2 Esc4 patrón dicc | Diccionario |
| 43–44 | 2 | `R2_ESC5_DIC` | 400 | R2 Esc5 sub2 dicc | Diccionario |
| 45–47 | 3 | `R2_ESC6_DIC` | 600 | R2 Esc6 sub3 dicc | Diccionario |
| 48–50 | 3 | `R3_GEO` | 600 | R3 geo | Gana con coords |
| 51–53 | 3 | `R3_FECHA` | 600 | R3 fecha | Gana por fecha |
| 54–56 | 3 | `R3_DICC_VIA` | 600 | R3 diccionario vía | Gana por conteo vía |
| 57–59 | 3 | `R3_FUERA` | 600 | R3 Δpuerta > 2 | **Sin** unificación |
| 60–99 | 40 | `CONTROL` | 8000 | Calles distintas | **Sin** unificación; 2 vigentes |

---

## 4. DDL exacto (copiar tal cual)

Schema: `bdm_stage`. Al inicio de DATA_LOAD: DROP IF EXISTS + CREATE de todas las tablas de negocio + catálogos.

### 4.1 Catálogos

```sql
-- tipo_ubicacion_dir
(1,'RES'),(2,'LAB'),(3,'CRR'),(4,'JUD'),(5,'CCL')

-- nomenclatura (sigla, nivel_complemento)
('BR',1),('UR',1),('CJ',1),('UN',1),
('ED',2),('ZN',2),('SEC',2),
('MZ',3),('ET',3),
('TO',4),('BQ',4),
('PI',5),('CS',5),('IN',5),('BL',5),
('LC',6),('OF',6),('PL',6),
('AP',7),('GJ',7),('DP',7),('ST',7);
```

### 4.2 Tablas de negocio (columnas)

| Tabla | Columnas |
|-------|----------|
| `ubicacion_estandarizada` | `cod_dw_ubic BIGINT`, `texto_ubicacion VARCHAR(200)`, `cod_dw_ciudad INTEGER`, `latitud DECIMAL(10,7)`, `longitud DECIMAL(10,7)` |
| `direccion_fisica` | `cod_dw_direccion_fisica BIGINT`, `complemento VARCHAR(100)`, `cod_dw_ubic BIGINT`, `tipo_via_principal VARCHAR(5)`, `via_principal VARCHAR(10)`, `via_generadora VARCHAR(10)`, `numero_puerta VARCHAR(10)`, `generada_enriquecida INTEGER` |
| `relacion_persona_ubicacion` | `cod_dw_persona_ubic BIGINT`, `id_buro_persona INTEGER`, `cod_pin_persona INTEGER`, `cod_dw_ubic BIGINT`, `cod_dw_direccion_fisica BIGINT`, `cod_dw_tipo_ubicacion_dir INTEGER`, `ind_unificacion INTEGER`, `orden_prioridad INTEGER`, `fecha_relacion_persona_ubicaci DATE`, `lote INTEGER`, `cod_tipo_ident_fte INTEGER` |
| `ciiu_persona` | `id_buro_persona INTEGER`, `cod_act_econo_ciiu_fte VARCHAR(10)` |
| `reporte_relacion_persona_ubica` | `cod_dw_persona_ubic BIGINT`, `id_buro_suscriptor INTEGER`, `fecha_reporte DATE`, `lote INTEGER` |
| `unificacion_direccion` | `cod_dw_persona_ubic BIGINT`, `cod_dw_direccion_unificada BIGINT`, `unifica_atributos INTEGER`, `fecha_unificacion DATE`, `lote INTEGER`, `severidad INTEGER`, `usuario_bd VARCHAR(100)` — **vacía en load** |
| `diccionario_complementos` | `cod_dw_ubic BIGINT`, `id_buro_persona INTEGER`, `nomenclatura VARCHAR(50)`, `nomen VARCHAR(10)`, `valor VARCHAR(50)`, `frecuencia INTEGER` |
| `diccionario_via` | `tipo VARCHAR(20)`, `llave VARCHAR(100)`, `via_generadora VARCHAR(10)`, `cod_dw_municipio INTEGER`, `conteo INTEGER` |
| `relacion_ubicac_estandar_geo` | `cod_dw_ubic BIGINT`, `latitud`, `longitud` — **crear vacía** |
| `bloqueo` | `id_buro_persona INTEGER` — **crear vacía** |

### 4.3 Instrumentación / generación

```sql
CREATE TABLE bdm_stage.perf_timings (
  run_id VARCHAR(64), step_order INT, step_id VARCHAR(64),
  label VARCHAR(256), script_source VARCHAR(256),
  started_at TIMESTAMP, ended_at TIMESTAMP,
  duration_sec BIGINT, status VARCHAR(16)
);

-- perf_scenario_seed: ver columnas en §5
-- perf_persona: CTAS desde perf_nums ⋈ seed
-- perf_persona_meta: (id_buro_persona, persona_seq, scenario_code)
```

---

## 5. Seed completo (INSERT obligatorio)

Columnas del VALUES (en este orden):

`bucket_lo, bucket_hi, scenario_code, ciiu, tipo_a, tipo_b, comp_a, comp_b, same_ubic, tipo_via, via_base, gen_a, gen_b, puerta_a, puerta_b, lat_a, lon_a, lat_b, lon_b, nit_flag, hijo_a, rep_a, rep_b, needs_dic`

```sql
INSERT INTO bdm_stage.perf_scenario_seed VALUES
-- R1 (0-11)
(0,2,'R1_ESC1','10',1,2,'','',1,'CL',45,12,12,'33','33',NULL,NULL,NULL,NULL,1,0,2,5),
(3,4,'R1_ESC2','81',2,1,'','',1,'KR',7,80,80,'22','22',NULL,NULL,NULL,NULL,1,0,1,4),
(5,6,'R1_ESC3','55',1,3,'','',1,'AK',57,63,63,'45','45',NULL,NULL,NULL,NULL,1,0,2,6),
(7,8,'R1_EMPATE','10',2,3,'','',1,'KR',7,80,80,'22','22',NULL,NULL,NULL,NULL,1,0,3,3),
(9,11,'R1_HIJA','82',1,3,'','',1,'AK',57,63,63,'45','45',NULL,NULL,NULL,NULL,1,1,2,3),
-- R2 directa (12-29)
(12,14,'R2_ESC1','10',1,1,'','AP 802',1,'DG',50,30,30,'10','10',NULL,NULL,NULL,NULL,1,0,2,3),
(15,17,'R2_ESC2','10',1,1,'AP 702','ED GALICIA AP 702',1,'TV',20,15,15,'40','40',NULL,NULL,NULL,NULL,1,0,2,4),
(18,20,'R2_ESC3_SIN_NIT','55',1,1,'AP 105','AP 404',1,'CL',22,27,27,'45','45',NULL,NULL,NULL,NULL,1,0,2,6),
(21,23,'R2_ESC4','10',1,1,'CS 5','PI 5',1,'CL',80,55,55,'18','18',NULL,NULL,NULL,NULL,1,0,3,2),
(24,29,'R2_EMPATE','10',1,1,'CS 8','PI 8',1,'CL',95,18,18,'42','42',NULL,NULL,NULL,NULL,1,0,2,2),
-- R2 motor (30-39)
(30,32,'R2_ESC3_NIT','10',1,1,'LC 101','LC 205',1,'KR',10,20,20,'30','30',NULL,NULL,NULL,NULL,3,0,3,3),
(33,36,'R2_ESC5_MOTOR','10',1,1,'TO 3','AP 504',1,'KR',30,45,45,'12','12',NULL,NULL,NULL,NULL,1,0,2,3),
(37,39,'R2_ESC6_MOTOR','10',1,1,'ED 2 OF 301','OF 302',1,'DG',70,25,25,'88','88',NULL,NULL,NULL,NULL,1,0,3,2),
-- R2 diccionario (40-47)
(40,42,'R2_ESC4_DIC','10',1,1,'CS 5','PI 5',1,'CL',80,55,55,'18','18',NULL,NULL,NULL,NULL,1,0,3,2),
(43,44,'R2_ESC5_DIC','10',1,1,'TO 5','PI 5',1,'CL',91,12,12,'34','34',NULL,NULL,NULL,NULL,1,0,3,2),
(45,47,'R2_ESC6_DIC','10',1,1,'LC 10 OF 200','OF 200',1,'KR',55,33,33,'22','22',NULL,NULL,NULL,NULL,1,0,4,2),
-- R3 (48-59)
(48,50,'R3_GEO','10',1,1,'','',0,'CL',34,78,80,'52','52',4.6097100,-74.0817500,NULL,NULL,1,0,3,2),
(51,53,'R3_FECHA','10',1,1,'','',0,'KR',15,45,45,'33','35',NULL,NULL,NULL,NULL,1,0,2,4),
(54,56,'R3_DICC_VIA','10',1,1,'','',0,'TV',60,20,22,'44','44',4.6200000,-74.0900000,4.6201000,-74.0901000,1,0,3,8),
(57,59,'R3_FUERA','10',1,1,'','',0,'DG',90,10,10,'50','55',NULL,NULL,NULL,NULL,1,0,2,3),
-- Control (60-99)
(60,99,'CONTROL','10',1,1,'','',0,'CL',100,10,20,'30','40',NULL,NULL,NULL,NULL,1,0,1,1);
```

**Semántica de flags:**

| Flag | Significado |
|------|-------------|
| `same_ubic=1` | R1/R2: ambas RPU apuntan a `cod_dw_ubic = …+1` (misma puerta lógica) |
| `same_ubic=0` | R3/CONTROL: ubicaciones distintas (+1 y +2) |
| `nit_flag` | Va a `cod_tipo_ident_fte` (3 = NIT → rama motor Esc3) |
| `hijo_a=1` | RPU A nace con `ind_unificacion=1` (`R1_HIJA`) |
| `rep_a` / `rep_b` | Cantidad de filas en `reporte_…` (entidades) por RPU |
| `needs_dic` | Metadata; los INSERT de diccionario se filtran por `scenario_code` explícito |

---

## 6. Algoritmo de generación (orden estricto)

### Paso A — Números 1..N

```sql
CREATE TABLE perf_digit (d INT);  -- 0..9
CREATE TABLE perf_nums AS
SELECT persona_seq FROM (
  SELECT ROW_NUMBER() OVER (ORDER BY d1.d,d2.d,d3.d,d4.d,d5.d) AS persona_seq
  FROM perf_digit d1 CROSS JOIN perf_digit d2 CROSS JOIN perf_digit d3
       CROSS JOIN perf_digit d4 CROSS JOIN perf_digit d5
) s WHERE persona_seq <= :N;  -- 20000
```

### Paso B — `perf_persona`

CTAS: `perf_nums` ⋈ `perf_scenario_seed` ON `persona_seq % 100 BETWEEN bucket_lo AND bucket_hi`, con columnas de §2 + todos los campos del seed + `via_num = via_base + (persona_seq % 500)`.

### Paso C — `ubicacion_estandarizada` (2 filas/persona)

**Texto A (`…+1`):**  
`tipo_via || ' ' || via_num || ' ' || gen_a || ' ' || puerta_a`  
`cod_dw_ciudad = 1`, coords `lat_a/lon_a`.

**Texto B (`…+2`):**

| Condición | texto_ubicacion B |
|-----------|-------------------|
| `CONTROL` | `tipo_via \|\| ' ' \|\| (via_num+50) \|\| ' ' \|\| gen_b \|\| ' ' \|\| puerta_b` |
| `same_ubic=1` | **Igual que A** |
| `R3_*` | `tipo_via \|\| ' ' \|\| via_num \|\| ' ' \|\| gen_b \|\| ' ' \|\| puerta_b` |
| else | Igual que A |

### Paso D — `direccion_fisica`

| Fila | cod_df | complemento | cod_dw_ubic | via_principal | via_generadora | numero_puerta |
|------|--------|-------------|-------------|---------------|----------------|---------------|
| A | `…+101` | `comp_a` | `…+1` | `via_num` | `gen_a` | `puerta_a` |
| B | `…+102` | `comp_b` | `…+1` si same_ubic else `…+2` | `via_num` (+50 si CONTROL) | `gen_a` si same_ubic else `gen_b` | `puerta_a` si same_ubic else `puerta_b` |

`generada_enriquecida = NULL` en load.

### Paso E — `ciiu_persona`

`INSERT SELECT id_buro_persona, ciiu FROM perf_persona`.

### Paso F — `relacion_persona_ubicacion` (2 RPU)

| Campo | RPU A | RPU B |
|-------|-------|-------|
| tipo uso | `tipo_a` | `tipo_b` |
| ubic | `…+1` (o lógica same_ubic) | `…+1` si same_ubic else `…+2` |
| dir física | `…+101` | `…+102` |
| `ind_unificacion` | `1` si `hijo_a=1` else `NULL` | `NULL` |
| fecha | `DATEADD(day, -(persona_seq%30), '2025-06-01')` | `DATEADD(day, persona_seq%60, '2025-03-01')` |
| `lote` | 1 | 1 |
| `cod_tipo_ident_fte` | `nit_flag` | `nit_flag` |

### Paso G — `reporte_relacion_persona_ubica`

```sql
-- A: CROSS JOIN números 1..8 WHERE n <= rep_a; id_buro_suscriptor = 900+(n%20); fecha 2025-05-01
-- B: igual con rep_b; fecha 2025-06-01
-- Extra solo R3_DICC_VIA sobre RPU A:
--   CROSS JOIN (1,2,3) → id_buro_suscriptor = 910+n  (suma 3 reportes → A queda con más entidades)
```

### Paso H — `diccionario_complementos` (por scenario_code)

Siempre `cod_dw_ubic = id_buro_persona * 1000 + 1`:

| scenario_code | Filas (nomenclatura / nomen / valor / frecuencia) |
|---------------|-----------------------------------------------------|
| `R2_ESC4`, `R2_ESC4_DIC` | `CS 5`/`CS`/`5`/10 · `PI 5`/`PI`/`5`/4 |
| `R2_ESC3_NIT` | comp_a → LC/101/8 · comp_b → LC/205/4 |
| `R2_ESC5_MOTOR` | TO/3/8 · AP/504/4 |
| `R2_ESC6_MOTOR` | `ED 2 OF 301`→ ED/2/6 y OF/301/4 · comp_b → OF/302/4 |
| `R2_ESC5_DIC` | TO/5/15 · PI/5/6 |
| `R2_ESC6_DIC` | LC/10/20 · OF/200/8 |
| `R2_EMPATE` | CS/8/10 · PI/8/10 |

### Paso I — `perf_persona_meta`

```sql
CREATE TABLE perf_persona_meta AS
SELECT id_buro_persona, persona_seq, scenario_code FROM perf_persona;
```

### Paso J — `diccionario_via` (solo `R3_DICC_VIA`)

```sql
-- tipo='Via_Generadora'
-- llave = tipo_via || ' ' || via_num || ' ' || puerta_a
-- fila1: via_generadora=gen_a, conteo=15
-- fila2: via_generadora=gen_b, conteo=8
-- cod_dw_municipio=1
```

### Paso K — ANALYZE + DROP auxiliares

```sql
ANALYZE relacion_persona_ubicacion;
ANALYZE ubicacion_estandarizada;
ANALYZE direccion_fisica;
ANALYZE ciiu_persona;
ANALYZE reporte_relacion_persona_ubica;
ANALYZE diccionario_complementos;

DROP TABLE IF EXISTS perf_digit;
DROP TABLE IF EXISTS perf_nums;
-- Opcional: DROP perf_persona (mantener perf_persona_meta para validación)
```

### Checks post-carga (esperados @20K)

```sql
-- personas = 20000, rpu = 40000
SELECT COUNT(DISTINCT id_buro_persona) FROM relacion_persona_ubicacion; -- 20000
SELECT COUNT(*) FROM relacion_persona_ubicacion; -- 40000
SELECT scenario_code, COUNT(*) FROM perf_persona_meta GROUP BY 1 ORDER BY 1;
```

---

## 7. Instrumentación de tiempos (`perf_timings`)

### 7.1 Patrón por hito

```sql
-- PERF:BEGIN
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES ('benchmark_20k_batch_v1', :order, ':step_id', ':label', ':source.sql', GETDATE());

-- ... ejecutar lógica de la regla ...

-- PERF:END
UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = 'benchmark_20k_batch_v1'
  AND step_id = ':step_id'
  AND ended_at IS NULL;
```

`run_id` por ambiente: DEV `benchmark_20k_batch_v1` · QA `…_qa_v1` · PDN `…_pdn_v1`.

### 7.2 Los 10 hitos del batch 20K

| order | step_id | label | Script lógico |
|------:|---------|-------|---------------|
| 1 | `DATA_LOAD` | Carga 20000 personas | `inc_data_load.sql` |
| 2 | `R1` | Regla 1 | `02_regla1_unificacion.sql` |
| 3 | `R2_ESC1_2` | R2 Escenarios 1 y 2 | `03_regla2_esc1_2.sql` |
| 4 | `R2_ESC4` | R2 Escenario 4 (+ empate / dicc) | `04_regla2_esc4.sql` |
| 5 | `R2_ESC3_SIN_NIT` | R2 Esc 3 sin NIT | `05_regla2_esc3_sin_nit.sql` |
| 6 | `R2_MOTOR_BATCH_PREP` | Prep motor unificado | `inc_batch_motor_prep.sql` |
| 7 | `R2_MOTOR_BATCH_RUN` | Motor 1 ejecución | `06_motor_nuevas_direcciones.sql` |
| 8 | `R2_MOTOR_BATCH_FIN` | Finalize (+ Esc5/6 dicc) | `inc_batch_motor_finalize.sql` |
| 9 | `R3` | Regla 3 | `10_regla3_geo.sql` |
| 10 | `VALIDATION` | Validación post-run | `01_validate_…` / `inc_validation.sql` |

**Nota:** el tiempo de Esc 5/6 motor y Esc 3 NIT se captura en hitos 6–8 (batch), no como hitos separados. Esc 1, 2, 4, 3-sin-NIT sí tienen hito propio.

### 7.3 Consultas de tiempos (generar siempre)

```sql
-- Por hito
SELECT step_order, step_id, label, duration_sec, started_at, ended_at, status, script_source
FROM bdm_stage.perf_timings
WHERE run_id = 'benchmark_20k_batch_v1'
ORDER BY step_order;

-- E2E
SELECT SUM(duration_sec) AS e2e_sec
FROM bdm_stage.perf_timings
WHERE run_id = 'benchmark_20k_batch_v1' AND status = 'OK';

-- Solo reglas (sin DATA_LOAD / VALIDATION)
SELECT step_id, duration_sec
FROM bdm_stage.perf_timings
WHERE run_id = 'benchmark_20k_batch_v1'
  AND step_id NOT IN ('DATA_LOAD','VALIDATION')
ORDER BY step_order;

-- Agrupado por “familia” de regla
SELECT
  CASE
    WHEN step_id = 'R1' THEN 'R1'
    WHEN step_id LIKE 'R2%' THEN 'R2'
    WHEN step_id = 'R3' THEN 'R3'
    ELSE 'OTRO'
  END AS familia,
  SUM(duration_sec) AS sec
FROM bdm_stage.perf_timings
WHERE run_id = 'benchmark_20k_batch_v1' AND status = 'OK'
GROUP BY 1
ORDER BY 1;
```

---

## 8. Consultas de clasificación (dónde quedó cada usuario)

`unifica_atributos`: **1 = R1**, **2 = R2**, **3 = R3**.  
Hija: `relacion_persona_ubicacion.ind_unificacion = 1`.  
Vigente/padre: `ind_unificacion IS NULL`.  
Log: `unificacion_direccion` (`cod_dw_persona_ubic` = hijo, `cod_dw_direccion_unificada` = padre).

### 8.1 Contadores globales

```sql
SELECT 'personas' AS metric, COUNT(DISTINCT id_buro_persona) AS val FROM bdm_stage.relacion_persona_ubicacion
UNION ALL SELECT 'rpu_total', COUNT(*) FROM bdm_stage.relacion_persona_ubicacion
UNION ALL SELECT 'rpu_vigentes', COUNT(*) FROM bdm_stage.relacion_persona_ubicacion WHERE ind_unificacion IS NULL
UNION ALL SELECT 'rpu_hijas', COUNT(*) FROM bdm_stage.relacion_persona_ubicacion WHERE ind_unificacion = 1
UNION ALL SELECT 'unificaciones', COUNT(*) FROM bdm_stage.unificacion_direccion
UNION ALL SELECT 'generada_enriquecida', COUNT(*) FROM bdm_stage.direccion_fisica WHERE generada_enriquecida = 1;
```

### 8.2 Absorciones por regla

```sql
SELECT unifica_atributos AS regla, COUNT(*) AS absorciones
FROM bdm_stage.unificacion_direccion
GROUP BY 1 ORDER BY 1;
```

### 8.3 Por scenario_code (clasificación masiva)

```sql
SELECT m.scenario_code,
  COUNT(DISTINCT m.id_buro_persona) AS personas,
  SUM(CASE WHEN u.cod_dw_persona_ubic IS NOT NULL THEN 1 ELSE 0 END) AS rpu_en_log_unificacion
FROM bdm_stage.perf_persona_meta m
LEFT JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
LEFT JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic
GROUP BY 1
ORDER BY 1;
```

### 8.4 Por regla × escenario

```sql
SELECT m.scenario_code, u.unifica_atributos AS regla, COUNT(*) AS absorciones
FROM bdm_stage.perf_persona_meta m
JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic
GROUP BY 1, 2
ORDER BY 1, 2;
```

### 8.5 Rol de cada RPU (PADRE / HIJO / VIGENTE sin log)

```sql
SELECT
  m.scenario_code,
  r.id_buro_persona,
  r.cod_dw_persona_ubic AS rpu,
  CASE
    WHEN r.ind_unificacion = 1 THEN 'HIJO'
    WHEN EXISTS (
      SELECT 1 FROM bdm_stage.unificacion_direccion u
      WHERE u.cod_dw_direccion_unificada = r.cod_dw_persona_ubic
    ) THEN 'PADRE'
    ELSE 'VIGENTE_SIN_HIJOS'
  END AS rol,
  u.cod_dw_direccion_unificada AS apunta_a_padre,
  u.unifica_atributos AS regla
FROM bdm_stage.perf_persona_meta m
JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
LEFT JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic
ORDER BY m.scenario_code, r.id_buro_persona, r.cod_dw_persona_ubic;
```

(Para muestras: añadir `WHERE m.scenario_code = 'R2_ESC1' LIMIT 100`.)

### 8.6 Detalle hijo → padre (una persona)

```sql
SELECT
  hijo.id_buro_persona AS persona,
  hijo.cod_dw_persona_ubic AS rpu_hijo,
  padre.cod_dw_persona_ubic AS rpu_padre,
  u.unifica_atributos AS regla,
  m.scenario_code
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion hijo ON u.cod_dw_persona_ubic = hijo.cod_dw_persona_ubic
JOIN bdm_stage.relacion_persona_ubicacion padre ON u.cod_dw_direccion_unificada = padre.cod_dw_persona_ubic
JOIN bdm_stage.perf_persona_meta m ON m.id_buro_persona = hijo.id_buro_persona
WHERE hijo.id_buro_persona = 100001;  -- ejemplo: primer R1_ESC1
```

### 8.7 Escenarios motor (deben tener ~3 RPU/persona post-run)

```sql
SELECT m.scenario_code,
  COUNT(DISTINCT m.id_buro_persona) AS personas,
  COUNT(r.cod_dw_persona_ubic) AS rpu
FROM bdm_stage.perf_persona_meta m
LEFT JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
WHERE m.scenario_code IN ('R2_ESC3_NIT','R2_ESC5_MOTOR','R2_ESC6_MOTOR')
GROUP BY 1 ORDER BY 1;
```

### 8.8 Escenarios que NO deben unificar

```sql
SELECT m.scenario_code, COUNT(u.cod_dw_persona_ubic) AS absorciones_inesperadas
FROM bdm_stage.perf_persona_meta m
LEFT JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
LEFT JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic
WHERE m.scenario_code IN ('R1_EMPATE','R1_HIJA','R2_EMPATE','R3_FUERA','CONTROL')
GROUP BY 1
ORDER BY 1;
-- Esperado: absorciones_inesperadas = 0 (salvo R1_HIJA que ya trae ind_unificacion=1 sin fila nueva en log de esta corrida)
```

### 8.9 Invariantes (violaciones → 0)

```sql
-- Padre nunca hijo
SELECT COUNT(*) AS violaciones_padre_hijo
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r
  ON r.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
WHERE r.ind_unificacion = 1;

-- CONTROL siempre 2 vigentes
SELECT COUNT(*) AS violaciones_control
FROM (
  SELECT m.id_buro_persona
  FROM bdm_stage.perf_persona_meta m
  LEFT JOIN bdm_stage.relacion_persona_ubicacion r
    ON r.id_buro_persona = m.id_buro_persona AND r.ind_unificacion IS NULL
  WHERE m.scenario_code = 'CONTROL'
  GROUP BY m.id_buro_persona
  HAVING COUNT(r.cod_dw_persona_ubic) <> 2
) t;
```

### 8.10 Gate PASS/FAIL @20K batch

Esperado: **10 hitos OK**, **20000** personas, **42000** RPU, invariantes **0**.

---

## 9. Script C — DROP post-pruebas (cleanup)

Generar un SQL que:

1. DROP de **todas** las `stg_regla1_*`, `stg_regla2_*`, `stg_motor_*`, `stg_regla3_*` (lista base en [`Demo_1_2/03_demo_cleanup.sql`](../Demo_1_2/03_demo_cleanup.sql)).
2. DROP de tablas mock + instrumentación.
3. **NO** haga `DROP SCHEMA bdm_stage`.

Plantilla mínima:

```sql
-- ============================================================
-- C_cleanup_post_pruebas.sql
-- Tras validar tiempos y clasificación — liberar bdm_stage mock
-- ============================================================

-- Staging R1
DROP TABLE IF EXISTS bdm_stage.stg_regla1_insumo;
DROP TABLE IF EXISTS bdm_stage.stg_regla1_scored;
DROP TABLE IF EXISTS bdm_stage.stg_regla1_pares;

-- Staging R2 (lista completa del cleanup demo + cualquier stg_regla2_* adicional del batch)
DROP TABLE IF EXISTS bdm_stage.stg_regla2_insumo;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_esc1_pares;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e1;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_esc2_pares;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e2;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_a;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_c;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_d;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e031;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_nit_pares;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub1;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_e;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_a;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_c;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub1;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub2;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_e;

-- Motor
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
DROP TABLE IF EXISTS bdm_stage.stg_motor_descomp;
DROP TABLE IF EXISTS bdm_stage.stg_motor_mdir;
DROP TABLE IF EXISTS bdm_stage.stg_motor_pares;
DROP TABLE IF EXISTS bdm_stage.stg_motor_resultado;
DROP TABLE IF EXISTS bdm_stage.stg_motor_final;
DROP TABLE IF EXISTS bdm_stage.stg_motor_max_ids;

-- Staging R3
DROP TABLE IF EXISTS bdm_stage.stg_regla3_insumo;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_pares;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_diccionario_via;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_scored;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_resultado;

-- Instrumentación / seed
DROP TABLE IF EXISTS bdm_stage.perf_timings;
DROP TABLE IF EXISTS bdm_stage.perf_scenario_seed;
DROP TABLE IF EXISTS bdm_stage.perf_persona;
DROP TABLE IF EXISTS bdm_stage.perf_persona_meta;
DROP TABLE IF EXISTS bdm_stage.perf_digit;
DROP TABLE IF EXISTS bdm_stage.perf_nums;

-- Tablas de negocio mock
DROP TABLE IF EXISTS bdm_stage.unificacion_direccion;
DROP TABLE IF EXISTS bdm_stage.relacion_persona_ubicacion;
DROP TABLE IF EXISTS bdm_stage.reporte_relacion_persona_ubica;
DROP TABLE IF EXISTS bdm_stage.ubicacion_estandarizada;
DROP TABLE IF EXISTS bdm_stage.direccion_fisica;
DROP TABLE IF EXISTS bdm_stage.ciiu_persona;
DROP TABLE IF EXISTS bdm_stage.tipo_ubicacion_dir;
DROP TABLE IF EXISTS bdm_stage.nomenclatura;
DROP TABLE IF EXISTS bdm_stage.diccionario_complementos;
DROP TABLE IF EXISTS bdm_stage.diccionario_via;
DROP TABLE IF EXISTS bdm_stage.relacion_ubicac_estandar_geo;
DROP TABLE IF EXISTS bdm_stage.bloqueo;

-- NO: DROP SCHEMA bdm_stage;
```

Si solo quieres **re-ejecutar** el benchmark sin cleanup total: vuelve a correr DATA_LOAD (ya hace DROP+CREATE de tablas de negocio) y `DELETE FROM perf_timings WHERE run_id = '…'`.

---

## 10. Checklist de aceptación para SQL generado por IA

- [ ] N personas configurables; default 20000  
- [ ] 22 filas en `perf_scenario_seed` **idénticas** a §5  
- [ ] Fórmulas de ID §2 sin desviación  
- [ ] 2 ubic + 2 dir + 2 RPU por persona en load  
- [ ] Diccionarios filtrados por `scenario_code` (§6 H/J)  
- [ ] `perf_persona_meta` disponible para clasificación  
- [ ] Script B con tiempos (§7) + clasificación (§8)  
- [ ] Script C con DROP staging + mock + perf_* (§9)  
- [ ] Sin inventar tablas/columnas fuera de esta spec  
- [ ] Dialect: Amazon Redshift (`GETDATE`, `DATEDIFF(second,…)`, `DATEADD`, `DISTSTYLE` opcional)

---

## 11. Referencias rápidas en el repo

| Necesitas | Archivo |
|-----------|---------|
| DML canónico | `Benchmark_20K/inc_data_load.sql` |
| Monolito 20K | `Benchmark_20K/00_run_benchmark_20k_batch.sql` |
| Validación DBeaver | `Benchmark_20K/Optimizado/01_validate_benchmark_20k_dev.sql` |
| Cleanup demo | `Demo_1_2/03_demo_cleanup.sql` |
| Semántica demo 19 personas | `Demo_1_2/01_demo_setup.sql` |
| Guía operativa | `Benchmark_20K/GUIA_BENCHMARK_20K_KIRO.md` |
| Armar monolito | `Benchmark_20K/build_benchmark.ps1` |

---

## 12. Prompt corto para pegar a otra IA

```
Lee Benchmark_20K/SPEC_IA_DATOS_SINTETICOS_20K.md y genera tres SQL Redshift:
A) carga sintética N=20000 según §§2–6 (seed §5 literal),
B) queries de perf_timings (§7) + clasificación padre/hijo por scenario_code y regla (§8),
C) DROP post-pruebas (§9).
No inventes columnas. Cumple el checklist §10.
```
