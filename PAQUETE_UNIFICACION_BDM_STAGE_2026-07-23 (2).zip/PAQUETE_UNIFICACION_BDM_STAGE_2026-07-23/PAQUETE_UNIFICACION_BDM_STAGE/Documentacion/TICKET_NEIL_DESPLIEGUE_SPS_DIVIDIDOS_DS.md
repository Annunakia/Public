# Ticket — Despliegue Unificación SPs divididos (reales + mock) en consumidor QA

**Sistema / cola sugerida:** Redshift / Data Sharing / Reconocer Batch QA  
**Solicitante:** Andrés  
**Fecha:** 2026-09-17  
**Prioridad:** Alta (bloquea pruebas QA Unificación)

---

## Título (pegar)

```
[Reconocer QA] Desplegar Unificación SPs divididos — path reales (edf_views) + path mock (bdm_stage) · feature/unificacion-edf-views
```

---

## Descripción (pegar)

### Ya validado en DEV productor (referencia)
En `procesosbatch-dev` / `dba_batch` el solicitante ya desplegó y verificó:
- 15 SPs `sp_unificacion_*` + 15 `sp_unificacion_mock_*` + `v_mock_*` + tabla `unificacion_direccion_mock`
- Esc4 con fix TC-R2-14 (`HAVING COUNT(*) = 1`) en real y mock
- TC-R2-14 = 0 en suite mock; gates reales C03/C04 = 0

### Promoción Bitbucket (2026-09-18) — parcial
Ya mergearon a **`qa/SLCOPRBA-1284`** (Unificación Alpha · **solo path reales**):
- `_strct` **PR #3** · `_pgm` **PR #3** · `_dt` **PR #7**
- Incluye vistas `v_xpm_*` + 15 SPs reales (Esc4 fix) + run/validación
- **Aún no** en QA branch: SPs/`v_mock_*` / salida mock → este ticket sigue para completar path mock + grants/seed

### Resumen
Necesitamos desplegar en **consumidor Reconocer QA** (`dba_rncr_batch`) la Unificación de direcciones con **SPs divididos por escenario**, en **dos familias** para que QA pruebe sin confundir modos:

| Modo | SPs | Fuente | Salida |
|------|-----|--------|--------|
| **Reales + Data Sharing** | `bdm_datos.sp_unificacion_*` (sin `mock`) | `edf_views` → `bdm_tempo.v_xpm_*` | `bdm_datos.unificacion_direccion` |
| **Mock** | `bdm_datos.sp_unificacion_mock_*` (con `mock`) | `bdm_stage` → `bdm_tempo.v_mock_*` | `bdm_datos.unificacion_direccion_mock` |

**No usar** path legacy: `bdm_stage.sp_unificacion_regla*` (SPs monolíticos sin DS).

### Ambiente
| Pieza | Valor |
|-------|--------|
| Cluster | Consumidor Reconocer |
| Database | `dba_rncr_batch` |
| Data Sharing (reales) | `ds_dba_rncr_batch.edf_views` → vistas `bdm_tempo.v_xpm_*` |
| Seed mock | Tablas `bdm_stage.*` + vistas `bdm_tempo.v_mock_*` |

### Repos / rama / orden de deploy (Jenkins)
| Orden | Repo | Rama |
|------:|------|------|
| 1 | `db_rcncr_btch_rdshft_strct` | `feature/unificacion-edf-views` |
| 2 | `db_rcncr_btch_rdshft_pgm` | `feature/unificacion-edf-views` |
| 3 | `db_rcncr_btch_rdshft_dt` | `feature/unificacion-edf-views` |

PRs (referencia):
- `_strct`: https://code.experian.local/projects/COAWSPPR/repos/db_rcncr_btch_rdshft_strct/pull-requests/2
- `_pgm`: https://code.experian.local/projects/COAWSPPR/repos/db_rcncr_btch_rdshft_pgm/pull-requests/2
- `_dt`: https://code.experian.local/projects/COAWSPPR/repos/db_rcncr_btch_rdshft_dt/pull-requests/6

### Qué debe incluir el deploy

**`_strct`**
- Vistas reales: `02_vistas_insumo_edf_views.sql` (`v_xpm_*`)
- Vistas mock: `02b_vistas_insumo_mock.sql` (`v_mock_*`)
- DDL salida mock: `01b_ddl_unificacion_direccion_mock.sql`
- DDL salida real / catálogos: `01_ddl_unificacion_direccion.sql`

**`_pgm`**
- 15 SPs reales `sp_unificacion_*`
- 15 SPs mock `sp_unificacion_mock_*` (misma subdivisión; leen `v_mock_*` / `bdm_stage`)

**`_dt`**
- `run_unificacion_ejecucion_secuencial.sql` (reales)
- `run_unificacion_mock_ejecucion_secuencial.sql` (mock)

### Tareas solicitadas
1. Merge / aprobar PRs y ejecutar **pipeline** en orden `_strct` → `_pgm` → `_dt` sobre consumidor QA.
2. Confirmar Data Sharing activo (`edf_views` visible para `v_xpm_*`).
3. Grants usuario QA:
   - EXECUTE sobre `bdm_datos.sp_unificacion_*` y `bdm_datos.sp_unificacion_mock_*`
   - SELECT/INSERT/UPDATE/DELETE en `bdm_stage` (seed mock)
   - Escritura en `bdm_datos` / `bdm_tempo` según corrida
4. Sembrar / habilitar **seed mock** en `bdm_stage` (suite TC + geo R3 con lat/long).
5. Entregar a QA confirmación de objetos desplegados (lista de SPs + vistas).

### Cómo validará QA (criterios de aceptación)

**A — Reales**
```sql
-- run_unificacion_ejecucion_secuencial.sql
CALL bdm_datos.sp_unificacion_regla1();
CALL bdm_datos.sp_unificacion_regla2();
CALL bdm_datos.sp_unificacion_regla3();
```
- Gates: **C03 = 0**, **C04 = 0** sobre `bdm_datos.unificacion_direccion`
- R3 sin geo → 0 filas = **N/A** (no es FAIL)

**B — Mock**
```sql
-- run_unificacion_mock_ejecucion_secuencial.sql
CALL bdm_datos.sp_unificacion_mock_regla1();
CALL bdm_datos.sp_unificacion_mock_regla2();
CALL bdm_datos.sp_unificacion_mock_regla3();
```
- Resultado en `bdm_datos.unificacion_direccion_mock`
- Suite TC: **TC-R2-14 = 0** · R3 mock con geo **sí se prueba**
- **No mezclar** SPs reales y mock en la misma corrida

### Done cuando
| Modo | Criterio |
|------|----------|
| Reales | Pipeline OK + SPs `sp_unificacion_*` + vistas `v_xpm_*` + C03/C04 = 0 en corrida QA |
| Mock | SPs `sp_unificacion_mock_*` + vistas `v_mock_*` + seed `bdm_stage` + grants + TC-R2-14 = 0 y R3 mock ejecutable |

### Referencias en repo `_dt` (docs)
- `docs/TICKET_NEIL_DESPLIEGUE_SPS_DIVIDIDOS_DS.md`
- `docs/MATRIZ_QA_SPS_DIVIDIDOS_DS.md`
- `docs/MAPEO_QA_IFR_TABLAS_COLUMNAS.md`
- `docs/ENTREGA_QA_UNIFICACION.md`
- `docs/MAPA_UNIFICACION_EDF_VIEWS_NEGOCIO.html`

### Contacto
Andrés — Unificación Reconocer / paquete Kidar
