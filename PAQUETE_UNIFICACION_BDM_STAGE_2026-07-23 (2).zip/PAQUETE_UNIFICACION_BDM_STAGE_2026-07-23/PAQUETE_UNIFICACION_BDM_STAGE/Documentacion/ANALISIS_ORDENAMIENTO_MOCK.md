# Análisis Ordenamiento + enlace a mocks de Unificación

> **Fuente:** `Manuel.transcripcion.txt`, `Public-main` (`01`–`06_*.sql`), `ws-ordenamiento/data/mock/mock_data_ordenamiento.sql`  
> **Paquete unificación:** `sql/01_bdm_stage_mock_setup.sql` (~20k personas / ~43k RPU)

---

## 1. Qué es Ordenamiento (vs Unificación)

| Proceso | Pregunta que responde | Entrada | Salida |
|---------|----------------------|---------|--------|
| **Unificación R1/R2/R3** | ¿Qué direcciones de la misma persona son la misma? | `relacion_persona_ubicacion` + ubicaciones | `unificacion_direccion`, `ind_unificacion=1` en hijas |
| **Ordenamiento** | ¿Qué dato de contacto es más confiable para ubicar a la persona? | Insumos por canal + betas | `score_ordenamiento`, `orden_prioridad` en RPU |

Unificación **reduce** direcciones duplicadas. Ordenamiento **rankea** contactos (DIR, TEL, CEL, EMA) por score de contactabilidad.

```
bdm_stage (post R1→R2→R3)
        ↓  ganadoras (ind_unificacion NULL)
   insumo_direccion  ←── derivado del mock unificación
   insumo_telefono   ←── mock adicional (no existe en unificación)
   insumo_celular    ←── mock adicional
   insumo_email      ←── mock adicional
        ↓
   02_scoring_dir … 05_scoring_ema  (× beta_ordenamiento)
        ↓
   score_ordenamiento (canal, score, lugar)
        ↓
   06_consolidacion → UPDATE relacion_persona_ubicacion.orden_prioridad
```

---

## 2. Pipeline SQL (PoC Kidar — ya validado en sandbox)

| Paso | Script | Qué hace |
|------|--------|----------|
| 0 | `01_ordenamiento_schemas.sql` | DDL: `beta_ordenamiento`, `insumo_*`, `score_ordenamiento` |
| 1 | Mock / carga insumos | Betas + filas en `insumo_direccion`, `insumo_telefono`, `insumo_celular`, `insumo_email` |
| 2 | `02_scoring_dir.sql` | 12 características DIR → score + `lugar` por persona+dirección |
| 3 | `03_scoring_tel.sql` | 11 características TEL |
| 4 | `04_scoring_cel.sql` | 11 características CEL |
| 5 | `05_scoring_ema.sql` | 13 características EMA |
| 6 | `06_consolidacion_persistencia.sql` | `UPDATE orden_prioridad` desde `score_ordenamiento` |

**Regla común de scoring (los 4 canales):**

1. Agregar métricas por **persona + clave del contacto** (dirección, teléfono, celular o email).
2. **Categorizar** cada métrica en bins (CASE WHEN con umbrales fijos).
3. **Ponderar:** `(categoría / max_categoría) × valor_beta` sumando todas las características del canal.
4. **Rankear:** `ROW_NUMBER() OVER (PARTITION BY id_buro_persona ORDER BY score DESC)` → `lugar`.

Ejemplo DIR (`02_scoring_dir.sql`):

- Métricas: meses desde primer reporte, # reportes 12m/6m, % sector financiero, tipo RES/LAB/CRR, # entidades, etc.
- Betas en `bdm_datos.beta_ordenamiento` (`canal='DIR'`, `cod_caracteristica='CO00DIR001IN'`, …).
- Agrupación: `GROUP BY id_buro_persona, direccion_fisica` (no por cada fila de reporte).

---

## 3. Tablas insumo — qué necesita cada canal

### `insumo_direccion` (canal DIR) — **se puede derivar del mock unificación**

| Columna | Origen en mock `bdm_stage` |
|---------|---------------------------|
| cod_dw_persona_ubic, cod_pin_persona, id_buro_persona | `relacion_persona_ubicacion` |
| direccion_fisica | `ubicacion_estandarizada.texto_ubicacion` |
| complemento | `direccion_fisica.complemento` |
| tipo_ubicacion | `tipo_ubicacion_dir.descripcion_tipo_ubicacion_dir` (RES/LAB/CRR) |
| cod_dane_ciudad | `ubicacion_estandarizada.cod_dw_ciudad` |
| id_buro_suscriptor, fecha_reporte | `reporte_relacion_persona_ubica` |
| meses_reporte | `DATEDIFF(month, fecha_reporte, CURRENT_DATE)` |
| sector_financiero | **Mock:** regla sobre `id_buro_suscriptor` o tabla auxiliar |
| conteo_direcciones | COUNT direcciones distintas por persona |

**Filtro clave:** solo RPUs **ganadoras** post-unificación → `COALESCE(ind_unificacion, 0) <> 1`.

### `insumo_telefono`, `insumo_celular`, `insumo_email` — **no vienen de unificación**

Unificación solo trabaja **direcciones**. Para TEL/CEL/EMA hay que **generar mocks** para las mismas personas (Manuel: partir de la base 20k/43k y agregar contactos).

Campos mínimos: ver DDL en `01_ordenamiento_schemas.sql` y ejemplos en `mock_data_ordenamiento.sql` (9 personas de prueba).

### `beta_ordenamiento`

Catálogo estático (~47 filas). Ya está en `mock_data_ordenamiento.sql` y en `ws-ordenamiento/data/synthetic/BETA_ORDENAMIENTO.csv`. En QA real: `ifr_data.v_beta_ordenamiento_*`.

---

## 4. Enlace mock unificación → ordenamiento

### Lo que ya tienes (paquete actual)

| Objeto | Mock 20k | Uso ordenamiento |
|--------|----------|------------------|
| `relacion_persona_ubicacion` | ✅ ~43k RPU | Base; post-R1/R2/R3 + `orden_prioridad` destino |
| `ubicacion_estandarizada` | ✅ | Texto dirección → `insumo_direccion.direccion_fisica` |
| `direccion_fisica` | ✅ | Complemento |
| `reporte_relacion_persona_ubica` | ✅ | Suscriptor, fecha → meses_reporte |
| `tipo_ubicacion_dir` | ✅ | RES/LAB/CRR |
| `unificacion_direccion` | ✅ post SPs | Historial padre-hijo |
| Tel / cel / email | ✅ | `04_insumo_tel_cel_ema_sintetico.sql` |

### Orden de ejecución propuesto (Experian / `bdm_stage` o `bdm_datos`)

```
1. sql/01_bdm_stage_mock_setup.sql          -- si no hay datos (o usar 42k reales DEV)
2. sql/05–08 unificación R1→R2→R3          -- deja ind_unificacion y ganadoras
3. sql/ordenamiento_mock/01_schemas.sql    -- copia de Public 01
4. sql/ordenamiento_mock/02_mock_betas.sql -- betas
5. sql/ordenamiento_mock/03_insumo_dir_desde_stage.sql  -- DIR desde unificación
6. sql/ordenamiento_mock/02b_sync_rpu_ganadoras.sql
7. sql/ordenamiento_mock/04_insumo_tel_cel_ema_sintetico.sql
8. sql/ordenamiento_mock/05_validate_ordenamiento_mock.sql
9. Public 02 → 06 scoring + consolidación
10. Validación: score_ordenamiento + orden_prioridad
```

Script de enlace DIR: `sql/ordenamiento_mock/03_insumo_dir_desde_stage.sql`.

---

## 5. Reglas funcionales (resumen por canal)

### DIR — 12 características

Prioriza direcciones con: más reportes recientes, más entidades financieras, tipo RES/LAB favorable, más entidades reportando, mayor peso relativo de reportes sobre total persona.

### TEL — 11 características

Prioriza: teléfonos con reportes válidos (≠ `NO VALIDA`), alta frecuencia 12m/6m, coincidencia geográfica, sector financiero, tipo cuenta FIJA.

### CEL — 11 características

Prioriza: operador (310…), pospago, reportes recientes, vínculo con texto ubicación.

### EMA — 13 características

Prioriza: dominios conocidos (gmail, hotmail…), reportes recientes, sector financiero, tipo cuenta PERSONAL.

---

## 6. Validación (referencia Kidar)

PoC con **9 personas** (`mock_data_ordenamiento.sql`): 15 scores, `orden_prioridad` actualizado — coherente manualmente.

Escala **5.000 personas** (seed=42): 95.210 insumos → 25.108 scores, 0 errores.

Para Experian: empezar con **9 personas** (smoke) → extender a subset del mock 20k → full 20k.

---

## 7. Gaps / pendientes

| # | Gap | Acción |
|---|-----|--------|
| 1 | SPs pre-proceso Teradata (`ORDENAMIENTO_242`, 12 SPs) no migrados | PoC Redshift usa `insumo_*` directo; OK para mock |
| 2 | `06_consolidacion` incompleto vs Teradata completo | Suficiente para ranking por RPU dentro de cada canal |
| 3 | Movilidad (P0029) no migrado | Fuera de scope mock inicial |
| 4 | Mock TEL/CEL/EMA para 20k personas | ✅ `04_insumo_tel_cel_ema_sintetico.sql` |
| 5 | `sector_financiero` no está en mock unificación | Mock: suscriptor >= 901 = financiero |
| 6 | Schema destino Experian | `bdm_datos` en `dba_rncr_batch` (acordado con Manuel) |

---

## 8. Referencias en repo

| Recurso | Ruta |
|---------|------|
| SQL scoring PoC | `Public-main/Public-main/01`–`06_*.sql` |
| Mock 9 personas | `.../ws-ordenamiento/data/mock/mock_data_ordenamiento.sql` |
| Resultados prueba | `.../ws-ordenamiento/docs/tecnico/resultados_pruebas_ordenamiento.md` |
| Orquestación Control-M | `.../proyecto/orquestacion/orquestacion_control_m_unificacion_ordenamiento.md` |
| Salidas esperadas | `.../proyecto/campos_salida_unificacion_ordenamiento.md` |
| Mock unificación 20k | `sql/01_bdm_stage_mock_setup.sql` |
| Enlace DIR mock | `sql/ordenamiento_mock/03_insumo_dir_desde_stage.sql` |
| Mock TEL/CEL/EMA 20K | `sql/ordenamiento_mock/04_insumo_tel_cel_ema_sintetico.sql` |
| Runner Python | `tools/ordenamiento_mock_run.py` |

---

*Siguiente paso: ejecutar `01`–`05` en DEV post-unificación → scoring `02`–`06` Public-main.*
