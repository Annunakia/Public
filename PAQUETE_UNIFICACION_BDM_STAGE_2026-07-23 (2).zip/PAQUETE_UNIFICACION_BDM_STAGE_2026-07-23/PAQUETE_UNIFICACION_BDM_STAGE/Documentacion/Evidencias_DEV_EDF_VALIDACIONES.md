# Evidencias validaciones DEV EDF (consumidor Reconocer)

```json
{
  "files": {
    "smoke_edf": [
      {
        "paso": "01_ds_dba_rncr_batch.edf_views.xpm",
        "total": 538235
      },
      {
        "paso": "02_xpm_location",
        "total": 599394
      },
      {
        "paso": "03_xpm_ci",
        "total": 2353389
      },
      {
        "paso": "04_xpm_cp",
        "total": 419506
      },
      {
        "paso": "05_xpm_con_location",
        "total": 599394
      },
      {
        "paso": "06_join_contactos_tipo_8",
        "total": 585732
      },
      {
        "paso": "07_vista_contacto_direccion",
        "total": 591166
      },
      {
        "paso": "08_vista_reportes",
        "total": 670487
      }
    ],
    "validaciones_unificacion": [
      {
        "validacion": "A01_relacion_persona_ubicacion",
        "total": 591166
      },
      {
        "validacion": "A02_ubicacion_estandarizada",
        "total": 588528
      },
      {
        "validacion": "A03_direccion_fisica",
        "total": 588196
      },
      {
        "validacion": "A04_ciiu_persona",
        "total": 407390
      },
      {
        "validacion": "A05_reporte_relacion_persona_ubica",
        "total": 670487
      },
      {
        "validacion": "A06_tipo_ubicacion_dir",
        "total": 6
      },
      {
        "validacion": "B01_total_unificaciones",
        "total": 72448
      },
      {
        "validacion": "B02_por_regla",
        "unifica_atributos": 2,
        "total": 72448
      },
      {
        "validacion": "B03_padres_distintos",
        "total": 72445
      },
      {
        "validacion": "B04_hijos_distintos",
        "total": 72448
      },
      {
        "validacion": "C01_fechas_del_dia",
        "total": 72448
      },
      {
        "validacion": "C02_usuarios_ejecucion",
        "usuario_bd": "c32525e",
        "total": 72448
      },
      {
        "validacion": "C03_hijos_sin_padre",
        "total": 0
      },
      {
        "validacion": "C04_autoreferencia",
        "total": 0
      }
    ]
  },
  "extra": {
    "sp_desplegados": [
      {
        "proname": "sp_unificacion_regla1"
      },
      {
        "proname": "sp_unificacion_regla2"
      },
      {
        "proname": "sp_unificacion_regla3"
      }
    ],
    "por_regla": [
      {
        "unifica_atributos": 2,
        "n": 72448
      }
    ],
    "cadena_vistas_sp": [
      {
        "paso": "D_v_ciiu",
        "total": 407390
      },
      {
        "paso": "D_v_reportes",
        "total": 670487
      },
      {
        "paso": "D_v_rpu",
        "total": 591166
      },
      {
        "paso": "E_nomenclatura",
        "total": 12
      },
      {
        "paso": "E_tipo_ubicacion_dir",
        "total": 6
      },
      {
        "paso": "F_insumo_r1_potencial",
        "total": 588196
      },
      {
        "paso": "G_sp_r1",
        "total": 1
      },
      {
        "paso": "G_sp_r2",
        "total": 1
      },
      {
        "paso": "G_sp_r3",
        "total": 1
      }
    ],
    "integridad": [
      {
        "check_name": "hijos_sin_padre",
        "n": 0
      },
      {
        "check_name": "fecha_hoy",
        "n": 72448
      },
      {
        "check_name": "autoreferencia",
        "n": 0
      }
    ],
    "ind_unificacion_marcados": [
      {
        "marcados": 0,
        "sin_marcar": 591166,
        "total": 591166
      }
    ]
  }
}
```
