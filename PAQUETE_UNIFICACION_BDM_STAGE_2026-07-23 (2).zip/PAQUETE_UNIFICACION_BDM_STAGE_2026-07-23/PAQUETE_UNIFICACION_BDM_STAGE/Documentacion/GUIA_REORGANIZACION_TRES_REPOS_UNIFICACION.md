# Guía de reorganización — Unificación en 3 repos Bitbucket

> **Uso:** input para Cursor / equipo al migrar código del paquete local a los repos del pipeline Redshift.  
> **Convención de nombres:** según Manuel — **sin ticket Jira** en el nombre del archivo; solo prefijo numérico de orden + descripción clara.  
> **Fuente datos:** `edf_views` vía datasharing (`ds_dba_rncr_batch.edf_views.*`) — **lectura remota, sin copiar tablas XPM al consumidor**.

---

## 1. Los tres repos

| Orden deploy | Repo | URL |
|-------------:|------|-----|
| 1 | `db_rcncr_btch_rdshft_strct` | https://code.experian.local/projects/COAWSPPR/repos/db_rcncr_btch_rdshft_strct/browse |
| 2 | `db_rcncr_btch_rdshft_pgm` | https://code.experian.local/projects/COAWSPPR/repos/db_rcncr_btch_rdshft_pgm/browse |
| 3 | `db_rcncr_btch_rdshft_dt` | https://code.experian.local/projects/COAWSPPR/repos/db_rcncr_btch_rdshft_dt/browse |

Cada repo = una subtarea Jira del pilot Jenkins (`type: struct` / `program` según repo).

---

## 2. Convención de nombres (sin ticket)

| Regla | Ejemplo |
|-------|---------|
| Sin `SLCOPRBA-XXXX` ni ID de historia | ~~`SLCOPRBA-1147-sp_r1.sql`~~ |
| Orden explícito con prefijo `00_`, `01_`, … en **_strct** | `01_ddl_unificacion_direccion.sql` |
| SPs con nombre funcional en **_pgm** | `sp_unificacion_regla1.sql` |
| Scripts de corrida con verbo `run_` en **_dt** | `run_unificacion_ejecucion_secuencial.sql` |
| Validación con prefijo `validacion_` en **_dt** | `validacion_unificacion_conteos.sql` |
| `deploy.par` lista **un archivo por línea**, en orden de ejecución | Igual nombre que en `SQL/` |
| `RevSQL/` mismo nombre que `SQL/` para rollback | `DROP` / `CREATE` inverso |

---

## 3. Mapeo paquete local → repos

### Repo 1 — `_strct` (estructura)

| Archivo en repo | Origen en paquete | Qué hace |
|-----------------|-------------------|----------|
| `00_prerequisitos_schemas.sql` | `sql/dev_edf_datasharing/00_prerequisitos_dev.sql` | Schemas `bdm_datos`, `bdm_tempo` + `convert_epoch_to_date` |
| `01_ddl_unificacion_direccion.sql` | `sql/dev_edf_datasharing/01_ddl_unificacion_direccion.sql` | Tabla salida + catálogos locales pequeños |
| `02_vistas_insumo_edf_views.sql` | `sql/dev_edf_datasharing/00_vistas_insumo_bdm.sql` | Vistas `bdm_tempo.v_xpm_*` sobre datashare |

**`deploy.par`:**
```
00_prerequisitos_schemas.sql
01_ddl_unificacion_direccion.sql
02_vistas_insumo_edf_views.sql
```

**No incluir:** tablas mock `bdm_stage.relacion_persona_ubicacion` ni copias de `edf_views`.

---

### Repo 2 — `_pgm` (programas) — **un SP por escenario**

Cada archivo = **un procedimiento = un escenario** (fácil de revisar en PR). Tres orquestadores encadenan los `CALL`.

| Archivo | Procedimiento | Escenario / rol |
|---------|---------------|-----------------|
| `sp_unificacion_r1_preparar_insumo.sql` | `sp_unificacion_r1_preparar_insumo` | Insumo común R1 |
| `sp_unificacion_r1_esc1_ciiu10_mismo_texto_padre_lab_crr.sql` | mismo | **R1 Esc1** — CIIU 10, padre LAB/CRR |
| `sp_unificacion_r1_esc2_ciiu81_90_mismo_texto_padre_res_crr.sql` | mismo | **R1 Esc2** — CIIU 81/82/90, padre RES/CRR |
| `sp_unificacion_r1_esc3_otros_ciiu_mayor_entidades_reportan.sql` | mismo | **R1 Esc3** — otros CIIU, mayor entidades |
| `sp_unificacion_regla1.sql` | `sp_unificacion_regla1` | **Orquestador R1** |
| `sp_unificacion_r2_preparar_insumo.sql` | `sp_unificacion_r2_preparar_insumo` | Insumo común R2 |
| `sp_unificacion_r2_esc1_complemento_vacio_esc2_substring_complemento.sql` | mismo | **R2 Esc1+2** — complemento vacío / substring |
| `sp_unificacion_r2_esc3_sin_nit_misma_nomenclatura.sql` | mismo | **R2 Esc3** — misma nomenclatura sin NIT |
| `sp_unificacion_r2_esc4_diccionario_frecuencia_complemento.sql` | mismo | **R2 Esc4** — diccionario frecuencia |
| `sp_unificacion_r2_esc5_nomenclatura_menor_nivel_pierde.sql` | mismo | **R2 Esc5** — menor nivel nomenclatura pierde |
| `sp_unificacion_r2_esc6_frecuencia_complemento_gana.sql` | mismo | **R2 Esc6** — frecuencia complemento gana |
| `sp_unificacion_r2_motor_nit_empates_nuevas_direcciones.sql` | mismo | **R2 Motor** — NIT / empates |
| `sp_unificacion_regla2.sql` | `sp_unificacion_regla2` | **Orquestador R2** |
| `sp_unificacion_r3_esc1_geo_misma_via_puerta_cercana.sql` | mismo | **R3 Esc1** — geo puerta ±2 |
| `sp_unificacion_regla3.sql` | `sp_unificacion_regla3` | **Orquestador R3** |

**`deploy.par`:** los 15 archivos en orden (escenarios antes que orquestador de cada regla).

**Regenerar desde monolito validado:**
```powershell
py -3 tools/gen_unificacion_sps_por_escenario.py
```

Origen lógica: `sql/qa_ifr_data/05-07_sp_regla*.sql` → salida en `sql/unificacion_por_escenario/` y `deploy_bitbucket/.../pgm/SQL/`.

**Lectura:** todos consumen `bdm_tempo.v_xpm_*` (datashare `edf_views`). Staging `stg_regla2_e2` persiste entre escenarios R2 hasta que el orquestador limpia al final.

---

### Repo 3 — `_dt` (datos / ejecución)

| Archivo en repo | Origen en paquete | Qué hace |
|-----------------|-------------------|----------|
| `run_unificacion_ejecucion_secuencial.sql` | Generado por `gen_unificacion_sps_por_escenario.py` | `CALL` orquestadores R1→R2→R3 |
| `validacion_unificacion_conteos.sql` | `sql/dev_edf_datasharing/00_drill_down_validaciones.sql` | SELECT de conteos post-corrida (evidencia DEV) |

**Documentación en repo `_dt`:** `docs/MAPA_UNIFICACION_EDF_VIEWS_NEGOCIO.html` (mapa interactivo datos reales, actualizado 2026-09-04).

**`deploy.par`:**
```
run_unificacion_ejecucion_secuencial.sql
```

> `validacion_unificacion_conteos.sql` es solo lectura; ejecutar manual o en job aparte — no bloquea el deploy productivo.

**Retirar del master:** `run_benchmark_20k_batch_orchestrator.sql` y carga sintética mock (borrar en PR, como acordado).

---

## 4. Arquitectura datasharing (recordatorio)

```
ds_dba_rncr_batch.edf_views.*
        │
        ▼  (vistas, sin copia)
bdm_tempo.v_xpm_*
        │
        ▼  (staging temporal dentro del SP, si aplica)
bdm_tempo.stg_regla*
        │
        ▼  (producto persistente)
bdm_datos.unificacion_direccion
```

Detalle: `Documentacion/ARQUITECTURA_DATASHARING_LECTURA_PRODUCTOR.md`

---

## 5. Rama y PR (flujo Manuel)

1. Clonar los 3 repos desde `master` (Experian).
2. Crear rama: `feature/unificacion-edf-views` (unificación) — luego `feature/ordenamiento` para scoring.
3. Copiar artefactos desde `deploy_bitbucket/` de este paquete (o regenerar con la guía).
4. PR por repo → revisión → pipeline Jenkins (o ticket DBA si falla datashare).
5. Validar DEV: R2 ≈ 72.448 absorciones, ≈ 518.718 ganadoras (`Evidencias_DEV_EDF_DATASHARING.md`).

---

## 6. Carpeta lista para copiar

En el paquete:

```
deploy_bitbucket/
├── db_rcncr_btch_rdshft_strct/deploy/redshift/
├── db_rcncr_btch_rdshft_pgm/deploy/redshift/
└── db_rcncr_btch_rdshft_dt/deploy/redshift/
```

Copiar cada subcarpeta al repo homónimo en Bitbucket (misma estructura `deploy/redshift/SQL`).

---

## 7. Ordenamiento (rama aparte — después de cerrar unificación)

Misma lógica de 3 repos, nombres sin ticket:

| Repo | Archivos previstos |
|------|-------------------|
| `_strct` | `01_ddl_ordenamiento.sql`, `02_catalogos_ordenamiento.sql`, `03_vistas_contacto_canal_edf_views.sql` |
| `_pgm` | `sp_ordenamiento_preparar_insumos_edf.sql`, `sp_ordenamiento_scoring_{dir,tel,cel,ema}_edf.sql`, `sp_ordenamiento_consolidacion_edf.sql`, `sp_ordenamiento_ejecucion_edf.sql` |
| `_dt` | `run_ordenamiento_ejecucion_edf.sql`, `validacion_ordenamiento_conteos.sql` |

Origen: `sql/dev_edf_ordenamiento/`

---

## 8. Checklist lunes

- [ ] `_strct` desplegado (vistas `edf_views`)
- [ ] `_pgm` desplegado (SPs regla 1–3)
- [ ] `_dt` ejecutado (`run_unificacion_ejecucion_secuencial.sql`)
- [ ] Validación conteos OK en DEV
- [ ] Mock SLCOPRBA-1147 eliminado del master en los 3 repos
