# Entrega QA — Ordenamiento (scoring post-unificación)

**Alcance de esta entrega:** solo **Ordenamiento / scoring de contactabilidad** (DIR · TEL · CEL · EMA).  
**Fuera de alcance aquí:** Unificación R1/R2/R3 (ver `ENTREGA_QA_UNIFICACION.md`).

**Fecha:** 2026-09-16  
**Rama Bitbucket (3 repos):** `feature/ordenamiento`  
**Orden deploy:** `_strct` → `_pgm` → `_dt`  
**Precondición:** Unificación ya corrida (hijas excluidas; solo ganadoras entran).

---

## 1. Qué deben configurar en el prompt

Hay **dos modos**. Elegir **uno** por corrida; no mezclar.

| | Modo A — Datos reales (EDF) | Modo B — Datos mockeados |
|--|-----------------------------|---------------------------|
| **Para qué** | Cierre / gates de Ordenamiento | Smoke / suite controlada |
| **DB** | Consumidor Reconocer · `dba_rncr_batch` | Productor / sandbox · `dba_batch` |
| **Insumo** | Post-unificación + `edf_views` / `v_xpm_*` | `sql/ordenamiento_mock/` o smoke 9 personas |
| **SPs** | Sufijo `_edf` en **`bdm_datos`** | Path legacy `bdm_stage` (sin `_edf`) |
| **Betas** | Catálogo **RITM5226589** (47 coefs Teradata) | Mismo catálogo RITM |

---

## 2. Modo A — Datos reales (Ordenamiento EDF)

### 2.1 Precondición

1. Data Sharing activo (`ds_dba_rncr_batch.edf_views`).
2. Vistas `bdm_tempo.v_xpm_*` desplegadas.
3. Unificación ejecutada → `bdm_datos.unificacion_direccion` con C03/C04 = 0.
4. Catálogos / DDL ordenamiento desplegados (`_strct`).

### 2.2 Artefactos por repo

| Repo | Qué despliega |
|------|----------------|
| `_strct` | DDL + catálogos + vistas contacto/insumo EDF |
| `_pgm` | SPs preparar · scoring DIR/TEL/CEL/EMA · consolidación · drop staging · orquestador |
| `_dt` | `run_ordenamiento_ejecucion_edf.sql` + `validacion_ordenamiento_conteos.sql` |

### 2.3 Stored procedures (nombres exactos)

```sql
-- Orquestador (recomendado)
CALL bdm_datos.sp_ordenamiento_ejecucion_edf(TRUE);

-- Equivalente por pasos (si se valida fase a fase):
-- CALL bdm_datos.sp_ordenamiento_preparar_insumos_edf();
-- CALL bdm_datos.sp_ordenamiento_scoring_dir_edf();
-- CALL bdm_datos.sp_ordenamiento_scoring_tel_edf();
-- CALL bdm_datos.sp_ordenamiento_scoring_cel_edf();
-- CALL bdm_datos.sp_ordenamiento_scoring_ema_edf();
-- CALL bdm_datos.sp_ordenamiento_consolidacion_edf();
-- CALL bdm_datos.sp_ordenamiento_drop_staging_edf();
```

Script DT: `run_ordenamiento_ejecucion_edf.sql`

### 2.4 Salidas a validar

| Objeto | Rol |
|--------|-----|
| `bdm_datos.score_ordenamiento` | Scores por canal |
| `bdm_datos.rpu_orden_prioridad` | Ranking DIR → `orden_prioridad` |
| `bdm_datos.relacion_persona_ubicacion.orden_prioridad` | Campo final en RPU (canal DIR) |

### 2.5 Gates de Ordenamiento (modo real)

Usar `validacion_ordenamiento_conteos.sql` o:

```sql
-- Scores por canal
SELECT canal, COUNT(*) AS scores,
       ROUND(MIN(score::FLOAT), 4) AS min_s,
       ROUND(MAX(score::FLOAT), 4) AS max_s
FROM bdm_datos.score_ordenamiento
GROUP BY 1 ORDER BY 1;

-- Gate hijas (DEBE ser 0)
SELECT COUNT(*) AS hijas_con_orden_incorrecto
FROM bdm_datos.relacion_persona_ubicacion
WHERE COALESCE(ind_unificacion, 0) = 1
  AND orden_prioridad IS NOT NULL;
```

| Gate | Esperado |
|------|----------|
| Scores DIR / TEL / EMA | > 0 (en DEV ~407K c/u) |
| Scores CEL | Puede ser bajo (dato ambiente; en DEV ~258) |
| `rpu_hijas_con_orden_incorrecto` | **0** |
| Fórmulas TEL-02 / EMA-03 / CEL-02 | Alineadas (ya en rama) |
| Betas | **47 filas RITM5226589** en `bdm_datos.beta_ordenamiento` (ver `BETAS_ORDENAMIENTO_RITM5226589.md`) |

**Evidencia DEV (2026-09-04):** total scores **1.223.998** · RPUs con orden **408.624** · hijas mal ordenadas **0**.

**No mezclar** en la misma corrida: path mock `bdm_stage` + path EDF `bdm_datos`.

---

## 3. Modo B — Datos mockeados (smoke / laboratorio)

| Pieza | Valor |
|-------|--------|
| Scripts | `sql/ordenamiento_mock/` · smoke 9 personas (20001–20009) |
| Guía ejemplos | `GUIA_ORDENAMIENTO_EJEMPLOS_BASICOS.md` §7 |
| Validación | `05_validate_ordenamiento_mock.sql` |

Usar para explicar ranking DIR/TEL/CEL/EMA con casos controlados.  
**No** sirve como cierre formal de prod / paridad Teradata.

---

## 4. Prompts listos (copiar)

### Prompt Ordenamiento — datos reales

```
Proceso: ORDENAMIENTO (scoring DIR/TEL/CEL/EMA). No re-evaluar Unificación salvo precondición.

Ambiente: consumidor Reconocer / dba_rncr_batch (Data Sharing).
Precondición: unificación ya corrida; solo RPU ganadoras entran.
SPs: CALL bdm_datos.sp_ordenamiento_ejecucion_edf(TRUE);
Salidas: bdm_datos.score_ordenamiento + rpu_orden_prioridad / orden_prioridad.
Validar: scores por canal > 0; hijas con orden = 0.
Betas: catálogo RITM5226589 (47 coefs) en bdm_datos.beta_ordenamiento.
CEL bajo en DEV es dato del ambiente, no FAIL del SP.
No mezclar bdm_stage mock en esta corrida.
```

### Prompt Ordenamiento — mock / smoke

```
Proceso: ORDENAMIENTO smoke/mock. No evaluar Unificación EDF.

Usar sql/ordenamiento_mock o personas 20001–20009.
Validar ranking por canal y ejemplos de la guía básica.
No usar como cierre prod ni paridad Teradata.
```

---

## 5. Estado en Bitbucket / brechas

| Ítem Ordenamiento | Estado |
|-------------------|--------|
| DDL + vistas (`_strct`) | En `feature/ordenamiento` |
| 8 SPs `_edf` (`_pgm`) incl. TEL/EMA/CEL | En rama |
| `run_` + validación (`_dt`) | En rama |
| PRs abiertos / merge | **Abiertos** `_strct` #4 · `_pgm` #4 · `_dt` #8 — **falta merge** |
| Deploy Jenkins QA consumidor | Pendiente pipeline (post-merge) |
| **BETAS** catálogo RITM5226589 | **Cargado** productor DEV + SQL en rama; re-evidencia consumidor **LOCKED** |
| **MIG-01** paridad Teradata | Diferido (no bloquea Opción A) |
| **F1-INC** incremental | No en scope Opción A (full refresh) |

---

## 6. Referencias

| Documento | Uso |
|-----------|-----|
| `FASES_ORDENAMIENTO_EXPLICADAS.md` | Fases F0–F4 |
| `GUIA_ORDENAMIENTO_EJEMPLOS_BASICOS.md` | Checklist + ejemplos |
| `Evidencias_ORDENAMIENTO_FORMULAS_DEV.md` | TEL-02 / EMA-03 / CEL-02 |
| `Evidencias_DEV_ORDENAMIENTO_EDF_COMPLETO.md` | E2E DEV |
| `PENDIENTES_Y_CIERRE_2026-09-04.md` | Hecho vs externo |
| `MAPA_ORDENAMIENTO_EDF_VIEWS_NEGOCIO.html` | Mapa negocio |

*Complemento Unificación:* `ENTREGA_QA_UNIFICACION.md`
