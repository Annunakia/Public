# Arquitectura datasharing — lectura en productor, sin copiar insumos

> **Problema detectado:** el pipeline actual **materializa** en el consumidor (`relacion_persona_ubicacion`, `insumo_*`) millones de filas leídas de `edf_views`. Eso no escala (disco, tiempo, duplicación por corte).

> **Principio:** el consumidor Reconocer **lee** del datashare `ds_dba_rncr_batch.edf_views.*` vía vistas `bdm_tempo.v_xpm_*` y **solo persiste el producto** del proceso.

---

## Qué ya estaba bien

| Capa | Objeto | Comportamiento |
|------|--------|----------------|
| Datashare | `ds_dba_rncr_batch.edf_views.*` | Lectura remota productor |
| Vistas insumo | `bdm_tempo.v_xpm_contacto_direccion`, `v_xpm_relacion_persona_ubicacion`, … | `SELECT` sobre datashare, sin copia |
| Unificación | `sp_unificacion_regla1/2/3` | Lee vistas; staging `stg_regla1_*` **temporal** dentro del SP (aceptable) |
| Salida unificación | `bdm_datos.unificacion_direccion` | **Producto local** (~72K filas) |

---

## Qué copiaba (anti-patrón)

| Script / SP | Tabla copiada | Volúmenes DEV | Problema |
|-------------|---------------|---------------|----------|
| `04_materializar_rpu_post_unificacion.sql` | `bdm_datos.relacion_persona_ubicacion` | ~591K filas | Duplica RPU del productor |
| `sp_ordenamiento_preparar_insumos_edf` | `insumo_direccion`, `insumo_telefono`, `insumo_celular`, `insumo_email` | ~2,3M filas | Duplica insumos de scoring |

---

## Diseño objetivo (implementado en `04_vistas_sin_copia_productor.sql` + `05_sp_preparar`)

```
PRODUCTOR (edf_views vía datashare)
        │
        ▼
bdm_tempo.v_xpm_*                    ← lectura remota (contrato datashare)
        │
        ▼  sp_ordenamiento_preparar_insumos_edf (por corrida)
bdm_tempo.stg_*                      ← staging TEMPORAL + ANALYZE + DISTKEY
        │                              (DROP al final de ejecución)
        ├─► sp_ordenamiento_scoring_*_edf
        │         └─► bdm_datos.score_ordenamiento
        │
        └─► sp_ordenamiento_drop_staging_edf
                  └─► bdm_datos.rpu_orden_prioridad (producto persistente)
```

**Escalable:** no hay tablas `insumo_*` ni `relacion_persona_ubicacion` permanentes. El staging existe solo durante la corrida (mismo patrón que `stg_regla1_*` en unificación).

### Persistencia permitida en consumidor

| Objeto | Tipo | Motivo |
|--------|------|--------|
| `unificacion_direccion` | Tabla | Resultado unificación |
| `score_ordenamiento` | Tabla | Scores por canal |
| `rpu_orden_prioridad` | Tabla | `orden_prioridad` (UPDATE consolidación) |
| `beta_ordenamiento`, catálogos | Tabla pequeña | Parametrización local |
| `tipo_ubicacion_dir`, `nomenclatura` | Tabla pequeña | Catálogos negocio |

### No volver a materializar

- ~~`relacion_persona_ubicacion`~~ → `bdm_tempo.v_rpu_post_unificacion`
- ~~`insumo_*` tablas~~ → vistas homónimas sobre datashare

---

## Ejecución

```powershell
# Tras unificación, desplegar vistas sin copia (reemplaza materializar + preparar)
py -3 tools/dev_edf_ordenamiento_run.py --sin-copia

# Scoring sin TRUNCATE/INSERT de insumos
CALL bdm_datos.sp_ordenamiento_ejecucion_edf(FALSE);
```

---

## Notas de rendimiento

- El **primer** scoring sobre vistas puede ser más lento que sobre tablas locales (pushdown al productor).
- Staging **dentro** del SP (CTAS `stg_*` como en R1) sigue siendo válido si un paso concreto lo exige; no debe quedar como tabla permanente entre corridas.
- Catálogos (`sector_financiero`, `tipo_cuenta_tel`) pueden venir del productor vía datashare cuando estén disponibles; hoy son snapshot pequeño local.
