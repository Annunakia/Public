# Ticket — Data Sharing DEV→DEV (`ifr_data` → Reconocer)

> **Proyecto:** MT-EXP-005-MAP-RECONOCER  
> **Fuente acordada:** **`ifr_data.xpm_*`** — modelo XPM tokenizado completo (igual QA)  
> **Actualizado:** 2026-08-25 — confirmado por equipo vs `edf_views`  
> **Nota DEV:** volumen productor hoy es muestra (xpm=144); estructura y tokenización sí son las correctas.

---

## Por qué `ifr_data` y no `edf_views`

| Aspecto | `ifr_data` | `edf_views` |
|---------|------------|-------------|
| Modelo IFR/QA | ✅ Igual (relationalizelastupdate, contacttype 3 tokenizado) | ❌ Distinto (tokenización en contacttype 8) |
| Campos standardized en tipo dir 1–3/7 | ✅ 33 contactos tokenizados en DEV | ❌ vacíos en tipos IFR |
| Volumen DEV hoy | ⚠️ Pequeño (144 xpm) | ✅ Grande (538K xpm) |
| Uso unificación | **Oficial** — SPs QA sin adaptación | Requería workarounds |

**Decisión:** datashare **`ifr_data`**; cuando el pipeline cargue más volumen en DEV, Reconocer lo verá automáticamente vía share.

---

## Resumen ejecutivo
Configurar **Redshift Data Sharing dev→dev** para que el cluster **Reconocer Batch DEV** (consumidor) lea datos IFR/XPM reales desde el cluster **productor IFR/Buro DEV**, ejecute Unificación R1/R2/R3 y persista resultados **localmente** en Reconocer (sin copiar permanentemente las tablas fuente).

Patrón ya validado en mock (`ds_reconocer_tablas` → `db_productor_reconocer` → SP consumidor). En producción DEV se replica la misma lógica con esquema **`ifr_data`** y vistas `bdm_tempo.v_xpm_*`.

---

## 2. Clusters y bases de datos

| Rol | Cluster identifier | Endpoint | Database trabajo |
|-----|-------------------|----------|------------------|
| **Productor (IFR/XPM)** | `eec-aws-us-eits-procesosbatch-dev-redshift` | `eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com` | `dba_batch` |
| **Consumidor (Reconocer)** | `eec-aws-us-eits-reconocerbatch-dev-redshift` | `eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com` | **`dba_reconocerbatch`** |

> **Confirmado por arquitectura:** los datos IFR reales **ya están en DEV** (productor). El consumidor Reconocer solo necesita el datashare montado; la lógica de Unificación **no se reescribe** — es reapuntado de vistas (`sql/dev_ifr_datasharing/`). Los SPs R1/R2/R3 son los mismos que pasaron tests en QA (`sql/qa_ifr_data/05`–`07`).

**Conteos IFR verificados productor DEV (2026-08-25):** xpm=144, location=133, ci=303, cp=126, contactos tokenizados tipo 1–3/7=33.

**Usuario:** `c32525e` en ambos clusters  
**Clave procesosbatch DEV** (`cee2enck00mg`): `b27YWI2FL`  
**Clave Reconocer DEV** (`cz7jl1sn7m8z`): `gl51TGx4nFhD`

**Grants consumidor:** ver `sql/dev_ifr_datasharing/00_grants_dba_reconocer.sql`

**Puerto:** `5440`

---

## 3. Objetos a compartir (productor)

### 3.1 Esquema y tablas IFR (lectura — insumo Unificación)

| Objeto | Descripción |
|--------|-------------|
| `ifr_data.xpm` | Raíz persona (PIN, location, counterparties, CIIU) |
| `ifr_data.xpm_location` | Ubicaciones por persona |
| `ifr_data.xpm_location_val_contactinformations` | Direcciones tokenizadas (`standardized*`, contactType) |
| `ifr_data.xpm_counterparties` | Entidades reportantes |

**No compartir** (quedan locales en consumidor Reconocer):

- Catálogos: `nomenclatura`, `tipo_ubicacion_dir`, `diccionario_via`, `diccionario_complementos`
- Staging: `bdm_tempo.*` / `rec_stage.*`
- Salida: `unificacion_direccion` (escritura local consumidor)

Referencia mapeo columnas: `Documentacion/MAPEO_QA_IFR_TABLAS_COLUMNAS.md`

---

## 4. SQL — Lado PRODUCTOR (ejecutar rol admin productor)

### 4.1 Obtener namespace del consumidor

En cluster **Reconocer DEV** (`dba_reconocerbatch`), ejecutar y guardar el valor:

```sql
SELECT pg_get_cluster_namespace() AS namespace_consumidor_reconocer_dev;
-- Entregar este valor al DBA productor para el GRANT USAGE ON DATASHARE
```

### 4.2 Crear datashare y publicar objetos IFR

```sql
-- ============================================================
-- PRODUCTOR DEV — Data Sharing IFR → Reconocer DEV
-- Cluster: eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg...
-- Database: <DB donde exista ifr_data>
-- ============================================================

-- 1) Crear datashare (nombre alineado al mock ds_reconocer_tablas)
CREATE DATASHARE ds_reconocer_ifr_dev;

-- 2) Publicar esquema IFR
ALTER DATASHARE ds_reconocer_ifr_dev ADD SCHEMA ifr_data;

-- 3) Publicar tablas XPM requeridas (explícito; alternativa: ADD ALL TABLES IN SCHEMA)
ALTER DATASHARE ds_reconocer_ifr_dev ADD TABLE ifr_data.xpm;
ALTER DATASHARE ds_reconocer_ifr_dev ADD TABLE ifr_data.xpm_location;
ALTER DATASHARE ds_reconocer_ifr_dev ADD TABLE ifr_data.xpm_location_val_contactinformations;
ALTER DATASHARE ds_reconocer_ifr_dev ADD TABLE ifr_data.xpm_counterparties;

-- 4) Autorizar namespace del consumidor Reconocer DEV
-- Reemplazar <NAMESPACE_RECONOCER_DEV> por resultado de pg_get_cluster_namespace() en consumidor
ALTER DATASHARE ds_reconocer_ifr_dev
  ADD ACCOUNT "<AWS_ACCOUNT_ID_CONSUMIDOR>"
  NAMESPACE "<NAMESPACE_RECONOCER_DEV>";

-- Si mismo account AWS (dev→dev misma cuenta), usar:
-- GRANT USAGE ON DATASHARE ds_reconocer_ifr_dev TO NAMESPACE '<NAMESPACE_RECONOCER_DEV>';

-- 5) Verificación productor
SELECT * FROM svv_datashares WHERE share_name = 'ds_reconocer_ifr_dev';
SELECT share_name, object_name, object_type
FROM svv_datashare_objects
WHERE share_name = 'ds_reconocer_ifr_dev'
ORDER BY object_name;
```

---

## 5. SQL — Lado CONSUMIDOR (ejecutar rol admin Reconocer DEV)

Cluster: `eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com`  
Database: **`dba_reconocerbatch`**

### 5.1 Crear base de datos desde datashare

```sql
-- ============================================================
-- CONSUMIDOR DEV — Montar IFR compartido
-- Equivalente mock: db_productor_reconocer
-- ============================================================

-- Reemplazar ACCOUNT/NAMESPACE del productor si cross-account
CREATE DATABASE db_ifr_shared
FROM DATASHARE ds_reconocer_ifr_dev
OF ACCOUNT '<AWS_ACCOUNT_ID_PRODUCTOR>'
NAMESPACE '<NAMESPACE_PRODUCTOR_DEV>';

-- Mismo account (dev→dev típico Experian):
-- CREATE DATABASE db_ifr_shared FROM DATASHARE ds_reconocer_ifr_dev;

-- Verificación montaje
SELECT * FROM svv_external_databases WHERE database_name = 'db_ifr_shared';
SELECT * FROM svv_external_schemas WHERE database_name = 'db_ifr_shared';
SELECT * FROM svv_external_tables WHERE database_name = 'db_ifr_shared' LIMIT 20;
```

### 5.2 Gate lectura IFR (antes de desplegar SPs)

```sql
-- Gate 1: conteos tablas base (esperado > 0 en DEV con carga IFR)
SELECT 'xpm' AS t, COUNT(*) AS n FROM db_ifr_shared.ifr_data.xpm
UNION ALL SELECT 'xpm_location', COUNT(*) FROM db_ifr_shared.ifr_data.xpm_location
UNION ALL SELECT 'xpm_ci', COUNT(*) FROM db_ifr_shared.ifr_data.xpm_location_val_contactinformations
UNION ALL SELECT 'xpm_cp', COUNT(*) FROM db_ifr_shared.ifr_data.xpm_counterparties;

-- Gate 2: JOIN direcciones (misma lógica validada QA — esperado ~1285+ contactos en muestra QA)
SELECT COUNT(*) AS contactos_direccion
FROM db_ifr_shared.ifr_data.xpm xpm
JOIN db_ifr_shared.ifr_data.xpm_location loc
  ON xpm.location = loc.id
 AND xpm.relationalizelastupdate = loc.relationalizelastupdate
JOIN db_ifr_shared.ifr_data.xpm_location_val_contactinformations ci
  ON loc."location.val.contactinformations" = ci.id
 AND loc.relationalizelastupdate = ci.relationalizelastupdate
WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7);
```

### 5.3 Permisos usuario aplicativo

```sql
-- Rol/usuario pipeline Unificación
GRANT USAGE ON DATABASE db_ifr_shared TO c32525e;
GRANT USAGE ON SCHEMA db_ifr_shared.ifr_data TO c32525e;
GRANT SELECT ON ALL TABLES IN SCHEMA db_ifr_shared.ifr_data TO c32525e;

-- Schemas locales Reconocer (ya existen: rec_datos, rec_stage, rec_mtdat, rec_vista)
GRANT USAGE ON SCHEMA rec_stage TO c32525e;
GRANT USAGE ON SCHEMA rec_datos TO c32525e;
GRANT USAGE ON SCHEMA rec_mtdat TO c32525e;
GRANT CREATE ON SCHEMA rec_stage TO c32525e;
GRANT CREATE ON SCHEMA rec_datos TO c32525e;

-- Alternativa: asignar rol de servicio batch_reconocer_unificacion con permisos anteriores
```

---

## 6. Despliegue aplicación (equipo Reconocer — post-ticket DBA)

Ejecutar en **`dba_reconocerbatch`** — carpeta **`sql/dev_ifr_datasharing/`** (reapuntado; SPs reutilizados de QA):

| # | Script | Acción |
|---|--------|--------|
| 0 | `00_prerequisitos_dev.sql` | Schemas `bdm_datos`/`bdm_tempo` + `convert_epoch_to_date` |
| 1 | `01_ddl_unificacion_direccion.sql` | Catálogos locales + `unificacion_direccion` (incl. tipo 7=DIR) |
| 2 | `00_vistas_insumo_bdm.sql` | Vistas `bdm_tempo.v_xpm_*` → **`db_ifr_shared.ifr_data.*`** |
| 3 | `00_smoke_ifr_data.sql` / `00_validar_solo_lectura_ifr_data.sql` | Gates lectura datashare |
| 4 | `../qa_ifr_data/05` → `07` | **SPs sin cambios** (tests QA ya OK) |
| 5 | `../qa_ifr_data/08_ejecucion_secuencial.sql` | `CALL R1; CALL R2; CALL R3` |
| 6 | `../qa_ifr_data/03_validaciones_unificacion.sql` | Gate funcional |

Índice: `sql/dev_ifr_datasharing/00_EJECUTAR_DEV_IFR_DATASHARING.sql`

---

## 7. Validación post-configuración (checklist)

| # | Check | Comando / criterio | Estado |
|---|-------|-------------------|--------|
| 1 | Datashare ACTIVE productor | `svv_datashares.share_name = 'ds_reconocer_ifr_dev'` | ☐ |
| 2 | DB externa montada consumidor | `svv_external_databases` → `db_ifr_shared` | ☐ |
| 3 | 4 tablas XPM visibles | `svv_external_tables` count = 4 | ☐ |
| 4 | Gate JOIN contactos | `contactos_direccion > 0` | ☐ |
| 5 | Vistas `v_xpm_*` desplegadas | `SELECT COUNT(*) FROM bdm_tempo.v_xpm_relacion_persona_ubicacion` | ☐ |
| 6 | Catálogo tipo 7=DIR | `SELECT * FROM bdm_datos.tipo_ubicacion_dir WHERE cod=7` | ☐ |
| 7 | CALL R1/R2/R3 OK | Sin error SQL | ☐ |
| 8 | Resultados en salida local | `SELECT unifica_atributos, COUNT(*) FROM bdm_datos.unificacion_direccion GROUP BY 1` | ☐ |

Scripts de validación en paquete:

- `sql/qa_ifr_data/00_validar_solo_lectura_ifr_data.sql`
- `sql/qa_ifr_data/00_validar_sp_joins_inline.sql`
- `tools/qa_ifr_inline_validation.py`

---

## 8. Comparativa mock vs real (para el revisor del ticket)

| Aspecto | Mock QDA | Real DEV→DEV |
|---------|----------|--------------|
| Datashare | `ds_reconocer_tablas` | `ds_reconocer_ifr_dev` |
| DB consumidor | `db_productor_reconocer` | `db_ifr_shared` |
| Datos compartidos | 10 tablas `bdm_datos.*` sintéticas | 4 tablas `ifr_data.xpm_*` reales |
| Transformación | Lectura directa tablas planas | Vistas `v_xpm_*` (XPM → modelo BDM) |
| Salida | `bdm_datos.unificacion_direccion` local | Igual (local en consumidor) |
| SP | `sp_unificacion_completa_data_sharing()` | `sp_unificacion_regla1/2/3()` |

---

## 9. Evidencia estado actual Reconocer DEV (2026-08-24)

Conexión verificada con `c32525e` a `cz7jl1sn7m8z` / `dba_reconocerbatch`:

- ✅ Login OK
- ❌ `svv_datashares` vacío
- ❌ `ifr_data` no presente
- ⚠️ Schemas `rec_datos`, `rec_stage`, `rec_mtdat`, `rec_vista` existen pero **sin permisos visibles** para `c32525e`

---

## 10. Texto corto para pegar en RTN / ServiceNow

**Asunto:** Configurar Data Sharing DEV→DEV — IFR (`ifr_data.xpm_*`) → Reconocer Batch DEV

**Descripción:**

Solicitamos configurar Redshift Datashare entre cluster productor IFR/Buro DEV y cluster consumidor Reconocer Batch DEV para habilitar Unificación de Direcciones con **datos reales XPM** (no mock).

**Productor:** `eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com` — esquema `ifr_data`, tablas `xpm`, `xpm_location`, `xpm_location_val_contactinformations`, `xpm_counterparties`.

**Consumidor:** `eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com` — database `dba_reconocerbatch`.

**Acciones:**

1. CREATE DATASHARE `ds_reconocer_ifr_dev` + ADD tablas IFR listadas.
2. GRANT USAGE al namespace del consumidor Reconocer DEV.
3. En consumidor: CREATE DATABASE `db_ifr_shared` FROM DATASHARE.
4. GRANT SELECT en `db_ifr_shared.ifr_data.*` a usuario `c32525e` (y rol pipeline batch).
5. GRANT USAGE/CREATE en schemas `rec_stage`, `rec_datos`, `rec_mtdat` a `c32525e`.

Referencia: mock validado en QDA (`presentacion_data_sharing.md`). Paquete SQL: `PAQUETE_UNIFICACION_BDM_STAGE/sql/qa_ifr_data/`.

**Criterio de aceptación ticket:** Gate 2 del §5.2 retorna `contactos_direccion > 0` desde consumidor vía `db_ifr_shared`.

---

*Documento generado para MT-EXP-005-MAP-RECONOCER — Unificación + Data Sharing DEV.*
