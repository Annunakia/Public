# Evidencias ejecución pipeline DEV (directa, sin merge PR)

**Fecha:** 2026-09-04T15:36:58

## Pasos ejecutados

1. **_strct** — prerequisitos, DDL, vistas `edf_views`
2. **_pgm** — 15 SPs por escenario + orquestadores
3. **_dt** — `run_unificacion_ejecucion_secuencial.sql` (R1→R2→R3)
4. **Validaciones** — `03_validaciones_unificacion.sql` PASS

## Métricas clave

| Métrica | Valor |
|---------|------:|
| R2 unificaciones | **72.448** |
| C03 hijos sin padre | 0 |
| C04 autoreferencia | 0 |
| Universo RPU | 591.166 |

## Drill-down queries

```json
[
  {
    "sql_head": "-- ============================================================\n-- 00_drill_down_validaciones.sql\n--",
    "rows": [
      {
        "rpus": 591166,
        "personas": 407351,
        "ubicaciones": 407351
      }
    ],
    "n": 1
  },
  {
    "sql_head": "-- Q-UNIV-02: Contacttype crudo\nSELECT\n  NULLIF(TRIM(ci.\"location.val.contactinformations.val.contac",
    "rows": [
      {
        "ct": "8",
        "n": 585732
      },
      {
        "ct": "1",
        "n": 2279
      },
      {
        "ct": "3",
        "n": 1873
      },
      {
        "ct": "2",
        "n": 1282
      }
    ],
    "n": 4
  },
  {
    "sql_head": "-- Q-R1-00: Salida R1\nSELECT COUNT(*)::BIGINT AS unificaciones_r1 FROM bdm_datos.unificacion_direcci",
    "rows": [
      {
        "unificaciones_r1": 0
      }
    ],
    "n": 1
  },
  {
    "sql_head": "-- Q-R1-CAND: Personas y RPUs entrada R1 (ubi deduplicada, DISTINCT RPU)\nWITH ubi1 AS (\n  SELECT cod",
    "rows": [
      {
        "grupos_multitipo": 2074,
        "personas": 156,
        "rpus_en_grupos": 2441
      }
    ],
    "n": 1
  },
  {
    "sql_head": "-- Q-R1-DIR-RESUMEN: Personas que entran a R1 (conteo calles y RPUs)\nWITH ubi1 AS (\n  SELECT cod_dw_",
    "rows": [
      {
        "id_buro_persona": -4875990999627445744,
        "cod_pin_persona": 110146,
        "calles_r1": 54,
        "rpus_r1": 111
      },
      {
        "id_buro_persona": -1906359094925953032,
        "cod_pin_persona": 235550,
        "calles_r1": 42,
        "rpus_r1": 86
      },
      {
        "id_buro_persona": -1560137832939220541,
        "cod_pin_persona": 49286,
        "calles_r1": 36,
        "rpus_r1": 69
      },
      {
        "id_buro_persona": 776276706070538348,
        "cod_pin_persona": 418497,
        "calles_r1": 13,
        "rpus_r1": 67
      },
      {
        "id_buro_persona": 698992710314787707,
        "cod_pin_persona": 258526,
        "calles_r1": 68,
        "rpus_r1": 66
      },
      {
        "id_buro_persona": -9103410599156451413,
        "cod_pin_persona": 310836,
        "calles_r1": 49,
        "rpus_r1": 62
      },
      {
        "id_buro_persona": -401119968657618621,
        "cod_pin_persona": 39795,
        "calles_r1": 40,
        "rpus_r1": 61
      },
      {
        "id_buro_persona": -6204948694683188270,
        "cod_pin_persona": 284281,
        "calles_r1": 16,
        "rpus_r1": 58
      }
    ],
    "n": 154
  },
  {
    "sql_head": "-- Q-R1-DIR-DETALLE: Identificador persona + cada direcci\u00f3n/RPU que aplica a R1\n-- Descomente el fil",
    "rows": [
      {
        "id_buro_persona": -9194362089521182288,
        "cod_pin_persona": 341989,
        "calle": "CARRERA 23 #6C-04 SUR",
        "cod_dw_ciudad": 29599174,
        "tipos_grupo": "CRR + LAB + RES",
        "n_rpus_grupo": 33,
        "rpu": 507625,
        "tipo": "CRR",
        "cod_dw_ubic": 360853,
        "fecha_relacion_persona_ubicaci": "2018-05-31"
      },
      {
        "id_buro_persona": -9194362089521182288,
        "cod_pin_persona": 341989,
        "calle": "CARRERA 23 #6C-04 SUR",
        "cod_dw_ciudad": 29599174,
        "tipos_grupo": "CRR + LAB + RES",
        "n_rpus_grupo": 33,
        "rpu": 507625,
        "tipo": "LAB",
        "cod_dw_ubic": 360853,
        "fecha_relacion_persona_ubicaci": "2018-05-31"
      },
      {
        "id_buro_persona": -9194362089521182288,
        "cod_pin_persona": 341989,
        "calle": "CARRERA 23 #6C-04 SUR",
        "cod_dw_ciudad": 29599174,
        "tipos_grupo": "CRR + LAB + RES",
        "n_rpus_grupo": 33,
        "rpu": 507625,
        "tipo": "RES",
        "cod_dw_ubic": 360853,
        "fecha_relacion_persona_ubicaci": "2018-05-31"
      },
      {
        "id_buro_persona": -9194362089521182288,
        "cod_pin_persona": 341989,
        "calle": "CARRERA 23 #6C-04 SUR",
        "cod_dw_ciudad": 29599174,
        "tipos_grupo": "CRR + LAB + RES",
        "n_rpus_grupo": 33,
        "rpu": 507626,
        "tipo": "CRR",
        "cod_dw_ubic": 360853,
        "fecha_relacion_persona_ubicaci": "2012-10-31"
      },
      {
        "id_buro_persona": -9194362089521182288,
        "cod_pin_persona": 341989,
        "calle": "CARRERA 23 #6C-04 SUR",
        "cod_dw_ciudad": 29599174,
        "tipos_grupo": "CRR + LAB + RES",
        "n_rpus_grupo": 33,
        "rpu": 507626,
        "tipo": "LAB",
        "cod_dw_ubic": 360853,
        "fecha_relacion_persona_ubicaci": "2013-11-30"
      },
      {
        "id_buro_persona": -9194362089521182288,
        "cod_pin_persona": 341989,
        "calle": "CARRERA 23 #6C-04 SUR",
        "cod_dw_ciudad": 29599174,
        "tipos_grupo": "CRR + LAB + RES",
        "n_rpus_grupo": 33,
        "rpu": 507626,
        "tipo": "RES",
        "cod_dw_ubic": 360853,
        "fecha_relacion_persona_ubicaci": "2013-11-30"
      },
      {
        "id_buro_persona": -9194362089521182288,
        "cod_pin_persona": 341989,
        "calle": "CARRERA 23 #6C-04 SUR",
        "cod_dw_ciudad": 29599174,
        "tipos_grupo": "CRR + LAB + RES",
        "n_rpus_grupo": 33,
        "rpu": 507627,
        "tipo": "RES",
        "cod_dw_ubic": 360853,
        "fecha_relacion_persona_ubicaci": "2023-07-31"
      },
      {
        "id_buro_persona": -9194362089521182288,
        "cod_pin_persona": 341989,
        "calle": "CARRERA 23 #6C-04 SUR",
        "cod_dw_ciudad": 29599174,
        "tipos_grupo": "CRR + LAB + RES",
        "n_rpus_grupo": 33,
        "rpu": 507628,
        "tipo": "RES",
        "cod_dw_ubic": 360853,
        "fecha_relacion_persona_ubicaci": "2024-01-31"
      }
    ],
    "n": 138047
  },
  {
    "sql_head": "-- Q-R1-EMPATE: Particiones con/sin ganador \u00fanico (multitipo)\nWITH insumo AS (\n  SELECT rpu.cod_dw_p",
    "rows": [
      {
        "escenario_r1": "ESC3",
        "particiones": 1895,
        "ganador_unico": 0,
        "empates": 1895
      }
    ],
    "n": 1
  },
  {
    "sql_head": "-- Q-R2-00: Salida total R2\nSELECT COUNT(*)::BIGINT AS unificaciones_r2 FROM bdm_datos.unificacion_d",
    "rows": [
      {
        "unificaciones_r2": 72448
      }
    ],
    "n": 1
  },
  {
    "sql_head": "-- Q-R2-ESC1: Candidatos Esc1 (padre comp / hija sin comp) \u2014 estimaci\u00f3n\nSELECT COUNT(DISTINCT b.cod_",
    "error": "relation \"b\" does not exist\n"
  },
  {
    "sql_head": "-- Q-R2-ESC1-EJ: Muestra real unificada R2\nSELECT TOP 10\n  u.cod_dw_persona_ubic AS hija,\n  u.cod_dw",
    "rows": [
      {
        "hija": 3,
        "padre": 2,
        "comp_hija": null,
        "comp_padre": "AP 601",
        "texto_ubicacion": "CL 84 C # 9 - 51 AP 601",
        "tipo": "CRR"
      },
      {
        "hija": 3,
        "padre": 2,
        "comp_hija": null,
        "comp_padre": "AP 601",
        "texto_ubicacion": "CL 84 C # 9 - 51 AP 601",
        "tipo": "CRR"
      },
      {
        "hija": 5,
        "padre": 4,
        "comp_hija": null,
        "comp_padre": "OF 302",
        "texto_ubicacion": "KR 7 # 75 - 51 OF 302",
        "tipo": "CRR"
      },
      {
        "hija": 5,
        "padre": 4,
        "comp_hija": null,
        "comp_padre": "OF 302",
        "texto_ubicacion": "KR 7 # 75 - 51 OF 302",
        "tipo": "CRR"
      },
      {
        "hija": 15,
        "padre": 14,
        "comp_hija": null,
        "comp_padre": "AP 502 B",
        "texto_ubicacion": "KR 9 C # 121 - 53 AP 502 B",
        "tipo": "CRR"
      },
      {
        "hija": 15,
        "padre": 14,
        "comp_hija": null,
        "comp_padre": "AP 502 B",
        "texto_ubicacion": "KR 9 C # 121 - 53 AP 502 B",
        "tipo": "CRR"
      },
      {
        "hija": 22,
        "padre": 21,
        "comp_hija": null,
        "comp_padre": "AP 1205",
        "texto_ubicacion": "KR 14 # 58 - 26 AP 1205",
        "tipo": "CRR"
      },
      {
        "hija": 22,
        "padre": 21,
        "comp_hija": null,
        "comp_padre": "AP 1205",
        "texto_ubicacion": "KR 14 # 58 - 26 AP 1205",
        "tipo": "CRR"
      }
    ],
    "n": 10
  },
  {
    "sql_head": "-- Q-R2-ESC2: Candidatos complemento contenido (sin unificar a\u00fan \u2014 remanente post-R2)\n-- Nota: en co",
    "error": "relation \"b\" does not exist\n"
  },
  {
    "sql_head": "-- Q-R3-GEO: Cobertura latitud\nSELECT\n  SUM(CASE WHEN ubi.latitud IS NOT NULL THEN 1 ELSE 0 END)::BI",
    "rows": [
      {
        "con_lat": 0,
        "total": 1173649
      }
    ],
    "n": 1
  },
  {
    "sql_head": "-- Q-R3-00: Salida R3\nSELECT COUNT(*)::BIGINT AS unificaciones_r3 FROM bdm_datos.unificacion_direcci",
    "rows": [
      {
        "unificaciones_r3": 0
      }
    ],
    "n": 1
  },
  {
    "sql_head": "-- Q-R3-POT: Pares potenciales SIN filtro geo (solo diagn\u00f3stico)\nWITH ins AS (\n  SELECT rpu.cod_dw_p",
    "rows": [
      {
        "pares_potenciales_sin_geo": 0
      }
    ],
    "n": 1
  },
  {
    "por_regla": [
      {
        "unifica_atributos": 2,
        "n": 72448
      }
    ]
  },
  {
    "universo_rpu": [
      {
        "rpus": 591166
      }
    ]
  }
]
```
