# Consultas Alpha / Datashare — 2026-08-25

## Q1_tablas_xpm_por_schema

```sql
SELECT table_schema, table_name
        FROM information_schema.tables
        WHERE table_name IN (
          'xpm','xpm_location','xpm_location_val_contactinformations','xpm_counterparties'
        )
        ORDER BY 1, 2
```

**OK** — [{"table_schema": "bdm_tempo", "table_name": "xpm"}, {"table_schema": "edf_masking", "table_name": "xpm"}, {"table_schema": "edf_masking", "table_name": "xpm_counterparties"}, {"table_schema": "edf_masking", "table_name": "xpm_location"}, {"table_schema": "edf_masking", "table_name": "xpm_location_val_contactinformations"}, {"table_schema": "edf_stage", "table_name": "xpm"}, {"table_schema": "edf_stage", "table_name": "xpm_counterparties"}, {"table_schema": "edf_stage", "table_name": "xpm_location"}, {"table_schema": "edf_stage", "table_name": "xpm_location_val_contactinformations"}, {"table_schema": "edf_views", "table_name": "xpm"}, {"table_schema": "edf_views", "table_name": "xpm_counterparties"}, {"table_schema": "edf_views", "table_name": "xpm_location"}, {"table_schema": "edf_views", "table_name": "xpm_location_val_contactinformations"}]

## Q2_token_bdm_datos

```sql
SELECT column_name
            FROM information_schema.columns
            WHERE table_schema = 'bdm_datos'
              AND table_name = 'xpm_location_val_contactinformations'
              AND (column_name ILIKE '%standardized%'
                   OR column_name ILIKE '%contacttype%'
                   OR column_name ILIKE '%token%')
            ORDER BY 1
            LIMIT 25
```

**OK** — []

## Q2_token_edf_views

```sql
SELECT column_name
            FROM information_schema.columns
            WHERE table_schema = 'edf_views'
              AND table_name = 'xpm_location_val_contactinformations'
              AND (column_name ILIKE '%standardized%'
                   OR column_name ILIKE '%contacttype%'
                   OR column_name ILIKE '%token%')
            ORDER BY 1
            LIMIT 25
```

**OK** — [{"column_name": "location.val.contactinformations.val.contactasreportedstandardized"}, {"column_name": "location.val.contactinformations.val.contactasstandardizedscore"}, {"column_name": "location.val.contactinformations.val.contacttype"}, {"column_name": "location.val.contactinformations.val.contacttypereportedforfirsttime"}, {"column_name": "location.val.contactinformations.val.standardizedcomplemento"}, {"column_name": "location.val.contactinformations.val.standardizeddanecode"}, {"column_name": "location.val.contactinformations.val.standardizeddepartment"}, {"column_name": "location.val.contactinformations.val.standardizedmunicipality"}, {"column_name": "location.val.contactinformations.val.standardizednumeropuerta"}, {"column_name": "location.val.contactinformations.val.standardizedtextoubicacion"}, {"column_name": "location.val.contactinformations.val.standardizedtipo"}, {"column_name": "location.val.contactinformations.val.standardizedtipoviaprincipal"}, {"column_name": "location.val.contactinformations.val.standardizedviageneradora"}, {"column_name": "location.val.contactinformations.val.standardizedviaprincipal"}]

## Q2_token_ifr_data

```sql
SELECT column_name
            FROM information_schema.columns
            WHERE table_schema = 'ifr_data'
              AND table_name = 'xpm_location_val_contactinformations'
              AND (column_name ILIKE '%standardized%'
                   OR column_name ILIKE '%contacttype%'
                   OR column_name ILIKE '%token%')
            ORDER BY 1
            LIMIT 25
```

**OK** — []

## Q2_token_bdm_tempo

```sql
SELECT column_name
            FROM information_schema.columns
            WHERE table_schema = 'bdm_tempo'
              AND table_name = 'xpm_location_val_contactinformations'
              AND (column_name ILIKE '%standardized%'
                   OR column_name ILIKE '%contacttype%'
                   OR column_name ILIKE '%token%')
            ORDER BY 1
            LIMIT 25
```

**OK** — []

## Q3_count_ifr_data_xpm

```sql
SELECT COUNT(*) AS total FROM ifr_data.xpm
```

**OK** — [{"total": 144}]

## Q3_count_edf_views_xpm

```sql
SELECT COUNT(*) AS total FROM edf_views.xpm
```

**OK** — [{"total": 538235}]

## Q3_count_edf_views_xpm_location

```sql
SELECT COUNT(*) AS total FROM edf_views.xpm_location
```

**OK** — [{"total": 599394}]

## Q3_count_edf_views_xpm_location_val_contactinformations

```sql
SELECT COUNT(*) AS total FROM edf_views.xpm_location_val_contactinformations
```

**OK** — [{"total": 2353389}]

## Q3_count_edf_views_xpm_counterparties

```sql
SELECT COUNT(*) AS total FROM edf_views.xpm_counterparties
```

**OK** — [{"total": 419506}]

## Q3_count_bdm_tempo_xpm

```sql
SELECT COUNT(*) AS total FROM bdm_tempo.xpm
```

**OK** — [{"total": 89165}]

## Q4_bdm_datos_xpm_plain

```sql
SELECT COUNT(*) AS total FROM bdm_datos.xpm
```

**ERROR:** `relation "bdm_datos.xpm" does not exist`

## Q5_join_alpha_edf_views

```sql
SELECT COUNT(*) AS contactos_direccion
        FROM edf_views.xpm xpm
        JOIN edf_views.xpm_location loc
          ON xpm.location = loc.id
         AND xpm.relationalizelastupdate = loc.relationalizelastupdate
        JOIN edf_views.xpm_location_val_contactinformations ci
          ON loc."location.val.contactinformations" = ci.id
         AND loc.relationalizelastupdate = ci.relationalizelastupdate
        WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1,
```

**ERROR:** `column xpm.relationalizelastupdate does not exist`

## Q6_datashares_productor

```sql
SELECT share_name, producer_account FROM svv_datashares LIMIT 10
```

**OK** — []

## R1_public_objects

```sql
SELECT table_name, table_type
        FROM information_schema.tables
        WHERE table_schema = 'public'
        ORDER BY 1
```

**OK** — [{"table_name": "diccionario_complementos", "table_type": "BASE TABLE"}, {"table_name": "nomenclatura", "table_type": "BASE TABLE"}, {"table_name": "tipo_ubicacion_dir", "table_type": "BASE TABLE"}, {"table_name": "unificacion_direccion", "table_type": "BASE TABLE"}]

## R2_procs_public

```sql
SELECT proname FROM pg_proc p
        JOIN pg_namespace n ON p.pronamespace = n.oid
        WHERE n.nspname = 'public' AND proname LIKE '%unificacion%'
```

**OK** — [{"proname": "sp_unificacion_regla1"}, {"proname": "sp_unificacion_regla2"}, {"proname": "sp_unificacion_regla3"}]

## R3_select_bdm_datos_xpm

```sql
SELECT COUNT(*) AS total FROM bdm_datos.xpm
```

**ERROR:** `schema "bdm_datos" does not exist`

## R4_select_datashare

```sql
SELECT COUNT(*) AS total FROM db_ifr_shared.bdm_datos.xpm
```

**ERROR:** `"db_ifr_shared" does not exist`

## R5_datashares_consumidor

```sql
SELECT * FROM svv_datashares LIMIT 5
```

**OK** — []

## R6_external_dbs

```sql
SELECT * FROM svv_external_databases LIMIT 5
```

**OK** — []
