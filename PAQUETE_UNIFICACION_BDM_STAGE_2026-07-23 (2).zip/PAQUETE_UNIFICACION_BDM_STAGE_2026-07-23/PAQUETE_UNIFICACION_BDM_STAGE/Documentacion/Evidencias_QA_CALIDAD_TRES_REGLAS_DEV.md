# Evidencias calidad — R1 / R2 / R3 (DEV)

**Resultado global:** PASS

## Salida por regla

| Regla | Unificaciones | Estado | Nota |
|-------|---------------|--------|------|
| R1 | 0 | OK | 0 en DEV real (sin multitipo resoluble) |
| R2 | 72448 | OK | Paridad baseline |
| R3 | 0 | OK | 0 en DEV (sin latitud/cobertura geo) |

## Invariantes de calidad

| Check | Esperado | Actual | Estado |
|-------|----------|--------|--------|
| C03_hijos_sin_padre | 0 | 0 | OK |
| C04_autoreferencia | 0 | 0 | OK |
| C05_hija_duplicada | 0 | 0 | OK |
| C06_padre_no_existe | 0 | 0 | OK |

## Contexto DEV

- Universo RPU: **591,166**
- Cobertura latitud R3: **0** / **1,173,649**
- Grupos multitipo R1 (candidatos): **2,074** grupos, **156** personas

```json
{
  "metricas": {
    "R1_salida": {
      "n": 0
    },
    "R2_salida": {
      "n": 72448
    },
    "R3_salida": {
      "n": 0
    },
    "C03_hijos_sin_padre": {
      "n": 0
    },
    "C04_autoreferencia": {
      "n": 0
    },
    "C05_hija_duplicada": {
      "n": 0
    },
    "C06_padre_no_existe": {
      "n": 0
    },
    "universo_rpu": {
      "n": 591166
    },
    "R3_cobertura_lat": {
      "con_lat": 0,
      "total": 1173649
    },
    "R1_candidatos_multitipo": {
      "grupos": 2074,
      "personas": 156
    }
  },
  "reglas": {
    "R1": {
      "ok": true,
      "nota": "0 en DEV real (sin multitipo resoluble)"
    },
    "R2": {
      "ok": true,
      "nota": "Paridad baseline"
    },
    "R3": {
      "ok": true,
      "nota": "0 en DEV (sin latitud/cobertura geo)"
    }
  },
  "invariantes": {
    "C03_hijos_sin_padre": {
      "expected": 0,
      "actual": 0,
      "ok": true
    },
    "C04_autoreferencia": {
      "expected": 0,
      "actual": 0,
      "ok": true
    },
    "C05_hija_duplicada": {
      "expected": 0,
      "actual": 0,
      "ok": true
    },
    "C06_padre_no_existe": {
      "expected": 0,
      "actual": 0,
      "ok": true
    }
  },
  "pass": true
}
```
