# Evidencias IFR public (producer)
Fecha: 2026-08-25T16:30:17

- **prereq**: OK
- **ddl**: OK
- **vistas_0**: OK
- **vistas_1**: OK
- **vistas_2**: OK
- **vistas_3**: OK
- **vistas_4**: OK
- **vistas_5**: OK
- **05_sp_regla1.sql**: OK
- **06_sp_regla2.sql**: OK
- **07_sp_regla3.sql**: OK
- **execute**: OK

```json
{
  "vista_contactos": {
    "n": 114
  },
  "unificacion": [
    {
      "unifica_atributos": 2,
      "n": 8
    }
  ]
}
```
