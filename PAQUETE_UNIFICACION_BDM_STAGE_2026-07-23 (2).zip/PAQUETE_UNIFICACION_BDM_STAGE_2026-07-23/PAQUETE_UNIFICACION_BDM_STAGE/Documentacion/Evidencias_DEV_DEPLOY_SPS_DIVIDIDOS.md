# Evidencias — Deploy DEV productor SPs divididos

> **Hecho por Andrés (CREATE OK en DEV productor).** En QA **no** hay CREATE → sigue ticket Neil.

## Post-deploy (misma sesión)
- `v_mock_*` legibles (`v_mock_relacion_persona_ubicacion` = 42.056)
- `v_xpm_*` recreadas en productor apuntando a `edf_views` local (el SQL de repo usa `ds_dba_rncr_batch.edf_views` para **consumidor**; en productor se sustituye solo en runtime)
- `v_xpm_relacion_persona_ubicacion` = 593.411
- `CALL bdm_datos.sp_unificacion_mock_r2_preparar_insumo()` → **OK** (~2.7s)
- Esc4 real + mock en cluster: **HAS_FIX** (`HAVING COUNT(*) = 1`)
- TC-R2-14 (`bdm_stage`): **0**
- Revalidación `tools/revalidar_qa_dev_pre_push.py`: **overall PASS** / `push_allowed=true`
- Consumidor DEV / QA productor: auth falló en esta pasada → deploy allá = ticket Neil

- **Fecha (UTC):** 2026-09-17T22:19:14.711988+00:00
- **Host:** `eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com` / `dba_batch` / usuario `c32525e`
- **STRCT:** PASS
- **PGM:** PASS
- **SPs reales en bdm_datos:** 15
- **SPs mock en bdm_datos:** 15
- **Vistas v_xpm_/v_mock_:** 11
- **Esc4 fix en cluster:** [{'name': 'sp_unificacion_mock_r2_esc4_diccionario_frecuencia_complemento', 'fix': 'HAS_FIX'}, {'name': 'sp_unificacion_r2_esc4_diccionario_frecuencia_complemento', 'fix': 'HAS_FIX'}]
- **TC-R2-14 (bdm_stage salida legacy):** 0 (esperado 0)
- **Gates reales snapshot:** R2=72448 C03=0 C04=0

## Fallos

_Ninguno._

## Inventario SPs

```
bdm_datos.sp_unificacion_mock_r1_esc1_ciiu10_mismo_texto_padre_lab_crr
bdm_datos.sp_unificacion_mock_r1_esc2_ciiu81_90_mismo_texto_padre_res_crr
bdm_datos.sp_unificacion_mock_r1_esc3_otros_ciiu_mayor_entidades_reportan
bdm_datos.sp_unificacion_mock_r1_preparar_insumo
bdm_datos.sp_unificacion_mock_r2_esc1_complemento_vacio_esc2_substring_complemento
bdm_datos.sp_unificacion_mock_r2_esc3_sin_nit_misma_nomenclatura
bdm_datos.sp_unificacion_mock_r2_esc4_diccionario_frecuencia_complemento
bdm_datos.sp_unificacion_mock_r2_esc5_nomenclatura_menor_nivel_pierde
bdm_datos.sp_unificacion_mock_r2_esc6_frecuencia_complemento_gana
bdm_datos.sp_unificacion_mock_r2_motor_nit_empates_nuevas_direcciones
bdm_datos.sp_unificacion_mock_r2_preparar_insumo
bdm_datos.sp_unificacion_mock_r3_esc1_geo_misma_via_puerta_cercana
bdm_datos.sp_unificacion_mock_regla1
bdm_datos.sp_unificacion_mock_regla2
bdm_datos.sp_unificacion_mock_regla3
bdm_datos.sp_unificacion_r1_esc1_ciiu10_mismo_texto_padre_lab_crr
bdm_datos.sp_unificacion_r1_esc2_ciiu81_90_mismo_texto_padre_res_crr
bdm_datos.sp_unificacion_r1_esc3_otros_ciiu_mayor_entidades_reportan
bdm_datos.sp_unificacion_r1_preparar_insumo
bdm_datos.sp_unificacion_r2_esc1_complemento_vacio_esc2_substring_complemento
bdm_datos.sp_unificacion_r2_esc3_sin_nit_misma_nomenclatura
bdm_datos.sp_unificacion_r2_esc4_diccionario_frecuencia_complemento
bdm_datos.sp_unificacion_r2_esc5_nomenclatura_menor_nivel_pierde
bdm_datos.sp_unificacion_r2_esc6_frecuencia_complemento_gana
bdm_datos.sp_unificacion_r2_motor_nit_empates_nuevas_direcciones
bdm_datos.sp_unificacion_r2_preparar_insumo
bdm_datos.sp_unificacion_r3_esc1_geo_misma_via_puerta_cercana
bdm_datos.sp_unificacion_regla1
bdm_datos.sp_unificacion_regla2
bdm_datos.sp_unificacion_regla3
```

## Inventario vistas

```
v_mock_ciiu_persona
v_mock_direccion_fisica
v_mock_relacion_persona_ubicacion
v_mock_reporte_relacion_persona_ubica
v_mock_ubicacion_estandarizada
v_xpm_ciiu_persona
v_xpm_contacto_direccion
v_xpm_direccion_fisica
v_xpm_relacion_persona_ubicacion
v_xpm_reporte_relacion_persona_ubica
v_xpm_ubicacion_estandarizada
```

```json
{
  "strct_ok": true,
  "pgm_ok": true,
  "sps_reales": 15,
  "sps_mock": 15,
  "views": 11
}
```
