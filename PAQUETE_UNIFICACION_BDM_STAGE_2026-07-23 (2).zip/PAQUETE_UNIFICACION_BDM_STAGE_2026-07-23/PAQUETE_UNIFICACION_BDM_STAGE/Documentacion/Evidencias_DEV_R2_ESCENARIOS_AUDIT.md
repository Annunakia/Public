# Audit R2 — escenarios, motor y tiempos (consumidor DEV)

Fecha: 2026-08-26  
Cluster: Reconocer DEV / `dba_rncr_batch` / datashare `ds_dba_rncr_batch`

---

## Tiempos de ejecución

| Paso | Segundos |
|------|----------:|
| `CALL sp_unificacion_regla1()` | **10,1** |
| `CALL sp_unificacion_regla2()` | **15,3** |
| `CALL sp_unificacion_regla3()` | **3,5** |
| **Total R1→R2→R3** | **~29 s** |

Pipeline completo anterior (`dev_edf_datasharing_run.py`, incl. deploy + validaciones): **~90 s**.

---

## Desglose por escenario R2 (72.448 filas)

| Escenario SP | Filas en trace | % |
|--------------|---------------:|--:|
| **ESC1 + ESC2** (primer bloque `stg_regla2_e2`) | **72.448** | 100% |
| ESC3 (diccionario nomenclatura) | 0 | — |
| ESC4 (frecuencia diccionario) | 0 | — |
| ESC5 (nivel nomenclatura) | 0 | — |
| ESC6 (empate frecuencia) | 0 | — |

### Subtipo dentro del bloque ESC1/ESC2

| Patrón | Filas |
|--------|------:|
| **ESC1** — padre **con** complemento, hija **sin** complemento | **72.448** |
| ESC2 — un complemento contiene al otro | 0 |

**Conclusión:** en edf_views DEV real, **toda** la R2 es Escenario 1 clásico: dirección base repetida y una variante trae apto/of/local (`AP 601`, `OF 302`, etc.) y la otra no trae complemento.

### Muestras reales

| Dirección base | Tipo | Comp. hija | Comp. padre |
|----------------|------|------------|-------------|
| `CL 84 C # 9 - 51 AP 601` | CRR | *(vacío)* | `AP 601` |
| `KR 7 # 75 - 51 OF 302` | CRR | *(vacío)* | `OF 302` |
| `KR 9 C # 121 - 53 AP 502 B` | CRR | *(vacío)* | `AP 502 B` |

Esc3–Esc6 no aportaron filas porque **Esc1/2 agotó todos los pares** antes (marca `ind_unificacion='S'` en staging).

---

## Motor de direcciones

| Métrica | Valor |
|---------|------:|
| Grupos candidatos (`stg_motor_keys`) | **3** |
| RPUs en ranking motor | **18** |
| Filas `stg_motor_insumo` (dirección sintética) | **9** |
| Personas distintas | **1** (NIT, `cod_tipo_ident_fte=3`) |

### ¿Alguno de los 72.448 usó el motor?

**No.** El motor **no inserta** en `bdm_datos.unificacion_direccion`. Solo construye `stg_motor_insumo` (complemento combinado + `generada_enriquecida=1`) y **se descarta** al cerrar el SP (comentario en SP: *“sin INSERT a ifr_data; pipeline materializa tablas físicas”*).

El motor corre **después** de Esc1–6, sobre RPUs que **siguen** `ind_unificacion='N'`. En esta corrida generó **9 filas staging** para **1 persona NIT** con complementos vacíos en origen (`complemento_motor = ''`), pero **ninguna** de esas filas aparece en la salida de unificación.

---

## Herramienta

```powershell
py -3 tools/audit_r2_escenarios_consumer.py
```

Reconstruye staging sin borrar tablas finales y escribe trazas en `bdm_tempo.diag_r2_trace`.
