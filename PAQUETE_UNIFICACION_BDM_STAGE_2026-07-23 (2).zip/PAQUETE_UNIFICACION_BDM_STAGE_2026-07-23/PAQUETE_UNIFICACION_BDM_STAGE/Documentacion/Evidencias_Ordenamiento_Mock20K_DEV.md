# Evidencias — Ordenamiento Mock Alto 20K DEV

* **Ejecutado:** 2026-08-26
* **Entorno:** Productor DEV — `dba_batch` / `c32525e`
* **Comando:** `CALL bdm_datos.sp_ordenamiento_ejecucion(TRUE)`
* **Duración:** ~50 s
* **Precondición:** `bdm_stage` post-unificación R1/R2/R3

## Entrada (bdm_stage)

| Métrica | Valor |
|---------|------:|
| Personas | 20.028 |
| RPU total | 42.056 |
| RPU ganadoras | 38.239 |

## Insumos generados

| Canal | Filas |
|-------|------:|
| DIR | 77.685 |
| TEL | 77.685 |
| CEL | 140.189 |
| EMA | 140.189 |
| Personas con insumo DIR | 20.027 |

## Scores (`score_ordenamiento`)

| Canal | Scores | Personas | Min | Max |
|-------|-------:|---------:|----:|----:|
| DIR | 28.636 | 20.027 | 0.6013 | 0.7730 |
| TEL | 28.636 | 20.027 | 0.5475 | 0.8175 |
| CEL | 140.189 | 20.027 | 0.4375 | 0.7475 |
| EMA | 40.053 | 20.027 | 0.4642 | 0.7100 |
| **Total** | **237.514** | | | |

## Persistencia

| Métrica | Valor |
|---------|------:|
| RPU en `bdm_datos.relacion_persona_ubicacion` | 38.239 |
| RPU con `orden_prioridad` poblado | **38.239 (100%)** |

## Muestra DIR (personas 100001–100005)

| id_buro_persona | score | lugar |
|----------------|------:|------:|
| 100001 | 0.6763 | 1 |
| 100002 | 0.6763 | 1 |
| 100003 | 0.6430 | 1 |
| 100004 | 0.6430 | 1 |
| 100005 | 0.6763 | 1 |

## Comparación referencia Kidar

| Referencia | Kidar 5K | Experian 20K |
|------------|----------|--------------|
| Insumos totales | ~95.210 | ~435.748 |
| Scores totales | ~25.108 | **237.514** |
| Errores | 0 | **0** |

## Reproducir

```powershell
py tools/ordenamiento_mock_run.py --mock-alto
```

```sql
CALL bdm_datos.sp_ordenamiento_ejecucion(TRUE);
```
