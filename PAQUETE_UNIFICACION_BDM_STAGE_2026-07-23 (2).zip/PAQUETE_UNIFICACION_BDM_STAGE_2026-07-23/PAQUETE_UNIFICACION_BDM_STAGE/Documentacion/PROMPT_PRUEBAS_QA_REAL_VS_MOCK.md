# Prompt + catálogo de nombres — Unificación QA (diseño vigente)

**Para:** QA (ajustar prompts / runners / checklists)  
**Proceso:** solo **Unificación** R1→R2→R3 · **no** Ordenamiento  
**Diseño:** SPs **divididos por escenario** + **Data Sharing** · dos modos  
**Rama:** `feature/unificacion-edf-views`  
**Fecha:** 2026-09-18  

> Elegir **un solo modo** por corrida.  
> Mock siempre lleva **`mock`** en el nombre del SP.  
> **No usar** legacy: `bdm_stage.sp_unificacion_regla*` (monolíticos sin DS).

Detalle tablas/columnas: [`MAPEO_QA_IFR_TABLAS_COLUMNAS.md`](MAPEO_QA_IFR_TABLAS_COLUMNAS.md)  
Matriz: [`MATRIZ_QA_SPS_DIVIDIDOS_DS.md`](MATRIZ_QA_SPS_DIVIDIDOS_DS.md)

---

## 0. Resumen de nombres (pegar en el prompt)

| Pieza | Modo A — **REALES** | Modo B — **MOCK** |
|-------|---------------------|-------------------|
| DB | `dba_rncr_batch` (consumidor) | Mismo (tras deploy Neil) |
| Fuente cruda | `ds_dba_rncr_batch.edf_views.xpm*` | `bdm_stage.*` (seed TC) |
| Vistas que leen los SPs | `bdm_tempo.v_xpm_*` | `bdm_tempo.v_mock_*` |
| Catálogos | `bdm_datos.nomenclatura` · `tipo_ubicacion_dir` · `diccionario_complementos` | `bdm_stage.nomenclatura` · `tipo_ubicacion_dir` · `diccionario_complementos` |
| Staging | `bdm_tempo.stg_regla*` | `bdm_tempo.stg_mock_regla*` |
| **Salida** | **`bdm_datos.unificacion_direccion`** | **`bdm_datos.unificacion_direccion_mock`** |
| Orquestadores | `sp_unificacion_regla1/2/3` | `sp_unificacion_mock_regla1/2/3` |
| Prefijo SPs | `sp_unificacion_*` (**sin** `mock`) | `sp_unificacion_mock_*` |
| Script corrida | `run_unificacion_ejecucion_secuencial.sql` | `run_unificacion_mock_ejecucion_secuencial.sql` |
| Suite TC / `perf_persona_meta` | **No** | **Sí** (`scenario_code`) |
| R3 | Sin lat/long → **N/A** (0 filas ≠ FAIL) | **Sí** (seed con geo) |
| Gate clave | C03=0 · C04=0 | TC-R2-14 = **0** (Esc4) |

---

## 1. Prompt listo — Modo A (datos REALES)

```
Proceso: UNIFICACIÓN de direcciones (R1→R2→R3). NO evaluar Ordenamiento.
Diseño: SPs divididos por escenario + Data Sharing + datos REALES.

Ambiente:
  Cluster: consumidor Reconocer
  Database: dba_rncr_batch

Fuente (Data Sharing):
  ds_dba_rncr_batch.edf_views.xpm
  ds_dba_rncr_batch.edf_views.xpm_location
  ds_dba_rncr_batch.edf_views.xpm_location_val_contactinformations
  ds_dba_rncr_batch.edf_views.xpm_counterparties

Vistas que usan los SPs (validar/gates sobre estas, no XPM crudo):
  bdm_tempo.v_xpm_contacto_direccion
  bdm_tempo.v_xpm_relacion_persona_ubicacion
  bdm_tempo.v_xpm_ubicacion_estandarizada
  bdm_tempo.v_xpm_direccion_fisica
  bdm_tempo.v_xpm_reporte_relacion_persona_ubica
  bdm_tempo.v_xpm_ciiu_persona

Catálogos:
  bdm_datos.nomenclatura
  bdm_datos.tipo_ubicacion_dir
  bdm_datos.diccionario_complementos

Staging: bdm_tempo.stg_regla* / stg_motor*
Salida: bdm_datos.unificacion_direccion

SPs ORQUESTADORES (schema bdm_datos) — SOLO estos, SIN la palabra mock:
  CALL bdm_datos.sp_unificacion_regla1();
  CALL bdm_datos.sp_unificacion_regla2();
  CALL bdm_datos.sp_unificacion_regla3();

SPs subdivididos reales (mismo schema; los orquestadores los llaman):
  R1: sp_unificacion_r1_preparar_insumo
      sp_unificacion_r1_esc1_ciiu10_mismo_texto_padre_lab_crr
      sp_unificacion_r1_esc2_ciiu81_90_mismo_texto_padre_res_crr
      sp_unificacion_r1_esc3_otros_ciiu_mayor_entidades_reportan
  R2: sp_unificacion_r2_preparar_insumo
      sp_unificacion_r2_esc1_complemento_vacio_esc2_substring_complemento
      sp_unificacion_r2_esc3_sin_nit_misma_nomenclatura
      sp_unificacion_r2_esc4_diccionario_frecuencia_complemento
      sp_unificacion_r2_esc5_nomenclatura_menor_nivel_pierde
      sp_unificacion_r2_esc6_frecuencia_complemento_gana
      sp_unificacion_r2_motor_nit_empates_nuevas_direcciones
  R3: sp_unificacion_r3_esc1_geo_misma_via_puerta_cercana

PROHIBIDO en esta corrida:
  - sp_unificacion_mock_* (cualquier SP con "mock")
  - bdm_stage.sp_unificacion_* (legacy)
  - bdm_datos.unificacion_direccion_mock
  - perf_persona_meta / scenario_code / TC-R*-*

Validación:
  - Conteos por unifica_atributos sobre bdm_datos.unificacion_direccion
  - C03 = 0 (hijo sin padre)
  - C04 = 0 (autoreferencia)
  - R3 sin lat/long → 0 filas = N/A (NO marcar FAIL)
  - No exigir cobertura de todos los escenarios R1/R2 solo con muestra real pequeña
```

---

## 2. Prompt listo — Modo B (datos MOCK)

```
Proceso: UNIFICACIÓN de direcciones (R1→R2→R3) — suite TC / laboratorio.
Diseño: SPs divididos por escenario + Data Sharing + datos MOCK.
NO evaluar Ordenamiento.

Ambiente:
  Database: dba_rncr_batch (consumidor, tras deploy Neil)
  Seed: tablas bdm_stage.*

Fuente seed (bdm_stage):
  relacion_persona_ubicacion
  ubicacion_estandarizada
  direccion_fisica
  reporte_relacion_persona_ubica
  ciiu_persona
  tipo_ubicacion_dir
  nomenclatura
  diccionario_complementos
  perf_persona_meta   ← scenario_code para TC

Vistas que usan los SPs mock (NO leen edf_views):
  bdm_tempo.v_mock_relacion_persona_ubicacion
  bdm_tempo.v_mock_ubicacion_estandarizada
  bdm_tempo.v_mock_direccion_fisica
  bdm_tempo.v_mock_reporte_relacion_persona_ubica
  bdm_tempo.v_mock_ciiu_persona

Catálogos: bdm_stage.nomenclatura / tipo_ubicacion_dir / diccionario_complementos
Staging: bdm_tempo.stg_mock_regla* / stg_mock_motor*
Salida: bdm_datos.unificacion_direccion_mock

SPs ORQUESTADORES (schema bdm_datos) — DEBEN llevar "mock" en el nombre:
  CALL bdm_datos.sp_unificacion_mock_regla1();
  CALL bdm_datos.sp_unificacion_mock_regla2();
  CALL bdm_datos.sp_unificacion_mock_regla3();

SPs subdivididos mock:
  R1: sp_unificacion_mock_r1_preparar_insumo
      sp_unificacion_mock_r1_esc1_ciiu10_mismo_texto_padre_lab_crr
      sp_unificacion_mock_r1_esc2_ciiu81_90_mismo_texto_padre_res_crr
      sp_unificacion_mock_r1_esc3_otros_ciiu_mayor_entidades_reportan
  R2: sp_unificacion_mock_r2_preparar_insumo
      sp_unificacion_mock_r2_esc1_complemento_vacio_esc2_substring_complemento
      sp_unificacion_mock_r2_esc3_sin_nit_misma_nomenclatura
      sp_unificacion_mock_r2_esc4_diccionario_frecuencia_complemento
      sp_unificacion_mock_r2_esc5_nomenclatura_menor_nivel_pierde
      sp_unificacion_mock_r2_esc6_frecuencia_complemento_gana
      sp_unificacion_mock_r2_motor_nit_empates_nuevas_direcciones
  R3: sp_unificacion_mock_r3_esc1_geo_misma_via_puerta_cercana

PROHIBIDO en esta corrida:
  - sp_unificacion_regla* / sp_unificacion_r*  (SIN la palabra mock)
  - bdm_tempo.v_xpm_* / edf_views
  - bdm_datos.unificacion_direccion  (salida real)
  - bdm_stage.sp_unificacion_* (legacy)

Validación:
  - Resultado en bdm_datos.unificacion_direccion_mock
  - Suite TC vía perf_persona_meta.scenario_code (TC-R1-01…08, TC-R2-01…14)
  - TC-R2-14 (R2_EMPATE): esperado 0 violaciones
    (Esc4 usa HAVING COUNT(*) = 1 — ganador único)
  - R3 mock CON geo (lat/long en seed): SÍ se prueba
```

---

## 3. Lista completa de objetos (checklist)

### 3.1 Vistas reales (`v_xpm_*`)
- `bdm_tempo.v_xpm_contacto_direccion`
- `bdm_tempo.v_xpm_relacion_persona_ubicacion`
- `bdm_tempo.v_xpm_ubicacion_estandarizada`
- `bdm_tempo.v_xpm_direccion_fisica`
- `bdm_tempo.v_xpm_reporte_relacion_persona_ubica`
- `bdm_tempo.v_xpm_ciiu_persona`

### 3.2 Vistas mock (`v_mock_*`)
- `bdm_tempo.v_mock_relacion_persona_ubicacion`
- `bdm_tempo.v_mock_ubicacion_estandarizada`
- `bdm_tempo.v_mock_direccion_fisica`
- `bdm_tempo.v_mock_reporte_relacion_persona_ubica`
- `bdm_tempo.v_mock_ciiu_persona`

### 3.3 Salidas
- Real: `bdm_datos.unificacion_direccion`
- Mock: `bdm_datos.unificacion_direccion_mock`

### 3.4 15 SPs reales (`bdm_datos`)
1. `sp_unificacion_r1_preparar_insumo`
2. `sp_unificacion_r1_esc1_ciiu10_mismo_texto_padre_lab_crr`
3. `sp_unificacion_r1_esc2_ciiu81_90_mismo_texto_padre_res_crr`
4. `sp_unificacion_r1_esc3_otros_ciiu_mayor_entidades_reportan`
5. `sp_unificacion_regla1`
6. `sp_unificacion_r2_preparar_insumo`
7. `sp_unificacion_r2_esc1_complemento_vacio_esc2_substring_complemento`
8. `sp_unificacion_r2_esc3_sin_nit_misma_nomenclatura`
9. `sp_unificacion_r2_esc4_diccionario_frecuencia_complemento`
10. `sp_unificacion_r2_esc5_nomenclatura_menor_nivel_pierde`
11. `sp_unificacion_r2_esc6_frecuencia_complemento_gana`
12. `sp_unificacion_r2_motor_nit_empates_nuevas_direcciones`
13. `sp_unificacion_regla2`
14. `sp_unificacion_r3_esc1_geo_misma_via_puerta_cercana`
15. `sp_unificacion_regla3`

### 3.5 15 SPs mock (`bdm_datos`) — mismos escenarios + `mock` en el nombre
1. `sp_unificacion_mock_r1_preparar_insumo`
2. `sp_unificacion_mock_r1_esc1_ciiu10_mismo_texto_padre_lab_crr`
3. `sp_unificacion_mock_r1_esc2_ciiu81_90_mismo_texto_padre_res_crr`
4. `sp_unificacion_mock_r1_esc3_otros_ciiu_mayor_entidades_reportan`
5. `sp_unificacion_mock_regla1`
6. `sp_unificacion_mock_r2_preparar_insumo`
7. `sp_unificacion_mock_r2_esc1_complemento_vacio_esc2_substring_complemento`
8. `sp_unificacion_mock_r2_esc3_sin_nit_misma_nomenclatura`
9. `sp_unificacion_mock_r2_esc4_diccionario_frecuencia_complemento`
10. `sp_unificacion_mock_r2_esc5_nomenclatura_menor_nivel_pierde`
11. `sp_unificacion_mock_r2_esc6_frecuencia_complemento_gana`
12. `sp_unificacion_mock_r2_motor_nit_empates_nuevas_direcciones`
13. `sp_unificacion_mock_regla2`
14. `sp_unificacion_mock_r3_esc1_geo_misma_via_puerta_cercana`
15. `sp_unificacion_mock_regla3`

---

## 4. Qué cambió vs el prompt viejo (legacy)

| Antes (obsoleto) | Ahora (vigente) |
|------------------|-----------------|
| Mock = `bdm_stage.sp_unificacion_regla*` | Mock = `bdm_datos.sp_unificacion_mock_*` |
| Salida mock en `bdm_stage.unificacion_direccion` | Salida mock = `bdm_datos.unificacion_direccion_mock` |
| SPs monolíticos R1/R2/R3 | SPs **divididos** por escenario + orquestador |
| Un solo path | Dos paths: `v_xpm_*` vs `v_mock_*` |
| TC-R2-14 sin fix documentado | Esc4: `HAVING COUNT(*) = 1` → esperado **0** |

---

## 5. Queries rápidas post-corrida

**Reales**
```sql
SELECT unifica_atributos, COUNT(*)
FROM bdm_datos.unificacion_direccion
GROUP BY 1 ORDER BY 1;

SELECT
  SUM(CASE WHEN cod_dw_direccion_unificada IS NULL THEN 1 ELSE 0 END) AS c03,
  SUM(CASE WHEN cod_dw_persona_ubic = cod_dw_direccion_unificada THEN 1 ELSE 0 END) AS c04
FROM bdm_datos.unificacion_direccion;
```

**Mock (conteo salida)**
```sql
SELECT unifica_atributos, COUNT(*)
FROM bdm_datos.unificacion_direccion_mock
GROUP BY 1 ORDER BY 1;
```

**TC-R2-14** (ajustar JOIN a `unificacion_direccion_mock` si la suite ya apunta a la salida nueva):
```sql
SELECT COUNT(*) AS violaciones
FROM bdm_stage.perf_persona_meta m
WHERE m.scenario_code = 'R2_EMPATE'
  AND EXISTS (
    SELECT 1
    FROM bdm_stage.relacion_persona_ubicacion r
    JOIN bdm_datos.unificacion_direccion_mock u
      ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic
     AND u.unifica_atributos = 2
    WHERE r.id_buro_persona = m.id_buro_persona
  );
-- esperado: 0
```

---

*Archivo para que QA ajuste prompts al diseño SPs divididos + DS (real / mock).*
