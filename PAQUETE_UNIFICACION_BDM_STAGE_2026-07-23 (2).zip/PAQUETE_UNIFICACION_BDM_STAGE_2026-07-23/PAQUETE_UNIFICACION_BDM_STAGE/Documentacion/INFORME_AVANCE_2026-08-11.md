# Informe de Avance — Unificación de Direcciones BDM

**Proceso:** PAQUETE_UNIFICACION_BDM_STAGE  
**Proyecto:** MT-EXP-005-MAP-RECONOCER  
**Ambiente:** Redshift `dba_batch` — develop + QA  
**Fecha informe:** 2026-08-11  
**Referencia técnica:** `Documentacion/ESTADO_COMPLETO_UNIFICACION_BDM.md`

---

## 1. De qué está hecho el paquete

El entregable es un **paquete SQL de unificación de direcciones (Reglas 1, 2 y 3)** compuesto por:

| Componente | Contenido |
|------------|-----------|
| **Lógica de negocio** | Reglas R1, R2 (escenarios 1–6) y R3 (geo), validadas en benchmark sintético |
| **SQL plano** | Scripts ejecutables sin SP (`02_unificacion_sql_plano.sql`) |
| **Stored procedures** | `sp_unificacion_regla1/2/3` + ejecución secuencial (`08`) |
| **Capa de lectura QA** | Vistas `bdm_tempo.v_xpm_*` que traducen XPM tokenizado → modelo BDM |
| **Fuentes develop/mock** | Esquema `bdm_stage` + benchmark 20K (`sql/`, `sql/benchmark_20k/`) |
| **Fuentes QA reales** | Esquema **`ifr_data`** — tablas `xpm_*` con campos tokenizados (`sql/qa_ifr_data/`) |
| **Salida** | Tabla `bdm_datos.unificacion_direccion` (QA) / `bdm_stage.unificacion_direccion` (develop) |
| **Documentación** | Mapping IFR, estado del proyecto, guías de instalación y validación |

**Origen de los datos en QA:** tablas Glue/XPM en **`ifr_data`**, no tablas BDM planas del MD. El paquete **mapea** desde:

- `ifr_data.xpm`
- `ifr_data.xpm_location`
- `ifr_data.xpm_location_val_contactinformations`
- `ifr_data.xpm_counterparties`

---

## 2. Actividades del periodo (2026-08-11)

### 2.1 Corrección del frente QA (`sql/qa_ifr_data/`)

- Fuente confirmada por equipo: **`ifr_data`** (campos tokenizados), no `edf_views`.
- Ajuste de nombres de columnas según catálogo real (`svv_external_columns`):
  - FK: `loc."location.val.contactinformations"` → `ci.id`
  - Tokenización: `ci."location.val.contactinformations.val.*"`
  - Reportes: `cp."counterparties.val.counterpartyidnumber"` + `loc."location.val.cutoffdate"`
- SPs R1/R2/R3 leen vistas `bdm_tempo.v_xpm_*` y escriben en `bdm_datos.unificacion_direccion`.

### 2.2 Validación en lectura (DBeaver QA — sin DDL)

Corrida exitosa de JOINs sobre `ifr_data` (2026-08-11):

| Paso | Métrica | Resultado |
|------|---------|----------:|
| Tablas base | `xpm` / `location` / `ci` / `counterparties` | 1052 / 1127 / 3773 / 1063 |
| JOIN contactos dirección | `06_join_contactos_direccion` | **1285** |
| JOIN reportes R1/R2 | `07_join_reportes_R1_R2` | **1897** |
| Con complemento (R2) | `09_con_complemento` | **130** |
| Con texto ubicación | `10_con_texto_ubicacion` | **607** |

**Conclusión:** mapping XPM → BDM **validado en lectura**. R1 debería correr; R2 parcial; R3 geo probablemente 0 (sin lat/long).

### 2.3 Pendiente operativo

- Despliegue vía **pipeline** (usuario sin permiso CREATE en QA): vistas, SPs y corrida `08`.
- Catálogos `tipo_ubicacion_dir` / `nomenclatura` — copia desde `bdm_stage` en `01_ddl`.

---

## 3. Resultados de ejecución (acumulado)

| Frente | Regla | Resultado |
|--------|-------|----------:|
| Benchmark 20K (`bdm_stage` sintético) | R1 / R2 / R3 | 1.800 / 7.200 / 600 — **Total 9.600** |
| Develop extracto real (`bdm_stage`) | R1 / R2 / R3 | 400 / 0 / 0 |
| QA `ifr_data` | Pipeline R1/R2/R3 | **No ejecutado** — mapping validado en SELECT |

---

## 4. Mapping validado QA

| Origen `ifr_data` | Destino lógico BDM | Vista / uso |
|-------------------|-------------------|-------------|
| `xpm` + `xpm_location` + `xpm_location_val_contactinformations` | `relacion_persona_ubicacion` | `bdm_tempo.v_xpm_relacion_persona_ubicacion` |
| Campos `location.val.contactinformations.val.standardized*` | `ubicacion_estandarizada` / `direccion_fisica` | `v_xpm_ubicacion_estandarizada`, `v_xpm_direccion_fisica` |
| `xpm` + `xpm_counterparties` + cutoff en location | `reporte_relacion_persona_ubica` | `v_xpm_reporte_relacion_persona_ubica` |
| `xpm.bestpersonalinformation.mainisiccodeforproduct` | `ciiu_persona` | `v_xpm_ciiu_persona` |
| Salida proceso | `unificacion_direccion` | `bdm_datos.unificacion_direccion` |

**Regla JOIN:** `relationalizelastupdate` en todos los JOINs XPM.

---

## 5. Pipeline propuesto (QA)

| # | Script |
|---|--------|
| 1 | `sql/qa_ifr_data/01_ddl_unificacion_direccion.sql` |
| 2 | `sql/qa_ifr_data/00_vistas_insumo_bdm.sql` |
| 3 | `sql/qa_ifr_data/00_validar_solo_lectura_ifr_data.sql` (gate) |
| 4 | `05` → `06` → `07` |
| 5 | `08_ejecucion_secuencial.sql` |
| 6 | `03_validaciones_unificacion.sql` |

---

## 6. Resumen ejecutivo

El paquete **PAQUETE_UNIFICACION_BDM_STAGE** está **hecho de SQL plano + stored procedures de unificación R1/R2/R3**, una **capa de vistas** que adapta el modelo XPM tokenizado de **`ifr_data`** al modelo BDM, más scripts de **validación, benchmark sintético 20K y documentación**.

| Tema | Estado |
|------|--------|
| Lógica R1/R2/R3 | Validada en sintético (**9.600**) |
| R1 develop real | Validada (**400**) |
| Mapping QA `ifr_data` → BDM | **Validado en lectura** (1285 contactos, 1897 reportes) |
| Corrida QA pipeline | **Pendiente** (permisos CREATE / despliegue) |
| R2 QA esperado | Parcial (~130 con complemento) |
| R3 QA esperado | Limitado (sin georreferenciación) |

**Avance global:** entregable técnico **completo en código**; frente QA con **mapping confirmado** contra catálogo real; falta **ejecución por pipeline** con rol autorizado.

---

*Informe actualizado 2026-08-11 — Unificación de Direcciones BDM Stage.*
