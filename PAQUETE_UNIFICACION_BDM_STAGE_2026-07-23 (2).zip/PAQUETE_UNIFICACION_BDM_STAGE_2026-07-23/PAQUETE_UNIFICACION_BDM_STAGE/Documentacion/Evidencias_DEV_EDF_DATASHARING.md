# Evidencias DEV EDF Datasharing
Fecha: 2026-09-01T14:42:25

## Preflight gaps
- PENDIENTE DBA productor: datashare ds_reconocer_procesosbatch_dev no visible

Namespace consumidor: `{'error': 'function pg_get_cluster_namespace() does not exist'}`

## Stages
- **preflight**: OK
- **prerequisitos**: OK
- **ddl**: OK
- **vistas**: OK
- **smoke**: OK
- **deploy_sp_r1**: OK
- **deploy_sp_r2**: OK
- **deploy_sp_r3**: OK
- **execute**: OK
- **validaciones**: OK

## Salida
```json
[
  {
    "unifica_atributos": 2,
    "n": 72448
  }
]
```
