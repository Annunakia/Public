> **Proyecto:** MT-EXP-005-MAP-RECONOCER  
> **Fuente confirmada:** `edf_views` (procesosbatch DEV) — **`ifr_data` no viable** (Spectrum/S3 + KMS)  
> **Actualizado:** 2026-08-26 — configuración validada Leonardo

---

## Resumen

Compartir **`edf_views`** desde **procesosbatch DEV** hacia **Reconocer Batch DEV** para ejecutar Unificación R1/R2/R3. Los SPs no cambian; las vistas en `sql/dev_edf_datasharing/` leen **`ds_dba_rncr_batch.edf_views.*`**.

**Conteos productor (edf_views):** xpm ~538K, xpm_ci ~2,35M. Tokenización en **`contacttype=8`**.

**Nota `ifr_data`:** tablas Spectrum en S3 cifradas con KMS → datashare falla con `kms:Decrypt` desde Reconocer. Alternativa documentada AWS (materialized views) no adoptada; se usa **`edf_views`**.

---

## Clusters

| Rol | Endpoint | Cuenta AWS | Database sesión |
|-----|----------|------------|-----------------|
| Productor | `eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com` | `651706752126` | `dba_batch` |
| Consumidor | `eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com` | `647096294147` | `dba_rncr_batch` |

**Datashare productor:** `ds_reconocer_procesosbatch_dev` (schema `edf_views`, 34 tablas)  
**BD compartida consumidor:** `ds_dba_rncr_batch` (no puede llamarse `dba_rncr_batch` — ya existe local)  
**Usuario pipeline:** `c32525e`

Consulta ejemplo: `SELECT COUNT(*) FROM ds_dba_rncr_batch.edf_views.xpm;`

---

## SQL DBA

| Lado | Archivo |
|------|---------|
| Productor | `sql/dev_edf_datasharing/00_datashare_producer.sql` |
| Consumidor montaje | `sql/dev_edf_datasharing/00_datashare_consumer.sql` |
| Consumidor grants | `sql/dev_edf_datasharing/00_grants_dba_reconocer.sql` |

---

## Criterio de aceptación

Desde consumidor (`c32525e`, BD `dba_rncr_batch`):

```sql
SELECT COUNT(*) FROM ds_dba_rncr_batch.edf_views.xpm;           -- > 500000
SELECT COUNT(*) FROM ds_dba_rncr_batch.edf_views.xpm_location;  -- > 0
```

Equipo ejecuta:

```powershell
$env:REDSHIFT_CONSUMER_PASSWORD="..."
$env:REDSHIFT_PRODUCER_PASSWORD="..."
py -3 tools/dev_edf_datasharing_run.py --preflight-only
py -3 tools/dev_edf_datasharing_run.py
```

Gate smoke: `06_join_contactos_tipo_8` > 400000 en `00_validar_solo_lectura_edf_views.sql`.

---

## Estado (2026-08-26)

Configuración DBA **completada** por Leonardo. Paquete reapuntado a `ds_dba_rncr_batch`. Pendiente: despliegue vistas + SPs + unificación end-to-end en consumidor.

---

*Prueba local productor (sin datashare): `tools/dev_edf_views_run.py` — R2 ~72K OK.*
