# Mapa mental — Unificación R1/R2/R3 (edf_views DEV real)

**Entorno:** Reconocer consumidor · datashare `ds_dba_rncr_batch.edf_views`  
**Corrida referencia:** 2026-08-26 · `tools/dev_edf_datasharing_run.py`  
**Fuente numérica:** `Evidencias_DEV_EDF_VALIDACIONES.md`, `Evidencias_DEV_R2_ESCENARIOS_AUDIT.md`, diagnósticos SQL sesión 2026-08-27

**Excel negocio (editable):**
- `Documentacion/MAPA_UNIFICACION_EDF_VIEWS_NEGOCIO_DETALLADO.xlsx` — drill-down con expectativa, hallazgos, ejemplos y query ID
- Queries SQL: `sql/dev_edf_datasharing/00_drill_down_validaciones.sql`
- Regenerar: `py -3 tools/export_mapa_unificacion_xlsx.py`

---

## 1. Universo inicial — ¿591k qué?

| Pregunta negocio | Respuesta exacta |
|------------------|------------------|
| ¿591.166 son personas? | **No.** Son **RPUs** (Relación Persona-Ubicación): 1 contacto-dirección XPM = 1 fila. |
| ¿Cuántas personas? | **407.351** personas distintas (`id_buro_persona`). |
| ¿Cuántas direcciones físicas únicas? | **588.528** ubicaciones (`cod_dw_ubic`); textos repetidos entre personas. |
| Promedio RPUs / persona | **1,45** (591.166 ÷ 407.351) |

### Desglose por modelo edf_views (contacttype crudo)

| Contacttype IFR | Significado | RPUs | % del universo |
|:---------------:|-------------|-----:|---------------:|
| **8** | Dirección **tokenizada** (modelo edf DEV) → se mapea a tipo CRR (3) | **585.732** | **99,08%** |
| **1** | RES — residencia | **2.279** | 0,39% |
| **3** | CRR — correspondencia (nativo, no token) | **1.873** | 0,32% |
| **2** | LAB — laboral | **1.282** | 0,22% |
| **7** | DIR clásico IFR | **0** | 0% |
| **Total** | | **591.166** | **100%** |

> **Corrección frecuente:** los **5.434** (tipos 1/2/3) **no son “salida R1”**. R1 produjo **0**. Es solo el remanente IFR clásico dentro del universo.

---

## 2. Vista de árbol (mapa mental)

```text
591.166 RPUs  (407.351 personas)
│
├─ REGla 1 — Mismo texto + ciudad, TIPOS DISTINTOS, gana score CIIU
│   ├─ Candidatos multitipo: 2.074 grupos · 231.546 RPUs involucradas
│   ├─ ESC1 (CIIU=10): padre LAB/CRR vs hijo otro tipo → UNIFICADAS: 0
│   ├─ ESC2 (CIIU 81/82/90): padre RES/CRR vs hijo otro tipo → 0
│   ├─ ESC3 (otros CIIU): gana quien más entidades reporta → 0
│   └─ ESC4 EMPATE: 1.895 particiones · 100% empate · ganador único: 0 → BLOQUEO TOTAL R1
│
├─ REGla 2 — Mismo texto + MISMO tipo, lógica COMPLEMENTO
│   ├─ ESC1: padre CON complemento / hija SIN → 72.448 hijas  ★ 100% de R2
│   ├─ ESC2: complemento contenido en otro → 0
│   ├─ ESC3: diccionario nomenclatura (no NIT) → 0
│   ├─ ESC4: frecuencia diccionario complementos → 0
│   ├─ ESC5: nivel nomenclatura → 0
│   ├─ ESC6: empate frecuencia → 0
│   └─ Motor direcciones (NIT): 9 filas staging · 0 en salida
│
└─ REGla 3 — Cercanía vía/puerta + GEO obligatoria
    ├─ Insumo: 591.166 RPUs
    ├─ Con latitud: 0
    └─ UNIFICADAS: 0  (pendiente ArcGIS / Experian GEO)
```

---

## 3. Waterfall — ¿Dónde queda cada RPU?

| Etapa | RPUs unificadas (hijas) | RPUs que siguen “libres” | Acumulado ganadoras |
|-------|------------------------:|-------------------------:|--------------------:|
| Inicio | — | 591.166 | 591.166 |
| Post-R1 | **0** | 591.166 | 591.166 |
| Post-R2 | **72.448** | 518.718 | 518.718 |
| Post-R3 | **0** | 518.718 | **518.718 ganadoras finales** |

| Métrica salida | Valor |
|----------------|------:|
| Total filas `unificacion_direccion` | 72.448 |
| Solo regla 2 | 72.448 |
| Padres distintos R2 | 72.445 |
| Integridad hijos sin padre | 0 |
| Autoreferencia | 0 |

---

## 4. REGLA 1 — Detalle por escenario (negocio)

### ¿Qué intenta R1?

Unificar direcciones de la **misma persona**, **misma dirección escrita**, **misma ciudad**, pero **distinto tipo de uso** (RES vs LAB vs CRR), eligiendo un **padre ganador** según actividad económica (CIIU).

### Condiciones obligatorias (todas)

1. Mismo `id_buro_persona` + `texto_ubicacion` + `cod_dw_ciudad`
2. **Distinto** `cod_dw_tipo_ubicacion_dir` (ej. RES=1 vs CRR=3)
3. Ganador con **score máximo único** (sin empate)
4. Padre = fila con mejor score; hijas = resto del grupo

### Tabla drill-down R1 (números exactos DEV)

| Escenario | Regla de negocio | Padre gana si… | Particiones evaluadas | Unificadas (hijas) | ¿Por qué 0? |
|-----------|------------------|----------------|----------------------:|-------------------:|-------------|
| **R1-ESC1** | Persona CIIU **10** (comercio) | Tipo **LAB o CRR** (+100.000 pts) + entidades reportan | Parte de 1.895 | **0** | LAB y CRR empatan mismo score |
| **R1-ESC2** | Persona CIIU **81 / 82 / 90** | Tipo **RES o CRR** (+100.000 pts) + entidades reportan | Parte de 1.895 | **0** | RES y CRR empatan mismo score |
| **R1-ESC3** | Otros CIIU | Solo gana mayor `# entidades reportan` | Parte de 1.895 | **0** | Mismo # reportes → empate |
| **R1-ESC4 EMPATE** | Desempate | Requiere **1 solo** ganador en score máx | **1.895** | **0** | **100% empates** (0 ganadores únicos) |
| **TOTAL R1** | | | | **0** | |

### Sub-universo R1 (candidatos vs bloqueo)

| Nivel | Métrica | Valor | Interpretación negocio |
|-------|---------|------:|------------------------|
| A | RPUs totales | 591.166 | Universo |
| B | Grupos multitipo (misma pers.+texto+ciudad, >1 tipo) | **2.074** | “En papel” podrían entrar a R1 |
| C | RPUs dentro de grupos multitipo | **231.546** | 39% del universo toca un grupo candidato |
| D | Particiones CIIU+texto+ciudad con empate | **1.895** | Motor no puede decidir padre |
| E | Ganadores únicos | **0** | **Cuello de botella confirmado** |
| F | **Salida unificación R1** | **0** | |

### Ejemplo concreto de empate (ESC2)

```
Persona con CIIU 81, misma dirección "CL 84 # 10-20":
  RPU-A  tipo RES  → score = 100.000 + 3 reportes = 100.003
  RPU-B  tipo CRR  → score = 100.000 + 3 reportes = 100.003
  → EMPATE → R1 no unifica (política R1_EMPATE)
```

### Relación con los 5.434 contacttype 1/2/3

| Hecho | Valor |
|-------|------:|
| RPUs nativas 1/2/3 | 5.434 |
| Participan en grupos multitipo | Subconjunto de 231.546 |
| Generaron unificación R1 | **0** |
| Motivo | No es por “ser pocos”; es porque **incluso donde hay multitipo, siempre empatan** |

---

## 5. REGLA 2 — Detalle por escenario (negocio)

### ¿Qué intenta R2?

Unificar RPUs de la **misma persona**, **misma dirección base**, **mismo tipo de uso**, cuando difieren por **complemento** (apto, oficina, local, etc.).

**Orden secuencial:** ESC1 → ESC2 → … → ESC6 → Motor. Cada escenario solo ve RPUs aún **no unificadas**.

### Tabla drill-down R2 (números exactos DEV)

| Escenario | Regla de negocio | Sub-escenario | Lógica padre/hija | Hijas unificadas | % R2 |
|-----------|------------------|---------------|-------------------|----------------:|-----:|
| **R2-ESC1** | Complemento informado vs vacío | **Sub-E1:** padre tiene complemento (`AP 601`, `OF 302`…), hija no | Padre = con complemento · Hija = sin complemento · **Mismo tipo_dir** | **72.448** | **100%** |
| **R2-ESC2** | Complemento más completo | Sub-E2: complemento A contiene a B | Padre = complemento más largo | **0** | 0% |
| **R2-ESC3** | Diccionario nomenclatura | Misma nomenclatura (AP, OF, LC…) distintos números | Solo no-NIT · Gana ID compuesto mayor | **0** | 0% |
| **R2-ESC4** | Frecuencia en diccionario | Gana complemento más frecuente por persona | Excluye empates frecuencia | **0** | 0% |
| **R2-ESC5** | Nivel nomenclatura | Gana nivel jerárquico superior | Catálogo `nomenclatura` | **0** | 0% |
| **R2-ESC6** | Empate frecuencia | Desempate por reglas motor | — | **0** | 0% |
| **Motor** | NIT — dirección enriquecida sintética | Esc3/5/6 motor batch | `generada_enriquecida=1` | **0** en salida* | 0% |
| **TOTAL R2** | | | | **72.448** | **100%** |

\*Motor generó **9 filas** staging para **1 persona NIT**; **ninguna** insertada en `unificacion_direccion`.

### Muestras reales R2-ESC1 (audit DEV)

| Dirección base | Tipo | Complemento hija | Complemento padre |
|----------------|------|--------------------|-------------------|
| `CL 84 C # 9 - 51 AP 601` | CRR | *(vacío)* | `AP 601` |
| `KR 7 # 75 - 51 OF 302` | CRR | *(vacío)* | `OF 302` |
| `KR 9 C # 121 - 53 AP 502 B` | CRR | *(vacío)* | `AP 502 B` |

### ¿De dónde salen los 72.448?

| Origen | RPUs aprox. | Nota |
|--------|------------:|------|
| Contacttype **8 → CRR** | ~72k (casi total) | Tokenización trae texto+complemento en cadena |
| Contacttype **1/2/3 nativo** | ~0 en salida | Sin patrón complemento vacío / con complemento |
| **No confundir** | 5.434 ≠ 72.448 | 5.434 = universo IFR legado; 72k = patrón complemento tipo 8 |

### RPUs que NO entraron a R2

| Concepto | RPUs |
|----------|-----:|
| Universo inicial | 591.166 |
| Unificadas R2 (hijas) | 72.448 |
| **Sin unificación R2** | **518.718** |
| Motivos típicos | Sin par complemento; dirección única; sin duplicado misma base |

---

## 6. REGLA 3 — Detalle (negocio)

### ¿Qué intenta R3?

Unificar direcciones de la **misma persona** en el **mismo municipio**, con **misma vía** (tokens 1-2 del texto), **número de puerta/vía generadora ±1 o ±2**, cuando el padre tiene **más entidades reportando** — **solo si hay coordenadas GEO**.

### Tabla drill-down R3

| Escenario | Regla | Requisito GEO | RPUs con latitud | Unificadas |
|-----------|-------|---------------|-----------------:|-----------:|
| **R3-ESC único** | Puerta/vía ±2 + más reportes | **latitud NOT NULL ambos** | **0** de 591.166 | **0** |
| **Bloqueo** | — | edf_views no expone coordenadas | 100% NULL | — |

### Justificación funcional (celda “Por qué”)

> **0 unificaciones — Racional:** No tenemos aún latitud/longitud en el insumo edf_views. Proyecto **GEO + ArcGIS** en curso (Experian). Sin geo, el filtro `WHERE latitud IS NOT NULL` elimina el 100% de candidatos antes de evaluar cercanía.

### Qué pedir a Experian / datos

| Dato | Para qué regla | Estado |
|------|----------------|--------|
| `latitud` / `longitud` en XPM o capa GEO | R3 | Pendiente |
| Consistencia tokenización tipo 8 | R2 | OK (72k) |
| Catálogo CIIU / sector | R1 scoring | Parcial (`mainisiccodeforproduct`) |
| Desempate R1 o scores asimétricos | R1 > 0 en edf real | Decisión negocio |

---

## 7. ¿La lógica está bien implementada?

| Pregunta | Respuesta |
|----------|-----------|
| ¿Apuntamiento edf_views OK? | **Sí** — paridad productor/consumidor; R2=72.448 alineado |
| ¿R1=0 es bug? | **No** — empate 100% en 1.895 particiones; política `R1_EMPATE` |
| ¿R3=0 es bug? | **No** — geo NULL documentado |
| ¿R2=72k responde a negocio? | **Sí** — Esc1 complemento; audit con muestras reales |
| ¿Suite mock 20k? | R1=1.401 · R2=6.002 — valida lógica con **datos diseñados** distintos a edf real |

---

## 8. Plantilla Excel (copiar columnas)

| Drill down Reglas | Descomponer escenario | Subescenario | Cantidades | Por qué / Justificación funcional |
|-------------------|----------------------|--------------|------------|-------------------------------------|
| **UNIVERSO** | RPUs insumo | Total | **591.166** | Contactos dirección XPM (no personas) |
| UNIVERSO | Personas | Distintas | **407.351** | PIN hash |
| UNIVERSO | Contacttype 8 | Tokenizado | **585.732** | 99% del universo |
| UNIVERSO | Contacttype 1/2/3 | IFR legado | **5.434** | No es salida R1 |
| **R1** | Candidatos multitipo | Grupos | **2.074** | Misma dir.+ciudad, >1 tipo |
| R1 | Candidatos multitipo | RPUs en grupos | **231.546** | 39% universo |
| R1 | ESC1 | CIIU=10 | **0** | Empate LAB/CRR |
| R1 | ESC2 | CIIU 81/82/90 | **0** | Empate RES/CRR |
| R1 | ESC3 | Otros CIIU | **0** | Empate # reportes |
| R1 | ESC4 | Empate | **1.895 particiones** | 0 ganadores únicos |
| R1 | **TOTAL** | | **0** | |
| **R2** | ESC1 Sub-E1 | Comp. sí / no | **72.448** | 100% R2 real |
| R2 | ESC2 Sub-E2 | Comp. contenido | **0** | Ya absorbió ESC1 |
| R2 | ESC3 | Nomenclatura | **0** | Sin remanentes |
| R2 | ESC4 | Frecuencia dic. | **0** | |
| R2 | ESC5 | Nivel nom. | **0** | |
| R2 | ESC6 | Empate freq. | **0** | |
| R2 | Motor NIT | Staging | **9** (0 salida) | No INSERT unificación |
| R2 | **TOTAL** | | **72.448** | |
| R2 | No unificadas | Remanente | **518.718** | Sin par complemento |
| **R3** | GEO | Con latitud | **0** | Pendiente ArcGIS |
| R3 | **TOTAL** | | **0** | |

---

## 9. Referencias técnicas

- Vistas: `sql/dev_edf_datasharing/00_vistas_insumo_bdm.sql`
- SPs: `sql/qa_ifr_data/05_sp_regla1.sql`, `06_sp_regla2.sql`, `07_sp_regla3.sql`
- Audit R2: `Documentacion/Evidencias_DEV_R2_ESCENARIOS_AUDIT.md`
- Suite negocio mock: `Documentacion/Evidencias_Suite_R1_R2_DEV.md`
