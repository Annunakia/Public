-- Personas que ENTRAN a regla 1 (R1) — DEV dba_rncr_batch
-- Criterio: misma calle + misma ciudad con al menos 2 usos distintos (RES/LAB/CRR)
-- Resultado esperado: 156 personas · 2.441 RPUs (según drill-down validado)
-- Ejecutar en Redshift (consumidor Reconocer DEV)

WITH ubi1 AS (
  SELECT cod_dw_ubic, texto_ubicacion, cod_dw_ciudad
  FROM bdm_tempo.v_xpm_ubicacion_estandarizada
  GROUP BY 1, 2, 3
),
grupos AS (
  SELECT rpu.id_buro_persona, ubi.texto_ubicacion, ubi.cod_dw_ciudad
  FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
  JOIN ubi1 ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  GROUP BY 1, 2, 3
  HAVING COUNT(DISTINCT rpu.cod_dw_tipo_ubicacion_dir) > 1
)
SELECT
  g.id_buro_persona,
  MAX(rpu.cod_pin_persona) AS cod_pin_persona,
  COUNT(DISTINCT g.texto_ubicacion || '|' || g.cod_dw_ciudad::VARCHAR) AS calles_r1,
  COUNT(DISTINCT rpu.cod_dw_persona_ubic) AS rpus_r1,
  ROUND(
    COUNT(DISTINCT rpu.cod_dw_persona_ubic)::DECIMAL
    / NULLIF(COUNT(DISTINCT g.texto_ubicacion || '|' || g.cod_dw_ciudad::VARCHAR), 0),
    2
  ) AS rpus_por_calle
FROM grupos g
JOIN bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
  ON rpu.id_buro_persona = g.id_buro_persona
JOIN ubi1 ubi
  ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
 AND ubi.texto_ubicacion = g.texto_ubicacion
 AND ubi.cod_dw_ciudad = g.cod_dw_ciudad
GROUP BY 1
ORDER BY rpus_r1 DESC, g.id_buro_persona;
