# Evidencias Ordenamiento Fase 1 — datashare edf_views

Fecha: 2026-08-26  
Entorno: Reconocer DEV / `dba_rncr_batch` / `ds_dba_rncr_batch`

---

## Pipeline ejecutado

```powershell
py -3 tools/dev_edf_ordenamiento_run.py
```

| Stage | Resultado |
|-------|-----------|
| DDL ordenamiento | OK |
| Betas (47 filas snapshot) | OK |
| Vistas contacto canal | OK |
| Materializar RPU post-unificación | OK |
| SP `sp_ordenamiento_preparar_insumos_edf` | OK |
| CALL preparar insumos | OK (~35 s) |

---

## Materialización RPU

| Métrica | Valor |
|---------|------:|
| RPU total | 591.166 |
| **Ganadoras** (`ind_unificacion <> 1`) | **518.718** |
| Hijas unificación R2 | 72.448 |
| Personas con DIR ganadora | 407.351 |

Coherente con unificación: 591.166 − 72.448 = 518.718 ✓

---

## Insumos generados (edf_views real)

| Insumo | Filas | Personas |
|--------|------:|---------:|
| **DIR** | **1.055.905** | 407.351 |
| **TEL** (types 4/5/8) | 627.934 | 407.320 |
| **EMA** (type 10) | 605.998 | 407.207 |
| **CEL** (type 9) | 17.240 | 115 |

Notas:
- DIR ≈ 2 reportes/RPU ganadora (join 1:1 contacto + reporte).
- EMA/TEL abundantes en edf_views DEV (type 10 ~587K contactos raw).
- CEL escaso en DEV real (type 9 ~1.165 contactos raw → 115 personas con ganadora DIR).

---

## Fix aplicado

Join inicial `ubi × reporte` por `cod_dw_ubic` generaba **29M** filas (producto cartesiano).  
Corregido usando `v_xpm_contacto_direccion` 1:1 por `cod_dw_persona_ubic`.

---

## Pendiente Fase 2

1. Desplegar SPs scoring (`sql/ordenamiento/11`–`16`) en consumidor
2. Adaptar tipos `BIGINT` en SPs si hace falta
3. `CALL sp_ordenamiento_scoring_*` + consolidación
4. Validar `score_ordenamiento` + `orden_prioridad`
5. Catálogo oficial `sector_financiero` (hoy mock `>= 901`)

---

## Archivos nuevos

- `sql/dev_edf_ordenamiento/*`
- `tools/dev_edf_ordenamiento_run.py`
