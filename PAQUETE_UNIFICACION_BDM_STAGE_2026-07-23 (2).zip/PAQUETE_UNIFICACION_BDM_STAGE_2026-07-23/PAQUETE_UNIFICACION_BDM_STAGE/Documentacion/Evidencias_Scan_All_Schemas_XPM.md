# Scan todos los schemas — tablas XPM/Alpha
## productor_dev / `dba_batch`
```json
{
  "label": "productor_dev",
  "host": "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com",
  "database": "dba_batch",
  "exact": {
    "xpm": [
      {
        "schema": "bdm_tempo",
        "type": "BASE TABLE"
      },
      {
        "schema": "edf_masking",
        "type": "BASE TABLE"
      },
      {
        "schema": "edf_stage",
        "type": "BASE TABLE"
      },
      {
        "schema": "edf_views",
        "type": "BASE TABLE"
      }
    ],
    "xpm_counterparties": [
      {
        "schema": "edf_masking",
        "type": "BASE TABLE"
      },
      {
        "schema": "edf_stage",
        "type": "BASE TABLE"
      },
      {
        "schema": "edf_views",
        "type": "BASE TABLE"
      }
    ],
    "xpm_location": [
      {
        "schema": "edf_masking",
        "type": "BASE TABLE"
      },
      {
        "schema": "edf_stage",
        "type": "BASE TABLE"
      },
      {
        "schema": "edf_views",
        "type": "BASE TABLE"
      }
    ],
    "xpm_location_val_contactinformations": [
      {
        "schema": "edf_masking",
        "type": "BASE TABLE"
      },
      {
        "schema": "edf_stage",
        "type": "BASE TABLE"
      },
      {
        "schema": "edf_views",
        "type": "BASE TABLE"
      }
    ]
  },
  "errors": [],
  "session": {
    "db": "dba_batch",
    "u": "c32525e"
  },
  "schema_count": 15,
  "counts": {
    "bdm_tempo.xpm": 89165,
    "edf_masking.xpm": "ERR: permission denied for schema edf_masking",
    "edf_stage.xpm": 776,
    "edf_views.xpm": 538235,
    "edf_masking.xpm_counterparties": "ERR: permission denied for schema edf_masking",
    "edf_stage.xpm_counterparties": 800,
    "edf_views.xpm_counterparties": 419506,
    "edf_masking.xpm_location": "ERR: permission denied for schema edf_masking",
    "edf_stage.xpm_location": 815,
    "edf_views.xpm_location": 599394,
    "edf_masking.xpm_location_val_contactinformations": "ERR: permission denied for schema edf_masking",
    "edf_stage.xpm_location_val_contactinformations": 171,
    "edf_views.xpm_location_val_contactinformations": 2353389
  },
  "token_cols": {
    "edf_views.xpm_location_val_contactinformations": [
      "location.val.contactinformations.val.standardizedmunicipality",
      "location.val.contactinformations.val.standardizedtipo",
      "location.val.contactinformations.val.contactasreportedstandardized",
      "location.val.contactinformations.val.standardizeddepartment",
      "location.val.contactinformations.val.standardizedviaprincipal"
    ]
  },
  "external_schemas": [
    {
      "esoid": "esoid",
      "eskind": "eskind",
      "schemaname": "schemaname",
      "esowner": "esowner",
      "databasename": "databasename",
      "esoptions": "esoptions"
    },
    {
      "esoid": "esoid",
      "eskind": "eskind",
      "schemaname": "schemaname",
      "esowner": "esowner",
      "databasename": "databasename",
      "esoptions": "esoptions"
    },
    {
      "esoid": "esoid",
      "eskind": "eskind",
      "schemaname": "schemaname",
      "esowner": "esowner",
      "databasename": "databasename",
      "esoptions": "esoptions"
    },
    {
      "esoid": "esoid",
      "eskind": "eskind",
      "schemaname": "schemaname",
      "esowner": "esowner",
      "databasename": "databasename",
      "esoptions": "esoptions"
    },
    {
      "esoid": "esoid",
      "eskind": "eskind",
      "schemaname": "schemaname",
      "esowner": "esowner",
      "databasename": "databasename",
      "esoptions": "esoptions"
    },
    {
      "esoid": "esoid",
      "eskind": "eskind",
      "schemaname": "schemaname",
      "esowner": "esowner",
      "databasename": "databasename",
      "esoptions": "esoptions"
    },
    {
      "esoid": "esoid",
      "eskind": "eskind",
      "schemaname": "schemaname",
      "esowner": "esowner",
      "databasename": "databasename",
      "esoptions": "esoptions"
    }
  ],
  "external_tables": [
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    },
    {
      "schemaname": "schemaname",
      "tablename": "tablename"
    }
  ],
  "external_counts": {
    "ifr_data.xpm": 144,
    "ifr_data.xpm_location": 133
  }
}
```

Prefixed xpm tables (150): first 30
- `bdm_datos.dq_all_sources_20250527_1523_xpm`
- `bdm_datos.dq_all_sources_20250527_1523_xpm_counterparties`
- `bdm_datos.dq_all_sources_20250527_1523_xpm_location`
- `bdm_datos.dq_all_sources_20250527_1523_xpm_location_val_contactinformations`
- `bdm_datos.dq_allfuentes_pers_inf_name_identif_20250529_1459_xpm`
- `bdm_datos.dq_allfuentes_pers_inf_name_identif_20250529_1459_xpm_counterparties`
- `bdm_datos.dq_allfuentes_pers_inf_name_identif_20250529_1459_xpm_location`
- `bdm_datos.dq_allfuentes_pers_inf_name_identif_20250529_1459_xpm_location_val_contactinformations`
- `bdm_datos.dq_bdacsv_20250522_1154_xpm`
- `bdm_datos.dq_bdacsv_20250522_1154_xpm_counterparties`
- `bdm_datos.dq_bdacsv_20250522_1154_xpm_location`
- `bdm_datos.dq_bdacsv_20250522_1154_xpm_location_val_contactinformations`
- `bdm_datos.dq_bdacsv_20250523_1642_xpm`
- `bdm_datos.dq_bdacsv_20250523_1642_xpm_counterparties`
- `bdm_datos.dq_bdacsv_20250523_1642_xpm_location`
- `bdm_datos.dq_bdacsv_20250523_1642_xpm_location_val_contactinformations`
- `bdm_datos.dq_bdacsv_regis_dian_das_20250523_1652_xpm`
- `bdm_datos.dq_bdacsv_regis_dian_das_20250523_1652_xpm_counterparties`
- `bdm_datos.dq_bdacsv_regis_dian_das_20250523_1652_xpm_location`
- `bdm_datos.dq_bdacsv_regis_dian_das_20250523_1652_xpm_location_val_contactinformations`
- `bdm_datos.dq_bdidas_20250522_0953_xpm`
- `bdm_datos.dq_bdidas_20250522_0953_xpm_counterparties`
- `bdm_datos.dq_bdidas_20250522_0953_xpm_location`
- `bdm_datos.dq_bdidas_20250522_0953_xpm_location_val_contactinformations`
- `bdm_datos.dq_bdidian_20250522_1041_xpm`
- `bdm_datos.dq_bdidian_20250522_1041_xpm_counterparties`
- `bdm_datos.dq_bdidian_20250522_1041_xpm_location`
- `bdm_datos.dq_bdidian_20250522_1041_xpm_location_val_contactinformations`
- `bdm_datos.dq_bdiiale_regis_dian_das_bdacsv_20250523_1057_xpm`
- `bdm_datos.dq_bdiiale_regis_dian_das_bdacsv_20250523_1057_xpm_counterparties`
## reconocer_dev / `dba`
```json
{
  "label": "reconocer_dev",
  "host": "eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com",
  "database": "dba",
  "exact": {},
  "errors": [],
  "session": {
    "db": "dba",
    "u": "c32525e"
  },
  "schema_count": 1,
  "counts": {},
  "token_cols": {},
  "external_schemas": [],
  "external_tables": [],
  "external_counts": {
    "ifr_data.xpm": "ERR: schema \"ifr_data\" does not exist",
    "ifr_data.xpm_location": "ERR: schema \"ifr_data\" does not exist"
  }
}
```
## reconocer_dba_reconocerbatch / `dba_reconocerbatch`
```json
{
  "label": "reconocer_dba_reconocerbatch",
  "host": "eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com",
  "database": "dba_reconocerbatch",
  "exact": {},
  "errors": [],
  "session": {
    "db": "dba_reconocerbatch",
    "u": "c32525e"
  },
  "schema_count": 0,
  "counts": {},
  "token_cols": {},
  "external_schemas": [],
  "external_tables": [],
  "external_counts": {
    "ifr_data.xpm": "ERR: schema \"ifr_data\" does not exist",
    "ifr_data.xpm_location": "ERR: schema \"ifr_data\" does not exist"
  }
}
```
