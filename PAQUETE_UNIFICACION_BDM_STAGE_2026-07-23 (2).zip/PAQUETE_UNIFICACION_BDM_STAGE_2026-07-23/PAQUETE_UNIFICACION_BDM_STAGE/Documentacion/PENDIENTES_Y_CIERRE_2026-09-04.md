# Pendientes y cierre — 2026-09-04

Documento de referencia: **qué quedó hecho por el equipo técnico** vs **qué depende de terceros** (Experian, DBA, aprobadores PR, pipeline).

---

## 1. Hecho (nuestro alcance — cerrado en DEV)

### Unificación (`edf_views` → consumidor Reconocer)

| Item | Estado | Evidencia |
|------|--------|-----------|
| 15 SPs por escenario + orquestadores R1/R2/R3 | OK | `Evidencias_QA_UNIFICACION_ESCENARIOS_DEV.md` |
| QA DEV: R2=72.448, C03/C04=0, 591.166 RPU | PASS | `Evidencias_EJECUCION_PIPELINE_DEV.md` |
| Artefactos Bitbucket unificación | En rama `feature/unificacion-edf-views` | PRs abiertos (_strct #2, _pgm #2, _dt #6) |
| Mapa HTML unificación | Generado | `MAPA_MENTAL_UNIFICACION_EDF_VIEWS_NEGOCIO.html` |

### Ordenamiento (`edf_views` → consumidor Reconocer)

| Item | Estado | Evidencia |
|------|--------|-----------|
| Pipeline Fase 1 + Fase 2 (scoring + consolidación) | OK | `Evidencias_DEV_ORDENAMIENTO_EDF_COMPLETO.md` |
| Corrección fórmulas TEL/EMA/CEL vs Teradata v2.0 | OK | `Evidencias_ORDENAMIENTO_FORMULAS_DEV.md` |
| 1.223.998 scores; 408.624 RPUs con `orden_prioridad` | PASS | mismo |
| Artefactos `deploy_bitbucket/` + sync repos | OK | `tools/sync_*_ordenamiento.py` |
| Rama `feature/ordenamiento` — commit + push | OK | commits 2026-09-04 en los 3 repos |
| Mapa HTML ordenamiento | Generado | `MAPA_ORDENAMIENTO_EDF_VIEWS_NEGOCIO.html` |

### Mapping IFR/XPM (QA lectura)

| Item | Estado | Evidencia |
|------|--------|-----------|
| JOINs y columnas SPs 05/06/07 | 9/10 OK | `Evidencias_Joins_SPs_QA_IFR.md` |
| Vistas `WITH NO SCHEMA BINDING` | Código listo | `sql/qa_ifr_data/00_vistas_insumo_bdm.sql` |

---

## 2. Pendiente nuestro (acción rápida posible)

| # | Acción | Notas |
|---|--------|-------|
| 1 | **Abrir PRs ordenamiento** en Bitbucket | Rama `feature/ordenamiento` ya en remoto; orden _strct → _pgm → _dt |
| 2 | **Seguimiento PRs unificación** | Aprobar/merge cuando revisores respondan |
| 3 | **Retirar mock SLCOPRBA-1147** del master | Acordado en `GUIA_REORGANIZACION_TRES_REPOS_UNIFICACION.md` — requiere PR a master post-merge |
| 4 | **Entrega QA Ordenamiento** | Listo: `ENTREGA_QA_ORDENAMIENTO.md` (2026-09-16) — espejo de unificación |
| 5 | **Cargar betas RITM + re-correr scoring DEV** | **Hecho en productor DEV** 2026-09-16 (`Evidencias_BETAS_RITM_SCORING_2026-09-16.md`). Consumidor: falta password/grants `bdm_datos` |

*Última actualización doc pendientes: 2026-09-16 (añadida entrega QA ordenamiento).*

---

## 3. Pendiente externo (no depende de nosotros)

### Bitbucket / governance

| Responsable | Pendiente |
|-------------|-----------|
| Revisores | Aprobación y merge PRs unificación y ordenamiento |
| Equipo | Revocar token Bitbucket al cierre del proyecto (pospuesto por usuario) |

### DBA / infraestructura

| Responsable | Pendiente |
|-------------|-----------|
| DBA productor | Publicar datashares (`ds_reconocer_procesosbatch_dev`, `ds_reconocer_ifr_dev`) |
| DBA / pipeline | Rol batch con `CREATE` en `bdm_tempo` / `bdm_datos` en QA |
| Pipeline | Deploy vistas `bdm_tempo.v_xpm_*` + SPs + ejecución orquestada |
| Carga catálogos | Fila `tipo_ubicacion_dir` código **7 = DIR** en QA/prod |

### Experian / datos

| Responsable | Pendiente |
|-------------|-----------|
| Experian / IFR | Datashare continuo `v_beta_ordenamiento_*` (opcional) — **snapshot RITM5226589 ya cargado** en `bdm_datos.beta_ordenamiento` (`BETAS_ORDENAMIENTO_RITM5226589.md`) |
| Experian | Georreferenciación (lat/long, ArcGIS) para R3 geo y DIR unificadas |
| Experian | Definición flag `bloqueado` (reclamaciones) |
| Experian | Confirmar regla `id_buro_persona` (`FNV_HASH(pin)` vs pipeline BDM) |
| Experian | `lote` / campos no presentes en XPM hoy |

### Fuera de scope acordado (mock / PoC)

| Item | Notas |
|------|-------|
| Movilidad P0029 | No migrado en PoC Redshift |
| SPs pre-proceso Teradata `ORDENAMIENTO_242` | PoC usa `insumo_*` directo |
| Paridad 1:1 Teradata ordenamiento | Condicionada a betas Experian |
| Orquestación Control-M | Documentada; implementación en herramienta del cliente |

---

## 4. Comandos útiles

```powershell
$env:REDSHIFT_CONSUMER_PASSWORD="<pwd>"
cd PAQUETE_UNIFICACION_BDM_STAGE

# Unificación DEV
py -3 tools/dev_edf_unificacion_run.py

# Ordenamiento DEV
py -3 tools/dev_edf_ordenamiento_run.py
py -3 tools/dev_edf_ordenamiento_run.py --fase2-only

# Sync Bitbucket ordenamiento
py -3 tools/sync_deploy_bitbucket_ordenamiento.py
py -3 tools/sync_repos_ordenamiento.py

# Mapas HTML
py -3 tools/export_mapa_ordenamiento_html.py
```

---

## 5. Referencias

| Documento | Contenido |
|-----------|-----------|
| `ESTADO_COMPLETO_UNIFICACION_BDM.md` | Estado histórico unificación + mapping IFR |
| `GUIA_REORGANIZACION_TRES_REPOS_UNIFICACION.md` | Flujo 3 repos y PRs |
| `Evidencias_*_DEV.md` | Corridas QA en consumidor Reconocer |

*Última actualización: 2026-09-04 — post commit/push `feature/ordenamiento`.*
