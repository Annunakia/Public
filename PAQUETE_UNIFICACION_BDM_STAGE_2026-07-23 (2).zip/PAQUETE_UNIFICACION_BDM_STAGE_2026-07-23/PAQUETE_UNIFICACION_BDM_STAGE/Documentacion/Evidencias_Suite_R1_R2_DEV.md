# Evidencias — Suite R1/R2 DEV (Redshift)

* **Ejecutado:** 2026-08-18 17:21:08
* **Entorno:** DEV — `eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com`
* **Pipeline:** reset + CALL R1 + CALL R2 + suite + evidencias

## Resumen

| Métrica | Valor |
|---------|------:|
| Casos oficiales | 23 |
| PASSED | **23** |
| FAILED | 0 |
| Aprobación | **100.0%** |

### Conteos post-ejecución

- **generada_enriquecida**: 2,000
- **unificacion_r1**: 1,401
- **unificacion_r2**: 6,002
- **relacion_persona_ubicacion**: 42,008

---

## TC-R1-01 — CIIU 10 escenario R1_ESC1: padre LAB

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |
| Nota | Validación corregida escenario R1 puro |

### Query de validación

```sql
SELECT COUNT(*) AS v FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        JOIN bdm_stage.relacion_persona_ubicacion rp ON rp.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
        JOIN bdm_stage.ciiu_persona c ON c.id_buro_persona = rh.id_buro_persona
        JOIN bdm_stage.tipo_ubicacion_dir tp ON tp.cod_dw_tipo_ubicacion_dir = rp.cod_dw_tipo_ubicacion_dir
        JOIN bdm_stage.perf_persona_meta m ON m.id_buro_persona = rh.id_buro_persona
        WHERE u.unifica_atributos = 1 AND c.cod_act_econo_ciiu_fte = '10'
          AND tp.descripcion_tipo_ubicacion_dir NOT IN ('LAB','CRR')
          AND m.scenario_code = 'R1_ESC1'
```

### Evidencia

| id_buro_persona | scenario_code | hija | padre | tipo_padre |
| --- | --- | --- | --- | --- |
| 100001 | R1_ESC1 | 100001001 | 100001002 | LAB |
| 100002 | R1_ESC1 | 100002001 | 100002002 | LAB |
| 100100 | R1_ESC1 | 100100001 | 100100002 | LAB |

---

## TC-R1-02 — CIIU 81/82/90: padre RES/CRR

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |

### Query de validación

```sql
SELECT COUNT(*) AS v FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        JOIN bdm_stage.relacion_persona_ubicacion rp ON rp.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
        JOIN bdm_stage.ciiu_persona c ON c.id_buro_persona = rh.id_buro_persona
        JOIN bdm_stage.tipo_ubicacion_dir tp ON tp.cod_dw_tipo_ubicacion_dir = rp.cod_dw_tipo_ubicacion_dir
        WHERE u.unifica_atributos = 1 AND c.cod_act_econo_ciiu_fte IN ('81','82','90')
          AND tp.descripcion_tipo_ubicacion_dir NOT IN ('RES','CRR')
```

### Evidencia

| scenario_code | unificaciones_ok |
| --- | --- |
| R1_ESC2 | 400 |

---

## TC-R1-03 — Otros CIIU: padre por max entidades

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |

### Query de validación

```sql
WITH scored AS (
          SELECT rpu.id_buro_persona, ubi.texto_ubicacion, rpu.cod_dw_persona_ubic,
                 COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor),0) AS ents
          FROM bdm_stage.relacion_persona_ubicacion rpu
          JOIN bdm_stage.ubicacion_estandarizada ubi ON ubi.cod_dw_ubic = rpu.cod_dw_ubic
          JOIN bdm_stage.ciiu_persona c ON c.id_buro_persona = rpu.id_buro_persona
          LEFT JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rep.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
          WHERE c.cod_act_econo_ciiu_fte NOT IN ('10','81','82','90')
          GROUP BY 1,2,3
        ), winners AS (
          SELECT id_buro_persona, texto_ubicacion, cod_dw_persona_ubic,
                 ROW_NUMBER() OVER (PARTITION BY id_buro_persona, texto_ubicacion ORDER BY ents DESC, cod_dw_persona_ubic DESC) rn
          FROM scored
        )
        SELECT COUNT(*) AS v FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        JOIN bdm_stage.ubicacion_estandarizada ubi ON ubi.cod_dw_ubic = rh.cod_dw_ubic
        JOIN bdm_stage.ciiu_persona c ON c.id_buro_persona = rh.id_buro_persona
        LEFT JOIN winners w ON w.id_buro_persona = rh.id_buro_persona AND w.texto_ubicacion = ubi.texto_ubicacion
          AND w.cod_dw_persona_ubic = u.cod_dw_direccion_unificada AND w.rn = 1
        WHERE u.unifica_atributos = 1 AND c.cod_act_econo_ciiu_fte NOT IN ('10','81','82','90')
          AND w.cod_dw_persona_ubic IS NULL
```

### Evidencia

| scenario_code | unificaciones_r1 |
| --- | --- |
| R1_ESC3 | 400 |

---

## TC-R1-04 — Hijas R1 con ind_unificacion = 1

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |

### Query de validación

```sql
SELECT COUNT(*) AS v FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        WHERE u.unifica_atributos = 1 AND COALESCE(r.ind_unificacion, 0) <> 1
```

### Evidencia

| hijas_r1_total | hijas_ind_1 |
| --- | --- |
| 1401 | 1401 |

---

## TC-R1-05 — Trazabilidad R1 completa

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |

### Query de validación

```sql
SELECT COUNT(*) AS v FROM bdm_stage.unificacion_direccion
        WHERE unifica_atributos = 1
          AND (cod_dw_persona_ubic IS NULL OR cod_dw_direccion_unificada IS NULL OR fecha_unificacion IS NULL)
```

### Evidencia

| filas_r1_completas |
| --- |
| 1401 |

---

## TC-R1-06 — Bloqueadas excluidas de R1

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |

### Query de validación

```sql
SELECT COUNT(*) AS v FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        JOIN bdm_stage.bloqueo b ON b.id_buro_persona = r.id_buro_persona
        WHERE u.unifica_atributos = 1
```

### Evidencia

| personas_bloqueadas_en_r1 |
| --- |
| 0 |

---

## TC-R1-07 — Segmentación CIIU sin solapamiento

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |

### Query de validación

```sql
SELECT COUNT(*) AS v FROM (
          SELECT rh.id_buro_persona, ubi.texto_ubicacion
          FROM bdm_stage.unificacion_direccion u
          JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic
          JOIN bdm_stage.ubicacion_estandarizada ubi ON ubi.cod_dw_ubic = rh.cod_dw_ubic
          JOIN bdm_stage.ciiu_persona c ON c.id_buro_persona = rh.id_buro_persona
          WHERE u.unifica_atributos = 1
          GROUP BY 1,2 HAVING COUNT(DISTINCT c.cod_act_econo_ciiu_fte) > 1
        ) t
```

### Evidencia

| particiones_ciiu_mixto |
| --- |
| 0 |

---

## TC-R1-08 — R1_EMPATE sin unificación

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |

### Query de validación

```sql
SELECT COUNT(*) AS v FROM bdm_stage.perf_persona_meta m
        JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
        JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic
        WHERE m.scenario_code = 'R1_EMPATE' AND u.unifica_atributos = 1
```

### Evidencia

| absorciones_r1_empate |
| --- |
| 0 |

---

## TC-R2-01 — Esc1: gana complemento informado

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |

### Query de validación

```sql
WITH winner AS (
          SELECT m.id_buro_persona,
                 MAX(CASE WHEN TRIM(COALESCE(df.complemento,'')) <> '' THEN r.cod_dw_persona_ubic END) AS padre
          FROM bdm_stage.perf_persona_meta m
          JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
          JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
          WHERE m.scenario_code = 'R2_ESC1' GROUP BY 1
        )
        SELECT COUNT(*) AS v FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        JOIN winner w ON w.id_buro_persona = rh.id_buro_persona
        WHERE u.unifica_atributos = 2 AND u.cod_dw_direccion_unificada <> w.padre
          AND rh.id_buro_persona IN (SELECT id_buro_persona FROM bdm_stage.perf_persona_meta WHERE scenario_code = 'R2_ESC1')
```

### Evidencia

| id_buro_persona | hija | padre | comp_hija | comp_padre |
| --- | --- | --- | --- | --- |
| 100012 | 100012001 | 100012002 |  | AP 802 |
| 100013 | 100013001 | 100013002 |  | AP 802 |
| 100014 | 100014001 | 100014002 |  | AP 802 |

---

## TC-R2-02 — Esc2: gana complemento más completo

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |

### Query de validación

```sql
WITH winner AS (
          SELECT m.id_buro_persona, r.cod_dw_persona_ubic AS padre,
                 ROW_NUMBER() OVER (PARTITION BY m.id_buro_persona ORDER BY LENGTH(COALESCE(df.complemento,'')) DESC, r.cod_dw_persona_ubic DESC) rn
          FROM bdm_stage.perf_persona_meta m
          JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
          JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
          WHERE m.scenario_code = 'R2_ESC2'
        )
        SELECT COUNT(*) AS v FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        JOIN winner w ON w.id_buro_persona = rh.id_buro_persona AND w.rn = 1
        WHERE u.unifica_atributos = 2 AND u.cod_dw_direccion_unificada <> w.padre
```

### Evidencia

| id_buro_persona | hija | padre | len_hija | len_padre |
| --- | --- | --- | --- | --- |
| 100015 | 100015001 | 100015002 | 6 | 17 |
| 100016 | 100016001 | 100016002 | 6 | 17 |
| 100017 | 100017001 | 100017002 | 6 | 17 |

---

## TC-R2-03 — Esc3 sin NIT: no crea dirección nueva

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |

### Query de validación

```sql
SELECT COUNT(*) AS v FROM bdm_stage.perf_persona_meta m
        JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
        JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
        WHERE m.scenario_code = 'R2_ESC3_SIN_NIT' AND COALESCE(df.generada_enriquecida, 0) = 1
```

### Evidencia

| dirs_generadas_esc3_sin_nit |
| --- |
| 0 |

---

## TC-R2-04 — Esc3 NIT: crea dirección generada_enriquecida=1

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |

### Query de validación

```sql
SELECT COUNT(*) AS v FROM bdm_stage.perf_persona_meta m
        WHERE m.scenario_code = 'R2_ESC3_NIT' AND NOT EXISTS (
          SELECT 1 FROM bdm_stage.relacion_persona_ubicacion r
          JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
          WHERE r.id_buro_persona = m.id_buro_persona AND COALESCE(df.generada_enriquecida, 0) = 1
        )
```

### Evidencia

| id_buro_persona | orden_prioridad | cod_dw_persona_ubic | complemento | generada_enriquecida |
| --- | --- | --- | --- | --- |
| 100030 | 1 | 100030001 | LC 101 |  |
| 100030 | 2 | 100030002 | LC 205 |  |
| 100030 | 3 | 100030003 | LC 101 LC 205 | 1 |

---

## TC-R2-05 — Esc4: personas sin unificación R2 (query corregido)

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |
| Nota | Nivel persona; no cuenta padre como violación |

### Query de validación

```sql
SELECT COUNT(*) AS v FROM bdm_stage.perf_persona_meta m
        WHERE m.scenario_code IN ('R2_ESC4','R2_ESC4_DIC') AND NOT EXISTS (
          SELECT 1 FROM bdm_stage.relacion_persona_ubicacion r
          JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic AND u.unifica_atributos = 2
          WHERE r.id_buro_persona = m.id_buro_persona
        )
```

### Evidencia

| scenario_code | personas | con_r2 |
| --- | --- | --- |
| R2_ESC4_DIC | 600 | 600 |
| R2_ESC4 | 600 | 600 |

---

## TC-R2-06 — Esc5 motor: dirección combinada

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |

### Query de validación

```sql
SELECT COUNT(*) AS v FROM bdm_stage.perf_persona_meta m
        WHERE m.scenario_code = 'R2_ESC5_MOTOR' AND NOT EXISTS (
          SELECT 1 FROM bdm_stage.relacion_persona_ubicacion r
          JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
          WHERE r.id_buro_persona = m.id_buro_persona AND COALESCE(df.generada_enriquecida, 0) = 1
        )
```

### Evidencia

| id_buro_persona | orden_prioridad | complemento | generada_enriquecida |
| --- | --- | --- | --- |
| 100033 | 1 | TO 3 |  |
| 100033 | 2 | AP 504 |  |
| 100033 | 3 | TO 3 AP 504 | 1 |

---

## TC-R2-07 — Esc6 motor: dirección combinada

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |

### Query de validación

```sql
SELECT COUNT(*) AS v FROM bdm_stage.perf_persona_meta m
        WHERE m.scenario_code = 'R2_ESC6_MOTOR' AND NOT EXISTS (
          SELECT 1 FROM bdm_stage.relacion_persona_ubicacion r
          JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
          WHERE r.id_buro_persona = m.id_buro_persona AND COALESCE(df.generada_enriquecida, 0) = 1
        )
```

### Evidencia

| id_buro_persona | orden_prioridad | complemento | generada_enriquecida |
| --- | --- | --- | --- |
| 100037 | 1 | ED 2 OF 301 |  |
| 100037 | 2 | OF 302 |  |
| 100037 | 3 | ED 2 OF 301 OF 302 | 1 |

---

## TC-R2-08 — Motor R2 con generada_enriquecida=1

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |

### Query de validación

```sql
SELECT COUNT(*) AS v FROM bdm_stage.direccion_fisica df
        JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
        JOIN bdm_stage.perf_persona_meta m ON m.id_buro_persona = r.id_buro_persona
        WHERE m.scenario_code IN ('R2_ESC3_NIT','R2_ESC5_MOTOR','R2_ESC6_MOTOR')
          AND r.cod_dw_persona_ubic > m.id_buro_persona * 1000 + 2
          AND COALESCE(df.generada_enriquecida, 0) <> 1
```

### Evidencia

| scenario_code | cod_dw_persona_ubic | complemento | generada_enriquecida |
| --- | --- | --- | --- |
| R2_ESC3_NIT | 100030003 | LC 101 LC 205 | 1 |
| R2_ESC3_NIT | 100031003 | LC 101 LC 205 | 1 |
| R2_ESC3_NIT | 100032003 | LC 101 LC 205 | 1 |
| R2_ESC3_NIT | 100130003 | LC 101 LC 205 | 1 |
| R2_ESC3_NIT | 100131003 | LC 101 LC 205 | 1 |
| R2_ESC3_NIT | 100132003 | LC 101 LC 205 | 1 |

---

## TC-R2-09 — Sin huérfanas generada_enriquecida=1

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |

### Query de validación

```sql
SELECT COUNT(*) AS v FROM bdm_stage.direccion_fisica df
        LEFT JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
        WHERE COALESCE(df.generada_enriquecida, 0) = 1 AND r.cod_dw_persona_ubic IS NULL
```

### Evidencia

| dirs_huerfanas |
| --- |
| 0 |

---

## TC-R2-10 — Padre nunca hijo en R2

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |

### Query de validación

```sql
SELECT COUNT(*) AS v FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
        WHERE u.unifica_atributos = 2 AND COALESCE(r.ind_unificacion, 0) = 1
```

### Evidencia

| padres_marcados_hijo |
| --- |
| 0 |

---

## TC-R2-11 — Cardinalidad 1 padre por hija R2

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |

### Query de validación

```sql
SELECT COUNT(*) AS v FROM (
          SELECT cod_dw_persona_ubic FROM bdm_stage.unificacion_direccion
          WHERE unifica_atributos = 2 GROUP BY 1 HAVING COUNT(DISTINCT cod_dw_direccion_unificada) <> 1
        ) t
```

### Evidencia

| hijas_multiples_padres |
| --- |
| 0 |

---

## TC-R2-12 — Complementos generados sin dobles espacios

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |

### Query de validación

```sql
SELECT COUNT(*) AS v FROM bdm_stage.direccion_fisica
        WHERE COALESCE(generada_enriquecida, 0) = 1 AND complemento LIKE '%  %'
```

### Evidencia

| complementos_doble_espacio |
| --- |
| 0 |

---

## TC-R2-13 — R2_ESC4_DIC: personas sin unificación (corregido)

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |
| Nota | Nivel persona |

### Query de validación

```sql
SELECT COUNT(*) AS v FROM bdm_stage.perf_persona_meta m
        WHERE m.scenario_code = 'R2_ESC4_DIC' AND NOT EXISTS (
          SELECT 1 FROM bdm_stage.relacion_persona_ubicacion r
          JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic AND u.unifica_atributos = 2
          WHERE r.id_buro_persona = m.id_buro_persona
        )
```

### Evidencia

| personas_esc4_dic | con_r2 |
| --- | --- |
| 600 | 600 |

---

## TC-R2-14 — R2_EMPATE: personas con absorción R2

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |
| Nota | Nivel persona; empate no debe unificar |

### Query de validación

```sql
SELECT COUNT(*) AS v FROM bdm_stage.perf_persona_meta m
        WHERE m.scenario_code = 'R2_EMPATE' AND EXISTS (
          SELECT 1 FROM bdm_stage.relacion_persona_ubicacion r
          JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic AND u.unifica_atributos = 2
          WHERE r.id_buro_persona = m.id_buro_persona
        )
```

### Evidencia

| personas_r2_empate_con_r2 |
| --- |
| 0 |

---

## TC-G-07 — Aislamiento intra-persona

| Campo | Valor |
|-------|-------|
| **Estado** | **PASSED** |
| Violaciones | 0 (esperado: 0) |

### Query de validación

```sql
SELECT COUNT(*) AS v FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion h ON h.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        JOIN bdm_stage.relacion_persona_ubicacion p ON p.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
        WHERE h.id_buro_persona <> p.id_buro_persona
```

### Evidencia

| unificaciones_inter_persona |
| --- |
| 0 |

---

## Mocks manuales (888001–888004)

### Mock 888001 — TC-R1-01 RES→LAB — **PASSED**

```sql
SELECT 'R1' regla, u.cod_dw_persona_ubic hija, u.cod_dw_direccion_unificada padre,
               df_h.complemento comp_hija, t_h.descripcion_tipo_ubicacion_dir tipo_hija,
               df_p.complemento comp_padre, t_p.descripcion_tipo_ubicacion_dir tipo_padre,
               rh.ind_unificacion
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic=u.cod_dw_persona_ubic
        JOIN bdm_stage.relacion_persona_ubicacion rp ON rp.cod_dw_persona_ubic=u.cod_dw_direccion_unificada
        JOIN bdm_stage.direccion_fisica df_h ON df_h.cod_dw_direccion_fisica=rh.cod_dw_direccion_fisica
        JOIN bdm_stage.direccion_fisica df_p ON df_p.cod_dw_direccion_fisica=rp.cod_dw_direccion_fisica
        JOIN bdm_stage.tipo_ubicacion_dir t_h ON t_h.cod_dw_tipo_ubicacion_dir=rh.cod_dw_tipo_ubicacion_dir
        JOIN bdm_stage.tipo_ubicacion_dir t_p ON t_p.cod_dw_tipo_ubicacion_dir=rp.cod_dw_tipo_ubicacion_dir
        WHERE rh.id_buro_persona=888001 AND u.unifica_atributos=1
```

| regla | hija | padre | comp_hija | tipo_hija | comp_padre | tipo_padre | ind_unificacion |
| --- | --- | --- | --- | --- | --- | --- | --- |
| R1 | 888001001 | 888001002 |  | RES |  | LAB | 1 |


### Mock 888002 — TC-R2 AP301→IN301 — **PASSED**

```sql
SELECT 'R2' regla, u.cod_dw_persona_ubic hija, u.cod_dw_direccion_unificada padre,
               df_h.complemento comp_hija, df_p.complemento comp_padre
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic=u.cod_dw_persona_ubic
        JOIN bdm_stage.relacion_persona_ubicacion rp ON rp.cod_dw_persona_ubic=u.cod_dw_direccion_unificada
        JOIN bdm_stage.direccion_fisica df_h ON df_h.cod_dw_direccion_fisica=rh.cod_dw_direccion_fisica
        JOIN bdm_stage.direccion_fisica df_p ON df_p.cod_dw_direccion_fisica=rp.cod_dw_direccion_fisica
        WHERE rh.id_buro_persona=888002 AND u.unifica_atributos=2
```

| regla | hija | padre | comp_hija | comp_padre |
| --- | --- | --- | --- | --- |
| R2 | 888002001 | 888002002 | AP 301 | IN 301 |


### Mock 888003 — TC-R2-13 diccionario — **PASSED**

```sql
SELECT u.cod_dw_persona_ubic hija, u.cod_dw_direccion_unificada padre,
               df_h.complemento comp_hija, df_p.complemento comp_padre
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic=u.cod_dw_persona_ubic
        JOIN bdm_stage.relacion_persona_ubicacion rp ON rp.cod_dw_persona_ubic=u.cod_dw_direccion_unificada
        JOIN bdm_stage.direccion_fisica df_h ON df_h.cod_dw_direccion_fisica=rh.cod_dw_direccion_fisica
        JOIN bdm_stage.direccion_fisica df_p ON df_p.cod_dw_direccion_fisica=rp.cod_dw_direccion_fisica
        WHERE rh.id_buro_persona=888003 AND u.unifica_atributos=2
```

| hija | padre | comp_hija | comp_padre |
| --- | --- | --- | --- |
| 888003002 | 888003001 | PI 5 | CS 5 |


### Mock 888004 — TC-R2-14 empate — **PASSED**

```sql
SELECT COUNT(*) AS unificaciones_r2_mock
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic=u.cod_dw_persona_ubic
        WHERE rh.id_buro_persona=888004 AND u.unifica_atributos=2
```

| unificaciones_r2_mock |
| --- |
| 0 |



*Generado automáticamente el 2026-08-18 17:21:08.*
