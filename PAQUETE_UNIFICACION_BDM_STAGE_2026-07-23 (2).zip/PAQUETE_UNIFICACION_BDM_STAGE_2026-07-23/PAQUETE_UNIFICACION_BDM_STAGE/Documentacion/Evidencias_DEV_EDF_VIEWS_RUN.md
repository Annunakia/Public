# Evidencias — Unificación DEV con edf_views
Fecha: 2026-08-25T09:25:52
Cluster: `eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com` / `dba_batch`

## Stages

- **ddl**: OK
- **vistas**: OK
- **smoke**: OK

### Smoke
```json
[
  {
    "paso": "01_edf_views.xpm",
    "total": 538235
  },
  {
    "paso": "02_edf_views.xpm_location",
    "total": 599394
  },
  {
    "paso": "03_edf_views.xpm_location_val_contactinformations",
    "total": 2353389
  },
  {
    "paso": "04_edf_views.xpm_counterparties",
    "total": 419506
  },
  {
    "paso": "05_xpm_con_location_match",
    "total": 599394
  },
  {
    "paso": "06_join_contactos_direccion",
    "total": 5434
  },
  {
    "paso": "07_join_reportes_R1_R2",
    "total": 84755
  },
  {
    "paso": "08_vista_contacto_direccion",
    "total": 591166
  },
  {
    "paso": "09_vista_reportes",
    "total": 670487
  }
]
```
- **deploy_sp_r1**: OK
- **deploy_sp_r2**: OK
- **deploy_sp_r3**: OK
- **execute**: OK
- **validaciones**: OK

## Resumen salida
```json
[
  {
    "unifica_atributos": 2,
    "n": 72448
  }
]
```
