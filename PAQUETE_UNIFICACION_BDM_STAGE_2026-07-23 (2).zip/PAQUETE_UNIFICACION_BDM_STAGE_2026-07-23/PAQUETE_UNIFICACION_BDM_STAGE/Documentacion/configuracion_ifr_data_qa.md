# Configuración de Datos Reales — Esquema `ifr_data` (QA)

> **Fecha**: 2026-08-03 | **Autor**: Equipo Macondotek
> **Proyecto**: MT-EXP-005-MAP-RECONOCER | **Cliente**: Experian Colombia
> **Objetivo**: Configurar los procesos de Unificación y Ordenamiento para consumir datos reales con estandarización/tokenización desde el esquema `ifr_data` en Redshift QA.
> **Contexto**: El XPM con estandarización ya entrega los campos tokenizados confirmados (complemento, tipo_via, via_principal, via_generadora, numero_puerta). Se abandona el uso de datos mockeados.

---

## 1. Resumen del Cambio

Hasta ahora los procesos de Unificación y Ordenamiento consumían datos mock del esquema `bdm_datos` (cargados manualmente). A partir de esta configuración, se apunta a **datos reales** del esquema `ifr_data` en el ambiente de QA.

| Concepto | Antes (Mock) | Ahora (Datos Reales) |
|----------|:------------:|:--------------------:|
| Esquema fuente | `bdm_datos` | `ifr_data` |
| Origen de datos | CSVs mock (20 personas) | XPM con estandarización (IFR pipeline) |
| Tokenización dirección | Carga manual de campos separados | EDF/Estandarización los entrega en el JSON |
| Volumen | 20 personas / 5,000 sintéticas | ~65-70M registros reales |
| Ambiente | Sandbox dev | QA |

---

## 2. Campos Tokenizados Confirmados en XPM Estandarizado

El JSON del XPM con estandarización (verificado en `Registro XPM Estandarización.json`) entrega los siguientes campos dentro de `location[].contactInformations[]` para `contactType: 3` (dirección):

| Campo JSON XPM | Ejemplo | Tabla Redshift destino | Columna Redshift |
|---------------|---------|----------------------|-----------------|
| `standardizedComplemento` | `"AP 1108"` | `ifr_data.direccion_fisica` | `complemento` |
| `standardizedTipoViaPrincipal` | `"KR"` | `ifr_data.direccion_fisica` | `tipo_via_principal` |
| `standardizedViaPrincipal` | `"14"` | `ifr_data.direccion_fisica` | `via_principal` |
| `standardizedViaGeneradora` | `"SUR"` | `ifr_data.direccion_fisica` | `via_generadora` |
| `standardizedNumeroPuerta` | `"95"` | `ifr_data.direccion_fisica` | `numero_puerta` |
| `standardizedTextoUbicacion` | `"KR 14 B SUR N 95 120 APTO 1108"` | `ifr_data.ubicacion_estandarizada` | `texto_ubicacion` |
| `contactAsReportedStandardized` | `"CARRERA 14B SUR 95 120 AP 1108 BOGOTA"` | `ifr_data.ubicacion_estandarizada` | `texto_ubicacion_normalizado` |
| `contactAsStandardizedScore` | `"0.96"` | `ifr_data.ubicacion_estandarizada` | `score_estandarizacion` |
| `standardizedDaneCode` | `"11001000"` | `ifr_data.ubicacion_estandarizada` | `cod_dw_ciudad` |
| `standardizedDepartment` | `"BOGOTA, D.C."` | `ifr_data.ubicacion_estandarizada` | `departamento` |
| `standardizedMunicipality` | `"BOGOTA"` | `ifr_data.ubicacion_estandarizada` | `municipio` |
| `standardizedTipo` | `"VIA"` | `ifr_data.ubicacion_estandarizada` | `tipo_ubicacion` |
| `contactAsReported` | `"KR 14 B SUR N 95 120 APTO 1108"` | `ifr_data.ubicacion_estandarizada` | `texto_ubicacion_original` |
| `contactType` | `3` | `ifr_data.relacion_persona_ubicacion` | `cod_dw_tipo_ubicacion_dir` |
| `contactEventLastUpdated` | `1772323199000` (epoch ms) | `ifr_data.relacion_persona_ubicacion` | `fecha_relacion_persona_ubicaci` |
| `contactFirstEventDate` | `1772323199000` (epoch ms) | `ifr_data.relacion_persona_ubicacion` | `fecha_primera_relacion` |
| `personIdType` (nivel `location`) | `3` (NIT) | `ifr_data.relacion_persona_ubicacion` | `cod_tipo_ident_fte` |

### Diferencia clave con `xpm_john.json` (sin estandarización)

| Campo | `xpm_john.json` (viejo) | XPM Estandarizado (nuevo) |
|-------|:-----------------------:|:-------------------------:|
| `standardizedComplemento` | ❌ No existe | ✅ `"AP 1108"` |
| `standardizedTipoViaPrincipal` | ❌ No existe | ✅ `"KR"` |
| `standardizedViaPrincipal` | ❌ No existe | ✅ `"14"` |
| `standardizedViaGeneradora` | ❌ No existe | ✅ `"SUR"` |
| `standardizedNumeroPuerta` | ❌ No existe | ✅ `"95"` |
| `standardizedDaneCode` | ❌ No existe | ✅ `"11001000"` |
| `contactAsReportedStandardized` | ❌ No existe | ✅ Dirección normalizada completa |
| `contactAsStandardizedScore` | ❌ No existe | ✅ Score de confianza (0-1) |

---

## 3. Mapeo de Tablas: XPM en `ifr_data` → insumo BDM

> **Nota QA:** En Redshift QA los datos tokenizados están en tablas **`ifr_data.xpm_*`**, no en tablas BDM planas (`relacion_persona_ubicacion`, etc.). Los scripts en `sql/qa_ifr_data/` leen XPM y exponen el modelo BDM vía vistas `bdm_tempo.v_xpm_*`.

### 3.1 Tablas XPM origen (QA)

| Tabla `ifr_data` | Descripción | Campos clave |
|------------------|-------------|--------------|
| `xpm` | Raíz persona | `pin`, `location`, `counterparties`, CIIU |
| `xpm_location` | Ubicación | FK desde `xpm.location` |
| `xpm_location_val_contactinformations` | Direcciones tokenizadas | `val.standardized*`, `val.contacttype` |
| `xpm_counterparties` | Entidades reportantes | `val.counterpartyidnumber`, `val.cutoffdate` |

### 3.2 Modelo BDM destino (vistas `bdm_tempo.v_xpm_*`)

| Tabla | Esquema QA | Descripción | Origen en XPM |
|-------|-----------|-------------|---------------|
| `ifr_data.ubicacion_estandarizada` | QA | Ubicación con texto estandarizado, coordenadas, DANE | `location[].contactInformations[]` (contactType=3) |
| `ifr_data.direccion_fisica` | QA | Componentes tokenizados de la dirección | `standardized*` fields |
| `ifr_data.relacion_persona_ubicacion` | QA | Relación persona ↔ ubicación con flags de proceso | `location[]` + raíz (`pin`) |
| `ifr_data.reporte_relacion_persona_ubica` | QA | Reportes de suscriptores por dato | `location[]` (counterparty info) |
| `ifr_data.ciiu_persona` | QA | CIIU por persona | `bestPersonalInformation.mainIsicCodeForProduct` |

### 3.2 Tablas de catálogos/parámetros (se mantienen en `bdm_datos`)

Estas tablas NO se mueven a `ifr_data` porque son catálogos estáticos, no datos de persona:

| Tabla | Esquema | Razón |
|-------|---------|-------|
| `bdm_datos.nomenclatura` | `bdm_datos` | Catálogo estático (89 registros) |
| `bdm_datos.tipo_ubicacion_dir` | `bdm_datos` | Catálogo estático (~5 registros) |
| `bdm_datos.diccionario_complementos` | `bdm_datos` | Se genera en proceso, no viene de IFR |
| `bdm_datos.diccionario_via` | `bdm_datos` | Catálogo estático |
| `bdm_datos.unificacion_direccion` | `bdm_datos` | Tabla resultado (Redshift la crea) |

### 3.3 Tablas de scoring/ordenamiento

| Tabla | Esquema QA | Descripción |
|-------|-----------|-------------|
| `ifr_data.v_beta_ordenamiento_dir` | QA | Coeficientes Beta canal DIR (12 registros) |
| `ifr_data.v_beta_ordenamiento_tel` | QA | Coeficientes Beta canal TEL (11 registros) |
| `ifr_data.v_beta_ordenamiento_cel` | QA | Coeficientes Beta canal CEL (11 registros) |
| `ifr_data.v_beta_ordenamiento_email` | QA | Coeficientes Beta canal EMA (13 registros) |
| `ifr_data.v_operador_ord_cel` | QA | Mapeo operador celular por prefijo |
| `ifr_data.v_tipo_cuenta_ord` | QA | Clasificación tipo cuenta para scoring |

---

## 4. DDL de Tablas en `ifr_data` (estructura esperada)

### 4.1 `ifr_data.ubicacion_estandarizada`

```sql
CREATE TABLE IF NOT EXISTS ifr_data.ubicacion_estandarizada (
  cod_dw_ubic                  BIGINT        ENCODE AZ64,
  texto_ubicacion              VARCHAR(200)  ENCODE ZSTD,    -- standardizedTextoUbicacion
  texto_ubicacion_normalizado  VARCHAR(300)  ENCODE ZSTD,    -- contactAsReportedStandardized
  texto_ubicacion_original     VARCHAR(300)  ENCODE ZSTD,    -- contactAsReported
  score_estandarizacion        DECIMAL(5,4)  ENCODE AZ64,    -- contactAsStandardizedScore
  cod_dw_ciudad                INTEGER       ENCODE AZ64,    -- standardizedDaneCode (cast a INT)
  departamento                 VARCHAR(50)   ENCODE ZSTD,    -- standardizedDepartment
  municipio                    VARCHAR(50)   ENCODE ZSTD,    -- standardizedMunicipality
  tipo_ubicacion               VARCHAR(20)   ENCODE ZSTD,    -- standardizedTipo ("VIA")
  cod_dw_tipo_ubicacion        INTEGER       ENCODE AZ64,    -- contactType
  latitud                      DECIMAL(10,6) ENCODE AZ64,    -- (pendiente Georreferenciación)
  longitud                     DECIMAL(10,6) ENCODE AZ64     -- (pendiente Georreferenciación)
)
DISTSTYLE KEY DISTKEY(cod_dw_ubic)
SORTKEY(cod_dw_ubic);
```

### 4.2 `ifr_data.direccion_fisica`

```sql
CREATE TABLE IF NOT EXISTS ifr_data.direccion_fisica (
  cod_dw_direccion_fisica  BIGINT       ENCODE AZ64,
  complemento              VARCHAR(100) ENCODE ZSTD,    -- standardizedComplemento
  tipo_via_principal       VARCHAR(20)  ENCODE ZSTD,    -- standardizedTipoViaPrincipal
  via_principal            VARCHAR(100) ENCODE ZSTD,    -- standardizedViaPrincipal
  via_generadora           VARCHAR(20)  ENCODE ZSTD,    -- standardizedViaGeneradora (nota: es VARCHAR, no INT)
  numero_puerta            VARCHAR(20)  ENCODE ZSTD,    -- standardizedNumeroPuerta (nota: es VARCHAR, no INT)
  cod_dw_ubic              BIGINT       ENCODE AZ64,
  generada_enriquecida     INTEGER      ENCODE AZ64 DEFAULT 0
)
DISTSTYLE KEY DISTKEY(cod_dw_ubic)
SORTKEY(cod_dw_direccion_fisica);
```

> ⚠️ **Nota importante sobre tipos**: En el XPM estandarizado, `standardizedViaGeneradora` viene como VARCHAR (`"SUR"`) y `standardizedNumeroPuerta` como VARCHAR (`"95"`). En los scripts mock se definieron como INTEGER. Los scripts de Unificación que comparan estos campos deben ajustar los CAST o comparaciones según corresponda.

### 4.3 `ifr_data.relacion_persona_ubicacion`

```sql
CREATE TABLE IF NOT EXISTS ifr_data.relacion_persona_ubicacion (
  cod_dw_persona_ubic            BIGINT    ENCODE AZ64,
  id_buro_persona                BIGINT    ENCODE AZ64,    -- generado en SPs
  cod_pin_persona                BIGINT    ENCODE AZ64,    -- pin del XPM
  cod_dw_ubic                    BIGINT    ENCODE AZ64,
  cod_dw_direccion_fisica        BIGINT    ENCODE AZ64,
  cod_dw_tipo_ubicacion_dir      INTEGER   ENCODE AZ64,    -- contactType (1=RES,2=LAB,3=CRR,9=CEL,10=EMA)
  ind_unificacion                INTEGER   ENCODE AZ64,    -- NULL=no procesada, 1=hija
  orden_prioridad                INTEGER   ENCODE AZ64,    -- resultado scoring
  fecha_relacion_persona_ubicaci DATE      ENCODE AZ64,    -- locationFirstEventDate (epoch→DATE)
  lote                           INTEGER   ENCODE AZ64,
  cod_tipo_ident_fte             INTEGER   ENCODE AZ64,    -- personIdType → XPM: location.val.personidtype
  bloqueado                      SMALLINT  ENCODE AZ64 DEFAULT 0
)
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, cod_dw_persona_ubic);
```

### 4.4 `ifr_data.reporte_relacion_persona_ubica`

```sql
CREATE TABLE IF NOT EXISTS ifr_data.reporte_relacion_persona_ubica (
  cod_dw_persona_ubic  BIGINT  ENCODE AZ64,
  id_buro_suscriptor   INTEGER ENCODE AZ64,    -- counterpartyIdNumber
  fecha_reporte        DATE    ENCODE AZ64      -- cutoffDate (epoch→DATE)
)
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
SORTKEY(cod_dw_persona_ubic);
```

### 4.5 `ifr_data.ciiu_persona`

```sql
CREATE TABLE IF NOT EXISTS ifr_data.ciiu_persona (
  id_buro_persona        BIGINT      ENCODE AZ64,
  cod_act_econo_ciiu_fte VARCHAR(10) ENCODE BYTEDICT  -- bestPersonalInformation.mainIsicCodeForProduct
)
DISTSTYLE KEY DISTKEY(id_buro_persona);
```

---

## 5. Transformaciones Requeridas (Epoch → Date, Tipos)

El pipeline IFR debe realizar estas conversiones antes de cargar a las tablas Redshift:

| Campo JSON | Tipo JSON | Transformación | Tipo Redshift |
|-----------|-----------|---------------|---------------|
| `contactEventLastUpdated` | BIGINT (epoch ms) | `TIMESTAMP 'epoch' + val/1000 * INTERVAL '1 second'` | DATE |
| `locationFirstEventDate` | BIGINT (epoch ms) | Misma conversión | DATE |
| `cutoffDate` | BIGINT (epoch ms) | Misma conversión | DATE |
| `standardizedDaneCode` | VARCHAR (`"11001000"`) | `CAST(val AS INTEGER)` | INTEGER |
| `standardizedNumeroPuerta` | VARCHAR (`"95"`) | Mantener como VARCHAR (puede tener letras) | VARCHAR(20) |
| `standardizedViaGeneradora` | VARCHAR (`"SUR"`) | Mantener como VARCHAR (puede ser texto) | VARCHAR(20) |
| `contactAsStandardizedScore` | VARCHAR (`"0.96"`) | `CAST(val AS DECIMAL(5,4))` | DECIMAL(5,4) |
| `pin` | BIGINT | Directo | BIGINT |

---

## 6. Cambios Requeridos en Scripts SQL de Reconocer

Para apuntar los scripts migrados (actualmente en `bdm_datos`) al nuevo esquema `ifr_data`:

### 6.1 Tablas de LECTURA (cambiar fuente de `bdm_datos` → `ifr_data`)

| Script | Cambio | Detalle |
|--------|--------|---------|
| `02_regla1_unificacion.sql` | `bdm_datos.relacion_persona_ubicacion` → `ifr_data.relacion_persona_ubicacion` | Insumo base R1 |
| `02_regla1_unificacion.sql` | `bdm_datos.ubicacion_estandarizada` → `ifr_data.ubicacion_estandarizada` | JOIN para texto_ubicacion |
| `02_regla1_unificacion.sql` | `bdm_datos.direccion_fisica` → `ifr_data.direccion_fisica` | JOIN para complemento |
| `02_regla1_unificacion.sql` | `bdm_datos.reporte_relacion_persona_ubica` → `ifr_data.reporte_relacion_persona_ubica` | Conteo entidades |
| `02_regla1_unificacion.sql` | `bdm_datos.ciiu_persona` → `ifr_data.ciiu_persona` | CIIU para scoring |
| Todos los scripts R2 | Mismo patrón | Mismas tablas base |
| `10_regla3_geo.sql` | Mismo patrón | + `ifr_data.ubicacion_estandarizada` para lat/long |
| Scripts de Ordenamiento | Mismo patrón | Todas las tablas base |

### 6.2 Tablas de ESCRITURA (se mantienen en `bdm_datos`)

Las tablas resultado que Reconocer genera internamente siguen en `bdm_datos`:

| Tabla | Esquema | Razón |
|-------|---------|-------|
| `bdm_datos.unificacion_direccion` | `bdm_datos` | Output del proceso de unificación |
| `bdm_datos.diccionario_complementos` | `bdm_datos` | Se genera durante R2 |

### 6.3 Tablas de STAGING (se mantienen en `bdm_tempo`)

Las tablas temporales del proceso siguen en `bdm_tempo`:

| Tabla | Esquema | Ejemplo |
|-------|---------|---------|
| `bdm_tempo.stg_regla1_*` | `bdm_tempo` | Staging de R1 |
| `bdm_tempo.stg_regla2_*` | `bdm_tempo` | Staging de R2 |
| `bdm_tempo.stg_motor_*` | `bdm_tempo` | Staging del motor |
| `bdm_tempo.stg_ord_*` | `bdm_tempo` | Staging de Ordenamiento |

---

## 7. Consideraciones Especiales para `via_generadora`

En los datos mock, `via_generadora` se definió como INTEGER (número de vía cruzada). En el XPM estandarizado viene como VARCHAR porque puede contener texto como `"SUR"`, `"NORTE"`, etc.

**Impacto en Regla 3**: Los scripts de Regla 3 comparan `via_generadora` con `±2` para determinar cercanía de puertas. Con el nuevo formato VARCHAR, la lógica debe adaptarse:

```sql
-- ANTES (mock, via_generadora INTEGER):
WHERE ABS(a.via_generadora - b.via_generadora) <= 2

-- AHORA (real, via_generadora VARCHAR):
-- Si es numérico:
WHERE ABS(CAST(a.via_generadora AS INTEGER) - CAST(b.via_generadora AS INTEGER)) <= 2
-- Si no es numérico (cardinal: SUR, NORTE):
-- Se compara exacto o se excluye de la regla de ±2
```

**Recomendación**: Agregar un campo derivado `via_generadora_num` (INTEGER, NULL si no es numérico) para facilitar la comparación en R3.

---

## 8. Mapeo contactType → Tipo de Canal (Ordenamiento)

El campo `contactType` del XPM determina el canal de scoring:

| contactType | Canal | Descripción | Proceso |
|:-----------:|:-----:|-------------|---------|
| 1 | DIR | Dirección residencial | Unificación + Ordenamiento DIR |
| 2 | DIR | Dirección laboral | Unificación + Ordenamiento DIR |
| 3 | DIR | Dirección correspondencia | Unificación + Ordenamiento DIR |
| 4 | TEL | Teléfono fijo | Ordenamiento TEL |
| 5 | TEL | Teléfono laboral | Ordenamiento TEL |
| 7 | DIR | Dirección judicial | Unificación + Ordenamiento DIR |
| 8 | TEL | Teléfono de contacto/casa | Ordenamiento TEL |
| 9 | CEL | Celular | Ordenamiento CEL |
| 10 | EMA | Email | Ordenamiento EMA |

---

## 9. Checklist de Configuración

### Pre-requisitos (verificar en QA)

- [ ] Esquema `ifr_data` existe y tiene datos cargados
- [ ] Tablas tienen la estructura definida en sección 4
- [ ] Campos `standardized*` están poblados (no NULL) para registros con `contactType` 1, 2, 3
- [ ] Conversión epoch→DATE fue aplicada correctamente
- [ ] `cod_dw_ciudad` (DANE code) está como INTEGER, no VARCHAR
- [ ] `pin` está disponible como BIGINT (identificador de persona)

### Configuración de scripts

- [x] Mapping XPM → BDM: `Documentacion/ESTADO_COMPLETO_UNIFICACION_BDM.md`
- [x] Vistas + SPs QA: carpeta `sql/qa_ifr_data/`
- [ ] Validar tablas `ifr_data.xpm*` y columnas `val.*`
- [ ] Desplegar vía pipeline QA
- [ ] Smoke: `sql/qa_ifr_data/00_smoke_ifr_data.sql`
- [ ] Full: `08_ejecucion_secuencial.sql` o `02_unificacion_sql_plano.sql`

### Validación post-ejecución

- [ ] R1: Verificar pares padre-hijo generados tienen sentido (misma puerta, ≠ tipo uso)
- [ ] R2: Verificar que `complemento` no es NULL en los pares comparados
- [ ] R3: Verificar que `tipo_via_principal` y `via_generadora` no son NULL
- [ ] Ordenamiento: Verificar distribución de scores por canal (similar a validación sintética)

---

## 10. Ejemplo de Query — Leer datos reales de `ifr_data`

```sql
-- Verificar que los campos tokenizados existen y están poblados
SELECT
  rpu.cod_pin_persona,
  ue.texto_ubicacion,
  ue.texto_ubicacion_original,
  ue.score_estandarizacion,
  ue.cod_dw_ciudad,
  df.complemento,
  df.tipo_via_principal,
  df.via_principal,
  df.via_generadora,
  df.numero_puerta,
  rpu.cod_dw_tipo_ubicacion_dir
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ue
  ON rpu.cod_dw_ubic = ue.cod_dw_ubic
JOIN bdm_tempo.v_xpm_direccion_fisica df
  ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.cod_dw_tipo_ubicacion_dir IN (1, 2, 3)  -- Solo direcciones
  AND df.complemento IS NOT NULL
LIMIT 100;
```

---

## 11. Gaps Remanentes (post-tokenización)

| # | Campo | Estado | Impacto |
|---|-------|--------|---------|
| 1 | `latitud` / `longitud` | 🔴 Pendiente (Georreferenciación — Adriana Rondón) | R3 subcaso 3, Ordenamiento F3 |
| 2 | `bloqueado` (flag reclamación) | 🟡 Pendiente definición con Experian | Excluir datos bloqueados del proceso |
| 3 | `id_buro_persona` generación | ✅ Se genera en SPs de Redshift | Ya definido |

Todo lo demás está cubierto por el XPM con estandarización + catálogos vía Colibrí.

---

*Documento para uso del equipo de Cursor en Experian para configurar las tablas de Redshift QA apuntando a datos reales con tokenización.*
*Referencia: `Registro XPM Estandarización.json`, `xpm_john.json`, `Modelo de Datos XPM Redshift.pdf`*
