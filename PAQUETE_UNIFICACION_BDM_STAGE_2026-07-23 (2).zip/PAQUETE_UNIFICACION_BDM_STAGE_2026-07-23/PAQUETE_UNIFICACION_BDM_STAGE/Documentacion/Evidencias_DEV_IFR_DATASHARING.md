# Evidencias — DEV IFR Data Sharing (Reconocer)

**Ejecutado:** 2026-08-25T17:06:06.373593  
**Consumidor:** `eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com` / `dba_reconocerbatch`  
**Productor:** `eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com` / `dba_batch`  
**Usuario:** `c32525e`  

## Resumen ejecutivo

| Ítem | Estado |
|------|--------|
| IFR en productor DEV (`ifr_data.xpm*`) | ✅ Cargado (144 xpm) |
| Datashare `ds_reconocer_ifr_dev` publicado | ❌ Pendiente DBA |
| `db_ifr_shared` montado en Reconocer | ❌ No existe |
| Permisos `c32525e` CREATE schemas | ❌ `can_create_in_db=false` |
| Deploy local (bdm_datos, vistas, SPs) | ❌ Bloqueado por permisos |
| SPs R1/R2/R3 (qa_ifr_data) | ⏸ Listos en paquete, sin desplegar |

**Conclusión:** Paquete SQL y runner listos. Falta ticket DBA (datashare + grants). Tras eso, re-ejecutar runner.

## Preflight consumidor

### session
```json
[
  {
    "login_user": "c32525e",
    "db_name": "dba_reconocerbatch"
  }
]
```

### datashares
```json
[]
```

### external_dbs
```json
[]
```

### external_tables
```json
[]
```

### db_ifr_shared_exists
```json
[]
```

### ifr_count_xpm
```json
{
  "error": "\"db_ifr_shared\" does not exist\n"
}
```

### schemas_local
```json
[]
```

### perm_create_schema
```json
[
  {
    "can_create_in_db": true
  }
]
```

### procs
```json
[]
```

## Preflight productor DEV

- **producer_datashares:** `[]`
- **producer_share_objects:** `[]`
- **producer_ifr_local:** `[{"obj": "ifr_data.xpm", "n": 144}, {"obj": "ifr_data.xpm_location", "n": 133}]`

## Etapas ejecutadas

| Etapa | OK | Detalle |
|-------|-----|---------|

## Qué falta (gaps)

- BLOQUEANTE: ifr_count_xpm — "db_ifr_shared" does not exist

- BLOQUEANTE: svv_datashares vacío — DBA debe crear datashare y montar db_ifr_shared
- BLOQUEANTE: database db_ifr_shared no montada en consumidor
- Productor DEV: sin datashares publicados aún (ds_reconocer_ifr_dev pendiente DBA)

## Próximos pasos DBA

1. Productor DEV (`cee2enck00mg`): `CREATE DATASHARE ds_reconocer_ifr_dev` + ADD tablas `ifr_data.xpm*`.
2. GRANT namespace consumidor Reconocer (`pg_get_cluster_namespace()` en cz7jl1sn7m8z).
3. Consumidor: `CREATE DATABASE db_ifr_shared FROM DATASHARE ds_reconocer_ifr_dev`.
4. Ejecutar `sql/dev_ifr_datasharing/00_grants_dba_reconocer.sql` (schemas bdm_datos/bdm_tempo + SELECT datashare).
5. Re-ejecutar: `py -3 tools/dev_ifr_datasharing_run.py`.