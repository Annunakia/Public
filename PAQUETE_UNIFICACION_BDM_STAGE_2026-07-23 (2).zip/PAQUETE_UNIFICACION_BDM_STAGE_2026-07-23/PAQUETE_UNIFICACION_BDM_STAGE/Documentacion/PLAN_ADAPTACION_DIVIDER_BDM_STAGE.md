# Plan de Adaptacion a Divider / `bdm_stage` / Un Solo Redshift

## 1. Objetivo inmediato

Tomar la prueba que ya quedo funcional en Kidar y convertirla en una version mas simple y mas desplegable para el ambiente del cliente, con estas caracteristicas:

- un solo Redshift,
- ejecucion en Divider,
- esquemas ajustados a `bdm_stage` y/o esquemas del cliente,
- datos mock o sinteticos controlados,
- SQL plano ejecutable,
- y, si hace falta, separacion posterior en `SP1`, `SP2`, `SP3`.

La idea no es volver a inventar la logica. La logica ya existe y ya fue probada. Lo que toca ahora es **empaquetarla en la forma que el cliente espera para el ambiente actual**.

---

## 2. Lo que ya esta resuelto

Esto ya no hay que reconstruirlo desde cero:

### Base funcional ya validada

- Carga de datos mock / sinteticos.
- Escalamiento a `20K`.
- Regla 1.
- Regla 2.
- Regla 3.
- Validaciones finales.
- Stored procedure completo validado en runtime.

### Activos existentes en el repo

#### Datos mock / sinteticos

- `ws-unificacion/demo_data_sharing/datos_sinteticos_2k_01_ddl.sql`
- `ws-unificacion/demo_data_sharing/datos_sinteticos_2k_02_datos.sql`
- `ws-unificacion/demo_data_sharing/datos_sinteticos_2k_03_reportes.sql`
- `ws-unificacion/demo_data_sharing/datos_sinteticos_20k_01_ddl.sql`
- `ws-unificacion/demo_data_sharing/datos_sinteticos_20k_02_datos.sql`
- `ws-unificacion/demo_data_sharing/datos_sinteticos_20k_03_reportes.sql`
- `ws-unificacion/demo_data_sharing/generar_datos_sinteticos_2k.py`
- `ws-unificacion/demo_data_sharing/generar_datos_sinteticos_20k.py`

#### Reglas separadas en Redshift

- `ws-unificacion/src/redshift/sql/02_regla1_unificacion.sql`
- `ws-unificacion/src/redshift/sql/03_regla2_esc1_2.sql`
- `ws-unificacion/src/redshift/sql/04_regla2_esc4.sql`
- `ws-unificacion/src/redshift/sql/05_regla2_esc3_sin_nit.sql`
- `ws-unificacion/src/redshift/sql/06_motor_nuevas_direcciones.sql`
- `ws-unificacion/src/redshift/sql/07_regla2_esc3_nit.sql`
- `ws-unificacion/src/redshift/sql/08_regla2_esc5.sql`
- `ws-unificacion/src/redshift/sql/09_regla2_esc6.sql`
- `ws-unificacion/src/redshift/sql/10_regla3_geo.sql`

#### SP completo ya armado

- `ws-unificacion/demo_data_sharing/06_consumidor_sp_unificacion_completa.sql`

#### Version de referencia del proceso original

- `Experian Reconocer/Unificacion/DB/Unificacion.sql`

Este archivo es importante porque probablemente es lo mas parecido al "sql grande" del que hablan en la llamada.

---

## 3. Lo que SI toca hacer ahora

Con base en la llamada y en lo ya construido, el trabajo inmediato queda asi:

### Paso 1. Bajar la prueba de dos Redshift a una variante de un solo Redshift

No usar como base principal la version `cross-account` para este siguiente entregable.

La razon:

- en Kidar la prueba de data sharing sirvio para validar arquitectura avanzada,
- pero ahora el cliente te esta pidiendo avanzar mas rapido sobre un escenario mas simple,
- y en la llamada fue explicito que, para este punto, recomiendan usar una sola base Redshift.

### Paso 2. Ajustar esquema destino a `bdm_stage`

La llamada repite varias veces que el mismo codigo se puede llevar a Experian cambiando esquemas hacia `bdm_stage`.

Por tanto, hay que preparar una variante donde:

- tablas fuente mock queden en `bdm_stage`,
- staging temporal quede en `bdm_tempo` o equivalente del cliente,
- y resultados queden en el esquema que el cliente defina para salidas.

### Paso 3. Producir un SQL grande ejecutable en Divider

El primer entregable no deberia ser el SP.

El primer entregable deberia ser un archivo SQL plano que:

1. limpie objetos previos,
2. cree tablas necesarias,
3. cargue datos mock,
4. ejecute Regla 1,
5. ejecute Regla 2,
6. ejecute Regla 3,
7. ejecute validaciones.

Esto cuadra exactamente con lo que te dijeron: primero un SQL plano, luego si hace falta se separa.

### Paso 4. Separar por stored procedures despues

Una vez el SQL plano quede estable, separar la logica a:

- `SP1` -> Regla 1
- `SP2` -> Regla 2
- `SP3` -> Regla 3

y eventualmente un `SP_MASTER` o ejecucion manual secuencial.

### Paso 5. Preparar validaciones

No basta con ejecutar. Hay que dejar validaciones del tipo:

- conteos de carga,
- conteos por regla,
- validaciones por escenario,
- total final esperado.

---

## 4. Entregables concretos que conviene producir

Esta es la lista exacta de archivos que recomiendo producir para este frente.

## 4.1 Entregable minimo viable

### `01_bdm_stage_mock_setup.sql`

Debe contener:

- `DROP` / limpieza controlada
- `CREATE SCHEMA IF NOT EXISTS bdm_stage`
- `CREATE TABLE` de las tablas fuente necesarias
- carga de datos mock o sinteticos

Fuente base recomendada:

- `ws-unificacion/demo_data_sharing/datos_sinteticos_20k_01_ddl.sql`
- `ws-unificacion/demo_data_sharing/datos_sinteticos_20k_02_datos.sql`
- `ws-unificacion/demo_data_sharing/datos_sinteticos_20k_03_reportes.sql`

### `02_unificacion_sql_plano.sql`

Debe contener la logica secuencial completa:

- Regla 1
- Regla 2
- Regla 3

Debe leer desde `bdm_stage` y no desde `db_productor_reconocer`.

Fuente base recomendada:

- `ws-unificacion/demo_data_sharing/06_consumidor_sp_unificacion_completa.sql`

Adaptacion requerida:

- quitar encapsulamiento `CREATE OR REPLACE PROCEDURE`
- reemplazar referencias `db_productor_reconocer.bdm_datos.*`
  por `bdm_stage.*` o la capa local equivalente
- conservar el orden de ejecucion ya validado

### `03_validaciones_unificacion.sql`

Debe contener:

- conteos por tabla cargada,
- conteos por `unifica_atributos`,
- total final esperado,
- validaciones por escenario si hace falta

Fuente base recomendada:

- `ws-unificacion/demo_data_sharing/04_validacion_data_sharing.sql`
- `ws-unificacion/demo_data_sharing/ESTADO_ACTUAL.md`

### `04_cleanup.sql`

Debe dejar el ambiente listo para repetir la prueba.

Debe incluir:

- `DROP TABLE IF EXISTS ...`
- `TRUNCATE` donde aplique
- limpieza de staging y resultados

Fuente base recomendada:

- `ws-unificacion/demo_data_sharing/05_cleanup.sql`

---

## 4.2 Entregable siguiente

Cuando el SQL plano ya este estable:

### `05_sp_regla1.sql`

Basado en:

- `ws-unificacion/src/redshift/sql/02_regla1_unificacion.sql`

### `06_sp_regla2.sql`

Basado en:

- `03_regla2_esc1_2.sql`
- `04_regla2_esc4.sql`
- `05_regla2_esc3_sin_nit.sql`
- `07_regla2_esc3_nit.sql`
- `08_regla2_esc5.sql`
- `09_regla2_esc6.sql`

### `07_sp_regla3.sql`

Basado en:

- `ws-unificacion/src/redshift/sql/10_regla3_geo.sql`

### `08_ejecucion_secuencial.sql`

Debe contener algo como:

```sql
CALL bdm_stage.sp_unificacion_regla1();
CALL bdm_stage.sp_unificacion_regla2();
CALL bdm_stage.sp_unificacion_regla3();
```

o los `CALL` en el esquema final que defina el cliente.

---

## 4.3 Entregable de empaque para cliente

Cuando ya exista una version estable en SQL plano o SPs, empaquetarla siguiendo el estandar del cliente:

### Estructura sugerida

```text
PAQUETE_UNIFICACION_BDM_STAGE/
|-- deploy_order.par
|-- Documentacion/
|   |-- GUIA_INSTALACION.md
|   |-- INDICE_COMPLETO.md
|   `-- PAQUETE_UNIFICACION_BDM_STAGE.yml
|-- sql/
|   |-- 01_bdm_stage_mock_setup.sql
|   |-- 02_unificacion_sql_plano.sql
|   |-- 03_validaciones_unificacion.sql
|   `-- 04_cleanup.sql
`-- rev-sql/
    |-- 04_rollback_cleanup.sql
    |-- 03_rollback_validaciones.sql
    |-- 02_rollback_unificacion.sql
    `-- 01_rollback_mock_setup.sql
```

Si luego se migra a SPs, la carpeta `sql/` puede quedar asi:

```text
sql/
|-- 01_bdm_stage_mock_setup.sql
|-- 02_sp_regla1.sql
|-- 03_sp_regla2.sql
|-- 04_sp_regla3.sql
|-- 05_ejecucion_secuencial.sql
|-- 06_validaciones_unificacion.sql
`-- 07_cleanup.sql
```

---

## 5. Mapeo exacto entre lo que ya existe y lo que hay que sacar

| Nuevo archivo objetivo | Base recomendada |
|---|---|
| `01_bdm_stage_mock_setup.sql` | `datos_sinteticos_20k_01_ddl.sql`, `datos_sinteticos_20k_02_datos.sql`, `datos_sinteticos_20k_03_reportes.sql` |
| `02_unificacion_sql_plano.sql` | `06_consumidor_sp_unificacion_completa.sql` |
| `03_validaciones_unificacion.sql` | `04_validacion_data_sharing.sql` + resultados de `ESTADO_ACTUAL.md` |
| `04_cleanup.sql` | `05_cleanup.sql` |
| `05_sp_regla1.sql` | `02_regla1_unificacion.sql` |
| `06_sp_regla2.sql` | `03` a `09` de `src/redshift/sql/` |
| `07_sp_regla3.sql` | `10_regla3_geo.sql` |
| `08_ejecucion_secuencial.sql` | nuevo archivo simple con `CALL` o secuencia SQL |

---

## 6. Orden exacto recomendado de trabajo

Este es el orden que mas sentido tiene para no perder tiempo:

1. Identificar el "sql grande" de referencia real.
   Prioridad:
   - `Experian Reconocer/Unificacion/DB/Unificacion.sql`
   - comparar contra `06_consumidor_sp_unificacion_completa.sql`

2. Construir `01_bdm_stage_mock_setup.sql`.

3. Construir `02_unificacion_sql_plano.sql` usando como base el SP completo ya validado.

4. Construir `03_validaciones_unificacion.sql`.

5. Probar todo en un solo Redshift con `bdm_stage`.

6. Solo despues separar en `SP1`, `SP2`, `SP3`.

7. Finalmente empaquetar bajo el estandar del cliente.

---

## 7. Decisiones practicas recomendadas

### Decision 1

No empezar separando en stored procedures.

Primero:

- SQL plano grande
- prueba funcional
- validaciones

Despues:

- SPs individuales

### Decision 2

Usar como base funcional principal:

- `06_consumidor_sp_unificacion_completa.sql`

porque ya fue validado en runtime y ya concentra el flujo que dio:

- `R1 = 3400`
- `R2 = 5600`
- `R3 = 717`
- `TOTAL = 9717`

### Decision 3

Usar el "sql grande" original como referencia funcional y de estilo, pero no como unica fuente de verdad.

La fuente de verdad operativa hoy es la version que ya corrio correctamente en Redshift.

### Decision 4

Para el frente actual, tratar `data sharing` como antecedente tecnico, no como dependencia de ejecucion.

Eso significa:

- no borrarlo,
- no descartarlo,
- pero tampoco obligarte a montarlo en este siguiente paso si el cliente aun esta probando sobre un solo Redshift.

---

## 8. Resultado esperado de este frente

Si esto se hace bien, al final deberias tener:

- un SQL grande ejecutable en Divider,
- apuntando a `bdm_stage`,
- que cree / cargue datos mock,
- ejecute R1, R2 y R3,
- devuelva validaciones,
- y quede listo para separarse en stored procedures.

En una frase:

> Lo que toca no es volver a demostrar la logica; lo que toca es empaquetar la logica ya probada en el formato operativo que el cliente necesita ahora.

---

## 9. Siguiente accion concreta

La siguiente accion recomendada es esta:

1. abrir `Experian Reconocer/Unificacion/DB/Unificacion.sql`
2. compararlo contra `ws-unificacion/demo_data_sharing/06_consumidor_sp_unificacion_completa.sql`
3. producir una primera version de:
   - `01_bdm_stage_mock_setup.sql`
   - `02_unificacion_sql_plano.sql`
   - `03_validaciones_unificacion.sql`

Ese seria el siguiente entregable real de trabajo.
