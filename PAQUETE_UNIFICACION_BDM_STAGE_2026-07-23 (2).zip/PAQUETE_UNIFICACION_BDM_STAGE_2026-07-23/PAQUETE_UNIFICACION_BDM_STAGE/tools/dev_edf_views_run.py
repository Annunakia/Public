"""Deploy + run Unificación R1/R2/R3 on procesosbatch DEV using edf_views."""
from __future__ import annotations

import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path

import psycopg2
from psycopg2.extras import RealDictCursor

ROOT = Path(__file__).resolve().parents[1]
EDF_SQL = ROOT / "sql" / "dev_edf_views"
QA_SQL = ROOT / "sql" / "qa_ifr_data"
DOC_OUT = ROOT / "Documentacion" / "Evidencias_DEV_EDF_VIEWS_RUN.md"

HOST = os.environ.get(
    "REDSHIFT_HOST",
    "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com",
)
PORT = int(os.environ.get("REDSHIFT_PORT", "5440"))
DB = os.environ.get("REDSHIFT_DB", "dba_batch")
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PASSWORD = os.environ.get("REDSHIFT_PASSWORD", "")

STAGES = [
    ("ddl", QA_SQL / "01_ddl_unificacion_direccion.sql"),
    ("vistas", EDF_SQL / "00_vistas_insumo_bdm.sql"),
    ("smoke", EDF_SQL / "00_validar_solo_lectura_edf_views.sql"),
    ("deploy_sp_r1", QA_SQL / "05_sp_regla1.sql"),
    ("deploy_sp_r2", QA_SQL / "06_sp_regla2.sql"),
    ("deploy_sp_r3", QA_SQL / "07_sp_regla3.sql"),
    ("execute", QA_SQL / "08_ejecucion_secuencial.sql"),
    ("validaciones", QA_SQL / "03_validaciones_unificacion.sql"),
]


def split_sql(text: str) -> list[str]:
    parts = re.split(r";\s*\n", text)
    out = []
    for p in parts:
        stmt = p.strip()
        if not stmt:
            continue
        lines = [ln for ln in stmt.splitlines() if ln.strip() and not ln.strip().startswith("--")]
        if not lines:
            continue
        out.append(stmt if stmt.endswith(";") else stmt + ";")
    return out


def rows_to_dicts(cur) -> list[dict]:
    if not cur.description:
        return []
    rows = cur.fetchall()
    if rows and hasattr(rows[0], "keys"):
        return [dict(r) for r in rows]
    cols = [d[0] for d in cur.description]
    return [dict(zip(cols, r)) for r in rows]


def run_file(cur, path: Path, label: str) -> dict:
    sql = path.read_text(encoding="utf-8")
    if label.startswith("deploy_sp") or label in ("ddl", "vistas"):
        try:
            cur.execute(sql)
            return {"label": label, "file": path.name, "ok": True, "error": None}
        except Exception as e:
            cur.connection.rollback()
            return {"label": label, "file": path.name, "ok": False, "error": str(e)}
    errors = []
    result_sets = []
    for stmt in split_sql(sql):
        try:
            cur.execute(stmt)
            if cur.description:
                result_sets.append({"statement": stmt[:180], "rows": rows_to_dicts(cur)})
        except Exception as e:
            cur.connection.rollback()
            errors.append({"statement": stmt[:180], "error": str(e)})
    return {
        "label": label,
        "file": path.name,
        "ok": len(errors) == 0,
        "errors": errors,
        "result_sets": result_sets,
    }


def summary_query(cur) -> list[dict]:
    cur.execute("""
        SELECT unifica_atributos, COUNT(*) AS n
        FROM bdm_datos.unificacion_direccion
        GROUP BY 1 ORDER BY 1
    """)
    return rows_to_dicts(cur)


def main() -> int:
    if not PASSWORD:
        print("Set REDSHIFT_PASSWORD", file=sys.stderr)
        return 1

    log: list[dict] = []
    conn = psycopg2.connect(
        host=HOST, port=PORT, dbname=DB, user=USER, password=PASSWORD,
        sslmode="require", connect_timeout=60,
    )
    conn.autocommit = True
    cur = conn.cursor(cursor_factory=RealDictCursor)

    print(f"Target: {HOST} / {DB} — fuente edf_views")
    for label, path in STAGES:
        print(f"  [{label}] {path.name} ...", end=" ", flush=True)
        if not path.exists():
            r = {"label": label, "ok": False, "error": f"missing {path}"}
            log.append(r)
            print("MISSING")
            break
        r = run_file(cur, path, label)
        log.append(r)
        print("OK" if r.get("ok") else "FAIL")
        if not r.get("ok"):
            print("  ", r.get("error") or r.get("errors"))
            break

    summary = []
    try:
        summary = summary_query(cur)
        print("\nResultado unificacion_direccion:")
        for row in summary:
            print(f"  regla {row['unifica_atributos']}: {row['n']}")
    except Exception as e:
        summary = [{"error": str(e)}]

    cur.close()
    conn.close()

    md = [
        f"# Evidencias — Unificación DEV con edf_views\n",
        f"Fecha: {datetime.now().isoformat(timespec='seconds')}\n",
        f"Cluster: `{HOST}` / `{DB}`\n\n",
        "## Stages\n\n",
    ]
    for r in log:
        md.append(f"- **{r['label']}**: {'OK' if r.get('ok') else 'FAIL'}\n")
        if r.get("error"):
            md.append(f"  - error: `{r['error'][:500]}`\n")
        if r.get("errors"):
            for e in r["errors"][:3]:
                md.append(f"  - `{e['error'][:300]}`\n")
        if r.get("result_sets") and r["label"] == "smoke":
            md.append("\n### Smoke\n```json\n")
            md.append(json.dumps(r["result_sets"][0]["rows"], indent=2, default=str))
            md.append("\n```\n")

    md.append("\n## Resumen salida\n```json\n")
    md.append(json.dumps(summary, indent=2, default=str))
    md.append("\n```\n")
    DOC_OUT.write_text("".join(md), encoding="utf-8")
    print(f"\nReport: {DOC_OUT}")
    return 0 if all(x.get("ok") for x in log) else 1


if __name__ == "__main__":
    raise SystemExit(main())
