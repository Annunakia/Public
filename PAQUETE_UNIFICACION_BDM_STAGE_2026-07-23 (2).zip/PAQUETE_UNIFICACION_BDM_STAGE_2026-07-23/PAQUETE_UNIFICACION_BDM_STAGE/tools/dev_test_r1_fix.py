"""Deploy fixed R1 SP, reset R1 state, rerun and validate TC-R1-04 / TC-R1-08."""
import os
import sys
from pathlib import Path

import psycopg2

HOST = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
PWD = os.environ.get("REDSHIFT_PASSWORD", "")
ROOT = Path(__file__).resolve().parents[1]


def main():
    if not PWD:
        print("Set REDSHIFT_PASSWORD")
        sys.exit(1)
    conn = psycopg2.connect(
        host=HOST, port=5440, dbname="dba_batch", user="c32525e",
        password=PWD, sslmode="require", connect_timeout=60,
    )
    conn.autocommit = True
    cur = conn.cursor()

    sp_sql = (ROOT / "sql" / "05_sp_regla1.sql").read_text(encoding="utf-8")
    cur.execute(sp_sql)
    print("DEPLOY OK")

    cur.execute("DELETE FROM bdm_stage.unificacion_direccion WHERE unifica_atributos = 1")
    print("deleted_r1_unif", cur.rowcount)

    cur.execute("""
        UPDATE bdm_stage.relacion_persona_ubicacion r
        SET ind_unificacion = NULL
        FROM bdm_stage.perf_persona_meta m
        WHERE m.id_buro_persona = r.id_buro_persona
          AND m.scenario_code <> 'R1_HIJA'
          AND r.ind_unificacion = 1
    """)
    print("reset_ind", cur.rowcount)

    cur.execute("CALL bdm_stage.sp_unificacion_regla1()")
    print("CALL R1 OK")

    checks = [
        ("TC-R1-04", """
            SELECT COUNT(*) FROM bdm_stage.unificacion_direccion u
            JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
            WHERE u.unifica_atributos = 1 AND COALESCE(r.ind_unificacion, 0) <> 1
        """),
        ("TC-R1-08", """
            SELECT COUNT(*) FROM bdm_stage.perf_persona_meta m
            JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
            JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic
            WHERE m.scenario_code = 'R1_EMPATE' AND u.unifica_atributos = 1
        """),
        ("R1_total", "SELECT COUNT(*) FROM bdm_stage.unificacion_direccion WHERE unifica_atributos = 1"),
    ]
    for name, sql in checks:
        cur.execute(sql)
        print(name, cur.fetchone()[0])

    cur.close()
    conn.close()


if __name__ == "__main__":
    main()
