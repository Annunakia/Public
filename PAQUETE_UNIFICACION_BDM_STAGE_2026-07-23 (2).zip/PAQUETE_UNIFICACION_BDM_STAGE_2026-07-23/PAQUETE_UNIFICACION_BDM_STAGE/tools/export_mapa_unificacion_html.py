"""Genera dashboard HTML interactivo — workflow Prezi + tema claro."""
from __future__ import annotations

import json
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "Documentacion" / "MAPA_UNIFICACION_EDF_VIEWS_NEGOCIO.html"
VOLUMENES = ROOT / "Documentacion" / "drill_down_volumenes.json"

sys.path.insert(0, str(ROOT / "tools"))
from export_mapa_unificacion_xlsx import (  # noqa: E402
    HEADERS,
    build_rows,
    ids_from_samples,
    load_samples,
    refresh_samples,
)
from mapa_narrativa import html_show_query  # noqa: E402
from mapa_escenario_tablas import pack_for_row  # noqa: E402
from mapa_profiling_tablas import pack_for_prof, prof_codigo, prof_titulo_nav  # noqa: E402
from mapa_unificacion_sps import (  # noqa: E402
    SP_POR_ESCENARIO,
    SP_R1_ESC1,
    SP_R1_ESC2,
    SP_R1_ESC3,
    SP_R2_ESC12,
    SP_R2_ESC3,
    SP_R2_ESC4,
    SP_R2_ESC5,
    SP_R2_ESC6,
    SP_R2_MOTOR,
    SP_R3_ESC1,
    build_repos_bitbucket,
    build_sps_detalle,
)


def load_volumenes() -> dict:
    if not VOLUMENES.exists():
        return {"universo": {}, "filas": [], "map": {}}
    data = json.loads(VOLUMENES.read_text(encoding="utf-8"))
    data["map"] = {(f["regla"], f["codigo"]): f for f in data.get("filas", [])}
    return data


def vol_key(regla: str, esc_codigo: str, sub: str) -> tuple[str, str] | None:
    if regla == "PUNTO DE PARTIDA":
        if esc_codigo == "TEMA" and "Activas" in sub:
            return ("UNIVERSO", "POST-R2")
        if esc_codigo == "TEMA":
            return ("UNIVERSO", "TEMA")
    if regla == "R1":
        if esc_codigo == "PRE-R1" and "no entran" in sub.lower():
            return ("R1", "PRE-R1-FUERA")
        if esc_codigo == "PRE-R1":
            return ("R1", "PRE-R1")
        if esc_codigo in ("ESC1", "ESC2", "ESC3", "EMPATE", "SALIDA", "INSUMO"):
            return ("R1", esc_codigo)
    if regla == "R2":
        if esc_codigo in ("ESC1", "ESC2", "ESC3", "ESC4", "ESC5", "ESC6", "MOTOR", "SIN PAR", "SALIDA", "INSUMO"):
            return ("R2", esc_codigo)
    if regla == "R3":
        if esc_codigo == "PRE-R3":
            return ("R3", "PRE-R3")
        if esc_codigo == "ESC1":
            return ("R3", "ESC1")
        if esc_codigo == "SALIDA":
            return ("R3", "SALIDA")
    return None


def attach_volumenes(d: dict, vol: dict) -> None:
    key = vol_key(d.get("_regla", ""), d.get("_esc_codigo", ""), d.get("Subescenario", ""))
    if not key:
        return
    f = vol.get("map", {}).get(key)
    if not f:
        return
    d["_personas"] = f["personas"]
    d["_rpus"] = f["rpus"]
    d["_rpuxp"] = f.get("rpuxp")
    if f.get("busca"):
        d["_vol_busca"] = f["busca"]


def attach_escenario_tablas(d: dict, vol: dict, samples: dict) -> None:
    regla = d.get("_regla", "")
    if regla == "PERFIL DE DATOS":
        esc = d.get("Escenario", "")
        pack = pack_for_prof(esc, samples)
        if not pack:
            return
        d["_tabla_ejemplo"] = pack.get("ejemplo")
        d["_tabla_pasos"] = pack.get("ejemplo_pasos")
        d["_conclusion_regla"] = pack.get("conclusion", "")
        if pack.get("busca"):
            d["_busca"] = pack["busca"]
        d["_esc_codigo"] = prof_codigo(esc)
        tit = prof_titulo_nav(esc)
        d["_titulo_corto"] = tit.split(" · ", 1)[1] if " · " in tit else tit
        return
    if regla not in ("R1", "R2", "R3"):
        return
    key = vol_key(regla, d.get("_esc_codigo", ""), d.get("Subescenario", ""))
    codigo = key[1] if key else d.get("_esc_codigo", "")
    pack = pack_for_row(regla, codigo, vol, samples)
    if not pack:
        return
    d["_tabla_ejemplo"] = pack.get("ejemplo")
    d["_tabla_pasos"] = pack.get("ejemplo_pasos")
    d["_tabla_dev"] = pack.get("resultado_dev")
    d["_conclusion_regla"] = pack.get("conclusion", "")
    if pack.get("dev_text"):
        d["_dev"] = pack["dev_text"]
    if pack.get("busca"):
        d["_busca"] = pack["busca"]
        d["_vol_busca"] = pack["busca"]


def row_dict(cells: list, vol: dict | None = None, samples: dict | None = None) -> dict:
    d = {HEADERS[i]: cells[i] if i < len(cells) else "" for i in range(len(HEADERS))}
    regla = str(d.get("Regla", "")).replace("▶ ", "").strip()
    d["_regla"] = regla
    d["_section"] = str(cells[0]).startswith("▶")
    d["_busca"] = d.get("Qué espera (negocio)", "")
    d["_dev"] = d.get("Qué encontramos DEV", "")
    d["_conclusion"] = d.get("Ejemplo verificable (reporte + ID + query)", "")
    d["_show_query"] = html_show_query(
        regla,
        d.get("Escenario", ""),
        d.get("Subescenario", ""),
        d.get("Estado", ""),
        d.get("Query validación (copiar en dba_rncr_batch)", ""),
    )
    d["_esc_codigo"] = _esc_codigo(regla, d.get("Escenario", ""), d.get("Subescenario", ""))
    d["_titulo_corto"] = _titulo_corto(d["_esc_codigo"], d.get("Subescenario", ""))
    if vol:
        attach_volumenes(d, vol)
    if vol and samples:
        attach_escenario_tablas(d, vol, samples)
    return d


def _titulo_corto(codigo: str, sub: str) -> str:
    for sep in (" · ", " — ", " - "):
        if sep in sub and sub.split(sep, 1)[0].strip().upper().replace(" ", "") == codigo.replace(" ", ""):
            return sub.split(sep, 1)[1].strip()
        if sub.startswith(codigo + sep):
            return sub[len(codigo) + len(sep) :].strip()
    return sub


def _esc_codigo(regla: str, escenario: str, sub: str) -> str:
    if escenario.startswith("ESC") and escenario != "ESC único":
        return escenario
    if escenario == "ESC único":
        return "ESC1"
    if escenario == "Motor":
        return "MOTOR"
    if escenario == "Política":
        return "EMPATE"
    if escenario == "TOTAL":
        return "SALIDA"
    if escenario == "Propósito":
        return "RESUMEN"
    if escenario == "Insumo":
        return "INSUMO"
    if escenario == "Pre-candidato":
        return "PRE-R1" if regla == "R1" else "PRE"
    if escenario == "Pre-requisito":
        return "PRE-R3"
    if escenario == "Remanente":
        return "SIN PAR"
    if regla == "PERFIL DE DATOS":
        if escenario == "Propósito":
            return "RESUMEN"
        if escenario == "Vista":
            return "REVISAR"
        if escenario in (
            "Complemento",
            "Texto",
            "Geo",
            "CIIU",
            "Puntaje",
            "DANE",
            "Tipo contacto",
        ):
            return prof_codigo(escenario)
    if escenario in ("Definición", "Waterfall"):
        return "TEMA"
    return escenario or "—"


def kpis(samples: dict, vol: dict | None = None) -> dict:
    ids = ids_from_samples(samples)
    u = (samples.get("univ") or [{}])[0] if isinstance(samples.get("univ"), list) else {}
    r2 = samples.get("r2_total", {}).get("n", 72448)
    rpus = int(u.get("rpus", 591166))
    r1_c = (samples.get("r1_cand") or [{}])[0]
    if isinstance(samples.get("r1_cand"), dict):
        r1_c = samples["r1_cand"]
    post = rpus - int(r2)
    if vol and vol.get("map"):
        post_row = vol["map"].get(("UNIVERSO", "POST-R2"), {})
        post = int(post_row.get("rpus", post))
    return {
        "rpus": rpus,
        "personas": int(u.get("personas", 407351)),
        "ubics": int(u.get("ubicaciones", 0)),
        "r1_out": 0,
        "r2_out": int(r2),
        "r3_out": 0,
        "post_r2": post,
        "r1_personas": int(r1_c.get("personas", 156)),
        "r1_grupos": int(r1_c.get("grupos", 2074)),
        "r1_rpus": int(r1_c.get("rpus", 2441)),
        "pid": ids.get("pid"),
        "hija_rpu": ids.get("hija"),
        "padre_rpu": ids.get("padre"),
    }


def render_html(payload: dict) -> str:
    data_json = json.dumps(payload, ensure_ascii=False)
    today = date.today().isoformat()
    return f"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Unificación edf_views — mapa DEV (15 SPs por escenario)</title>
<style>
:root {{
  --bg: #f4f6f9;
  --white: #ffffff;
  --text: #1a2332;
  --muted: #5c6b7a;
  --line: #dde3ea;
  --accent: #1d6fdc;
  --accent-soft: #e8f1fc;
  --ok: #0d9f6e;
  --ok-soft: #e6f7f1;
  --warn: #c27803;
  --warn-soft: #fef6e6;
  --block: #c0392b;
  --block-soft: #fdecea;
  --shadow: 0 8px 32px rgba(26,35,50,0.08);
  --radius: 16px;
  --sans: "Segoe UI", system-ui, sans-serif;
  --mono: Consolas, "Cascadia Code", monospace;
  --topbar-h: 38px;
  --footer-h: 0px;
  --header-h: 52px;
  --scenario-nav-w: 96px;
}}
* {{ box-sizing: border-box; margin: 0; padding: 0; }}
html, body {{ height: 100%; overflow: hidden; }}
body {{ font-family: var(--sans); background: var(--bg); color: var(--text); }}

/* Header: título + pasos horizontales */
.app-header {{
  position: fixed; top: 0; left: 0; right: 0; z-index: 100;
  height: var(--header-h); background: var(--white); border-bottom: 1px solid var(--line);
  display: flex; align-items: center; gap: 0.65rem;
  padding: 0 0.65rem 0 0.55rem;
}}
.app-header h1 {{
  font-size: 1.05rem; font-weight: 800; flex-shrink: 0;
  padding-right: 0.65rem; margin-right: 0.15rem;
  border-right: 1px solid var(--line); line-height: 1;
}}
.step-nav {{
  flex: 1; display: flex; align-items: center; gap: 0.3rem;
  overflow-x: auto; min-width: 0;
}}
.step-btn {{
  padding: 0.32rem 0.75rem; border-radius: 999px;
  border: 1px solid var(--line); background: var(--bg);
  font-size: 0.72rem; font-weight: 600; color: var(--muted);
  cursor: pointer; white-space: nowrap; font-family: inherit;
  transition: all 0.15s;
}}
.step-btn:hover {{ border-color: var(--accent); color: var(--accent); background: var(--accent-soft); }}
.step-btn.active {{
  background: var(--accent); color: #fff; border-color: var(--accent);
  box-shadow: 0 2px 8px rgba(29,111,220,0.25);
}}
.header-meta {{
  font-size: 0.62rem; color: var(--muted); white-space: nowrap; flex-shrink: 0;
}}
.progress {{ flex: 0 0 64px; height: 3px; background: var(--line); border-radius: 2px; overflow: hidden; }}
.progress i {{ display: block; height: 100%; background: var(--accent); width: 0%; transition: width 0.5s; }}
.rail {{ display: none; }}

/* Viewport a pantalla completa bajo header */
.viewport {{
  position: fixed; left: 0; top: var(--header-h); right: 0; bottom: 0;
  overflow: hidden; background: var(--bg);
}}
.canvas {{
  position: relative; width: 100%; height: 100%;
}}
.frame {{
  position: absolute; inset: 0;
  width: 100%; height: 100%;
  background: var(--white);
  border: none; border-radius: 0; box-shadow: none;
  padding: 0;
  display: none;
  flex-direction: column;
  overflow: hidden;
}}
.frame.frame-on {{
  display: flex;
  visibility: visible; opacity: 1; pointer-events: auto;
}}
.frame.frame-off {{
  display: none;
  visibility: hidden; opacity: 0; pointer-events: none;
}}
.frame-fit {{
  flex: 1; min-height: 0; width: 100%;
  display: flex; flex-direction: column;
  padding: 0.35rem 0.55rem 0.2rem;
  overflow: hidden;
}}
#frame-home .frame-fit {{
  display: block;
  overflow-x: hidden;
  overflow-y: auto;
  padding: 0.45rem 0.75rem 0.35rem;
  max-width: none;
  margin: 0;
  width: 100%;
}}
.frame-fit.rule-frame {{
  padding: 0.15rem 0.45rem 0.1rem 0;
}}
.frame-fit.rule-frame .frame-title,
.frame-fit.rule-frame .frame-sub,
.frame-fit.rule-frame .rule-nav-hint {{ display: none; }}
.drill-section {{
  margin-bottom: 1.75rem;
  clear: both;
}}
.drill-section-title {{
  font-size: 0.88rem;
  font-weight: 700;
  color: var(--text);
  margin-bottom: 0.65rem;
  padding-bottom: 0.35rem;
  border-bottom: 2px solid var(--accent-soft);
}}
.drill-section-note {{
  font-size: 0.75rem;
  color: var(--muted);
  line-height: 1.45;
  margin-bottom: 0.75rem;
}}
.frame-title {{ font-size: clamp(0.95rem, 1.6vw, 1.2rem); font-weight: 700; margin-bottom: 0.1rem; letter-spacing: -0.02em; flex-shrink: 0; line-height: 1.2; }}
.frame-sub {{ color: var(--muted); font-size: 0.72rem; margin-bottom: 0.35rem; flex-shrink: 0; line-height: 1.3; }}

/* Home frame layout */
.kpi-row {{ display: grid; grid-template-columns: repeat(5, 1fr); gap: 0.75rem; flex-shrink: 0; }}
#frame-home .kpi-row {{ margin-bottom: 0; }}
.kpi {{
  background: var(--bg); border: 1px solid var(--line); border-radius: 10px;
  padding: 0.65rem 0.5rem; text-align: center;
}}
.kpi b {{ display: block; font-size: clamp(1rem, 2vw, 1.35rem); color: var(--accent); margin: 0.15rem 0; }}
.kpi small {{ font-size: 0.72rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.05em; }}
.kpi span {{ font-size: 0.8rem; color: var(--muted); }}

.flow-interactive {{
  display: flex; align-items: stretch; gap: 0; margin: 0.5rem 0;
  background: var(--bg); border-radius: 12px; border: 1px solid var(--line); overflow: hidden;
  flex-shrink: 0;
}}
.flow-node {{
  flex: 1; padding: 0.75rem 0.5rem; text-align: center; cursor: pointer;
  border-right: 1px solid var(--line); transition: background 0.2s;
}}
.flow-node:last-child {{ border-right: none; }}
.flow-node:hover {{ background: var(--accent-soft); }}
.flow-node strong {{ display: block; font-size: 1.25rem; color: var(--accent); }}
.flow-node em {{ display: block; font-style: normal; font-size: 0.75rem; color: var(--muted); margin-top: 0.35rem; }}
.flow-arrow-box {{ display: flex; align-items: center; padding: 0 0.25rem; color: var(--muted); font-size: 1.2rem; }}

.rules-map {{
  display: grid; grid-template-columns: repeat(4, 1fr); gap: 0.45rem;
  margin-bottom: 0.65rem; flex-shrink: 0;
}}
.rules-card {{
  background: var(--bg); border: 1px solid var(--line); border-radius: 10px;
  padding: 0.6rem 0.7rem; cursor: pointer; transition: all 0.15s;
}}
.rules-card:hover {{ border-color: var(--accent); background: var(--accent-soft); }}
.rules-card h3 {{ font-size: 0.76rem; font-weight: 700; color: var(--accent); margin-bottom: 0.3rem; line-height: 1.25; }}
.rules-card .esc-tag {{
  font-size: 0.62rem; font-weight: 600; color: var(--warn); background: var(--warn-soft);
  display: inline-block; padding: 0.1rem 0.35rem; border-radius: 4px; margin-bottom: 0.25rem;
}}
.rules-card p {{ font-size: 0.66rem; color: var(--muted); line-height: 1.35; }}
.rules-card b {{ display: block; font-size: 0.72rem; color: var(--text); margin-top: 0.3rem; }}

.btn {{
  display: inline-flex; align-items: center; gap: 0.4rem;
  padding: 0.55rem 1rem; border-radius: 10px; font-size: 0.85rem; font-weight: 600;
  border: 1px solid var(--line); background: var(--white); cursor: pointer;
  transition: all 0.15s; font-family: inherit;
}}
.btn:hover {{ border-color: var(--accent); color: var(--accent); }}
.btn-primary {{ background: var(--accent); color: #fff; border-color: var(--accent); }}
.btn-primary:hover {{ background: #1558b0; color: #fff; }}
.btn-query {{
  background: var(--accent-soft); color: var(--accent); border-color: #b8d4f5;
  padding: 0.65rem 1.1rem; font-size: 0.88rem;
}}
.btn-query:hover {{ background: var(--accent); color: #fff; }}

/* Rule frames — índice lateral + escenario ancho completo */
.rule-frame {{
  display: flex; flex-direction: column; min-height: 0; flex: 1; height: 100%;
}}
.rule-layout {{
  flex: 1; min-height: 0;
  display: grid;
  grid-template-columns: var(--scenario-nav-w) minmax(0, 1fr);
  gap: 0.25rem;
  overflow: hidden;
}}
.scenario-nav {{
  overflow-y: auto; min-height: 0;
  border: none; border-right: 1px solid var(--line); border-radius: 0;
  background: transparent; padding: 0.1rem 0.15rem 0.1rem 0.05rem;
}}
.scenario-nav-item {{
  display: block; width: 100%; text-align: left;
  padding: 0.18rem 0.22rem; margin-bottom: 0.1rem;
  border: 1px solid transparent; border-radius: 4px;
  background: transparent; cursor: pointer; font-family: inherit;
}}
.scenario-nav-item:last-child {{ margin-bottom: 0; }}
.scenario-nav-item:hover {{ background: var(--accent-soft); border-color: #c5daf5; }}
.scenario-nav-item.active {{
  background: var(--accent-soft); border-color: var(--accent);
}}
.scenario-nav-item .nav-code {{
  font-size: 0.58rem; font-weight: 800; color: var(--accent); display: block; line-height: 1.2;
}}
.scenario-nav-item .nav-title {{ display: none; }}
.scenario-stage {{
  overflow: hidden; min-height: 0; min-width: 0;
  padding-right: 0.25rem;
  display: flex; align-items: flex-start;
}}
.scenario-stage .scenario-item {{
  width: 100%;
  transform-origin: top left;
}}
.frame-fit.rule-frame .scenario-body {{
  display: grid;
  grid-template-columns: 1fr;
  gap: 0.35rem;
  align-content: start;
}}
.frame-fit.rule-frame .scenario-body > .scenario-head,
.frame-fit.rule-frame .scenario-body > .scenario-section,
.frame-fit.rule-frame .scenario-body > .tbl-block-full,
.frame-fit.rule-frame .scenario-body > .tbl-block-ej-full {{
  grid-column: 1 / -1;
}}
.frame-fit.rule-frame .tbl-block-ej-full .scenario-table {{
  width: 100%;
  table-layout: auto;
}}
.frame-fit.rule-frame .tbl-block-ej-full .scenario-table th,
.frame-fit.rule-frame .tbl-block-ej-full .scenario-table td {{
  font-size: 0.72rem;
  padding: 0.32rem 0.42rem;
  line-height: 1.4;
  vertical-align: top;
}}
.frame-fit.rule-frame .scenario-table th,
.frame-fit.rule-frame .scenario-table td {{
  font-size: 0.74rem; padding: 0.28rem 0.38rem; line-height: 1.35;
}}
.frame-fit.rule-frame .tbl-caption {{ font-size: 0.76rem; margin-top: 0.05rem; }}
.frame-fit.rule-frame .scenario-section p {{ font-size: 0.78rem; }}
.frame-fit.rule-frame .conclusion-box {{ padding: 0.35rem 0.45rem 1.85rem; }}
.frame-fit.rule-frame .esc-pill {{ padding: 0.2rem 0.45rem; }}
.scenario-item {{
  display: flex; flex-direction: column; gap: 0;
  padding: 0; border: 1px solid var(--line); border-radius: 10px;
  background: var(--white); flex-shrink: 0;
}}
.scenario-item.section {{ border-color: var(--accent); border-width: 2px; }}
.esc-pill {{
  display: flex; align-items: center; justify-content: space-between; gap: 0.35rem;
  padding: 0.28rem 0.55rem; font-size: 0.68rem; font-weight: 800;
  letter-spacing: 0.03em; text-transform: uppercase; flex-shrink: 0;
}}
.esc-pill .esc-code {{ font-size: 0.75rem; }}
.esc-pill .esc-kind {{ font-size: 0.58rem; font-weight: 600; opacity: 0.85; }}
.esc-pill.neutral {{ background: #eef1f5; color: #5c6b7a; }}
.esc-pill.paso {{ background: #fef6e6; color: #9a6700; }}
.esc-pill.empate {{ background: #fdecea; color: #c0392b; }}
.esc-pill.salida {{ background: #e6f7f1; color: #0d9f6e; }}
.esc-pill.esc1 {{ background: #1d6fdc; color: #fff; }}
.esc-pill.esc2 {{ background: #1558b0; color: #fff; }}
.esc-pill.esc3 {{ background: #0e4a8a; color: #fff; }}
.esc-pill.esc4 {{ background: #5b8fd9; color: #fff; }}
.esc-pill.esc5 {{ background: #7aa6e0; color: #fff; }}
.esc-pill.esc6 {{ background: #99bce8; color: #1a2332; }}
.esc-pill.motor {{ background: #ede7f6; color: #5e35b1; }}
.scenario-body {{
  display: flex; flex-direction: column; gap: 0.45rem;
  padding: 0.45rem 0.55rem 0.5rem;
}}
.scenario-table th, .scenario-table td {{
  font-size: 0.8rem; padding: 0.38rem 0.48rem;
}}
.tbl-caption {{
  font-size: 0.84rem; font-weight: 600; color: var(--text); margin-top: 0.15rem; line-height: 1.4;
}}
.scenario-head {{
  position: relative;
  display: flex; align-items: flex-start; gap: 0.5rem; flex-wrap: wrap;
  padding-right: 6.5rem;
}}
.scenario-head h4 {{ font-size: 1rem; font-weight: 600; line-height: 1.35; flex: 1; min-width: 0; margin: 0; }}
.scenario-head-main {{
  display: flex; align-items: flex-start; gap: 0.5rem; flex: 1; min-width: 0;
}}
.scenario-head-text {{ flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 0.12rem; }}
.scenario-vol-meta {{
  font-size: 0.78rem; font-weight: 600; color: var(--text); margin: 0; line-height: 1.35;
}}
.scenario-vol-hint {{
  font-size: 0.68rem; color: var(--muted); margin: 0; line-height: 1.3;
}}
.btn-head-query {{
  position: absolute; top: 0; right: 0;
  bottom: auto;
}}
.scenario-section {{ display: flex; flex-direction: column; gap: 0.3rem; }}
.scenario-section .sec-label {{
  font-size: 0.66rem; font-weight: 700; text-transform: uppercase;
  letter-spacing: 0.05em; color: var(--accent);
}}
.scenario-section p {{
  font-size: 0.84rem; color: var(--text); line-height: 1.5; margin: 0;
}}
.scenario-section .busca-line {{ color: var(--muted); }}
.conclusion-box {{
  position: relative;
  background: var(--accent-soft); border: 1px solid #b8d4f5; border-radius: 8px;
  padding: 0.4rem 0.5rem 2.15rem;
}}
.conclusion-box p {{ color: var(--text); padding-right: 0.25rem; }}
.btn-card-query {{
  position: absolute; bottom: 0.45rem; right: 0.55rem;
  font-size: 0.68rem; font-weight: 600; padding: 0.35rem 0.75rem;
  border-radius: 8px; border: 1px solid var(--accent);
  background: var(--white); color: var(--accent); cursor: pointer;
  font-family: inherit; white-space: nowrap;
}}
.btn-card-query:hover {{ background: var(--accent); color: #fff; }}
.card-query-wrap {{ display: flex; justify-content: flex-end; padding-top: 0.15rem; }}
.card-query-wrap .btn-card-query {{ position: static; }}
.dev-narrative p {{ font-size: 0.82rem; }}
.scenario-group {{
  grid-column: 1 / -1;
  padding: 0.35rem 0.5rem 0.15rem;
  border-bottom: 2px solid var(--accent-soft);
  margin-top: 0.15rem;
}}
.scenario-group:first-child {{ margin-top: 0; }}
.scenario-group strong {{ display: block; font-size: 0.78rem; color: var(--accent); font-weight: 700; }}
.scenario-group span {{ display: block; font-size: 0.66rem; color: var(--muted); line-height: 1.3; margin-top: 0.1rem; }}
.scenario-item[data-esc="ESC1"] {{ border-top: 3px solid #1d6fdc; }}
.scenario-item[data-esc="ESC2"] {{ border-top: 3px solid #1558b0; }}
.scenario-item[data-esc="ESC3"] {{ border-top: 3px solid #0e4a8a; }}
.scenario-item[data-esc="ESC4"] {{ border-top: 3px solid #5b8fd9; }}
.scenario-item[data-esc="ESC5"] {{ border-top: 3px solid #7aa6e0; }}
.scenario-item[data-esc="ESC6"] {{ border-top: 3px solid #99bce8; }}
.sp-detail-card dl {{ margin: 0.5rem 0; font-size: 0.88rem; }}
.sp-detail-card dt {{ font-weight: 600; color: var(--muted); margin-top: 0.35rem; }}
.sp-detail-card dd {{ margin: 0.15rem 0 0 0; }}
.sp-query-pre {{
  background: #f0f4f8; border: 1px solid var(--line); border-radius: 8px;
  padding: 0.65rem; font-family: var(--mono); font-size: 0.75rem;
  white-space: pre-wrap; margin-top: 0.5rem;
}}
#frame-sps.rule-frame {{ --scenario-nav-w: 14rem; }}
#frame-sps .scenario-nav-item .nav-title {{
  display: block;
  font-size: 0.62rem;
  color: var(--muted);
  line-height: 1.25;
  margin-top: 0.12rem;
  white-space: normal;
  word-break: break-word;
}}
#frame-sps .scenario-stage {{ align-items: stretch; }}
#frame-sps .scenario-stage .scenario-item {{
  width: 100%;
  max-width: 100%;
  transform: none !important;
}}
#frame-sps .sp-detail-card dl {{
  display: grid;
  grid-template-columns: max-content minmax(0, 1fr);
  gap: 0.4rem 0.85rem;
  align-items: start;
  margin: 0.5rem 0;
}}
#frame-sps .sp-detail-card dt {{
  margin-top: 0;
  text-transform: uppercase;
  font-size: 0.65rem;
  white-space: nowrap;
}}
#frame-sps .sp-detail-card dd {{ margin: 0; }}
.badge {{
  font-size: 0.65rem; font-weight: 700; padding: 0.2rem 0.5rem; border-radius: 6px;
  text-transform: uppercase; flex-shrink: 0;
}}
.badge.ok {{ background: var(--ok-soft); color: var(--ok); }}
.badge.warn {{ background: var(--warn-soft); color: var(--warn); }}
.badge.block {{ background: var(--block-soft); color: var(--block); }}
.badge.neutral {{ background: var(--line); color: var(--muted); }}
.scenario-text {{ flex: 1; min-width: 0; }}
.vol-stats {{
  font-size: 0.72rem; color: var(--accent); font-weight: 600;
  padding-top: 0.15rem; border-top: 1px dashed var(--line);
}}

.drill-wrap {{ margin-top: 0.5rem; flex: 1; min-height: 0; display: flex; flex-direction: column; }}
.drill-wrap h3 {{ font-size: 0.82rem; margin-bottom: 0.25rem; flex-shrink: 0; }}
.drill-note {{ font-size: 0.7rem; color: var(--muted); margin-bottom: 0.35rem; flex-shrink: 0; }}
.drill-scroll {{ overflow: auto; border: 1px solid var(--line); border-radius: 10px; flex: 1; min-height: 100px; }}
.drill-table {{ width: 100%; border-collapse: collapse; font-size: 0.7rem; }}
.drill-table th, .drill-table td {{ padding: 0.4rem 0.5rem; text-align: left; border-bottom: 1px solid var(--line); vertical-align: top; }}
.drill-table th {{ position: sticky; top: 0; background: var(--accent-soft); z-index: 1; font-size: 0.65rem; text-transform: uppercase; letter-spacing: 0.04em; }}
.drill-table tr.section td {{ background: #eef2f7; font-weight: 700; font-size: 0.67rem; }}
.drill-table .num {{ text-align: right; white-space: nowrap; font-variant-numeric: tabular-nums; }}
.drill-table .busca {{ color: var(--muted); max-width: 260px; line-height: 1.3; }}
.drill-table tr.zero {{ opacity: 0.7; }}

/* Glosario + cascada drill-down (estilo Excel negocio) */
.glossary {{
  display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.85rem;
  flex-shrink: 0;
}}
.glossary-card {{
  background: var(--accent-soft); border: 1px solid #b8d4f5; border-radius: 10px;
  padding: 0.85rem 0.95rem;
}}
.glossary-card h4 {{ font-size: 0.78rem; color: var(--accent); margin-bottom: 0.35rem; }}
.glossary-card p {{ font-size: 0.74rem; color: var(--text); line-height: 1.45; }}

.metric-toggle {{
  display: inline-flex; border: 1px solid var(--line); border-radius: 8px; overflow: hidden;
  flex-shrink: 0;
}}
.metric-toggle button {{
  border: none; background: var(--white); padding: 0.45rem 0.85rem;
  font-size: 0.76rem; cursor: pointer; font-family: inherit; color: var(--muted);
}}
.metric-toggle button.active {{ background: var(--accent); color: #fff; font-weight: 600; }}
#frame-home .metric-toggle {{ margin-bottom: 0.85rem; }}

.drill-cascade-panel {{
  background: var(--bg);
  border: 1px solid var(--line);
  border-radius: 12px;
  padding: 1rem 1.15rem 1.15rem;
}}
.drill-cascade {{
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 1rem;
  overflow: visible;
}}
.cascade-step {{
  position: relative;
  text-align: center;
  min-width: 0;
}}
.cascade-step .step-num {{
  display: inline-block;
  font-size: 0.62rem;
  font-weight: 700;
  color: var(--accent);
  background: var(--white);
  border: 1px solid var(--line);
  border-radius: 999px;
  padding: 0.1rem 0.45rem;
  margin-bottom: 0.35rem;
}}
.cascade-box {{
  background: var(--white); border: 2px solid var(--line); border-radius: 10px;
  padding: 0.75rem 0.55rem; min-height: 108px; cursor: pointer; transition: all 0.15s;
  display: flex; flex-direction: column; justify-content: center;
}}
.cascade-box:hover, .cascade-box.active {{ border-color: var(--accent); background: var(--accent-soft); box-shadow: 0 2px 8px rgba(29,111,220,0.12); }}
.cascade-box.universo {{ border-color: var(--accent); background: linear-gradient(180deg,#e8f1fc,#fff); }}
.cascade-box.zero {{ opacity: 0.72; border-style: dashed; }}
.cascade-box .lbl {{ font-size: 0.68rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.03em; color: var(--muted); line-height: 1.25; }}
.cascade-box .val {{ font-size: 0.92rem; font-weight: 800; color: var(--accent); margin: 0.35rem 0; line-height: 1.3; word-break: break-word; }}
.cascade-box .sub {{ font-size: 0.68rem; color: var(--muted); line-height: 1.35; }}

.drill-matrix-wrap {{ display: block; }}
#frame-home .drill-scroll {{
  height: min(540px, 52vh);
  min-height: 360px;
  overflow: auto;
  border: 1px solid var(--line);
  border-radius: 10px;
  background: var(--white);
}}
.drill-matrix-wrap h3 {{ font-size: 0.88rem; margin-bottom: 0.35rem; }}
.drill-matrix-note {{ font-size: 0.74rem; color: var(--muted); margin-bottom: 0.65rem; line-height: 1.45; }}

.strategic-box {{
  padding: 1rem 1.1rem; background: var(--warn-soft);
  border: 1px solid #f0d9a8; border-radius: 10px; flex-shrink: 0;
}}
.strategic-box h4 {{ font-size: 0.82rem; color: var(--warn); margin-bottom: 0.45rem; }}
.strategic-box ol {{ margin-left: 1.2rem; font-size: 0.76rem; color: var(--text); line-height: 1.55; }}

.drill-table .regla-cell {{ font-weight: 700; color: var(--accent); white-space: nowrap; }}
.drill-table .justif {{ min-width: 220px; max-width: 360px; line-height: 1.4; font-size: 0.74rem; }}
.drill-table .subesc {{ color: var(--muted); font-size: 0.72rem; white-space: normal; }}
#frame-home .drill-table th, #frame-home .drill-table td {{
  padding: 0.55rem 0.65rem;
  font-size: 0.74rem;
}}
#frame-home .rules-map {{ margin-top: 0.25rem; }}

.scenario-table {{
  width: 100%; border-collapse: collapse; margin-top: 0.15rem;
  font-size: 0.74rem; table-layout: auto;
}}
.scenario-table th {{
  background: #eef2f7; text-align: left; padding: 0.45rem 0.55rem;
  font-weight: 600; font-size: 0.68rem; vertical-align: top;
  border: 1px solid var(--line);
}}
.scenario-table td {{
  border: 1px solid var(--line); padding: 0.45rem 0.55rem;
  text-align: left; vertical-align: top;
  white-space: normal; word-break: break-word; line-height: 1.45;
}}
.scenario-table td.ok {{ color: var(--ok); font-weight: 600; }}
.scenario-table td.fail {{ color: var(--block); font-weight: 600; }}

.app-footer, .nav-float {{ display: none !important; }}

/* Modal query */
.modal-backdrop {{
  position: fixed; inset: 0; background: rgba(26,35,50,0.45); z-index: 200;
  display: none; align-items: center; justify-content: center; padding: 1rem;
}}
.modal-backdrop.open {{ display: flex; }}
.modal {{
  background: var(--white); border-radius: var(--radius); width: min(720px, 96vw);
  max-height: 90vh; overflow: hidden; display: flex; flex-direction: column;
  box-shadow: 0 24px 64px rgba(0,0,0,0.18);
}}
.modal-head {{ padding: 1.25rem 1.5rem; border-bottom: 1px solid var(--line); }}
.modal-head h2 {{ font-size: 1.15rem; }}
.modal-head p {{ font-size: 0.85rem; color: var(--muted); margin-top: 0.35rem; }}
.modal-body {{ padding: 1rem 1.5rem; overflow-y: auto; flex: 1; }}
.modal-body pre {{
  background: #f0f4f8; border: 1px solid var(--line); border-radius: 10px;
  padding: 1rem; font-family: var(--mono); font-size: 0.78rem;
  white-space: pre-wrap; word-break: break-word; max-height: 280px; overflow-y: auto;
}}
.modal-foot {{
  padding: 1rem 1.5rem; border-top: 1px solid var(--line);
  display: flex; gap: 0.75rem; flex-wrap: wrap;
}}

.qa-results {{
  display: grid; grid-template-columns: 1fr 1fr; gap: 0.85rem;
}}
.qa-card {{
  background: #fff; border: 1px solid var(--line); border-radius: 12px;
  padding: 0.9rem 1rem; display: flex; flex-direction: column; gap: 0.45rem;
}}
.qa-card h4 {{
  margin: 0; font-size: 0.82rem; letter-spacing: 0.02em; text-transform: uppercase;
  color: var(--muted); font-weight: 700;
}}
.qa-card .qa-pass {{
  display: inline-block; font-size: 0.72rem; font-weight: 700;
  background: #dcfce7; color: #166534; border-radius: 999px; padding: 0.15rem 0.55rem;
}}
.qa-card table {{
  width: 100%; border-collapse: collapse; font-size: 0.78rem;
}}
.qa-card th, .qa-card td {{
  text-align: left; padding: 0.28rem 0.2rem; border-bottom: 1px solid #eef2f7;
  vertical-align: top;
}}
.qa-card th {{ color: var(--muted); font-weight: 600; width: 38%; }}
.qa-card code {{ font-family: var(--mono); font-size: 0.72rem; }}
.qa-note {{
  margin: 0.65rem 0 0; font-size: 0.78rem; color: var(--muted); line-height: 1.4;
}}
@media (max-width: 900px) {{
  .qa-results {{ grid-template-columns: 1fr; }}
}}
.toast {{
  position: fixed; bottom: 0.75rem; left: 50%; transform: translateX(-50%);
  background: var(--text); color: #fff; padding: 0.65rem 1.25rem; border-radius: 999px;
  font-size: 0.85rem; z-index: 300; opacity: 0; transition: opacity 0.3s; pointer-events: none;
}}
.toast.show {{ opacity: 1; }}

@media (max-width: 900px) {{
  .step-nav {{ gap: 0.2rem; }}
  .step-btn {{ padding: 0.28rem 0.55rem; font-size: 0.66rem; }}
  .rule-layout {{ grid-template-columns: 72px 1fr; }}
  .scenario-nav {{ max-height: none; }}
  .rules-map {{ grid-template-columns: 1fr; }}
  .kpi-row {{ grid-template-columns: repeat(2, 1fr); }}
  .glossary {{ grid-template-columns: 1fr; }}
  .drill-cascade {{ grid-template-columns: repeat(2, minmax(0, 1fr)); }}
}}
@media (max-width: 1200px) {{
  .drill-cascade {{ grid-template-columns: repeat(2, minmax(0, 1fr)); }}
}}
</style>
</head>
<body>

<header class="app-header">
  <h1>Unificacion</h1>
  <nav class="step-nav" id="stepNav"></nav>
  <span class="header-meta">DEV · reales+mock · R2=72.448 · TC mock 23/23 PASS · {today}</span>
  <div class="progress"><i id="progressBar"></i></div>
</header>

<div class="viewport" id="viewport">
  <div class="canvas" id="canvas">

    <div class="frame" id="frame-home">
      <div class="frame-fit">
      <div class="frame-title">Drill-down — del universo a cada escenario</div>
      <div class="frame-sub">Vista unificada: conceptos, cascada DEV y matriz completa. Desplácese hacia abajo para ver la tabla y las reglas.</div>

      <section class="drill-section">
        <div class="drill-section-title">1 · Qué estamos contando</div>
        <p class="drill-section-note">Persona, reporte de dirección y calle no son lo mismo. Los números del mapa usan estas definiciones.</p>
        <div class="glossary" id="glossary"></div>
      </section>

      <section class="drill-section">
        <div class="drill-section-title">2 · Resumen DEV</div>
        <div class="kpi-row" id="kpiRow"></div>
      </section>

      <section class="drill-section">
        <div class="drill-section-title">2b · Resultados QA — reales vs mock (revalidado 2026-09-16)</div>
        <p class="drill-section-note">Dos modos, dos familias de SPs. Overall pre-push: <b>PASS</b> (reales + mock). No mezclar en la misma corrida.</p>
        <div class="qa-results">
          <div class="qa-card">
            <h4>Datos reales <span class="qa-pass">PASS</span></h4>
            <table>
              <tr><th>Fuente</th><td><code>edf_views</code> → <code>v_xpm_*</code></td></tr>
              <tr><th>SPs</th><td><code>sp_unificacion_regla1/2/3</code> (+ 12 por escenario)</td></tr>
              <tr><th>Salida</th><td><code>bdm_datos.unificacion_direccion</code></td></tr>
              <tr><th>R2</th><td><b>72.448</b></td></tr>
              <tr><th>C03 / C04</th><td><b>0</b> / <b>0</b></td></tr>
              <tr><th>R1 / R3</th><td>0 / 0 (R3 = N/A sin geo)</td></tr>
              <tr><th>Universo RPU</th><td>591.166</td></tr>
              <tr><th>Run</th><td><code>run_unificacion_ejecucion_secuencial.sql</code></td></tr>
            </table>
          </div>
          <div class="qa-card">
            <h4>Datos mock <span class="qa-pass">PASS 23/23</span></h4>
            <table>
              <tr><th>Fuente</th><td><code>bdm_stage</code> → <code>v_mock_*</code></td></tr>
              <tr><th>SPs</th><td><code>sp_unificacion_mock_regla1/2/3</code> (+ 12 por escenario)</td></tr>
              <tr><th>Salida</th><td><code>bdm_datos.unificacion_direccion_mock</code></td></tr>
              <tr><th>Suite TC</th><td>TC-R1-01…08 + TC-R2-01…14 = <b>0</b> violaciones</td></tr>
              <tr><th>Preflight</th><td>R1=3.204 · R2=6.002 · R3=13 (bdm_stage)</td></tr>
              <tr><th>R3 mock</th><td>Sí se prueba (con lat/long sembrado)</td></tr>
              <tr><th>Run</th><td><code>run_unificacion_mock_ejecucion_secuencial.sql</code></td></tr>
            </table>
          </div>
        </div>
        <p class="qa-note">Rama: <code>feature/unificacion-edf-views</code> · Tablas QA: <code>MAPEO_QA_IFR_TABLAS_COLUMNAS.md</code> · Gate: <code>tools/revalidar_qa_dev_pre_push.py</code> → <code>push_allowed=true</code>. Consumidor Reconocer puede estar locked; revalidación reales en productor <code>bdm_datos</code> con mismos gates.</p>
      </section>

      <section class="drill-section">
        <div class="drill-section-title">3 · Cascada — del universo al valor filtrado</div>
        <p class="drill-section-note">Cada caja es un paso del recorrido. Elija métrica y haga clic en una caja para ir a su fila en la matriz.</p>
        <div class="metric-toggle" id="metricToggle"></div>
        <div class="drill-cascade-panel">
          <div class="drill-cascade" id="drillCascade"></div>
        </div>
      </section>

      <section class="drill-section drill-section-matrix">
        <div class="drill-section-title">4 · Matriz drill-down</div>
        <p class="drill-matrix-note">Regla → escenario → subescenario → cantidades → por qué. Incluye escenarios en cero. La tabla tiene scroll propio.</p>
        <div class="drill-matrix-wrap">
          <div class="drill-scroll"><table class="drill-table" id="drillMatrix"></table></div>
        </div>
      </section>

      <section class="drill-section">
        <div class="drill-section-title">5 · Preguntas de cierre</div>
        <div class="strategic-box">
          <ol>
            <li>¿Qué le tenemos que pedir a Experian en cuanto a datos? (geo, CIIU, complementos, calidad de ci.id / RPUs)</li>
            <li>¿Nuestra lógica está bien implementada? — Apuntamiento de cada escenario a la lógica de negocio y conteos DEV coherentes (R2=72.448 · C03/C04=0).</li>
            <li>¿QA tiene ambos paths? — Reales (<code>sp_unificacion_*</code> + <code>v_xpm_*</code>) y mock (<code>sp_unificacion_mock_*</code> + <code>v_mock_*</code>); deploy Neil + seed + grants.</li>
          </ol>
        </div>
      </section>

      <section class="drill-section">
        <div class="drill-section-title">6 · Detalle por regla</div>
        <div class="rules-map" id="rulesMap"></div>
      </section>
      </div>
    </div>

    <div class="frame frame-off" id="frame-universo" aria-hidden="true"></div>

    <div class="frame" id="frame-r1">
      <div class="frame-fit rule-frame">
      <div class="frame-title">Regla R1 — Mismo texto, distinto uso</div>
      <div class="frame-sub">Índice a la izquierda · escenario completo a la derecha · Anterior / Siguiente cambia de bloque.</div>
      <div class="rule-layout">
        <aside class="scenario-nav" id="nav-r1"></aside>
        <div class="scenario-stage" id="stage-r1"></div>
      </div>
      <div class="rule-nav-hint" id="hint-r1"></div>
      </div>
    </div>

    <div class="frame" id="frame-r2">
      <div class="frame-fit rule-frame">
      <div class="frame-title">Regla R2 — Complemento</div>
      <div class="frame-sub">Ejemplos con códigos reales de DEV: misma calle, usos, puntajes y si se unifica o no.</div>
      <div class="rule-layout">
        <aside class="scenario-nav" id="nav-r2"></aside>
        <div class="scenario-stage" id="stage-r2"></div>
      </div>
      <div class="rule-nav-hint" id="hint-r2"></div>
      </div>
    </div>

    <div class="frame" id="frame-r3">
      <div class="frame-fit rule-frame">
      <div class="frame-title">Regla R3 — Cercanía geo</div>
      <div class="frame-sub">Bloqueada en DEV — tablas muestran requisito geo y por qué no entra.</div>
      <div class="rule-layout">
        <aside class="scenario-nav" id="nav-r3"></aside>
        <div class="scenario-stage" id="stage-r3"></div>
      </div>
      <div class="rule-nav-hint" id="hint-r3"></div>
      </div>
    </div>

    <div class="frame frame-off" id="frame-profiling">
      <div class="frame-fit rule-frame">
      <div class="frame-title">Perfil de datos — calidad del insumo</div>
      <div class="frame-sub">RESUMEN + columnas críticas · Anterior / Siguiente entre bloques.</div>
      <div class="rule-layout">
        <aside class="scenario-nav" id="nav-profiling"></aside>
        <div class="scenario-stage" id="stage-profiling"></div>
      </div>
      <div class="rule-nav-hint" id="hint-profiling"></div>
      </div>
    </div>

    <div class="frame frame-off" id="frame-sps">
      <div class="frame-fit rule-frame">
      <div class="frame-title">Catálogo SP — 15 reales + 15 mock</div>
      <div class="frame-sub">Reales: sp_unificacion_* (v_xpm_*) · Mock: sp_unificacion_mock_* (v_mock_/bdm_stage) · repos _strct / _pgm / _dt</div>
      <div class="rule-layout">
        <aside class="scenario-nav" id="nav-sps"></aside>
        <div class="scenario-stage" id="stage-sps"></div>
      </div>
      </div>
    </div>

  </div>
</div>

<div class="modal-backdrop" id="queryModal">
  <div class="modal">
    <div class="modal-head">
      <h2>Ver query</h2>
      <p id="modalSubtitle">Copiar y ejecutar en dba_rncr_batch</p>
    </div>
    <div class="modal-body"><pre id="modalSql"></pre></div>
    <div class="modal-foot">
      <button type="button" class="btn btn-primary" id="btnCopyQuery">Copiar query</button>
      <button type="button" class="btn" id="btnCloseModal">Cerrar</button>
    </div>
  </div>
</div>

<div class="toast" id="toast"></div>

<script>
const DATA = {data_json};

const FRAMES = [
  {{ id: 'home', label: 'Drill-down', el: 'frame-home', progress: 0 }},
  {{ id: 'r1', label: 'Regla R1', el: 'frame-r1', progress: 20 }},
  {{ id: 'r2', label: 'Regla R2', el: 'frame-r2', progress: 40 }},
  {{ id: 'r3', label: 'Regla R3', el: 'frame-r3', progress: 55 }},
  {{ id: 'profiling', label: 'Perfil de datos', el: 'frame-profiling', progress: 75 }},
  {{ id: 'sps', label: 'SPs', el: 'frame-sps', progress: 100 }},
];

let currentFrame = 0;
let metricMode = 'ambos';

const RULE_FRAMES = [
  null,
  {{ regla: 'R1', nav: 'nav-r1', stage: 'stage-r1', hint: 'hint-r1' }},
  {{ regla: 'R2', nav: 'nav-r2', stage: 'stage-r2', hint: 'hint-r2' }},
  {{ regla: 'R3', nav: 'nav-r3', stage: 'stage-r3', hint: 'hint-r3' }},
  {{ regla: 'PERFIL DE DATOS', nav: 'nav-profiling', stage: 'stage-profiling', hint: 'hint-profiling' }},
];
const ruleRowMap = {{}};
const scenarioPos = {{ 1: 0, 2: 0, 3: 0, 4: 0 }};
const SP_ITEMS = DATA.sps_detalle || [];
let spPos = 0;
let modalSqlText = '';

function fmt(n) {{ return Number(n).toLocaleString('es-CO'); }}
function esc(s) {{ const d=document.createElement('div'); d.textContent=s||''; return d.innerHTML; }}

function badgeClass(estado) {{
  const e = (estado||'').toLowerCase();
  if (e==='ok'||e==='esperado') return 'ok';
  if (['empate','info','revisar','n/a','pendiente','esperado dev'].some(x=>e.includes(x))) return 'warn';
  if (['bloqueo','bloqueado'].some(x=>e.includes(x))) return 'block';
  return 'neutral';
}}

function toast(msg) {{
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2200);
}}

function openQueryModal(sql, title) {{
  modalSqlText = sql || '';
  document.getElementById('modalSql').textContent = modalSqlText;
  document.getElementById('modalSubtitle').textContent = title || 'Validación en dba_rncr_batch';
  document.getElementById('queryModal').classList.add('open');
}}

function closeQueryModal() {{
  document.getElementById('queryModal').classList.remove('open');
}}

document.getElementById('btnCloseModal').onclick = closeQueryModal;
document.getElementById('queryModal').onclick = (e) => {{ if (e.target.id==='queryModal') closeQueryModal(); }};
document.getElementById('btnCopyQuery').onclick = () => {{
  navigator.clipboard.writeText(modalSqlText).then(() => toast('Query copiada'));
}};

function fitRuleStage() {{
  const fr = document.querySelector('.frame.frame-on');
  if (!fr || fr.id === 'frame-sps' || !fr.querySelector('.rule-layout')) return;
  const stage = fr.querySelector('.scenario-stage');
  const item = stage?.querySelector('.scenario-item');
  if (!stage || !item) return;
  item.style.transform = '';
  item.style.width = '';
  const sh = stage.clientHeight;
  const sw = stage.clientWidth;
  if (sh < 20 || sw < 20) return;
  const ih = item.scrollHeight;
  const iw = item.scrollWidth;
  const scale = Math.min(1, sw / Math.max(iw, 1), sh / Math.max(ih, 1));
  const s = Math.max(0.72, scale);
  if (s < 0.992) {{
    item.style.transform = `scale(${{s}})`;
    item.style.transformOrigin = 'top left';
    item.style.width = `${{100 / s}}%`;
  }}
}}

function fitActiveFrame() {{
  fitRuleStage();
}}

function showFrame(idx) {{
  currentFrame = idx;
  const f = FRAMES[idx];
  document.getElementById('progressBar').style.width = f.progress + '%';
  document.querySelectorAll('.step-btn').forEach((b,i) => b.classList.toggle('active', i===idx));
  document.querySelectorAll('.frame').forEach((fr) => {{
    const on = fr.id === f.el;
    fr.classList.toggle('frame-on', on);
    fr.classList.toggle('frame-off', !on);
  }});
  if (idx >= 1 && idx <= 4) showRuleScenario(idx, scenarioPos[idx], false);
  if (idx === 5) showSpDetail(spPos, false);
  requestAnimationFrame(() => requestAnimationFrame(fitRuleStage));
}}

function zoomToFrame(idx) {{ showFrame(idx); }}

function buildRuleRowMap() {{
  for (let fi = 1; fi <= 4; fi++) {{
    const regla = RULE_FRAMES[fi].regla;
    ruleRowMap[fi] = [];
    DATA.rows.forEach((row, i) => {{
      if (row._regla === regla) ruleRowMap[fi].push(i);
    }});
  }}
}}

function showRuleScenario(frameIdx, localIdx, scrollNav) {{
  const meta = RULE_FRAMES[frameIdx];
  const indices = ruleRowMap[frameIdx] || [];
  if (!indices.length) return;
  localIdx = Math.max(0, Math.min(indices.length - 1, localIdx));
  scenarioPos[frameIdx] = localIdx;
  const rowIdx = indices[localIdx];
  const row = DATA.rows[rowIdx];
  const code = escCodigo(row);
  const stage = document.getElementById(meta.stage);
  stage.innerHTML = `<div class="scenario-item" data-esc="${{esc(code)}}">${{buildScenarioCardHtml(row, rowIdx)}}</div>`;
  document.querySelectorAll(`#${{meta.nav}} .scenario-nav-item`).forEach((btn, i) => {{
    btn.classList.toggle('active', i === localIdx);
  }});
  if (scrollNav) {{
    const active = document.querySelector(`#${{meta.nav}} .scenario-nav-item.active`);
    if (active) active.scrollIntoView({{ block: 'nearest' }});
  }}
  requestAnimationFrame(() => requestAnimationFrame(fitRuleStage));
}}

function initRuleFrame(frameIdx) {{
  const meta = RULE_FRAMES[frameIdx];
  const indices = ruleRowMap[frameIdx] || [];
  const nav = document.getElementById(meta.nav);
  nav.innerHTML = indices.map((rowIdx, li) => {{
    const row = DATA.rows[rowIdx];
    const code = escCodigo(row);
    const titulo = row._titulo_corto || row.Subescenario || row.Escenario;
    return `<button type="button" class="scenario-nav-item" data-frame="${{frameIdx}}" data-local="${{li}}">
      <span class="nav-code">${{esc(code)}}</span>
      <span class="nav-title">${{esc(titulo)}}</span>
    </button>`;
  }}).join('');
  nav.querySelectorAll('.scenario-nav-item').forEach(btn => {{
    btn.onclick = () => {{
      showRuleScenario(+btn.dataset.frame, +btn.dataset.local, true);
    }};
  }});
  showRuleScenario(frameIdx, scenarioPos[frameIdx], false);
}}

function initRuleFrames() {{
  buildRuleRowMap();
  [1, 2, 3, 4].forEach(initRuleFrame);
  initSpFrame();
}}

function renderSpCard(sp) {{
  return `<div class="scenario-item sp-detail-card">
    <div class="esc-pill paso"><span class="esc-code">${{esc(sp.id)}}</span><span class="esc-kind">${{esc(sp.grupo)}}</span></div>
    <div class="scenario-body">
      <div class="scenario-head">
        <div class="scenario-head-main">
          <span class="badge ok">${{esc(sp.repo)}}</span>
          <div class="scenario-head-text"><h4><code>${{esc(sp.archivo)}}</code></h4></div>
        </div>
        <button type="button" class="btn btn-query btn-head-query btn-sp-query">Ver query</button>
      </div>
      <p style="margin:0.35rem 0"><strong>${{esc(sp.rol)}}</strong></p>
      <dl>
        <dt>Entra</dt><dd>${{esc(sp.entra)}}</dd>
        <dt>Sale</dt><dd>${{esc(sp.sale)}}</dd>
        <dt>Lógica</dt><dd>${{esc(sp.logica)}}</dd>
      </dl>
      <pre class="sp-query-pre">${{esc(sp.query)}}</pre>
    </div>
  </div>`;
}}

function showSpDetail(pos, scroll) {{
  if (!SP_ITEMS.length) return;
  const p = Math.max(0, Math.min(pos, SP_ITEMS.length - 1));
  spPos = p;
  const sp = SP_ITEMS[p];
  document.getElementById('nav-sps').innerHTML = SP_ITEMS.map((s, j) =>
    `<button type="button" class="scenario-nav-item ${{j===p?'active':''}}" data-pos="${{j}}">
      <span class="nav-code">${{esc(s.id)}}</span>
      <span class="nav-title">${{esc(s.rol || s.archivo.replace('.sql',''))}}</span>
    </button>`
  ).join('');
  document.getElementById('stage-sps').innerHTML = renderSpCard(sp);
  document.getElementById('nav-sps').querySelectorAll('.scenario-nav-item').forEach(btn => {{
    btn.onclick = () => showSpDetail(+btn.dataset.pos, true);
  }});
  document.getElementById('stage-sps').querySelector('.btn-sp-query')?.addEventListener('click', () => {{
    openQueryModal(sp.query, sp.archivo);
  }});
  if (scroll) fitRuleStage();
}}

function initSpFrame() {{
  showSpDetail(0, false);
}}

function escCodigo(row) {{
  if (row._esc_codigo) return row._esc_codigo;
  const esc = row.Escenario || '';
  if (esc.startsWith('ESC')) return esc;
  return esc || '—';
}}

function renderTabla(tbl, cls) {{
  if (!tbl || !tbl.headers) return '';
  const head = tbl.headers.map(h => `<th>${{esc(h)}}</th>`).join('');
  const rows = (tbl.rows || []).map(r =>
    `<tr>${{r.map(c => {{
      const s = String(c ?? '');
      const cl = s.includes('✓') ? 'ok' : (s.includes('✗') ? 'fail' : '');
      return `<td class="${{cl}}">${{esc(s)}}</td>`;
    }}).join('')}}</tr>`
  ).join('');
  const cap = tbl.title ? `<div class="tbl-caption">${{esc(tbl.title)}}</div>` : '';
  return `${{cap}}<table class="${{cls || 'scenario-table'}}"><thead><tr>${{head}}</tr></thead><tbody>${{rows}}</tbody></table>`;
}}

function scenarioVolMeta(row) {{
  const code = row._esc_codigo || '';
  const regla = (row._regla || '').replace(/^▶\\s*/, '').trim();
  const k = DATA.kpis || {{}};
  if (regla === 'PERFIL DE DATOS') {{
    return `${{fmt(k.rpus || 591166)}} reportes perfilados · vistas bdm_tempo ← edf_views`;
  }}
  if (code === 'SALIDA') {{
    if (regla === 'R1') return `En DEV: ${{fmt(k.r1_out ?? 0)}} unificaciones guardadas`;
    if (regla === 'R2') return `En DEV: ${{fmt(k.r2_out ?? 0)}} reportes absorbidos (hija → padre)`;
    if (regla === 'R3') return `En DEV: ${{fmt(k.r3_out ?? 0)}} unificaciones por proximidad`;
  }}
  const p = row._personas;
  const r = row._rpus;
  if (p == null && r == null) return '';
  const bits = [];
  if (p != null && p !== '') bits.push(`${{fmt(p)}} personas`);
  if (r != null && r !== '') bits.push(`${{fmt(r)}} reportes`);
  let s = bits.join(' · ');
  const x = row._rpuxp;
  if (x != null && p > 0 && code !== 'SALIDA') {{
    s += ` · prom. ${{Number(x).toFixed(2).replace('.', ',')}} reportes/persona`;
  }}
  return s;
}}

function buildScenarioCardHtml(row, rowIdx) {{
  const bc = badgeClass(row.Estado);
  const titulo = row._titulo_corto || row.Subescenario || row.Escenario;
  const busca = row._vol_busca || row._busca || row['Qué espera (negocio)'] || '';
  const dev = row._dev || row['Qué encontramos DEV'] || '';
  const conclusion = row._conclusion_regla || row._conclusion || row['Ejemplo verificable (reporte + ID + query)'] || '';
  const sql = row['Query validación (copiar en dba_rncr_batch)'];
  const escCode = row._esc_codigo || '';
  const showQuery = row._show_query && sql;
  const queryBtn = showQuery
    ? `<button type="button" class="btn-card-query${{escCode === 'RESUMEN' ? ' btn-head-query' : ''}}" data-idx="${{rowIdx}}">Ver query</button>`
    : '';
  const headQueryBtn = escCode === 'RESUMEN' ? queryBtn : '';
  const conclQueryBtn = escCode !== 'RESUMEN' ? queryBtn : '';
  const wrapTbl = (tbl, role) => {{
    if (!tbl) return '';
    const cls = role === 'full' ? 'tbl-block-full' : role === 'ej-full' ? 'tbl-block-ej-full' : 'tbl-block';
    return `<div class="tbl-block ${{cls}}">${{renderTabla(tbl, 'scenario-table')}}</div>`;
  }};
  const tblPasos = wrapTbl(row._tabla_pasos, 'full');
  const tblEj = wrapTbl(row._tabla_ejemplo, row._tabla_ejemplo ? 'ej-full' : 'full');
  const volMeta = scenarioVolMeta(row);
  const volHint = volMeta && /reportes/i.test(volMeta)
    ? `<p class="scenario-vol-hint">Un reporte = una dirección reportada (casa, trabajo o correspondencia).</p>`
    : '';
  const profMeta = (row._regla === 'PERFIL DE DATOS' && row._esc_codigo && row._esc_codigo.startsWith('PROF-'))
    ? `<p class="scenario-vol-hint">${{esc(row._titulo_corto || '')}}</p>`
    : '';
  const volBlock = volMeta
    ? `<p class="scenario-vol-meta">${{esc(volMeta)}}</p>${{volHint}}${{profMeta}}`
    : profMeta;
  const buscaBlock = busca
    ? `<div class="scenario-section"><span class="sec-label">Qué busca</span><p class="busca-line">${{esc(busca)}}</p></div>`
    : '';
  const showDevNarr = dev && !row._tabla_pasos && !row._tabla_ejemplo;
  const devBlock = showDevNarr
    ? `<div class="scenario-section dev-narrative"><span class="sec-label">Qué encontramos en DEV</span><p>${{esc(dev)}}</p></div>`
    : '';
  const conclBlock = conclusion
    ? `<div class="scenario-section conclusion-box"><span class="sec-label">Conclusión</span><p>${{esc(conclusion)}}</p>${{conclQueryBtn}}</div>`
    : (conclQueryBtn ? `<div class="scenario-section card-query-wrap">${{conclQueryBtn}}</div>` : '');
  const accion = row['Acción / revisión'];
  const accionBlock = accion
    ? `<div class="scenario-section"><span class="sec-label">Acción / revisión</span><p>${{esc(accion)}}</p></div>`
    : '';
  return `
    ${{escPillHtml(row)}}
    <div class="scenario-body">
      <div class="scenario-head">
        <div class="scenario-head-main">
          <span class="badge ${{bc}}">${{esc(row.Estado||'—')}}</span>
          <div class="scenario-head-text">
            <h4>${{esc(titulo)}}</h4>
            ${{volBlock}}
          </div>
        </div>
        ${{headQueryBtn}}
      </div>
      ${{buscaBlock}}
      ${{tblPasos}}
      ${{tblEj}}
      ${{devBlock}}
      ${{conclBlock}}
      ${{accionBlock}}
    </div>
  `;
}}

function escPillMeta(row) {{
  const code = escCodigo(row);
  let kind = '';
  let cls = 'neutral';
  if (/^ESC[1-6]$/.test(code)) {{
    kind = 'Escenario de regla';
    cls = code.toLowerCase();
  }} else if (code === 'INSUMO') {{
    kind = 'Insumo · no es ESC';
    cls = 'paso';
  }} else if (code === 'PRE-R1') {{
    kind = 'Pre-R1 · quién entra';
    cls = 'paso';
  }} else if (code === 'PRE-R3') {{
    kind = 'Pre-R3 · requisito geo';
    cls = 'paso';
  }} else if (code === 'PRE') {{
    kind = 'Pre-candidato';
    cls = 'paso';
  }} else if (code === 'EMPATE') {{
    kind = 'Política · no desempata';
    cls = 'empate';
  }} else if (code === 'SALIDA') {{
    kind = 'Resultado final';
    cls = 'salida';
  }} else if (code === 'MOTOR') {{
    kind = 'Motor NIT · staging';
    cls = 'motor';
  }} else if (code === 'TEMA') {{
    kind = 'Punto de partida';
    cls = 'neutral';
  }} else if (code === 'RESUMEN') {{
    kind = 'Regla general';
    cls = 'neutral';
  }} else if (code === 'SIN PAR') {{
    kind = 'Sin duplicado R2';
    cls = 'neutral';
  }} else if (code.startsWith('PROF-')) {{
    kind = 'Perfil · columna';
    cls = 'warn';
  }} else if (code === 'REVISAR') {{
    kind = 'Deuda en vista';
    cls = 'warn';
  }}
  return {{ code, kind, cls }};
}}

function escPillHtml(row) {{
  const m = escPillMeta(row);
  return `<div class="esc-pill ${{m.cls}}"><span class="esc-code">${{esc(m.code)}}</span><span class="esc-kind">${{esc(m.kind)}}</span></div>`;
}}

const GROUP_LABELS = {{
  'PERFIL DE DATOS': {{
    'Propósito': {{ h: 'RESUMEN · Panorama calidad', s: 'bdm_tempo.v_xpm_* · edf_views' }},
    'Complemento': {{ h: 'v_xpm_direccion_fisica.complemento', s: 'standardizedcomplemento · R2' }},
    'Texto': {{ h: 'v_xpm_ubicacion_estandarizada.texto_ubicacion', s: 'Agrupación R1/R2/R3' }},
    'Geo': {{ h: 'v_xpm_ubicacion_estandarizada.lat/long', s: 'Bloqueo R3 en DEV' }},
    'CIIU': {{ h: 'v_xpm_ciiu_persona.cod_act_econo_ciiu_fte', s: 'xpm.mainisiccodeforproduct' }},
    'Puntaje': {{ h: 'v_xpm_contacto_direccion.score_estandarizacion', s: 'contactasstandardizedscore' }},
    'DANE': {{ h: 'v_xpm_ubicacion_estandarizada.cod_dw_ciudad', s: 'standardizeddanecode · cityname' }},
    'Tipo contacto': {{ h: 'contacttype → tipo_ubicacion_dir', s: 'xpm_location_val_contactinformations' }},
    'Vista': {{ h: 'REVISAR · 00_vistas_insumo_bdm.sql', s: 'Columnas forzadas a NULL' }},
  }},
  'PUNTO DE PARTIDA': {{
    'Definición': {{ h: 'TEMA · Conteos iniciales', s: 'RPUs, personas y ubicaciones distintas' }},
    'Waterfall': {{ h: 'TEMA · Después de R2', s: 'Cuántas direcciones quedan activas' }},
  }},
  R1: {{
    'Propósito': {{ h: 'RESUMEN · Regla R1', s: 'Personas y RPUs · CIIU y reportes' }},
    'Insumo': {{ h: 'INSUMO · Contacttype', s: 'Etiqueta en edf_views (1=casa, 2=trabajo, 8=token)' }},
    'Pre-candidato': {{ h: 'PRE-R1 · Quién entra a R1', s: 'Misma calle y ciudad con casa, trabajo y/o correspondencia' }},
    'ESC1': {{ h: 'ESC1 · Comercio CIIU 10', s: 'SP: {SP_R1_ESC1}' }},
    'ESC2': {{ h: 'ESC2 · Servicios 81/82/90', s: 'SP: {SP_R1_ESC2}' }},
    'ESC3': {{ h: 'ESC3 · Otros CIIU', s: 'SP: {SP_R1_ESC3}' }},
    'Política': {{ h: 'EMPATE · Sin desempate', s: 'Si dos tipos empatan → no unifica' }},
    'TOTAL': {{ h: 'SALIDA · unificacion_direccion', s: 'Filas con unifica_atributos=1' }},
  }},
  R2: {{
    'Propósito': {{ h: 'RESUMEN · Regla R2', s: 'Duplicados por complemento y diccionario' }},
    'Insumo': {{ h: 'INSUMO · Contacttype 8', s: 'Token → complemento estandarizado. No es ESC.' }},
    'ESC1': {{ h: 'ESC1 · Padre con apto', s: 'SP: {SP_R2_ESC12}' }},
    'ESC2': {{ h: 'ESC2 · Complemento contenido', s: 'SP: {SP_R2_ESC12}' }},
    'ESC3': {{ h: 'ESC3 · Misma nomenclatura', s: 'SP: {SP_R2_ESC3}' }},
    'ESC4': {{ h: 'ESC4 · Más frecuente', s: 'SP: {SP_R2_ESC4}' }},
    'ESC5': {{ h: 'ESC5 · Nivel jerárquico', s: 'SP: {SP_R2_ESC5}' }},
    'ESC6': {{ h: 'ESC6 · Frecuencia acumulada', s: 'SP: {SP_R2_ESC6}' }},
    'Motor': {{ h: 'MOTOR · NIT enriquecida', s: 'SP: {SP_R2_MOTOR}' }},
    'Remanente': {{ h: 'SIN PAR · Sin duplicado', s: 'No unificó en R2' }},
    'TOTAL': {{ h: 'SALIDA · unificacion_direccion', s: 'Filas con unifica_atributos=2' }},
  }},
  R3: {{
    'Propósito': {{ h: 'RESUMEN · Regla R3', s: 'Cercanía geográfica vía/puerta' }},
    'Pre-requisito': {{ h: 'PRE-R3 · Coordenadas', s: 'Sin lat/long no corre' }},
    'ESC único': {{ h: 'ESC1 · Cercanía vía y puerta', s: 'SP: {SP_R3_ESC1}' }},
    'TOTAL': {{ h: 'SALIDA · unificacion_direccion', s: 'Filas con unifica_atributos=3' }},
  }},
}};

function fmtRatio(v) {{ return (v == null || v === undefined) ? '—' : Number(v).toLocaleString('es-CO', {{minimumFractionDigits:2, maximumFractionDigits:2}}); }}

function volGet(regla, codigo) {{
  return (DATA.volumenes?.filas || []).find(f => f.regla === regla && f.codigo === codigo) || null;
}}

function fmtMetric(f) {{
  if (!f) return '—';
  if (metricMode === 'personas') return fmt(f.personas);
  if (metricMode === 'rpus') return fmt(f.rpus);
  return `${{fmt(f.personas)}} pers · ${{fmt(f.rpus)}} RPU`;
}}

function fmtMetricSub(f) {{
  if (!f || f.rpuxp == null) return '';
  if (metricMode === 'personas') return `${{fmtRatio(f.rpuxp)}} RPU/pers.`;
  return `${{fmtRatio(f.rpuxp)}} RPU/pers.`;
}}

function subescenarioLabel(f) {{
  const c = f.codigo;
  if (c === 'EMPATE') return 'Empate (política sin desempate)';
  if (c === 'PRE-R1') return 'Entra: misma calle + casa/trabajo/correspondencia';
  if (c === 'PRE-R1-FUERA') return 'No entra: un solo uso o calles distintas';
  if (c === 'PRE-R3') return 'Requisito lat/long';
  if (c === 'MOTOR') return 'Motor NIT · solo staging';
  if (c === 'SIN PAR') return 'N/A · sin par duplicado';
  if (c === 'SALIDA') return 'Hijas en unificacion_direccion';
  if (c === 'INSUMO') return 'Insumo antes de ESC';
  if (c === 'TEMA') return 'Conteo inicial';
  if (c === 'POST-R2') return 'Tras absorber hijas R2';
  if (/^ESC[1-6]$/.test(c)) return c;
  return 'N/A';
}}

function justificacionExtra(f) {{
  if (f.regla === 'R3' && f.personas === 0 && f.rpus === 0)
    return ' Racional 0: aún no hay coordenadas — proceso GEO + ArcGIS pendiente.';
  if (f.codigo === 'EMPATE')
    return ' Entender por qué empate: dos o más tipos con mismo puntaje; sin desempate no unifica.';
  if (f.codigo === 'ESC1' && f.regla === 'R2' && f.rpus > 0)
    return ' En DEV el 100% de la salida R2 viene por este escenario (padre con complemento).';
  return '';
}}

const CASCADE_STEPS = [
  {{ regla: 'UNIVERSO', codigo: 'TEMA', label: 'Universo total', hint: 'Todo el insumo' }},
  {{ regla: 'R1', codigo: 'PRE-R1', label: 'R1 · entran', hint: 'Misma calle · 2+ usos' }},
  {{ regla: 'R1', codigo: 'ESC3', label: 'R1 · ESC3', hint: 'Puntaje por reportes' }},
  {{ regla: 'R1', codigo: 'EMPATE', label: 'R1 · empate', hint: 'Sin ganador único' }},
  {{ regla: 'R2', codigo: 'ESC1', label: 'R2 · ESC1', hint: 'Complemento apto' }},
  {{ regla: 'R2', codigo: 'SALIDA', label: 'R2 · salida', hint: 'Hijas absorbidas' }},
  {{ regla: 'UNIVERSO', codigo: 'POST-R2', label: 'Post-R2', hint: 'Activos' }},
  {{ regla: 'R3', codigo: 'PRE-R3', label: 'R3 · geo', hint: 'Requisito coords' }},
];

function renderGlossary() {{
  const k = DATA.kpis;
  document.getElementById('glossary').innerHTML = `
    <div class="glossary-card">
      <h4>Persona</h4>
      <p>Cada titular tiene un código interno (número largo). Una persona puede tener muchos reportes de dirección. En DEV hay <strong>${{fmt(k.personas)}}</strong> personas distintas.</p>
    </div>
    <div class="glossary-card">
      <h4>Reporte de dirección</h4>
      <p>Cada vez que alguien reporta una dirección para casa, trabajo o correspondencia queda un registro con su propio código. No es «la calle» sola: es «esta persona, este uso, esta calle». En DEV hay <strong>${{fmt(k.rpus)}}</strong> reportes · promedio ${{fmtRatio(DATA.volumenes?.universo?.rpuxp)}} por persona.</p>
    </div>
    <div class="glossary-card">
      <h4>Calle normalizada</h4>
      <p>La dirección escrita y estandarizada (calle + ciudad). Varios reportes pueden apuntar a la misma calle. En DEV hay <strong>${{fmt(k.ubics || '—')}}</strong> calles distintas en los datos.</p>
    </div>
    <div class="glossary-card">
      <h4>Las tres reglas</h4>
      <p><strong>Regla 1:</strong> misma calle con casa y trabajo (u otro par de usos) → elige una dirección principal por puntaje.<br>
      <strong>Regla 2:</strong> misma calle, mismo uso, una fila con apto y otra sin apto → gana la completa.<br>
      <strong>Regla 3:</strong> calles parecidas en el mapa (necesita coordenadas; en DEV aún no corre).</p>
    </div>
  `;
}}

function renderMetricToggle() {{
  const el = document.getElementById('metricToggle');
  el.innerHTML = ['personas','rpus','ambos'].map(m =>
    `<button type="button" data-m="${{m}}" class="${{metricMode===m?'active':''}}">${{m==='personas'?'Solo personas':m==='rpus'?'Solo RPUs':'Personas + RPUs'}}</button>`
  ).join('');
  el.querySelectorAll('button').forEach(b => {{
    b.onclick = () => {{ metricMode = b.dataset.m; renderMetricToggle(); renderCascade(); renderDrillMatrix(); }};
  }});
}}

function renderCascade() {{
  const el = document.getElementById('drillCascade');
  el.innerHTML = CASCADE_STEPS.map((s, i) => {{
    const f = volGet(s.regla, s.codigo);
    const zero = f && f.personas === 0 && f.rpus === 0;
    const cls = 'cascade-box' + (i === 0 ? ' universo' : '') + (zero ? ' zero' : '');
    return `<div class="cascade-step">
      <div class="step-num">Paso ${{i + 1}}</div>
      <div class="${{cls}}" data-regla="${{esc(s.regla)}}" data-codigo="${{esc(s.codigo)}}" title="${{esc(f?.busca||'')}}">
        <div class="lbl">${{esc(s.label)}}</div>
        <div class="val">${{fmtMetric(f)}}</div>
        <div class="sub">${{esc(s.hint)}}${{f && fmtMetricSub(f) ? ' · ' + fmtMetricSub(f) : ''}}</div>
      </div>
    </div>`;
  }}).join('');
  el.querySelectorAll('.cascade-box').forEach(box => {{
    box.onclick = () => {{
      el.querySelectorAll('.cascade-box').forEach(b => b.classList.remove('active'));
      box.classList.add('active');
      const regla = box.dataset.regla, codigo = box.dataset.codigo;
      const row = document.querySelector(`#drillMatrix tr[data-regla="${{regla}}"][data-codigo="${{codigo}}"]`);
      if (row) row.scrollIntoView({{ behavior: 'smooth', block: 'center' }});
    }};
  }});
}}

function renderDrillMatrix() {{
  const filas = DATA.volumenes?.filas || [];
  const qtyHdr = metricMode === 'personas' ? 'Personas' : metricMode === 'rpus' ? 'RPUs' : 'Personas · RPUs';
  let html = `<thead><tr>
    <th>Regla</th><th>Escenario</th><th>Subescenario</th>
    <th class="num">${{qtyHdr}}</th><th class="num">RPU/pers.</th>
    <th>Por qué · justificación funcional</th>
  </tr></thead><tbody>`;
  let lastRegla = '';
  filas.forEach(f => {{
    if (f.regla !== lastRegla) {{
      html += `<tr class="section"><td colspan="6">${{esc(f.regla)}} — drill down</td></tr>`;
      lastRegla = f.regla;
    }}
    const zc = (f.personas === 0 && f.rpus === 0) ? 'zero' : '';
    const just = (f.busca || '') + justificacionExtra(f);
    html += `<tr class="${{zc}}" data-regla="${{esc(f.regla)}}" data-codigo="${{esc(f.codigo)}}">
      <td class="regla-cell">${{esc(f.regla)}}</td>
      <td>${{esc(f.codigo)}} · ${{esc(f.escenario)}}</td>
      <td class="subesc">${{esc(subescenarioLabel(f))}}</td>
      <td class="num">${{fmtMetric(f)}}</td>
      <td class="num">${{fmtRatio(f.rpuxp)}}</td>
      <td class="justif">${{esc(just)}}</td>
    </tr>`;
  }});
  html += '</tbody>';
  document.getElementById('drillMatrix').innerHTML = html;
}}

function renderDrillTable(tableId, filterFn) {{
  renderDrillMatrix();
}}

function wireScenarioQueryButtons() {{
  document.querySelectorAll('.scenario-stage').forEach(stage => {{
    stage.addEventListener('click', (e) => {{
      const btn = e.target.closest('.btn-card-query');
      if (!btn) return;
      e.preventDefault();
      e.stopPropagation();
      const row = DATA.rows[+btn.dataset.idx];
      if (!row) return;
      openQueryModal(
        row['Query validación (copiar en dba_rncr_batch)'],
        row._titulo_corto || row.Subescenario || row.Escenario
      );
    }});
  }});
}}

function renderHome() {{
  const k = DATA.kpis;
  const rules = [
    {{
      title: 'R1 · Mismo texto, distinto uso',
      tag: 'PRE-R1 · ESC1–3 · empate',
      desc: 'Personas con la misma calle y al menos dos usos (casa, trabajo, correspondencia). Puntúa y elige una dirección.',
      dev: fmt(k.r1_personas) + ' personas · ' + fmt(k.r1_rpus) + ' RPUs',
      frame: 1,
    }},
    {{
      title: 'R2 · Complemento',
      tag: 'ESC1 … ESC6 + motor',
      desc: 'Misma calle y tipo, distinto apto/oficina. Cascada hasta ESC6.',
      dev: fmt(k.r2_out) + ' hijas (100% ESC1)',
      frame: 2,
    }},
    {{
      title: 'R3 · Cercanía',
      tag: 'PRE-R3 · ESC1',
      desc: 'Calles parecidas en el mismo municipio. Requiere lat/long.',
      dev: fmt(k.r3_out) + ' hijas · sin geo en DEV',
      frame: 3,
    }},
    {{
      title: 'Perfil de datos',
      tag: 'Calidad insumo',
      desc: 'Nulos, vacíos y columnas a revisar en edf_views.',
      dev: 'Geo pendiente · tipo 8',
      frame: 4,
    }},
    {{
      title: 'Catálogo SP',
      tag: '15 archivos _pgm',
      desc: 'Un SP por escenario con nombre diciente (esc + regla de negocio).',
      dev: 'Pestaña SPs',
      frame: 5,
    }},
  ];
  document.getElementById('rulesMap').innerHTML = rules.map(r => `
    <div class="rules-card" data-frame="${{r.frame}}">
      <h3>${{esc(r.title)}}</h3>
      <span class="esc-tag">${{esc(r.tag)}}</span>
      <p>${{esc(r.desc)}}</p>
      <b>DEV: ${{esc(r.dev)}}</b>
    </div>
  `).join('');
  document.querySelectorAll('.rules-card').forEach(c => {{
    c.onclick = () => {{
      const fi = +c.dataset.frame;
      if (fi === 5) {{
        showFrame(5);
        showSpDetail(0, true);
        return;
      }}
      scenarioPos[fi] = 0;
      showFrame(fi);
      showRuleScenario(fi, 0, true);
    }};
  }});
  document.getElementById('kpiRow').innerHTML = `
    <div class="kpi"><small>Universo</small><b>${{fmt(k.personas)}}</b><span>${{fmt(k.rpus)}} RPUs</span></div>
    <div class="kpi"><small>R1 entran</small><b>${{fmt(k.r1_personas)}}</b><span>${{fmt(k.r1_rpus)}} RPUs</span></div>
    <div class="kpi"><small>R2 salida</small><b>${{fmt(k.r2_out)}}</b><span>hijas ESC1</span></div>
    <div class="kpi"><small>Post-R2</small><b>${{fmt(k.post_r2)}}</b><span>RPUs activos</span></div>
    <div class="kpi"><small>R3</small><b>${{fmt(k.r3_out)}}</b><span>bloqueada geo</span></div>
  `;
  renderGlossary();
  renderMetricToggle();
  renderCascade();
  renderDrillMatrix();
}}

function renderStepNav() {{
  document.getElementById('stepNav').innerHTML = FRAMES.map((f,i) =>
    `<button type="button" class="step-btn" data-idx="${{i}}">${{esc(f.label)}}</button>`
  ).join('');
  document.querySelectorAll('.step-btn').forEach(b => {{
    b.onclick = () => zoomToFrame(+b.dataset.idx);
  }});
}}

renderStepNav();
renderHome();
initRuleFrames();
wireScenarioQueryButtons();
window.addEventListener('resize', () => {{
  showFrame(currentFrame);
  fitRuleStage();
}});
showFrame(0);
</script>
</body>
</html>"""


def main() -> int:
    import os
    import subprocess

    # Usar samples cacheados si no hay password (no bloquear regeneración HTML)
    try:
        refresh_samples()
    except Exception as e:
        print(f"refresh_samples skip: {e}")
    env = os.environ.copy()
    if env.get("REDSHIFT_CONSUMER_PASSWORD") or env.get("REDSHIFT_PASSWORD"):
        subprocess.run(
            [sys.executable, str(ROOT / "tools" / "fetch_drill_down_volumenes.py")],
            cwd=str(ROOT),
            env=env,
            check=False,
        )
    samples = load_samples()
    vol = load_volumenes()
    rows = [row_dict(r, vol, samples) for r in build_rows(samples)]
    payload = {
        "generated": date.today().isoformat(),
        "kpis": kpis(samples, vol),
        "volumenes": {k: vol[k] for k in ("generated", "universo", "filas") if k in vol},
        "rows": rows,
        "sps_detalle": build_sps_detalle(),
        "repos_bitbucket": build_repos_bitbucket(),
    }
    OUT.write_text(render_html(payload), encoding="utf-8")
    # sync copies
    for dest in (
        ROOT / "repos" / "db_rcncr_btch_rdshft_dt" / "docs" / OUT.name,
        ROOT / "deploy_bitbucket" / "db_rcncr_btch_rdshft_dt" / "docs" / OUT.name,
    ):
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(OUT.read_text(encoding="utf-8"), encoding="utf-8")
            print(f"Copied: {dest}")
        except Exception as e:
            print(f"skip copy {dest}: {e}")
    print(f"Exported: {OUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
