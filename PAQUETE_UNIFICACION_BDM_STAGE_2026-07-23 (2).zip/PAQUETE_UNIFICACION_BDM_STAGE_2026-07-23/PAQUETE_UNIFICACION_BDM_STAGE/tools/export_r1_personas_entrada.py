"""Exporta las personas que entran a R1 (156 en DEV) — CSV + JSON."""
from __future__ import annotations

import csv
import json
import os
import sys
from pathlib import Path

import psycopg2
from psycopg2.extras import RealDictCursor

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from mapa_r1_sql import R1_RESUMEN_PERSONA_SQL  # noqa: E402

HOST = "eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com"
DB = os.environ.get("REDSHIFT_CONSUMER_DB", "dba_rncr_batch")
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PWD = os.environ.get("REDSHIFT_CONSUMER_PASSWORD", os.environ.get("REDSHIFT_PASSWORD", ""))
PORT = int(os.environ.get("REDSHIFT_PORT", "5440"))

OUT_CSV = ROOT / "Documentacion" / "r1_personas_entrada_DEV.csv"
OUT_JSON = ROOT / "Documentacion" / "r1_personas_entrada_DEV.json"


def main() -> int:
    if not PWD:
        print("Defina REDSHIFT_CONSUMER_PASSWORD o REDSHIFT_PASSWORD", file=sys.stderr)
        return 1
    conn = psycopg2.connect(
        host=HOST,
        port=PORT,
        dbname=DB,
        user=USER,
        password=PWD,
        sslmode="require",
        connect_timeout=120,
    )
    conn.autocommit = True
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute(R1_RESUMEN_PERSONA_SQL)
    rows = [dict(r) for r in cur.fetchall()]
    cur.close()
    conn.close()

    OUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    fields = [
        "id_buro_persona",
        "cod_pin_persona",
        "calles_r1",
        "rpus_r1",
        "rpus_por_calle",
    ]
    with OUT_CSV.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k) for k in fields})

    payload = {
        "generated": "DEV",
        "criterio": "Misma calle + ciudad con 2+ usos (casa/trabajo/correspondencia)",
        "total_personas": len(rows),
        "total_rpus": sum(int(r.get("rpus_r1") or 0) for r in rows),
        "personas": rows,
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2, ensure_ascii=False, default=str), encoding="utf-8")

    print(f"Personas R1 entrada: {len(rows)}")
    print(f"CSV:  {OUT_CSV}")
    print(f"JSON: {OUT_JSON}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
