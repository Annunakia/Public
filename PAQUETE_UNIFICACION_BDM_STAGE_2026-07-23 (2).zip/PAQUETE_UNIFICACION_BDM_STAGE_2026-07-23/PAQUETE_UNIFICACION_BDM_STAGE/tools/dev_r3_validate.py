"""Check/load R3 mocks on DEV, deploy R3 SP, run validation TC-R3-01/08/10."""
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import psycopg2
from psycopg2.extras import RealDictCursor

ROOT = Path(__file__).resolve().parents[1]
HOST = os.environ.get(
    "REDSHIFT_HOST",
    "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com",
)
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PASSWORD = os.environ.get("REDSHIFT_PASSWORD", "")

PERSONAS = (930001, 930008, 930010)


def q(cur, sql, params=None):
    cur.execute(sql, params or ())
    cols = [d[0] for d in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchall()]


def run_sql_file(cur, path):
    text = path.read_text(encoding="utf-8")
    cur.execute(text)


def validate(cur):
    checks = []

    def add(case_id, desc, sql, expect):
        rows = q(cur, sql)
        val = rows[0][list(rows[0].keys())[0]] if rows else None
        status = "PASSED" if val == expect else "FAILED"
        checks.append(
            {
                "case": case_id,
                "desc": desc,
                "value": val,
                "expected": expect,
                "status": status,
            }
        )

    add(
        "TC-R3-01",
        "Manzana 930001 no unifica en R3",
        """
        SELECT COUNT(*) AS v
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion r
          ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        WHERE r.id_buro_persona = 930001 AND u.unifica_atributos = 3
        """,
        0,
    )

    add(
        "TC-R3-08",
        "Cuadrante 930008 unifica puerta ±2",
        """
        SELECT COUNT(*) AS v
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion r
          ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        WHERE r.id_buro_persona = 930008 AND u.unifica_atributos = 3
        """,
        1,
    )

    add(
        "TC-R3-10",
        "Empate 930010 no unifica",
        """
        SELECT COUNT(*) AS v
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion r
          ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        WHERE r.id_buro_persona = 930010 AND u.unifica_atributos = 3
        """,
        0,
    )

    add(
        "TC-R3-10-X",
        "Sin traza cruzada 930010",
        """
        SELECT COUNT(*) AS v
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion r1
          ON r1.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        JOIN bdm_stage.unificacion_direccion u2
          ON u2.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
         AND u2.cod_dw_direccion_unificada = u.cod_dw_persona_ubic
        WHERE r1.id_buro_persona = 930010 AND u.unifica_atributos = 3
        """,
        0,
    )

    rows = q(
        cur,
        """
        SELECT r.id_buro_persona, r.cod_dw_persona_ubic, COALESCE(r.ind_unificacion, 0) AS ind
        FROM bdm_stage.relacion_persona_ubicacion r
        WHERE r.id_buro_persona IN (930001, 930008, 930010)
        ORDER BY 1, 2
        """,
    )
    checks.append({"case": "IND_FLAGS", "rows": rows})
    return checks


def main():
    if not PASSWORD:
        print("Set REDSHIFT_PASSWORD")
        sys.exit(1)

    report = {
        "host": HOST,
        "user": USER,
        "executed_at": datetime.now().isoformat(),
    }

    conn = psycopg2.connect(
        host=HOST,
        port=5440,
        dbname="dba_batch",
        user=USER,
        password=PASSWORD,
        sslmode="require",
        connect_timeout=60,
    )
    conn.autocommit = True
    cur = conn.cursor(cursor_factory=RealDictCursor)

    report["personas_before"] = q(
        cur,
        """
        SELECT id_buro_persona, COUNT(*) AS n
        FROM bdm_stage.relacion_persona_ubicacion
        WHERE id_buro_persona IN %s
        GROUP BY 1 ORDER BY 1
        """,
        (PERSONAS,),
    )

    mock_path = ROOT / "sql" / "qa_redshift" / "mock_tc_r3_01_08_10.sql"
    try:
        run_sql_file(cur, mock_path)
        report["mock_load"] = "ok"
    except Exception as e:
        report["mock_load"] = str(e)

    report["personas_after_load"] = q(
        cur,
        """
        SELECT id_buro_persona, COUNT(*) AS n
        FROM bdm_stage.relacion_persona_ubicacion
        WHERE id_buro_persona IN %s
        GROUP BY 1 ORDER BY 1
        """,
        (PERSONAS,),
    )

    sp_path = ROOT / "sql" / "07_sp_regla3.sql"
    try:
        run_sql_file(cur, sp_path)
        report["sp_deploy"] = "ok"
    except Exception as e:
        report["sp_deploy"] = str(e)

    for pid in PERSONAS:
        cur.execute(
            """
            DELETE FROM bdm_stage.unificacion_direccion
            WHERE cod_dw_persona_ubic IN (
              SELECT cod_dw_persona_ubic FROM bdm_stage.relacion_persona_ubicacion
              WHERE id_buro_persona = %s
            )
            """,
            (pid,),
        )
        cur.execute(
            """
            UPDATE bdm_stage.relacion_persona_ubicacion
            SET ind_unificacion = NULL
            WHERE id_buro_persona = %s
            """,
            (pid,),
        )

    try:
        cur.execute("CALL bdm_stage.sp_unificacion_regla3()")
        report["r3_run"] = "ok"
    except Exception as e:
        report["r3_run"] = str(e)

    report["validation"] = validate(cur)
    report["summary"] = {
        "passed": sum(1 for c in report["validation"] if c.get("status") == "PASSED"),
        "failed": [c for c in report["validation"] if c.get("status") == "FAILED"],
    }

    out = ROOT / "tools" / "dev_r3_validation_results.json"
    out.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    print(json.dumps(report, indent=2, default=str))
    cur.close()
    conn.close()


if __name__ == "__main__":
    main()
