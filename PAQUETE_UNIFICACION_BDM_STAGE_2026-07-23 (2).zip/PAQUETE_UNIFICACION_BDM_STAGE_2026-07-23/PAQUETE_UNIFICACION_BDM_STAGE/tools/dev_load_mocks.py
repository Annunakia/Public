"""Load all mocks on DEV with autocommit."""
import os, json, psycopg2

HOST = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
PWD = os.environ["REDSHIFT_PASSWORD"]

MOCKS = [
    (888001,1888001,888001001,888001101,888001102,888001001,888001002,"CL 45 12 33 MOCK DEV RES-LAB","","",1,2,"MOCK_TC_R1_01",
     [(888001001,901),(888001002,902),(888001002,903),(888001002,904),(888001002,905)],[]),
    (888002,1888002,888002001,888002101,888002102,888002001,888002002,"CL 45 12 33 MOCK DEV AP301-IN301","AP 301","IN 301",1,1,"MOCK_TC_R2_COMP",
     [(888002001,901),(888002001,902),(888002002,903)],[]),
    (888003,1888003,888003001,888003101,888003102,888003001,888003002,"CL 80 55 18 MOCK DEV TC-R2-13","CS 5","PI 5",1,1,"MOCK_TC_R2_13",
     [(888003001,911),(888003001,912),(888003001,913),(888003002,914),(888003002,915)],[("CS 5","CS","5",10),("PI 5","PI","5",4)]),
    (888004,1888004,888004001,888004101,888004102,888004001,888004002,"CL 95 18 42 MOCK DEV TC-R2-14","CS 8","PI 8",1,1,"MOCK_TC_R2_14",
     [(888004001,921),(888004001,922),(888004002,923),(888004002,924)],[("CS 8","CS","8",10),("PI 8","PI","8",10)]),
]

conn = psycopg2.connect(host=HOST, port=5440, dbname="dba_batch", user="c32525e", password=PWD, sslmode="require")
conn.autocommit = True
cur = conn.cursor()
out = {}
for m in MOCKS:
    pid,pin,ubic,df1,df2,rpu1,rpu2,texto,c1,c2,t1,t2,sc,reps,dic = m
    cur.execute("SELECT COUNT(*) FROM bdm_stage.relacion_persona_ubicacion WHERE id_buro_persona=%s", (pid,))
    if cur.fetchone()[0] > 0:
        out[pid] = "exists"; continue
    try:
        cur.execute("INSERT INTO bdm_stage.ubicacion_estandarizada VALUES (%s,%s,1,NULL,NULL)", (ubic, texto))
        cur.execute("INSERT INTO bdm_stage.direccion_fisica VALUES (%s,%s,%s,'CL','45','12','33',NULL),(%s,%s,%s,'CL','45','12','33',NULL)",
                    (df1,c1,ubic,df2,c2,ubic))
        cur.execute("INSERT INTO bdm_stage.ciiu_persona VALUES (%s,'10')", (pid,))
        cur.execute("""INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
            (%s,%s,%s,%s,%s,%s,NULL,1,DATE '2025-06-01',99,1),
            (%s,%s,%s,%s,%s,%s,NULL,2,DATE '2025-06-01',99,1)""",
            (rpu1,pid,pin,ubic,df1,t1,rpu2,pid,pin,ubic,df2,t2))
        for rpu,sub in reps:
            cur.execute("INSERT INTO bdm_stage.reporte_relacion_persona_ubica VALUES (%s,%s,DATE '2025-05-01',99)", (rpu,sub))
        for nom,nomen,val,freq in dic:
            cur.execute("INSERT INTO bdm_stage.diccionario_complementos VALUES (%s,%s,%s,%s,%s,%s)", (ubic,pid,nom,nomen,val,freq))
        cur.execute("DELETE FROM bdm_stage.perf_persona_meta WHERE id_buro_persona=%s", (pid,))
        cur.execute("INSERT INTO bdm_stage.perf_persona_meta VALUES (%s,%s,%s)", (pid,pid,sc))
        out[pid] = "inserted"
    except Exception as e:
        out[pid] = str(e)
print(json.dumps(out, indent=2))
