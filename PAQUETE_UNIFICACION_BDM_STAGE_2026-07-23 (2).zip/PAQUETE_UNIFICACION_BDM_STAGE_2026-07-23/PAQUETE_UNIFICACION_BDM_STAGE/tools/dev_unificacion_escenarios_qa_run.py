"""QA DEV — despliega SPs por escenario, ejecuta y valida antes de Bitbucket deploy."""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path

import psycopg2
from psycopg2.extras import RealDictCursor

ROOT = Path(__file__).resolve().parents[1]
DEV_SQL = ROOT / "sql" / "dev_edf_datasharing"
SCENARIO_SQL = ROOT / "sql" / "unificacion_por_escenario"
DEPLOY_PAR = (
    ROOT / "deploy_bitbucket" / "db_rcncr_btch_rdshft_pgm" / "deploy" / "redshift" / "deploy.par"
)
VALIDACIONES = ROOT / "sql" / "qa_ifr_data" / "03_validaciones_unificacion.sql"
RUN_SQL = (
    ROOT
    / "deploy_bitbucket"
    / "db_rcncr_btch_rdshft_dt"
    / "deploy"
    / "redshift"
    / "SQL"
    / "run_unificacion_ejecucion_secuencial.sql"
)
DOC_OUT = ROOT / "Documentacion" / "Evidencias_QA_UNIFICACION_ESCENARIOS_DEV.md"

CONSUMER_HOST = os.environ.get(
    "REDSHIFT_CONSUMER_HOST",
    "eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com",
)
PORT = int(os.environ.get("REDSHIFT_PORT", "5440"))
CONSUMER_DB = os.environ.get("REDSHIFT_CONSUMER_DB", "dba_rncr_batch")
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PASSWORD = os.environ.get("REDSHIFT_CONSUMER_PASSWORD", os.environ.get("REDSHIFT_PASSWORD", ""))

# Baseline monolito validado 2026-09-01 (edf_views DEV)
BASELINE = {
    "r2_unificaciones": 72448,
    "c03_hijos_sin_padre": 0,
    "c04_autoreferencia": 0,
}

SETUP_STAGES = [
    ("prerequisitos", DEV_SQL / "00_prerequisitos_dev.sql"),
    ("ddl", DEV_SQL / "01_ddl_unificacion_direccion.sql"),
    ("vistas", DEV_SQL / "00_vistas_insumo_bdm.sql"),
    ("smoke", DEV_SQL / "00_validar_solo_lectura_edf_views.sql"),
]


def split_sql(text: str) -> list[str]:
    parts = re.split(r";\s*\n", text)
    out = []
    for p in parts:
        stmt = p.strip()
        if not stmt:
            continue
        lines = [ln for ln in stmt.splitlines() if ln.strip() and not ln.strip().startswith("--")]
        if not lines:
            continue
        out.append(stmt if stmt.endswith(";") else stmt + ";")
    return out


def rows_to_dicts(cur) -> list[dict]:
    if not cur.description:
        return []
    rows = cur.fetchall()
    if rows and hasattr(rows[0], "keys"):
        return [dict(r) for r in rows]
    cols = [d[0] for d in cur.description]
    return [dict(zip(cols, r)) for r in rows]


def connect():
    return psycopg2.connect(
        host=CONSUMER_HOST,
        port=PORT,
        dbname=CONSUMER_DB,
        user=USER,
        password=PASSWORD,
        sslmode="require",
        connect_timeout=120,
    )


def exec_whole(cur, path: Path, label: str) -> dict:
    try:
        cur.execute(path.read_text(encoding="utf-8-sig"))
        return {"label": label, "file": path.name, "ok": True}
    except Exception as e:
        cur.connection.rollback()
        return {"label": label, "file": path.name, "ok": False, "error": str(e)}


def exec_statements(cur, path: Path, label: str) -> dict:
    errors, result_sets = [], []
    for stmt in split_sql(path.read_text(encoding="utf-8-sig")):
        try:
            cur.execute(stmt)
            if cur.description:
                result_sets.append({"statement": stmt[:120], "rows": rows_to_dicts(cur)})
        except Exception as e:
            cur.connection.rollback()
            errors.append({"statement": stmt[:120], "error": str(e)})
    return {
        "label": label,
        "file": path.name,
        "ok": len(errors) == 0,
        "errors": errors,
        "result_sets": result_sets,
    }


def load_sp_order() -> list[str]:
    if DEPLOY_PAR.exists():
        return [ln.strip() for ln in DEPLOY_PAR.read_text(encoding="utf-8").splitlines() if ln.strip()]
    return sorted(p.name for p in SCENARIO_SQL.glob("sp_*.sql"))


def run_assertions(cur) -> list[dict]:
    checks = []

    cur.execute(
        """
        SELECT unifica_atributos, COUNT(*)::BIGINT AS n
        FROM bdm_datos.unificacion_direccion
        GROUP BY 1 ORDER BY 1
        """
    )
    por_regla = rows_to_dicts(cur)
    checks.append({"id": "B02_por_regla", "rows": por_regla, "ok": True})

    r2 = next((r["n"] for r in por_regla if r.get("unifica_atributos") == 2), None)
    checks.append(
        {
            "id": "PARITY_R2_COUNT",
            "expected": BASELINE["r2_unificaciones"],
            "actual": r2,
            "ok": r2 == BASELINE["r2_unificaciones"],
        }
    )

    for vid, sql in [
        (
            "C03_hijos_sin_padre",
            "SELECT COUNT(*)::BIGINT AS n FROM bdm_datos.unificacion_direccion WHERE cod_dw_direccion_unificada IS NULL",
        ),
        (
            "C04_autoreferencia",
            "SELECT COUNT(*)::BIGINT AS n FROM bdm_datos.unificacion_direccion WHERE cod_dw_persona_ubic = cod_dw_direccion_unificada",
        ),
    ]:
        cur.execute(sql)
        n = rows_to_dicts(cur)[0]["n"]
        exp = BASELINE["c03_hijos_sin_padre"] if "C03" in vid else BASELINE["c04_autoreferencia"]
        checks.append({"id": vid, "expected": exp, "actual": n, "ok": n == exp})

    cur.execute(
        """
        SELECT COUNT(*)::BIGINT AS rpus
        FROM bdm_tempo.v_xpm_relacion_persona_ubicacion
        """
    )
    checks.append({"id": "UNIVERSO_RPU", "rows": rows_to_dicts(cur), "ok": True})

    return checks


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-setup", action="store_true", help="Solo redeploy SPs + run + validar")
    ap.add_argument("--deploy-only", action="store_true")
    args = ap.parse_args()

    if not PASSWORD:
        print("Set REDSHIFT_CONSUMER_PASSWORD or REDSHIFT_PASSWORD", file=sys.stderr)
        return 1

    log: list[dict] = []
    conn = connect()
    conn.autocommit = True
    cur = conn.cursor(cursor_factory=RealDictCursor)

    if not args.skip_setup:
        for label, path in SETUP_STAGES:
            print(f"[{label}] ...", end=" ", flush=True)
            r = exec_statements(cur, path, label) if label == "smoke" else exec_whole(cur, path, label)
            log.append(r)
            print("OK" if r["ok"] else "FAIL")
            if not r["ok"]:
                print(r.get("error") or r.get("errors"))
                conn.close()
                return 1

    for fname in load_sp_order():
        path = SCENARIO_SQL / fname
        if not path.exists():
            path = ROOT / "deploy_bitbucket" / "db_rcncr_btch_rdshft_pgm" / "deploy" / "redshift" / "SQL" / fname
        print(f"[deploy {fname}] ...", end=" ", flush=True)
        r = exec_whole(cur, path, f"deploy_{fname}")
        log.append(r)
        print("OK" if r["ok"] else "FAIL")
        if not r["ok"]:
            print(r["error"])
            conn.close()
            return 1

    if args.deploy_only:
        conn.close()
        print("Deploy-only OK")
        return 0

    print("[execute] ...", end=" ", flush=True)
    r = exec_statements(cur, RUN_SQL, "execute")
    log.append(r)
    print("OK" if r["ok"] else "FAIL")
    if not r["ok"]:
        print(r["errors"])
        conn.close()
        return 1

    print("[validaciones] ...", end=" ", flush=True)
    r = exec_statements(cur, VALIDACIONES, "validaciones")
    log.append(r)
    print("OK" if r["ok"] else "FAIL")

    checks = run_assertions(cur)
    all_ok = r["ok"] and all(c.get("ok") for c in checks if "expected" in c or c["id"] == "PARITY_R2_COUNT")

    print("\n=== ASSERTIONS ===")
    print(json.dumps(checks, indent=2, default=str))

    conn.close()

    lines = [
        f"# Evidencias QA — Unificación por escenario (DEV)\n",
        f"Fecha: {datetime.now().isoformat(timespec='seconds')}\n\n",
        "## Stages\n",
    ]
    for item in log:
        lines.append(f"- **{item['label']}**: {'OK' if item.get('ok') else 'FAIL'}\n")
    lines.append("\n## Assertions\n```json\n")
    lines.append(json.dumps(checks, indent=2, default=str))
    lines.append("\n```\n")
    lines.append(f"\n**Resultado:** {'PASS' if all_ok else 'FAIL'}\n")
    DOC_OUT.write_text("".join(lines), encoding="utf-8")
    print(f"Report: {DOC_OUT}")
    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
