"""Fetch live counts + example IDs from Reconocer DEV for drill-down Excel."""
from __future__ import annotations

import json
import os
import sys

import psycopg2
from psycopg2.extras import RealDictCursor

HOST = "eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com"
DB = os.environ.get("REDSHIFT_CONSUMER_DB", "dba_rncr_batch")
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PWD = os.environ.get("REDSHIFT_CONSUMER_PASSWORD", os.environ.get("REDSHIFT_PASSWORD", ""))
PORT = int(os.environ.get("REDSHIFT_PORT", "5440"))

QUERIES = {
    "univ": """
        SELECT COUNT(*)::BIGINT AS rpus,
               COUNT(DISTINCT id_buro_persona)::BIGINT AS personas,
               COUNT(DISTINCT cod_dw_ubic)::BIGINT AS ubicaciones
        FROM bdm_tempo.v_xpm_relacion_persona_ubicacion
    """,
    "r1_total": "SELECT COUNT(*)::BIGINT AS n FROM bdm_datos.unificacion_direccion WHERE unifica_atributos = 1",
    "r1_cand": """
        WITH ubi1 AS (
          SELECT cod_dw_ubic, texto_ubicacion, cod_dw_ciudad
          FROM bdm_tempo.v_xpm_ubicacion_estandarizada
          GROUP BY 1, 2, 3
        ),
        grupos AS (
          SELECT rpu.id_buro_persona, ubi.texto_ubicacion, ubi.cod_dw_ciudad
          FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
          JOIN ubi1 ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
          GROUP BY 1, 2, 3
          HAVING COUNT(DISTINCT rpu.cod_dw_tipo_ubicacion_dir) > 1
        )
        SELECT
          (SELECT COUNT(*) FROM grupos)::BIGINT AS grupos,
          (SELECT COUNT(DISTINCT id_buro_persona) FROM grupos)::BIGINT AS personas,
          (SELECT COUNT(DISTINCT rpu.cod_dw_persona_ubic)::BIGINT
           FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
           JOIN ubi1 ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
           JOIN grupos g ON rpu.id_buro_persona = g.id_buro_persona
             AND ubi.texto_ubicacion = g.texto_ubicacion
             AND ubi.cod_dw_ciudad = g.cod_dw_ciudad
          ) AS rpus
    """,
    "r1_empate": """
        WITH insumo AS (
          SELECT rpu.cod_dw_persona_ubic, rpu.id_buro_persona, ubi.texto_ubicacion, ubi.cod_dw_ciudad,
            rpu.cod_dw_tipo_ubicacion_dir,
            COALESCE(ciiu.cod_act_econo_ciiu_fte, '') AS ciiu,
            COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor), 0) AS n_rep,
            tud.descripcion_tipo_ubicacion_dir AS tipo_dir
          FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
          JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
          JOIN bdm_tempo.v_xpm_reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
          LEFT JOIN bdm_tempo.v_xpm_ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona
          LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
          WHERE rpu.ind_unificacion IS NULL
          GROUP BY 1,2,3,4,5,6,8
        ),
        scored AS (
          SELECT *, CASE WHEN ciiu = '10' THEN 'ESC1' WHEN ciiu IN ('81','82','90') THEN 'ESC2' ELSE 'ESC3' END AS esc,
            CASE WHEN ciiu = '10' THEN CASE WHEN tipo_dir IN ('LAB','CRR') THEN 100000 ELSE 0 END + n_rep
                 WHEN ciiu IN ('81','82','90') THEN CASE WHEN tipo_dir IN ('RES','CRR') THEN 100000 ELSE 0 END + n_rep
                 ELSE n_rep END AS score
          FROM insumo
        ),
        mult AS (
          SELECT id_buro_persona, texto_ubicacion, cod_dw_ciudad FROM scored
          GROUP BY 1,2,3 HAVING COUNT(DISTINCT cod_dw_tipo_ubicacion_dir) > 1
        )
        SELECT COUNT(*)::BIGINT AS particiones,
               SUM(CASE WHEN cnt > 1 THEN 1 ELSE 0 END)::BIGINT AS empates
        FROM (
          SELECT s.id_buro_persona, s.texto_ubicacion, s.cod_dw_ciudad, s.esc, COUNT(*) AS cnt
          FROM scored s
          JOIN mult m USING (id_buro_persona, texto_ubicacion, cod_dw_ciudad)
          JOIN (SELECT id_buro_persona, texto_ubicacion, cod_dw_ciudad, esc, MAX(score) ms FROM scored GROUP BY 1,2,3,4) mx
            ON s.id_buro_persona=mx.id_buro_persona AND s.texto_ubicacion=mx.texto_ubicacion
           AND s.cod_dw_ciudad=mx.cod_dw_ciudad AND s.esc=mx.esc AND s.score=mx.ms
          GROUP BY 1,2,3,4
        ) t
    """,
    "r1_ej_multitipo": """
        WITH cand AS (
          SELECT rpu.id_buro_persona, ubi.texto_ubicacion, ubi.cod_dw_ciudad
          FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
          JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
          GROUP BY 1,2,3
          HAVING COUNT(DISTINCT rpu.cod_dw_tipo_ubicacion_dir) > 1
        ),
        g AS (
          SELECT id_buro_persona, texto_ubicacion, cod_dw_ciudad
          FROM cand
          ORDER BY id_buro_persona
          LIMIT 1
        )
        SELECT rpu.id_buro_persona,
               MIN(rpu.cod_dw_persona_ubic) AS cod_dw_persona_ubic,
               rpu.cod_dw_tipo_ubicacion_dir,
               MAX(tud.descripcion_tipo_ubicacion_dir) AS tipo,
               MAX(LEFT(ubi.texto_ubicacion, 60)) AS texto_ubicacion,
               MAX(NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::VARCHAR), '')) AS contacttype
        FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
        JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
        JOIN g ON rpu.id_buro_persona=g.id_buro_persona AND ubi.texto_ubicacion=g.texto_ubicacion AND ubi.cod_dw_ciudad=g.cod_dw_ciudad
        LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir=tud.cod_dw_tipo_ubicacion_dir
        LEFT JOIN ds_dba_rncr_batch.edf_views.xpm_location_val_contactinformations ci ON ci.id = rpu.cod_dw_persona_ubic
        GROUP BY rpu.id_buro_persona, rpu.cod_dw_tipo_ubicacion_dir
        ORDER BY rpu.cod_dw_tipo_ubicacion_dir
    """,
    "r1_ej_score": """
        WITH cand AS (
          SELECT rpu.id_buro_persona, ubi.texto_ubicacion, ubi.cod_dw_ciudad
          FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
          JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
          GROUP BY 1,2,3
          HAVING COUNT(DISTINCT rpu.cod_dw_tipo_ubicacion_dir) > 1
        ),
        g AS (
          SELECT id_buro_persona, texto_ubicacion, cod_dw_ciudad
          FROM cand
          ORDER BY id_buro_persona
          LIMIT 1
        ),
        insumo AS (
          SELECT rpu.cod_dw_persona_ubic, rpu.id_buro_persona, ubi.texto_ubicacion, ubi.cod_dw_ciudad,
            rpu.cod_dw_tipo_ubicacion_dir,
            COALESCE(ciiu.cod_act_econo_ciiu_fte, '') AS ciiu,
            COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor), 0) AS n_rep,
            tud.descripcion_tipo_ubicacion_dir AS tipo_dir
          FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
          JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
          JOIN bdm_tempo.v_xpm_reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
          LEFT JOIN bdm_tempo.v_xpm_ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona
          LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
          JOIN g ON rpu.id_buro_persona = g.id_buro_persona
            AND ubi.texto_ubicacion = g.texto_ubicacion
            AND ubi.cod_dw_ciudad = g.cod_dw_ciudad
          WHERE rpu.ind_unificacion IS NULL
          GROUP BY 1,2,3,4,5,6,8
        ),
        by_tipo AS (
          SELECT id_buro_persona, texto_ubicacion, cod_dw_ciudad, cod_dw_tipo_ubicacion_dir,
                 MAX(tipo_dir) AS tipo_dir, MAX(ciiu) AS ciiu, MAX(n_rep) AS n_rep,
                 MIN(cod_dw_persona_ubic) AS rpu
          FROM insumo
          GROUP BY 1,2,3,4
        ),
        scored AS (
          SELECT *,
            CASE WHEN ciiu = '10' THEN 'ESC1'
                 WHEN ciiu IN ('81','82','90') THEN 'ESC2'
                 ELSE 'ESC3' END AS esc,
            CASE WHEN ciiu = '10' THEN CASE WHEN tipo_dir IN ('LAB','CRR') THEN 100000 ELSE 0 END + n_rep
                 WHEN ciiu IN ('81','82','90') THEN CASE WHEN tipo_dir IN ('RES','CRR') THEN 100000 ELSE 0 END + n_rep
                 ELSE n_rep END AS score
          FROM by_tipo
        )
        SELECT id_buro_persona, rpu, cod_dw_tipo_ubicacion_dir, tipo_dir,
               LEFT(texto_ubicacion, 60) AS texto_ubicacion, ciiu, esc, n_rep, score
        FROM scored
        ORDER BY cod_dw_tipo_ubicacion_dir
    """,
    "r1_ej_fuera": """
        WITH grp AS (
          SELECT rpu.id_buro_persona, ubi.texto_ubicacion, ubi.cod_dw_ciudad,
                 COUNT(DISTINCT rpu.cod_dw_tipo_ubicacion_dir) AS n_tipos
          FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
          JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
          GROUP BY 1,2,3
        )
        SELECT TOP 1 rpu.id_buro_persona, rpu.cod_dw_persona_ubic,
               tud.descripcion_tipo_ubicacion_dir AS tipo, ubi.texto_ubicacion, g.n_tipos
        FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
        JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
        JOIN grp g ON rpu.id_buro_persona=g.id_buro_persona AND ubi.texto_ubicacion=g.texto_ubicacion
                  AND ubi.cod_dw_ciudad=g.cod_dw_ciudad AND g.n_tipos = 1
        LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir=tud.cod_dw_tipo_ubicacion_dir
        ORDER BY rpu.cod_dw_persona_ubic
    """,
    "r1_ct": """
        SELECT NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::VARCHAR), '') AS ct,
               COUNT(*)::BIGINT AS n
        FROM ds_dba_rncr_batch.edf_views.xpm xpm
        JOIN ds_dba_rncr_batch.edf_views.xpm_location loc ON xpm.location = loc.id
        JOIN ds_dba_rncr_batch.edf_views.xpm_location_val_contactinformations ci
          ON loc."location.val.contactinformations" = ci.id
        WHERE NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::VARCHAR), '') IN ('1','2','3','7','8')
        GROUP BY 1 ORDER BY n DESC
    """,
    "r2_total": "SELECT COUNT(*)::BIGINT AS n FROM bdm_datos.unificacion_direccion WHERE unifica_atributos = 2",
    "r2_ej": """
        SELECT TOP 3
          u.cod_dw_persona_ubic AS hija_rpu,
          u.cod_dw_direccion_unificada AS padre_rpu,
          df_h.complemento AS comp_hija,
          df_p.complemento AS comp_padre,
          ubi.texto_ubicacion AS dir,
          tud.descripcion_tipo_ubicacion_dir AS tipo
        FROM bdm_datos.unificacion_direccion u
        JOIN bdm_tempo.v_xpm_direccion_fisica df_h ON df_h.cod_dw_direccion_fisica = u.cod_dw_persona_ubic
        JOIN bdm_tempo.v_xpm_direccion_fisica df_p ON df_p.cod_dw_direccion_fisica = u.cod_dw_direccion_unificada
        JOIN bdm_tempo.v_xpm_relacion_persona_ubicacion rpu ON rpu.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
        LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
        WHERE u.unifica_atributos = 2
        ORDER BY u.cod_dw_persona_ubic
    """,
    "r2_ct8": """
        SELECT COUNT(*)::BIGINT AS hijas_ct8
        FROM bdm_datos.unificacion_direccion u
        JOIN ds_dba_rncr_batch.edf_views.xpm_location_val_contactinformations ci ON ci.id = u.cod_dw_persona_ubic
        WHERE u.unifica_atributos = 2
          AND NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::VARCHAR), '') = '8'
    """,
    "r3_geo": """
        SELECT SUM(CASE WHEN ubi.latitud IS NOT NULL THEN 1 ELSE 0 END)::BIGINT AS con_lat,
               COUNT(DISTINCT rpu.cod_dw_persona_ubic)::BIGINT AS rpus
        FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
        JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
    """,
    "r3_total": "SELECT COUNT(*)::BIGINT AS n FROM bdm_datos.unificacion_direccion WHERE unifica_atributos = 3",
    "r3_pot_ej": """
        WITH ins AS (
          SELECT rpu.cod_dw_persona_ubic, rpu.id_buro_persona, LEFT(ubi.texto_ubicacion,50) AS dir,
            ubi.cod_dw_ciudad AS mun, COALESCE(cnt.n,0) AS n_rep
          FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
          JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
          LEFT JOIN (
            SELECT cod_dw_persona_ubic, COUNT(DISTINCT id_buro_suscriptor) AS n
            FROM bdm_tempo.v_xpm_reporte_relacion_persona_ubica GROUP BY 1
          ) cnt ON cnt.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
        )
        SELECT TOP 1 a.cod_dw_persona_ubic AS padre_rpu, b.cod_dw_persona_ubic AS hija_rpu,
               a.dir AS dir_padre, b.dir AS dir_hija, a.n_rep AS rep_padre, b.n_rep AS rep_hija
        FROM ins a JOIN ins b
          ON a.id_buro_persona = b.id_buro_persona AND a.mun = b.mun
         AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
         AND SPLIT_PART(a.dir,' ',1) = SPLIT_PART(b.dir,' ',1)
         AND SPLIT_PART(a.dir,' ',2) = SPLIT_PART(b.dir,' ',2)
         AND a.n_rep > b.n_rep
    """,
    "prof_comp": """
        SELECT CASE WHEN df.complemento IS NULL THEN 'NULL'
               WHEN LENGTH(TRIM(df.complemento)) = 0 THEN 'VACIO'
               ELSE 'CON_VALOR' END AS estado_complemento,
               COUNT(*)::BIGINT AS n
        FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
        JOIN bdm_tempo.v_xpm_direccion_fisica df ON df.cod_dw_direccion_fisica = rpu.cod_dw_persona_ubic
        GROUP BY 1 ORDER BY 1
    """,
    "prof_texto": """
        SELECT CASE WHEN ubi.texto_ubicacion IS NULL OR LENGTH(TRIM(ubi.texto_ubicacion)) = 0
               THEN 'VACIO' ELSE 'OK' END AS estado_texto,
               COUNT(*)::BIGINT AS n
        FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
        JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
        GROUP BY 1
    """,
    "prof_geo": """
        SELECT SUM(CASE WHEN ubi.latitud IS NOT NULL AND ubi.longitud IS NOT NULL THEN 1 ELSE 0 END)::BIGINT AS con_geo,
               SUM(CASE WHEN ubi.latitud IS NULL OR ubi.longitud IS NULL THEN 1 ELSE 0 END)::BIGINT AS sin_geo,
               COUNT(*)::BIGINT AS total
        FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
        JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
    """,
    "prof_ciiu": """
        SELECT SUM(CASE WHEN ciiu.cod_act_econo_ciiu_fte IS NULL OR TRIM(ciiu.cod_act_econo_ciiu_fte) = ''
               THEN 1 ELSE 0 END)::BIGINT AS sin_ciiu,
               COUNT(*)::BIGINT AS total
        FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
        LEFT JOIN bdm_tempo.v_xpm_ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona
    """,
    "prof_score": """
        SELECT SUM(CASE WHEN cd.score_estandarizacion IS NULL THEN 1 ELSE 0 END)::BIGINT AS sin_score,
               COUNT(*)::BIGINT AS total
        FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
        JOIN bdm_tempo.v_xpm_contacto_direccion cd ON cd.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
    """,
    "prof_dane": """
        SELECT SUM(CASE WHEN ubi.cod_dw_ciudad IS NULL THEN 1 ELSE 0 END)::BIGINT AS sin_ciudad,
               COUNT(*)::BIGINT AS total
        FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
        JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
    """,
    "prof_ct": """
        SELECT CASE
          WHEN NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::VARCHAR), '') IS NULL THEN 'NULL'
          WHEN NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::VARCHAR), '') IN ('1','2','3','7','8') THEN 'CATALOGO'
          ELSE 'FUERA_CATALOGO' END AS estado_ct,
          COUNT(*)::BIGINT AS n
        FROM ds_dba_rncr_batch.edf_views.xpm xpm
        JOIN ds_dba_rncr_batch.edf_views.xpm_location loc ON xpm.location = loc.id
        JOIN ds_dba_rncr_batch.edf_views.xpm_location_val_contactinformations ci
          ON loc."location.val.contactinformations" = ci.id
        GROUP BY 1 ORDER BY 1
    """,
}


def fmt_r1_ej(rows: list) -> str:
    if not rows:
        return "Sin muestra (ejecutar tras vistas desplegadas)"
    if isinstance(rows, dict):
        rows = [rows]
    pid = rows[0]["id_buro_persona"]
    parts = [f"id_buro_persona={pid}"]
    seen_tipo: set = set()
    for r in rows:
        td = r.get("cod_dw_tipo_ubicacion_dir")
        if td in seen_tipo:
            continue
        seen_tipo.add(td)
        parts.append(
            f"RPU {r['cod_dw_persona_ubic']} ct={r.get('contacttype','?')} "
            f"tipo {r.get('tipo')}({td}) | {str(r.get('texto_ubicacion',''))[:40]}"
        )
        if len(seen_tipo) >= 4:
            break
    return " // ".join(parts)


def fmt_r2_ej(rows: list) -> str:
    if not rows:
        return "Sin muestra"
    r = rows[0]
    return (
        f"hija RPU {r['hija_rpu']} comp='{r['comp_hija'] or ''}' → "
        f"padre RPU {r['padre_rpu']} comp='{r['comp_padre']}' | {r['dir']} | {r['tipo']}"
    )


R1_SCORE_PARTITION_SQL = """
WITH insumo AS (
  SELECT rpu.cod_dw_persona_ubic, rpu.id_buro_persona, ubi.texto_ubicacion, ubi.cod_dw_ciudad,
    rpu.cod_dw_tipo_ubicacion_dir,
    COALESCE(ciiu.cod_act_econo_ciiu_fte, '') AS ciiu,
    COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor), 0) AS n_rep,
    tud.descripcion_tipo_ubicacion_dir AS tipo_dir
  FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
  JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  JOIN bdm_tempo.v_xpm_reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  LEFT JOIN bdm_tempo.v_xpm_ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona
  LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
  WHERE rpu.ind_unificacion IS NULL
    AND rpu.id_buro_persona = %s
    AND ubi.texto_ubicacion = %s
  GROUP BY 1,2,3,4,5,6,8
),
by_tipo AS (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_ciudad, cod_dw_tipo_ubicacion_dir,
         MAX(tipo_dir) AS tipo_dir, MAX(ciiu) AS ciiu, MAX(n_rep) AS n_rep,
         MIN(cod_dw_persona_ubic) AS rpu
  FROM insumo
  GROUP BY 1,2,3,4
),
scored AS (
  SELECT *,
    CASE WHEN ciiu = '10' THEN 'ESC1'
         WHEN ciiu IN ('81','82','90') THEN 'ESC2'
         ELSE 'ESC3' END AS esc,
    CASE WHEN ciiu = '10' THEN CASE WHEN tipo_dir IN ('LAB','CRR') THEN 100000 ELSE 0 END + n_rep
         WHEN ciiu IN ('81','82','90') THEN CASE WHEN tipo_dir IN ('RES','CRR') THEN 100000 ELSE 0 END + n_rep
         ELSE n_rep END AS score
  FROM by_tipo
)
SELECT id_buro_persona, rpu, cod_dw_tipo_ubicacion_dir, tipo_dir,
       LEFT(texto_ubicacion, 60) AS texto_ubicacion, ciiu, esc, n_rep, score
FROM scored
ORDER BY cod_dw_tipo_ubicacion_dir
"""


def sync_r1_score_to_multitipo(cur, out: dict) -> None:
    mt = out.get("r1_ej_multitipo")
    if not isinstance(mt, list) or len(mt) < 2:
        return
    pid = mt[0].get("id_buro_persona")
    calle = mt[0].get("texto_ubicacion")
    if pid is None or not calle:
        return
    sc = out.get("r1_ej_score") or []
    if (
        isinstance(sc, list)
        and len(sc) >= 2
        and all(s.get("id_buro_persona") == pid for s in sc)
        and all((s.get("texto_ubicacion") or "") == calle for s in sc)
    ):
        return
    try:
        cur.execute(R1_SCORE_PARTITION_SQL, (pid, calle))
        rows = [dict(r) for r in cur.fetchall()]
        if rows:
            out["r1_ej_score"] = rows
    except Exception as e:
        out["r1_ej_score_error"] = str(e).split("\n")[0]


def main() -> int:
    if not PWD:
        print("Set REDSHIFT_CONSUMER_PASSWORD", file=sys.stderr)
        return 1
    conn = psycopg2.connect(
        host=HOST, port=PORT, dbname=DB, user=USER, password=PWD, sslmode="require", connect_timeout=90
    )
    conn.autocommit = True
    cur = conn.cursor(cursor_factory=RealDictCursor)
    out: dict = {}
    for key, sql in QUERIES.items():
        try:
            cur.execute(sql)
            if cur.description and len(cur.description) == 1 and (cur.description[0].name or "") == "n":
                out[key] = dict(cur.fetchone())
            elif cur.description:
                rows = [dict(r) for r in cur.fetchall()]
                out[key] = rows[0] if len(rows) == 1 and key.endswith("_total") else rows
            else:
                out[key] = {}
        except Exception as e:
            out[key] = {"error": str(e).split("\n")[0]}
    sync_r1_score_to_multitipo(cur, out)
    cur.close()
    conn.close()

    path = os.path.join(os.path.dirname(__file__), "..", "Documentacion", "drill_down_live_samples.json")
    prev: dict = {}
    if os.path.isfile(path):
        try:
            with open(path, encoding="utf-8") as pf:
                prev = json.load(pf)
        except json.JSONDecodeError:
            prev = {}
    if not out.get("r1_ej_multitipo") and prev.get("r1_ej_multitipo"):
        out["r1_ej_multitipo"] = prev["r1_ej_multitipo"]
    if not out.get("r1_ej_multitipo"):
        from mapa_samples_helpers import resolve_r1_multitipo
        out["r1_ej_multitipo"] = resolve_r1_multitipo(out)
    if not out.get("r1_ej_score"):
        from mapa_samples_helpers import resolve_r1_scores
        out["r1_ej_score"] = resolve_r1_scores(out)
    elif prev.get("r1_ej_score") and isinstance(out.get("r1_ej_score"), dict) and out["r1_ej_score"].get("error"):
        out["r1_ej_score"] = prev["r1_ej_score"]
    if isinstance(out.get("r1_ej_multitipo"), list):
        out["r1_ej_text"] = fmt_r1_ej(out["r1_ej_multitipo"])
        mt = out["r1_ej_multitipo"]
        sc = out.get("r1_ej_score")
        if isinstance(sc, list) and sc and mt:
            pid = mt[0].get("id_buro_persona")
            calle = mt[0].get("texto_ubicacion")
            aligned = [
                s for s in sc
                if s.get("id_buro_persona") == pid
                and (not calle or (s.get("texto_ubicacion") or "") == calle)
            ]
            if aligned:
                out["r1_ej_score"] = aligned
    if isinstance(out.get("r2_ej"), list):
        out["r2_ej_text"] = fmt_r2_ej(out["r2_ej"])

    path = os.path.join(os.path.dirname(__file__), "..", "Documentacion", "drill_down_live_samples.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, default=str)
    print(json.dumps({k: v for k, v in out.items() if k not in ("r1_ej_multitipo", "r2_ej")}, default=str)[:4000])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
