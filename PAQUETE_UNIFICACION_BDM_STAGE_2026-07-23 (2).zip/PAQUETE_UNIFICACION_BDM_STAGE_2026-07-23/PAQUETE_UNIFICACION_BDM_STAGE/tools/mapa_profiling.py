"""Narrativas data profiling — vacíos, nulos y columnas a revisar."""
from __future__ import annotations


def escenario_cierre(codigo: str, titulo: str) -> str:
    return f"Escenario: {codigo} — {titulo}."


def con_prof_resumen(rpus: int, alertas: int) -> str:
    return (
        f"Perfilamos {rpus:,} RPUs del insumo edf_views (vistas bdm_tempo). "
        f"Encontramos {alertas} columnas o campos con vacíos/nulos críticos para R1, R2 o R3. "
        f"Prioridad: geo (R3 bloqueada), complemento (R2), CIIU/score (R1). "
        f"{escenario_cierre('RESUMEN', 'Panorama calidad insumo')}"
    )


def con_prof_complemento(rpus: int, null_n: int, vacio_n: int, valor_n: int) -> str:
    pct_null = 100 * null_n / max(rpus, 1)
    pct_vacio = 100 * vacio_n / max(rpus, 1)
    pct_val = 100 * valor_n / max(rpus, 1)
    return (
        f"En DEV, complemento (standardizedcomplemento → v_xpm_direccion_fisica.complemento): "
        f"NULL {null_n:,} ({pct_null:.1f}%), vacío {vacio_n:,} ({pct_vacio:.1f}%), "
        f"con valor {valor_n:,} ({pct_val:.1f}%). "
        f"R2 ESC1 exige pares padre con apto / hija sin apto — el patrón NULL/vacío es esperado en hijas. "
        f"Revisar tipo 8 (token) cuando complemento debería venir informado y no aparece. "
        f"{escenario_cierre('PROF-COMP', 'v_xpm_direccion_fisica.complemento')}"
    )


def con_prof_texto(rpus: int, vacio_n: int) -> str:
    pct = 100 * vacio_n / max(rpus, 1)
    return (
        f"texto_ubicacion vacío o NULL en {vacio_n:,} RPUs ({pct:.1f}%). "
        f"Sin texto no hay agrupación R1/R2/R3. Origen: standardizedtextoubicacion / contactasreported*. "
        f"{escenario_cierre('PROF-TEXTO', 'v_xpm_ubicacion_estandarizada.texto_ubicacion')}"
    )


def con_prof_geo(rpus: int, con_lat: int) -> str:
    pct = 100 * con_lat / max(rpus, 1)
    return (
        f"latitud/longitud en v_xpm_ubicacion_estandarizada: {con_lat:,} con valor ({pct:.1f}%) "
        f"de {rpus:,} RPUs. La vista fuerza CAST(NULL) — R3 no puede ejecutarse. "
        f"Acción: integrar geo Experian/ArcGIS en insumo o desbloquear columnas en edf_views. "
        f"{escenario_cierre('PROF-GEO', 'v_xpm_ubicacion_estandarizada.latitud/longitud')}"
    )


def con_prof_ciiu(rpus: int, sin_ciiu: int) -> str:
    pct = 100 * sin_ciiu / max(rpus, 1)
    return (
        f"Personas sin CIIU (v_xpm_ciiu_persona): {sin_ciiu:,} RPUs afectados ({pct:.1f}%). "
        f"R1 ESC3 usa solo conteo de reportes; ESC1/ESC2 requieren CIIU para bonus. "
        f"Revisar mainisiccodeforproduct en edf_views.xpm. "
        f"{escenario_cierre('PROF-CIIU', 'v_xpm_ciiu_persona.cod_act_econo_ciiu_fte')}"
    )


def con_prof_score(rpus: int, sin_score: int) -> str:
    pct = 100 * sin_score / max(rpus, 1)
    return (
        f"score_estandarizacion NULL o inválido: {sin_score:,} RPUs ({pct:.1f}%). "
        f"No bloquea reglas hoy, pero indica calidad de estandarización en fuente. "
        f"Revisar contactasstandardizedscore en edf_views. "
        f"{escenario_cierre('PROF-SCORE', 'v_xpm_contacto_direccion.score_estandarizacion')}"
    )


def con_prof_dane(rpus: int, sin_ciudad: int) -> str:
    pct = 100 * sin_ciudad / max(rpus, 1)
    return (
        f"cod_dw_ciudad NULL (DANE/cityname): {sin_ciudad:,} RPUs ({pct:.1f}%). "
        f"Agrupación R1 usa persona + texto + ciudad — sin ciudad el grupo puede fragmentarse o excluirse. "
        f"Revisar standardizeddanecode y cityname. "
        f"{escenario_cierre('PROF-DANE', 'v_xpm_ubicacion_estandarizada.cod_dw_ciudad')}"
    )


def con_prof_contacttype(rpus: int, ct8: int, ct_otros: int, ct_invalid: int) -> str:
    return (
        f"Tipo de contacto 8 (token): {ct8:,} ({100*ct8/max(rpus,1):.1f}%). "
        f"Nativos 1/2/3/7: {ct_otros:,}. Fuera catálogo o nulo: {ct_invalid:,}. "
        f"Tipo 8 alimenta CRR y explica dominancia R2; validar mapeo tipo 9 u otros no mapeados. "
        f"{escenario_cierre('PROF-CT', 'contacttype → cod_dw_tipo_ubicacion_dir')}"
    )


def con_prof_vista(rpus: int) -> str:
    return (
        f"Columnas forzadas NULL en 00_vistas_insumo_bdm.sql: latitud, longitud, lote, ind_unificacion. "
        f"relationalizelastupdate también NULL. Son deuda técnica conocida en DEV datasharing. "
        f"Revisar antes de promover a QA/producción. "
        f"{escenario_cierre('REVISAR', 'Columnas forzadas en vista')}"
    )
