"""IDs y muestras R1 con fallback cuando el fetch live viene vacío."""
from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FALLBACK_FILE = ROOT / "Documentacion" / "ejemplo_persona_r1_fallback.json"

# Última persona multitipo válida en DEV (edf_views) — no usar 0
FALLBACK_R1_MULTITIPO = [
    {
        "id_buro_persona": 5744892419337831637,
        "cod_dw_persona_ubic": 388798,
        "cod_dw_tipo_ubicacion_dir": 1,
        "tipo": "RES",
        "texto_ubicacion": "CALLE 45 67SUR-17",
        "contacttype": "9",
    },
    {
        "id_buro_persona": 5744892419337831637,
        "cod_dw_persona_ubic": 388801,
        "cod_dw_tipo_ubicacion_dir": 2,
        "tipo": "LAB",
        "texto_ubicacion": "CALLE 45 67SUR-17",
        "contacttype": "9",
    },
    {
        "id_buro_persona": 5744892419337831637,
        "cod_dw_persona_ubic": 388798,
        "cod_dw_tipo_ubicacion_dir": 3,
        "tipo": "CRR",
        "texto_ubicacion": "CALLE 45 67SUR-17",
        "contacttype": "9",
    },
]


def _load_fallback_file() -> dict:
    if FALLBACK_FILE.exists():
        try:
            return json.loads(FALLBACK_FILE.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            pass
    return {"r1_ej_multitipo": FALLBACK_R1_MULTITIPO}


def _parse_pid_from_text(text: str) -> int | None:
    if not text:
        return None
    m = re.search(r"id_buro_persona=(-?\d+)", text)
    if m:
        return int(m.group(1))
    return None


def resolve_r1_multitipo(samples: dict) -> list:
    rows = samples.get("r1_ej_multitipo") or []
    if isinstance(rows, dict):
        rows = [rows]
    if rows and rows[0].get("id_buro_persona"):
        return rows
    fb = _load_fallback_file().get("r1_ej_multitipo") or FALLBACK_R1_MULTITIPO
    if fb:
        return fb
    pid = _parse_pid_from_text(str(samples.get("r1_ej_text", "")))
    if pid:
        return [{"id_buro_persona": pid, "tipo": "RES", "texto_ubicacion": "", "cod_dw_persona_ubic": ""}]
    return FALLBACK_R1_MULTITIPO


def resolve_r1_scores(samples: dict) -> list:
    rows = samples.get("r1_ej_score") or []
    if isinstance(rows, dict):
        rows = [rows]
    if rows and rows[0].get("id_buro_persona"):
        return rows
    fb = _load_fallback_file().get("r1_ej_score") or []
    return fb if fb else []


def apply_sample_fallbacks(samples: dict) -> dict:
    """Completa muestras vacías sin pisar datos live buenos."""
    out = dict(samples)
    if not (out.get("r1_ej_multitipo") or []):
        out["r1_ej_multitipo"] = resolve_r1_multitipo(out)
    if not (out.get("r1_ej_score") or []):
        out["r1_ej_score"] = resolve_r1_scores(out)
    mt = out.get("r1_ej_multitipo") or []
    sc = out.get("r1_ej_score") or []
    if mt and sc:
        pid = mt[0].get("id_buro_persona")
        calle = mt[0].get("texto_ubicacion")
        aligned = [
            s for s in sc
            if s.get("id_buro_persona") == pid
            and (not calle or (s.get("texto_ubicacion") or "") == calle)
        ]
        if len(aligned) >= 2:
            out["r1_ej_score"] = aligned
        elif pid == (_load_fallback_file().get("id_buro_persona")):
            out["r1_ej_score"] = _load_fallback_file().get("r1_ej_score") or sc
    if not out.get("r1_ej_text") and out.get("r1_ej_multitipo"):
        pid = out["r1_ej_multitipo"][0].get("id_buro_persona")
        out["r1_ej_text"] = f"id_buro_persona={pid} (fallback documentado DEV)"
    return out


def r1_grupo_por_tipo(samples: dict) -> list[dict]:
    rows = resolve_r1_multitipo(samples)
    seen: set = set()
    out: list[dict] = []
    for r in rows:
        td = r.get("cod_dw_tipo_ubicacion_dir")
        if td in seen:
            continue
        seen.add(td)
        out.append(r)
    return out


def ids_from_samples(samples: dict) -> dict:
    tipos = r1_grupo_por_tipo(samples)
    fuera = samples.get("r1_ej_fuera")
    if isinstance(fuera, list) and fuera:
        fuera = fuera[0]
    if not isinstance(fuera, dict):
        fuera = {}
    r2_rows = samples.get("r2_ej") or []
    if isinstance(r2_rows, dict):
        r2_rows = [r2_rows]
    r2 = r2_rows[0] if r2_rows else {}
    pid = tipos[0].get("id_buro_persona") if tipos else None
    if not pid:
        pid = _parse_pid_from_text(str(samples.get("r1_ej_text", "")))
    if not pid:
        pid = FALLBACK_R1_MULTITIPO[0]["id_buro_persona"]
    u = (samples.get("univ") or [{}])[0]
    if isinstance(samples.get("univ"), list) and samples["univ"]:
        u = samples["univ"][0]
    if not isinstance(u, dict):
        u = {}
    by_tipo = {t.get("cod_dw_tipo_ubicacion_dir"): t for t in tipos}
    return {
        "pid": int(pid),
        "dir": str((tipos[0].get("texto_ubicacion") if tipos else "") or FALLBACK_R1_MULTITIPO[0]["texto_ubicacion"])[:55],
        "rpu_res": (by_tipo.get(1) or {}).get("cod_dw_persona_ubic"),
        "rpu_lab": (by_tipo.get(2) or {}).get("cod_dw_persona_ubic"),
        "rpu_crr": (by_tipo.get(3) or {}).get("cod_dw_persona_ubic"),
        "pid_fuera": fuera.get("id_buro_persona", -7811848946940219335),
        "rpu_fuera": fuera.get("cod_dw_persona_ubic", 1),
        "dir_fuera": str(fuera.get("texto_ubicacion") or "CR 14 L 71 F Sur  05")[:55],
        "tipo_fuera": fuera.get("tipo", "CRR"),
        "hija": r2.get("hija_rpu", 3),
        "padre": r2.get("padre_rpu", 2),
        "comp_padre": r2.get("comp_padre") or "AP 601",
        "dir_r2": str(r2.get("dir") or r2.get("texto_ubicacion") or "CL 84 C # 9 - 51 AP 601")[:55],
        "rpu_geo": (by_tipo.get(1) or {}).get("cod_dw_persona_ubic") or 388798,
        "multitipo_rows": tipos,
        "score_rows": resolve_r1_scores(samples),
        "rpus": int(u.get("rpus", 591166)),
        "personas": int(u.get("personas", 407351)),
    }
