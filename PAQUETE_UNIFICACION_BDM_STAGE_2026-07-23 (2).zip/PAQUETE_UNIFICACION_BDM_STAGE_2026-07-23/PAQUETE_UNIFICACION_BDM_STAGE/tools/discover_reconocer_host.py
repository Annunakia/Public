"""Try to discover Reconocer DEV endpoint by DNS/connect scan."""
import socket
import psycopg2

BASE = "eec-aws-us-eits-reconocerbatch-dev-redshift"
USER = "c32525e"
PASSWORD = os.environ.get("REDSHIFT_PASSWORD", "")

# Known sibling suffixes + variants derived from naming patterns
SUFFIXES = [
    "cee2enck00mg",   # procesosbatch DEV (unlikely same cluster)
    "cwefyckvccgy",   # procesosbatch QA
    # reconocer-specific guesses from Experian pattern (c + 11 alnum)
    "cee2enck00mh", "cee2enck00mi", "cee2enck00mj",
    "cre2enck00mg", "cre2enck00mh",
    "cee2encj00mg", "cee2enck00ng",
    "cwefyckvccgz", "cwefyckvccgx",
    "cee2fnck00mg", "cee3enck00mg",
    "cohtdqb0q8af", "cohtdqb0q8ag",
    "cwe2enck00mg", "cwe2enck00mh",
    "cee2rnck00mg", "cee2rbck00mg",  # reconocer hints
]

# Also try if cluster shares identifier pattern with shortened name
PREFIXES = [
    BASE,
    "eec-aws-us-eits-reconocer-dev-redshift",
    "eec-aws-us-eits-reconocerbatch-dev",
]

candidates = set()
for prefix in PREFIXES:
    for suf in SUFFIXES:
        candidates.add(f"{prefix}.{suf}.us-east-1.redshift.amazonaws.com")

resolved = []
connected = []
auth_failed = []

for host in sorted(candidates):
    try:
        ip = socket.gethostbyname(host)
        resolved.append((host, ip))
        try:
            conn = psycopg2.connect(
                host=host, port=5440, dbname="dba_batch", user=USER,
                password=PASSWORD, sslmode="require", connect_timeout=6,
            )
            connected.append(host)
            conn.close()
        except psycopg2.OperationalError as e:
            msg = str(e)
            if "password authentication failed" in msg:
                auth_failed.append(host)
            elif "does not exist" not in msg and "translate" not in msg:
                print("CONN_ERR", host, msg[:120])
    except socket.gaierror:
        pass

print("RESOLVED_DNS:", len(resolved))
for h, ip in resolved:
    print(" ", h, "->", ip)
print("AUTH_OK:", connected)
print("AUTH_FAIL_HOST_OK:", auth_failed)
