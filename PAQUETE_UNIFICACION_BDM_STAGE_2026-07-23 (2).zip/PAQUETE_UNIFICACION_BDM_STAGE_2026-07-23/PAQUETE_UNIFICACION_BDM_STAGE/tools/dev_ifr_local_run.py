"""Run unification on productor DEV using local ifr_data (pre-datashare smoke)."""
from __future__ import annotations
import os, sys
from pathlib import Path
import psycopg2
from psycopg2.extras import RealDictCursor

ROOT = Path(__file__).resolve().parents[1]
HOST = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
PWD = os.environ.get("REDSHIFT_PASSWORD", "b27YWI2FL")

# Copy ifr views: replace db_ifr_shared.ifr_data with ifr_data for local test
ifr_views = (ROOT / "sql" / "dev_ifr_datasharing" / "00_vistas_insumo_bdm.sql").read_text(encoding="utf-8")
local_views = ifr_views.replace("db_ifr_shared.ifr_data", "ifr_data")

STEPS = [
    ("prereq", (ROOT / "sql" / "dev_ifr_datasharing" / "00_prerequisitos_dev.sql").read_text(encoding="utf-8")),
    ("ddl", (ROOT / "sql" / "dev_ifr_datasharing" / "01_ddl_unificacion_direccion.sql").read_text(encoding="utf-8")),
    ("vistas", local_views),
    ("sp1", (ROOT / "sql" / "qa_ifr_data" / "05_sp_regla1.sql").read_text(encoding="utf-8")),
    ("sp2", (ROOT / "sql" / "qa_ifr_data" / "06_sp_regla2.sql").read_text(encoding="utf-8")),
    ("sp3", (ROOT / "sql" / "qa_ifr_data" / "07_sp_regla3.sql").read_text(encoding="utf-8")),
    ("exec", "TRUNCATE TABLE bdm_datos.unificacion_direccion;\nCALL bdm_datos.sp_unificacion_regla1();\nCALL bdm_datos.sp_unificacion_regla2();\nCALL bdm_datos.sp_unificacion_regla3();"),
]

def main():
    c = psycopg2.connect(host=HOST, port=5440, dbname="dba_batch", user="c32525e", password=PWD, sslmode="require")
    c.autocommit = True
    cur = c.cursor(cursor_factory=RealDictCursor)
    for name, sql in STEPS:
        print(f"[{name}] ...", end=" ", flush=True)
        try:
            cur.execute(sql)
            print("OK")
        except Exception as e:
            print("FAIL", str(e).split(chr(10))[0][:120])
            return 1
    cur.execute("SELECT unifica_atributos, COUNT(*) n FROM bdm_datos.unificacion_direccion GROUP BY 1 ORDER BY 1")
    print("Resultado:", cur.fetchall())
    cur.execute("SELECT COUNT(*) n FROM bdm_tempo.v_xpm_contacto_direccion")
    print("Vista contactos:", cur.fetchone())
    c.close()
    return 0

if __name__ == "__main__":
    sys.exit(main())
