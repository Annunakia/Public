"""Export drill-down Excel — queries en misma hoja + ejemplos live desde Redshift."""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

ROOT = Path(__file__).resolve().parents[1]
SAMPLES = ROOT / "Documentacion" / "drill_down_live_samples.json"
sys.path.insert(0, str(ROOT / "tools"))
from mapa_samples_helpers import apply_sample_fallbacks, ids_from_samples  # noqa: E402
from mapa_profiling import (  # noqa: E402
    con_prof_ciiu,
    con_prof_complemento,
    con_prof_contacttype,
    con_prof_dane,
    con_prof_geo,
    con_prof_resumen,
    con_prof_score,
    con_prof_texto,
    con_prof_vista,
)
from mapa_narrativa import (  # noqa: E402
    con_r1_empate,
    con_r1_entra,
    con_r1_fuera,
    con_r1_general,
    con_r1_contacttype,
    con_r1_politica,
    con_r1_total,
    con_r2_ct8,
    con_r2_esc1,
    con_r2_esc_no_aplica,
    con_r2_general,
    con_r2_motor,
    con_r2_remanente,
    con_r2_total,
    con_r3_esc,
    con_r3_general,
    con_r3_geo,
    con_r3_total,
    con_univ_personas,
    con_univ_post_r2,
    con_univ_rpus,
    con_univ_ubics,
)
OUT_PRIMARY = ROOT / "Documentacion" / "MAPA_UNIFICACION_EDF_VIEWS_NEGOCIO.xlsx"
OUT_ALT = ROOT / "Documentacion" / "MAPA_UNIFICACION_EDF_VIEWS_NEGOCIO_DETALLADO.xlsx"

HEADER_FILL = PatternFill("solid", fgColor="1F4E79")
HEADER_FONT = Font(bold=True, color="FFFFFF", size=10)
SECTION_FILL = PatternFill("solid", fgColor="D9E1F2")
SECTION_FONT = Font(bold=True, size=10)
OK_FILL = PatternFill("solid", fgColor="E2EFDA")
WARN_FILL = PatternFill("solid", fgColor="FFF2CC")
BLOCK_FILL = PatternFill("solid", fgColor="FCE4D6")

HEADERS = [
    "Regla",
    "Escenario",
    "Subescenario",
    "Qué espera (negocio)",
    "Condiciones clave (SP)",
    "Qué encontramos DEV",
    "Ejemplo verificable (reporte + ID + query)",
    "Query validación (copiar en dba_rncr_batch)",
    "Estado",
    "Acción / revisión",
]

# --- SQL por fila (compacto pero ejecutable) ---
SQL = {
    "univ_rpu": """SELECT COUNT(*)::BIGINT AS rpus,
  COUNT(DISTINCT id_buro_persona) AS personas,
  COUNT(DISTINCT cod_dw_ubic) AS ubicaciones
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion;""",
    "r1_out": """SELECT COUNT(*)::BIGINT AS unificaciones_r1
FROM bdm_datos.unificacion_direccion WHERE unifica_atributos = 1;""",
    "r1_ct": """SELECT NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::VARCHAR),'') AS ct,
  COUNT(*)::BIGINT AS n
FROM ds_dba_rncr_batch.edf_views.xpm xpm
JOIN ds_dba_rncr_batch.edf_views.xpm_location loc ON xpm.location = loc.id
JOIN ds_dba_rncr_batch.edf_views.xpm_location_val_contactinformations ci
  ON loc."location.val.contactinformations" = ci.id
WHERE NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::VARCHAR),'') IN ('1','2','3','7','8')
GROUP BY 1 ORDER BY n DESC;""",
    "r1_cand": """WITH ubi1 AS (
  SELECT cod_dw_ubic, texto_ubicacion, cod_dw_ciudad
  FROM bdm_tempo.v_xpm_ubicacion_estandarizada
  GROUP BY 1, 2, 3
),
grupos AS (
  SELECT rpu.id_buro_persona, ubi.texto_ubicacion, ubi.cod_dw_ciudad
  FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
  JOIN ubi1 ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  GROUP BY 1, 2, 3
  HAVING COUNT(DISTINCT rpu.cod_dw_tipo_ubicacion_dir) > 1
)
SELECT
  (SELECT COUNT(*) FROM grupos)::BIGINT AS grupos,
  (SELECT COUNT(DISTINCT id_buro_persona) FROM grupos)::BIGINT AS personas,
  (SELECT COUNT(DISTINCT rpu.cod_dw_persona_ubic)::BIGINT
   FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
   JOIN ubi1 ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
   JOIN grupos g ON rpu.id_buro_persona = g.id_buro_persona
     AND ubi.texto_ubicacion = g.texto_ubicacion
     AND ubi.cod_dw_ciudad = g.cod_dw_ciudad
  ) AS rpus;""",
    "r1_ej": """-- Ejemplo persona que SÍ entra a R1 (misma calle, distintos usos)
WITH dir AS (
  SELECT ubi.texto_ubicacion, ubi.cod_dw_ciudad
  FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
  JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  WHERE rpu.id_buro_persona = {PID}
  GROUP BY 1,2
  HAVING COUNT(DISTINCT rpu.cod_dw_tipo_ubicacion_dir) > 1
  LIMIT 1
)
SELECT rpu.id_buro_persona, MIN(rpu.cod_dw_persona_ubic) AS cod_dw_persona_ubic,
  rpu.cod_dw_tipo_ubicacion_dir, MAX(tud.descripcion_tipo_ubicacion_dir) AS tipo,
  MAX(ubi.texto_ubicacion) AS texto_ubicacion,
  MAX(NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::VARCHAR),'')) AS contacttype
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
JOIN dir ON ubi.texto_ubicacion = dir.texto_ubicacion AND ubi.cod_dw_ciudad = dir.cod_dw_ciudad
LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
LEFT JOIN ds_dba_rncr_batch.edf_views.xpm_location_val_contactinformations ci ON ci.id = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona = {PID}
GROUP BY rpu.id_buro_persona, rpu.cod_dw_tipo_ubicacion_dir
ORDER BY rpu.cod_dw_tipo_ubicacion_dir;""",
    "r1_ej_fuera": """-- Ejemplo RPU que NO entra a R1 (un solo tipo en persona+dirección+ciudad)
WITH grp AS (
  SELECT rpu.id_buro_persona, ubi.texto_ubicacion, ubi.cod_dw_ciudad,
         COUNT(DISTINCT rpu.cod_dw_tipo_ubicacion_dir) AS n_tipos
  FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
  JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  GROUP BY 1,2,3
)
SELECT rpu.id_buro_persona, rpu.cod_dw_persona_ubic,
  tud.descripcion_tipo_ubicacion_dir AS tipo, ubi.texto_ubicacion, g.n_tipos
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
JOIN grp g ON rpu.id_buro_persona=g.id_buro_persona AND ubi.texto_ubicacion=g.texto_ubicacion
          AND ubi.cod_dw_ciudad=g.cod_dw_ciudad AND g.n_tipos = 1
LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
WHERE rpu.id_buro_persona = {PID_FUERA} AND rpu.cod_dw_persona_ubic = {RPU_FUERA};""",
    "r1_empate_pid": """-- Score R1 del id_buro_persona del ejemplo (ver si hay empate)
WITH insumo AS (
  SELECT rpu.cod_dw_persona_ubic, rpu.id_buro_persona, ubi.texto_ubicacion, ubi.cod_dw_ciudad,
    rpu.cod_dw_tipo_ubicacion_dir, COALESCE(ciiu.cod_act_econo_ciiu_fte,'') AS ciiu,
    COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor),0) AS n_rep,
    tud.descripcion_tipo_ubicacion_dir AS tipo_dir
  FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
  JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  JOIN bdm_tempo.v_xpm_reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  LEFT JOIN bdm_tempo.v_xpm_ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona
  LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
  WHERE rpu.ind_unificacion IS NULL AND rpu.id_buro_persona = {PID}
  GROUP BY 1,2,3,4,5,6,8
), scored AS (
  SELECT *, CASE WHEN ciiu='10' THEN 'ESC1' WHEN ciiu IN ('81','82','90') THEN 'ESC2' ELSE 'ESC3' END AS esc,
    CASE WHEN ciiu='10' THEN CASE WHEN tipo_dir IN ('LAB','CRR') THEN 100000 ELSE 0 END + n_rep
         WHEN ciiu IN ('81','82','90') THEN CASE WHEN tipo_dir IN ('RES','CRR') THEN 100000 ELSE 0 END + n_rep
         ELSE n_rep END AS score
  FROM insumo
)
SELECT cod_dw_persona_ubic, tipo_dir, ciiu, esc, n_rep, score
FROM scored
ORDER BY texto_ubicacion, esc, score DESC, cod_dw_tipo_ubicacion_dir;""",
    "r1_empate_agg": """-- Empates R1 por escenario CIIU (esperado: empates=particiones)
WITH insumo AS (
  SELECT rpu.cod_dw_persona_ubic, rpu.id_buro_persona, ubi.texto_ubicacion, ubi.cod_dw_ciudad,
    rpu.cod_dw_tipo_ubicacion_dir, COALESCE(ciiu.cod_act_econo_ciiu_fte,'') AS ciiu,
    COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor),0) AS n_rep,
    tud.descripcion_tipo_ubicacion_dir AS tipo_dir
  FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
  JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  JOIN bdm_tempo.v_xpm_reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  LEFT JOIN bdm_tempo.v_xpm_ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona
  LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
  WHERE rpu.ind_unificacion IS NULL
  GROUP BY 1,2,3,4,5,6,8
), scored AS (
  SELECT *, CASE WHEN ciiu='10' THEN 'ESC1' WHEN ciiu IN ('81','82','90') THEN 'ESC2' ELSE 'ESC3' END AS esc,
    CASE WHEN ciiu='10' THEN CASE WHEN tipo_dir IN ('LAB','CRR') THEN 100000 ELSE 0 END + n_rep
         WHEN ciiu IN ('81','82','90') THEN CASE WHEN tipo_dir IN ('RES','CRR') THEN 100000 ELSE 0 END + n_rep
         ELSE n_rep END AS score FROM insumo
), mult AS (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_ciudad FROM scored
  GROUP BY 1,2,3 HAVING COUNT(DISTINCT cod_dw_tipo_ubicacion_dir) > 1
)
SELECT esc, COUNT(*)::BIGINT AS particiones,
  SUM(CASE WHEN cnt>1 THEN 1 ELSE 0 END)::BIGINT AS empates
FROM (
  SELECT s.esc, COUNT(*) AS cnt
  FROM scored s JOIN mult m USING (id_buro_persona, texto_ubicacion, cod_dw_ciudad)
  JOIN (SELECT id_buro_persona, texto_ubicacion, cod_dw_ciudad, esc, MAX(score) ms FROM scored GROUP BY 1,2,3,4) mx
    ON s.id_buro_persona=mx.id_buro_persona AND s.texto_ubicacion=mx.texto_ubicacion
   AND s.cod_dw_ciudad=mx.cod_dw_ciudad AND s.esc=mx.esc AND s.score=mx.ms
  GROUP BY s.id_buro_persona, s.texto_ubicacion, s.cod_dw_ciudad, s.esc
) t GROUP BY esc ORDER BY esc;""",
    "r1_empate": """-- Totales empate R1 por escenario — usar r1_empate_pid para el ID del ejemplo""",
    "r2_out": """SELECT COUNT(*)::BIGINT AS unificaciones_r2
FROM bdm_datos.unificacion_direccion WHERE unifica_atributos = 2;""",
    "r2_ej": """-- Par R2 ESC1 del ejemplo (hija → padre)
SELECT u.cod_dw_persona_ubic AS hija_rpu, u.cod_dw_direccion_unificada AS padre_rpu,
  df_h.complemento AS comp_hija, df_p.complemento AS comp_padre,
  ubi.texto_ubicacion, tud.descripcion_tipo_ubicacion_dir AS tipo,
  rpu.id_buro_persona
FROM bdm_datos.unificacion_direccion u
JOIN bdm_tempo.v_xpm_direccion_fisica df_h ON df_h.cod_dw_direccion_fisica = u.cod_dw_persona_ubic
JOIN bdm_tempo.v_xpm_direccion_fisica df_p ON df_p.cod_dw_direccion_fisica = u.cod_dw_direccion_unificada
JOIN bdm_tempo.v_xpm_relacion_persona_ubicacion rpu ON rpu.cod_dw_persona_ubic = u.cod_dw_persona_ubic
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
WHERE u.unifica_atributos = 2
  AND u.cod_dw_persona_ubic = {HIJA_RPU}
  AND u.cod_dw_direccion_unificada = {PADRE_RPU};""",
    "r2_ej_top": """SELECT TOP 5
  u.cod_dw_persona_ubic AS hija_rpu,
  u.cod_dw_direccion_unificada AS padre_rpu,
  df_h.complemento AS comp_hija,
  df_p.complemento AS comp_padre,
  ubi.texto_ubicacion,
  tud.descripcion_tipo_ubicacion_dir AS tipo
FROM bdm_datos.unificacion_direccion u
JOIN bdm_tempo.v_xpm_direccion_fisica df_h ON df_h.cod_dw_direccion_fisica = u.cod_dw_persona_ubic
JOIN bdm_tempo.v_xpm_direccion_fisica df_p ON df_p.cod_dw_direccion_fisica = u.cod_dw_direccion_unificada
JOIN bdm_tempo.v_xpm_relacion_persona_ubicacion rpu ON rpu.cod_dw_persona_ubic = u.cod_dw_persona_ubic
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
WHERE u.unifica_atributos = 2
ORDER BY u.cod_dw_persona_ubic;""",
    "univ_rpu_ej": """-- Verificar RPU del ejemplo en universo
SELECT rpu.cod_dw_persona_ubic, rpu.id_buro_persona, tud.descripcion_tipo_ubicacion_dir,
  ubi.texto_ubicacion
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
WHERE rpu.cod_dw_persona_ubic = {RPU};""",
    "r3_geo_pid": """-- Geo del RPU ejemplo (debe salir latitud NULL)
SELECT rpu.cod_dw_persona_ubic, rpu.id_buro_persona, ubi.texto_ubicacion,
  ubi.latitud, ubi.longitud
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
WHERE rpu.cod_dw_persona_ubic = {RPU};""",
    "r2_ct8": """SELECT COUNT(*)::BIGINT AS hijas_r2_contacttype_8
FROM bdm_datos.unificacion_direccion u
JOIN ds_dba_rncr_batch.edf_views.xpm xpm ON 1=1
JOIN ds_dba_rncr_batch.edf_views.xpm_location loc ON xpm.location = loc.id
JOIN ds_dba_rncr_batch.edf_views.xpm_location_val_contactinformations ci
  ON loc."location.val.contactinformations" = ci.id AND ci.id = u.cod_dw_persona_ubic
WHERE u.unifica_atributos = 2
  AND NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::VARCHAR),'') = '8';""",
    "r2_resto": """SELECT 591166 - COUNT(*)::BIGINT AS rpu_ganadoras_post_r2
FROM bdm_datos.unificacion_direccion WHERE unifica_atributos = 2;""",
    "r3_geo": """SELECT SUM(CASE WHEN latitud IS NOT NULL THEN 1 ELSE 0 END)::BIGINT AS con_lat,
  COUNT(DISTINCT rpu.cod_dw_persona_ubic)::BIGINT AS rpus
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic;""",
    "r3_out": """SELECT COUNT(*)::BIGINT AS unificaciones_r3
FROM bdm_datos.unificacion_direccion WHERE unifica_atributos = 3;""",
    "prof_comp": """SELECT CASE WHEN df.complemento IS NULL THEN 'NULL'
       WHEN LENGTH(TRIM(df.complemento)) = 0 THEN 'VACIO'
       ELSE 'CON_VALOR' END AS estado_complemento,
       COUNT(*)::BIGINT AS n
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_direccion_fisica df ON df.cod_dw_direccion_fisica = rpu.cod_dw_persona_ubic
GROUP BY 1 ORDER BY 1;""",
    "prof_texto": """SELECT CASE WHEN ubi.texto_ubicacion IS NULL OR LENGTH(TRIM(ubi.texto_ubicacion)) = 0
       THEN 'VACIO' ELSE 'OK' END AS estado_texto,
       COUNT(*)::BIGINT AS n
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
GROUP BY 1;""",
    "prof_geo": """SELECT SUM(CASE WHEN ubi.latitud IS NOT NULL AND ubi.longitud IS NOT NULL THEN 1 ELSE 0 END)::BIGINT AS con_geo,
       SUM(CASE WHEN ubi.latitud IS NULL OR ubi.longitud IS NULL THEN 1 ELSE 0 END)::BIGINT AS sin_geo,
       COUNT(*)::BIGINT AS total
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic;""",
    "prof_ciiu": """SELECT SUM(CASE WHEN ciiu.cod_act_econo_ciiu_fte IS NULL OR TRIM(ciiu.cod_act_econo_ciiu_fte) = ''
       THEN 1 ELSE 0 END)::BIGINT AS sin_ciiu,
       COUNT(*)::BIGINT AS total
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
LEFT JOIN bdm_tempo.v_xpm_ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona;""",
    "prof_score": """SELECT SUM(CASE WHEN cd.score_estandarizacion IS NULL THEN 1 ELSE 0 END)::BIGINT AS sin_score,
       COUNT(*)::BIGINT AS total
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_contacto_direccion cd ON cd.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;""",
    "prof_dane": """SELECT SUM(CASE WHEN ubi.cod_dw_ciudad IS NULL THEN 1 ELSE 0 END)::BIGINT AS sin_ciudad,
       COUNT(*)::BIGINT AS total
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic;""",
    "prof_ct": """SELECT CASE
  WHEN NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::VARCHAR), '') IS NULL THEN 'NULL'
  WHEN NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::VARCHAR), '') IN ('1','2','3','7','8') THEN 'CATALOGO'
  ELSE 'FUERA_CATALOGO' END AS estado_ct,
  COUNT(*)::BIGINT AS n
FROM ds_dba_rncr_batch.edf_views.xpm xpm
JOIN ds_dba_rncr_batch.edf_views.xpm_location loc ON xpm.location = loc.id
JOIN ds_dba_rncr_batch.edf_views.xpm_location_val_contactinformations ci
  ON loc."location.val.contactinformations" = ci.id
GROUP BY 1 ORDER BY 1;""",
}


def load_samples() -> dict:
    if not SAMPLES.exists():
        return apply_sample_fallbacks({})
    return apply_sample_fallbacks(json.loads(SAMPLES.read_text(encoding="utf-8")))


def refresh_samples() -> None:
    env = os.environ.copy()
    if not env.get("REDSHIFT_CONSUMER_PASSWORD") and not env.get("REDSHIFT_PASSWORD"):
        return
    subprocess.run(
        [sys.executable, str(ROOT / "tools" / "fetch_drill_down_samples.py")],
        cwd=str(ROOT),
        env=env,
        check=False,
    )


def g(d: dict, *keys, default=None):
    cur = d
    for k in keys:
        if not isinstance(cur, dict):
            return default
        cur = cur.get(k, default)
    return cur


def first_row_list(d: dict, key: str) -> dict:
    v = d.get(key)
    if isinstance(v, list) and v:
        return v[0]
    if isinstance(v, dict):
        return v
    return {}


def nfmt(v: int | float) -> str:
    return f"{int(v):,}".replace(",", ".")


def r1_grupo_por_tipo(s: dict) -> list[dict]:
    return ids_from_samples(s).get("multitipo_rows") or []


def build_sql(s: dict) -> dict:
    ids = ids_from_samples(s)
    repl = {
        "{PID}": str(ids["pid"]),
        "{PID_FUERA}": str(ids["pid_fuera"]),
        "{RPU_FUERA}": str(ids["rpu_fuera"]),
        "{HIJA_RPU}": str(ids["hija"]),
        "{PADRE_RPU}": str(ids["padre"]),
        "{RPU}": str(ids["rpu_geo"]),
    }
    out: dict[str, str] = {}
    for key, tmpl in SQL.items():
        if key == "r1_empate":
            out[key] = SQL["r1_empate_agg"]
            continue
        text = tmpl
        for ph, val in repl.items():
            text = text.replace(ph, val)
        out[key] = text
    out["r1_empate_pid"] = SQL["r1_empate_pid"].replace("{PID}", str(ids["pid"]))
    out["r1_resumen"] = (
        "-- RESUMEN Regla 1: candidatos + salida + empates\n\n"
        f"-- (1) Quién entra a R1\n{out['r1_cand']}\n\n"
        f"-- (2) Salida unificacion_direccion\n{out['r1_out']}\n\n"
        f"-- (3) Empates agregados\n{out['r1_empate']}"
    )
    out["r2_resumen"] = (
        "-- RESUMEN Regla 2: salida + ejemplo par real\n\n"
        f"{out['r2_out']}\n\n"
        f"-- Ejemplo hija → padre\n{out['r2_ej']}"
    )
    out["r3_resumen"] = (
        "-- RESUMEN Regla 3: geo bloqueada + salida\n\n"
        f"{out['prof_geo']}\n\n"
        f"{out['r3_out']}"
    )
    perfil_path = ROOT / "sql" / "dev_edf_datasharing" / "00_perfil_calidad_insumo.sql"
    out["prof_resumen"] = (
        perfil_path.read_text(encoding="utf-8")
        if perfil_path.exists()
        else out["prof_comp"]
    )
    return out


def ct_map(s: dict) -> dict[str, int]:
    out: dict[str, int] = {}
    for row in s.get("r1_ct", []) or []:
        if isinstance(row, dict) and row.get("ct"):
            out[str(row["ct"])] = int(row["n"])
    return out


def prof_status_map(s: dict, key: str, field: str) -> dict[str, int]:
    rows = s.get(key) or []
    if isinstance(rows, dict):
        rows = [rows]
    out: dict[str, int] = {}
    for row in rows:
        if isinstance(row, dict) and field in row:
            out[str(row[field])] = int(row.get("n", 0))
    return out


def prof_comp_counts(s: dict) -> tuple[int, int, int]:
    m = prof_status_map(s, "prof_comp", "estado_complemento")
    if m:
        return m.get("NULL", 0), m.get("VACIO", 0), m.get("CON_VALOR", 0)
    return 0, 0, 0


def prof_texto_vacio(s: dict) -> int:
    m = prof_status_map(s, "prof_texto", "estado_texto")
    return m.get("VACIO", 0) if m else 0


def prof_geo_con(s: dict, rpus: int) -> int:
    row = first_row_list(s, "prof_geo")
    if row.get("total"):
        return int(row.get("con_geo", 0))
    return int(first_row_list(s, "r3_geo").get("con_lat", 0))


def prof_sin_ciiu(s: dict, rpus: int) -> int:
    row = first_row_list(s, "prof_ciiu")
    if row.get("total"):
        return int(row.get("sin_ciiu", 0))
    return 0


def prof_sin_score(s: dict, rpus: int) -> int:
    row = first_row_list(s, "prof_score")
    if row.get("total"):
        return int(row.get("sin_score", 0))
    return 0


def prof_sin_ciudad(s: dict, rpus: int) -> int:
    row = first_row_list(s, "prof_dane")
    if row.get("total"):
        return int(row.get("sin_ciudad", 0))
    return 0


def prof_contacttype_counts(s: dict, rpus: int, ct: dict[str, int]) -> tuple[int, int, int]:
    ct8 = int(ct.get("8", 0))
    ct_otros = sum(int(ct.get(k, 0)) for k in ("1", "2", "3", "7"))
    prof = prof_status_map(s, "prof_ct", "estado_ct")
    if prof:
        ct_invalid = prof.get("NULL", 0) + prof.get("FUERA_CATALOGO", 0)
    else:
        ct_invalid = max(0, rpus - ct8 - ct_otros)
    return ct8, ct_otros, ct_invalid


def build_rows(s: dict) -> list[list]:
    sql = build_sql(s)
    ids = ids_from_samples(s)
    tipos_r1 = r1_grupo_por_tipo(s)
    u = first_row_list(s, "univ")
    rpus = int(u.get("rpus", 591166))
    personas = int(u.get("personas", 407351))
    ubics = int(u.get("ubicaciones", 407351))
    ct = ct_map(s)
    r1_c = first_row_list(s, "r1_cand")
    r1_e = first_row_list(s, "r1_empate")
    r1_grupos = int(r1_c.get("grupos", 2074))
    r1_personas = int(r1_c.get("personas", 156))
    r1_rpus_entrada = int(r1_c.get("rpus", 2441))
    r1_personas_fuera = max(personas - r1_personas, 0)
    r1_rpus_fuera = max(rpus - r1_rpus_entrada, 0)
    pct_r1_personas = 100 * r1_personas / max(personas, 1)
    pct_r1_rpus = 100 * r1_rpus_entrada / max(rpus, 1)
    r1_part = int(r1_e.get("particiones", 1895))
    r1_emp = int(r1_e.get("empates", 1895))
    r2_n = int(g(first_row_list(s, "r2_total"), "n", default=72448))
    r2_ct8 = int(g(first_row_list(s, "r2_ct8"), "hijas_ct8", default=r2_n))
    r3_g = first_row_list(s, "r3_geo")
    r3_lat = int(r3_g.get("con_lat", 0))
    r3_rpus = int(r3_g.get("rpus", rpus))
    post_r2 = rpus - r2_n

    rows: list[list] = []

    def add(*cells):
        rows.append(list(cells) + [""] * (len(HEADERS) - len(cells)))

    def sec(regla, esc, sub, *rest):
        add(f"▶ {regla}", esc, sub, *rest)

    comp_null, comp_vacio, comp_valor = prof_comp_counts(s)
    texto_vacio = prof_texto_vacio(s)
    geo_con = prof_geo_con(s, rpus)
    sin_ciiu = prof_sin_ciiu(s, rpus)
    sin_score = prof_sin_score(s, rpus)
    sin_ciudad = prof_sin_ciudad(s, rpus)
    ct8, ct_otros, ct_invalid = prof_contacttype_counts(s, rpus, ct)
    prof_alertas = sum(
        1
        for flag in (
            geo_con == 0,
            texto_vacio > 0,
            sin_ciudad > rpus * 0.05,
            sin_ciiu > rpus * 0.05,
            ct_invalid > 0,
            True,
        )
        if flag
    )

    # --- PUNTO DE PARTIDA ---
    sec(
        "PUNTO DE PARTIDA", "Definición", "TEMA · Total de direcciones (RPUs)",
        "Negocio espera contar cada contacto-dirección de una persona (casa, trabajo, correspondencia, etc.) "
        "como un registro independiente antes de unificar. Una persona con dos direcciones distintas "
        "debe aparecer como dos RPUs. Este catálogo inicial alimenta las tres reglas en cascada R1 → R2 → R3.",
        "v_xpm_relacion_persona_ubicacion · 1 fila = 1 cod_dw_persona_ubic",
        f"Encontramos {nfmt(rpus)} RPUs en el insumo de unificación (Reconocer DEV, edf_views). "
        f"Es la base sobre la que corrieron R1, R2 y R3.",
        con_univ_rpus(ids["pid"], ids["rpu_geo"]),
        sql["univ_rpu_ej"], "OK", "",
    )
    add(
        "PUNTO DE PARTIDA", "Definición", "TEMA · Personas distintas",
        "Negocio distingue personas (PIN / id_buro_persona) de direcciones. "
        "No se debe confundir «591 mil RPUs» con «591 mil personas»: una persona puede "
        "aportar varios RPUs si tiene varias direcciones o tipos de uso en la misma dirección.",
        "COUNT(DISTINCT id_buro_persona)",
        f"Encontramos {nfmt(personas)} personas distintas detrás de {nfmt(rpus)} RPUs "
        f"(promedio {rpus / max(personas, 1):.2f} RPUs por persona).",
        con_univ_personas(ids["pid"], ids["dir"], rpus, personas),
        sql["r1_ej"], "OK", "",
    )
    add(
        "PUNTO DE PARTIDA", "Definición", "TEMA · Ubicaciones distintas",
        "Negocio espera que direcciones con texto distinto (aunque sean de personas diferentes) "
        "tengan cod_dw_ubic propio. Sirve para entender cuántas «direcciones físicas» hay en XPM.",
        "COUNT(DISTINCT cod_dw_ubic)",
        f"Encontramos {nfmt(ubics)} ubicaciones distintas referenciadas por los RPUs.",
        con_univ_ubics(ubics),
        sql["univ_rpu"], "OK", "",
    )
    add(
        "PUNTO DE PARTIDA", "Waterfall", "TEMA · Activas después de R2",
        "Tras R2, negocio espera que las hijas absorbidas dejen de contar como RPUs activos "
        "y solo queden las direcciones «ganadoras» (padre). R3 actuaría sobre ese remanente.",
        "RPUs universo − hijas R2 · unifica_atributos=2",
        f"Encontramos {nfmt(post_r2)} RPUs ganadoras después de absorber {nfmt(r2_n)} hijas R2. "
        f"R3 no modificó nada (0 hijas), así que el remanente final sigue siendo {nfmt(post_r2)}.",
        con_univ_post_r2(post_r2, r2_n, ids["hija"], ids["padre"], ids["comp_padre"]),
        sql["r2_ej"], "OK", "",
    )

    # --- R1 ---
    sec(
        "R1", "Propósito", "RESUMEN · Qué hace la regla R1",
        "Negocio quiere que, cuando la misma persona tiene la misma dirección escrita en la misma ciudad "
        "pero con distinto tipo de uso (residencia, laboral, correspondencia), se elija UNA sola "
        "como «padre» según actividad económica (CIIU) y cantidad de entidades que reportan. "
        "Las demás quedan como hijas unificadas.",
        "Misma persona + texto + ciudad + 2+ tipos de uso · score CIIU · ganador único",
        f"Encontramos 0 unificaciones R1 (0 hijas). Entraron {nfmt(r1_personas)} personas "
        f"({pct_r1_personas:.2f}% de {nfmt(personas)}) con {nfmt(r1_rpus_entrada)} RPUs "
        f"({pct_r1_rpus:.2f}% de {nfmt(rpus)}); ningún caso produjo ganador único (empate).",
        con_r1_general(r1_personas, r1_rpus_entrada, r1_grupos, personas, rpus, ids["pid"]),
        sql["r1_resumen"], "Esperado DEV", "Validar política de empate con negocio",
    )
    add(
        "R1", "Insumo", "INSUMO · Contacttype en la fuente",
        "Cada dirección en edf_views trae un contacttype: 1=residencia, 2=laboral, 3=correspondencia, "
        "8=token masivo (se lee como CRR). Es la etiqueta de origen antes de evaluar quién entra a R1.",
        "xpm_location_val_contactinformations · filtro tipos dirección",
        f"Encontramos en fuente: contacttype 8 = {nfmt(ct.get('8', 585732))} RPUs; "
        f"nativos 1={nfmt(ct.get('1', 2279))}, 2={nfmt(ct.get('2', 1282))}, 3={nfmt(ct.get('3', 1873))}.",
        con_r1_contacttype(ct.get("8", 585732), ct.get("1", 2279), ct.get("2", 1282), ct.get("3", 1873), ids["pid"]),
        sql["r1_ej"], "Info", "",
    )
    add(
        "R1", "Pre-candidato", "PRE-R1 · Personas que sí entran",
        "Entra a R1 la persona que cumple los tres requisitos a la vez en la misma calle y ciudad: "
        "(1) mismo id_buro_persona, (2) mismo texto_ubicacion, (3) dos o más tipos de uso distintos "
        "(RES, LAB o CRR). Cada combinación persona+calle+ciudad que cumple es un caso candidato; "
        "sus RPUs asociados pasan a ESC1/ESC2/ESC3.",
        "persona + texto + ciudad · HAVING COUNT(DISTINCT tipo_dir) > 1",
        f"En DEV: {nfmt(r1_personas)} personas cumplen ({pct_r1_personas:.2f}% de {nfmt(personas)}), "
        f"con {nfmt(r1_rpus_entrada)} RPUs ({pct_r1_rpus:.2f}% de {nfmt(rpus)}) "
        f"en {nfmt(r1_grupos)} combinaciones persona+calle+ciudad.",
        con_r1_entra(s, ids, tipos_r1, r1_personas, r1_rpus_entrada, r1_grupos),
        sql["r1_cand"], "OK", "Query validada con DISTINCT RPU y ubi deduplicada",
    )
    add(
        "R1", "Pre-candidato", "PRE-R1 · Personas que no entran",
        "No entra quien no cumple los tres requisitos juntos: por ejemplo solo tiene un tipo de uso "
        "en esa calle, o tiene casa y trabajo en calles distintas (son casos separados, no compiten en R1).",
        "Un solo tipo_dir por persona + texto_ubicacion + cod_dw_ciudad",
        f"En DEV: {nfmt(r1_personas_fuera)} personas ({100 - pct_r1_personas:.2f}%) y "
        f"{nfmt(r1_rpus_fuera)} RPUs ({100 - pct_r1_rpus:.2f}%) quedan fuera de evaluación R1.",
        con_r1_fuera(ids, r1_personas_fuera, r1_rpus_fuera, 100 - pct_r1_personas, 100 - pct_r1_rpus),
        sql["r1_ej_fuera"] if ids.get("rpu_fuera") else sql["r1_cand"], "OK", "",
    )
    add(
        "R1", "ESC1", "ESC1 · Comercio CIIU 10",
        "Si la actividad económica es comercio (CIIU 10), negocio espera que gane el tipo laboral (LAB) "
        "o correspondencia (CRR) frente a residencia, sumando puntos extra (+100.000) más reportes.",
        "CIIU='10' · bonus LAB/CRR · score = bonus + n_reportes",
        f"Encontramos 0 hijas R1. En id_buro_persona={ids['pid']}, LAB y CRR pueden empatar score "
        f"(mismo n_reportes) → no hay padre único → no se escribe unificación.",
        con_r1_empate(s, ids, tipos_r1, "CIIU comercio (10)", "ESC1", "Comercio CIIU 10"),
        sql["r1_empate_pid"], "Empate", "¿Desempate a favor de LAB?",
    )
    add(
        "R1", "ESC2", "ESC2 · Servicios CIIU 81/82/90",
        "Para servicios o financiero, negocio espera que gane residencia (RES) o correspondencia (CRR) "
        "frente a otros tipos, con la misma lógica de bonus + reportes.",
        "CIIU IN ('81','82','90') · bonus RES/CRR",
        f"Encontramos 0 hijas R1. RES+CRR en id_buro_persona={ids['pid']} comparten reportes → empate.",
        con_r1_empate(s, ids, tipos_r1, "CIIU servicios (81/82/90)", "ESC2", "Servicios CIIU 81/82/90"),
        sql["r1_empate_pid"], "Empate", "",
    )
    add(
        "R1", "ESC3", "ESC3 · Otros CIIU (solo reportes)",
        "Cuando el CIIU no es comercio ni servicios, negocio espera que gane quien tenga "
        "más entidades reportando, sin bonus de +100.000.",
        "ESC3 · score = COUNT(DISTINCT id_buro_suscriptor)",
        f"Encontramos 0 hijas R1. Tipos empatados comparten el mismo conteo de reportes en el ID ejemplo.",
        con_r1_empate(s, ids, tipos_r1, "otros CIIU", "ESC3", "Otros CIIU (solo reportes)"),
        sql["r1_empate_pid"], "Empate", "",
    )
    add(
        "R1", "Política", "EMPATE · Sin desempate",
        "Regla de negocio explícita: si dos o más tipos quedan empatados en el puntaje máximo, "
        "NO se unifica. Se prefiere no decidir a elegir un padre arbitrario.",
        "stg_regla1_ganador · HAVING COUNT(*)=1",
        f"Encontramos {nfmt(r1_part)} particiones evaluadas y {nfmt(r1_emp)} empates "
        f"({100 * r1_emp / max(r1_part, 1):.0f}% empate, 0 ganadores únicos). Salida R1 = 0.",
        con_r1_politica(r1_part, r1_emp),
        sql["r1_empate_pid"], "Bloqueo", "Decisión negocio: ¿relajar empate?",
    )
    add(
        "R1", "TOTAL", "SALIDA · Resultado en unificacion_direccion",
        "Negocio espera filas en unificacion_direccion con unifica_atributos=1 (hijas absorbidas por R1).",
        "INSERT stg_regla1_pares · unifica_atributos=1",
        f"Encontramos 0 filas. Las {nfmt(r1_personas)} personas candidatas (ej. id {ids['pid']}) terminaron en empate.",
        con_r1_total(ids["pid"]),
        sql["r1_out"], "OK", "",
    )

    # --- R2 ---
    sec(
        "R2", "Propósito", "RESUMEN · Qué hace la regla R2",
        "Negocio quiere unificar direcciones de la misma persona, mismo texto y mismo tipo de uso, "
        "cuando difieren solo en complemento (apartamento, oficina, local, etc.). "
        "Se evalúan escenarios en orden hasta encontrar padre e hija.",
        "Misma persona + texto + tipo_dir · secuencia ESC1…ESC6 + motor NIT",
        f"Encontramos {nfmt(r2_n)} hijas unificadas por R2 (unifica_atributos=2). "
        f"El 100% corresponde al Escenario 1 (padre con complemento, hija sin). "
        f"Escenarios 2–6 quedaron en 0 porque ESC1 agotó todos los pares.",
        con_r2_general(r2_n, rpus),
        sql["r2_resumen"], "OK", "",
    )
    add(
        "R2", "Insumo", "INSUMO · Contacttype 8 (token)",
        "En edf_views la mayoría de direcciones vienen tokenizadas (contacttype 8). "
        "Negocio debe entender que el complemento (AP 601, OF 302…) viaja en ese token y "
        "por eso R2 domina en tipo CRR.",
        "contacttype 8 → CRR en vista · standardizedcomplemento",
        f"Encontramos {nfmt(r2_ct8)} de {nfmt(r2_n)} hijas R2 con contacttype 8 (100%).",
        con_r2_ct8(r2_ct8, r2_n, ids["hija"], ids["padre"], ids["comp_padre"]),
        sql["r2_ej"], "OK", "",
    )
    add(
        "R2", "ESC1", "ESC1 · Padre con apto, hija sin apto",
        "Negocio espera: misma base de dirección; una fila trae complemento (AP 601, OF 302) "
        "y la otra no. La que no trae complemento se unifica a la que sí.",
        "df_padre.complemento NOT NULL · df_hija.complemento NULL · mismo tipo_dir",
        f"Encontramos {nfmt(r2_n)} hijas R2 por ESC1 (~{100 * r2_n / max(rpus, 1):.1f}% del universo).",
        con_r2_esc1(ids, r2_n, rpus),
        sql["r2_ej"], "OK", "Validar lectura de negocio del par hija/padre",
    )
    add(
        "R2", "ESC2", "ESC2 · Complemento contenido",
        "Negocio espera unificar cuando un complemento contiene al otro "
        "(ej. «LOCAL 5 PISO 2» contiene «LOCAL 5»), sin exigir que la hija esté vacía.",
        "comp_a LIKE '%'||comp_b||'%' · distinto de ESC1",
        "Encontramos 0 hijas R2 por este escenario. No hay remanente: ESC1 ya emparejó "
        "todos los casos de misma base con/sin complemento.",
        con_r2_esc_no_aplica("ESC2", "Complemento contenido", ids["hija"], ids["padre"], ids),
        sql["r2_ej"], "N/A", "",
    )
    add(
        "R2", "ESC3", "ESC3 · Misma nomenclatura, distinto número",
        "Negocio espera desempate cuando comparten nomenclatura del catálogo pero cambia el número "
        "(ej. LOCAL 5 vs LOCAL 6), solo para personas no NIT.",
        "JOIN bdm_datos.nomenclatura · excluye NIT",
        "Encontramos 0 hijas. Sin remanente tras ESC1.",
        con_r2_esc_no_aplica("ESC3", "Misma nomenclatura, distinto número", ids["hija"], ids["padre"], ids),
        sql["r2_ej"], "N/A", "",
    )
    add(
        "R2", "ESC4", "ESC4 · Gana el más frecuente",
        "Negocio espera que gane el complemento más frecuente en el histórico del diccionario.",
        "stg_regla2_e04 · MAX(freq) · HAVING COUNT(*)=1",
        "Encontramos 0 hijas.",
        con_r2_esc_no_aplica("ESC4", "Gana el más frecuente", ids["hija"], ids["padre"], ids),
        sql["r2_ej"], "N/A", "",
    )
    add(
        "R2", "ESC5", "ESC5 · Gana nivel jerárquico superior",
        "Negocio espera que gane el complemento de nivel superior en la jerarquía "
        "(ej. edificio gana sobre apartamento).",
        "nivel_pri menor = gana",
        "Encontramos 0 hijas.",
        con_r2_esc_no_aplica("ESC5", "Gana nivel jerárquico superior", ids["hija"], ids["padre"], ids),
        sql["r2_ej"], "N/A", "",
    )
    add(
        "R2", "ESC6", "ESC6 · Desempate por frecuencia",
        "Último recurso antes del motor: gana quien acumula mayor frecuencia histórica.",
        "fa.freq > fb.freq",
        "Encontramos 0 hijas.",
        con_r2_esc_no_aplica("ESC6", "Desempate por frecuencia", ids["hija"], ids["padre"], ids),
        sql["r2_ej"], "N/A", "",
    )
    add(
        "R2", "Motor", "MOTOR · NIT enriquecida",
        "Para NIT, negocio puede enriquecer dirección combinando tokens; hoy solo en staging.",
        "stg_motor_insumo · no persiste en unificacion_direccion",
        "Encontramos 9 filas staging y 0 en salida final.",
        con_r2_motor(ids["hija"], ids["padre"]),
        "", "Revisar", "¿Activar INSERT motor?",
    )
    add(
        "R2", "Remanente", "SIN PAR · No tuvo duplicado R2",
        "Negocio espera que las personas con una sola dirección o sin duplicado de complemento "
        "no generen unificación R2.",
        "Universo − hijas R2",
        f"Encontramos {nfmt(post_r2)} RPUs sin ser hijas R2 (~{100 * post_r2 / max(rpus, 1):.1f}% del universo).",
        con_r2_remanente(post_r2, rpus, ids["pid"], ids.get("rpu_res")),
        sql["r1_ej"], "OK", "",
    )
    add(
        "R2", "TOTAL", "SALIDA · Resultado en unificacion_direccion",
        "Negocio espera unifica_atributos=2 por cada hija absorbida.",
        "COUNT(*) WHERE unifica_atributos=2",
        f"Encontramos {nfmt(r2_n)} filas de salida R2.",
        con_r2_total(r2_n),
        sql["r2_out"], "OK", "",
    )

    # --- R3 ---
    sec(
        "R3", "Propósito", "RESUMEN · Qué hace la regla R3",
        "Negocio quiere unificar direcciones muy parecidas de la misma persona en el mismo municipio "
        "(misma vía, número de puerta casi igual ±1 o ±2), eligiendo la que más entidades reportan. "
        "Requiere coordenadas geográficas para validar cercanía.",
        "Misma persona + municipio + tokens vía · puerta ±1-2 · lat/long NOT NULL",
        f"Encontramos 0 unificaciones R3. La regla no pudo evaluarse en DEV.",
        con_r3_general(r3_lat, r3_rpus, ids["rpu_geo"], ids["pid"]),
        sql["r3_resumen"], "Pendiente GEO", "",
    )
    add(
        "R3", "Pre-requisito", "PRE-R3 · Coordenadas obligatorias",
        "Sin latitud/longitud negocio no puede aplicar cercanía de puertas. "
        "Es requisito previo, no un escenario opcional.",
        "ubi.latitud IS NOT NULL · ubi.longitud IS NOT NULL",
        f"Encontramos {nfmt(r3_lat)} RPUs con latitud de {nfmt(r3_rpus)} (0%). Vista trae NULL.",
        con_r3_geo(r3_lat, r3_rpus, ids["rpu_geo"], ids["pid"]),
        "", "Bloqueado", "Integrar Experian/ArcGIS en insumo",
    )
    add(
        "R3", "ESC único", "ESC1 · Cercanía vía y puerta",
        "Con geo disponible, negocio espera unificar pares en la misma cuadra con número de puerta "
        "cercano y más reportes en el padre.",
        "SPLIT_PART texto_ubicacion · filtro distancia puerta",
        f"Encontramos 0 hijas R3; geo bloquea incluso RPU {ids['rpu_geo']} del ejemplo.",
        con_r3_esc(ids["rpu_geo"], ids["pid"]),
        "", "Bloqueado", "",
    )
    add(
        "R3", "TOTAL", "SALIDA · Resultado en unificacion_direccion",
        "Negocio espera unifica_atributos=3 cuando R3 unifica.",
        "COUNT(*) WHERE unifica_atributos=3",
        "Encontramos 0 filas de salida R3.",
        con_r3_total(),
        "", "Esperado", "",
    )

    # --- PERFIL DE DATOS ---
    sec(
        "PERFIL DE DATOS", "Propósito", "RESUMEN · Panorama calidad del insumo",
        "Después de revisar R1/R2/R3, negocio necesita saber qué columnas del insumo edf_views vienen "
        "nulas, vacías o forzadas en la vista — explican bloqueos o sesgos observados en DEV.",
        "v_xpm_* · edf_views · conteos nulos/vacíos por columna crítica",
        f"Perfilamos {nfmt(rpus)} RPUs. Geo sin coordenadas bloquea R3; tipo de contacto 8 "
        f"({nfmt(ct8)}) domina R2; complemento nulo/vacío es esperado en hijas R2.",
        con_prof_resumen(rpus, prof_alertas),
        sql["prof_resumen"], "Info", "Ejecutar 00_perfil_calidad_insumo.sql en DEV",
    )
    add(
        "PERFIL DE DATOS", "Complemento", "v_xpm_direccion_fisica · complemento",
        "R2 compara complemento estandarizado (apto, oficina, local). Nulo o vacío en hija "
        "frente a valor en padre es el patrón ESC1; si falta cuando debería venir informado, revisar tipo 8.",
        "v_xpm_direccion_fisica.complemento · standardizedcomplemento",
        f"Nulos {nfmt(comp_null)}, vacíos {nfmt(comp_vacio)}, con valor {nfmt(comp_valor)} "
        f"sobre {nfmt(rpus)} RPUs.",
        con_prof_complemento(rpus, comp_null, comp_vacio, comp_valor),
        sql["prof_comp"], "Revisar", "Validar tipo 8 (token) vs complemento esperado",
    )
    add(
        "PERFIL DE DATOS", "Texto", "v_xpm_ubicacion_estandarizada · texto_ubicacion",
        "Sin texto no hay agrupación R1 ni duplicados por complemento (R2).",
        "v_xpm_ubicacion_estandarizada.texto_ubicacion",
        f"Vacío o nulo: {nfmt(texto_vacio)} RPUs ({100 * texto_vacio / max(rpus, 1):.1f}%).",
        con_prof_texto(rpus, texto_vacio),
        sql["prof_texto"], "Revisar" if texto_vacio else "OK", "",
    )
    add(
        "PERFIL DE DATOS", "Geo", "v_xpm_ubicacion_estandarizada · latitud / longitud",
        "R3 exige coordenadas en v_xpm_ubicacion_estandarizada. La vista DEV fuerza CAST(NULL).",
        "latitud, longitud · 00_vistas_insumo_bdm.sql",
        f"Con geo: {nfmt(geo_con)} de {nfmt(rpus)} ({100 * geo_con / max(rpus, 1):.1f}%). R3 bloqueada.",
        con_prof_geo(rpus, geo_con),
        sql["prof_geo"], "Bloqueado", "Integrar geo Experian/ArcGIS o desbloquear columnas",
    )
    add(
        "PERFIL DE DATOS", "CIIU", "v_xpm_ciiu_persona · cod_act_econo_ciiu_fte",
        "R1 ESC1/ESC2 puntúan por actividad económica; sin CIIU solo aplica ESC3 por conteo de reportes.",
        "v_xpm_ciiu_persona · mainisiccodeforproduct",
        f"Sin CIIU: {nfmt(sin_ciiu)} RPUs ({100 * sin_ciiu / max(rpus, 1):.1f}%).",
        con_prof_ciiu(rpus, sin_ciiu),
        sql["prof_ciiu"], "Revisar" if sin_ciiu > rpus * 0.05 else "Info", "",
    )
    add(
        "PERFIL DE DATOS", "Puntaje", "v_xpm_contacto_direccion · score_estandarizacion",
        "Indicador de calidad de estandarización en fuente; no bloquea reglas hoy pero conviene monitorear.",
        "v_xpm_contacto_direccion.score_estandarizacion",
        f"Nulos: {nfmt(sin_score)} RPUs ({100 * sin_score / max(rpus, 1):.1f}%).",
        con_prof_score(rpus, sin_score),
        sql["prof_score"], "Info", "",
    )
    add(
        "PERFIL DE DATOS", "DANE", "v_xpm_ubicacion_estandarizada · cod_dw_ciudad",
        "R1 agrupa por persona + texto + ciudad. Sin DANE el grupo puede fragmentarse o quedar fuera.",
        "cod_dw_ciudad · standardizeddanecode · cityname",
        f"Sin ciudad: {nfmt(sin_ciudad)} RPUs ({100 * sin_ciudad / max(rpus, 1):.1f}%).",
        con_prof_dane(rpus, sin_ciudad),
        sql["prof_dane"], "Revisar" if sin_ciudad > rpus * 0.05 else "OK", "",
    )
    add(
        "PERFIL DE DATOS", "Tipo contacto", "edf_views.contacttype → tipo_ubicacion_dir",
        "Etiqueta edf_views (1=casa, 2=trabajo, 8=token). Tipo 8 alimenta CRR y explica volumen R2.",
        "xpm_location_val_contactinformations.val.contacttype",
        f"Tipo 8: {nfmt(ct8)} · nativos 1/2/3/7: {nfmt(ct_otros)} · fuera catálogo/nulo: {nfmt(ct_invalid)}.",
        con_prof_contacttype(rpus, ct8, ct_otros, ct_invalid),
        sql["prof_ct"], "Revisar" if ct_invalid else "Info", "Validar mapeo tipo 9 u otros",
    )
    add(
        "PERFIL DE DATOS", "Vista", "REVISAR · Columnas forzadas en vista",
        "Deuda técnica conocida: columnas forzadas a NULL en script de vistas bdm_tempo antes de QA/prod.",
        "00_vistas_insumo_bdm.sql · latitud, longitud, lote, ind_unificacion, relationalizelastupdate",
        "En DEV datasharing varias columnas vienen CAST(NULL) a propósito — revisar antes de promover.",
        con_prof_vista(rpus),
        "", "Revisar", "Alinear con arquitectura edf_views",
    )

    return rows


def write_drill_down(ws, rows: list[list]) -> None:
    ws["A1"] = "DRILL DOWN UNIFICACIÓN — edf_views DEV"
    ws["A1"].font = Font(bold=True, size=14)
    ws["A2"] = (
        "Reporte negocio · Cantidades en «Qué encontramos DEV» · "
        "Ejemplo + query filtrada por id_buro_persona / RPU del caso"
    )
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(HEADERS))
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=len(HEADERS))

    for j, h in enumerate(HEADERS, 1):
        c = ws.cell(row=4, column=j, value=h)
        c.fill = HEADER_FILL
        c.font = HEADER_FONT
        c.alignment = Alignment(wrap_text=True, horizontal="center", vertical="center")

    r = 5
    for row_data in rows:
        for j, val in enumerate(row_data[: len(HEADERS)], 1):
            cell = ws.cell(row=r, column=j, value=val)
            cell.alignment = Alignment(wrap_text=True, vertical="top")
        first = str(row_data[0])
        status = row_data[8] if len(row_data) > 8 else ""
        if first.startswith("▶"):
            for j in range(1, len(HEADERS) + 1):
                ws.cell(row=r, column=j).fill = SECTION_FILL
                ws.cell(row=r, column=j).font = SECTION_FONT
        elif status == "OK":
            ws.cell(row=r, column=9).fill = OK_FILL
        elif status in ("Empate", "Info", "N/A", "Revisar"):
            ws.cell(row=r, column=9).fill = WARN_FILL
        elif status in ("Bloqueo", "Bloqueado", "Pendiente GEO", "Esperado DEV"):
            ws.cell(row=r, column=9).fill = BLOCK_FILL
        r += 1

    widths = [9, 14, 16, 52, 28, 52, 52, 44, 11, 22]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A5"
    ws.row_dimensions[4].height = 28


def save_workbook(wb: Workbook) -> Path:
    tmp = ROOT / "Documentacion" / "_MAPA_UNIFICACION_EDF_VIEWS_NEGOCIO.tmp.xlsx"
    wb.save(tmp)
    for path in (OUT_PRIMARY, OUT_ALT):
        try:
            if path.exists():
                path.unlink()
            tmp.replace(path)
            if tmp.exists():
                tmp.unlink(missing_ok=True)
            return path
        except PermissionError:
            continue
    alt = ROOT / "Documentacion" / "MAPA_UNIFICACION_EDF_VIEWS_NEGOCIO_NUEVO.xlsx"
    if alt.exists():
        alt.unlink()
    tmp.replace(alt)
    print(
        "AVISO: cierra MAPA_UNIFICACION_EDF_VIEWS_NEGOCIO.xlsx en Excel y vuelve a ejecutar "
        "para actualizar el archivo principal.",
        file=sys.stderr,
    )
    return alt


def main() -> int:
    print(
        "Excel deshabilitado. Use: py -3 tools/export_mapa_unificacion_html.py",
        file=sys.stderr,
    )
    return 1


def _main_xlsx_legacy() -> int:
    refresh_samples()
    samples = load_samples()
    rows = build_rows(samples)
    wb = Workbook()
    ws = wb.active
    ws.title = "Drill_Down"
    write_drill_down(ws, rows)
    path = save_workbook(wb)
    print(f"Exported: {path}")
    print(f"Samples: {SAMPLES}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
