import os, json, psycopg2
from psycopg2.extras import RealDictCursor

h = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
c = psycopg2.connect(host=h, port=5440, dbname="dba_batch", user="c32525e",
                     password=os.environ["REDSHIFT_PASSWORD"], sslmode="require")
v = c.cursor(cursor_factory=RealDictCursor)

v.execute("""
SELECT exp.caso, exp.persona, exp.descripcion, exp.exp_unif_r3,
       COALESCE(act.unif_r3, 0) AS unif_r3,
       act.id_hijo, act.id_padre,
       CASE
         WHEN COALESCE(act.unif_r3, 0) <> exp.exp_unif_r3 THEN 'FAILED'
         WHEN exp.exp_hijo IS NOT NULL
          AND (act.id_hijo <> exp.exp_hijo OR act.id_padre <> exp.exp_padre) THEN 'FAILED'
         ELSE 'PASSED'
       END AS estado
FROM (
  SELECT 'TC-R3-01' AS caso, 930001 AS persona, 'Exclusion Manzana/Rural' AS descripcion,
         0 AS exp_unif_r3, CAST(NULL AS BIGINT) AS exp_hijo, CAST(NULL AS BIGINT) AS exp_padre
  UNION ALL SELECT 'TC-R3-02', 930002, 'Geoloc parcial', 1, 930002002, 930002001
  UNION ALL SELECT 'TC-R3-03', 930003, 'Sin GPS - fecha', 1, 930003001, 930003002
  UNION ALL SELECT 'TC-R3-04', 930004, 'Diccionario via', 1, 930004001, 930004002
  UNION ALL SELECT 'TC-R3-05', 930005, 'Puerta delta=2', 1, 930005001, 930005002
  UNION ALL SELECT 'TC-R3-06', 930006, 'Puerta delta>2', 0, NULL, NULL
  UNION ALL SELECT 'TC-R3-07', 930007, 'Modificador BIS', 0, NULL, NULL
  UNION ALL SELECT 'TC-R3-08', 930008, 'Cuadrante N', 1, 930008001, 930008002
  UNION ALL SELECT 'TC-R3-09', 930009, 'Puerta delta=1', 0, NULL, NULL
  UNION ALL SELECT 'TC-R3-10', 930010, 'Empate diccionario', 0, NULL, NULL
) exp
LEFT JOIN (
  SELECT r.id_buro_persona, COUNT(*) AS unif_r3,
         MAX(u.cod_dw_persona_ubic) AS id_hijo,
         MAX(u.cod_dw_direccion_unificada) AS id_padre
  FROM bdm_stage.unificacion_direccion u
  JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
  WHERE u.unifica_atributos = 3 AND r.id_buro_persona BETWEEN 930001 AND 930010
  GROUP BY 1
) act ON act.id_buro_persona = exp.persona
ORDER BY exp.caso
""")
summary = [dict(r) for r in v.fetchall()]

v.execute("""
SELECT COUNT(*) AS trazas_cruzadas_r3
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r1 ON r1.cod_dw_persona_ubic = u.cod_dw_persona_ubic
JOIN bdm_stage.unificacion_direccion u2
  ON u2.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
 AND u2.cod_dw_direccion_unificada = u.cod_dw_persona_ubic
WHERE r1.id_buro_persona = 930010 AND u.unifica_atributos = 3 AND u2.unifica_atributos = 3
""")
cross = v.fetchone()["trazas_cruzadas_r3"]

passed = sum(1 for r in summary if r["estado"] == "PASSED")
print(json.dumps({"call": "bdm_stage.sp_unificacion_regla3()", "passed": passed, "total": len(summary),
                  "trazas_cruzadas_930010": cross, "detalle": summary}, indent=2, default=str))
c.close()
