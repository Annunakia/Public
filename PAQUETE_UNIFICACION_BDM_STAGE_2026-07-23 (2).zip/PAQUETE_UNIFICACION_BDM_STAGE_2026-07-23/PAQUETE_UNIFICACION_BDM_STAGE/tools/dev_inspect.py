import os, json, psycopg2
from psycopg2.extras import RealDictCursor
h = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
c = psycopg2.connect(host=h, port=5440, dbname="dba_batch", user="c32525e",
                     password=os.environ["REDSHIFT_PASSWORD"], sslmode="require")
cur = c.cursor(cursor_factory=RealDictCursor)
cur.execute("SELECT COUNT(*) AS cnt FROM bdm_stage.relacion_persona_ubicacion")
print("rpu", cur.fetchone())
cur.execute("SELECT unifica_atributos, COUNT(*) AS cnt FROM bdm_stage.unificacion_direccion GROUP BY 1 ORDER BY 1")
print("unif", cur.fetchall())
cur.execute("""
SELECT proname FROM pg_proc p JOIN pg_namespace n ON p.pronamespace=n.oid
WHERE n.nspname='bdm_stage' AND proname LIKE '%unific%'
""")
print("procs", cur.fetchall())
cur.execute("""
SELECT id_buro_persona FROM bdm_stage.relacion_persona_ubicacion
WHERE id_buro_persona BETWEEN 888001 AND 888004 GROUP BY 1 ORDER BY 1
""")
print("mocks", cur.fetchall())
