import os, psycopg2
from psycopg2.extras import RealDictCursor

c = psycopg2.connect(
    host="eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com",
    port=5440, dbname="dba_batch", user="c32525e",
    password=os.environ.get("REDSHIFT_PASSWORD", "b27YWI2FL"), sslmode="require",
)
c.autocommit = True
cur = c.cursor(cursor_factory=RealDictCursor)

cur.execute("""
    SELECT
      SUM(CASE WHEN NULLIF(TRIM(ci."location.val.contactinformations.val.standardizeddanecode"::varchar),'') IS NOT NULL THEN 1 ELSE 0 END) has_dane,
      SUM(CASE WHEN NULLIF(TRIM(ci."location.val.contactinformations.val.citycode"::varchar),'') IS NOT NULL THEN 1 ELSE 0 END) has_citycode,
      SUM(CASE WHEN NULLIF(TRIM(ci."location.val.contactinformations.val.cityname"::varchar),'') IS NOT NULL THEN 1 ELSE 0 END) has_cityname,
      COUNT(*) total
    FROM edf_views.xpm xpm
    JOIN edf_views.xpm_location loc ON xpm.location = loc.id
    JOIN edf_views.xpm_location_val_contactinformations ci
      ON loc."location.val.contactinformations" = ci.id
    WHERE NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::varchar),'') IN ('1','2','3','7')
""")
print("geo fields in subset:", cur.fetchone())

cur.execute("""
    SELECT ci."location.val.contactinformations.val.citycode" cc,
           ci."location.val.contactinformations.val.cityname" cn,
           ci."location.val.contactinformations.val.standardizedmunicipality" sm,
           COUNT(*) n
    FROM edf_views.xpm xpm
    JOIN edf_views.xpm_location loc ON xpm.location = loc.id
    JOIN edf_views.xpm_location_val_contactinformations ci
      ON loc."location.val.contactinformations" = ci.id
    WHERE NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::varchar),'') IN ('1','2','3','7')
    GROUP BY 1,2,3 ORDER BY n DESC LIMIT 8
""")
print("top city combos:", cur.fetchall())
c.close()
