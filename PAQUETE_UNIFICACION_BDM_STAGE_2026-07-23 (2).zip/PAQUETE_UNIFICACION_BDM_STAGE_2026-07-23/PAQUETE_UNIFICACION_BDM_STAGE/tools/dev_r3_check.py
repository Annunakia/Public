import os, json, psycopg2
from psycopg2.extras import RealDictCursor

h = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
c = psycopg2.connect(
    host=h, port=5440, dbname="dba_batch", user="c32525e",
    password=os.environ["REDSHIFT_PASSWORD"], sslmode="require",
)
cur = c.cursor(cursor_factory=RealDictCursor)

def check(case, desc, sql, expect):
    cur.execute(sql)
    val = cur.fetchone()["v"]
    status = "PASSED" if val == expect else "FAILED"
    return {"case": case, "desc": desc, "value": int(val), "expected": expect, "status": status}

checks = [
    check("TC-R3-01", "Manzana 930001 no unifica",
          """SELECT COUNT(*) AS v FROM bdm_stage.unificacion_direccion u
             JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic=u.cod_dw_persona_ubic
             WHERE r.id_buro_persona=930001 AND u.unifica_atributos=3""", 0),
    check("TC-R3-08", "Cuadrante 930008 unifica puerta ±2",
          """SELECT COUNT(*) AS v FROM bdm_stage.unificacion_direccion u
             JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic=u.cod_dw_persona_ubic
             WHERE r.id_buro_persona=930008 AND u.unifica_atributos=3""", 1),
    check("TC-R3-10", "Empate 930010 no unifica",
          """SELECT COUNT(*) AS v FROM bdm_stage.unificacion_direccion u
             JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic=u.cod_dw_persona_ubic
             WHERE r.id_buro_persona=930010 AND u.unifica_atributos=3""", 0),
    check("TC-R3-10-X", "Sin traza cruzada 930010",
          """SELECT COUNT(*) AS v FROM bdm_stage.unificacion_direccion u
             JOIN bdm_stage.relacion_persona_ubicacion r1 ON r1.cod_dw_persona_ubic=u.cod_dw_persona_ubic
             JOIN bdm_stage.unificacion_direccion u2
               ON u2.cod_dw_persona_ubic=u.cod_dw_direccion_unificada
              AND u2.cod_dw_direccion_unificada=u.cod_dw_persona_ubic
             WHERE r1.id_buro_persona=930010 AND u.unifica_atributos=3""", 0),
]

cur.execute(
    """
    SELECT r.id_buro_persona, r.cod_dw_persona_ubic, ubi.texto_ubicacion,
           COALESCE(r.ind_unificacion,0) AS ind,
           u.cod_dw_direccion_unificada AS padre
    FROM bdm_stage.relacion_persona_ubicacion r
    JOIN bdm_stage.ubicacion_estandarizada ubi ON ubi.cod_dw_ubic=r.cod_dw_ubic
    LEFT JOIN bdm_stage.unificacion_direccion u
      ON u.cod_dw_persona_ubic=r.cod_dw_persona_ubic AND u.unifica_atributos=3
    WHERE r.id_buro_persona IN (930001,930008,930010)
    ORDER BY 1,2
    """
)
detail = cur.fetchall()

report = {
    "checks": checks,
    "detail": [dict(r) for r in detail],
    "passed": sum(1 for x in checks if x["status"] == "PASSED"),
    "total": len(checks),
}
print(json.dumps(report, indent=2, default=str))
c.close()
