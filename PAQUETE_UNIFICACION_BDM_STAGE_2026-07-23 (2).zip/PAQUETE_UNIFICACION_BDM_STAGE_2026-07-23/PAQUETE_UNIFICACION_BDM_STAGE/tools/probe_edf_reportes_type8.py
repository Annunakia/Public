import os, psycopg2
from psycopg2.extras import RealDictCursor

c = psycopg2.connect(
    host="eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com",
    port=5440, dbname="dba_batch", user="c32525e",
    password=os.environ.get("REDSHIFT_PASSWORD", "b27YWI2FL"), sslmode="require",
)
c.autocommit = True
cur = c.cursor(cursor_factory=RealDictCursor)

for label, q in [
    ("type8 all", """
        SELECT COUNT(*) n FROM edf_views.xpm xpm
        JOIN edf_views.xpm_location loc ON xpm.location = loc.id
        JOIN edf_views.xpm_location_val_contactinformations ci
          ON loc."location.val.contactinformations" = ci.id
        WHERE NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::varchar),'') = '8'
    """),
    ("type8 + cp valid", """
        SELECT COUNT(*) n FROM edf_views.xpm xpm
        JOIN edf_views.xpm_location loc ON xpm.location = loc.id
        JOIN edf_views.xpm_location_val_contactinformations ci
          ON loc."location.val.contactinformations" = ci.id
        JOIN edf_views.xpm_counterparties cp ON xpm.counterparties = cp.id
        WHERE NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::varchar),'') = '8'
          AND NULLIF(TRIM(cp."counterparties.val.counterpartyidnumber"::varchar),'') ~ '^[0-9]+$'
          AND CAST(NULLIF(TRIM(cp."counterparties.val.counterpartyidnumber"::varchar),'') AS BIGINT) <= 2147483647
    """),
    ("view reportes", "SELECT COUNT(*) n FROM bdm_tempo.v_xpm_reporte_relacion_persona_ubica"),
    ("join contacto-reporte", """
        SELECT COUNT(*) n FROM bdm_tempo.v_xpm_contacto_direccion c
        JOIN bdm_tempo.v_xpm_reporte_relacion_persona_ubica r
          ON c.cod_dw_persona_ubic = r.cod_dw_persona_ubic
    """),
    ("type8 loc counterparty sample", """
        SELECT loc."location.val.counterpartyidnumber" AS v, COUNT(*) AS n
        FROM edf_views.xpm xpm
        JOIN edf_views.xpm_location loc ON xpm.location = loc.id
        JOIN edf_views.xpm_location_val_contactinformations ci
          ON loc."location.val.contactinformations" = ci.id
        WHERE NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::varchar), '') = '8'
        GROUP BY 1 ORDER BY n DESC LIMIT 5
    """),
]:
    cur.execute(q)
    print(label, cur.fetchone())
c.close()
