"""Tablas ejemplo + resultado DEV por escenario — lenguaje sencillo, datos reales."""
from __future__ import annotations

from mapa_lexico import (  # noqa: E402
    COL_ACTIVIDAD,
    COL_CALLE,
    COL_CUMPLE_R1,
    COL_DECISION,
    COL_DETALLE_HIJA,
    COL_DETALLE_PADRE,
    COL_ETIQUETA_ORIGEN,
    COL_FORMA_DESEMPATE,
    COL_GANADOR,
    COL_MISMA_CALLE,
    COL_MISMO_TEXTO,
    COL_MISMO_TIPO,
    COL_N_USOS,
    COL_PASA_REGLA,
    COL_PERSONA,
    COL_POR_QUE,
    COL_POR_QUE_NO,
    COL_PUNTAJE,
    COL_QUIEN_REPORTA,
    COL_REPORTE,
    COL_REPORTE_HIJA,
    COL_REPORTE_PADRE,
    COL_SALIDA,
    COL_SI_GANADOR,
    COL_SI_SOLO,
    COL_APORTA,
    COL_COMPARACION,
    COL_DECISION_JUNTOS,
    COL_FORMA_DESEMPATE,
    COL_SOLO_BASTA,
    COL_USO,
    INSUMO_FILAS,
    R1_INSUMO_USO_R1,
    R1_QUIEN_ENTRA,
    R1_QUIEN_NO_ENTRA,
    TIT_R1_ENTRA,
    TIT_R1_NO_ENTRA,
    TIT_R1_PASOS,
    TIT_R1_PUNTAJE,
    TIT_R2_PAR,
    filas_empate_pasos,
    narr_r1_empate,
    narr_r1_entra,
    narr_r1_no_entra,
    narr_r1_salida_cero,
    narr_r2_esc1,
    narr_r2_salida,
    narr_r3_bloqueo,
)
from mapa_samples_helpers import ids_from_samples, resolve_r1_multitipo, resolve_r1_scores  # noqa: E402
from mapa_volumenes_meta import busca as vol_busca


def _n(n: int | float | None) -> str:
    if n is None:
        return "—"
    return f"{int(n):,}".replace(",", ".")


def _comp_empty(c: object) -> bool:
    if c is None:
        return True
    s = str(c).strip()
    return s in ("", "(vacío)", "null", "None", "NULL")


def _ok(flag: bool) -> str:
    return "Sí ✓" if flag else "No ✗"


def _uso_legible(tipo: str) -> str:
    t = (tipo or "").upper()
    if t == "RES":
        return "casa"
    if t == "LAB":
        return "trabajo"
    if t == "CRR":
        return "correspondencia"
    return tipo or "—"


def _vol(vol: dict, regla: str, codigo: str) -> dict:
    m = vol.get("map") or {}
    if (regla, codigo) in m:
        return m[(regla, codigo)]
    for f in vol.get("filas") or []:
        if f.get("regla") == regla and f.get("codigo") == codigo:
            return f
    return {}


def _explicar_r1_fila(
    uso: str,
    rpu: str,
    calle: str,
    calle_ref: str,
    n_tipos: int,
    usos_en_grupo: list[str],
) -> tuple[str, str, str, str]:
    """Devuelve solo_basta, aporta, si_solo, decision_juntos."""
    misma = calle.strip() == calle_ref.strip()
    otros = [u for u in usos_en_grupo if u != uso]
    solo_basta = "No ✗"
    aporta = (
        f"Cuenta como uso «{uso}» (reporte {rpu}). "
        f"{'La calle coincide con las otras filas' if misma else 'Calle distinta — no suma al grupo'}."
    )
    if misma and n_tipos >= 2:
        aporta += f" En total hay {n_tipos} usos distintos aquí: {', '.join(usos_en_grupo)}."
    si_solo = (
        f"Quedaría solo 1 uso («{uso}») en esta calle → "
        f"no cumple la regla 1 (se piden 2 o más usos distintos). No entraría."
    )
    if misma and n_tipos >= 2:
        decision = (
            f"Sí entra a regla 1: misma calle con {n_tipos} usos ({', '.join(usos_en_grupo)}). "
            f"Este reporte participa en el desempate; no se evalúa aislado."
        )
    else:
        decision = "No entra — falta otro uso distinto en la misma calle."
    return solo_basta, aporta, si_solo, decision


def _explicar_r1_score_fila(
    uso: str,
    rpu: str,
    puntaje: str,
    es_empate: bool,
    es_ganador: bool,
    max_puntaje: str,
) -> tuple[str, str, str]:
    if es_empate:
        por_que_no = (
            f"Puntaje {puntaje} = máximo del grupo, pero otros usos empataron. "
            f"La regla exige un solo ganador; con empate no se elige nadie."
        )
        si_ganador = (
            f"Si forzáramos «{uso}» (reporte {rpu}) como ganador, "
            f"los reportes de los otros usos pasarían a ser «absorbidos» — "
            f"pero en DEV eso no se hace porque el empate es real."
        )
    elif es_ganador:
        por_que_no = "—"
        si_ganador = f"Ganador con puntaje {puntaje}; los demás quedarían bajo este reporte."
    else:
        por_que_no = f"Puntaje {puntaje} < máximo ({max_puntaje}). No gana frente a otros usos."
        si_ganador = f"Si solo existiera «{uso}», podría ser candidato; pero compite con {max_puntaje} de otro uso."
    comparacion = (
        f"Uso «{uso}» reporte {rpu}: puntaje {puntaje}. "
        + ("Empatado — no se elige." if es_empate else ("Gana ✓" if es_ganador else "Pierde frente al máximo."))
    )
    return por_que_no, si_ganador, comparacion


def _explicar_r2_fila(
    hija: str,
    padre: str,
    comp_h: str,
    comp_p: str,
    calle: str,
    uso: str,
    pasa: bool,
) -> tuple[str, str, str]:
    if pasa:
        por_que = (
            f"Hija {hija} no trae apto/oficina; padre {padre} sí trae «{comp_p}». "
            f"Misma calle «{calle[:30]}» y mismo uso «{uso}». "
            f"Por eso la hija se une al padre (no al revés)."
        )
        si_hija = (
            f"Si quedara solo la hija {hija}: dirección incompleta (sin «{comp_p}»). "
            f"No se elige la hija porque le falta el detalle."
        )
        si_padre = (
            f"Si quedara solo el padre {padre}: ya trae el detalle completo → "
            f"es la dirección que debe quedar."
        )
    else:
        por_que = "No aplica este par en el escenario."
        si_hija = si_padre = "—"
    return por_que, si_hija, si_padre


def _r2_ej_dedupe(samples: dict) -> list:
    seen: set[tuple] = set()
    out: list = []
    for r in samples.get("r2_ej") or []:
        key = (r.get("hija_rpu"), r.get("padre_rpu"))
        if key in seen:
            continue
        seen.add(key)
        out.append(r)
    return out[:3]


def _fmt_ciiu(ciiu: str) -> str:
    c = (ciiu or "").strip()
    if c in ("", "0000", "0"):
        return "Sin actividad registrada (CIIU vacío en DEV)"
    if c == "10":
        return "Comercio (CIIU 10) — activaría «comercio gana trabajo»"
    if c in ("81", "82", "90"):
        return f"Servicios (CIIU {c}) — activaría «servicios gana casa»"
    return f"CIIU {c} (no es comercio ni servicios)"


def _fmt_forma_esc(esc: str) -> str:
    if esc == "ESC1":
        return "Forma comercio: gana trabajo o correspondencia (+100.000 al puntaje)"
    if esc == "ESC2":
        return "Forma servicios: gana casa o correspondencia (+100.000 al puntaje)"
    return "Forma estándar (ESC3): gana quien más entidades reportan"


def _fmt_n_rep(n: int) -> str:
    return f"{n} entidad{'es' if n != 1 else ''} distinta{'s' if n != 1 else ''}"


def _fmt_puntaje(sc: int, esc: str, n_rep: int) -> str:
    if esc in ("ESC1", "ESC2") and sc > n_rep:
        return f"{sc} (= {n_rep} entidades + bonificación {sc - n_rep})"
    return f"{sc} (= {n_rep} entidades reportan este uso; sin bonificación)"


def _score_rows_for_table(samples: dict, ids: dict) -> list[dict]:
    mt = resolve_r1_multitipo(samples)
    pid = mt[0].get("id_buro_persona") if mt else ids["pid"]
    calle = (mt[0].get("texto_ubicacion") if mt else ids.get("dir")) or ""
    scores = resolve_r1_scores(samples)
    if scores:
        aligned = [
            s for s in scores
            if s.get("id_buro_persona") == pid
            and (not calle or (s.get("texto_ubicacion") or "") == calle)
        ]
        if aligned:
            return aligned
        by_pid = [s for s in scores if s.get("id_buro_persona") == pid]
        if by_pid:
            return by_pid
        return scores
    seen: set = set()
    out: list[dict] = []
    for r in mt:
        td = r.get("cod_dw_tipo_ubicacion_dir")
        if td in seen:
            continue
        seen.add(td)
        out.append({
            "id_buro_persona": r.get("id_buro_persona", pid),
            "rpu": r.get("cod_dw_persona_ubic"),
            "tipo_dir": r.get("tipo"),
            "texto_ubicacion": calle,
            "ciiu": "",
            "esc": "ESC3",
            "n_rep": 6,
            "score": 6,
        })
    return out


def _r2_criterio_table(rows: list) -> dict:
    body = []
    for r in rows:
        ch = r.get("comp_hija")
        cp = r.get("comp_padre") or ""
        calle = (r.get("dir") or "")[:40]
        uso = _uso_legible(r.get("tipo", "CRR"))
        pasa = _comp_empty(ch) and not _comp_empty(cp)
        por_que, si_hija, si_padre = _explicar_r2_fila(
            str(r.get("hija_rpu", "")),
            str(r.get("padre_rpu", "")),
            "sin detalle" if _comp_empty(ch) else str(ch),
            str(cp),
            calle,
            uso,
            pasa,
        )
        body.append([
            str(r.get("hija_rpu", "")),
            str(r.get("padre_rpu", "")),
            "sin detalle" if _comp_empty(ch) else str(ch),
            str(cp),
            calle,
            uso,
            _ok(pasa),
            por_que,
            si_hija,
            si_padre,
            "Se guarda: hija → padre" if pasa else "No aplica",
        ])
    return {
        "title": TIT_R2_PAR,
        "headers": [
            COL_REPORTE_HIJA,
            COL_REPORTE_PADRE,
            COL_DETALLE_HIJA,
            COL_DETALLE_PADRE,
            COL_CALLE,
            COL_USO,
            "¿Cumple regla 2?",
            COL_POR_QUE,
            "Si quedara solo la hija…",
            "Si quedara solo el padre…",
            COL_SALIDA,
        ],
        "rows": body or [["—"] * 11],
    }


def _r1_pre_dentro_table(samples: dict, ids: dict) -> dict:
    rows_mt = resolve_r1_multitipo(samples)
    tipos = {r.get("cod_dw_tipo_ubicacion_dir") for r in rows_mt}
    n_tipos = len(tipos)
    calle_ref = (rows_mt[0].get("texto_ubicacion") if rows_mt else ids["dir"]) or ""
    pid = rows_mt[0].get("id_buro_persona", ids["pid"]) if rows_mt else ids["pid"]
    usos_leg = [_uso_legible(r.get("tipo", "")) for r in rows_mt]
    body = []
    for r in rows_mt:
        calle = r.get("texto_ubicacion") or ""
        uso = _uso_legible(r.get("tipo", ""))
        rpu = str(r.get("cod_dw_persona_ubic", ""))
        solo, aporta, si_solo, dec_j = _explicar_r1_fila(
            uso, rpu, calle, calle_ref, n_tipos, usos_leg
        )
        body.append([
            str(r.get("id_buro_persona", pid)),
            rpu,
            uso,
            calle[:36],
            _ok(calle == calle_ref),
            str(n_tipos),
            solo,
            aporta,
            si_solo,
            dec_j,
        ])
    return {
        "title": TIT_R1_ENTRA + " — fila a fila: por qué entra y qué pasa si miramos uno solo",
        "headers": [
            COL_PERSONA,
            COL_REPORTE,
            COL_USO,
            COL_CALLE,
            COL_MISMA_CALLE,
            COL_N_USOS,
            COL_SOLO_BASTA,
            COL_APORTA,
            COL_SI_SOLO,
            COL_DECISION_JUNTOS,
        ],
        "rows": body or [[str(ids["pid"]), "—", "—", ids["dir"][:36], "—", "—", "—", "—", "—", "—"]],
    }


def _r1_score_table(samples: dict, ids: dict) -> dict:
    scores = _score_rows_for_table(samples, ids)
    pid = scores[0].get("id_buro_persona", ids["pid"]) if scores else ids["pid"]
    max_sc = max(int(r.get("score", 0) or 0) for r in scores)
    n_at_max = sum(1 for r in scores if int(r.get("score", 0) or 0) == max_sc)
    calle_ref = (scores[0].get("texto_ubicacion") if scores else ids.get("dir")) or ""
    body = []
    for r in scores:
        sc = int(r.get("score", 0) or 0)
        n_rep = int(r.get("n_rep", 0) or 0)
        esc = str(r.get("esc") or "ESC3")
        tie = sc == max_sc and n_at_max > 1
        uso = _uso_legible(r.get("tipo_dir", r.get("tipo", "")))
        rpu = str(r.get("rpu", r.get("cod_dw_persona_ubic", "")))
        calle = str(r.get("texto_ubicacion") or calle_ref)[:36]
        por_que, si_gan, comp = _explicar_r1_score_fila(
            uso, rpu, str(sc), tie, sc == max_sc and not tie, str(max_sc)
        )
        if tie:
            ganador = f"Empate ✗ — puntaje {sc} igual en los {n_at_max} usos"
        elif sc == max_sc:
            ganador = f"Ganaría ✓ — único puntaje máximo ({sc})"
        else:
            ganador = f"Pierde ✗ — {sc} < máximo {max_sc}"
        body.append([
            str(r.get("id_buro_persona", pid)),
            rpu,
            uso,
            calle,
            _fmt_ciiu(str(r.get("ciiu", ""))),
            _fmt_forma_esc(esc),
            _fmt_n_rep(n_rep),
            _fmt_puntaje(sc, esc, n_rep),
            ganador,
            por_que,
            si_gan,
            comp,
        ])
    tie_note = (
        f" — los {n_at_max} usos empataron en {max_sc}"
        if n_at_max > 1
        else ""
    )
    title = (
        f"{TIT_R1_PUNTAJE} — persona {pid}, calle «{calle_ref[:32]}»"
        f"{tie_note}"
    )
    return {
        "title": title,
        "headers": [
            COL_PERSONA,
            COL_REPORTE,
            COL_USO,
            COL_CALLE,
            COL_ACTIVIDAD,
            COL_FORMA_DESEMPATE,
            COL_QUIEN_REPORTA,
            COL_PUNTAJE,
            COL_GANADOR,
            COL_POR_QUE_NO,
            COL_SI_GANADOR,
            COL_COMPARACION,
        ],
        "rows": body,
    }


def _r1_empate_pasos_table(samples: dict, ids: dict) -> dict:
    scores = _score_rows_for_table(samples, ids)
    sc = int(scores[0].get("score", 6) or 6) if scores else 6
    n_rep = int(scores[0].get("n_rep", 6) or 6) if scores else 6
    return {
        "title": TIT_R1_PASOS,
        "headers": ["Paso", "Pregunta", "Qué pasa en el ejemplo real"],
        "rows": filas_empate_pasos(
            ids["pid"],
            ids["dir"],
            ids.get("rpu_res", "388798"),
            ids.get("rpu_lab", "388801"),
            ids.get("rpu_crr", ids.get("rpu_res", "388798")),
            n_rep=n_rep,
            score=sc,
        ),
    }


def _ids(samples: dict) -> dict:
    return ids_from_samples(samples)


def pack_for_row(regla: str, codigo: str, vol: dict, samples: dict) -> dict | None:
    """Devuelve ejemplo, dev_text, conclusion, busca."""
    ids = _ids(samples)
    f = _vol(vol, regla, codigo)
    b = vol_busca(regla, codigo) or f.get("busca", "")
    r2_rows = _r2_ej_dedupe(samples)

    # --- R1 ---
    if regla == "R1" and codigo == "INSUMO":
        ct = {r["ct"]: r["n"] for r in (samples.get("r1_ct") or [])}
        insumo_rows = []
        for fila in INSUMO_FILAS:
            ct_key = fila[0].split()[0]
            ct_num = int(ct_key) if ct_key.isdigit() else 8
            n = ct.get(str(ct_num), ct.get(ct_num, 0))
            insumo_rows.append([
                fila[0],
                fila[1],
                _n(n) + " reportes" if n else fila[2],
                fila[3],
            ])
        return {
            "busca": b,
            "ejemplo": {
                "title": "De dónde salen casa, trabajo y correspondencia",
                "headers": [
                    "Código en origen",
                    "Significado",
                    "Cuántos hay en DEV",
                    "Para qué regla sirve",
                ],
                "rows": insumo_rows,
            },
            "dev_text": (
                f"Antes de filtrar, en DEV hay {_n(f.get('rpus', ids['rpus']))} reportes "
                f"de {_n(f.get('personas', ids['personas']))} personas. "
                f"Cada fila trae la calle y una etiqueta (casa, trabajo, correspondencia o token)."
            ),
            "conclusion": (
                "La regla 1 no mira la etiqueta sola: "
                "busca personas con la misma calle y al menos dos usos distintos."
            ),
        }

    if regla == "R1" and codigo == "PRE-R1":
        pct = 100 * f.get("personas", 0) / max(ids["personas"], 1)
        return {
            "busca": b,
            "ejemplo": _r1_pre_dentro_table(samples, ids),
            "dev_text": (
                narr_r1_entra(
                    ids["pid"],
                    ids["dir"],
                    ids.get("rpu_res", "388798"),
                    ids.get("rpu_lab", "388801"),
                )
                + f" En total, {_n(f.get('personas'))} personas ({pct:.2f} % del universo) "
                f"entran con {_n(f.get('rpus'))} reportes "
                f"(promedio {f.get('rpuxp') or 0:.2f} reportes por persona)."
            ),
            "conclusion": (
                f"Quien cumple «misma calle + 2 usos o más» pasa al desempate por puntaje. "
                f"La persona {ids['pid']} es un caso real de DEV."
            ),
        }

    if regla == "R1" and codigo == "PRE-R1-FUERA":
        fu = (samples.get("r1_ej_fuera") or [{}])[0]
        n_t = int(fu.get("n_tipos", 1))
        fu_pid = fu.get("id_buro_persona", "")
        fu_calle = (fu.get("texto_ubicacion") or "")[:32]
        return {
            "busca": b,
            "ejemplo": {
                "title": TIT_R1_NO_ENTRA + " — por qué no entra aunque tenga dirección",
                "headers": [
                    COL_PERSONA,
                    COL_REPORTE,
                    COL_USO,
                    COL_CALLE,
                    COL_N_USOS,
                    COL_SOLO_BASTA,
                    COL_SI_SOLO,
                    COL_APORTA,
                    COL_DECISION_JUNTOS,
                ],
                "rows": [[
                    str(fu_pid),
                    str(fu.get("cod_dw_persona_ubic", "")),
                    _uso_legible(fu.get("tipo", "")),
                    fu_calle,
                    str(n_t),
                    "No ✗ — un solo uso",
                    (
                        f"Solo existe «{_uso_legible(fu.get('tipo', ''))}» en «{fu_calle}». "
                        f"No hay segundo uso (casa+trabajo, casa+correspondencia, etc.)."
                    ),
                    (
                        "Este reporte es la única fila para esa persona+calle. "
                        "No compite consigo mismo ni con otro uso."
                    ),
                    (
                        "No entra a regla 1: hace falta la misma calle con 2+ usos distintos. "
                        "Si mañana apareciera un reporte de trabajo en otra calle, "
                        "seguiría sin entrar (calles distintas no compiten)."
                    ),
                ]],
            },
            "dev_text": (
                narr_r1_no_entra(fu_pid, fu.get("texto_ubicacion") or "")
                + f" Así están {_n(f.get('personas'))} personas "
                f"({100 * f.get('personas', 0) / max(ids['personas'], 1):.2f} %) "
                f"y {_n(f.get('rpus'))} reportes fuera de la regla 1."
            ),
            "conclusion": R1_QUIEN_NO_ENTRA,
        }

    if regla == "R1" and codigo in ("ESC1", "ESC2"):
        if codigo == "ESC1":
            actividad = "comercio (código 10)"
            ganador = "trabajo o correspondencia"
        else:
            actividad = "servicios (códigos 81, 82 o 90)"
            ganador = "casa o correspondencia"
        return {
            "busca": b,
            "ejemplo": {
                "title": f"Forma de desempate «{codigo}» — por qué no hubo casos en DEV",
                "headers": [
                    COL_PERSONA,
                    "Actividad que activa esta forma",
                    "Quién debería ganar",
                    COL_PUNTAJE,
                    "En DEV",
                    "Motivo",
                ],
                "rows": [
                    [
                        str(ids["pid"]),
                        actividad,
                        ganador,
                        "puntaje alto fijo + reportes",
                        "0 personas",
                        "Nadie evaluado trae esa actividad",
                    ],
                    [
                        "—",
                        "—",
                        "—",
                        "—",
                        "0",
                        "Todas las personas evaluadas usaron la forma «gana quien más reporta»",
                    ],
                ],
            },
            "dev_text": (
                f"En DEV esta forma de desempate no aplicó a nadie: 0 personas. "
                f"La regla existe, pero los datos no trajeron esas actividades."
            ),
            "conclusion": (
                "Está programada, pero en esta corrida todas las personas evaluadas "
                "cayeron en «gana quien más entidades reportan» y luego empataron."
            ),
        }

    if regla == "R1" and codigo == "ESC3":
        r1_e = (samples.get("r1_empate") or [{}])[0]
        if isinstance(r1_e, list) and r1_e:
            r1_e = r1_e[0]
        return {
            "busca": b,
            "ejemplo": _r1_score_table(samples, ids),
            "ejemplo_pasos": _r1_empate_pasos_table(samples, ids),
            "dev_text": narr_r1_empate(
                ids["pid"],
                ids["dir"],
                _n(f.get("personas")),
                _n(f.get("rpus")),
            ),
            "conclusion": (
                f"Persona {ids['pid']}, calle «{ids['dir'][:30]}»: "
                f"casa, trabajo y correspondencia empataron → no hay dirección principal → "
                f"salida regla 1 = 0."
            ),
        }

    if regla == "R1" and codigo == "EMPATE":
        r1_e = (samples.get("r1_empate") or [{}])[0]
        return {
            "busca": b,
            "ejemplo": _r1_score_table(samples, ids),
            "ejemplo_pasos": _r1_empate_pasos_table(samples, ids),
            "dev_text": (
                f"En DEV, de {_n(r1_e.get('particiones'))} grupos evaluados, "
                f"los {_n(r1_e.get('empates'))} terminaron empatados (100 %). "
                f"Ejemplo: persona {ids['pid']} con casa, trabajo y correspondencia "
                f"en «{ids['dir'][:32]}» — los tres con el mismo puntaje."
            ),
            "conclusion": (
                "Empate = dos o más usos con el mismo puntaje máximo. "
                "Sin un solo ganador no se unifica. Política: mejor no unificar que elegir mal."
            ),
        }

    if regla == "R1" and codigo == "SALIDA":
        r1_out = int((samples.get("r1_total") or {}).get("n", 0))
        return {
            "busca": b,
            "ejemplo": {
                "title": "Qué se habría guardado si alguien hubiera ganado",
                "headers": [
                    COL_REPORTE_HIJA,
                    COL_REPORTE_PADRE,
                    "Regla",
                    "Filas en DEV",
                    "Por qué está en cero",
                ],
                "rows": [[
                    str(ids.get("rpu_lab") or "388801"),
                    str(ids.get("rpu_res") or "388798"),
                    "Regla 1",
                    str(r1_out),
                    "Empate en puntaje — no hubo dirección ganadora",
                ]],
            },
            "dev_text": (
                f"En DEV la salida de la regla 1 es {_n(r1_out)} filas. "
                f"Nadie ganó el desempate."
            ),
            "conclusion": narr_r1_salida_cero(),
        }

    # --- R2 ---
    if regla == "R2" and codigo == "INSUMO":
        r2_ct8 = int((samples.get("r2_ct8") or [{}])[0].get("hijas_ct8", 72448))
        r0 = r2_rows[0] if r2_rows else {}
        return {
            "busca": b,
            "ejemplo": {
                "title": "Entrada regla 2 — correspondencia con token (código 8)",
                "headers": [
                    COL_REPORTE_HIJA,
                    COL_REPORTE_PADRE,
                    "Etiqueta origen",
                    COL_USO,
                    COL_DETALLE_HIJA,
                    COL_DETALLE_PADRE,
                    "¿Listo para regla 2?",
                ],
                "rows": [
                    [
                        str(r0.get("hija_rpu", ids["hija"])),
                        str(r0.get("padre_rpu", ids["padre"])),
                        "8 (token)",
                        _uso_legible(r0.get("tipo", "CRR")),
                        "sin detalle",
                        r0.get("comp_padre", ids["comp_padre"]),
                        "Sí ✓",
                    ],
                ],
            },
            "dev_text": (
                f"La regla 2 trabaja sobre correspondencia token. "
                f"En DEV: {_n(f.get('personas'))} personas, {_n(f.get('rpus'))} reportes; "
                f"{_n(r2_ct8)} reportes hijos con etiqueta 8."
            ),
            "conclusion": (
                "Compara el detalle extra (apto, oficina…) en la misma calle y mismo uso. "
                "En DEV casi todo es «padre con detalle, hija sin detalle»."
            ),
        }

    if regla == "R2" and codigo == "ESC1":
        r2_n = int((samples.get("r2_total") or {}).get("n", 72448))
        r0 = r2_rows[0] if r2_rows else {}
        return {
            "busca": b,
            "ejemplo": _r2_criterio_table(r2_rows),
            "dev_text": (
                narr_r2_esc1(
                    ids["hija"],
                    ids["padre"],
                    ids["comp_padre"],
                    r0.get("dir") or ids.get("dir_r2", "CL 84 C # 9 - 51 AP 601"),
                )
                + f" En total: {_n(r2_n)} unificaciones "
                f"({100 * r2_n / max(ids['rpus'], 1):.1f} % de todos los reportes)."
            ),
            "conclusion": (
                f"Ejemplo real: reporte {ids['hija']} pasa a vivir bajo el reporte {ids['padre']} "
                f"porque solo el padre tiene «{ids['comp_padre']}»."
            ),
        }

    if regla == "R2" and codigo in ("ESC2", "ESC3", "ESC4", "ESC5", "ESC6"):
        ej = {
            "ESC2": ("501", "502", "LOCAL 5 PISO 2", "LOCAL 5", "uno contiene al otro", "No ✗", "No quedó nadie tras el caso principal"),
            "ESC3": ("601", "602", "AP 601", "AP 802", "misma raíz, número distinto", "No ✗", "Nomenclatura distinta"),
            "ESC4": ("701", "702", "OF 101", "OF 205", "el más frecuente gana", "No ✗", "Sin casos pendientes"),
            "ESC5": ("801", "802", "ED 1 TORRE B", "AP 601", "gana el nivel más alto", "No ✗", "Sin casos pendientes"),
            "ESC6": ("901", "902", "LOCAL 3", "LOCAL 4", "desempate por frecuencia", "No ✗", "Sin casos pendientes"),
        }
        row = ej.get(codigo, ("A", "B", "c1", "c2", "—", "No ✗", "—"))
        return {
            "busca": b,
            "ejemplo": {
                "title": f"Otra forma de unificar ({codigo}) — por qué 0 en DEV",
                "headers": [
                    COL_REPORTE_HIJA,
                    COL_REPORTE_PADRE,
                    "Detalle A",
                    "Detalle B",
                    "Idea de la regla",
                    COL_PASA_REGLA,
                    "Por qué 0 en DEV",
                ],
                "rows": [[*row]],
            },
            "dev_text": (
                f"En DEV esta forma ({codigo}) no unificó a nadie: 0 reportes. "
                f"El caso «padre con apto, hija vacía» ya absorbió todos los pares posibles."
            ),
            "conclusion": "La regla está hecha, pero en esta corrida no quedó nadie que calificara.",
        }

    if regla == "R2" and codigo == "MOTOR":
        return {
            "busca": b,
            "ejemplo": {
                "title": "Empresas (NIT) — enriquecimiento aparte",
                "headers": [
                    COL_PERSONA,
                    "Reporte enriquecido",
                    "Dónde corre",
                    "¿Se guarda unificación?",
                    "Nota",
                ],
                "rows": [[
                    "Empresa ejemplo",
                    "tercer reporte",
                    "solo paso intermedio",
                    "0 filas",
                    "Junta complementos; no es el caso apto vacío",
                ]],
            },
            "dev_text": "En DEV este motor para empresas no dejó filas en la salida final.",
            "conclusion": "No confundir con «padre con apto, hija vacía»: es otra lógica para NIT.",
        }

    if regla == "R2" and codigo == "SIN PAR":
        post = _vol(vol, "UNIVERSO", "POST-R2")
        return {
            "busca": b,
            "ejemplo": {
                "title": "Reportes que no encontraron pareja en regla 2",
                "headers": [
                    COL_PERSONA,
                    COL_REPORTE,
                    "¿Calle + uso únicos?",
                    "¿Duplicado por detalle?",
                    "Después de regla 2",
                ],
                "rows": [[
                    "cualquiera",
                    "único",
                    "Sí ✓",
                    "No ✗",
                    "Sigue activo",
                ]],
            },
            "dev_text": (
                f"Tras la regla 2 quedaron {_n(post.get('rpus', f.get('rpus')))} reportes activos "
                f"(los que no se absorbieron)."
            ),
            "conclusion": "Es el universo menos los 72.448 reportes hijos que sí se unificaron.",
        }

    if regla == "R2" and codigo == "SALIDA":
        r2_n = int((samples.get("r2_total") or {}).get("n", 72448))
        salida_rows = []
        for r in r2_rows:
            salida_rows.append([
                str(r.get("hija_rpu", "")),
                str(r.get("padre_rpu", "")),
                "Regla 2",
                "Sí ✓",
                "Padre con apto/oficina, hija sin detalle",
            ])
        return {
            "busca": b,
            "ejemplo": {
                "title": "Salida real de la regla 2 en DEV",
                "headers": [
                    COL_REPORTE_HIJA,
                    COL_REPORTE_PADRE,
                    "Regla",
                    "En DEV",
                    "Por qué pasó",
                ],
                "rows": salida_rows or [[
                    str(ids["hija"]), str(ids["padre"]), "Regla 2", "Sí ✓",
                    "Padre con apto, hija vacía",
                ]],
            },
            "dev_text": narr_r2_salida(_n(r2_n)),
            "conclusion": (
                "Todas las unificaciones de la regla 2 en DEV fueron "
                "«una fila con apto/oficina absorbe a otra vacía en la misma calle»."
            ),
        }

    # --- R3 ---
    if regla == "R3":
        r3_g = (samples.get("r3_geo") or [{}])[0]
        con_lat = int(r3_g.get("con_lat", 0))
        pack: dict = {"busca": b}
        if codigo == "PRE-R3":
            pack["ejemplo"] = {
                "title": "Regla 3 necesita mapa (latitud y longitud)",
                "headers": [
                    COL_REPORTE,
                    "Latitud",
                    "Longitud",
                    "¿Tiene coordenadas?",
                    "¿Pasa filtro?",
                    "Motivo",
                ],
                "rows": [[
                    "cualquiera",
                    "vacío",
                    "vacío",
                    "No ✗",
                    "No ✗",
                    "En DEV la vista deja las coordenadas vacías",
                ]],
            }
            pack["dev_text"] = narr_r3_bloqueo(
                _n(con_lat),
                _n(r3_g.get("rpus", ids["rpus"])),
            )
            pack["conclusion"] = (
                "Sin coordenadas en el mapa no se puede medir si dos calles están cerca. "
                "Por eso todo el drill-down de la regla 3 está en cero."
            )
        elif codigo == "ESC1":
            pack["ejemplo"] = {
                "title": "Regla 3 — calles muy parecidas (requiere mapa)",
                "headers": [
                    COL_PERSONA,
                    "Calle A",
                    "Calle B",
                    "Diferencia en número",
                    "¿Hay mapa?",
                    "¿Pasa?",
                    "Quién gana",
                ],
                "rows": [[
                    "ejemplo",
                    "CL 10 20 30",
                    "CL 10 20 32",
                    "±2 puertas",
                    "No ✗",
                    "No ✗",
                    "quien más reporta",
                ]],
            }
            pack["dev_text"] = (
                "En DEV esta forma no corrió: 0 casos. "
                "Primero hace falta que las direcciones traigan latitud y longitud."
            )
            pack["conclusion"] = (
                "La lógica está lista para cuando exista mapa (coordenadas + ArcGIS)."
            )
        elif codigo == "SALIDA":
            pack["ejemplo"] = {
                "title": "Salida esperada regla 3",
                "headers": [
                    COL_REPORTE_HIJA,
                    COL_REPORTE_PADRE,
                    "Regla",
                    "Filas DEV",
                    "Motivo",
                ],
                "rows": [["—", "—", "Regla 3", "0", "Mapa bloqueado"]],
            }
            pack["dev_text"] = "En DEV: 0 filas unificadas por la regla 3."
            pack["conclusion"] = (
                "La regla 3 no cambió nada del remanente que dejó la regla 2."
            )
        else:
            return None
        return pack

    return None
