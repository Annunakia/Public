import os, json, psycopg2
from psycopg2.extras import RealDictCursor

h = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
c = psycopg2.connect(host=h, port=5440, dbname="dba_batch", user="c32525e",
                     password=os.environ["REDSHIFT_PASSWORD"], sslmode="require")
cur = c.cursor(cursor_factory=RealDictCursor)

for pid in range(930001, 930011):
    cur.execute("""
        SELECT r.cod_dw_persona_ubic, ubi.texto_ubicacion, ubi.latitud,
               df.tipo_via_principal, df.via_generadora, df.numero_puerta,
               COALESCE(r.ind_unificacion,0) ind
        FROM bdm_stage.relacion_persona_ubicacion r
        JOIN bdm_stage.ubicacion_estandarizada ubi ON ubi.cod_dw_ubic=r.cod_dw_ubic
        LEFT JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica=r.cod_dw_direccion_fisica
        WHERE r.id_buro_persona=%s ORDER BY 1
    """, (pid,))
    rows = cur.fetchall()
    if not rows:
        print(f"{pid}: NO DATA")
        continue
    cur.execute("""
        SELECT u.cod_dw_persona_ubic hijo, u.cod_dw_direccion_unificada padre, u.unifica_atributos
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic=u.cod_dw_persona_ubic
        WHERE r.id_buro_persona=%s
    """, (pid,))
    unif = cur.fetchall()
    print(f"\n=== {pid} ===")
    for r in rows:
        print(dict(r))
    print("unif:", [dict(u) for u in unif])
c.close()
