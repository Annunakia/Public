"""Deploy SPs on DEV (if permitted) and run R1/R2 on mocks."""
import os
import sys
from pathlib import Path

import psycopg2

HOST = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
PWD = os.environ.get("REDSHIFT_PASSWORD", "")
ROOT = Path(__file__).resolve().parents[1]
SP_FILES = [ROOT / "sql" / "05_sp_regla1.sql", ROOT / "sql" / "06_sp_regla2.sql"]


def main():
    if not PWD:
        print("Set REDSHIFT_PASSWORD")
        sys.exit(1)
    conn = psycopg2.connect(
        host=HOST, port=5440, dbname="dba_batch", user="c32525e",
        password=PWD, sslmode="require", connect_timeout=60,
    )
    conn.autocommit = True
    cur = conn.cursor()
    for sp in SP_FILES:
        sql = sp.read_text(encoding="utf-8")
        try:
            cur.execute(sql)
            print(f"DEPLOY OK: {sp.name}")
        except Exception as e:
            print(f"DEPLOY FAIL: {sp.name} -> {e}")

    for call in [
        "CALL bdm_stage.sp_unificacion_regla1()",
        "CALL bdm_stage.sp_unificacion_regla2()",
    ]:
        try:
            cur.execute(call)
            print(f"CALL OK: {call}")
        except Exception as e:
            print(f"CALL FAIL: {call} -> {e}")

    cur.execute("""
        SELECT r.id_buro_persona, COUNT(*) n
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        WHERE r.id_buro_persona BETWEEN 888001 AND 888004
        GROUP BY 1 ORDER BY 1
    """)
    print("mock_unif", cur.fetchall())
    cur.close()
    conn.close()


if __name__ == "__main__":
    main()
