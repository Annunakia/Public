"""Run R3 summary validation query against DEV for personas 930001-930010."""
import os, json, psycopg2
from psycopg2.extras import RealDictCursor

h = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
c = psycopg2.connect(host=h, port=5440, dbname="dba_batch", user="c32525e",
                     password=os.environ["REDSHIFT_PASSWORD"], sslmode="require")
c.autocommit = True
cur = c.cursor()

for pid in range(930001, 930011):
    cur.execute("""
        DELETE FROM bdm_stage.unificacion_direccion
        WHERE cod_dw_persona_ubic IN (
          SELECT cod_dw_persona_ubic FROM bdm_stage.relacion_persona_ubicacion WHERE id_buro_persona=%s
        )""", (pid,))
    cur.execute("UPDATE bdm_stage.relacion_persona_ubicacion SET ind_unificacion=NULL WHERE id_buro_persona=%s", (pid,))

cur.execute("CALL bdm_stage.sp_unificacion_regla3()")
cur.close()

v = c.cursor(cursor_factory=RealDictCursor)
v.execute(open(r"c:\Users\C32525E\Downloads\R3_Queries_Validacion.sql", encoding="utf-8").read().split("-- TC-R3-01")[0] + """
SELECT exp.caso, exp.persona, exp.exp_unif_r3, COALESCE(act.unif_r3,0) unif_r3,
  CASE WHEN COALESCE(act.unif_r3,0) <> exp.exp_unif_r3 THEN 'FAILED'
       WHEN exp.exp_hijo IS NOT NULL AND (act.id_hijo <> exp.exp_hijo OR act.id_padre <> exp.exp_padre) THEN 'FAILED'
       ELSE 'PASSED' END estado
FROM (
  SELECT 'TC-R3-01' caso, 930001 persona, 0 exp_unif_r3, CAST(NULL AS BIGINT) exp_hijo, CAST(NULL AS BIGINT) exp_padre
  UNION ALL SELECT 'TC-R3-02',930002,1,930002002,930002001
  UNION ALL SELECT 'TC-R3-03',930003,1,930003001,930003002
  UNION ALL SELECT 'TC-R3-04',930004,1,930004001,930004002
  UNION ALL SELECT 'TC-R3-05',930005,1,930005001,930005002
  UNION ALL SELECT 'TC-R3-06',930006,0,NULL,NULL
  UNION ALL SELECT 'TC-R3-07',930007,0,NULL,NULL
  UNION ALL SELECT 'TC-R3-08',930008,1,930008001,930008002
  UNION ALL SELECT 'TC-R3-09',930009,0,NULL,NULL
  UNION ALL SELECT 'TC-R3-10',930010,0,NULL,NULL
) exp
LEFT JOIN (
  SELECT r.id_buro_persona, COUNT(*) unif_r3,
    MAX(u.cod_dw_persona_ubic) id_hijo, MAX(u.cod_dw_direccion_unificada) id_padre
  FROM bdm_stage.unificacion_direccion u
  JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic=u.cod_dw_persona_ubic
  WHERE u.unifica_atributos=3 AND r.id_buro_persona BETWEEN 930001 AND 930010
  GROUP BY 1
) act ON act.id_buro_persona=exp.persona ORDER BY 1
""")
print(json.dumps([dict(r) for r in v.fetchall()], indent=2))
c.close()
