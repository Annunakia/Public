import json, os, psycopg2
from psycopg2.extras import RealDictCursor

H = "eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com"
c = psycopg2.connect(
    host=H, port=5440, dbname="dba_reconocerbatch", user="c32525e",
    password=os.environ["REDSHIFT_PASSWORD"], sslmode="require",
)
cur = c.cursor(cursor_factory=RealDictCursor)
out = {}
for name, sql in [
    ("schemas", "SELECT * FROM svv_all_schemas WHERE database_name='dba_reconocerbatch' ORDER BY schema_name LIMIT 30"),
    ("tables", "SELECT schema_name, table_name, table_type FROM svv_all_tables WHERE database_name='dba_reconocerbatch' ORDER BY 1,2 LIMIT 40"),
    ("privs", "SELECT * FROM svv_user_privileges WHERE username=current_user LIMIT 20"),
]:
    try:
        cur.execute(sql)
        out[name] = [dict(r) for r in cur.fetchall()]
    except Exception as e:
        out[name + "_err"] = str(e)[:200]
print(json.dumps(out, indent=2, default=str))
c.close()
