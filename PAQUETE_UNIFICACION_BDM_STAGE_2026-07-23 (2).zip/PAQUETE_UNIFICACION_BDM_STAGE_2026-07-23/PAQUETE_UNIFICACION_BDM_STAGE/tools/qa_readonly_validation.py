"""Validación QA solo lectura sobre bdm_stage (datos reales del pipeline)."""
import json
import os
import sys
from datetime import datetime

import psycopg2
from psycopg2.extras import RealDictCursor

from qa_validation_cases import CASES, PREFLIGHT_SQL

HOST = os.environ.get(
    "REDSHIFT_HOST",
    "eec-aws-us-eits-procesosbatch-qa-redshift.cwefyckvccgy.us-east-1.redshift.amazonaws.com",
)
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PASSWORD = os.environ.get("REDSHIFT_PASSWORD", "")


def run_case(cur, case_id, desc, sql, note=""):
    try:
        cur.execute(sql)
        row = cur.fetchone()
        val = row[list(row.keys())[0]]
        status = "PASSED" if int(val) == 0 else "FAILED"
        return {
            "id": case_id,
            "desc": desc,
            "note": note,
            "value": int(val),
            "expected": 0,
            "status": status,
            "sql": sql.strip(),
        }
    except Exception as e:
        cur.connection.rollback()
        return {
            "id": case_id,
            "desc": desc,
            "note": note,
            "value": None,
            "expected": 0,
            "status": "NO EJECUTADO",
            "error": str(e),
            "sql": sql.strip(),
        }


def fetch_all(cur, sql):
    cur.execute(sql)
    cols = [d[0] for d in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchall()]


def main():
    if not PASSWORD:
        print("Set REDSHIFT_PASSWORD", file=sys.stderr)
        sys.exit(1)

    conn = psycopg2.connect(
        host=HOST,
        port=int(os.environ.get("REDSHIFT_PORT", "5440")),
        dbname=os.environ.get("REDSHIFT_DB", "dba_batch"),
        user=USER,
        password=PASSWORD,
        connect_timeout=45,
        sslmode="require",
    )
    conn.autocommit = True
    cur = conn.cursor(cursor_factory=RealDictCursor)

    preflight = {}
    for name, sql in PREFLIGHT_SQL:
        try:
            preflight[name] = fetch_all(cur, sql)
        except Exception as e:
            cur.connection.rollback()
            preflight[name] = {"error": str(e)}

    results = [run_case(cur, *c) for c in CASES]
    passed = sum(1 for r in results if r["status"] == "PASSED")
    failed = sum(1 for r in results if r["status"] == "FAILED")

    out = {
        "executed_at": datetime.now().isoformat(),
        "environment": "QA",
        "host": HOST,
        "schema": "bdm_stage",
        "mode": "SELECT_ONLY",
        "sql_source": "sql/qa_redshift/04_validacion_tc_r1_r2_bdm_stage.sql",
        "sp_alignment": {
            "R1_ganador_unico": "TC-R1-08",
            "R1_update_ind_unificacion": "TC-R1-04",
            "R2_e04_ganador_unico": "TC-R2-14",
            "R2_motor_esc3_5_6": "TC-R2-04, TC-R2-06, TC-R2-07, TC-R2-08",
        },
        "preflight": preflight,
        "summary": {
            "total": len(results),
            "passed": passed,
            "failed": failed,
            "not_run": sum(1 for r in results if r["status"] == "NO EJECUTADO"),
            "pct": round(100 * passed / len(results), 1) if results else 0,
        },
        "cases": results,
        "failed_cases": [r for r in results if r["status"] == "FAILED"],
    }
    print(json.dumps(out, default=str, indent=2))
    cur.close()
    conn.close()


if __name__ == "__main__":
    main()
