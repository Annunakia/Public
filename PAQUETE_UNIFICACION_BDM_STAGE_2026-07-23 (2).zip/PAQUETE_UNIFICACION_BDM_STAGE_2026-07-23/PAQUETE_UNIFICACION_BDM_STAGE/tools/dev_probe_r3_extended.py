import os, json, psycopg2
from psycopg2.extras import RealDictCursor

h = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
c = psycopg2.connect(host=h, port=5440, dbname="dba_batch", user="c32525e",
                     password=os.environ["REDSHIFT_PASSWORD"], sslmode="require")
cur = c.cursor(cursor_factory=RealDictCursor)

for pid in [930005, 930009]:
    cur.execute("""
        SELECT r.cod_dw_persona_ubic, ubi.texto_ubicacion,
               df.tipo_via_principal, df.via_generadora, df.numero_puerta,
               ubi.latitud, COUNT(DISTINCT rep.id_buro_suscriptor) ent
        FROM bdm_stage.relacion_persona_ubicacion r
        JOIN bdm_stage.ubicacion_estandarizada ubi ON ubi.cod_dw_ubic=r.cod_dw_ubic
        JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica=r.cod_dw_direccion_fisica
        LEFT JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rep.cod_dw_persona_ubic=r.cod_dw_persona_ubic
        WHERE r.id_buro_persona=%s GROUP BY 1,2,3,4,5,6 ORDER BY 1
    """, (pid,))
    print(f"persona_{pid}", json.dumps([dict(r) for r in cur.fetchall()], default=str))
    cur.execute("""
        SELECT u.cod_dw_persona_ubic hijo, u.cod_dw_direccion_unificada padre
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic=u.cod_dw_persona_ubic
        WHERE r.id_buro_persona=%s AND u.unifica_atributos=3
    """, (pid,))
    print(f"unif_{pid}", cur.fetchall())

cur.execute("""
  SELECT id_buro_persona, COUNT(*) n FROM bdm_stage.relacion_persona_ubicacion
  WHERE id_buro_persona BETWEEN 930001 AND 930013 GROUP BY 1 ORDER BY 1
""")
print("loaded", cur.fetchall())
c.close()
