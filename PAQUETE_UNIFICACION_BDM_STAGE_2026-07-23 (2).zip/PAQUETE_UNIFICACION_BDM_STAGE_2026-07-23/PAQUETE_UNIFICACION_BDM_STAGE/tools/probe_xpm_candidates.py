"""Count candidate XPM sources: bdm_datos dq_*, ddm_views, ifr_data, edf_views."""
import os
import psycopg2
from psycopg2.extras import RealDictCursor

HOST = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
PWD = os.environ.get("REDSHIFT_PASSWORD", "b27YWI2FL")

def main():
    c = psycopg2.connect(
        host=HOST, port=5440, dbname="dba_batch", user="c32525e",
        password=PWD, sslmode="require",
    )
    c.autocommit = True
    cur = c.cursor(cursor_factory=RealDictCursor)

    for title, q in [
        ("bdm_datos xpm tables", """
            SELECT table_name FROM information_schema.tables
            WHERE table_schema='bdm_datos' AND table_name ILIKE '%xpm%'
            ORDER BY 1 LIMIT 50
        """),
        ("ifr_data all tables", """
            SELECT table_name FROM information_schema.tables
            WHERE table_schema='ifr_data' ORDER BY 1
        """),
        ("ddm_views xpm", """
            SELECT table_name, table_type FROM information_schema.tables
            WHERE table_schema='ddm_views' AND table_name ILIKE '%xpm%'
            ORDER BY 1
        """),
        ("edf_views vw_biz_xpm", """
            SELECT table_name FROM information_schema.tables
            WHERE table_schema='edf_views' AND table_name LIKE 'vw_biz_xpm%'
            ORDER BY 1
        """),
    ]:
        print(f"\n=== {title} ===")
        cur.execute(q)
        rows = cur.fetchall()
        print(f"{len(rows)} rows")
        for r in rows[:25]:
            print(" ", dict(r))

    counts = [
        "ddm_views.v_xpm",
        "ddm_views.v_xpm_location",
        "ddm_views.v_xpm_location_val_contactinformations",
        "ddm_views.v_xpm_counterparties",
        "edf_views.vw_biz_xpm",
        "edf_views.vw_biz_xpm_location",
        "edf_views.vw_biz_xpm_location_val_contactinformations",
        "edf_views.vw_biz_xpm_counterparties",
        "edf_views.xpm",
        "edf_views.xpm_location_val_contactinformations",
        "ifr_data.xpm",
        "ifr_data.xpm_location",
        "ifr_data.xpm_location_val_contactinformations",
        "ifr_data.xpm_counterparties",
    ]
    print("\n=== COUNTS ===")
    for t in counts:
        try:
            cur.execute(f"SELECT COUNT(*) AS n FROM {t}")
            print(f"{t}: {cur.fetchone()['n']}")
        except Exception as e:
            print(f"{t}: ERR {str(e).split(chr(10))[0][:100]}")

    # Latest dq_* in bdm_datos (by name pattern)
    cur.execute("""
        SELECT table_name FROM information_schema.tables
        WHERE table_schema='bdm_datos'
          AND table_name LIKE 'dq_%_xpm'
        ORDER BY table_name DESC
        LIMIT 5
    """)
    latest = [r["table_name"] for r in cur.fetchall()]
    print("\n=== Latest bdm_datos dq_*_xpm (top 5 by name) ===")
    for base in latest:
        stem = base.replace("_xpm", "")
        siblings = [f"{stem}_xpm", f"{stem}_xpm_location",
                    f"{stem}_xpm_location_val_contactinformations", f"{stem}_xpm_counterparties"]
        print(f"\nSet: {stem}")
        for t in siblings:
            fq = f"bdm_datos.{t}"
            try:
                cur.execute(f"SELECT COUNT(*) AS n FROM {fq}")
                print(f"  {fq}: {cur.fetchone()['n']}")
            except Exception as e:
                print(f"  {fq}: ERR {str(e).split(chr(10))[0][:80]}")

    c.close()

if __name__ == "__main__":
    main()
