"""Compare ifr_data vs edf_views completeness on productor DEV."""
import os, psycopg2
from psycopg2.extras import RealDictCursor

HOST = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
PWD = os.environ.get("REDSHIFT_PASSWORD", "b27YWI2FL")

def counts(cur, schema):
    tables = ("xpm", "xpm_location", "xpm_location_val_contactinformations", "xpm_counterparties")
    out = {}
    for t in tables:
        fq = f"{schema}.{t}"
        try:
            cur.execute(f"SELECT COUNT(*) AS n FROM {fq}")
            out[t] = cur.fetchone()["n"]
        except Exception as e:
            out[t] = f"ERR: {str(e).split(chr(10))[0][:80]}"
    return out

def tokenized(cur, schema):
    q = f"""
        SELECT COUNT(*) AS n
        FROM {schema}.xpm xpm
        JOIN {schema}.xpm_location loc ON xpm.location = loc.id
         AND xpm.relationalizelastupdate = loc.relationalizelastupdate
        JOIN {schema}.xpm_location_val_contactinformations ci
          ON loc."location.val.contactinformations" = ci.id
         AND loc.relationalizelastupdate = ci.relationalizelastupdate
        WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1,2,3,7)
          AND NULLIF(TRIM(ci."location.val.contactinformations.val.standardizedtextoubicacion"::varchar),'') IS NOT NULL
    """
    try:
        cur.execute(q)
        return cur.fetchone()["n"]
    except Exception as e:
        return f"ERR: {str(e).split(chr(10))[0][:100]}"

def main():
    c = psycopg2.connect(host=HOST, port=5440, dbname="dba_batch", user="c32525e", password=PWD, sslmode="require")
    c.autocommit = True
    cur = c.cursor(cursor_factory=RealDictCursor)
    print("=== ifr_data ===")
    print("counts:", counts(cur, "ifr_data"))
    print("tokenized addr types 1-3-7:", tokenized(cur, "ifr_data"))
    print("\n=== edf_views ===")
    print("counts:", counts(cur, "edf_views"))
    # edf without relationalizelastupdate
    try:
        cur.execute("""
            SELECT COUNT(*) n FROM edf_views.xpm xpm
            JOIN edf_views.xpm_location loc ON xpm.location = loc.id
            JOIN edf_views.xpm_location_val_contactinformations ci
              ON loc."location.val.contactinformations" = ci.id
            WHERE NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::varchar),'') = '8'
              AND NULLIF(TRIM(ci."location.val.contactinformations.val.standardizedtextoubicacion"::varchar),'') IS NOT NULL
        """)
        print("edf type8 tokenized:", cur.fetchone()["n"])
    except Exception as e:
        print("edf tokenized ERR", e)
    c.close()

if __name__ == "__main__":
    main()
