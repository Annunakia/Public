import os, json, psycopg2
from psycopg2.extras import RealDictCursor
PWD = os.environ["REDSHIFT_CONSUMER_PASSWORD"]
conn = psycopg2.connect(
    host="eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com",
    port=5440, dbname="dba_rncr_batch", user="c32525e", password=PWD, sslmode="require",
)
conn.autocommit = True
cur = conn.cursor(cursor_factory=RealDictCursor)
cur.execute("""
SELECT NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::VARCHAR), '') AS ct,
       COUNT(*)::BIGINT AS n
FROM ds_dba_rncr_batch.edf_views.xpm xpm
JOIN ds_dba_rncr_batch.edf_views.xpm_location loc ON xpm.location = loc.id
JOIN ds_dba_rncr_batch.edf_views.xpm_location_val_contactinformations ci
  ON loc."location.val.contactinformations" = ci.id
GROUP BY 1 ORDER BY n DESC NULLS LAST LIMIT 25
""")
print(json.dumps(cur.fetchall(), indent=2, default=str))
conn.close()
