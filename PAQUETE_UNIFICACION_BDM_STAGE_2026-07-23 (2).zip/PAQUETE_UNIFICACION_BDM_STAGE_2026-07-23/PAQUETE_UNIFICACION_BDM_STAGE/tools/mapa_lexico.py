"""Textos en lenguaje sencillo para tablas y narrativa del mapa de unificación."""

# --- Conceptos base (una sola vez) ---
GLOSS_PERSONA = (
    "Cada persona tiene un código interno (número largo). "
    "Una misma persona puede tener varios reportes de dirección."
)
GLOSS_REPORTE = (
    "Cada reporte de dirección es un registro distinto: "
    "no es la calle en sí, sino «esta persona reportó esta dirección para este uso»."
)
GLOSS_USO = (
    "Para qué se usa esa dirección: casa, trabajo o correspondencia "
    "(en el sistema aparecen como RES, LAB y CRR)."
)

# --- Condición R1 (antes «multitipo») ---
R1_QUIEN_ENTRA = (
    "Persona que en la misma calle y ciudad tiene al menos dos usos distintos: "
    "por ejemplo casa y trabajo, o casa y correspondencia."
)
R1_QUIEN_NO_ENTRA = (
    "Persona que solo tiene un uso en esa calle (solo casa, solo trabajo o solo correspondencia), "
    "o que tiene casa y trabajo en calles diferentes."
)

R1_USO_CASA = "casa"
R1_USO_TRABAJO = "trabajo"
R1_USO_CORR = "correspondencia"

# --- Encabezados de columnas (sin jerga) ---
COL_PERSONA = "Código persona"
COL_REPORTE = "Código reporte dirección"
COL_USO = "Para qué se usa"
COL_ETIQUETA_ORIGEN = "Etiqueta en sistema origen"
COL_CALLE = "Calle (texto)"
COL_MISMA_CALLE = "¿Misma calle y ciudad?"
COL_N_USOS = "Cuántos usos distintos hay"
COL_CUMPLE_R1 = "¿Pasa el filtro de la regla 1?"
COL_DECISION = "Qué pasa con esta persona"
COL_ACTIVIDAD = "Actividad económica"
COL_FORMA_DESEMPATE = "Forma de elegir ganador"
COL_QUIEN_REPORTA = "Cuántas entidades reportan"
COL_PUNTAJE = "Puntaje"
COL_GANADOR = "¿Gana y queda como dirección principal?"
COL_REPORTE_HIJA = "Reporte que se absorbe (hija)"
COL_REPORTE_PADRE = "Reporte que queda (padre)"
COL_DETALLE_HIJA = "Detalle extra en hija (apto, oficina…)"
COL_DETALLE_PADRE = "Detalle extra en padre"
COL_MISMO_TEXTO = "¿Misma calle escrita?"
COL_MISMO_TIPO = "¿Mismo uso (casa/trabajo/corr.)?"
COL_PASA_REGLA = "¿Cumple esta regla?"
COL_SALIDA = "¿Se guarda la unificación?"
COL_METRICA = "Qué medimos"
COL_VALOR = "Valor en DEV"
COL_SOLO_BASTA = "¿Este reporte solo alcanza?"
COL_APORTA = "Qué aporta este reporte al conteo"
COL_SI_SOLO = "Si miráramos SOLO este reporte (ignorando los demás)"
COL_DECISION_JUNTOS = "Decisión mirando TODOS los reportes juntos"
COL_POR_QUE = "Explicación detallada"
COL_POR_QUE_NO = "Por qué NO se eligió este"
COL_SI_GANADOR = "Si este fuera el ganador…"
COL_COMPARACION = "Comparado con el otro reporte"

R1_INSUMO_USO_R1 = "Regla 1: misma calle + 2 o más usos"

# --- Títulos de tablas ---
TIT_R1_ENTRA = "Ejemplo real DEV — persona que sí entra a la regla 1"
TIT_R1_NO_ENTRA = "Ejemplo real DEV — persona que no entra a la regla 1"
TIT_R1_PUNTAJE = "Cómo se puntúa y por qué nadie gana"
TIT_R1_PASOS = "Paso a paso: por qué termina en empate"
TIT_R2_PAR = "Ejemplo real DEV — dos reportes, uno con apto y otro sin apto"
TIT_DEV = "Resultado consulta DEV"

# --- Narrativas con datos reales ---
def narr_r1_entra(pid: int | str, calle: str, rpu_casa: int | str, rpu_trabajo: int | str) -> str:
    return (
        f"En DEV encontramos a la persona {pid}. "
        f"Vive y trabaja en la misma calle: «{calle}». "
        f"Tiene un reporte de casa (código {rpu_casa}), otro de trabajo (código {rpu_trabajo}) "
        f"y también correspondencia en esa misma calle. "
        f"Como hay al menos dos usos distintos en la misma calle, esta persona sí entra a la regla 1."
    )


def narr_r1_no_entra(pid: int | str, calle: str) -> str:
    return (
        f"En DEV la persona {pid} solo tiene un uso en «{calle[:40]}». "
        f"No compite casa contra trabajo en la misma calle, así que la regla 1 ni siquiera la evalúa."
    )


def narr_r1_empate(pid: int | str, calle: str, n_personas: str, n_reportes: str) -> str:
    return (
        f"La persona {pid} en «{calle[:36]}» sí entró a la regla 1. "
        f"Se comparó casa, trabajo y correspondencia. "
        f"Los tres quedaron con el mismo puntaje: nadie gana. "
        f"En todo DEV pasó lo mismo con {n_personas} personas y {n_reportes} reportes: "
        f"por eso la salida de la regla 1 es cero."
    )


def narr_r1_salida_cero() -> str:
    return (
        "Hubo 156 personas que cumplían «misma calle con dos o más usos», "
        "pero en todas el puntaje quedó empatado. "
        "Sin un solo ganador no se puede decir cuál reporte absorbe a cuál."
    )


def narr_r2_esc1(hija: int | str, padre: int | str, detalle: str, calle: str) -> str:
    return (
        f"En DEV el reporte {hija} (sin detalle de apto u oficina) "
        f"se une al reporte {padre}, que sí trae «{detalle}», "
        f"porque ambos dicen la misma calle «{calle[:34]}» y el mismo uso. "
        f"Gana el que tiene el detalle completo."
    )


def narr_r2_salida(n: str) -> str:
    return (
        f"En DEV se unificaron {n} reportes hijos bajo un reporte padre. "
        f"El 100 % fue el caso «padre con apto/oficina, hija vacía»."
    )


def narr_r3_bloqueo(n_con_coords: str, n_total: str) -> str:
    return (
        f"La regla 3 necesita latitud y longitud de cada dirección. "
        f"En DEV solo {n_con_coords} de {n_total} reportes traen coordenadas "
        f"(la vista las deja vacías), así que la regla 3 no pudo correr."
    )


# --- Pasos del empate (sin SP, ESC, CIIU crudos) ---
def filas_empate_pasos(
    pid: int | str,
    calle: str,
    rpu_casa: int | str,
    rpu_trabajo: int | str,
    rpu_corr: int | str = "",
    *,
    n_rep: int = 6,
    score: int = 6,
) -> list[list[str]]:
    calle_c = calle[:36]
    rpu_crr = rpu_corr or rpu_casa
    return [
        [
            "1",
            "¿Entra esta persona?",
            f"Sí. Persona {pid} en «{calle_c}» tiene al menos dos usos distintos: "
            f"casa (reporte {rpu_casa}), trabajo (reporte {rpu_trabajo}) "
            f"y correspondencia (reporte {rpu_crr}). "
            f"Si miráramos solo uno, no entraría; juntos sí.",
        ],
        [
            "2",
            "¿Qué actividad económica tiene?",
            f"CIIU vacío en DEV → no aplica «comercio gana trabajo» (ESC1) "
            f"ni «servicios gana casa» (ESC2). "
            f"Se usa la forma estándar: gana quien más entidades reportan.",
        ],
        [
            "3",
            "¿Cómo se puntúa cada uso?",
            f"Casa (reporte {rpu_casa}): {_fmt_n_rep_lex(n_rep)} → puntaje {score}. "
            f"Trabajo (reporte {rpu_trabajo}): {_fmt_n_rep_lex(n_rep)} → puntaje {score}. "
            f"Correspondencia (reporte {rpu_crr}): {_fmt_n_rep_lex(n_rep)} → puntaje {score}. "
            f"Los tres quedaron iguales.",
        ],
        [
            "4",
            "¿Por qué no elijo casa y descarto trabajo?",
            f"Porque trabajo empató con puntaje {score} (mismas {n_rep} entidades). "
            f"Elegir casa sería arbitrario: la regla exige un solo ganador.",
        ],
        [
            "5",
            "¿Por qué no elijo correspondencia?",
            f"Mismo motivo: correspondencia también tiene puntaje {score} "
            f"con {n_rep} entidades. Ningún uso supera a los otros.",
        ],
        [
            "6",
            "Resultado",
            f"Empate {score}-{score}-{score} → no hay dirección principal → "
            f"no se guarda unificación → salida regla 1 = 0.",
        ],
    ]


def _fmt_n_rep_lex(n: int) -> str:
    return f"{n} entidad{'es' if n != 1 else ''} distinta{'s' if n != 1 else ''}"


# --- Insumo contacttype en lenguaje claro ---
INSUMO_FILAS = [
    ["8 (token)", "correspondencia vía token", "585.732 reportes", "Sobre todo regla 2"],
    ["1", "casa", "2.279 reportes", "Regla 1"],
    ["2", "trabajo", "1.282 reportes", "Regla 1"],
    ["3", "correspondencia directa", "1.873 reportes", "Regla 1"],
]
