"""Deploy SPs Ordenamiento + smoke test o mock alto 20K."""
from __future__ import annotations

import argparse
import os
import re
import sys
from pathlib import Path

import psycopg2

ROOT = Path(__file__).resolve().parents[1]
MOCK = ROOT / "sql" / "ordenamiento_mock"
SP = ROOT / "sql" / "ordenamiento"

HOST = os.environ.get(
    "REDSHIFT_HOST",
    "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com",
)
PORT = int(os.environ.get("REDSHIFT_PORT", "5440"))
DB = os.environ.get("REDSHIFT_DB", "dba_batch")
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PASSWORD = os.environ.get("REDSHIFT_PASSWORD", "")


def split_sql(sql: str) -> list[str]:
    """Split on semicolons outside $$ blocks (SP bodies)."""
    parts: list[str] = []
    buf: list[str] = []
    in_dollar = False
    for line in sql.splitlines():
        if re.search(r"\$\$", line):
            in_dollar = not in_dollar
        buf.append(line)
        if not in_dollar and line.rstrip().endswith(";"):
            stmt = "\n".join(buf).strip()
            if stmt:
                parts.append(stmt)
            buf = []
    tail = "\n".join(buf).strip()
    if tail:
        parts.append(tail)
    return parts


def exec_file(cur, path: Path, label: str) -> dict:
    sql = path.read_text(encoding="utf-8")
    stmts = split_sql(sql) if "CREATE OR REPLACE PROCEDURE" in sql.upper() else [sql]
    try:
        last_rows = []
        for i, stmt in enumerate(stmts):
            cur.execute(stmt)
            if cur.description:
                last_rows = cur.fetchall()
        return {"ok": True, "label": label, "rows": last_rows}
    except Exception as e:
        cur.connection.rollback()
        return {"ok": False, "label": label, "error": str(e).split("\n")[0][:400]}


def call_proc(cur, name: str) -> dict:
    try:
        cur.execute(f"CALL bdm_datos.{name}()")
        return {"ok": True, "label": name}
    except Exception as e:
        cur.connection.rollback()
        return {"ok": False, "label": name, "error": str(e).split("\n")[0][:400]}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--smoke", action="store_true", help="Carga mock 9 personas + ejecuta SPs")
    parser.add_argument("--deploy-sps", action="store_true", help="Despliega SPs 10-16")
    parser.add_argument("--mock-alto", action="store_true", help="Preparar insumos 20K + scoring")
    parser.add_argument("--with-scoring", action="store_true", help="Solo scoring SQL plano (legacy)")
    args = parser.parse_args()

    if not PASSWORD:
        print("Falta REDSHIFT_PASSWORD", file=sys.stderr)
        return 1

    conn = psycopg2.connect(
        host=HOST, port=PORT, dbname=DB, user=USER, password=PASSWORD, sslmode="require"
    )
    conn.autocommit = True
    cur = conn.cursor()

    base_steps = ["01_schemas.sql", "02_mock_betas.sql"]
    for name in base_steps:
        r = exec_file(cur, MOCK / name, name)
        print(f"[{'OK' if r['ok'] else 'FAIL'}] {name}" + (f" — {r.get('error')}" if not r["ok"] else ""))
        if not r["ok"]:
            conn.close()
            return 1

    if args.deploy_sps or args.smoke or args.mock_alto:
        for name in sorted(SP.glob("*.sql")):
            if name.name.startswith("00_"):
                continue
            r = exec_file(cur, name, name.name)
            print(f"[{'OK' if r['ok'] else 'FAIL'}] {name.name}" + (f" — {r.get('error')}" if not r["ok"] else ""))
            if not r["ok"]:
                conn.close()
                return 1

    if args.smoke:
        r = exec_file(cur, MOCK / "06_smoke_mock_9_personas.sql", "smoke_data")
        print(f"[{'OK' if r['ok'] else 'FAIL'}] smoke_data" + (f" — {r.get('error')}" if not r["ok"] else ""))
        if not r["ok"]:
            conn.close()
            return 1
        for proc in [
            "sp_ordenamiento_scoring_dir",
            "sp_ordenamiento_scoring_tel",
            "sp_ordenamiento_scoring_cel",
            "sp_ordenamiento_scoring_ema",
            "sp_ordenamiento_consolidacion",
        ]:
            r = call_proc(cur, proc)
            print(f"[{'OK' if r['ok'] else 'FAIL'}] CALL {proc}" + (f" — {r.get('error')}" if not r["ok"] else ""))
            if not r["ok"]:
                conn.close()
                return 1

    if args.mock_alto:
        try:
            cur.execute("CALL bdm_datos.sp_ordenamiento_ejecucion(TRUE)")
            print("[OK] CALL sp_ordenamiento_ejecucion(TRUE)")
        except Exception as e:
            cur.connection.rollback()
            print(f"[FAIL] CALL sp_ordenamiento_ejecucion — {str(e).split(chr(10))[0][:400]}")
            conn.close()
            return 1

    if args.with_scoring and not args.smoke and not args.mock_alto:
        public = Path(
            r"C:\Users\C32525E\Downloads\Public-main\Public-main"
            r"\MT-EXP-005-MAP-RECONOCER\MT-EXP-005-MAP-RECONOCER\ws-ordenamiento\src\redshift"
        )
        for name in ["02_scoring_dir.sql", "03_scoring_tel.sql", "04_scoring_cel.sql",
                     "05_scoring_ema.sql", "06_consolidacion_persistencia.sql"]:
            r = exec_file(cur, public / name, name)
            print(f"[{'OK' if r['ok'] else 'FAIL'}] {name}" + (f" — {r.get('error')}" if not r["ok"] else ""))

    cur.execute(
        "SELECT canal, COUNT(*) AS n, ROUND(MIN(score::float),4), ROUND(MAX(score::float),4) "
        "FROM bdm_datos.score_ordenamiento GROUP BY 1 ORDER BY 1"
    )
    rows = cur.fetchall()
    if rows:
        print("score_ordenamiento:", rows)
    cur.execute("SELECT COUNT(*) FROM bdm_datos.relacion_persona_ubicacion WHERE orden_prioridad IS NOT NULL")
    print("rpu_con_orden_prioridad:", cur.fetchone()[0])

    conn.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
