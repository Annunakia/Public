"""Execute TC-R1/R2 QA validations against Redshift (bdm_stage, solo SELECT)."""
import json
import os
import sys
from datetime import datetime

import psycopg2
from psycopg2.extras import RealDictCursor

from qa_validation_cases import CASES, PREFLIGHT_SQL

HOST = os.environ.get(
    "REDSHIFT_HOST",
    "eec-aws-us-eits-procesosbatch-qa-redshift.cwefyckvccgy.us-east-1.redshift.amazonaws.com",
)
PORT = int(os.environ.get("REDSHIFT_PORT", "5440"))
DB = os.environ.get("REDSHIFT_DB", "dba_batch")
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PASSWORD = os.environ.get("REDSHIFT_PASSWORD", "")


def run(cur, sql, case_id):
    try:
        cur.execute(sql)
        row = cur.fetchone()
        val = row[list(row.keys())[0]] if row else None
        return {"case": case_id, "ok": True, "value": val, "sql": sql.strip(), "error": None}
    except Exception as e:
        cur.connection.rollback()
        return {"case": case_id, "ok": False, "value": None, "sql": sql.strip(), "error": str(e)}


def passed(case_id, value, error):
    if error:
        return "NO EJECUTADO"
    if value is None:
        return "NO EJECUTADO"
    try:
        return "PASSED" if int(value) == 0 else "FAILED"
    except (TypeError, ValueError):
        return "FAILED"


def fetch_all(cur, sql):
    cur.execute(sql)
    cols = [d[0] for d in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchall()]


def main():
    if not PASSWORD:
        print("Set REDSHIFT_PASSWORD")
        sys.exit(1)

    conn = psycopg2.connect(
        host=HOST,
        port=PORT,
        dbname=DB,
        user=USER,
        password=PASSWORD,
        connect_timeout=45,
        sslmode="require",
    )
    conn.autocommit = True
    cur = conn.cursor(cursor_factory=RealDictCursor)

    report = {
        "executed_at": datetime.now().isoformat(),
        "host": HOST,
        "database": DB,
        "user": USER,
        "schema": "bdm_stage",
        "sql_source": "sql/qa_redshift/04_validacion_tc_r1_r2_bdm_stage.sql",
        "connection": None,
        "preflight": {},
        "validations": [],
    }

    cur.execute("SELECT current_user AS u, current_database() AS db")
    report["connection"] = dict(cur.fetchone())

    for name, sql in PREFLIGHT_SQL:
        try:
            report["preflight"][name] = fetch_all(cur, sql)
        except Exception as e:
            cur.connection.rollback()
            report["preflight"][name] = {"error": str(e)}

    for case_id, desc, sql, note in CASES:
        r = run(cur, sql, case_id)
        r["desc"] = desc
        r["note"] = note
        r["status"] = passed(case_id, r["value"], r["error"])
        report["validations"].append(r)

    passed_n = sum(1 for v in report["validations"] if v["status"] == "PASSED")
    failed_n = sum(1 for v in report["validations"] if v["status"] == "FAILED")
    report["summary"] = {
        "total": len(report["validations"]),
        "passed": passed_n,
        "failed": failed_n,
        "pct": round(100 * passed_n / len(report["validations"]), 1) if report["validations"] else 0,
    }

    print(json.dumps(report, default=str, indent=2))
    cur.close()
    conn.close()


if __name__ == "__main__":
    main()
