import json, os, psycopg2
from psycopg2.extras import RealDictCursor

H = "eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com"
P = os.environ["REDSHIFT_PASSWORD"]

def q(db, sql):
    c = psycopg2.connect(host=H, port=5440, dbname=db, user="c32525e", password=P, sslmode="require", connect_timeout=20)
    cur = c.cursor(cursor_factory=RealDictCursor)
    cur.execute(sql)
    rows = [dict(r) for r in cur.fetchall()]
    c.close()
    return rows

out = {
    "connection": {
        "host": H,
        "user": "c32525e",
        "database_work": "dba_reconocerbatch",
        "database_edf": "dba_rncr_batch",
    },
    "rec_tables": q(
        "dba_reconocerbatch",
        "SELECT schemaname, tablename FROM pg_tables WHERE schemaname LIKE 'rec_%' ORDER BY 1,2 LIMIT 50",
    ),
    "edf_tables": q(
        "dba_rncr_batch",
        "SELECT schemaname, tablename FROM pg_tables WHERE schemaname='edf_data' ORDER BY 2 LIMIT 30",
    ),
}
for v in ("svv_external_databases", "svv_external_schemas", "svv_external_tables", "svv_datashares"):
    try:
        out[v] = q("dba_reconocerbatch", f"SELECT * FROM {v} LIMIT 20")
    except Exception as e:
        out[v + "_err"] = str(e)[:150]

print(json.dumps(out, indent=2, default=str))
