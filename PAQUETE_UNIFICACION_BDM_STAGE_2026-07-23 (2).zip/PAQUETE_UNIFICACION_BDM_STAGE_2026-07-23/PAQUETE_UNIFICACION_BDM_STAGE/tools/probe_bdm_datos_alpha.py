"""Compare ifr_data vs bdm_datos on productor/consumidor DEV."""
import os
import psycopg2
from psycopg2.extras import RealDictCursor

HOSTS = {
    "productor": (
        "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com",
        "dba_batch",
        os.environ.get("REDSHIFT_PASSWORD", "b27YWI2FL"),
    ),
    "reconocer_dba": (
        "eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com",
        "dba",
        os.environ.get("REDSHIFT_CONSUMER_PASSWORD", os.environ.get("REDSHIFT_PASSWORD", "")),
    ),
}


def scan(label, host, db, pwd):
    out = {"label": label, "host": host, "database": db}
    try:
        c = psycopg2.connect(
            host=host, port=5440, dbname=db, user="c32525e",
            password=pwd, sslmode="require", connect_timeout=25,
        )
        cur = c.cursor(cursor_factory=RealDictCursor)
        cur.execute("SELECT current_database() AS db, current_user AS u")
        out["session"] = dict(cur.fetchone())
        out["schemas"] = {}
        for sch in ("bdm_datos", "bdm_tempo", "ifr_data", "public"):
            cur.execute(
                "SELECT table_name FROM information_schema.tables "
                "WHERE table_schema = %s ORDER BY 1 LIMIT 40",
                (sch,),
            )
            tabs = [r["table_name"] for r in cur.fetchall()]
            out["schemas"][sch] = tabs
        out["counts"] = {}
        for t in (
            "ifr_data.xpm",
            "bdm_datos.xpm",
            "bdm_datos.relacion_persona_ubicacion",
            "bdm_datos.ubicacion_estandarizada",
            "public.unificacion_direccion",
        ):
            try:
                cur.execute(f"SELECT COUNT(*) AS n FROM {t}")
                out["counts"][t] = cur.fetchone()["n"]
            except Exception as e:
                out["counts"][t] = f"ERR: {str(e).split(chr(10))[0][:100]}"
        c.close()
    except Exception as e:
        out["error"] = str(e).split("\n")[0][:200]
    return out


if __name__ == "__main__":
    import json
    for label, (h, db, pwd) in HOSTS.items():
        print(json.dumps(scan(label, h, db, pwd), indent=2, default=str))
