"""
Carga mocks Regla 3 en DEV/QA (bdm_stage).
Rango dedicado mocks: 931002-931013 (+ legacy 930001/930008/930010 si no existen).

Uso:
  set REDSHIFT_PASSWORD=...
  py -3 tools/dev_load_r3_mocks.py
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import date

import psycopg2

HOST = os.environ.get(
    "REDSHIFT_HOST",
    "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com",
)
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PASSWORD = os.environ.get("REDSHIFT_PASSWORD", "")


def _addr(rpu, ubic, df, texto, tipo, via, gen, puerta, lat, lon, reports, orden):
    return {
        "rpu": rpu,
        "ubic": ubic,
        "df": df,
        "texto": texto,
        "tipo_via": tipo,
        "via": via,
        "gen": gen,
        "puerta": puerta,
        "lat": lat,
        "lon": lon,
        "reports": reports,
        "orden": orden,
    }


def _mock(pid, pin, scenario, addrs):
    return {"id": pid, "pin": pin, "scenario": scenario, "addrs": addrs}


MOCKS = [
    # Legacy QA (solo inserta si no existe)
    _mock(
        930001,
        1930001,
        "MOCK_TC_R3_01",
        [
            _addr(930001001, 930001001, 930001101, "MZ 10 20 30", "MZ", "10", "20", "30", 4.6097, -74.0817, [(930011, date(2025, 5, 1))], 1),
            _addr(930001002, 930001001, 930001102, "MZ 10 22 30", "MZ", "10", "22", "30", 4.6098, -74.0818, [(930012, date(2025, 5, 1))], 2),
        ],
    ),
    _mock(
        930008,
        1930008,
        "MOCK_TC_R3_08",
        [
            _addr(930008001, 930008001, 930008101, "CL 205 12 33 N", "CL", "205", "12", "33", 4.61, -74.082, [(930081, date(2025, 5, 1)), (930082, date(2025, 5, 2))], 1),
            _addr(930008002, 930008002, 930008102, "CL 205 12 35 N", "CL", "205", "12", "35", 4.6101, -74.0821, [(930083, date(2025, 5, 1)), (930084, date(2025, 5, 2)), (930085, date(2025, 5, 3))], 2),
        ],
    ),
    _mock(
        930010,
        1930010,
        "MOCK_TC_R3_10",
        [
            _addr(930010001, 930010001, 930010101, "TV 207 20 40", "TV", "207", "20", "40", 4.62, -74.09, [(930101, date(2025, 5, 1)), (930102, date(2025, 5, 2)), (930103, date(2025, 5, 3))], 1),
            _addr(930010002, 930010002, 930010102, "TV 207 22 40", "TV", "207", "22", "40", 4.6201, -74.0901, [(930104, date(2025, 5, 1)), (930105, date(2025, 5, 2)), (930106, date(2025, 5, 3))], 2),
        ],
    ),
]

# Nuevos mocks en rango 9310xx (sin colisión con QA legacy 930005/930009)
_NEW = [
    ("MOCK_TC_R3_02", "CL", "34", [("78", "52"), ("80", "52")], True, [(2, 2), (5, 2)]),
    ("MOCK_TC_R3_03", "KR", "15", [("45", "33"), ("45", "35")], False, [(2, date(2024, 1, 15)), (2, date(2025, 8, 10))]),
    ("MOCK_TC_R3_04", "TV", "60", [("20", "44"), ("22", "44")], True, [(2, 2), (4, 2)]),
    ("MOCK_TC_R3_05", "DG", "90", [("10", "50"), ("10", "55")], False, [(2, 2), (2, 2)]),
    ("MOCK_TC_R3_06", "RURAL", "5", [("10", "20"), ("12", "20")], True, [(1, 1), (1, 1)]),
    ("MOCK_TC_R3_07", "CL", "50", [("25", "52B"), ("25", "54")], True, [(1, 1), (1, 1)]),
    ("MOCK_TC_R3_09", "CL", "70", [("30", "40"), ("30", "42")], "mixed", [(1, 1), (2, 0)]),
    ("MOCK_TC_R3_11", "CL", "120", [("55", "18"), ("57", "18")], True, [(1, 1), (3, 1)]),
    ("MOCK_TC_R3_12", "CL", "88", [("15", "10"), ("15", "12")], True, [(1, 1), (3, 1)]),
    ("MOCK_TC_R3_13", "CL", "99", [("20", "10"), ("20", "11")], True, [(2, 2), (2, 2)]),
]

_PIDS = [931002, 931003, 931004, 931005, 931006, 931007, 931009, 931011, 931012, 931013]

for pid, (scenario, tipo, via, gens, geo, reps) in zip(_PIDS, _NEW):
    pin = 1930000 + (pid - 930000)
    rpu1, rpu2 = pid * 1000 + 1, pid * 1000 + 2
    df1, df2 = pid * 1000 + 101, pid * 1000 + 102
    ub1, ub2 = pid * 1000 + 1, pid * 1000 + 2
    (g1, p1), (g2, p2) = gens
    t1 = f"{tipo} {via} {g1} {p1} MOCK {scenario}"
    t2 = f"{tipo} {via} {g2} {p2} MOCK {scenario}"
    if geo is True:
        lat1, lat2 = 4.61, 4.6101
    elif geo is False:
        lat1, lat2 = None, None
    else:  # mixed: solo addr1 geo
        lat1, lat2 = 4.615, None

    def _reports(rpu, spec):
        n, extra = spec
        out = []
        for i in range(n):
            sub = pid * 10 + rpu % 10 + i
            if isinstance(extra, date):
                out.append((sub, extra))
            else:
                out.append((sub, date(2025, 5, 1 + i)))
        return out

    addrs = [
        _addr(rpu1, ub1, df1, t1, tipo, via, g1, p1, lat1, -74.08 if lat1 else None, _reports(rpu1, reps[0]), 1),
        _addr(rpu2, ub2, df2, t2, tipo, via, g2, p2, lat2, -74.081 if lat2 else None, _reports(rpu2, reps[1]), 2),
    ]
    MOCKS.append(_mock(pid, pin, scenario, addrs))

# expect_unif, hijo, padre
EXPECT = {
    930001: (0, None, None),
    930008: (1, 930008001, 930008002),
    930010: (0, None, None),
    931002: (1, 931002001, 931002002),
    931003: (1, 931003001, 931003002),
    931004: (1, 931004001, 931004002),
    931005: (0, None, None),
    931006: (0, None, None),
    931007: (0, None, None),
    931009: (1, 931009002, 931009001),
    931011: (1, 931011001, 931011002),
    931012: (1, 931012001, 931012002),
    931013: (0, None, None),
}

ALL_PIDS = list(EXPECT.keys())


def load_one(cur, m):
    pid = m["id"]
    cur.execute(
        "SELECT COUNT(*) FROM bdm_stage.relacion_persona_ubicacion WHERE id_buro_persona=%s",
        (pid,),
    )
    if cur.fetchone()[0] > 0:
        return "exists"

    ubics = {a["ubic"] for a in m["addrs"]}
    for ubic in ubics:
        a = next(x for x in m["addrs"] if x["ubic"] == ubic)
        cur.execute(
            """
            INSERT INTO bdm_stage.ubicacion_estandarizada
              (cod_dw_ubic, texto_ubicacion, cod_dw_ciudad, latitud, longitud)
            VALUES (%s, %s, 1, %s, %s)
            """,
            (ubic, a["texto"], a["lat"], a["lon"]),
        )

    for a in m["addrs"]:
        cur.execute(
            """
            INSERT INTO bdm_stage.direccion_fisica
              (cod_dw_direccion_fisica, complemento, cod_dw_ubic, tipo_via_principal,
               via_principal, via_generadora, numero_puerta, generada_enriquecida)
            VALUES (%s, '', %s, %s, %s, %s, %s, CAST(NULL AS INTEGER))
            """,
            (a["df"], a["ubic"], a["tipo_via"], a["via"], a["gen"], a["puerta"]),
        )

    cur.execute(
        "INSERT INTO bdm_stage.ciiu_persona (id_buro_persona, cod_act_econo_ciiu_fte) VALUES (%s, '10')",
        (pid,),
    )

    for a in m["addrs"]:
        cur.execute(
            """
            INSERT INTO bdm_stage.relacion_persona_ubicacion
              (cod_dw_persona_ubic, id_buro_persona, cod_pin_persona, cod_dw_ubic,
               cod_dw_direccion_fisica, cod_dw_tipo_ubicacion_dir, ind_unificacion,
               orden_prioridad, fecha_relacion_persona_ubicaci, lote, cod_tipo_ident_fte)
            VALUES (%s, %s, %s, %s, %s, %s, NULL, %s, DATE '2025-06-01', 99, 1)
            """,
            (a["rpu"], pid, m["pin"], a["ubic"], a["df"], 1, a["orden"]),
        )
        for sub, f in a["reports"]:
            cur.execute(
                """
                INSERT INTO bdm_stage.reporte_relacion_persona_ubica
                  (cod_dw_persona_ubic, id_buro_suscriptor, fecha_reporte, lote)
                VALUES (%s, %s, %s, 99)
                """,
                (a["rpu"], sub, f),
            )

    cur.execute("DELETE FROM bdm_stage.perf_persona_meta WHERE id_buro_persona=%s", (pid,))
    cur.execute(
        "INSERT INTO bdm_stage.perf_persona_meta (id_buro_persona, persona_seq, scenario_code) VALUES (%s, %s, %s)",
        (pid, pid, m["scenario"]),
    )
    return "inserted"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--only", help="Comma-separated id_buro_persona list")
    args = parser.parse_args()

    if not PASSWORD:
        print("Set REDSHIFT_PASSWORD")
        sys.exit(1)

    only = {int(x.strip()) for x in args.only.split(",")} if args.only else None

    conn = psycopg2.connect(
        host=HOST, port=5440, dbname="dba_batch", user=USER,
        password=PASSWORD, sslmode="require",
    )
    conn.autocommit = True
    cur = conn.cursor()
    out = {}
    for m in MOCKS:
        if only and m["id"] not in only:
            continue
        try:
            out[m["id"]] = load_one(cur, m)
        except Exception as e:
            out[m["id"]] = f"error: {e}"
    print(json.dumps(out, indent=2))
    cur.close()
    conn.close()


if __name__ == "__main__":
    main()
