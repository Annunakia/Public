"""Insert single mock persona: 1st address RES, 2nd address LAB (same door, CIIU 10)."""
import json
import os

import psycopg2

HOST = os.environ.get(
    "REDSHIFT_HOST",
    "eec-aws-us-eits-procesosbatch-qa-redshift.cwefyckvccgy.us-east-1.redshift.amazonaws.com",
)
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PASSWORD = os.environ.get("REDSHIFT_PASSWORD", "")

# Mock persona outside benchmark range 100001-120000
ID_BURO_PERSONA = 888001
COD_PIN_PERSONA = 1888001
COD_DW_UBIC = ID_BURO_PERSONA * 1000 + 1          # 888001001
COD_DF_RES = ID_BURO_PERSONA * 1000 + 101         # 888001101
COD_DF_LAB = ID_BURO_PERSONA * 1000 + 102         # 888001102
RPU_RES = ID_BURO_PERSONA * 1000 + 1              # 888001001
RPU_LAB = ID_BURO_PERSONA * 1000 + 2              # 888001002


def main():
    conn = psycopg2.connect(
        host=HOST, port=5440, dbname="dba_batch", user=USER, password=PASSWORD,
        connect_timeout=45, sslmode="require",
    )
    conn.autocommit = False
    cur = conn.cursor()

    cur.execute(
        "SELECT COUNT(*) FROM bdm_stage.relacion_persona_ubicacion WHERE id_buro_persona = %s",
        (ID_BURO_PERSONA,),
    )
    if cur.fetchone()[0] > 0:
        conn.rollback()
        print(json.dumps({"status": "exists", "id_buro_persona": ID_BURO_PERSONA}, indent=2))
        return

    sql_batch = [
        (
            """
            INSERT INTO bdm_stage.ubicacion_estandarizada
              (cod_dw_ubic, texto_ubicacion, cod_dw_ciudad, latitud, longitud)
            VALUES (%s, %s, 1, NULL, NULL)
            """,
            (COD_DW_UBIC, "CL 45 12 33 MOCK QA RES-LAB"),
        ),
        (
            """
            INSERT INTO bdm_stage.direccion_fisica
              (cod_dw_direccion_fisica, complemento, cod_dw_ubic, tipo_via_principal,
               via_principal, via_generadora, numero_puerta, generada_enriquecida)
            VALUES
              (%s, '', %s, 'CL', '45', '12', '33', NULL),
              (%s, '', %s, 'CL', '45', '12', '33', NULL)
            """,
            (COD_DF_RES, COD_DW_UBIC, COD_DF_LAB, COD_DW_UBIC),
        ),
        (
            """
            INSERT INTO bdm_stage.ciiu_persona (id_buro_persona, cod_act_econo_ciiu_fte)
            VALUES (%s, '10')
            """,
            (ID_BURO_PERSONA,),
        ),
        (
            """
            INSERT INTO bdm_stage.relacion_persona_ubicacion
              (cod_dw_persona_ubic, id_buro_persona, cod_pin_persona, cod_dw_ubic,
               cod_dw_direccion_fisica, cod_dw_tipo_ubicacion_dir, ind_unificacion,
               orden_prioridad, fecha_relacion_persona_ubicaci, lote, cod_tipo_ident_fte)
            VALUES
              (%s, %s, %s, %s, %s, 1, NULL, 1, DATE '2025-06-01', 99, 1),
              (%s, %s, %s, %s, %s, 2, NULL, 2, DATE '2025-06-01', 99, 1)
            """,
            (
                RPU_RES, ID_BURO_PERSONA, COD_PIN_PERSONA, COD_DW_UBIC, COD_DF_RES,
                RPU_LAB, ID_BURO_PERSONA, COD_PIN_PERSONA, COD_DW_UBIC, COD_DF_LAB,
            ),
        ),
        (
            """
            INSERT INTO bdm_stage.reporte_relacion_persona_ubica
              (cod_dw_persona_ubic, id_buro_suscriptor, fecha_reporte, lote)
            VALUES
              (%s, 901, DATE '2025-05-01', 99),
              (%s, 902, DATE '2025-05-01', 99),
              (%s, 903, DATE '2025-05-01', 99),
              (%s, 904, DATE '2025-05-01', 99),
              (%s, 905, DATE '2025-05-01', 99)
            """,
            (RPU_RES, RPU_LAB, RPU_LAB, RPU_LAB, RPU_LAB),
        ),
    ]

    for sql, params in sql_batch:
        cur.execute(sql, params)

    conn.commit()

    cur.execute(
        """
        SELECT r.cod_dw_persona_ubic, t.descripcion_tipo_ubicacion_dir AS tipo,
               r.cod_dw_direccion_fisica, u.texto_ubicacion
        FROM bdm_stage.relacion_persona_ubicacion r
        JOIN bdm_stage.tipo_ubicacion_dir t ON t.cod_dw_tipo_ubicacion_dir = r.cod_dw_tipo_ubicacion_dir
        JOIN bdm_stage.ubicacion_estandarizada u ON u.cod_dw_ubic = r.cod_dw_ubic
        WHERE r.id_buro_persona = %s
        ORDER BY r.orden_prioridad
        """,
        (ID_BURO_PERSONA,),
    )
    rows = [
        {"rpu": r[0], "tipo": r[1], "direccion_fisica": r[2], "texto_ubicacion": r[3]}
        for r in cur.fetchall()
    ]

    out = {
        "status": "inserted",
        "id_buro_persona": ID_BURO_PERSONA,
        "cod_pin_persona": COD_PIN_PERSONA,
        "cod_dw_ubic": COD_DW_UBIC,
        "ciiu": "10",
        "direcciones": rows,
        "nota": "1ra RES (RPU 888001001), 2da LAB (RPU 888001002). LAB tiene mas entidades reportantes (4 vs 1).",
    }
    print(json.dumps(out, indent=2))
    cur.close()
    conn.close()


if __name__ == "__main__":
    main()
