"""Diagnose why QA might see FAIL on TC-R3-01/08/10 vs our R3-only validation."""
import json, os, psycopg2
from psycopg2.extras import RealDictCursor

h = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
c = psycopg2.connect(host=h, port=5440, dbname="dba_batch", user="c32525e",
                     password=os.environ["REDSHIFT_PASSWORD"], sslmode="require")
v = c.cursor(cursor_factory=RealDictCursor)

def q(sql, params=None):
    v.execute(sql, params)
    return [dict(r) for r in v.fetchall()]

PIDS = (930001, 930008, 930010)
report = {}

# 1) Raw address data (QA screenshot shows lat 4.7 for 930001 — check actual)
report["direcciones"] = q("""
SELECT r.id_buro_persona, r.cod_dw_persona_ubic, r.ind_unificacion,
       u.texto_ubicacion, u.latitud, u.longitud,
       df.tipo_via_principal, df.via_generadora, df.numero_puerta
FROM bdm_stage.relacion_persona_ubicacion r
JOIN bdm_stage.ubicacion_estandarizada u ON u.cod_dw_ubic = r.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
WHERE r.id_buro_persona IN %s
ORDER BY 1, 2
""", (PIDS,))

# 2) ALL unificacion traces by rule (common QA mistake: no filter)
report["trazas_por_regla"] = q("""
SELECT r.id_buro_persona, u.unifica_atributos,
       u.cod_dw_persona_ubic AS hijo, u.cod_dw_direccion_unificada AS padre
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
WHERE r.id_buro_persona IN %s
ORDER BY 1, 2, 3
""", (PIDS,))

# 3) R3-only counts (correct validation)
report["r3_only"] = q("""
SELECT r.id_buro_persona,
       SUM(CASE WHEN u.unifica_atributos=3 THEN 1 ELSE 0 END) AS unif_r3,
       SUM(CASE WHEN u.unifica_atributos=1 THEN 1 ELSE 0 END) AS unif_r1,
       SUM(CASE WHEN u.unifica_atributos=2 THEN 1 ELSE 0 END) AS unif_r2
FROM bdm_stage.relacion_persona_ubicacion r
LEFT JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic
WHERE r.id_buro_persona IN %s
GROUP BY 1 ORDER BY 1
""", (PIDS,))

# 4) Cross traces ALL rules vs R3 only (930010)
report["cruces_930010"] = q("""
SELECT 'all_rules' AS scope, COUNT(*) AS n
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r1 ON r1.cod_dw_persona_ubic = u.cod_dw_persona_ubic
JOIN bdm_stage.unificacion_direccion u2
  ON u2.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
 AND u2.cod_dw_direccion_unificada = u.cod_dw_persona_ubic
WHERE r1.id_buro_persona = 930010
UNION ALL
SELECT 'r3_only', COUNT(*)
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r1 ON r1.cod_dw_persona_ubic = u.cod_dw_persona_ubic
JOIN bdm_stage.unificacion_direccion u2
  ON u2.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
 AND u2.cod_dw_direccion_unificada = u.cod_dw_persona_ubic
WHERE r1.id_buro_persona = 930010 AND u.unifica_atributos=3 AND u2.unifica_atributos=3
""")

# 5) SP definition check — does it have MZ exclusion?
v.execute("""
SELECT CASE WHEN prosrc ILIKE '%tipo_via_principal%' AND prosrc ILIKE '%MZ%' THEN 1 ELSE 0 END AS has_mz_filter,
       CASE WHEN prosrc ILIKE '%N%' AND prosrc ILIKE '%cuadrante%' THEN 1 ELSE 0 END AS has_cuadrante_logic,
       CASE WHEN prosrc ILIKE '%score%' AND prosrc ILIKE '%<%' THEN 1 ELSE 0 END AS has_strict_score
FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
WHERE n.nspname='bdm_stage' AND p.proname='sp_unificacion_regla3'
""")
report["sp_deployed"] = dict(v.fetchone() or {})

# 6) Simulate WRONG validation (no unifica_atributos filter) — what QA might use
report["wrong_validation"] = {
    "TC-R3-01": q("SELECT COUNT(*) n FROM bdm_stage.unificacion_direccion u JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic=u.cod_dw_persona_ubic WHERE r.id_buro_persona=930001")[0]["n"],
    "TC-R3-08": q("SELECT COUNT(*) n FROM bdm_stage.unificacion_direccion u JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic=u.cod_dw_persona_ubic WHERE r.id_buro_persona=930008")[0]["n"],
    "TC-R3-10": q("""
        SELECT COUNT(*) n FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion r1 ON r1.cod_dw_persona_ubic=u.cod_dw_persona_ubic
        JOIN bdm_stage.unificacion_direccion u2
          ON u2.cod_dw_persona_ubic=u.cod_dw_direccion_unificada AND u2.cod_dw_direccion_unificada=u.cod_dw_persona_ubic
        WHERE r1.id_buro_persona=930010
    """)[0]["n"],
}

print(json.dumps(report, indent=2, default=str))
c.close()
