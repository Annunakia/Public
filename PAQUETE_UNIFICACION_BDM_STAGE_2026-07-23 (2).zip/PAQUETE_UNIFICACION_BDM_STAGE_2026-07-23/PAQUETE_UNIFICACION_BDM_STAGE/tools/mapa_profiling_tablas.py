"""Tablas de perfilado profesional — tablas/columnas exactas, conteos DEV."""
from __future__ import annotations

from export_mapa_unificacion_xlsx import (  # noqa: E402
    ct_map,
    first_row_list,
    prof_comp_counts,
    prof_contacttype_counts,
    prof_geo_con,
    prof_sin_ciudad,
    prof_sin_ciiu,
    prof_sin_score,
    prof_status_map,
    prof_texto_vacio,
)

COL_VISTA = "Vista / tabla en BDM"
COL_CAMPO = "Columna perfilada"
COL_ORIGEN = "Campo origen (edf_views)"
COL_ESTADO = "Estado del dato"
COL_RPUS = "Reportes (RPUs)"
COL_PCT = "% del universo"
COL_IMPACTO = "Impacto en unificación"
COL_TABLA = "Objeto"
COL_DETALLE = "Detalle en DEV"


def _n(n: int | float | None) -> str:
    if n is None:
        return "—"
    return f"{int(n):,}".replace(",", ".")


def _pct(n: int, total: int) -> str:
    if total <= 0:
        return "0,0 %"
    return f"{100 * n / total:.1f} %".replace(".", ",")


def _rpus(samples: dict) -> int:
    u = first_row_list(samples, "univ")
    return int(u.get("rpus", 591166))


def _dist_rows(total: int, buckets: list[tuple[str, int]]) -> list[list[str]]:
    rows = []
    for estado, n in buckets:
        rows.append([estado, _n(n), _pct(n, total), ""])
    return rows


# Metadatos por escenario de perfil
PROF_META: dict[str, dict] = {
    "Complemento": {
        "codigo": "PROF-COMP",
        "titulo": "v_xpm_direccion_fisica.complemento",
        "vista": "bdm_tempo.v_xpm_direccion_fisica",
        "columna": "complemento",
        "origen": "xpm_location_val_contactinformations.standardizedcomplemento",
        "tablas_edf": "ds_dba_rncr_batch.edf_views.xpm → xpm_location → xpm_location_val_contactinformations",
        "impacto": "Regla 2 ESC1: padre con apto/oficina absorbe hija sin detalle",
    },
    "Texto": {
        "codigo": "PROF-TEXTO",
        "titulo": "v_xpm_ubicacion_estandarizada.texto_ubicacion",
        "vista": "bdm_tempo.v_xpm_ubicacion_estandarizada",
        "columna": "texto_ubicacion",
        "origen": "standardizedtextoubicacion · contactasreportedstandardized · contactasreported",
        "tablas_edf": "v_xpm_contacto_direccion (derivada de edf_views.xpm_location_val_contactinformations)",
        "impacto": "Reglas R1/R2/R3: agrupación por misma calle escrita",
    },
    "Geo": {
        "codigo": "PROF-GEO",
        "titulo": "v_xpm_ubicacion_estandarizada.latitud / longitud",
        "vista": "bdm_tempo.v_xpm_ubicacion_estandarizada",
        "columna": "latitud, longitud",
        "origen": "Forzadas a CAST(NULL) en 00_vistas_insumo_bdm.sql (DEV)",
        "tablas_edf": "No mapeadas desde edf_views en esta corrida DEV",
        "impacto": "Regla 3 bloqueada — 0 coordenadas utilizables",
    },
    "CIIU": {
        "codigo": "PROF-CIIU",
        "titulo": "v_xpm_ciiu_persona.cod_act_econo_ciiu_fte",
        "vista": "bdm_tempo.v_xpm_ciiu_persona",
        "columna": "cod_act_econo_ciiu_fte",
        "origen": "edf_views.xpm.bestpersonalinformation.mainisiccodeforproduct",
        "tablas_edf": "ds_dba_rncr_batch.edf_views.xpm (LEFT JOIN por id_buro_persona)",
        "impacto": "Regla 1: sin CIIU solo aplica ESC3 (conteo de entidades); ESC1/ESC2 no aplican",
    },
    "Puntaje": {
        "codigo": "PROF-SCORE",
        "titulo": "v_xpm_contacto_direccion.score_estandarizacion",
        "vista": "bdm_tempo.v_xpm_contacto_direccion",
        "columna": "score_estandarizacion",
        "origen": "xpm_location_val_contactinformations.contactasstandardizedscore",
        "tablas_edf": "ds_dba_rncr_batch.edf_views.xpm_location_val_contactinformations",
        "impacto": "Calidad de estandarización; no bloquea R1/R2/R3 hoy",
    },
    "DANE": {
        "codigo": "PROF-DANE",
        "titulo": "v_xpm_ubicacion_estandarizada.cod_dw_ciudad",
        "vista": "bdm_tempo.v_xpm_ubicacion_estandarizada",
        "columna": "cod_dw_ciudad",
        "origen": "standardizeddanecode · cityname (hash si no hay código DANE)",
        "tablas_edf": "xpm_location_val_contactinformations",
        "impacto": "Regla 1: grupo persona + calle + ciudad — sin ciudad el grupo se fragmenta",
    },
    "Tipo contacto": {
        "codigo": "PROF-CT",
        "titulo": "edf_views contacttype → cod_dw_tipo_ubicacion_dir",
        "vista": "bdm_tempo.v_xpm_contacto_direccion",
        "columna": "cod_dw_tipo_ubicacion_dir (mapeo desde contacttype)",
        "origen": "xpm_location_val_contactinformations.contacttype (1/2/3/7/8)",
        "tablas_edf": "ds_dba_rncr_batch.edf_views.xpm + xpm_location + xpm_location_val_contactinformations",
        "impacto": "Tipo 8 → correspondencia (CRR); domina volumen R2 en DEV",
    },
}


def _cadena_table(meta: dict) -> dict:
    return {
        "title": "Cadena de datos — de edf_views a la vista BDM",
        "headers": [COL_TABLA, COL_CAMPO, COL_DETALLE],
        "rows": [
            ["Vista consumida por reglas", meta["vista"], meta["columna"]],
            ["Tablas edf_views (origen)", meta["tablas_edf"], meta["origen"]],
            ["Regla afectada", "—", meta["impacto"]],
        ],
    }


def _tabla_distribucion(title: str, headers: list[str], rows: list[list[str]]) -> dict:
    return {"title": title, "headers": headers, "rows": rows}


def pack_for_prof(escenario: str, samples: dict) -> dict | None:
    rpus = _rpus(samples)
    ct = ct_map(samples)

    if escenario == "Propósito":
        comp_null, comp_vacio, comp_valor = prof_comp_counts(samples)
        geo_con = prof_geo_con(samples, rpus)
        sin_ciiu = prof_sin_ciiu(samples, rpus)
        sin_score = prof_sin_score(samples, rpus)
        sin_ciudad = prof_sin_ciudad(samples, rpus)
        texto_vacio = prof_texto_vacio(samples)
        ct8, ct_otros, ct_invalid = prof_contacttype_counts(samples, rpus, ct)
        rows = [
            [m["vista"], m["columna"], _n(
                {
                    "Complemento": comp_null + comp_vacio,
                    "Texto": texto_vacio,
                    "Geo": rpus - geo_con,
                    "CIIU": sin_ciiu,
                    "Puntaje": sin_score,
                    "DANE": sin_ciudad,
                    "Tipo contacto": ct_invalid,
                }.get(name, 0)
            ), m["impacto"]]
            for name, m in PROF_META.items()
        ]
        return {
            "ejemplo": {
                "title": "Panorama de calidad — columnas críticas del insumo",
                "headers": [COL_VISTA, COL_CAMPO, "RPUs con alerta", COL_IMPACTO],
                "rows": rows,
            },
            "ejemplo_pasos": {
                "title": "Universo perfilado",
                "headers": ["Métrica", "Valor DEV"],
                "rows": [
                    ["Reportes de dirección (RPUs)", _n(rpus)],
                    ["Personas distintas", _n(first_row_list(samples, "univ").get("personas", 407351))],
                    ["Fuente", "bdm_tempo.v_xpm_* ← ds_dba_rncr_batch.edf_views"],
                    ["Script perfil", "sql/dev_edf_datasharing/00_perfil_calidad_insumo.sql"],
                ],
            },
            "conclusion": (
                f"Perfil de { _n(rpus) } RPUs en vistas bdm_tempo. "
                f"Geo sin coordenadas bloquea R3; contacttype 8 ({_n(ct8)}) domina R2; "
                f"complemento NULL/vacío es patrón esperado en hijas R2."
            ),
        }

    if escenario == "Vista":
        return {
            "ejemplo": {
                "title": "Deuda técnica en 00_vistas_insumo_bdm.sql",
                "headers": [COL_VISTA, COL_CAMPO, "Valor forzado en DEV", COL_IMPACTO],
                "rows": [
                    ["bdm_tempo.v_xpm_contacto_direccion", "latitud, longitud", "CAST(NULL)", "R3 no ejecutable"],
                    ["bdm_tempo.v_xpm_contacto_direccion", "relationalizelastupdate", "CAST(NULL)", "Sin filtro temporal en JOIN"],
                    ["bdm_tempo.v_xpm_relacion_persona_ubicacion", "ind_unificacion", "CAST(NULL)", "No marca ganadores previos"],
                    ["bdm_tempo.v_xpm_relacion_persona_ubicacion", "lote", "CAST(NULL)", "Sin trazabilidad de lote"],
                ],
            },
            "conclusion": (
                "Columnas forzadas a NULL en la vista de insumo DEV. "
                "Revisar antes de promover a QA — especialmente geo para R3."
            ),
        }

    meta = PROF_META.get(escenario)
    if not meta:
        return None

    dist_headers = [COL_ESTADO, COL_RPUS, COL_PCT, "Notas"]
    dist_rows: list[list[str]] = []
    con_ok = ""

    if escenario == "Complemento":
        comp_null, comp_vacio, comp_valor = prof_comp_counts(samples)
        dist_rows = [
            ["NULL", _n(comp_null), _pct(comp_null, rpus), "Sin complemento en origen"],
            ["VACÍO (trim = '')", _n(comp_vacio), _pct(comp_vacio, rpus), "Campo presente pero vacío"],
            ["CON VALOR (apto, local…)", _n(comp_valor), _pct(comp_valor, rpus), "Patrón típico del reporte padre R2"],
        ]
        con_ok = (
            f"NULL {_n(comp_null)} ({_pct(comp_null, rpus)}) · "
            f"vacío {_n(comp_vacio)} · con valor {_n(comp_valor)} sobre {_n(rpus)} RPUs."
        )
    elif escenario == "Texto":
        vacio = prof_texto_vacio(samples)
        ok = rpus - vacio
        dist_rows = [
            ["OK (texto informado)", _n(ok), _pct(ok, rpus), "Permite agrupar por calle"],
            ["VACÍO o NULL", _n(vacio), _pct(vacio, rpus), "No entra a agrupación R1/R2/R3"],
        ]
        con_ok = f"Texto vacío: {_n(vacio)} RPUs ({_pct(vacio, rpus)})."
    elif escenario == "Geo":
        row = first_row_list(samples, "prof_geo")
        con = int(row.get("con_geo", 0))
        sin = int(row.get("sin_geo", rpus - con))
        total = int(row.get("total", rpus))
        dist_rows = [
            ["Con latitud Y longitud", _n(con), _pct(con, total), "Requisito mínimo R3"],
            ["Sin coordenadas", _n(sin), _pct(sin, total), "Vista DEV fuerza NULL — R3 = 0"],
        ]
        con_ok = f"Coordenadas utilizables: {_n(con)} de {_n(total)} ({_pct(con, total)})."
    elif escenario == "CIIU":
        row = first_row_list(samples, "prof_ciiu")
        sin = int(row.get("sin_ciiu", prof_sin_ciiu(samples, rpus)))
        total = int(row.get("total", rpus))
        con = total - sin
        dist_rows = [
            ["CON CIIU (persona con actividad)", _n(con), _pct(con, total), "Puede activar ESC1/ESC2 en R1"],
            ["SIN CIIU (NULL o vacío)", _n(sin), _pct(sin, total), "Solo ESC3 — conteo de entidades"],
        ]
        con_ok = (
            f"Sin CIIU: {_n(sin)} RPUs ({_pct(sin, total)}). "
            f"Origen vacío: xpm.mainisiccodeforproduct."
        )
    elif escenario == "Puntaje":
        row = first_row_list(samples, "prof_score")
        sin = int(row.get("sin_score", prof_sin_score(samples, rpus)))
        total = int(row.get("total", rpus))
        con = total - sin
        dist_rows = [
            ["Score informado", _n(con), _pct(con, total), "Estandarización OK en origen"],
            ["NULL o no numérico", _n(sin), _pct(sin, total), "contactasstandardizedscore inválido"],
        ]
        con_ok = f"Sin score: {_n(sin)} ({_pct(sin, total)})."
    elif escenario == "DANE":
        row = first_row_list(samples, "prof_dane")
        sin = int(row.get("sin_ciudad", prof_sin_ciudad(samples, rpus)))
        total = int(row.get("total", rpus))
        con = total - sin
        dist_rows = [
            ["cod_dw_ciudad informado", _n(con), _pct(con, total), "Ciudad/DANE en grupo R1"],
            ["cod_dw_ciudad NULL", _n(sin), _pct(sin, total), "Riesgo de fragmentar grupos R1"],
        ]
        con_ok = f"Sin ciudad DANE: {_n(sin)} ({_pct(sin, total)})."
    elif escenario == "Tipo contacto":
        ct8, ct_otros, ct_invalid = prof_contacttype_counts(samples, rpus, ct)
        prof_ct = prof_status_map(samples, "prof_ct", "estado_ct")
        dist_rows = [
            ["Catálogo válido (1/2/3/7/8)", _n(prof_ct.get("CATALOGO", ct8 + ct_otros)), _pct(prof_ct.get("CATALOGO", ct8 + ct_otros), rpus), "Tipos mapeados en vista"],
            ["Fuera de catálogo", _n(prof_ct.get("FUERA_CATALOGO", 0)), _pct(prof_ct.get("FUERA_CATALOGO", 0), rpus), "contacttype no reconocido"],
            ["NULL", _n(prof_ct.get("NULL", 0)), _pct(prof_ct.get("NULL", 0), rpus), "Sin contacttype"],
        ]
        dist_rows.append(["Tipo 8 (token → CRR)", _n(ct8), _pct(ct8, rpus), "Principal insumo R2"])
        dist_rows.append(["Tipos 1/2/3/7 nativos", _n(ct_otros), _pct(ct_otros, rpus), "Regla 1 — casa/trabajo/corr."])
        con_ok = f"Token tipo 8: {_n(ct8)} ({_pct(ct8, rpus)}); fuera catálogo: {_n(ct_invalid)}."

    return {
        "ejemplo": _tabla_distribucion(
            f"Distribución de calidad — {meta['titulo']}",
            dist_headers,
            dist_rows,
        ),
        "ejemplo_pasos": _cadena_table(meta),
        "conclusion": con_ok or meta["impacto"],
        "busca": meta["impacto"],
    }


def prof_codigo(escenario: str) -> str:
    if escenario == "Propósito":
        return "RESUMEN"
    if escenario == "Vista":
        return "REVISAR"
    return PROF_META.get(escenario, {}).get("codigo", escenario)


def prof_titulo_nav(escenario: str) -> str:
    if escenario == "Propósito":
        return "RESUMEN · Panorama calidad"
    if escenario == "Vista":
        return "REVISAR · 00_vistas_insumo_bdm.sql"
    meta = PROF_META.get(escenario)
    if meta:
        return meta["titulo"]
    return escenario
