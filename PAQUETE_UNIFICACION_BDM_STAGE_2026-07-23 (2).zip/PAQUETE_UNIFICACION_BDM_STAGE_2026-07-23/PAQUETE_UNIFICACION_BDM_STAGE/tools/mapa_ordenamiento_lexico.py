"""Contenido de negocio — mapa interactivo Ordenamiento DEV."""
from __future__ import annotations

import json
import re
from pathlib import Path

from mapa_ordenamiento_escenarios import esc_codigo, pack_escenario

ROOT = Path(__file__).resolve().parents[1]
EVIDENCIAS = ROOT / "Documentacion" / "Evidencias_DEV_ORDENAMIENTO_EDF_COMPLETO.md"

HEADERS = [
    "Regla",
    "Escenario",
    "Subescenario",
    "Qué espera (negocio)",
    "Qué encontramos DEV",
    "Estado",
    "Ejemplo verificable (reporte + ID + query)",
    "Query validación (copiar en dba_rncr_batch)",
    "Acción / revisión",
]

DEFAULT_KPIS = {
    "personas": 407351,
    "rpu_ganadoras": 518718,
    "rpu_hijas": 72448,
    "rpu_con_orden": 408624,
    "betas": 47,
    "total_scores": 1223998,
    "preparar_seg": 78.1,
    "scoring_seg": 20.0,
    "canales": {
        "DIR": {"scores": 409014, "personas": 407351, "min": 0.6113, "max": 0.843, "insumo": 1055905},
        "TEL": {"scores": 407320, "personas": 407320, "min": 0.2675, "max": 0.635, "insumo": 627934},
        "CEL": {"scores": 258, "personas": 115, "min": 0.49, "max": 0.7325, "insumo": 17240},
        "EMA": {"scores": 407406, "personas": 407207, "min": 0.26, "max": 0.525, "insumo": 605998},
    },
}


def _parse_evidence_md() -> dict:
    if not EVIDENCIAS.exists():
        return {}
    text = EVIDENCIAS.read_text(encoding="utf-8")
    out: dict = {}
    for block in re.findall(r"```json\n(.*?)\n```", text, re.S):
        try:
            data = json.loads(block)
        except json.JSONDecodeError:
            continue
        if isinstance(data, dict) and "preparar_seg" in data:
            out["timings"] = data
        if isinstance(data, list):
            for item in data:
                if not isinstance(item, dict):
                    continue
                rows = item.get("rows")
                if not rows:
                    continue
                if rows and rows[0].get("canal"):
                    out["scores_canal"] = {r["canal"]: r for r in rows}
                elif rows and rows[0].get("paso"):
                    out["pasos"] = {r["paso"]: int(r["total"]) for r in rows}
    return out


def load_kpis() -> dict:
    k = dict(DEFAULT_KPIS)
    ev = _parse_evidence_md()
    pasos = ev.get("pasos", {})
    if pasos:
        k["personas"] = pasos.get("personas_con_orden", k["personas"])
        k["rpu_con_orden"] = pasos.get("rpu_con_orden_prioridad", k["rpu_con_orden"])
        k["rpu_hijas"] = pasos.get("rpu_hijas_sin_orden", k["rpu_hijas"])
        k["total_scores"] = pasos.get("total_scores", k["total_scores"])
        k["rpu_ganadoras"] = pasos.get("rpu_ganadoras", k["rpu_ganadoras"])
        k["betas"] = pasos.get("beta_ordenamiento", k["betas"])
        for canal, key_p, key_i in [
            ("DIR", "personas_dir", "insumo_dir"),
            ("TEL", "personas_tel", "insumo_tel"),
            ("CEL", "personas_cel", "insumo_cel"),
            ("EMA", "personas_ema", "insumo_ema"),
        ]:
            if key_p in pasos:
                k["canales"][canal]["personas"] = pasos[key_p]
            if key_i in pasos:
                k["canales"][canal]["insumo"] = pasos[key_i]
    sc = ev.get("scores_canal", {})
    for canal, row in sc.items():
        if canal in k["canales"]:
            k["canales"][canal].update(
                {
                    "scores": row.get("scores", k["canales"][canal]["scores"]),
                    "min": row.get("min_score", k["canales"][canal]["min"]),
                    "max": row.get("max_score", k["canales"][canal]["max"]),
                }
            )
    if ev.get("timings"):
        k["preparar_seg"] = ev["timings"].get("preparar_seg", k["preparar_seg"])
        k["scoring_seg"] = ev["timings"].get("scoring_total_seg", k["scoring_seg"])
    return k


def build_volumenes(k: dict) -> dict:
    filas = [
        {
            "regla": "UNIVERSO",
            "codigo": "POST-UNIF",
            "escenario": "Ganadoras",
            "personas": k["personas"],
            "contactos": k["rpu_ganadoras"],
            "busca": "RPUs que compiten tras unificación R1/R2/R3 (ind_unificacion <> 1).",
        },
        {
            "regla": "UNIVERSO",
            "codigo": "HIJAS",
            "escenario": "Excluidas",
            "personas": 0,
            "contactos": k["rpu_hijas"],
            "busca": "Hijas de unificación: no reciben score ni orden_prioridad.",
        },
        {
            "regla": "FASE 1",
            "codigo": "INSUMO-DIR",
            "escenario": "insumo_direccion",
            "personas": k["canales"]["DIR"]["personas"],
            "contactos": k["canales"]["DIR"]["insumo"],
            "busca": "Reportes de dirección en RPUs ganadoras → base canal DIR.",
        },
        {
            "regla": "FASE 1",
            "codigo": "INSUMO-TEL",
            "escenario": "insumo_telefono",
            "personas": k["canales"]["TEL"]["personas"],
            "contactos": k["canales"]["TEL"]["insumo"],
            "busca": "Contactos XPM contactType 4, 5, 8 para personas con DIR ganadora.",
        },
        {
            "regla": "FASE 1",
            "codigo": "INSUMO-CEL",
            "escenario": "insumo_celular",
            "personas": k["canales"]["CEL"]["personas"],
            "contactos": k["canales"]["CEL"]["insumo"],
            "busca": "Celulares contactType 9. Cobertura baja en DEV edf_views.",
        },
        {
            "regla": "FASE 1",
            "codigo": "INSUMO-EMA",
            "escenario": "insumo_email",
            "personas": k["canales"]["EMA"]["personas"],
            "contactos": k["canales"]["EMA"]["insumo"],
            "busca": "Emails contactType 10 con formato válido (@).",
        },
        {
            "regla": "DIR",
            "codigo": "SCORE",
            "escenario": "score_ordenamiento",
            "personas": k["canales"]["DIR"]["personas"],
            "contactos": k["canales"]["DIR"]["scores"],
            "busca": "Un score por dirección distinta; ROW_NUMBER → lugar.",
        },
        {
            "regla": "TEL",
            "codigo": "SCORE",
            "escenario": "score_ordenamiento",
            "personas": k["canales"]["TEL"]["personas"],
            "contactos": k["canales"]["TEL"]["scores"],
            "busca": "Ranking teléfonos por persona (clave = número).",
        },
        {
            "regla": "CEL",
            "codigo": "SCORE",
            "escenario": "score_ordenamiento",
            "personas": k["canales"]["CEL"]["personas"],
            "contactos": k["canales"]["CEL"]["scores"],
            "busca": "Ranking celulares; operador desde prefijo.",
        },
        {
            "regla": "EMA",
            "codigo": "SCORE",
            "escenario": "score_ordenamiento",
            "personas": k["canales"]["EMA"]["personas"],
            "contactos": k["canales"]["EMA"]["scores"],
            "busca": "Ranking emails por dominio y recencia.",
        },
        {
            "regla": "SALIDA",
            "codigo": "CONSOL",
            "escenario": "orden_prioridad",
            "personas": k["personas"],
            "contactos": k["rpu_con_orden"],
            "busca": "UPDATE relacion_persona_ubicacion desde score DIR (canal principal).",
        },
        {
            "regla": "SALIDA",
            "codigo": "CHECK",
            "escenario": "hijas_sin_orden",
            "personas": 0,
            "contactos": k["rpu_hijas"],
            "busca": "Validación F3-02 doc v2.0: hijas sin orden_prioridad.",
        },
    ]
    for f in filas:
        p, c = f["personas"], f["contactos"]
        f["ratio"] = round(c / p, 2) if p else None
    return {"filas": filas, "universo": {"personas": k["personas"], "contactos": k["rpu_ganadoras"]}}


def _tbl(headers: list[str], rows: list[list]) -> str:
    th = "".join(f"<th>{h}</th>" for h in headers)
    body = ""
    for row in rows:
        body += "<tr>" + "".join(f"<td>{c}</td>" for c in row) + "</tr>"
    return f'<table class="scenario-table"><thead><tr>{th}</tr></thead><tbody>{body}</tbody></table>'


def _scenario_row(
    k: dict,
    regla: str,
    pack_code: str,
    sub: str,
    busca: str,
    dev: str,
    estado: str,
    *,
    conclusion: str = "",
    query: str = "",
    accion: str = "",
) -> dict:
    code = esc_codigo(regla, pack_code)
    row: dict = {
        "Regla": regla,
        "Escenario": code,
        "Subescenario": sub,
        "Qué espera (negocio)": busca,
        "Qué encontramos DEV": dev,
        "Estado": estado,
        "Ejemplo verificable (reporte + ID + query)": conclusion,
        "Query validación (copiar en dba_rncr_batch)": query,
        "Acción / revisión": accion,
        "_pack_code": pack_code,
    }
    packed = pack_escenario(regla, pack_code, k)
    row.update(packed)
    if packed.get("_conclusion") and not conclusion:
        row["Ejemplo verificable (reporte + ID + query)"] = packed["_conclusion"]
    row["_esc_codigo"] = code
    row["_titulo_corto"] = sub
    row["_busca"] = busca
    row["_dev"] = dev if not packed.get("_tabla_ejemplo") and not packed.get("_tabla_pasos") else ""
    row["_conclusion_regla"] = row.get("Ejemplo verificable (reporte + ID + query)", "")
    row["_show_query"] = bool(query)
    return row


def build_rows(k: dict) -> list[dict]:
    c = k["canales"]
    q_dir = """SELECT canal, COUNT(*) AS n, ROUND(MIN(score::FLOAT),4) AS min_s, ROUND(MAX(score::FLOAT),4) AS max_s
FROM bdm_datos.score_ordenamiento WHERE canal='DIR' GROUP BY 1;"""
    q_hijas = """SELECT COUNT(*) AS hijas_con_orden_incorrecto
FROM bdm_datos.relacion_persona_ubicacion
WHERE COALESCE(ind_unificacion,0)=1 AND orden_prioridad IS NOT NULL;"""
    q_stg = """SELECT COUNT(*) FROM bdm_tempo.stg_rpu_post_unificacion WHERE COALESCE(ind_unificacion,0)<>1;"""

    return [
        _scenario_row(
            k, "PUNTO DE PARTIDA", "RESUMEN",
            "Qué es Ordenamiento y cómo se relaciona con Unificación",
            "Después de R1/R2/R3, priorizar contactos por canal con score relativo (no probabilidad calibrada).",
            f"{k['personas']:,} personas · {k['rpu_ganadoras']:,} RPUs ganadoras compiten.",
            "OK", query=q_stg,
        ),
        _scenario_row(
            k, "PUNTO DE PARTIDA", "FLUJO",
            "Pipeline en Redshift (Opción A)",
            "edf_views → unificación previa → staging insumos → scoring 4 canales → orden_prioridad.",
            f"Preparar ~{k['preparar_seg']}s · Scoring ~{k['scoring_seg']}s · {k['total_scores']:,} scores.",
            "OK", query="CALL bdm_datos.sp_ordenamiento_ejecucion_edf(TRUE);",
        ),
        _scenario_row(
            k, "ALCANCE", "ALCANCE",
            "Alcance funcional acordado",
            "DDL/SQL/SP en Redshift; aplicar betas Experian; paridad condicional; procesos upstream fuera del SP.",
            "Documento consolidado de requerimientos en revisión; referencia: doc funcional v2.0.",
            "Pendiente",
        ),
        _scenario_row(
            k, "FASE 1", "INSUMO-CT",
            "contactType → canal (quién entra y quién no)",
            "Cada tipo XPM alimenta un canal; TEL/CEL/EMA solo si la persona tiene dirección ganadora.",
            f"DIR {c['DIR']['insumo']:,} filas · TEL {c['TEL']['insumo']:,} · CEL {c['CEL']['insumo']:,} · EMA {c['EMA']['insumo']:,}.",
            "OK",
        ),
        _scenario_row(
            k, "FASE 1", "RPU-STG",
            "Materialización RPU en staging",
            "stg_rpu_post_unificacion: lectura datashare + join unificacion_direccion; sin copia permanente.",
            f"Ganadoras {k['rpu_ganadoras']:,} · Hijas excluidas {k['rpu_hijas']:,}.",
            "OK", query=q_stg,
        ),
        _scenario_row(
            k, "FASE 1", "BETAS",
            "Parametrización de coeficientes",
            "Experian define betas; Redshift solo los aplica vía JOIN (no recalibra el modelo).",
            f"{k['betas']} betas RITM5226589 en bdm_datos.beta_ordenamiento.",
            "OK",
            query="SELECT canal, COUNT(*) FROM bdm_datos.beta_ordenamiento GROUP BY 1;",
            accion="Snapshot RITM5226589 (sesión John). Datashare IFR opcional después.",
        ),
        _scenario_row(
            k, "CANAL DIR", "DIR-RANK",
            "Ranking de direcciones (RANK-01)",
            "Varias direcciones ganadoras por persona; mayor score → lugar 1 → orden_prioridad.",
            f"{c['DIR']['scores']:,} scores · rango {c['DIR']['min']}–{c['DIR']['max']}.",
            "OK", query=q_dir,
        ),
        _scenario_row(
            k, "CANAL DIR", "ELEG-HIJA",
            "Hija de unificación excluida (F3-02)",
            "ind_unificacion=1 no recibe score ni orden; solo trazabilidad en unificacion_direccion.",
            f"0 hijas con orden incorrecto · {k['rpu_hijas']:,} hijas sin orden.",
            "OK", query=q_hijas,
        ),
        _scenario_row(
            k, "CANAL DIR", "ELEG-BLOQ",
            "Bloqueos y datos NO VÁLIDOS (F3-01 / F3-03)",
            "Registros bloqueados o inválidos no compiten; parte se filtra en upstream o en preparar insumos.",
            "Filtro hijas OK; bloqueos explícitos dependen de insumo IFR.",
            "Parcial",
        ),
        _scenario_row(
            k, "CANAL DIR", "DIR-EMPATE",
            "Empate de score (RANK-02)",
            "Dos direcciones con mismo score: no se agrega desempate funcional nuevo en migración.",
            "ROW_NUMBER preserva baseline; diferencias por empate → hallazgo de certificación.",
            "OK",
        ),
        _scenario_row(
            k, "CANAL TEL", "TEL-RANK",
            "Ranking teléfono fijo por persona",
            "Canal independiente de DIR; agrupa por número; no escribe orden_prioridad en RPU.",
            f"{c['TEL']['scores']:,} scores · {c['TEL']['personas']:,} personas.",
            "OK",
            query="SELECT COUNT(*) FROM bdm_datos.score_ordenamiento WHERE canal='TEL';",
        ),
        _scenario_row(
            k, "CANAL TEL", "TEL-02",
            "TEL020 fuera de la suma (caso TEL-02)",
            "Coincidencia geo se calcula pero no debe modificar el score final (baseline Teradata).",
            f"Corregido en 12_sp_ordenamiento_scoring_tel_edf.sql · rango {c['TEL']['min']}–{c['TEL']['max']}.",
            "OK",
        ),
        _scenario_row(
            k, "CANAL CEL", "CEL-02",
            "Operador no mapeado → 0.22 (caso CEL-02)",
            "CEL018 = 100 × COALESCE(catalogo_operador.valor, 0.22); prefijo LEFT(celular,3).",
            f"{c['CEL']['scores']:,} scores · {c['CEL']['personas']:,} personas · catalogo_operador_ord_cel OK.",
            "OK",
        ),
        _scenario_row(
            k, "CANAL EMA", "EMA-03",
            "EMA003/007/018/025 fuera de la suma (caso EMA-03)",
            "Se calculan para trazabilidad pero no deben mover el ranking final (Sumatoria_Score_Email Teradata).",
            f"Corregido · rango {c['EMA']['min']}–{c['EMA']['max']} · {c['EMA']['scores']:,} scores.",
            "OK",
        ),
        _scenario_row(
            k, "CONSOLIDACIÓN", "CONSOL",
            "Persistencia orden_prioridad",
            "Mejor lugar del canal DIR por RPU ganadora → rpu_orden_prioridad.",
            f"{k['rpu_con_orden']:,} RPUs con orden.",
            "OK",
            query="SELECT COUNT(*) FROM bdm_datos.rpu_orden_prioridad;",
        ),
        _scenario_row(
            k, "VALIDACIÓN", "VALID",
            "Matriz de pruebas mínima",
            "Checks F3-02, RANK-01, TEL-02, EMA-03, CEL-02, MIG-01 según doc v2.0.",
            "Pipeline E2E DEV OK · fórmulas corregidas 2026-09-04 · 0 hijas con orden incorrecto.",
            "OK",
            query="sql/dev_edf_ordenamiento/00_validar_fase2.sql",
        ),
        _scenario_row(
            k, "ARQUITECTURA SP", "SP-PREP",
            "SP preparar insumos — staging temporal",
            "Una lectura datashare → 11 CTAS en bdm_tempo.stg_*. Sin copia permanente de XPM.",
            "sp_ordenamiento_preparar_insumos_edf · ~78s preparar en corrida full.",
            "OK",
            query="SELECT COUNT(*) FROM bdm_tempo.stg_insumo_direccion;",
        ),
        _scenario_row(
            k, "ARQUITECTURA SP", "SP-ORQ",
            "Orquestador — 8 SPs en secuencia",
            "preparar → scoring×4 → consolidar → drop. Equivalente Control-M Opción A.",
            "sp_ordenamiento_ejecucion_edf(TRUE) · ~20s scoring DEV.",
            "OK",
            query="CALL bdm_datos.sp_ordenamiento_ejecucion_edf(TRUE);",
        ),
        _scenario_row(
            k, "REPOS", "BITBUCKET",
            "3 repos — rama feature/ordenamiento",
            "Despliegue Jenkins: _strct → _pgm → _dt. Nombres sin ticket Jira (Manuel).",
            "14 archivos SQL en deploy_bitbucket/ · merge con unificación en misma rama base.",
            "OK",
        ),
    ]


def build_alcance() -> list[dict]:
    """Alcance acordado en Mesa/Sesión Alineación (sept-2026)."""
    return [
        {
            "id": "SES-01",
            "titulo": "Unificación primero",
            "responsable": "Acuerdo mesa",
            "detalle": "No avanzar ordenamiento sin unificación OK. Solo RPUs ganadoras entran; hijas fuera.",
            "estado": "ok",
        },
        {
            "id": "SES-02",
            "titulo": "4 canales independientes",
            "responsable": "Acuerdo sesión",
            "detalle": "DIR / TEL / CEL / EMA. Un teléfono no compite con un email. Solo DIR escribe orden_prioridad.",
            "estado": "ok",
        },
        {
            "id": "SES-03",
            "titulo": "Betas = catálogo",
            "responsable": "John → RITM5226589",
            "detalle": "Coeficientes en bdm_datos.beta_ordenamiento (47 filas Teradata). No hardcode en SP. No recalcular en este proyecto.",
            "estado": "ok",
        },
        {
            "id": "SES-04",
            "titulo": "Opción A (scoring EDF)",
            "responsable": "Implementación",
            "detalle": "Data sharing edf_views → preparar → scoring×4 → consolidar. Sin copiar productor. Full refresh.",
            "estado": "ok",
        },
        {
            "id": "SES-05",
            "titulo": "Fuera de alcance ahora",
            "responsable": "Diferido",
            "detalle": "Opción B / malla 242 / incremental F1 / Control-M / EMR / recalcular betas.",
            "estado": "na",
        },
        {
            "id": "SES-06",
            "titulo": "PRs + re-evidencia consumidor",
            "responsable": "Ops / Andrés",
            "detalle": "Re-evidencia DEV post-RITM OK (2026-09-18). PRs ordenamiento #4/#4/#8 pendientes de merge. QA consumidor aún sin bdm_*.",
            "estado": "parcial",
        },
    ]


def build_fases_documento() -> list[dict]:
    """Mapa para explicar en reunión (1 pregunta = 1 fase). Opción A DEV."""
    return [
        {
            "fase": "0",
            "nombre": "Precondición",
            "requiere": "¿Quién es dirección vigente?",
            "implementado": "Unificación R1/R2/R3 ya corrida; hijas ind=1 fuera",
            "estado": "ok",
            "nota": "Ejemplo: RPU 10002 hija no entra; 10001 y 10003 sí",
        },
        {
            "fase": "1",
            "nombre": "Armar candidatos",
            "requiere": "¿Qué contactos entran hoy?",
            "implementado": "Vistas + preparar_insumos_edf (solo ganadoras + XPM)",
            "estado": "ok",
            "nota": "Email sin @ fuera · contactType → canal",
        },
        {
            "fase": "2",
            "nombre": "Scoring × 4",
            "requiere": "¿Cuál intento primero por canal?",
            "implementado": "DIR/TEL/CEL/EMA · (cat/max)×β RITM · ROW_NUMBER",
            "estado": "ok",
            "nota": "Smoke: 20001 DIR · 20004 TEL · 20006 CEL · 20008 EMA",
        },
        {
            "fase": "3–4",
            "nombre": "Guardar y limpiar",
            "requiere": "¿Qué queda en el RPU?",
            "implementado": "consolidacion → orden_prioridad · drop stg_*",
            "estado": "ok",
            "nota": "Gate: 0 hijas con orden · CALL ejecucion_edf(TRUE)",
        },
    ]


def build_brechas() -> list[dict]:
    return [
        {
            "id": "TEL-02",
            "canal": "TEL",
            "regla": "CO01TEL020 no participa en suma final",
            "actual": "Corregido — alineado sesión/Teradata",
            "prio": "alta",
            "estado": "ok",
        },
        {
            "id": "EMA-03",
            "canal": "EMA",
            "regla": "CO01EMA003 y CO01EMA007 no participan en suma",
            "actual": "Corregido (+ EMA018/025)",
            "prio": "alta",
            "estado": "ok",
        },
        {
            "id": "CEL-02",
            "canal": "CEL",
            "regla": "Prefijo sin operador → valor 0.22 en CO01CEL018",
            "actual": "catalogo_operador + COALESCE(0.22)",
            "prio": "alta",
            "estado": "ok",
        },
        {
            "id": "BETAS",
            "canal": "ALL",
            "regla": "Betas = catálogo (acuerdo sesión con John/Manuel)",
            "actual": "RITM5226589 cargado (47 coefs) · datashare IFR opcional",
            "prio": "baja",
            "estado": "ok",
        },
        {
            "id": "MIG-01",
            "canal": "ALL",
            "regla": "Paridad 1:1 Teradata (post-betas)",
            "actual": "Diferido en sesión — no bloquea Opción A",
            "prio": "media",
            "estado": "na",
        },
        {
            "id": "F1-INC",
            "canal": "ALL",
            "regla": "Incremental por novedad (F1 Teradata)",
            "actual": "Fuera de alcance Opción A (full refresh)",
            "prio": "media",
            "estado": "na",
        },
        {
            "id": "PRS",
            "canal": "ALL",
            "regla": "Merge PRs feature/ordenamiento",
            "actual": "Abiertos: _strct #4 · _pgm #4 · _dt #8 — falta merge strct→pgm→dt",
            "prio": "alta",
            "estado": "parcial",
        },
        {
            "id": "REEVID",
            "canal": "ALL",
            "regla": "Re-evidencia consumidor DEV post-betas RITM",
            "actual": "2026-09-18: RITM 47 + ejecucion_edf OK · hijas=0 · scores post-RITM",
            "prio": "baja",
            "estado": "ok",
        },
    ]


def build_guion_sesion() -> list[dict]:
    """Guión 2 minutos — lenguaje de las transcripciones Mesa/Alineación."""
    return [
        {
            "paso": "1",
            "titulo": "Qué es",
            "decir": "Unificación ya dijo qué direcciones son la misma. Ordenamiento responde: si hay varias, ¿cuál contacto intento primero?",
        },
        {
            "paso": "2",
            "titulo": "Regla de oro",
            "decir": "Solo ganadoras. Las hijas no compiten. Cuatro canales aparte: calle, fijo, celular, email.",
        },
        {
            "paso": "3",
            "titulo": "Cómo puntúa",
            "decir": "Cada característica se vuelve un valor; se multiplica por el beta del catálogo (RITM); se suma; gana el mayor score → lugar 1.",
        },
        {
            "paso": "4",
            "titulo": "Ejemplo fácil",
            "decir": "María: casa vs oficina (DIR 20001). Fijo válido vs no válido (TEL 20004). Cel Claro vs otro (CEL 20006). Gmail vs corporativo (EMA 20008).",
        },
        {
            "paso": "5",
            "titulo": "Qué ya cerramos",
            "decir": "Opción A en DEV (1,22M scores) · fórmulas TEL/EMA/CEL · 47 betas RITM · 0 hijas mal · PRs #4/#4/#8 abiertos.",
        },
        {
            "paso": "6",
            "titulo": "Qué falta / qué no es",
            "decir": "Falta: unlock consumidor + re-evidencia EDF + merge/pipeline. No es este sprint: 242, incremental, recalcular betas, QA productor.",
        },
    ]


def build_artefactos() -> list[dict]:
    return [
        {"tipo": "_strct", "archivo": "01_ddl_ordenamiento.sql", "rol": "DDL tablas producto"},
        {"tipo": "_strct", "archivo": "02_carga_betas_ritm5226589.sql", "rol": "Catálogo 47 betas Teradata (RITM)"},
        {"tipo": "_strct", "archivo": "02_catalogos_ordenamiento.sql", "rol": "Catálogos sector/tel/cel operador"},
        {"tipo": "_strct", "archivo": "03_vistas_contacto_canal_edf_views.sql", "rol": "v_xpm_contacto_canal"},
        {"tipo": "_strct", "archivo": "04_vistas_insumo_ordenamiento_edf_views.sql", "rol": "v_rpu + insumo_* vistas"},
        {"tipo": "_pgm", "archivo": "sp_ordenamiento_preparar_insumos_edf.sql", "rol": "Staging stg_* (11 pasos)"},
        {"tipo": "_pgm", "archivo": "sp_ordenamiento_scoring_dir_edf.sql", "rol": "12 características DIR"},
        {"tipo": "_pgm", "archivo": "sp_ordenamiento_scoring_tel_edf.sql", "rol": "10 vars en SUM (sin TEL020)"},
        {"tipo": "_pgm", "archivo": "sp_ordenamiento_scoring_cel_edf.sql", "rol": "CEL018 operador + 0.22"},
        {"tipo": "_pgm", "archivo": "sp_ordenamiento_scoring_ema_edf.sql", "rol": "9 vars en SUM (sin 003/007/018/025)"},
        {"tipo": "_pgm", "archivo": "sp_ordenamiento_consolidacion_edf.sql", "rol": "rpu_orden_prioridad"},
        {"tipo": "_pgm", "archivo": "sp_ordenamiento_drop_staging_edf.sql", "rol": "DROP stg_*"},
        {"tipo": "_pgm", "archivo": "sp_ordenamiento_ejecucion_edf.sql", "rol": "Orquestador secuencial"},
        {"tipo": "_dt", "archivo": "run_ordenamiento_ejecucion_edf.sql", "rol": "CALL orquestador"},
        {"tipo": "_dt", "archivo": "validacion_ordenamiento_conteos.sql", "rol": "Gate post-corrida"},
        {"tipo": "DEV", "archivo": "tools/dev_edf_ordenamiento_run.py", "rol": "Deploy + QA automatizado"},
        {"tipo": "DOC", "archivo": "BETAS_ORDENAMIENTO_RITM5226589.md", "rol": "Acuerdo sesión + carga catálogo"},
    ]
