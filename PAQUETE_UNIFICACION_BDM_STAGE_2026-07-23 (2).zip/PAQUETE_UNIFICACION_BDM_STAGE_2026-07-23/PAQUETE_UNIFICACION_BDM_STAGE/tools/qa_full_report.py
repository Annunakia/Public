"""Full TC-R1/R2 validation suite for bdm_stage on Redshift QA."""
import json
import os
from datetime import datetime

import psycopg2
from psycopg2.extras import RealDictCursor

HOST = os.environ.get(
    "REDSHIFT_HOST",
    "eec-aws-us-eits-procesosbatch-qa-redshift.cwefyckvccgy.us-east-1.redshift.amazonaws.com",
)
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PASSWORD = os.environ.get("REDSHIFT_PASSWORD", "")


def q(cur, case_id, desc, expected, sql):
    try:
        cur.execute(sql)
        row = cur.fetchone()
        val = row[list(row.keys())[0]]
        if isinstance(val, (int, float)):
            status = "PASSED" if val == 0 else "FAILED"
            real = str(int(val))
        else:
            status = "PASSED" if val is not None else "FAILED"
            real = str(val)
        return {
            "id": case_id,
            "desc": desc,
            "sql": sql.strip(),
            "expected": expected,
            "real": real,
            "status": status,
            "error": None,
        }
    except Exception as e:
        cur.connection.rollback()
        return {
            "id": case_id,
            "desc": desc,
            "sql": sql.strip(),
            "expected": expected,
            "real": f"ERROR: {e}",
            "status": "NO EJECUTADO",
            "error": str(e),
        }


def main():
    conn = psycopg2.connect(
        host=HOST,
        port=5440,
        dbname="dba_batch",
        user=USER,
        password=PASSWORD,
        connect_timeout=45,
        sslmode="require",
    )
    conn.autocommit = True
    cur = conn.cursor(cursor_factory=RealDictCursor)

    smoke = {}
    for tbl in [
        "bdm_stage.relacion_persona_ubicacion",
        "bdm_stage.unificacion_direccion",
        "bdm_stage.direccion_fisica",
    ]:
        cur.execute(f"SELECT COUNT(*) AS c FROM {tbl}")
        smoke[tbl] = cur.fetchone()["c"]

    cases = []

    cases.append(
        q(
            cur,
            "TC-R1-01",
            "CIIU 10: padre LAB/CRR con max entidades; RES excluida",
            "violaciones = 0",
            """
            SELECT COUNT(*) AS v
            FROM bdm_stage.unificacion_direccion u
            JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic
            JOIN bdm_stage.relacion_persona_ubicacion rp ON rp.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
            JOIN bdm_stage.ciiu_persona c ON c.id_buro_persona = rh.id_buro_persona
            JOIN bdm_stage.tipo_ubicacion_dir tp ON tp.cod_dw_tipo_ubicacion_dir = rp.cod_dw_tipo_ubicacion_dir
            WHERE u.unifica_atributos = 1
              AND c.cod_act_econo_ciiu_fte = '10'
              AND tp.descripcion_tipo_ubicacion_dir NOT IN ('LAB','CRR')
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R1-02",
            "CIIU 81/82/90: padre RES/CRR; excluye LAB",
            "violaciones = 0",
            """
            SELECT COUNT(*) AS v
            FROM bdm_stage.unificacion_direccion u
            JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic
            JOIN bdm_stage.relacion_persona_ubicacion rp ON rp.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
            JOIN bdm_stage.ciiu_persona c ON c.id_buro_persona = rh.id_buro_persona
            JOIN bdm_stage.tipo_ubicacion_dir tp ON tp.cod_dw_tipo_ubicacion_dir = rp.cod_dw_tipo_ubicacion_dir
            WHERE u.unifica_atributos = 1
              AND c.cod_act_econo_ciiu_fte IN ('81','82','90')
              AND tp.descripcion_tipo_ubicacion_dir NOT IN ('RES','CRR')
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R1-03",
            "Otros CIIU: padre por max entidades sin preferencia tipo",
            "violaciones = 0",
            """
            WITH scored AS (
              SELECT rpu.id_buro_persona, ubi.texto_ubicacion, rpu.cod_dw_persona_ubic,
                     COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor),0) AS ents
              FROM bdm_stage.relacion_persona_ubicacion rpu
              JOIN bdm_stage.ubicacion_estandarizada ubi ON ubi.cod_dw_ubic = rpu.cod_dw_ubic
              JOIN bdm_stage.ciiu_persona c ON c.id_buro_persona = rpu.id_buro_persona
              LEFT JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rep.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
              WHERE c.cod_act_econo_ciiu_fte NOT IN ('10','81','82','90')
              GROUP BY 1,2,3
            ),
            winners AS (
              SELECT id_buro_persona, texto_ubicacion, cod_dw_persona_ubic,
                     ROW_NUMBER() OVER (PARTITION BY id_buro_persona, texto_ubicacion ORDER BY ents DESC, cod_dw_persona_ubic DESC) AS rn
              FROM scored
            )
            SELECT COUNT(*) AS v
            FROM bdm_stage.unificacion_direccion u
            JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic
            JOIN bdm_stage.ubicacion_estandarizada ubi ON ubi.cod_dw_ubic = rh.cod_dw_ubic
            JOIN bdm_stage.ciiu_persona c ON c.id_buro_persona = rh.id_buro_persona
            LEFT JOIN winners w ON w.id_buro_persona = rh.id_buro_persona
              AND w.texto_ubicacion = ubi.texto_ubicacion
              AND w.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
              AND w.rn = 1
            WHERE u.unifica_atributos = 1
              AND c.cod_act_econo_ciiu_fte NOT IN ('10','81','82','90')
              AND w.cod_dw_persona_ubic IS NULL
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R1-04",
            "Toda hija R1 tiene ind_unificacion = 1",
            "anomalias = 0",
            """
            SELECT COUNT(*) AS v
            FROM bdm_stage.unificacion_direccion u
            JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
            WHERE u.unifica_atributos = 1 AND COALESCE(r.ind_unificacion, 0) <> 1
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R1-05",
            "Trazabilidad R1: hijo, padre y fecha_unificacion",
            "anomalias = 0",
            """
            SELECT COUNT(*) AS v
            FROM bdm_stage.unificacion_direccion
            WHERE unifica_atributos = 1
              AND (cod_dw_persona_ubic IS NULL OR cod_dw_direccion_unificada IS NULL OR fecha_unificacion IS NULL)
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R1-06",
            "Bloqueadas / previas hijas no participan en R1",
            "anomalias = 0",
            """
            SELECT COUNT(*) AS v
            FROM bdm_stage.unificacion_direccion u
            JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
            JOIN bdm_stage.bloqueo b ON b.id_buro_persona = r.id_buro_persona
            WHERE u.unifica_atributos = 1
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R1-07",
            "Segmentación CIIU sin solapamientos en unificaciones R1",
            "anomalias = 0",
            """
            SELECT COUNT(*) AS v
            FROM (
              SELECT rh.id_buro_persona, ubi.texto_ubicacion, COUNT(DISTINCT c.cod_act_econo_ciiu_fte) AS ciiu_cnt
              FROM bdm_stage.unificacion_direccion u
              JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic
              JOIN bdm_stage.ubicacion_estandarizada ubi ON ubi.cod_dw_ubic = rh.cod_dw_ubic
              JOIN bdm_stage.ciiu_persona c ON c.id_buro_persona = rh.id_buro_persona
              WHERE u.unifica_atributos = 1
              GROUP BY 1,2
              HAVING COUNT(DISTINCT c.cod_act_econo_ciiu_fte) > 1
            ) t
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R1-08",
            "Empate persistente R1: escenario R1_EMPATE sin unificación",
            "absorciones = 0",
            """
            SELECT COUNT(*) AS v
            FROM bdm_stage.perf_persona_meta m
            JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
            JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic
            WHERE m.scenario_code = 'R1_EMPATE' AND u.unifica_atributos = 1
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R2-01",
            "Esc1: complemento vacío vs informado -> gana informado",
            "violaciones = 0",
            """
            WITH esc AS (
              SELECT m.id_buro_persona, r.cod_dw_persona_ubic, df.complemento,
                     COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor),0) AS ents
              FROM bdm_stage.perf_persona_meta m
              JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
              JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
              LEFT JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rep.cod_dw_persona_ubic = r.cod_dw_persona_ubic
              WHERE m.scenario_code = 'R2_ESC1'
              GROUP BY 1,2,3
            ),
            winner AS (
              SELECT id_buro_persona,
                     MAX(CASE WHEN TRIM(COALESCE(complemento,'')) <> '' THEN cod_dw_persona_ubic END) AS padre_esperado
              FROM esc GROUP BY 1
            )
            SELECT COUNT(*) AS v
            FROM bdm_stage.unificacion_direccion u
            JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic
            JOIN winner w ON w.id_buro_persona = rh.id_buro_persona
            WHERE u.unifica_atributos = 2
              AND rh.id_buro_persona IN (SELECT id_buro_persona FROM bdm_stage.perf_persona_meta WHERE scenario_code = 'R2_ESC1')
              AND u.cod_dw_direccion_unificada <> w.padre_esperado
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R2-02",
            "Esc2: inclusión total -> gana complemento más completo",
            "violaciones = 0",
            """
            WITH esc AS (
              SELECT m.id_buro_persona, r.cod_dw_persona_ubic, LENGTH(COALESCE(df.complemento,'')) AS comp_len
              FROM bdm_stage.perf_persona_meta m
              JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
              JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
              WHERE m.scenario_code = 'R2_ESC2'
            ),
            winner AS (
              SELECT id_buro_persona, cod_dw_persona_ubic AS padre_esperado,
                     ROW_NUMBER() OVER (PARTITION BY id_buro_persona ORDER BY comp_len DESC, cod_dw_persona_ubic DESC) AS rn
              FROM esc
            )
            SELECT COUNT(*) AS v
            FROM bdm_stage.unificacion_direccion u
            JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic
            JOIN winner w ON w.id_buro_persona = rh.id_buro_persona AND w.rn = 1
            WHERE u.unifica_atributos = 2
              AND rh.id_buro_persona IN (SELECT id_buro_persona FROM bdm_stage.perf_persona_meta WHERE scenario_code = 'R2_ESC2')
              AND u.cod_dw_direccion_unificada <> w.padre_esperado
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R2-03",
            "Esc3 sin NIT: gana mayor entidades; no crea dirección nueva",
            "violaciones = 0",
            """
            SELECT COUNT(*) AS v
            FROM bdm_stage.perf_persona_meta m
            JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
            JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
            WHERE m.scenario_code = 'R2_ESC3_SIN_NIT'
              AND COALESCE(df.generada_enriquecida, 0) = 1
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R2-04",
            "Esc3 con NIT: crea dirección combinada generada_enriquecida=1",
            "personas_sin_nueva_dir = 0",
            """
            SELECT COUNT(*) AS v
            FROM bdm_stage.perf_persona_meta m
            WHERE m.scenario_code = 'R2_ESC3_NIT'
              AND NOT EXISTS (
                SELECT 1
                FROM bdm_stage.relacion_persona_ubicacion r
                JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
                WHERE r.id_buro_persona = m.id_buro_persona
                  AND COALESCE(df.generada_enriquecida, 0) = 1
              )
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R2-05",
            "Esc4: nomenclaturas distintas mismo nivel -> diccionario",
            "violaciones = 0",
            """
            SELECT COUNT(*) AS v
            FROM bdm_stage.perf_persona_meta m
            JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
            LEFT JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic AND u.unifica_atributos = 2
            WHERE m.scenario_code IN ('R2_ESC4','R2_ESC4_DIC')
              AND u.cod_dw_persona_ubic IS NULL
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R2-06",
            "Esc5 motor: genera dirección combinada",
            "personas_sin_nueva_dir = 0",
            """
            SELECT COUNT(*) AS v
            FROM bdm_stage.perf_persona_meta m
            WHERE m.scenario_code = 'R2_ESC5_MOTOR'
              AND NOT EXISTS (
                SELECT 1 FROM bdm_stage.relacion_persona_ubicacion r
                JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
                WHERE r.id_buro_persona = m.id_buro_persona AND COALESCE(df.generada_enriquecida,0)=1
              )
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R2-07",
            "Esc6 motor: complementos complejos -> dirección combinada",
            "personas_sin_nueva_dir = 0",
            """
            SELECT COUNT(*) AS v
            FROM bdm_stage.perf_persona_meta m
            WHERE m.scenario_code = 'R2_ESC6_MOTOR'
              AND NOT EXISTS (
                SELECT 1 FROM bdm_stage.relacion_persona_ubicacion r
                JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
                WHERE r.id_buro_persona = m.id_buro_persona AND COALESCE(df.generada_enriquecida,0)=1
              )
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R2-08",
            "Integridad ind_generada: direcciones motor R2 con generada_enriquecida=1",
            "anomalias = 0",
            """
            SELECT COUNT(*) AS v
            FROM bdm_stage.direccion_fisica df
            JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
            JOIN bdm_stage.perf_persona_meta m ON m.id_buro_persona = r.id_buro_persona
            WHERE m.scenario_code IN ('R2_ESC3_NIT','R2_ESC5_MOTOR','R2_ESC6_MOTOR')
              AND r.cod_dw_persona_ubic > m.id_buro_persona * 1000 + 2
              AND COALESCE(df.generada_enriquecida, 0) <> 1
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R2-09",
            "Integridad persona-ubicación: 0 huérfanas generada_enriquecida=1",
            "anomalias = 0",
            """
            SELECT COUNT(*) AS v
            FROM bdm_stage.direccion_fisica df
            LEFT JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
            WHERE COALESCE(df.generada_enriquecida, 0) = 1 AND r.cod_dw_persona_ubic IS NULL
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R2-10",
            "Padre nunca hijo en mismo ciclo R2",
            "anomalias = 0",
            """
            SELECT COUNT(*) AS v
            FROM bdm_stage.unificacion_direccion u
            JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
            WHERE u.unifica_atributos = 2 AND COALESCE(r.ind_unificacion, 0) = 1
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R2-11",
            "Cardinalidad hija-padre: exactamente 1 padre por hija R2",
            "anomalias = 0",
            """
            SELECT COUNT(*) AS v
            FROM (
              SELECT cod_dw_persona_ubic
              FROM bdm_stage.unificacion_direccion
              WHERE unifica_atributos = 2
              GROUP BY 1
              HAVING COUNT(DISTINCT cod_dw_direccion_unificada) <> 1
            ) t
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R2-12",
            "Formateo complementos: sin dobles espacios en generadas",
            "anomalias = 0",
            """
            SELECT COUNT(*) AS v
            FROM bdm_stage.direccion_fisica
            WHERE COALESCE(generada_enriquecida, 0) = 1
              AND complemento LIKE '%  %'
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R2-13",
            "Priorización diccionario Esc4_DIC",
            "violaciones = 0",
            """
            SELECT COUNT(*) AS v
            FROM bdm_stage.perf_persona_meta m
            JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
            LEFT JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic AND u.unifica_atributos = 2
            WHERE m.scenario_code = 'R2_ESC4_DIC'
              AND u.cod_dw_persona_ubic IS NULL
            """,
        )
    )

    cases.append(
        q(
            cur,
            "TC-R2-14",
            "Empate persistente R2: escenario R2_EMPATE sin unificación",
            "absorciones = 0",
            """
            SELECT COUNT(*) AS v
            FROM bdm_stage.perf_persona_meta m
            JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
            JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic
            WHERE m.scenario_code = 'R2_EMPATE' AND u.unifica_atributos = 2
            """,
        )
    )

    integrity = {}
    integrity["TC-G-07"] = q(
        cur,
        "TC-G-07",
        "Aislamiento intra-persona",
        "anomalias = 0",
        """
        SELECT COUNT(*) AS v
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion h ON h.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        JOIN bdm_stage.relacion_persona_ubicacion p ON p.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
        WHERE h.id_buro_persona <> p.id_buro_persona
        """,
    )

    cur.execute(
        "SELECT unifica_atributos, COUNT(*) AS total FROM bdm_stage.unificacion_direccion GROUP BY 1 ORDER BY 1"
    )
    by_rule = [dict(r) for r in cur.fetchall()]

    passed = sum(1 for c in cases if c["status"] == "PASSED")
    failed = sum(1 for c in cases if c["status"] == "FAILED")
    blocked = sum(1 for c in cases if c["status"] == "NO EJECUTADO")

    out = {
        "executed_at": datetime.now().isoformat(),
        "environment": "QA",
        "host": HOST,
        "user": USER,
        "smoke": smoke,
        "by_rule": by_rule,
        "summary": {"total": len(cases), "passed": passed, "failed": failed, "blocked": blocked},
        "cases": cases,
        "integrity": integrity,
    }
    print(json.dumps(out, default=str, indent=2))


if __name__ == "__main__":
    main()
