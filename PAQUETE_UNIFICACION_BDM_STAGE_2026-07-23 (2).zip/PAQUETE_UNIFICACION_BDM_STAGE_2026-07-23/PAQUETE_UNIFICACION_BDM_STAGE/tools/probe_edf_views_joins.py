"""Discover edf_views join columns vs ifr_data."""
import os
import psycopg2
from psycopg2.extras import RealDictCursor

HOST = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
PWD = os.environ.get("REDSHIFT_PASSWORD", "b27YWI2FL")

TABLES = ("xpm", "xpm_location", "xpm_location_val_contactinformations", "xpm_counterparties")

JOIN_CANDIDATES = (
    "relationalizelastupdate", "location", "counterparties", "pin", "id",
    "location.val.contactinformations",
)


def cols(cur, schema, table):
    cur.execute("""
        SELECT column_name FROM information_schema.columns
        WHERE table_schema = %s AND table_name = %s
        ORDER BY ordinal_position
    """, (schema, table))
    return [r["column_name"] for r in cur.fetchall()]


def try_join_counts(cur):
    tests = []

    # without relationalizelastupdate
    tests.append(("join_loc_no_rel", """
        SELECT COUNT(*) AS n FROM edf_views.xpm xpm
        JOIN edf_views.xpm_location loc ON xpm.location = loc.id
    """))
    tests.append(("join_ci_no_rel", """
        SELECT COUNT(*) AS n FROM edf_views.xpm xpm
        JOIN edf_views.xpm_location loc ON xpm.location = loc.id
        JOIN edf_views.xpm_location_val_contactinformations ci
          ON loc."location.val.contactinformations" = ci.id
        WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1,2,3,7)
    """))
    tests.append(("join_full_no_rel", """
        SELECT COUNT(*) AS n FROM edf_views.xpm xpm
        JOIN edf_views.xpm_location loc ON xpm.location = loc.id
        JOIN edf_views.xpm_location_val_contactinformations ci
          ON loc."location.val.contactinformations" = ci.id
        JOIN edf_views.xpm_counterparties cp ON xpm.counterparties = cp.id
        WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1,2,3,7)
    """))

    # sample xpm columns
    tests.append(("xpm_sample", """
        SELECT pin, location, counterparties FROM edf_views.xpm LIMIT 3
    """))

    for name, q in tests:
        try:
            cur.execute(q)
            rows = cur.fetchall()
            print(f"\n{name}: OK -> {rows[:3]}")
        except Exception as e:
            print(f"\n{name}: ERR -> {str(e).split(chr(10))[0][:150]}")


def main():
    c = psycopg2.connect(
        host=HOST, port=5440, dbname="dba_batch", user="c32525e",
        password=PWD, sslmode="require",
    )
    c.autocommit = True
    cur = c.cursor(cursor_factory=RealDictCursor)

    for schema in ("edf_views", "ifr_data"):
        print(f"\n{'='*50}\nSCHEMA {schema}\n{'='*50}")
        for t in TABLES:
            try:
                all_c = cols(cur, schema, t)
                print(f"\n{t}: {len(all_c)} cols")
                hits = [c for c in all_c if any(k in c.lower() for k in
                    ("relational", "location", "counterpart", "pin", "contact", "standardized", "cutoff"))]
                for h in hits[:25]:
                    print(f"  {h}")
                if len(hits) > 25:
                    print(f"  ... +{len(hits)-25} more")
            except Exception as e:
                print(f"{t}: ERR {e}")

    print("\n\n=== JOIN TESTS edf_views ===")
    try_join_counts(cur)
    c.close()


if __name__ == "__main__":
    main()
