"""Query procesosbatch DEV for datashare / external DB hints."""
import json, os, psycopg2
from psycopg2.extras import RealDictCursor

h = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
c = psycopg2.connect(
    host=h, port=5440, dbname="dba_batch", user="c32525e",
    password=os.environ["REDSHIFT_PASSWORD"], sslmode="require", connect_timeout=30,
)
cur = c.cursor(cursor_factory=RealDictCursor)
out = {}
for name, sql in [
    ("datashares", "SELECT * FROM svv_datashares LIMIT 30"),
    ("consumers", "SELECT * FROM svv_datashare_consumers LIMIT 30"),
    ("objects", "SELECT share_name, object_name, object_type FROM svv_datashare_objects LIMIT 20"),
    ("databases", "SELECT datname FROM pg_database ORDER BY 1"),
]:
    try:
        cur.execute(sql)
        out[name] = [dict(r) for r in cur.fetchall()]
    except Exception as e:
        out[name + "_err"] = str(e)
print(json.dumps(out, indent=2, default=str))
c.close()
