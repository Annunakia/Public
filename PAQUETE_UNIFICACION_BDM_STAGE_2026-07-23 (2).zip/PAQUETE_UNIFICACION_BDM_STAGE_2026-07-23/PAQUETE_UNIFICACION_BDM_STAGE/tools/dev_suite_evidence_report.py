"""Execute full suite on DEV and generate markdown evidence report per test case."""
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import psycopg2
from psycopg2.extras import RealDictCursor

HOST = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
PWD = os.environ.get("REDSHIFT_PASSWORD", "")
ROOT = Path(__file__).resolve().parents[1]
DOC_PATH = ROOT / "Documentacion" / "Evidencias_Suite_R1_R2_DEV.md"
JSON_PATH = ROOT / "tools" / "dev_suite_evidence.json"

sys.path.insert(0, str(ROOT / "tools"))
from qa_rerun_full_corrected import CASES, run  # noqa: E402

# Sample evidence query per official case (LIMIT 3 rows)
EVIDENCE_SQL = {
    "TC-R1-01": """
        SELECT m.id_buro_persona, m.scenario_code, u.cod_dw_persona_ubic AS hija,
               u.cod_dw_direccion_unificada AS padre, tp.descripcion_tipo_ubicacion_dir AS tipo_padre
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        JOIN bdm_stage.relacion_persona_ubicacion rp ON rp.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
        JOIN bdm_stage.ciiu_persona c ON c.id_buro_persona = rh.id_buro_persona
        JOIN bdm_stage.tipo_ubicacion_dir tp ON tp.cod_dw_tipo_ubicacion_dir = rp.cod_dw_tipo_ubicacion_dir
        JOIN bdm_stage.perf_persona_meta m ON m.id_buro_persona = rh.id_buro_persona
        WHERE u.unifica_atributos = 1 AND c.cod_act_econo_ciiu_fte = '10'
          AND tp.descripcion_tipo_ubicacion_dir IN ('LAB','CRR')
          AND m.scenario_code = 'R1_ESC1'
        ORDER BY m.id_buro_persona LIMIT 3
    """,
    "TC-R1-02": """
        SELECT m.scenario_code, COUNT(*) AS unificaciones_ok
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        JOIN bdm_stage.relacion_persona_ubicacion rp ON rp.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
        JOIN bdm_stage.ciiu_persona c ON c.id_buro_persona = rh.id_buro_persona
        JOIN bdm_stage.tipo_ubicacion_dir tp ON tp.cod_dw_tipo_ubicacion_dir = rp.cod_dw_tipo_ubicacion_dir
        JOIN bdm_stage.perf_persona_meta m ON m.id_buro_persona = rh.id_buro_persona
        WHERE u.unifica_atributos = 1 AND c.cod_act_econo_ciiu_fte IN ('81','82','90')
          AND tp.descripcion_tipo_ubicacion_dir IN ('RES','CRR')
        GROUP BY 1 ORDER BY 1 LIMIT 3
    """,
    "TC-R1-03": """
        SELECT m.scenario_code, COUNT(*) AS unificaciones_r1
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        JOIN bdm_stage.ciiu_persona c ON c.id_buro_persona = rh.id_buro_persona
        JOIN bdm_stage.perf_persona_meta m ON m.id_buro_persona = rh.id_buro_persona
        WHERE u.unifica_atributos = 1 AND c.cod_act_econo_ciiu_fte NOT IN ('10','81','82','90')
        GROUP BY 1 ORDER BY 2 DESC LIMIT 3
    """,
    "TC-R1-04": """
        SELECT COUNT(*) AS hijas_r1_total,
               SUM(CASE WHEN COALESCE(r.ind_unificacion,0)=1 THEN 1 ELSE 0 END) AS hijas_ind_1
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        WHERE u.unifica_atributos = 1
    """,
    "TC-R1-05": """
        SELECT COUNT(*) AS filas_r1_completas
        FROM bdm_stage.unificacion_direccion
        WHERE unifica_atributos = 1
          AND cod_dw_persona_ubic IS NOT NULL
          AND cod_dw_direccion_unificada IS NOT NULL
          AND fecha_unificacion IS NOT NULL
    """,
    "TC-R1-06": """
        SELECT COUNT(*) AS personas_bloqueadas_en_r1
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        JOIN bdm_stage.bloqueo b ON b.id_buro_persona = r.id_buro_persona
        WHERE u.unifica_atributos = 1
    """,
    "TC-R1-07": """
        SELECT COUNT(*) AS particiones_ciiu_mixto
        FROM (
          SELECT rh.id_buro_persona, ubi.texto_ubicacion
          FROM bdm_stage.unificacion_direccion u
          JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic
          JOIN bdm_stage.ubicacion_estandarizada ubi ON ubi.cod_dw_ubic = rh.cod_dw_ubic
          JOIN bdm_stage.ciiu_persona c ON c.id_buro_persona = rh.id_buro_persona
          WHERE u.unifica_atributos = 1
          GROUP BY 1,2 HAVING COUNT(DISTINCT c.cod_act_econo_ciiu_fte) > 1
        ) t
    """,
    "TC-R1-08": """
        SELECT COUNT(*) AS absorciones_r1_empate
        FROM bdm_stage.perf_persona_meta m
        JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
        JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic
        WHERE m.scenario_code = 'R1_EMPATE' AND u.unifica_atributos = 1
    """,
    "TC-R2-01": """
        SELECT m.id_buro_persona, u.cod_dw_persona_ubic AS hija, u.cod_dw_direccion_unificada AS padre,
               df_h.complemento AS comp_hija, df_p.complemento AS comp_padre
        FROM bdm_stage.perf_persona_meta m
        JOIN bdm_stage.unificacion_direccion u ON u.unifica_atributos = 2
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic AND rh.id_buro_persona = m.id_buro_persona
        JOIN bdm_stage.direccion_fisica df_h ON df_h.cod_dw_direccion_fisica = rh.cod_dw_direccion_fisica
        JOIN bdm_stage.relacion_persona_ubicacion rp ON rp.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
        JOIN bdm_stage.direccion_fisica df_p ON df_p.cod_dw_direccion_fisica = rp.cod_dw_direccion_fisica
        WHERE m.scenario_code = 'R2_ESC1'
        ORDER BY m.id_buro_persona LIMIT 3
    """,
    "TC-R2-02": """
        SELECT m.id_buro_persona, u.cod_dw_persona_ubic AS hija, u.cod_dw_direccion_unificada AS padre,
               LENGTH(df_h.complemento) AS len_hija, LENGTH(df_p.complemento) AS len_padre
        FROM bdm_stage.perf_persona_meta m
        JOIN bdm_stage.unificacion_direccion u ON u.unifica_atributos = 2
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic AND rh.id_buro_persona = m.id_buro_persona
        JOIN bdm_stage.direccion_fisica df_h ON df_h.cod_dw_direccion_fisica = rh.cod_dw_direccion_fisica
        JOIN bdm_stage.relacion_persona_ubicacion rp ON rp.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
        JOIN bdm_stage.direccion_fisica df_p ON df_p.cod_dw_direccion_fisica = rp.cod_dw_direccion_fisica
        WHERE m.scenario_code = 'R2_ESC2'
        ORDER BY m.id_buro_persona LIMIT 3
    """,
    "TC-R2-03": """
        SELECT COUNT(*) AS dirs_generadas_esc3_sin_nit
        FROM bdm_stage.perf_persona_meta m
        JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
        JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
        WHERE m.scenario_code = 'R2_ESC3_SIN_NIT' AND COALESCE(df.generada_enriquecida, 0) = 1
    """,
    "TC-R2-04": """
        SELECT m.id_buro_persona, r.orden_prioridad, r.cod_dw_persona_ubic,
               df.complemento, df.generada_enriquecida
        FROM bdm_stage.perf_persona_meta m
        JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
        JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
        WHERE m.id_buro_persona = 100030
        ORDER BY r.orden_prioridad
    """,
    "TC-R2-05": """
        SELECT m.scenario_code, COUNT(DISTINCT m.id_buro_persona) AS personas,
               COUNT(DISTINCT CASE WHEN u.cod_dw_persona_ubic IS NOT NULL THEN m.id_buro_persona END) AS con_r2
        FROM bdm_stage.perf_persona_meta m
        LEFT JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
        LEFT JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic AND u.unifica_atributos = 2
        WHERE m.scenario_code IN ('R2_ESC4','R2_ESC4_DIC')
        GROUP BY 1
    """,
    "TC-R2-06": """
        SELECT m.id_buro_persona, r.orden_prioridad, df.complemento, df.generada_enriquecida
        FROM bdm_stage.perf_persona_meta m
        JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
        JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
        WHERE m.id_buro_persona = 100033
        ORDER BY r.orden_prioridad
    """,
    "TC-R2-07": """
        SELECT m.id_buro_persona, r.orden_prioridad, df.complemento, df.generada_enriquecida
        FROM bdm_stage.perf_persona_meta m
        JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
        JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
        WHERE m.id_buro_persona = 100037
        ORDER BY r.orden_prioridad
    """,
    "TC-R2-08": """
        SELECT m.scenario_code, r.cod_dw_persona_ubic, df.complemento, df.generada_enriquecida
        FROM bdm_stage.perf_persona_meta m
        JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
        JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
        WHERE m.scenario_code IN ('R2_ESC3_NIT','R2_ESC5_MOTOR','R2_ESC6_MOTOR')
          AND r.cod_dw_persona_ubic > m.id_buro_persona * 1000 + 2
        ORDER BY m.scenario_code, m.id_buro_persona LIMIT 6
    """,
    "TC-R2-09": """
        SELECT COUNT(*) AS dirs_huerfanas
        FROM bdm_stage.direccion_fisica df
        LEFT JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
        WHERE COALESCE(df.generada_enriquecida, 0) = 1 AND r.cod_dw_persona_ubic IS NULL
    """,
    "TC-R2-10": """
        SELECT COUNT(*) AS padres_marcados_hijo
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
        WHERE u.unifica_atributos = 2 AND COALESCE(r.ind_unificacion, 0) = 1
    """,
    "TC-R2-11": """
        SELECT COUNT(*) AS hijas_multiples_padres
        FROM (
          SELECT cod_dw_persona_ubic FROM bdm_stage.unificacion_direccion
          WHERE unifica_atributos = 2 GROUP BY 1 HAVING COUNT(DISTINCT cod_dw_direccion_unificada) <> 1
        ) t
    """,
    "TC-R2-12": """
        SELECT COUNT(*) AS complementos_doble_espacio
        FROM bdm_stage.direccion_fisica
        WHERE COALESCE(generada_enriquecida, 0) = 1 AND complemento LIKE '%  %'
    """,
    "TC-R2-13": """
        SELECT COUNT(DISTINCT m.id_buro_persona) AS personas_esc4_dic,
               COUNT(DISTINCT CASE WHEN u.cod_dw_persona_ubic IS NOT NULL THEN m.id_buro_persona END) AS con_r2
        FROM bdm_stage.perf_persona_meta m
        LEFT JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
        LEFT JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic AND u.unifica_atributos = 2
        WHERE m.scenario_code = 'R2_ESC4_DIC'
    """,
    "TC-R2-14": """
        SELECT COUNT(*) AS personas_r2_empate_con_r2
        FROM bdm_stage.perf_persona_meta m
        WHERE m.scenario_code = 'R2_EMPATE' AND EXISTS (
          SELECT 1 FROM bdm_stage.relacion_persona_ubicacion r
          JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic AND u.unifica_atributos = 2
          WHERE r.id_buro_persona = m.id_buro_persona
        )
    """,
    "TC-G-07": """
        SELECT COUNT(*) AS unificaciones_inter_persona
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion h ON h.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        JOIN bdm_stage.relacion_persona_ubicacion p ON p.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
        WHERE h.id_buro_persona <> p.id_buro_persona
    """,
}

MOCK_EVIDENCE = {
    "888001": """
        SELECT 'R1' regla, u.cod_dw_persona_ubic hija, u.cod_dw_direccion_unificada padre,
               df_h.complemento comp_hija, t_h.descripcion_tipo_ubicacion_dir tipo_hija,
               df_p.complemento comp_padre, t_p.descripcion_tipo_ubicacion_dir tipo_padre,
               rh.ind_unificacion
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic=u.cod_dw_persona_ubic
        JOIN bdm_stage.relacion_persona_ubicacion rp ON rp.cod_dw_persona_ubic=u.cod_dw_direccion_unificada
        JOIN bdm_stage.direccion_fisica df_h ON df_h.cod_dw_direccion_fisica=rh.cod_dw_direccion_fisica
        JOIN bdm_stage.direccion_fisica df_p ON df_p.cod_dw_direccion_fisica=rp.cod_dw_direccion_fisica
        JOIN bdm_stage.tipo_ubicacion_dir t_h ON t_h.cod_dw_tipo_ubicacion_dir=rh.cod_dw_tipo_ubicacion_dir
        JOIN bdm_stage.tipo_ubicacion_dir t_p ON t_p.cod_dw_tipo_ubicacion_dir=rp.cod_dw_tipo_ubicacion_dir
        WHERE rh.id_buro_persona=888001 AND u.unifica_atributos=1
    """,
    "888002": """
        SELECT 'R2' regla, u.cod_dw_persona_ubic hija, u.cod_dw_direccion_unificada padre,
               df_h.complemento comp_hija, df_p.complemento comp_padre
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic=u.cod_dw_persona_ubic
        JOIN bdm_stage.relacion_persona_ubicacion rp ON rp.cod_dw_persona_ubic=u.cod_dw_direccion_unificada
        JOIN bdm_stage.direccion_fisica df_h ON df_h.cod_dw_direccion_fisica=rh.cod_dw_direccion_fisica
        JOIN bdm_stage.direccion_fisica df_p ON df_p.cod_dw_direccion_fisica=rp.cod_dw_direccion_fisica
        WHERE rh.id_buro_persona=888002 AND u.unifica_atributos=2
    """,
    "888003": """
        SELECT u.cod_dw_persona_ubic hija, u.cod_dw_direccion_unificada padre,
               df_h.complemento comp_hija, df_p.complemento comp_padre
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic=u.cod_dw_persona_ubic
        JOIN bdm_stage.relacion_persona_ubicacion rp ON rp.cod_dw_persona_ubic=u.cod_dw_direccion_unificada
        JOIN bdm_stage.direccion_fisica df_h ON df_h.cod_dw_direccion_fisica=rh.cod_dw_direccion_fisica
        JOIN bdm_stage.direccion_fisica df_p ON df_p.cod_dw_direccion_fisica=rp.cod_dw_direccion_fisica
        WHERE rh.id_buro_persona=888003 AND u.unifica_atributos=2
    """,
    "888004": """
        SELECT COUNT(*) AS unificaciones_r2_mock
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic=u.cod_dw_persona_ubic
        WHERE rh.id_buro_persona=888004 AND u.unifica_atributos=2
    """,
}


def deploy_sps(cur):
    for name in ("05_sp_regla1.sql", "06_sp_regla2.sql"):
        cur.execute((ROOT / "sql" / name).read_text(encoding="utf-8"))


def reset_state(cur):
    cur.execute("DELETE FROM bdm_stage.unificacion_direccion")
    cur.execute("""
        DELETE FROM bdm_stage.relacion_persona_ubicacion
        WHERE cod_dw_direccion_fisica IN (
          SELECT cod_dw_direccion_fisica FROM bdm_stage.direccion_fisica
          WHERE COALESCE(generada_enriquecida, 0) = 1
        )
    """)
    cur.execute("DELETE FROM bdm_stage.direccion_fisica WHERE COALESCE(generada_enriquecida, 0) = 1")
    cur.execute("""
        UPDATE bdm_stage.relacion_persona_ubicacion r SET ind_unificacion = NULL
        FROM bdm_stage.perf_persona_meta m
        WHERE m.id_buro_persona = r.id_buro_persona AND m.scenario_code <> 'R1_HIJA'
    """)


def fetch_rows(cur, sql):
    cur.execute(sql)
    rows = cur.fetchall()
    if not rows:
        return []
    if isinstance(rows[0], dict):
        return [dict(r) for r in rows]
    cols = [d[0] for d in cur.description]
    return [dict(zip(cols, r)) for r in rows]


def rows_to_md(rows):
    if not rows:
        return "_Sin filas._\n"
    cols = list(rows[0].keys())
    lines = ["| " + " | ".join(cols) + " |", "| " + " | ".join("---" for _ in cols) + " |"]
    for r in rows:
        lines.append("| " + " | ".join(str(r[c]) if r[c] is not None else "" for c in cols) + " |")
    return "\n".join(lines) + "\n"


def sql_block(sql):
    return f"```sql\n{sql.strip()}\n```\n"


def build_markdown(payload):
    ts = payload["executed_at"]
    s = payload["summary"]
    lines = [
        "# Evidencias — Suite R1/R2 DEV (Redshift)",
        "",
        f"* **Ejecutado:** {ts}",
        f"* **Entorno:** DEV — `{payload['host']}`",
        f"* **Pipeline:** {payload['pipeline']}",
        "",
        "## Resumen",
        "",
        f"| Métrica | Valor |",
        f"|---------|------:|",
        f"| Casos oficiales | {s['total_oficial']} |",
        f"| PASSED | **{s['passed']}** |",
        f"| FAILED | {s['failed']} |",
        f"| Aprobación | **{s['pct']}%** |",
        "",
        "### Conteos post-ejecución",
        "",
    ]
    for c in payload["counts"]:
        lines.append(f"- **{c['lbl']}**: {c['n']:,}" if isinstance(c.get("n"), int) else f"- **{c.get('lbl')}**: {c.get('n')}")
    lines.extend(["", "---", ""])

    for case in payload["official_cases"]:
        icon = "PASSED" if case["status"] == "PASSED" else case["status"]
        lines.extend([
            f"## {case['id']} — {case['desc']}",
            "",
            f"| Campo | Valor |",
            f"|-------|-------|",
            f"| **Estado** | **{icon}** |",
            f"| Violaciones | {case['value']} (esperado: {case['expected']}) |",
        ])
        if case.get("note"):
            lines.append(f"| Nota | {case['note']} |")
        lines.extend(["", "### Query de validación", "", sql_block(case["validation_sql"])])
        lines.extend(["### Evidencia", ""])
        ev = case.get("evidence_rows", [])
        lines.append(rows_to_md(ev))
        lines.extend(["---", ""])

    lines.extend(["## Mocks manuales (888001–888004)", ""])
    for mock in payload["mocks_detail"]:
        lines.extend([
            f"### Mock {mock['id']} — {mock['caso']} — **{mock['status']}**",
            "",
            sql_block(mock["sql"]),
            rows_to_md(mock["rows"]),
            "",
        ])

    lines.append(f"\n*Generado automáticamente el {ts}.*\n")
    return "\n".join(lines)


def main():
    if not PWD:
        print("Set REDSHIFT_PASSWORD")
        sys.exit(1)

    conn = psycopg2.connect(
        host=HOST, port=5440, dbname="dba_batch", user="c32525e",
        password=PWD, sslmode="require", connect_timeout=120,
    )
    conn.autocommit = True
    cur = conn.cursor(cursor_factory=RealDictCursor)

    print("Deploying SPs...")
    deploy_sps(cur)
    print("Reset state...")
    reset_state(cur)
    print("CALL R1...")
    cur.execute("CALL bdm_stage.sp_unificacion_regla1()")
    print("CALL R2...")
    cur.execute("CALL bdm_stage.sp_unificacion_regla2()")

    counts = fetch_rows(cur, """
        SELECT 'relacion_persona_ubicacion' lbl, COUNT(*)::bigint n FROM bdm_stage.relacion_persona_ubicacion
        UNION ALL SELECT 'unificacion_r1', COUNT(*) FROM bdm_stage.unificacion_direccion WHERE unifica_atributos=1
        UNION ALL SELECT 'unificacion_r2', COUNT(*) FROM bdm_stage.unificacion_direccion WHERE unifica_atributos=2
        UNION ALL SELECT 'generada_enriquecida', COUNT(*) FROM bdm_stage.direccion_fisica WHERE COALESCE(generada_enriquecida,0)=1
    """)

    results = [run(cur, *c) for c in CASES]
    official_raw = [
        r for r in results
        if not (r["id"] == "TC-R1-01" and "query original" in r.get("desc", "").lower())
    ]

    official_cases = []
    seen = set()
    for r in official_raw:
        cid = r["id"]
        if cid in seen:
            continue
        seen.add(cid)
        ev_sql = EVIDENCE_SQL.get(cid, "")
        ev_rows = fetch_rows(cur, ev_sql) if ev_sql else []
        official_cases.append({
            "id": cid,
            "desc": r["desc"],
            "note": r.get("note", ""),
            "status": r["status"],
            "value": r["value"],
            "expected": r["expected"],
            "validation_sql": r["sql"],
            "evidence_sql": ev_sql.strip(),
            "evidence_rows": ev_rows,
        })

    mock_meta = [
        ("888001", "TC-R1-01 RES→LAB"),
        ("888002", "TC-R2 AP301→IN301"),
        ("888003", "TC-R2-13 diccionario"),
        ("888004", "TC-R2-14 empate"),
    ]
    mocks_detail = []
    for mid, caso in mock_meta:
        sql = MOCK_EVIDENCE[mid]
        rows = fetch_rows(cur, sql)
        if mid == "888004":
            status = "PASSED" if rows and rows[0].get("unificaciones_r2_mock", 1) == 0 else "FAILED"
        elif mid in ("888001", "888002", "888003"):
            status = "PASSED" if rows else "FAILED"
        else:
            status = "UNKNOWN"
        mocks_detail.append({"id": mid, "caso": caso, "status": status, "sql": sql.strip(), "rows": rows})

    passed = sum(1 for c in official_cases if c["status"] == "PASSED")
    payload = {
        "executed_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "host": HOST,
        "pipeline": "reset + CALL R1 + CALL R2 + suite + evidencias",
        "counts": counts,
        "summary": {
            "total_oficial": len(official_cases),
            "passed": passed,
            "failed": len(official_cases) - passed,
            "pct": round(100 * passed / len(official_cases), 1),
        },
        "official_cases": official_cases,
        "mocks_detail": mocks_detail,
    }

    JSON_PATH.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    DOC_PATH.write_text(build_markdown(payload), encoding="utf-8")

    print(json.dumps(payload["summary"], indent=2))
    print(f"Wrote {DOC_PATH}")
    print(f"Wrote {JSON_PATH}")

    cur.close()
    conn.close()


if __name__ == "__main__":
    main()
