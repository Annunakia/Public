"""Generate public-schema variants for Reconocer DEV (db=dba) while bdm_* grants pending."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "sql" / "dev_ifr_datasharing_public"
QA = ROOT / "sql" / "qa_ifr_data"
DEV = ROOT / "sql" / "dev_ifr_datasharing"


def remap(text: str) -> str:
    text = text.replace("bdm_datos.", "public.")
    text = text.replace("bdm_tempo.", "public.")
    text = text.replace("CREATE SCHEMA IF NOT EXISTS bdm_datos;", "-- schema public (ya existe)")
    text = text.replace("CREATE SCHEMA IF NOT EXISTS bdm_tempo;", "-- schema public (ya existe)")
    return text


def write(name: str, content: str, header: str = "") -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    body = header + content if header else content
    (OUT / name).write_text(body, encoding="utf-8")
    print("wrote", name)


def main():
    prereq = """-- TEMPORAL: Reconocer DEV db=dba, schema public (sin permisos bdm_datos/bdm_tempo)
-- catalog_history: solo sistema — no usar para objetos pipeline

CREATE OR REPLACE FUNCTION public.convert_epoch_to_date(val BIGINT)
RETURNS DATE
STABLE
AS $$
  SELECT DATE(TIMESTAMP 'epoch' + ($1 / 1000) * INTERVAL '1 second')
$$ LANGUAGE SQL;
"""
    write("00_prerequisitos_public.sql", prereq)

    ddl = remap((DEV / "01_ddl_unificacion_direccion.sql").read_text(encoding="utf-8"))
    ddl = ddl.replace(
        "01_ddl_unificacion_direccion.sql  (DEV datasharing / Reconocer)",
        "01_ddl_unificacion_direccion.sql  (TEMPORAL public / db=dba)",
    )
    write("01_ddl_unificacion_direccion.sql", ddl)

    vistas = remap((DEV / "00_vistas_insumo_bdm.sql").read_text(encoding="utf-8"))
    vistas = vistas.replace(
        "00_vistas_insumo_bdm.sql  (DEV datasharing / Reconocer)",
        "00_vistas_insumo_bdm.sql  (TEMPORAL public / db=dba)",
    )
    write("00_vistas_insumo_bdm.sql", vistas)

    for sp in ("05_sp_regla1.sql", "06_sp_regla2.sql", "07_sp_regla3.sql"):
        content = remap((QA / sp).read_text(encoding="utf-8"))
        content = f"-- TEMPORAL public schema — revertir a bdm_datos cuando DBA otorgue grants\n{content}"
        write(sp, content)

    exec_sql = remap((QA / "08_ejecucion_secuencial.sql").read_text(encoding="utf-8"))
    write("08_ejecucion_secuencial.sql", exec_sql)

    smoke = remap((DEV / "00_validar_solo_lectura_ifr_data.sql").read_text(encoding="utf-8"))
    write("00_validar_solo_lectura_ifr_data.sql", smoke)

    idx = """-- Orden TEMPORAL — Reconocer DEV database dba, schema public
-- 00_prerequisitos_public.sql
-- 01_ddl_unificacion_direccion.sql
-- 00_vistas_insumo_bdm.sql  (requiere db_ifr_shared montado)
-- 05_sp_regla1.sql -> 07_sp_regla3.sql
-- 08_ejecucion_secuencial.sql
-- Cuando existan grants bdm_*: migrar a sql/dev_ifr_datasharing/
"""
    write("00_EJECUTAR_PUBLIC.sql", idx)

    readme = """# TEMPORAL — Reconocer DEV `dba` / schema `public`

Mientras DBA otorga `bdm_datos` / `bdm_tempo`, desplegar aquí.

| Conexión DBeaver | Valor |
|------------------|-------|
| Host | `eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z...` |
| Database | **`dba`** (no `dba_reconocerbatch`) |
| Schema trabajo | **`public`** |
| IFR (cuando datashare listo) | `db_ifr_shared.ifr_data.*` |

Regenerar SPs/vistas: `py -3 tools/gen_reconocer_public_sql.py`

Runner: `py -3 tools/dev_ifr_datasharing_run.py --public-temp`
"""
    write("README.md", readme)


if __name__ == "__main__":
    main()
