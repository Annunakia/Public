"""Find xpm/alpha tables in productor bdm_datos."""
import os
import psycopg2
from psycopg2.extras import RealDictCursor

HOST = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
PWD = os.environ.get("REDSHIFT_PASSWORD", "b27YWI2FL")

c = psycopg2.connect(
    host=HOST, port=5440, dbname="dba_batch", user="c32525e",
    password=PWD, sslmode="require", connect_timeout=30,
)
c.autocommit = True
cur = c.cursor(cursor_factory=RealDictCursor)

for pattern in ("%xpm%", "%location%", "%counterpart%", "%contactinform%"):
    cur.execute(
        "SELECT table_schema, table_name FROM information_schema.tables "
        "WHERE table_schema IN ('bdm_datos','ifr_data','bdm_tempo','public') "
        "AND LOWER(table_name) LIKE %s ORDER BY 1,2 LIMIT 40",
        (pattern,),
    )
    rows = cur.fetchall()
    if rows:
        print(f"\n=== LIKE {pattern} ===")
        for r in rows:
            print(r["table_schema"], r["table_name"])

# all schemas containing xpm
cur.execute(
    "SELECT DISTINCT table_schema FROM information_schema.tables "
    "WHERE LOWER(table_name) LIKE '%xpm%' ORDER BY 1"
)
print("\n=== schemas with xpm tables ===")
print([r["table_schema"] for r in cur.fetchall()])

for t in [
    "ifr_data.xpm",
    "ifr_data.xpm_location",
    "ifr_data.xpm_location_val_contactinformations",
]:
    try:
        cur.execute(f"SELECT COUNT(*) n FROM {t}")
        print(t, cur.fetchone()["n"])
    except Exception as e:
        print(t, "ERR", str(e).split("\n")[0][:100])

# exact table names per transcription (Alpha in bdm_datos)
cur.execute(
    "SELECT table_name FROM information_schema.tables "
    "WHERE table_schema = 'bdm_datos' AND table_name IN "
    "('xpm','xpm_location','xpm_location_val_contactinformations','xpm_counterparties') "
    "ORDER BY 1"
)
print("\n=== exact Alpha names in bdm_datos ===")
exact = [r["table_name"] for r in cur.fetchall()]
print(exact)
for t in exact:
    cur.execute(f"SELECT COUNT(*) n FROM bdm_datos.{t}")
    print(f"  {t}", cur.fetchone()["n"])

# salida / recent loads (Friday delivery candidates)
cur.execute(
    "SELECT table_name FROM information_schema.tables "
    "WHERE table_schema = 'bdm_datos' AND (table_name LIKE 'dq_salida%' OR table_name LIKE '%202508%') "
    "AND table_name LIKE '%xpm%' ORDER BY table_name DESC LIMIT 20"
)
cands = [r["table_name"] for r in cur.fetchall()]
print("\n=== recent salida xpm prefixes ===")
for name in cands[:5]:
    if "_xpm" in name:
        prefix = name.split("_xpm")[0] + "_xpm"
    else:
        continue
    print("prefix", prefix)
    for suf in ("", "_location", "_location_val_contactinformations", "_counterparties"):
        tn = prefix + suf
        try:
            cur.execute(
                "SELECT 1 FROM information_schema.tables "
                "WHERE table_schema='bdm_datos' AND table_name = %s", (tn.replace("bdm_datos.", ""),)
            )
            if cur.fetchone():
                cur.execute(f"SELECT COUNT(*) n FROM bdm_datos.{tn.replace('bdm_datos.','')}")
                print(" ", tn, cur.fetchone()["n"])
        except Exception:
            pass
    break

c.close()
