"""Pipeline completo DEV — unificación (datashare edf_views) + ordenamiento en consumidor Reconocer."""
from __future__ import annotations

import argparse
import subprocess
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
UNIF = ROOT / "tools" / "dev_edf_datasharing_run.py"
ORD = ROOT / "tools" / "dev_edf_ordenamiento_run.py"
CIERRE = ROOT / "Documentacion" / "Cierre_DEV_DATASHARING_ORDENAMIENTO.md"


def run_step(script: Path, extra: list[str] | None = None) -> int:
    cmd = [sys.executable, str(script)] + (extra or [])
    print(f"\n>>> {' '.join(cmd)}\n", flush=True)
    return subprocess.call(cmd, cwd=str(ROOT))


def main() -> int:
    ap = argparse.ArgumentParser(description="Unificación + ordenamiento EDF en consumidor DEV")
    ap.add_argument("--solo-unificacion", action="store_true")
    ap.add_argument("--solo-ordenamiento", action="store_true")
    ap.add_argument("--fase1-only", action="store_true", help="Solo Fase 1 ordenamiento")
    ap.add_argument("--fase2-only", action="store_true", help="Solo Fase 2 ordenamiento")
    args = ap.parse_args()

    do_unif = not args.solo_ordenamiento
    do_ord = not args.solo_unificacion
    started = datetime.now().isoformat(timespec="seconds")
    rc = 0

    if do_unif:
        rc = run_step(UNIF)
        if rc != 0:
            return rc

    if do_ord:
        ord_args: list[str] = []
        if args.fase1_only:
            ord_args.append("--fase1-only")
        if args.fase2_only:
            ord_args.append("--fase2-only")
        rc = run_step(ORD, ord_args)
        if rc != 0:
            return rc

    finished = datetime.now().isoformat(timespec="seconds")
    CIERRE.write_text(
        "\n".join(
            [
                "# Cierre DEV — Datasharing + Ordenamiento (Reconocer consumidor)",
                "",
                f"Inicio: {started}",
                f"Fin: {finished}",
                f"Exit code: {rc}",
                "",
                "## Alcance ejecutado",
                "",
                f"- Unificación: {'Sí' if do_unif else 'No'} (`tools/dev_edf_datasharing_run.py`)",
                f"- Ordenamiento: {'Sí' if do_ord else 'No'} (`tools/dev_edf_ordenamiento_run.py`)",
                "",
                "## Evidencias",
                "",
                "- `Documentacion/Evidencias_DEV_EDF_DATASHARING.md`",
                "- `Documentacion/Evidencias_DEV_ORDENAMIENTO_EDF_COMPLETO.md`",
                "- `Documentacion/Evidencias_DEV_TIMINGS_DATASHARING.md`",
                "",
                "## Comando único",
                "",
                "```powershell",
                '$env:REDSHIFT_CONSUMER_PASSWORD="<pwd>"',
                "py -3 tools/dev_edf_pipeline_completo_run.py",
                "```",
                "",
            ]
        ),
        encoding="utf-8",
    )
    print(f"\nCierre: {CIERRE}")
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
