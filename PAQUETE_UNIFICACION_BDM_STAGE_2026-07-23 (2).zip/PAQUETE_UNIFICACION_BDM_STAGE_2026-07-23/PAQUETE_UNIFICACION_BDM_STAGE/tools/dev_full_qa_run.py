"""
DEV end-to-end: load mocks, run R2, full QA suite.
Host DEV real: cee2enck00mg (no cwefyckvccgy — ese es QA)
"""
import json
import os
import sys
from datetime import datetime

import psycopg2
from psycopg2.extras import RealDictCursor

HOST = os.environ.get(
    "REDSHIFT_HOST",
    "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com",
)
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PASSWORD = os.environ.get("REDSHIFT_PASSWORD", "")

MOCKS = [
    dict(id=888001, pin=1888001, ubic=888001001, df1=888001101, df2=888001102, rpu1=888001001, rpu2=888001002,
         texto="CL 45 12 33 MOCK DEV RES-LAB", c1="", c2="", tipo1=1, tipo2=2,
         scenario="MOCK_TC_R1_01", reports=[(888001001,901),(888001002,902),(888001002,903),(888001002,904),(888001002,905)], dic=[]),
    dict(id=888002, pin=1888002, ubic=888002001, df1=888002101, df2=888002102, rpu1=888002001, rpu2=888002002,
         texto="CL 45 12 33 MOCK DEV AP301-IN301", c1="AP 301", c2="IN 301", tipo1=1, tipo2=1,
         scenario="MOCK_TC_R2_COMP", reports=[(888002001,901),(888002001,902),(888002002,903)], dic=[]),
    dict(id=888003, pin=1888003, ubic=888003001, df1=888003101, df2=888003102, rpu1=888003001, rpu2=888003002,
         texto="CL 80 55 18 MOCK DEV TC-R2-13", c1="CS 5", c2="PI 5", tipo1=1, tipo2=1,
         scenario="MOCK_TC_R2_13", reports=[(888003001,911),(888003001,912),(888003001,913),(888003002,914),(888003002,915)],
         dic=[("CS 5","CS","5",10),("PI 5","PI","5",4)]),
    dict(id=888004, pin=1888004, ubic=888004001, df1=888004101, df2=888004102, rpu1=888004001, rpu2=888004002,
         texto="CL 95 18 42 MOCK DEV TC-R2-14", c1="CS 8", c2="PI 8", tipo1=1, tipo2=1,
         scenario="MOCK_TC_R2_14", reports=[(888004001,921),(888004001,922),(888004002,923),(888004002,924)],
         dic=[("CS 8","CS","8",10),("PI 8","PI","8",10)]),
]


def q(cur, sql):
    cur.execute(sql)
    cols = [d[0] for d in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchall()]


def load_mock(cur, m):
    cur.execute("SELECT COUNT(*) AS n FROM bdm_stage.relacion_persona_ubicacion WHERE id_buro_persona=%s", (m["id"],))
    row = cur.fetchone()
    n = row["n"] if isinstance(row, dict) else row[0]
    if n > 0:
        return "exists"
    cur.execute("INSERT INTO bdm_stage.ubicacion_estandarizada VALUES (%s,%s,1,NULL,NULL)", (m["ubic"], m["texto"]))
    cur.execute(
        "INSERT INTO bdm_stage.direccion_fisica VALUES (%s,%s,%s,'CL','45','12','33',NULL),(%s,%s,%s,'CL','45','12','33',NULL)",
        (m["df1"], m["c1"], m["ubic"], m["df2"], m["c2"], m["ubic"]),
    )
    cur.execute("INSERT INTO bdm_stage.ciiu_persona VALUES (%s,'10')", (m["id"],))
    cur.execute(
        """INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
           (%s,%s,%s,%s,%s,%s,NULL,1,DATE '2025-06-01',99,1),
           (%s,%s,%s,%s,%s,%s,NULL,2,DATE '2025-06-01',99,1)""",
        (m["rpu1"], m["id"], m["pin"], m["ubic"], m["df1"], m["tipo1"],
         m["rpu2"], m["id"], m["pin"], m["ubic"], m["df2"], m["tipo2"]),
    )
    for rpu, sub in m["reports"]:
        cur.execute("INSERT INTO bdm_stage.reporte_relacion_persona_ubica VALUES (%s,%s,DATE '2025-05-01',99)", (rpu, sub))
    for nom, nomen, val, freq in m["dic"]:
        cur.execute(
            "INSERT INTO bdm_stage.diccionario_complementos VALUES (%s,%s,%s,%s,%s,%s)",
            (m["ubic"], m["id"], nom, nomen, val, freq),
        )
    cur.execute(
        "DELETE FROM bdm_stage.perf_persona_meta WHERE id_buro_persona=%s", (m["id"],)
    )
    cur.execute("INSERT INTO bdm_stage.perf_persona_meta VALUES (%s,%s,%s)", (m["id"], m["id"], m["scenario"]))
    return "inserted"


def run_suite(conn):
    cases = []
    cur = conn.cursor()

    def add(cid, desc, sql):
        cur.execute(sql)
        val = cur.fetchone()[0]
        cases.append({"id": cid, "desc": desc, "value": int(val), "status": "PASSED" if int(val) == 0 else "FAILED"})

    add("TC-R1-01", "R1_ESC1 CIIU10 padre LAB",
        """SELECT COUNT(*) AS v FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic=u.cod_dw_persona_ubic
        JOIN bdm_stage.relacion_persona_ubicacion rp ON rp.cod_dw_persona_ubic=u.cod_dw_direccion_unificada
        JOIN bdm_stage.ciiu_persona c ON c.id_buro_persona=rh.id_buro_persona
        JOIN bdm_stage.tipo_ubicacion_dir tp ON tp.cod_dw_tipo_ubicacion_dir=rp.cod_dw_tipo_ubicacion_dir
        JOIN bdm_stage.perf_persona_meta m ON m.id_buro_persona=rh.id_buro_persona
        WHERE u.unifica_atributos=1 AND c.cod_act_econo_ciiu_fte='10'
          AND tp.descripcion_tipo_ubicacion_dir NOT IN ('LAB','CRR') AND m.scenario_code='R1_ESC1'""")

    for cid, sql in [
        ("TC-R1-02", "SELECT COUNT(*) AS v FROM bdm_stage.unificacion_direccion u JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic=u.cod_dw_persona_ubic JOIN bdm_stage.relacion_persona_ubicacion rp ON rp.cod_dw_persona_ubic=u.cod_dw_direccion_unificada JOIN bdm_stage.ciiu_persona c ON c.id_buro_persona=rh.id_buro_persona JOIN bdm_stage.tipo_ubicacion_dir tp ON tp.cod_dw_tipo_ubicacion_dir=rp.cod_dw_tipo_ubicacion_dir WHERE u.unifica_atributos=1 AND c.cod_act_econo_ciiu_fte IN ('81','82','90') AND tp.descripcion_tipo_ubicacion_dir NOT IN ('RES','CRR')"),
        ("TC-R1-04", "SELECT COUNT(*) AS v FROM bdm_stage.unificacion_direccion u JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic=u.cod_dw_persona_ubic WHERE u.unifica_atributos=1 AND COALESCE(r.ind_unificacion,0)<>1"),
        ("TC-R1-05", "SELECT COUNT(*) AS v FROM bdm_stage.unificacion_direccion WHERE unifica_atributos=1 AND (cod_dw_persona_ubic IS NULL OR cod_dw_direccion_unificada IS NULL OR fecha_unificacion IS NULL)"),
        ("TC-R1-08", "SELECT COUNT(*) AS v FROM bdm_stage.perf_persona_meta m JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona=m.id_buro_persona JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic=r.cod_dw_persona_ubic WHERE m.scenario_code='R1_EMPATE' AND u.unifica_atributos=1"),
        ("TC-R2-05", "SELECT COUNT(*) AS v FROM bdm_stage.perf_persona_meta m WHERE m.scenario_code IN ('R2_ESC4','R2_ESC4_DIC') AND NOT EXISTS (SELECT 1 FROM bdm_stage.relacion_persona_ubicacion r JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic=r.cod_dw_persona_ubic AND u.unifica_atributos=2 WHERE r.id_buro_persona=m.id_buro_persona)"),
        ("TC-R2-09", "SELECT COUNT(*) AS v FROM bdm_stage.direccion_fisica df LEFT JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_direccion_fisica=df.cod_dw_direccion_fisica WHERE COALESCE(df.generada_enriquecida,0)=1 AND r.cod_dw_persona_ubic IS NULL"),
        ("TC-R2-10", "SELECT COUNT(*) AS v FROM bdm_stage.unificacion_direccion u JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic=u.cod_dw_direccion_unificada WHERE u.unifica_atributos=2 AND COALESCE(r.ind_unificacion,0)=1"),
        ("TC-R2-11", "SELECT COUNT(*) AS v FROM (SELECT cod_dw_persona_ubic FROM bdm_stage.unificacion_direccion WHERE unifica_atributos=2 GROUP BY 1 HAVING COUNT(DISTINCT cod_dw_direccion_unificada)<>1) t"),
        ("TC-R2-13", "SELECT COUNT(*) AS v FROM bdm_stage.perf_persona_meta m WHERE m.scenario_code='R2_ESC4_DIC' AND NOT EXISTS (SELECT 1 FROM bdm_stage.relacion_persona_ubicacion r JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic=r.cod_dw_persona_ubic AND u.unifica_atributos=2 WHERE r.id_buro_persona=m.id_buro_persona)"),
        ("TC-R2-14", "SELECT COUNT(*) AS v FROM bdm_stage.perf_persona_meta m WHERE m.scenario_code='R2_EMPATE' AND EXISTS (SELECT 1 FROM bdm_stage.relacion_persona_ubicacion r JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic=r.cod_dw_persona_ubic AND u.unifica_atributos=2 WHERE r.id_buro_persona=m.id_buro_persona)"),
        ("TC-G-07", "SELECT COUNT(*) AS v FROM bdm_stage.unificacion_direccion u JOIN bdm_stage.relacion_persona_ubicacion h ON h.cod_dw_persona_ubic=u.cod_dw_persona_ubic JOIN bdm_stage.relacion_persona_ubicacion p ON p.cod_dw_persona_ubic=u.cod_dw_direccion_unificada WHERE h.id_buro_persona<>p.id_buro_persona"),
    ]:
        add(cid, cid, sql)

    return cases


def mock_checks(conn):
    cur = conn.cursor(cursor_factory=RealDictCursor)
    out = {}
    # TC-R1-01 mock 888001
    r = q(cur, """
        SELECT CASE WHEN COUNT(*)=1 AND MAX(u.cod_dw_direccion_unificada)=888001002
                    AND MAX(u.cod_dw_persona_ubic)=888001001 THEN 'PASSED' ELSE 'FAILED' END estado
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic=u.cod_dw_persona_ubic
        WHERE rh.id_buro_persona=888001 AND u.unifica_atributos=1
    """)[0]
    out["MOCK_888001_TC-R1-01"] = r["estado"]

    r = q(cur, """
        SELECT CASE WHEN COUNT(*)=1 AND MAX(u.cod_dw_direccion_unificada)=888003001
                    AND MAX(u.cod_dw_persona_ubic)=888003002 THEN 'PASSED' ELSE 'FAILED' END estado
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic=u.cod_dw_persona_ubic
        WHERE rh.id_buro_persona=888003 AND u.unifica_atributos=2
    """)[0]
    out["MOCK_888003_TC-R2-13"] = r["estado"]

    r = q(cur, """
        SELECT CASE WHEN COUNT(*)=0 THEN 'PASSED' ELSE 'FAILED' END estado
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic=u.cod_dw_persona_ubic
        WHERE rh.id_buro_persona=888004 AND u.unifica_atributos=2
    """)[0]
    out["MOCK_888004_TC-R2-14"] = r["estado"]
    return out


def main():
    report = {"host": HOST, "executed_at": datetime.now().isoformat()}
    conn = psycopg2.connect(host=HOST, port=5440, dbname="dba_batch", user=USER, password=PASSWORD, sslmode="require", connect_timeout=60)
    cur = conn.cursor(cursor_factory=RealDictCursor)

    report["smoke"] = q(cur, """
        SELECT 'rpu' lbl, COUNT(*) n FROM bdm_stage.relacion_persona_ubicacion
        UNION ALL SELECT 'unif', COUNT(*) FROM bdm_stage.unificacion_direccion
    """)

    report["load"] = {}
    conn.autocommit = True
    wcur = conn.cursor(cursor_factory=RealDictCursor)
    for m in MOCKS:
        try:
            report["load"][m["id"]] = load_mock(wcur, m)
        except Exception as e:
            report["load"][m["id"]] = f"error: {e}"
    procs = ["CALL bdm_stage.sp_unificacion_regla1()", "CALL bdm_stage.sp_unificacion_regla2()"]
    report["procs"] = {}
    for p in procs:
        try:
            cur.execute(p)
            report["procs"][p] = "ok"
        except Exception as e:
            report["procs"][p] = str(e)

    report["benchmark_suite"] = run_suite(conn)
    report["mock_validation"] = mock_checks(conn)
    passed = sum(1 for c in report["benchmark_suite"] if c["status"] == "PASSED")
    report["summary"] = {
        "benchmark_passed": passed,
        "benchmark_total": len(report["benchmark_suite"]),
        "benchmark_failed": [c for c in report["benchmark_suite"] if c["status"] == "FAILED"],
    }
    print(json.dumps(report, indent=2, default=str))
    cur.close()
    conn.close()


if __name__ == "__main__":
    if not PASSWORD:
        print("Set REDSHIFT_PASSWORD")
        sys.exit(1)
    main()
