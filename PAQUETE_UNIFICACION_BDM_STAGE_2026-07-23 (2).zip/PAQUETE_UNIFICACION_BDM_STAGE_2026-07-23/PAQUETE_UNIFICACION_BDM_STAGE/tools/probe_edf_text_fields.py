import os, psycopg2
from psycopg2.extras import RealDictCursor

c = psycopg2.connect(
    host="eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com",
    port=5440, dbname="dba_batch", user="c32525e",
    password=os.environ.get("REDSHIFT_PASSWORD", "b27YWI2FL"), sslmode="require",
)
c.autocommit = True
cur = c.cursor(cursor_factory=RealDictCursor)

cur.execute("""
    SELECT
      SUM(CASE WHEN NULLIF(TRIM(ci."location.val.contactinformations.val.standardizedtextoubicacion"::varchar),'') IS NOT NULL THEN 1 ELSE 0 END) AS has_std_text,
      SUM(CASE WHEN NULLIF(TRIM(ci."location.val.contactinformations.val.contactasreportedstandardized"::varchar),'') IS NOT NULL THEN 1 ELSE 0 END) AS has_rep_std,
      SUM(CASE WHEN NULLIF(TRIM(ci."location.val.contactinformations.val.contactasreported"::varchar),'') IS NOT NULL THEN 1 ELSE 0 END) AS has_rep,
      COUNT(*) AS total
    FROM edf_views.xpm xpm
    JOIN edf_views.xpm_location loc ON xpm.location = loc.id
    JOIN edf_views.xpm_location_val_contactinformations ci
      ON loc."location.val.contactinformations" = ci.id
    WHERE NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::varchar),'') IN ('1','2','3','7')
""")
print("raw text counts:", cur.fetchone())

cur.execute("""
    SELECT
      ci."location.val.contactinformations.val.standardizedtextoubicacion" AS a,
      ci."location.val.contactinformations.val.contactasreportedstandardized" AS b,
      ci."location.val.contactinformations.val.contactasreported" AS c
    FROM edf_views.xpm xpm
    JOIN edf_views.xpm_location loc ON xpm.location = loc.id
    JOIN edf_views.xpm_location_val_contactinformations ci
      ON loc."location.val.contactinformations" = ci.id
    WHERE NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::varchar),'') IN ('1','2','3','7')
    LIMIT 5
""")
print("samples:", cur.fetchall())
c.close()
