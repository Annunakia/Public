"""DEV edf_views datasharing — deploy + run on Reconocer Batch DEV."""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path

import psycopg2
from psycopg2.extras import RealDictCursor

ROOT = Path(__file__).resolve().parents[1]
DEV_SQL = ROOT / "sql" / "dev_edf_datasharing"
QA_SQL = ROOT / "sql" / "qa_ifr_data"
DOC_OUT = ROOT / "Documentacion" / "Evidencias_DEV_EDF_DATASHARING.md"

CONSUMER_HOST = os.environ.get(
    "REDSHIFT_CONSUMER_HOST",
    "eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com",
)
PRODUCER_HOST = os.environ.get(
    "REDSHIFT_PRODUCER_HOST",
    "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com",
)
PORT = int(os.environ.get("REDSHIFT_PORT", "5440"))
CONSUMER_DB = os.environ.get("REDSHIFT_CONSUMER_DB", "dba_rncr_batch")
USER = os.environ.get("REDSHIFT_USER", "c32525e")
CONSUMER_PASSWORD = os.environ.get("REDSHIFT_CONSUMER_PASSWORD", os.environ.get("REDSHIFT_PASSWORD", ""))
PRODUCER_PASSWORD = os.environ.get("REDSHIFT_PRODUCER_PASSWORD", os.environ.get("REDSHIFT_PASSWORD", ""))
PRODUCER_DB = os.environ.get("REDSHIFT_PRODUCER_DB", "dba_batch")

STAGES = [
    ("preflight", None),
    ("prerequisitos", DEV_SQL / "00_prerequisitos_dev.sql"),
    ("ddl", DEV_SQL / "01_ddl_unificacion_direccion.sql"),
    ("vistas", DEV_SQL / "00_vistas_insumo_bdm.sql"),
    ("smoke", DEV_SQL / "00_validar_solo_lectura_edf_views.sql"),
    ("deploy_sp_r1", QA_SQL / "05_sp_regla1.sql"),
    ("deploy_sp_r2", QA_SQL / "06_sp_regla2.sql"),
    ("deploy_sp_r3", QA_SQL / "07_sp_regla3.sql"),
    ("execute", QA_SQL / "08_ejecucion_secuencial.sql"),
    ("validaciones", QA_SQL / "03_validaciones_unificacion.sql"),
]

PREFLIGHT_CONSUMER = [
    ("session", "SELECT current_user AS u, current_database() AS db"),
    ("namespace", "SELECT pg_get_cluster_namespace() AS ns"),
    ("datashares", "SELECT share_name, producer_account FROM svv_datashares LIMIT 20"),
    ("external_dbs", "SELECT database_name FROM svv_external_databases LIMIT 20"),
    ("edf_count", """
        SELECT 'xpm' AS t, COUNT(*) AS n FROM ds_dba_rncr_batch.edf_views.xpm
        UNION ALL SELECT 'xpm_ci', COUNT(*) FROM ds_dba_rncr_batch.edf_views.xpm_location_val_contactinformations
    """),
    ("create_priv", """
        SELECT has_schema_privilege('c32525e','bdm_tempo','CREATE') AS c_tempo,
               has_schema_privilege('c32525e','bdm_datos','CREATE') AS c_datos
    """),
]

PREFLIGHT_PRODUCER = [
    ("producer_shares", "SELECT share_name FROM svv_datashares WHERE share_name ILIKE '%edf%'"),
    ("producer_objects", """
        SELECT share_name, object_name FROM svv_datashare_objects
        WHERE share_name = 'ds_reconocer_procesosbatch_dev' ORDER BY object_name
    """),
    ("producer_counts", """
        SELECT 'edf_views.xpm' AS t, COUNT(*) AS n FROM edf_views.xpm
        UNION ALL SELECT 'edf_views.xpm_ci', COUNT(*) FROM edf_views.xpm_location_val_contactinformations
    """),
]


def rows_to_dicts(cur) -> list[dict]:
    if not cur.description:
        return []
    rows = cur.fetchall()
    if rows and hasattr(rows[0], "keys"):
        return [dict(r) for r in rows]
    cols = [d[0] for d in cur.description]
    return [dict(zip(cols, r)) for r in rows]


def split_sql(text: str) -> list[str]:
    parts = re.split(r";\s*\n", text)
    out = []
    for p in parts:
        stmt = p.strip()
        if not stmt:
            continue
        lines = [ln for ln in stmt.splitlines() if ln.strip() and not ln.strip().startswith("--")]
        if not lines:
            continue
        out.append(stmt if stmt.endswith(";") else stmt + ";")
    return out


def connect(host: str, dbname: str, password: str):
    return psycopg2.connect(
        host=host, port=PORT, dbname=dbname, user=USER,
        password=password, sslmode="require", connect_timeout=60,
    )


def run_file(cur, path: Path, label: str) -> dict:
    sql = path.read_text(encoding="utf-8-sig")
    if label.startswith("deploy_sp") or label in ("prerequisitos", "ddl", "vistas"):
        try:
            cur.execute(sql)
            return {"label": label, "file": path.name, "ok": True, "error": None}
        except Exception as e:
            cur.connection.rollback()
            return {"label": label, "file": path.name, "ok": False, "error": str(e)}
    errors, result_sets = [], []
    for stmt in split_sql(sql):
        try:
            cur.execute(stmt)
            if cur.description:
                result_sets.append({"statement": stmt[:160], "rows": rows_to_dicts(cur)})
        except Exception as e:
            cur.connection.rollback()
            errors.append({"statement": stmt[:160], "error": str(e)})
    return {"label": label, "file": path.name, "ok": len(errors) == 0, "errors": errors, "result_sets": result_sets}


def preflight_all() -> dict:
    out = {"consumer": {}, "producer": {}, "gaps": [], "ok": True}
    try:
        c = connect(CONSUMER_HOST, CONSUMER_DB, CONSUMER_PASSWORD)
        c.autocommit = True
        cur = c.cursor(cursor_factory=RealDictCursor)
        for name, sql in PREFLIGHT_CONSUMER:
            try:
                cur.execute(sql)
                out["consumer"][name] = rows_to_dicts(cur) if cur.description else []
            except Exception as e:
                c.rollback()
                out["consumer"][name] = {"error": str(e).split(chr(10))[0][:200]}
                if name in ("edf_count",):
                    out["gaps"].append(f"BLOQUEANTE consumidor: {name} — {e}")
                    out["ok"] = False
        c.close()
    except Exception as e:
        out["consumer"]["connection"] = {"error": str(e)}
        out["gaps"].append(f"BLOQUEANTE: no conecta consumidor — {e}")
        out["ok"] = False

    try:
        p = connect(PRODUCER_HOST, PRODUCER_DB, PRODUCER_PASSWORD)
        p.autocommit = True
        cur = p.cursor(cursor_factory=RealDictCursor)
        for name, sql in PREFLIGHT_PRODUCER:
            try:
                cur.execute(sql)
                out["producer"][name] = rows_to_dicts(cur) if cur.description else []
            except Exception as e:
                p.rollback()
                out["producer"][name] = {"error": str(e).split(chr(10))[0][:200]}
        p.close()
    except Exception as e:
        out["producer"]["connection"] = {"error": str(e)}

    shares = out["producer"].get("producer_shares", [])
    if isinstance(shares, list) and not any(
        isinstance(r, dict) and r.get("share_name") == "ds_reconocer_procesosbatch_dev" for r in shares
    ):
        out["gaps"].append("PENDIENTE DBA productor: datashare ds_reconocer_procesosbatch_dev no visible")

    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--preflight-only", action="store_true")
    ap.add_argument("--through", choices=[s[0] for s in STAGES if s[0] != "preflight"])
    args = ap.parse_args()

    if not CONSUMER_PASSWORD:
        print("Set REDSHIFT_CONSUMER_PASSWORD or REDSHIFT_PASSWORD", file=sys.stderr)
        return 1

    pf = preflight_all()
    print("=== PREFLIGHT ===")
    print(json.dumps(pf, indent=2, default=str)[:4000])
    for g in pf["gaps"]:
        print("!", g)

    if args.preflight_only:
        _write_doc([{"label": "preflight", "ok": pf["ok"], "preflight": pf}], pf)
        return 0 if pf["ok"] else 1

    if not pf["ok"]:
        print("\nDatashare no listo. Enviar ticket DBA y reintentar.", file=sys.stderr)
        _write_doc([{"label": "blocked", "ok": False, "preflight": pf}], pf)
        return 1

    log = [{"label": "preflight", "ok": True, "preflight": pf}]
    conn = connect(CONSUMER_HOST, CONSUMER_DB, CONSUMER_PASSWORD)
    conn.autocommit = True
    cur = conn.cursor(cursor_factory=RealDictCursor)

    stop_at = args.through
    for label, path in STAGES[1:]:
        if path and not path.exists():
            log.append({"label": label, "ok": False, "error": f"missing {path}"})
            break
        print(f"[{label}] ...", end=" ", flush=True)
        if path:
            r = run_file(cur, path, label)
        else:
            r = {"label": label, "ok": True}
        log.append(r)
        print("OK" if r.get("ok") else "FAIL")
        if not r.get("ok"):
            print(r.get("error") or r.get("errors"))
            break
        if stop_at == label:
            break

    summary = []
    try:
        cur.execute("""
            SELECT unifica_atributos, COUNT(*) AS n
            FROM bdm_datos.unificacion_direccion GROUP BY 1 ORDER BY 1
        """)
        summary = rows_to_dicts(cur)
        print("Salida:", summary)
    except Exception:
        pass
    cur.close()
    conn.close()
    _write_doc(log, pf, summary)
    return 0 if all(x.get("ok") for x in log) else 1


def _write_doc(log, pf, summary=None):
    lines = [
        f"# Evidencias DEV EDF Datasharing\n",
        f"Fecha: {datetime.now().isoformat(timespec='seconds')}\n\n",
        "## Preflight gaps\n",
    ]
    for g in pf.get("gaps", []):
        lines.append(f"- {g}\n")
    ns = pf.get("consumer", {}).get("namespace")
    if ns:
        lines.append(f"\nNamespace consumidor: `{ns}`\n")
    lines.append("\n## Stages\n")
    for r in log:
        lines.append(f"- **{r['label']}**: {'OK' if r.get('ok') else 'FAIL'}\n")
    if summary:
        lines.append(f"\n## Salida\n```json\n{json.dumps(summary, indent=2, default=str)}\n```\n")
    DOC_OUT.write_text("".join(lines), encoding="utf-8")
    print(f"Report: {DOC_OUT}")


if __name__ == "__main__":
    raise SystemExit(main())
