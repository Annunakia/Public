"""Textos «qué busca» y metadatos del drill-down — lenguaje sencillo."""
from __future__ import annotations

# regla, codigo → explicación en palabras de todos los días
BUSCA: dict[tuple[str, str], str] = {
    ("UNIVERSO", "TEMA"): (
        "Todas las personas y todos sus reportes de dirección, antes de aplicar cualquier regla."
    ),
    ("UNIVERSO", "POST-R2"): (
        "Lo que queda activo después de que la regla 2 absorbe reportes duplicados."
    ),
    ("R1", "INSUMO"): (
        "Cómo viene marcada cada dirección en los datos de origen: "
        "casa, trabajo, correspondencia o token."
    ),
    ("R1", "PRE-R1"): (
        "Personas que en la misma calle y ciudad tienen al menos dos usos distintos "
        "(por ejemplo casa y trabajo, o casa y correspondencia)."
    ),
    ("R1", "PRE-R1-FUERA"): (
        "Personas con un solo uso en esa calle, o con casa y trabajo en calles diferentes."
    ),
    ("R1", "ESC1"): (
        "Si la persona tiene actividad de comercio, gana trabajo o correspondencia frente a casa."
    ),
    ("R1", "ESC2"): (
        "Si tiene actividad de servicios, gana casa o correspondencia frente a los demás usos."
    ),
    ("R1", "ESC3"): (
        "En cualquier otra actividad, gana el uso que más entidades distintas reportaron."
    ),
    ("R1", "EMPATE"): (
        "Dos o más usos (casa, trabajo, correspondencia) quedaron con el mismo puntaje: "
        "no se elige ganador y no se unifica."
    ),
    ("R1", "SALIDA"): (
        "Reportes que la regla 1 habría absorbido si hubiera un ganador claro."
    ),
    ("R2", "INSUMO"): (
        "Direcciones de correspondencia «token» (código 8) donde el detalle extra viaja en el token."
    ),
    ("R2", "ESC1"): (
        "Misma persona, misma calle y mismo uso: una fila trae apto u oficina y la otra no — "
        "gana la que tiene el detalle."
    ),
    ("R2", "ESC2"): (
        "Un detalle contiene al otro (ejemplo: «LOCAL 5 PISO 2» contiene «LOCAL 5»)."
    ),
    ("R2", "ESC3"): (
        "Misma palabra de catálogo pero número distinto (LOCAL 5 vs LOCAL 6); solo personas, no empresas."
    ),
    ("R2", "ESC4"): (
        "Gana el detalle que más veces aparece en el diccionario, si hay un solo ganador."
    ),
    ("R2", "ESC5"): (
        "Gana el detalle de nivel más alto (edificio por encima de apartamento)."
    ),
    ("R2", "ESC6"): (
        "Último desempate: el detalle más frecuente en todo el diccionario."
    ),
    ("R2", "MOTOR"): (
        "Para empresas (NIT): junta complementos en un reporte enriquecido; "
        "solo paso intermedio, no es la salida principal en DEV."
    ),
    ("R2", "SIN PAR"): (
        "Personas y reportes que no encontraron duplicado por detalle en la regla 2."
    ),
    ("R2", "SALIDA"): (
        "Reportes absorbidos por la regla 2 (el hijo pasa a vivir bajo el padre)."
    ),
    ("R3", "PRE-R3"): (
        "Direcciones que traen latitud y longitud — sin mapa no corre la regla 3."
    ),
    ("R3", "ESC1"): (
        "Misma persona y municipio: calles muy parecidas en el mapa; gana quien más reporta."
    ),
    ("R3", "SALIDA"): (
        "Reportes que la regla 3 habría unificado usando el mapa."
    ),
}

ORDER = [
    ("UNIVERSO", "TEMA"),
    ("UNIVERSO", "POST-R2"),
    ("R1", "INSUMO"),
    ("R1", "PRE-R1"),
    ("R1", "PRE-R1-FUERA"),
    ("R1", "ESC1"),
    ("R1", "ESC2"),
    ("R1", "ESC3"),
    ("R1", "EMPATE"),
    ("R1", "SALIDA"),
    ("R2", "INSUMO"),
    ("R2", "ESC1"),
    ("R2", "ESC2"),
    ("R2", "ESC3"),
    ("R2", "ESC4"),
    ("R2", "ESC5"),
    ("R2", "ESC6"),
    ("R2", "MOTOR"),
    ("R2", "SIN PAR"),
    ("R2", "SALIDA"),
    ("R3", "PRE-R3"),
    ("R3", "ESC1"),
    ("R3", "SALIDA"),
]

LABEL: dict[tuple[str, str], str] = {
    ("UNIVERSO", "TEMA"): "Entrada total",
    ("UNIVERSO", "POST-R2"): "Activos después de regla 2",
    ("R1", "PRE-R1-FUERA"): "No entran a regla 1",
    ("R2", "SIN PAR"): "Sin pareja en regla 2",
}


def busca(regla: str, codigo: str) -> str:
    return BUSCA.get((regla, codigo), "")


def etiqueta(regla: str, codigo: str) -> str:
    if (regla, codigo) in LABEL:
        return LABEL[(regla, codigo)]
    if codigo == "PRE-R1":
        return "Entran a regla 1"
    if codigo == "PRE-R3":
        return "Con coordenadas en mapa"
    if codigo == "SALIDA":
        return "Salida unificaciones"
    if codigo == "INSUMO":
        return "Datos de origen"
    if codigo == "MOTOR":
        return "Motor empresas (NIT)"
    if codigo == "EMPATE":
        return "Empate — nadie gana"
    return codigo
