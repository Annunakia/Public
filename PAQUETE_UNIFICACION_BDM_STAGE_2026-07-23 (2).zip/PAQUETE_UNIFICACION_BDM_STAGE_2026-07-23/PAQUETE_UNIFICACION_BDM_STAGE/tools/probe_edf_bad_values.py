"""Find cast-breaking values in edf_views via our views."""
import os, psycopg2
from psycopg2.extras import RealDictCursor

c = psycopg2.connect(
    host="eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com",
    port=5440, dbname="dba_batch", user="c32525e",
    password=os.environ.get("REDSHIFT_PASSWORD", "b27YWI2FL"), sslmode="require",
)
c.autocommit = True
cur = c.cursor(cursor_factory=RealDictCursor)

queries = [
    ("bad_score", """
        SELECT COUNT(*) n FROM bdm_tempo.v_xpm_contacto_direccion
        WHERE score_estandarizacion IS NULL
    """),
    ("bad_dane", """
        SELECT cod_dw_ciudad, COUNT(*) n
        FROM bdm_tempo.v_xpm_contacto_direccion
        WHERE cod_dw_ciudad IS NULL OR cod_dw_ciudad > 2147483647
        GROUP BY 1 ORDER BY n DESC LIMIT 5
    """),
    ("raw_dane_samples", """
        SELECT ci."location.val.contactinformations.val.standardizeddanecode" AS raw
        FROM edf_views.xpm xpm
        JOIN edf_views.xpm_location loc ON xpm.location = loc.id
        JOIN edf_views.xpm_location_val_contactinformations ci
          ON loc."location.val.contactinformations" = ci.id
        WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1,2,3,7)
          AND (ci."location.val.contactinformations.val.standardizeddanecode" IS NULL
            OR TRIM(ci."location.val.contactinformations.val.standardizeddanecode") = ''
            OR ci."location.val.contactinformations.val.standardizeddanecode" !~ '^[0-9]+$')
        LIMIT 10
    """),
    ("bad_cp", """
        SELECT COUNT(*) n FROM edf_views.xpm_counterparties cp
        WHERE cp."counterparties.val.counterpartyidnumber" IS NULL
           OR TRIM(cp."counterparties.val.counterpartyidnumber"::varchar) = ''
           OR cp."counterparties.val.counterpartyidnumber" !~ '^[0-9]+$'
    """),
    ("bad_ciiu", """
        SELECT xpm."bestpersonalinformation.mainisiccodeforproduct" AS ciiu, COUNT(*) n
        FROM edf_views.xpm xpm
        WHERE xpm."bestpersonalinformation.mainisiccodeforproduct" IS NOT NULL
        GROUP BY 1 ORDER BY n DESC LIMIT 10
    """),
    ("test_r1_select", """
        SELECT COUNT(*) n FROM (
          SELECT rpu.cod_dw_persona_ubic, COALESCE(ciiu.cod_act_econo_ciiu_fte, '') AS c
          FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
          LEFT JOIN bdm_tempo.v_xpm_ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona
          LIMIT 1000
        ) x
    """),
]
for name, q in queries:
    print(f"\n--- {name} ---")
    try:
        cur.execute(q)
        print(cur.fetchall()[:10])
    except Exception as e:
        print("ERR", str(e).split("\n")[0][:200])

# score empty raw
cur.execute("""
    SELECT COUNT(*) n FROM edf_views.xpm_location_val_contactinformations ci
    WHERE TRIM(COALESCE(ci."location.val.contactinformations.val.contactasstandardizedscore"::varchar,'')) = ''
""")
print("\n--- empty score raw ---", cur.fetchone())

cur.execute("""
    SELECT ci."location.val.contactinformations.val.contactasstandardizedscore" AS s, COUNT(*) n
    FROM edf_views.xpm_location_val_contactinformations ci
    WHERE ci."location.val.contactinformations.val.contactasstandardizedscore" IS NOT NULL
      AND ci."location.val.contactinformations.val.contactasstandardizedscore"::varchar !~ '^[0-9]*(\\.[0-9]+)?$'
    GROUP BY 1 LIMIT 5
""")
cur.execute("""
    SELECT ci."location.val.contactinformations.val.standardizeddanecode" AS dane, COUNT(*) AS n
    FROM edf_views.xpm_location_val_contactinformations ci
    GROUP BY 1 ORDER BY n DESC LIMIT 15
""")
print("\n--- dane samples ---", cur.fetchall())

cur.execute("""
    SELECT cp."counterparties.val.counterpartyidnumber" AS v, COUNT(*) AS n
    FROM edf_views.xpm_counterparties cp
    WHERE cp."counterparties.val.counterpartyidnumber" ~ '^[0-9]+$'
      AND CAST(cp."counterparties.val.counterpartyidnumber" AS BIGINT) > 2147483647
    GROUP BY 1 LIMIT 5
""")
print("--- cp overflow int ---", cur.fetchall())

c.close()
