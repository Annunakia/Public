"""Full clean R1+R2 rerun on DEV and validation suite."""
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import psycopg2
from psycopg2.extras import RealDictCursor

HOST = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
PWD = os.environ.get("REDSHIFT_PASSWORD", "")
ROOT = Path(__file__).resolve().parents[1]

# Import case definitions from qa_rerun_full_corrected
sys.path.insert(0, str(ROOT / "tools"))
from qa_rerun_full_corrected import CASES, run, fetch_all  # noqa: E402


def deploy_sps(cur):
    for name in ("05_sp_regla1.sql", "06_sp_regla2.sql"):
        cur.execute((ROOT / "sql" / name).read_text(encoding="utf-8"))
        print(f"DEPLOY OK: {name}")


def reset_state(cur):
    cur.execute("DELETE FROM bdm_stage.unificacion_direccion")
    print("cleared unificacion_direccion")

    cur.execute("""
        DELETE FROM bdm_stage.relacion_persona_ubicacion
        WHERE cod_dw_direccion_fisica IN (
          SELECT cod_dw_direccion_fisica FROM bdm_stage.direccion_fisica
          WHERE COALESCE(generada_enriquecida, 0) = 1
        )
    """)
    print("deleted rpu on generated dirs", cur.rowcount)

    cur.execute("""
        DELETE FROM bdm_stage.direccion_fisica
        WHERE COALESCE(generada_enriquecida, 0) = 1
    """)
    print("deleted generated dirs", cur.rowcount)

    cur.execute("""
        UPDATE bdm_stage.relacion_persona_ubicacion r
        SET ind_unificacion = NULL
        FROM bdm_stage.perf_persona_meta m
        WHERE m.id_buro_persona = r.id_buro_persona
          AND m.scenario_code <> 'R1_HIJA'
    """)
    print("reset ind_unificacion (except R1_HIJA)", cur.rowcount)


def mock_checks(cur):
    checks = {}
    q = """
        SELECT CASE WHEN COUNT(*)=1 AND MAX(u.cod_dw_direccion_unificada)=888001002
                    AND MAX(u.cod_dw_persona_ubic)=888001001 THEN 'PASSED' ELSE 'FAILED' END AS estado
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic=u.cod_dw_persona_ubic
        WHERE rh.id_buro_persona=888001 AND u.unifica_atributos=1
    """
    cur.execute(q)
    checks["MOCK_888001_TC-R1-01"] = cur.fetchone()["estado"]

    q = """
        SELECT CASE WHEN COUNT(*)=1 AND MAX(u.cod_dw_direccion_unificada)=888003001
                    AND MAX(u.cod_dw_persona_ubic)=888003002 THEN 'PASSED' ELSE 'FAILED' END AS estado
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic=u.cod_dw_persona_ubic
        WHERE rh.id_buro_persona=888003 AND u.unifica_atributos=2
    """
    cur.execute(q)
    checks["MOCK_888003_TC-R2-13"] = cur.fetchone()["estado"]

    q = """
        SELECT CASE WHEN COUNT(*)=0 THEN 'PASSED' ELSE 'FAILED' END AS estado
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic=u.cod_dw_persona_ubic
        WHERE rh.id_buro_persona=888004 AND u.unifica_atributos=2
    """
    cur.execute(q)
    checks["MOCK_888004_TC-R2-14"] = cur.fetchone()["estado"]
    return checks


def main():
    if not PWD:
        print("Set REDSHIFT_PASSWORD")
        sys.exit(1)

    conn = psycopg2.connect(
        host=HOST, port=5440, dbname="dba_batch", user="c32525e",
        password=PWD, sslmode="require", connect_timeout=90,
    )
    conn.autocommit = True
    cur = conn.cursor(cursor_factory=RealDictCursor)

    deploy_sps(cur)
    reset_state(cur)

    cur.execute("CALL bdm_stage.sp_unificacion_regla1()")
    print("CALL R1 OK")
    cur.execute("CALL bdm_stage.sp_unificacion_regla2()")
    print("CALL R2 OK")

    counts = fetch_all(
        cur,
        """
        SELECT 'rpu' lbl, COUNT(*) n FROM bdm_stage.relacion_persona_ubicacion
        UNION ALL SELECT 'unif_r1', COUNT(*) FROM bdm_stage.unificacion_direccion WHERE unifica_atributos=1
        UNION ALL SELECT 'unif_r2', COUNT(*) FROM bdm_stage.unificacion_direccion WHERE unifica_atributos=2
        UNION ALL SELECT 'gen_dir', COUNT(*) FROM bdm_stage.direccion_fisica WHERE COALESCE(generada_enriquecida,0)=1
        """,
    )
    print("counts", counts)

    results = [run(cur, *c) for c in CASES]
    official = [r for r in results if not (r["id"] == "TC-R1-01" and "original" in r.get("note", ""))]
    passed = sum(1 for r in official if r["status"] == "PASSED")
    failed = sum(1 for r in official if r["status"] == "FAILED")
    mocks = mock_checks(cur)

    out = {
        "executed_at": datetime.now().isoformat(),
        "environment": "DEV",
        "host": HOST,
        "pipeline": "clean reset + R1 fix + R2",
        "counts": counts,
        "summary": {
            "total_oficial": len(official),
            "passed": passed,
            "failed": failed,
            "pct": round(100 * passed / len(official), 1) if official else 0,
        },
        "mock_validation": mocks,
        "failed_cases": [r for r in official if r["status"] == "FAILED"],
        "cases": results,
    }

    out_path = ROOT / "tools" / "dev_full_rerun_post_fix.json"
    out_path.write_text(json.dumps(out, indent=2, default=str), encoding="utf-8")
    print(json.dumps({"summary": out["summary"], "mocks": mocks, "failed": out["failed_cases"]}, indent=2, default=str))
    print(f"Wrote {out_path}")

    cur.close()
    conn.close()


if __name__ == "__main__":
    main()
