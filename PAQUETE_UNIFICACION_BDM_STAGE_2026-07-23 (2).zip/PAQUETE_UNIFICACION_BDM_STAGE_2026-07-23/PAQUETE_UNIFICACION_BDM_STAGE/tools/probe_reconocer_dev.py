"""Probe Reconocer DEV Redshift: DB name, schemas, datashares, IFR."""
import json
import os
import sys
import psycopg2
from psycopg2.extras import RealDictCursor

HOST = os.environ.get(
    "REDSHIFT_HOST",
    "eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com",
)
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PASSWORD = os.environ.get("REDSHIFT_PASSWORD", "")
DB_CANDIDATES = ["dev", "dba", "dba_batch", "reconocer", "batch"]


def probe(dbname):
    c = psycopg2.connect(
        host=HOST, port=5440, dbname=dbname, user=USER, password=PASSWORD,
        sslmode="require", connect_timeout=25,
    )
    cur = c.cursor(cursor_factory=RealDictCursor)
    out = {"host": HOST, "database": dbname, "connected": True}

    cur.execute("SELECT current_database() AS db, current_user AS usr, version() AS ver")
    out["session"] = dict(cur.fetchone())

    cur.execute(
        "SELECT datname FROM pg_database "
        "WHERE datname NOT IN ('template0','template1','padb_harvest','sys:internal') ORDER BY 1"
    )
    out["databases"] = [r["datname"] for r in cur.fetchall()]

    cur.execute(
        "SELECT schema_name FROM information_schema.schemata "
        "WHERE schema_name NOT LIKE 'pg_%%' AND schema_name NOT IN ('information_schema') "
        "ORDER BY 1 LIMIT 50"
    )
    out["schemas"] = [r["schema_name"] for r in cur.fetchall()]

    for sch in ("ifr_data", "bdm_stage", "bdm_datos", "bdm_tempo"):
        if sch in out["schemas"]:
            cur.execute(
                "SELECT table_name FROM information_schema.tables "
                "WHERE table_schema = %s ORDER BY 1 LIMIT 20",
                (sch,),
            )
            out[f"tables_{sch}"] = [r["table_name"] for r in cur.fetchall()]

    for q, key in [
        ("SELECT * FROM svv_datashares LIMIT 30", "datashares"),
        ("SELECT share_name, object_name, object_type FROM svv_datashare_objects LIMIT 25", "share_objects"),
    ]:
        try:
            cur.execute(q)
            out[key] = [dict(r) for r in cur.fetchall()]
        except Exception as e:
            out[f"{key}_err"] = str(e)[:200]

    for path in ("ifr_data.xpm",):
        try:
            cur.execute(f"SELECT COUNT(*) AS n FROM {path}")
            out[f"count_{path.replace('.', '_')}"] = cur.fetchone()["n"]
        except Exception as e:
            out[f"count_{path.replace('.', '_')}_err"] = str(e)[:120]

    c.close()
    return out


def main():
    if not PASSWORD:
        print("Set REDSHIFT_PASSWORD")
        sys.exit(1)
    last_err = None
    for db in DB_CANDIDATES:
        try:
            r = probe(db)
            print(json.dumps(r, indent=2, default=str))
            return
        except Exception as e:
            last_err = f"{db}: {e}"
            print(f"try {last_err}", file=sys.stderr)
    print(f"All DBs failed. Last: {last_err}")
    sys.exit(1)


if __name__ == "__main__":
    main()
