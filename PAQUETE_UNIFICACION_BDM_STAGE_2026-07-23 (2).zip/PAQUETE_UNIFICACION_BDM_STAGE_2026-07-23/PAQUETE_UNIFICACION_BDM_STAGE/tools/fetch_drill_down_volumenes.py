"""Fetch drill-down personas + RPUs por regla/escenario — DEV dba_rncr_batch."""
from __future__ import annotations

import json
import os
import sys
from datetime import date
from pathlib import Path

import psycopg2
from psycopg2.extras import RealDictCursor

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "Documentacion" / "drill_down_volumenes.json"

sys.path.insert(0, str(ROOT / "tools"))
from mapa_r1_sql import R1_CAND_SQL  # noqa: E402
from mapa_volumenes_meta import ORDER, busca, etiqueta  # noqa: E402

HOST = "eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com"
DB = os.environ.get("REDSHIFT_CONSUMER_DB", "dba_rncr_batch")
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PWD = os.environ.get("REDSHIFT_CONSUMER_PASSWORD", os.environ.get("REDSHIFT_PASSWORD", ""))
PORT = int(os.environ.get("REDSHIFT_PORT", "5440"))

R1_ESC_EVAL = """
WITH ubi1 AS (
  SELECT cod_dw_ubic, texto_ubicacion, cod_dw_ciudad
  FROM bdm_tempo.v_xpm_ubicacion_estandarizada
  GROUP BY 1, 2, 3
),
insumo AS (
  SELECT rpu.cod_dw_persona_ubic, rpu.id_buro_persona, ubi.texto_ubicacion, ubi.cod_dw_ciudad,
    rpu.cod_dw_tipo_ubicacion_dir,
    COALESCE(ciiu.cod_act_econo_ciiu_fte, '') AS ciiu,
    COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor), 0) AS n_rep,
    tud.descripcion_tipo_ubicacion_dir AS tipo_dir
  FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
  JOIN ubi1 ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  JOIN bdm_tempo.v_xpm_reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  LEFT JOIN bdm_tempo.v_xpm_ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona
  LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
  WHERE rpu.ind_unificacion IS NULL
  GROUP BY 1, 2, 3, 4, 5, 6, 8
),
scored AS (
  SELECT *,
    CASE WHEN ciiu = '10' THEN 'ESC1' WHEN ciiu IN ('81','82','90') THEN 'ESC2' ELSE 'ESC3' END AS esc,
    CASE WHEN ciiu = '10' THEN CASE WHEN tipo_dir IN ('LAB','CRR') THEN 100000 ELSE 0 END + n_rep
         WHEN ciiu IN ('81','82','90') THEN CASE WHEN tipo_dir IN ('RES','CRR') THEN 100000 ELSE 0 END + n_rep
         ELSE n_rep END AS score
  FROM insumo
),
mult AS (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_ciudad FROM scored
  GROUP BY 1, 2, 3 HAVING COUNT(DISTINCT cod_dw_tipo_ubicacion_dir) > 1
)
SELECT s.esc AS codigo,
       COUNT(DISTINCT s.id_buro_persona)::BIGINT AS personas,
       COUNT(DISTINCT s.cod_dw_persona_ubic)::BIGINT AS rpus
FROM scored s
JOIN mult m USING (id_buro_persona, texto_ubicacion, cod_dw_ciudad)
GROUP BY 1
"""

R1_EMPATE_PERSONAS = """
WITH ubi1 AS (
  SELECT cod_dw_ubic, texto_ubicacion, cod_dw_ciudad
  FROM bdm_tempo.v_xpm_ubicacion_estandarizada
  GROUP BY 1, 2, 3
),
insumo AS (
  SELECT rpu.cod_dw_persona_ubic, rpu.id_buro_persona, ubi.texto_ubicacion, ubi.cod_dw_ciudad,
    rpu.cod_dw_tipo_ubicacion_dir,
    COALESCE(ciiu.cod_act_econo_ciiu_fte, '') AS ciiu,
    COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor), 0) AS n_rep,
    tud.descripcion_tipo_ubicacion_dir AS tipo_dir
  FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
  JOIN ubi1 ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  JOIN bdm_tempo.v_xpm_reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  LEFT JOIN bdm_tempo.v_xpm_ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona
  LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
  WHERE rpu.ind_unificacion IS NULL
  GROUP BY 1, 2, 3, 4, 5, 6, 8
),
scored AS (
  SELECT *,
    CASE WHEN ciiu = '10' THEN 'ESC1' WHEN ciiu IN ('81','82','90') THEN 'ESC2' ELSE 'ESC3' END AS esc,
    CASE WHEN ciiu = '10' THEN CASE WHEN tipo_dir IN ('LAB','CRR') THEN 100000 ELSE 0 END + n_rep
         WHEN ciiu IN ('81','82','90') THEN CASE WHEN tipo_dir IN ('RES','CRR') THEN 100000 ELSE 0 END + n_rep
         ELSE n_rep END AS score
  FROM insumo
),
mult AS (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_ciudad FROM scored
  GROUP BY 1, 2, 3 HAVING COUNT(DISTINCT cod_dw_tipo_ubicacion_dir) > 1
),
win AS (
  SELECT s.id_buro_persona, s.texto_ubicacion, s.cod_dw_ciudad, s.esc, MAX(s.score) AS max_score
  FROM scored s JOIN mult m USING (id_buro_persona, texto_ubicacion, cod_dw_ciudad)
  GROUP BY 1, 2, 3, 4
),
emp_part AS (
  SELECT s.id_buro_persona, s.texto_ubicacion, s.cod_dw_ciudad, s.esc
  FROM scored s
  JOIN win w ON s.id_buro_persona = w.id_buro_persona AND s.texto_ubicacion = w.texto_ubicacion
    AND s.cod_dw_ciudad = w.cod_dw_ciudad AND s.esc = w.esc AND s.score = w.max_score
  GROUP BY 1, 2, 3, 4
  HAVING COUNT(*) > 1
)
SELECT COUNT(DISTINCT s.id_buro_persona)::BIGINT AS personas,
       COUNT(DISTINCT s.cod_dw_persona_ubic)::BIGINT AS rpus
FROM scored s
JOIN emp_part e USING (id_buro_persona, texto_ubicacion, cod_dw_ciudad, esc)
"""

QUERIES = {
    "univ": """
        SELECT COUNT(*)::BIGINT AS rpus,
               COUNT(DISTINCT id_buro_persona)::BIGINT AS personas
        FROM bdm_tempo.v_xpm_relacion_persona_ubicacion
    """,
    "post_r2": """
        SELECT COUNT(DISTINCT r.id_buro_persona)::BIGINT AS personas,
               COUNT(DISTINCT r.cod_dw_persona_ubic)::BIGINT AS rpus
        FROM bdm_tempo.v_xpm_relacion_persona_ubicacion r
        WHERE NOT EXISTS (
          SELECT 1 FROM bdm_datos.unificacion_direccion u
          WHERE u.cod_dw_persona_ubic = r.cod_dw_persona_ubic AND u.unifica_atributos = 2
        )
    """,
    "r1_salida": """
        SELECT COUNT(DISTINCT r.id_buro_persona)::BIGINT AS personas,
               COUNT(DISTINCT u.cod_dw_persona_ubic)::BIGINT AS rpus
        FROM bdm_datos.unificacion_direccion u
        JOIN bdm_tempo.v_xpm_relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        WHERE u.unifica_atributos = 1
    """,
    "r2_salida": """
        SELECT COUNT(DISTINCT r.id_buro_persona)::BIGINT AS personas,
               COUNT(DISTINCT u.cod_dw_persona_ubic)::BIGINT AS rpus
        FROM bdm_datos.unificacion_direccion u
        JOIN bdm_tempo.v_xpm_relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        WHERE u.unifica_atributos = 2
    """,
    "r2_ct8": """
        SELECT COUNT(DISTINCT rpu.id_buro_persona)::BIGINT AS personas,
               COUNT(DISTINCT rpu.cod_dw_persona_ubic)::BIGINT AS rpus
        FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
        JOIN ds_dba_rncr_batch.edf_views.xpm_location_val_contactinformations ci ON ci.id = rpu.cod_dw_persona_ubic
        WHERE NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::VARCHAR), '') = '8'
    """,
    "r3_geo": """
        WITH ubi1 AS (
          SELECT cod_dw_ubic FROM bdm_tempo.v_xpm_ubicacion_estandarizada
          GROUP BY 1 HAVING MAX(CASE WHEN latitud IS NOT NULL AND longitud IS NOT NULL THEN 1 ELSE 0 END) = 1
        )
        SELECT COUNT(DISTINCT r.id_buro_persona)::BIGINT AS personas,
               COUNT(DISTINCT r.cod_dw_persona_ubic)::BIGINT AS rpus
        FROM bdm_tempo.v_xpm_relacion_persona_ubicacion r
        JOIN ubi1 u ON r.cod_dw_ubic = u.cod_dw_ubic
    """,
    "r3_salida": """
        SELECT COUNT(DISTINCT r.id_buro_persona)::BIGINT AS personas,
               COUNT(DISTINCT u.cod_dw_persona_ubic)::BIGINT AS rpus
        FROM bdm_datos.unificacion_direccion u
        JOIN bdm_tempo.v_xpm_relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        WHERE u.unifica_atributos = 3
    """,
    "motor": """
        SELECT COUNT(DISTINCT id_buro_persona)::BIGINT AS personas,
               COUNT(*)::BIGINT AS rpus
        FROM bdm_tempo.stg_motor_insumo
    """,
}


def rpuxp(rpus: int, personas: int) -> float | None:
    if personas <= 0:
        return None
    return round(rpus / personas, 2)


def row(regla: str, codigo: str, personas: int, rpus: int) -> dict:
    return {
        "regla": regla,
        "codigo": codigo,
        "escenario": etiqueta(regla, codigo),
        "busca": busca(regla, codigo),
        "personas": int(personas),
        "rpus": int(rpus),
        "rpuxp": rpuxp(rpus, personas),
    }


def fetch_one(cur, sql: str) -> dict:
    cur.execute(sql)
    return dict(cur.fetchone() or {})


def main() -> int:
    if not PWD:
        print("Defina REDSHIFT_CONSUMER_PASSWORD", file=sys.stderr)
        return 1
    conn = psycopg2.connect(
        host=HOST, port=PORT, dbname=DB, user=USER, password=PWD, sslmode="require", connect_timeout=120
    )
    conn.autocommit = True
    cur = conn.cursor(cursor_factory=RealDictCursor)

    raw: dict = {}
    for key, sql in QUERIES.items():
        try:
            raw[key] = fetch_one(cur, sql)
        except Exception as e:
            raw[key] = {"error": str(e).split("\n")[0], "personas": 0, "rpus": 0}

    try:
        raw["r1_cand"] = fetch_one(cur, R1_CAND_SQL)
    except Exception as e:
        raw["r1_cand"] = {"error": str(e), "personas": 0, "rpus": 0, "grupos": 0}

    try:
        cur.execute(R1_ESC_EVAL)
        raw["r1_esc"] = {r["codigo"]: dict(r) for r in cur.fetchall()}
    except Exception as e:
        raw["r1_esc"] = {"error": str(e).split("\n")[0]}

    try:
        raw["r1_empate"] = fetch_one(cur, R1_EMPATE_PERSONAS)
    except Exception as e:
        raw["r1_empate"] = {"personas": 0, "rpus": 0, "error": str(e).split("\n")[0]}

    cur.close()
    conn.close()

    u = raw["univ"]
    personas_u = int(u.get("personas", 0))
    rpus_u = int(u.get("rpus", 0))
    rc = raw["r1_cand"]
    r1_p_in = int(rc.get("personas", 0))
    r1_r_in = int(rc.get("rpus", 0))
    pr = raw["post_r2"]
    r2_out = raw["r2_salida"]
    r1_out = raw["r1_salida"]
    r3_out = raw["r3_salida"]
    r1_esc = raw.get("r1_esc") or {}

    filas: list[dict] = []
    filas.append(row("UNIVERSO", "TEMA", personas_u, rpus_u))
    filas.append(row("UNIVERSO", "POST-R2", int(pr.get("personas", 0)), int(pr.get("rpus", 0))))
    filas.append(row("R1", "INSUMO", personas_u, rpus_u))
    filas.append(row("R1", "PRE-R1", r1_p_in, r1_r_in))
    filas.append(row("R1", "PRE-R1-FUERA", max(personas_u - r1_p_in, 0), max(rpus_u - r1_r_in, 0)))

    for esc in ("ESC1", "ESC2", "ESC3"):
        e = r1_esc.get(esc, {}) if isinstance(r1_esc, dict) else {}
        filas.append(row("R1", esc, int(e.get("personas", 0)), int(e.get("rpus", 0))))

    re = raw["r1_empate"]
    filas.append(row("R1", "EMPATE", int(re.get("personas", 0)), int(re.get("rpus", 0))))
    filas.append(row("R1", "SALIDA", int(r1_out.get("personas", 0)), int(r1_out.get("rpus", 0))))

    ct8 = raw["r2_ct8"]
    filas.append(row("R2", "INSUMO", int(ct8.get("personas", 0)), int(ct8.get("rpus", 0))))
    filas.append(row("R2", "ESC1", int(r2_out.get("personas", 0)), int(r2_out.get("rpus", 0))))
    for esc in ("ESC2", "ESC3", "ESC4", "ESC5", "ESC6"):
        filas.append(row("R2", esc, 0, 0))

    mot = raw["motor"]
    if mot.get("error"):
        filas.append(row("R2", "MOTOR", 0, 0))
    else:
        filas.append(row("R2", "MOTOR", int(mot.get("personas", 0)), int(mot.get("rpus", 0))))

    filas.append(row("R2", "SIN PAR", int(pr.get("personas", 0)), int(pr.get("rpus", 0))))
    filas.append(row("R2", "SALIDA", int(r2_out.get("personas", 0)), int(r2_out.get("rpus", 0))))

    geo = raw["r3_geo"]
    filas.append(row("R3", "PRE-R3", int(geo.get("personas", 0)), int(geo.get("rpus", 0))))
    filas.append(row("R3", "ESC1", int(r3_out.get("personas", 0)), int(r3_out.get("rpus", 0))))
    filas.append(row("R3", "SALIDA", int(r3_out.get("personas", 0)), int(r3_out.get("rpus", 0))))

    idx = {k: i for i, k in enumerate(ORDER)}
    filas.sort(key=lambda f: idx.get((f["regla"], f["codigo"]), 999))

    payload = {
        "generated": date.today().isoformat(),
        "universo": {
            "personas": personas_u,
            "rpus": rpus_u,
            "rpuxp": rpuxp(rpus_u, personas_u),
        },
        "filas": filas,
    }
    OUT.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"universo": payload["universo"], "n_filas": len(filas)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
