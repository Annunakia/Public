import os, psycopg2
from psycopg2.extras import RealDictCursor

c = psycopg2.connect(
    host="eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com",
    port=5440, dbname="dba_batch", user="c32525e",
    password=os.environ.get("REDSHIFT_PASSWORD", "b27YWI2FL"), sslmode="require",
)
c.autocommit = True
cur = c.cursor(cursor_factory=RealDictCursor)

cur.execute("""
    SELECT ci."location.val.contactinformations.val.contacttype" AS t,
           COUNT(*) AS n
    FROM edf_views.xpm xpm
    JOIN edf_views.xpm_location loc ON xpm.location = loc.id
    JOIN edf_views.xpm_location_val_contactinformations ci
      ON loc."location.val.contactinformations" = ci.id
    WHERE NULLIF(TRIM(ci."location.val.contactinformations.val.standardizedtextoubicacion"::varchar),'') IS NOT NULL
    GROUP BY 1 ORDER BY n DESC LIMIT 10
""")
print("tokenized by contacttype:", cur.fetchall())

cur.execute("""
    SELECT COUNT(*) AS n
    FROM edf_views.xpm xpm
    JOIN edf_views.xpm_location loc ON xpm.location = loc.id
    JOIN edf_views.xpm_location_val_contactinformations ci
      ON loc."location.val.contactinformations" = ci.id
    WHERE NULLIF(TRIM(ci."location.val.contactinformations.val.standardizedtextoubicacion"::varchar),'') IS NOT NULL
      AND CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1,2,3,7)
""")
print("tokenized addr types:", cur.fetchone())

cur.execute("""
    SELECT COUNT(*) AS n
    FROM edf_views.xpm xpm
    JOIN edf_views.xpm_location loc ON xpm.location = loc.id
    JOIN edf_views.xpm_location_val_contactinformations ci
      ON loc."location.val.contactinformations" = ci.id
    WHERE ci."location.val.contactinformations.val.contacttype" = '3'
      AND NULLIF(TRIM(ci."location.val.contactinformations.val.standardizedtextoubicacion"::varchar),'') IS NOT NULL
""")
print("type 3 tokenized:", cur.fetchone())

cur.execute("""
    SELECT COUNT(*) AS n
    FROM edf_views.xpm xpm
    JOIN edf_views.xpm_location loc ON xpm.location = loc.id
    JOIN edf_views.xpm_location_val_contactinformations ci
      ON loc."location.val.contactinformations" = ci.id
    WHERE NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::varchar), '') = '8'
      AND NULLIF(TRIM(ci."location.val.contactinformations.val.standardizedtextoubicacion"::varchar), '') IS NOT NULL
""")
print("type 8 tokenized join:", cur.fetchone())

cur.execute("""
    SELECT COUNT(*) AS n
    FROM edf_views.xpm xpm
    JOIN edf_views.xpm_location loc ON xpm.location = loc.id
    JOIN edf_views.xpm_location_val_contactinformations ci
      ON loc."location.val.contactinformations" = ci.id
    JOIN edf_views.xpm_counterparties cp ON xpm.counterparties = cp.id
    WHERE NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::varchar), '') = '8'
      AND NULLIF(TRIM(ci."location.val.contactinformations.val.standardizedtextoubicacion"::varchar), '') IS NOT NULL
""")
print("type 8 full join reportes:", cur.fetchone())
c.close()
