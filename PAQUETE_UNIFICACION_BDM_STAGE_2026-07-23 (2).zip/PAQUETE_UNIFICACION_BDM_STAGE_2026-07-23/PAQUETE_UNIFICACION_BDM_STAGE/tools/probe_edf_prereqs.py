import os, psycopg2
from psycopg2.extras import RealDictCursor

c = psycopg2.connect(
    host="eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com",
    port=5440, dbname="dba_batch", user="c32525e",
    password=os.environ.get("REDSHIFT_PASSWORD", "b27YWI2FL"), sslmode="require",
)
c.autocommit = True
cur = c.cursor(cursor_factory=RealDictCursor)

checks = [
    ("convert_epoch", "SELECT bdm_datos.convert_epoch_to_date(1772323199000) AS d"),
    ("ciiu col", """
        SELECT column_name FROM information_schema.columns
        WHERE table_schema='edf_views' AND table_name='xpm' AND column_name ILIKE '%isic%'
    """),
    ("id cols", """
        SELECT table_name, column_name FROM information_schema.columns
        WHERE table_schema='edf_views'
          AND table_name IN ('xpm_location','xpm_location_val_contactinformations','xpm_counterparties')
          AND column_name='id'
    """),
    ("procs", """
        SELECT n.nspname, p.proname FROM pg_proc p
        JOIN pg_namespace n ON p.pronamespace=n.oid
        WHERE p.proname LIKE '%unificacion%'
    """),
    ("create priv", """
        SELECT has_schema_privilege('c32525e','bdm_tempo','CREATE') AS c_tempo,
               has_schema_privilege('c32525e','bdm_datos','CREATE') AS c_datos
    """),
    ("tipo_ubicacion", "SELECT COUNT(*) AS n FROM bdm_datos.tipo_ubicacion_dir"),
    ("unificacion table", "SELECT COUNT(*) AS n FROM bdm_datos.unificacion_direccion"),
]
for name, q in checks:
    print("---", name, "---")
    try:
        cur.execute(q)
        print(cur.fetchall())
    except Exception as e:
        print("ERR", str(e).split("\n")[0][:120])
c.close()
