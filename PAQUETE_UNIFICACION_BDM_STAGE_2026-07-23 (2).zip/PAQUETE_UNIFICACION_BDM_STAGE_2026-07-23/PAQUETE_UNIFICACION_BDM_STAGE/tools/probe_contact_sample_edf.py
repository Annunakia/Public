import os, json, psycopg2
from psycopg2.extras import RealDictCursor
PWD = os.environ["REDSHIFT_CONSUMER_PASSWORD"]
conn = psycopg2.connect(
    host="eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com",
    port=5440, dbname="dba_rncr_batch", user="c32525e", password=PWD, sslmode="require",
)
conn.autocommit = True
cur = conn.cursor(cursor_factory=RealDictCursor)
for ct in ("4", "9", "10"):
    cur.execute(f"""
    SELECT ci."location.val.contactinformations.val.contacttype" AS ct,
      NULLIF(TRIM(ci."location.val.contactinformations.val.contactasreported"::VARCHAR), '') AS reported,
      NULLIF(TRIM(ci."location.val.contactinformations.val.contactasreportedstandardized"::VARCHAR), '') AS std
    FROM ds_dba_rncr_batch.edf_views.xpm_location_val_contactinformations ci
    WHERE NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::VARCHAR), '') = '{ct}'
    LIMIT 3
    """)
    print(ct, cur.fetchall())
conn.close()
