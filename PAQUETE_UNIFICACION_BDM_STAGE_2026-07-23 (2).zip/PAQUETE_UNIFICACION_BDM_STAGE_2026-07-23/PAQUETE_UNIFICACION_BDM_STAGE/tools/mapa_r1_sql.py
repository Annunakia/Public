"""Queries R1 — entrada por personas y RPUs (sin inflar por duplicados en ubi)."""

R1_UBI1_CTE = """
ubi1 AS (
  SELECT cod_dw_ubic, texto_ubicacion, cod_dw_ciudad
  FROM bdm_tempo.v_xpm_ubicacion_estandarizada
  GROUP BY 1, 2, 3
)"""

R1_GRUPOS_CTE = f"""
grupos AS (
  SELECT rpu.id_buro_persona, ubi.texto_ubicacion, ubi.cod_dw_ciudad
  FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
  JOIN ubi1 ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  GROUP BY 1, 2, 3
  HAVING COUNT(DISTINCT rpu.cod_dw_tipo_ubicacion_dir) > 1
)"""

R1_CAND_SQL = f"""
WITH {R1_UBI1_CTE},
{R1_GRUPOS_CTE}
SELECT
  (SELECT COUNT(*) FROM grupos)::BIGINT AS grupos,
  (SELECT COUNT(DISTINCT id_buro_persona) FROM grupos)::BIGINT AS personas,
  (SELECT COUNT(DISTINCT rpu.cod_dw_persona_ubic)::BIGINT
   FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
   JOIN ubi1 ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
   JOIN grupos g ON rpu.id_buro_persona = g.id_buro_persona
     AND ubi.texto_ubicacion = g.texto_ubicacion
     AND ubi.cod_dw_ciudad = g.cod_dw_ciudad
  ) AS rpus
"""

# Persona + direcciones que entran a R1 (misma calle+ciudad con 2+ usos RES/LAB/CRR).
# Filtro opcional: descomente AND rpu.id_buro_persona = <id>
R1_DIRECCIONES_PERSONA_SQL = f"""
WITH {R1_UBI1_CTE},
{R1_GRUPOS_CTE},
grupo_tipos AS (
  SELECT
    g.id_buro_persona,
    g.texto_ubicacion,
    g.cod_dw_ciudad,
    LISTAGG(DISTINCT tud.descripcion_tipo_ubicacion_dir, ' + ')
      WITHIN GROUP (ORDER BY tud.descripcion_tipo_ubicacion_dir) AS tipos_grupo
  FROM grupos g
  JOIN bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
    ON rpu.id_buro_persona = g.id_buro_persona
  JOIN ubi1 ubi
    ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
   AND ubi.texto_ubicacion = g.texto_ubicacion
   AND ubi.cod_dw_ciudad = g.cod_dw_ciudad
  LEFT JOIN bdm_datos.tipo_ubicacion_dir tud
    ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
  GROUP BY 1, 2, 3
),
grupo_rpus AS (
  SELECT
    g.id_buro_persona,
    g.texto_ubicacion,
    g.cod_dw_ciudad,
    COUNT(DISTINCT rpu.cod_dw_persona_ubic) AS n_rpus_grupo
  FROM grupos g
  JOIN bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
    ON rpu.id_buro_persona = g.id_buro_persona
  JOIN ubi1 ubi
    ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
   AND ubi.texto_ubicacion = g.texto_ubicacion
   AND ubi.cod_dw_ciudad = g.cod_dw_ciudad
  GROUP BY 1, 2, 3
)
SELECT
  rpu.id_buro_persona,
  rpu.cod_pin_persona,
  LEFT(g.texto_ubicacion, 100) AS calle,
  g.cod_dw_ciudad,
  gt.tipos_grupo,
  gr.n_rpus_grupo,
  rpu.cod_dw_persona_ubic AS rpu,
  tud.descripcion_tipo_ubicacion_dir AS tipo,
  rpu.cod_dw_ubic,
  rpu.fecha_relacion_persona_ubicaci
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN ubi1 ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
JOIN grupos g
  ON rpu.id_buro_persona = g.id_buro_persona
 AND ubi.texto_ubicacion = g.texto_ubicacion
 AND ubi.cod_dw_ciudad = g.cod_dw_ciudad
JOIN grupo_tipos gt
  ON g.id_buro_persona = gt.id_buro_persona
 AND g.texto_ubicacion = gt.texto_ubicacion
 AND g.cod_dw_ciudad = gt.cod_dw_ciudad
JOIN grupo_rpus gr
  ON g.id_buro_persona = gr.id_buro_persona
 AND g.texto_ubicacion = gr.texto_ubicacion
 AND g.cod_dw_ciudad = gr.cod_dw_ciudad
LEFT JOIN bdm_datos.tipo_ubicacion_dir tud
  ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
WHERE 1 = 1
  -- AND rpu.id_buro_persona = -5233481187049215074
ORDER BY rpu.id_buro_persona, calle, rpu, tipo
"""

R1_RESUMEN_PERSONA_SQL = f"""
WITH {R1_UBI1_CTE},
{R1_GRUPOS_CTE}
SELECT
  g.id_buro_persona,
  MAX(rpu.cod_pin_persona) AS cod_pin_persona,
  COUNT(DISTINCT g.texto_ubicacion || '|' || g.cod_dw_ciudad::VARCHAR) AS calles_r1,
  COUNT(DISTINCT rpu.cod_dw_persona_ubic) AS rpus_r1,
  ROUND(
    COUNT(DISTINCT rpu.cod_dw_persona_ubic)::DECIMAL
    / NULLIF(COUNT(DISTINCT g.texto_ubicacion || '|' || g.cod_dw_ciudad::VARCHAR), 0),
    2
  ) AS rpus_por_calle
FROM grupos g
JOIN bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
  ON rpu.id_buro_persona = g.id_buro_persona
JOIN ubi1 ubi
  ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
 AND ubi.texto_ubicacion = g.texto_ubicacion
 AND ubi.cod_dw_ciudad = g.cod_dw_ciudad
/* BEFORE_GROUP */
GROUP BY 1
ORDER BY rpus_r1 DESC, g.id_buro_persona
"""
