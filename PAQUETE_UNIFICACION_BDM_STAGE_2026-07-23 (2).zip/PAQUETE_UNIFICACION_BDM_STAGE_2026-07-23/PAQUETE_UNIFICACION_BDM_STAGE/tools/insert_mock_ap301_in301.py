"""Insert mock persona 888002: AP 301 + IN 301."""
import json
import os
import psycopg2

HOST = "eec-aws-us-eits-procesosbatch-qa-redshift.cwefyckvccgy.us-east-1.redshift.amazonaws.com"
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PASSWORD = os.environ.get("REDSHIFT_PASSWORD", "")

ID = 888002


def main():
    conn = psycopg2.connect(
        host=HOST, port=5440, dbname="dba_batch", user=USER, password=PASSWORD, sslmode="require"
    )
    conn.autocommit = False
    cur = conn.cursor()
    cur.execute(
        "SELECT COUNT(*) FROM bdm_stage.relacion_persona_ubicacion WHERE id_buro_persona = %s", (ID,)
    )
    if cur.fetchone()[0] > 0:
        print(json.dumps({"status": "exists", "id_buro_persona": ID}))
        return
    try:
        cur.execute(
            "INSERT INTO bdm_stage.ubicacion_estandarizada VALUES (%s, %s, 1, NULL, NULL)",
            (ID * 1000 + 1, "CL 45 12 33 MOCK QA AP301-IN301"),
        )
        cur.execute(
            """INSERT INTO bdm_stage.direccion_fisica VALUES
               (%s, 'AP 301', %s, 'CL', '45', '12', '33', NULL),
               (%s, 'IN 301', %s, 'CL', '45', '12', '33', NULL)""",
            (ID * 1000 + 101, ID * 1000 + 1, ID * 1000 + 102, ID * 1000 + 1),
        )
        cur.execute("INSERT INTO bdm_stage.ciiu_persona VALUES (%s, '10')", (ID,))
        cur.execute(
            """INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
               (%s, %s, %s, %s, %s, 1, NULL, 1, DATE '2025-06-01', 99, 1),
               (%s, %s, %s, %s, %s, 1, NULL, 2, DATE '2025-06-01', 99, 1)""",
            (
                ID * 1000 + 1, ID, ID + 1000000, ID * 1000 + 1, ID * 1000 + 101,
                ID * 1000 + 2, ID, ID + 1000000, ID * 1000 + 1, ID * 1000 + 102,
            ),
        )
        cur.execute(
            """INSERT INTO bdm_stage.reporte_relacion_persona_ubica VALUES
               (%s, 901, DATE '2025-05-01', 99),
               (%s, 902, DATE '2025-05-01', 99),
               (%s, 903, DATE '2025-05-01', 99)""",
            (ID * 1000 + 1, ID * 1000 + 1, ID * 1000 + 2),
        )
        conn.commit()
        print(json.dumps({"status": "inserted", "id_buro_persona": ID}, indent=2))
    except Exception as e:
        conn.rollback()
        print(json.dumps({"status": "error", "message": str(e)}))


if __name__ == "__main__":
    main()
