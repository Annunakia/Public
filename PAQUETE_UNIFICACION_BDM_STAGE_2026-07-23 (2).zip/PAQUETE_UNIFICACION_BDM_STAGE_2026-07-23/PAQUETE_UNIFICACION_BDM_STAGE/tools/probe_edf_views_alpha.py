import os
import psycopg2
from psycopg2.extras import RealDictCursor

c = psycopg2.connect(
    host="eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com",
    port=5440, dbname="dba_batch", user="c32525e",
    password=os.environ["REDSHIFT_PASSWORD"], sslmode="require",
)
c.autocommit = True
cur = c.cursor(cursor_factory=RealDictCursor)

for t in (
    "bdm_tempo.xpm",
    "edf_views.xpm",
    "edf_views.xpm_location",
    "edf_views.xpm_location_val_contactinformations",
    "edf_views.xpm_counterparties",
    "ifr_data.xpm",
):
    try:
        cur.execute(f"SELECT COUNT(*) AS n FROM {t}")
        print(t, cur.fetchone()["n"])
    except Exception as e:
        print(t, "ERR", str(e).split("\n")[0][:120])

cur.execute(
    "SELECT column_name FROM information_schema.columns "
    "WHERE table_schema = 'edf_views' "
    "AND table_name = 'xpm_location_val_contactinformations' "
    "AND column_name ILIKE '%standardized%' LIMIT 15"
)
print("edf_views standardized cols:", [r["column_name"] for r in cur.fetchall()])

cur.execute(
    "SELECT column_name FROM information_schema.columns "
    "WHERE table_schema = 'ifr_data' "
    "AND table_name = 'xpm_location_val_contactinformations' "
    "AND column_name ILIKE '%standardized%' LIMIT 5"
)
print("ifr_data standardized cols:", [r["column_name"] for r in cur.fetchall()])

c.close()
