"""Catálogo SP unificación — nombres dicientes (escenario + descripción)."""
from __future__ import annotations

# Sincronizado con tools/gen_unificacion_sps_por_escenario.py
SP_R1_PREP = "sp_unificacion_r1_preparar_insumo"
SP_R1_ESC1 = "sp_unificacion_r1_esc1_ciiu10_mismo_texto_padre_lab_crr"
SP_R1_ESC2 = "sp_unificacion_r1_esc2_ciiu81_90_mismo_texto_padre_res_crr"
SP_R1_ESC3 = "sp_unificacion_r1_esc3_otros_ciiu_mayor_entidades_reportan"
SP_R1_ORQ = "sp_unificacion_regla1"
SP_R2_PREP = "sp_unificacion_r2_preparar_insumo"
SP_R2_ESC12 = "sp_unificacion_r2_esc1_complemento_vacio_esc2_substring_complemento"
SP_R2_ESC3 = "sp_unificacion_r2_esc3_sin_nit_misma_nomenclatura"
SP_R2_ESC4 = "sp_unificacion_r2_esc4_diccionario_frecuencia_complemento"
SP_R2_ESC5 = "sp_unificacion_r2_esc5_nomenclatura_menor_nivel_pierde"
SP_R2_ESC6 = "sp_unificacion_r2_esc6_frecuencia_complemento_gana"
SP_R2_MOTOR = "sp_unificacion_r2_motor_nit_empates_nuevas_direcciones"
SP_R2_ORQ = "sp_unificacion_regla2"
SP_R3_ESC1 = "sp_unificacion_r3_esc1_geo_misma_via_puerta_cercana"
SP_R3_ORQ = "sp_unificacion_regla3"


def _f(proc: str) -> str:
    return f"{proc}.sql"


def build_repos_bitbucket() -> list[dict]:
    return [
        {
            "orden": 1,
            "repo": "db_rcncr_btch_rdshft_strct",
            "rama": "feature/unificacion-edf-views",
            "archivos": [
                ("00_prerequisitos_schemas.sql", "Schemas bdm_datos/bdm_tempo + convert_epoch_to_date"),
                ("01_ddl_unificacion_direccion.sql", "Tabla salida real + catálogos"),
                ("01b_ddl_unificacion_direccion_mock.sql", "Tabla salida mock"),
                ("02_vistas_insumo_edf_views.sql", "v_xpm_* sobre datashare (reales)"),
                ("02b_vistas_insumo_mock.sql", "v_mock_* sobre bdm_stage (mock)"),
            ],
        },
        {
            "orden": 2,
            "repo": "db_rcncr_btch_rdshft_pgm",
            "rama": "feature/unificacion-edf-views",
            "archivos": [
                (_f(SP_R1_PREP), "Insumo común R1"),
                (_f(SP_R1_ESC1), "R1 Esc1 — CIIU 10, padre LAB/CRR"),
                (_f(SP_R1_ESC2), "R1 Esc2 — CIIU 81/82/90, padre RES/CRR"),
                (_f(SP_R1_ESC3), "R1 Esc3 — otros CIIU, mayor entidades"),
                (_f(SP_R1_ORQ), "Orquestador Regla 1"),
                (_f(SP_R2_PREP), "Insumo común R2"),
                (_f(SP_R2_ESC12), "R2 Esc1+2 — complemento vacío / substring"),
                (_f(SP_R2_ESC3), "R2 Esc3 — misma nomenclatura sin NIT"),
                (_f(SP_R2_ESC4), "R2 Esc4 — diccionario frecuencia complemento"),
                (_f(SP_R2_ESC5), "R2 Esc5 — menor nivel nomenclatura pierde"),
                (_f(SP_R2_ESC6), "R2 Esc6 — frecuencia complemento gana"),
                (_f(SP_R2_MOTOR), "R2 Motor — NIT / empates / nuevas direcciones"),
                (_f(SP_R2_ORQ), "Orquestador Regla 2"),
                (_f(SP_R3_ESC1), "R3 Esc1 — geo misma vía puerta ±2"),
                (_f(SP_R3_ORQ), "Orquestador Regla 3"),
                ("sp_unificacion_mock_regla1.sql", "Orquestador MOCK R1 (lee v_mock_*)"),
                ("sp_unificacion_mock_regla2.sql", "Orquestador MOCK R2"),
                ("sp_unificacion_mock_regla3.sql", "Orquestador MOCK R3"),
                ("(+12 SPs mock por escenario)", "Misma subdivisión con prefijo sp_unificacion_mock_*"),
            ],
        },
        {
            "orden": 3,
            "repo": "db_rcncr_btch_rdshft_dt",
            "rama": "feature/unificacion-edf-views",
            "archivos": [
                ("run_unificacion_ejecucion_secuencial.sql", "CALL regla1 → regla2 → regla3 (reales)"),
                ("run_unificacion_mock_ejecucion_secuencial.sql", "CALL mock_regla1 → mock_regla2 → mock_regla3"),
                ("validacion_unificacion_conteos.sql", "Conteos post-corrida DEV"),
                ("MAPEO_QA_IFR_TABLAS_COLUMNAS.md", "Tablas QA reales + mock"),
            ],
        },
    ]


def build_sps_detalle() -> list[dict]:
    """Un registro por SP — pestaña SPs del mapa HTML."""
    return [
        {
            "id": "R1·PREP",
            "grupo": "Regla 1",
            "archivo": _f(SP_R1_PREP),
            "repo": "_pgm",
            "rol": "Materializar insumo común R1",
            "entra": "bdm_tempo.v_xpm_*",
            "sale": "bdm_tempo.stg_regla1_insumo",
            "logica": "Agrupa RPUs con reportes, CIIU y tipo dirección. Sin unificar aún.",
            "query": "SELECT COUNT(*) FROM bdm_tempo.stg_regla1_insumo;",
        },
        {
            "id": "R1·ESC1",
            "grupo": "Regla 1",
            "archivo": _f(SP_R1_ESC1),
            "repo": "_pgm",
            "rol": "Esc1 — CIIU 10, mismo texto distinto tipo",
            "entra": "stg_regla1_insumo (CIIU=10)",
            "sale": "INSERT unificacion_direccion unifica_atributos=1",
            "logica": "Padre LAB o CRR con más entidades reportan. Empate → no une.",
            "query": "SELECT COUNT(*) FROM bdm_datos.unificacion_direccion WHERE unifica_atributos=1;",
        },
        {
            "id": "R1·ESC2",
            "grupo": "Regla 1",
            "archivo": _f(SP_R1_ESC2),
            "repo": "_pgm",
            "rol": "Esc2 — CIIU 81/82/90, mismo texto distinto tipo",
            "entra": "stg_regla1_insumo",
            "sale": "INSERT unificacion_direccion",
            "logica": "Padre RES o CRR + entidades. Ganador único por grupo.",
            "query": "SELECT COUNT(*) FROM bdm_datos.unificacion_direccion WHERE unifica_atributos=1;",
        },
        {
            "id": "R1·ESC3",
            "grupo": "Regla 1",
            "archivo": _f(SP_R1_ESC3),
            "repo": "_pgm",
            "rol": "Esc3 — otros CIIU, mismo texto distinto tipo",
            "entra": "stg_regla1_insumo",
            "sale": "INSERT unificacion_direccion",
            "logica": "Gana quien reportan más entidades (sin bono LAB/RES).",
            "query": "SELECT COUNT(*) FROM bdm_datos.unificacion_direccion WHERE unifica_atributos=1;",
        },
        {
            "id": "R1·ORQ",
            "grupo": "Orquestador",
            "archivo": _f(SP_R1_ORQ),
            "repo": "_pgm",
            "rol": "Orquestador Regla 1",
            "entra": "Vistas v_xpm_*",
            "sale": "Salida R1 + DROP stg_regla1_insumo",
            "logica": "CALL prep → esc1 → esc2 → esc3 en orden.",
            "query": f"CALL bdm_datos.{SP_R1_ORQ}();",
        },
        {
            "id": "R2·PREP",
            "grupo": "Regla 2",
            "archivo": _f(SP_R2_PREP),
            "repo": "_pgm",
            "rol": "Materializar insumo común R2",
            "entra": "v_xpm_* + salida R1",
            "sale": "stg_regla2_insumo, stg_regla2_e2",
            "logica": "Candidatos con ind_unificacion NULL tras R1.",
            "query": "SELECT COUNT(*) FROM bdm_tempo.stg_regla2_insumo;",
        },
        {
            "id": "R2·ESC1+2",
            "grupo": "Regla 2",
            "archivo": _f(SP_R2_ESC12),
            "repo": "_pgm",
            "rol": "Esc1 complemento vacío · Esc2 substring complemento",
            "entra": "stg_regla2_insumo",
            "sale": "INSERT unificacion_direccion unifica_atributos=2",
            "logica": "Esc1: vacío absorbe con complemento. Esc2: contenido en substring.",
            "query": "SELECT COUNT(*) FROM bdm_datos.unificacion_direccion WHERE unifica_atributos=2;",
        },
        {
            "id": "R2·ESC3",
            "grupo": "Regla 2",
            "archivo": _f(SP_R2_ESC3),
            "repo": "_pgm",
            "rol": "Esc3 — misma nomenclatura sin NIT",
            "entra": "Post Esc1+2",
            "sale": "INSERT unificacion_direccion",
            "logica": "Excluye cod_tipo_ident_fte=3 (NIT).",
            "query": "SELECT COUNT(*) FROM bdm_datos.unificacion_direccion WHERE unifica_atributos=2;",
        },
        {
            "id": "R2·ESC4",
            "grupo": "Regla 2",
            "archivo": _f(SP_R2_ESC4),
            "repo": "_pgm",
            "rol": "Esc4 — diccionario frecuencia complemento",
            "entra": "stg_regla2_e04_*",
            "sale": "INSERT unificacion_direccion",
            "logica": "Gana mayor frecuencia en diccionario; empate excluido.",
            "query": "SELECT COUNT(*) FROM bdm_datos.unificacion_direccion WHERE unifica_atributos=2;",
        },
        {
            "id": "R2·ESC5",
            "grupo": "Regla 2",
            "archivo": _f(SP_R2_ESC5),
            "repo": "_pgm",
            "rol": "Esc5 — menor nivel nomenclatura pierde",
            "entra": "Nomenclaturas distintas mismo texto",
            "sale": "INSERT unificacion_direccion",
            "logica": "Compara nivel jerárquico de vía.",
            "query": "SELECT COUNT(*) FROM bdm_datos.unificacion_direccion WHERE unifica_atributos=2;",
        },
        {
            "id": "R2·ESC6",
            "grupo": "Regla 2",
            "archivo": _f(SP_R2_ESC6),
            "repo": "_pgm",
            "rol": "Esc6 — frecuencia complemento gana",
            "entra": "stg_regla2_e06_freq",
            "sale": "INSERT unificacion_direccion",
            "logica": "Mayor frecuencia acumulada en diccionario.",
            "query": "SELECT COUNT(*) FROM bdm_datos.unificacion_direccion WHERE unifica_atributos=2;",
        },
        {
            "id": "R2·MOTOR",
            "grupo": "Regla 2",
            "archivo": _f(SP_R2_MOTOR),
            "repo": "_pgm",
            "rol": "Motor — NIT, empates Esc5/Esc6, nuevas direcciones",
            "entra": "Claves motor en staging",
            "sale": "stg_motor_insumo (staging, no IFR)",
            "logica": "Enriquece complementos NIT; no escribe en productor.",
            "query": "SELECT COUNT(*) FROM bdm_tempo.stg_motor_insumo;",
        },
        {
            "id": "R2·ORQ",
            "grupo": "Orquestador",
            "archivo": _f(SP_R2_ORQ),
            "repo": "_pgm",
            "rol": "Orquestador Regla 2",
            "entra": "Post R1",
            "sale": "Salida R2 + limpieza staging R2",
            "logica": "CALL prep → esc1+2 → esc3…esc6 → motor → DROP stg_*.",
            "query": f"CALL bdm_datos.{SP_R2_ORQ}();",
        },
        {
            "id": "R3·ESC1",
            "grupo": "Regla 3",
            "archivo": _f(SP_R3_ESC1),
            "repo": "_pgm",
            "rol": "Esc1 — geo misma vía, puerta más cercana (±2)",
            "entra": "lat/long + via_generadora + numero_puerta",
            "sale": "INSERT unificacion_direccion unifica_atributos=3",
            "logica": "Requiere coordenadas; en DEV fuente sin geo → 0 filas.",
            "query": "SELECT COUNT(*) FROM bdm_datos.unificacion_direccion WHERE unifica_atributos=3;",
        },
        {
            "id": "R3·ORQ",
            "grupo": "Orquestador",
            "archivo": _f(SP_R3_ORQ),
            "repo": "_pgm",
            "rol": "Orquestador Regla 3",
            "entra": "Post R2",
            "sale": "Salida R3",
            "logica": f"CALL {SP_R3_ESC1}.",
            "query": f"CALL bdm_datos.{SP_R3_ORQ}();",
        },
    ]


# Mapa escenario UI → nombre SP (para GROUP_LABELS en HTML)
SP_POR_ESCENARIO = {
    "R1": {
        "Insumo": SP_R1_PREP,
        "ESC1": SP_R1_ESC1,
        "ESC2": SP_R1_ESC2,
        "ESC3": SP_R1_ESC3,
        "Política": SP_R1_ORQ,
    },
    "R2": {
        "Insumo": SP_R2_PREP,
        "ESC1": SP_R2_ESC12,
        "ESC2": SP_R2_ESC12,
        "ESC3": SP_R2_ESC3,
        "ESC4": SP_R2_ESC4,
        "ESC5": SP_R2_ESC5,
        "ESC6": SP_R2_ESC6,
        "Motor": SP_R2_MOTOR,
    },
    "R3": {
        "ESC único": SP_R3_ESC1,
    },
}
