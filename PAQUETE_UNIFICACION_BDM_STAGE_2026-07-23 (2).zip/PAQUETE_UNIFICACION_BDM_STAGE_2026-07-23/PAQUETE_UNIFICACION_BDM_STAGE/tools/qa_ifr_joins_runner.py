"""Run IFR/XPM join validation scripts against Redshift QA (read-only)."""
from __future__ import annotations

import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path

import psycopg2
from psycopg2.extras import RealDictCursor

BASE = Path(__file__).resolve().parent.parent
SQL_DIR = BASE / "sql" / "qa_ifr_data"
HOST = os.environ.get(
    "REDSHIFT_HOST",
    "eec-aws-us-eits-procesosbatch-qa-redshift.cwefyckvccgy.us-east-1.redshift.amazonaws.com",
)
PORT = int(os.environ.get("REDSHIFT_PORT", "5440"))
DB = os.environ.get("REDSHIFT_DB", "dba_batch")
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PASSWORD = os.environ.get("REDSHIFT_PASSWORD", "")


def split_sql(text: str) -> list[str]:
    parts: list[str] = []
    buf: list[str] = []
    for line in text.splitlines():
        if line.strip().startswith("--"):
            continue
        buf.append(line)
        if line.rstrip().endswith(";"):
            stmt = "\n".join(buf).strip()
            if stmt:
                parts.append(stmt)
            buf = []
    tail = "\n".join(buf).strip()
    if tail:
        parts.append(tail)
    return parts


def run_file(cur, path: Path) -> list[dict]:
    text = path.read_text(encoding="utf-8")
    out: list[dict] = []
    for stmt in split_sql(text):
        label = "query"
        m = re.search(r"'([^']+)'\s+AS\s+(?:chk|paso)", stmt, re.I)
        if m:
            label = m.group(1)
        try:
            cur.execute(stmt)
            rows = cur.fetchall()
            out.append({"file": path.name, "label": label, "ok": True, "rows": rows, "error": None})
        except Exception as exc:  # noqa: BLE001
            cur.connection.rollback()
            out.append({"file": path.name, "label": label, "ok": False, "rows": [], "error": str(exc)})
    return out


def main() -> int:
    if not PASSWORD:
        print("ERROR: REDSHIFT_PASSWORD not set", file=sys.stderr)
        return 2

    deploy_files = [
        SQL_DIR / "01_ddl_unificacion_direccion.sql",
        SQL_DIR / "00_vistas_insumo_bdm.sql",
    ]
    validate_files = [
        SQL_DIR / "00_validar_joins_columnas_sp.sql",
        SQL_DIR / "00_validar_cod_tipo_ident.sql",
    ]

    conn = psycopg2.connect(
        host=HOST,
        port=PORT,
        dbname=DB,
        user=USER,
        password=PASSWORD,
        sslmode="require",
        connect_timeout=45,
    )
    conn.autocommit = True
    cur = conn.cursor(cursor_factory=RealDictCursor)

    results = {
        "timestamp": datetime.now().isoformat(),
        "host": HOST,
        "user": USER,
        "deploy": [],
        "validation": [],
    }

    for path in deploy_files:
        for item in run_file(cur, path):
            results["deploy"].append(item)

    for path in validate_files:
        for item in run_file(cur, path):
            results["validation"].append(item)

    out_path = BASE / "tools" / "qa_ifr_joins_results.json"
    out_path.write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")

    errors = [x for x in results["deploy"] + results["validation"] if not x["ok"]]
    print(f"host={HOST} user={USER}")
    print(f"deploy_steps={len(results['deploy'])} validation_steps={len(results['validation'])} errors={len(errors)}")
    for item in results["validation"]:
        if not item["ok"]:
            print(f"FAIL {item['file']} {item['label']}: {item['error']}")
            continue
        rows = item["rows"]
        if len(rows) == 1 and len(rows[0]) <= 4:
            print(f"OK   {item['label']}: {dict(rows[0])}")
        else:
            print(f"OK   {item['label']}: {len(rows)} row(s)")

    cur.close()
    conn.close()
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
