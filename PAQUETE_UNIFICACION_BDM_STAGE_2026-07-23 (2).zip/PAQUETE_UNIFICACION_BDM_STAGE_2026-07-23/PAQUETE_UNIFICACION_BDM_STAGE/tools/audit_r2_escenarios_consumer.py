"""Audit R2 scenarios + motor + timing on Reconocer consumer."""
from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path

import psycopg2
from psycopg2.extras import RealDictCursor

ROOT = Path(__file__).resolve().parents[1]
SP_PATH = ROOT / "sql" / "qa_ifr_data" / "06_sp_regla2.sql"
OUT = ROOT / "Documentacion" / "Evidencias_DEV_R2_ESCENARIOS_AUDIT.md"

HOST = "eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com"
DB = os.environ.get("REDSHIFT_CONSUMER_DB", "dba_rncr_batch")
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PWD = os.environ.get("REDSHIFT_CONSUMER_PASSWORD", os.environ.get("REDSHIFT_PASSWORD", ""))
PORT = int(os.environ.get("REDSHIFT_PORT", "5440"))

INSERT_LABELS = [
    ("ESC1_ESC2", "FROM bdm_tempo.stg_regla2_e2\n  WHERE ind_unificacion = 'S'"),
    ("ESC3_DICCIONARIO", "FROM bdm_tempo.stg_regla2_e03_e1"),
    ("ESC4_DICC_FREQ", "FROM bdm_tempo.stg_regla2_e04_e"),
    ("ESC5_NOMENCLATURA", "FROM bdm_tempo.stg_regla2_e05_pares"),
    ("ESC6_FREQ_IGUAL", "FROM bdm_tempo.stg_regla2_e06_pares"),
]


def build_audit_sql() -> str:
    body = SP_PATH.read_text(encoding="utf-8-sig")
    m = re.search(r"BEGIN\s+(.*)\s+END;\s*\$\$", body, re.DOTALL)
    if not m:
        raise RuntimeError("Cannot parse SP body")
    inner = m.group(1)

    inner = re.sub(
        r"\s*-- Limpieza final de staging de esta regla\s+"
        r"DROP TABLE IF EXISTS bdm_tempo\.stg_regla2_insumo;.*?DROP TABLE IF EXISTS bdm_tempo\.stg_motor_insumo;\s*",
        "\n",
        inner,
        flags=re.DOTALL,
    )

    for label, from_clause in INSERT_LABELS:
        pattern = (
            r"INSERT INTO bdm_datos\.unificacion_direccion\s+"
            r"SELECT DISTINCT\s+cod_dw_persona_ubic,\s+id_padre,\s+2,.*?"
            + re.escape(from_clause)
        )
        repl = (
            f"INSERT INTO bdm_tempo.diag_r2_trace (escenario, cod_dw_persona_ubic, id_padre)\n"
            f"  SELECT DISTINCT '{label}', cod_dw_persona_ubic, id_padre\n  "
            + from_clause
        )
        inner, n = re.subn(pattern, repl, inner, count=1, flags=re.DOTALL)
        if n != 1:
            raise RuntimeError(f"Failed to patch INSERT for {label}")

    inner = re.sub(
        r"INSERT INTO bdm_datos\.unificacion_direccion",
        "-- skipped unificacion insert",
        inner,
    )

    return f"""
CREATE TABLE IF NOT EXISTS bdm_tempo.diag_r2_trace (
  escenario VARCHAR(30),
  cod_dw_persona_ubic BIGINT,
  id_padre BIGINT
);

TRUNCATE TABLE bdm_tempo.diag_r2_trace;

{inner}

SELECT 'motor_insumo_filas' AS metric, COUNT(*)::BIGINT AS n FROM bdm_tempo.stg_motor_insumo
UNION ALL
SELECT 'motor_grupos_keys', COUNT(*)::BIGINT FROM bdm_tempo.stg_motor_keys
UNION ALL
SELECT 'motor_ranked_filas', COUNT(*)::BIGINT FROM bdm_tempo.stg_motor_ranked;
"""


def q(cur, sql: str):
    cur.execute(sql)
    if cur.description:
        return [dict(r) for r in cur.fetchall()]
    return []


def main():
    if not PWD:
        raise SystemExit("Set REDSHIFT_CONSUMER_PASSWORD")

    conn = psycopg2.connect(
        host=HOST, port=PORT, dbname=DB, user=USER, password=PWD, sslmode="require"
    )
    conn.autocommit = True
    cur = conn.cursor(cursor_factory=RealDictCursor)

    timings: dict[str, float] = {}

    t0 = time.perf_counter()
    cur.execute("TRUNCATE TABLE bdm_datos.unificacion_direccion")
    cur.execute("CALL bdm_datos.sp_unificacion_regla1()")
    timings["r1_seg"] = round(time.perf_counter() - t0, 1)

    t0 = time.perf_counter()
    cur.execute("CALL bdm_datos.sp_unificacion_regla2()")
    timings["r2_seg"] = round(time.perf_counter() - t0, 1)

    t0 = time.perf_counter()
    cur.execute("CALL bdm_datos.sp_unificacion_regla3()")
    timings["r3_seg"] = round(time.perf_counter() - t0, 1)
    timings["r123_total_seg"] = round(timings["r1_seg"] + timings["r2_seg"] + timings["r3_seg"], 1)

    salida = q(cur, """
        SELECT unifica_atributos, COUNT(*) n
        FROM bdm_datos.unificacion_direccion GROUP BY 1 ORDER BY 1
    """)

    audit_sql = build_audit_sql()
    t0 = time.perf_counter()
    cur.execute(audit_sql)
    timings["audit_rebuild_seg"] = round(time.perf_counter() - t0, 1)

    por_escenario = q(cur, """
        SELECT escenario, COUNT(*) AS filas,
               COUNT(DISTINCT cod_dw_persona_ubic) AS hijas_distintas,
               COUNT(DISTINCT id_padre) AS padres_distintos
        FROM bdm_tempo.diag_r2_trace
        GROUP BY 1 ORDER BY 1
    """)

    motor = q(cur, """
        SELECT 'motor_insumo_filas' AS metric, COUNT(*)::BIGINT AS n FROM bdm_tempo.stg_motor_insumo
        UNION ALL SELECT 'motor_grupos_keys', COUNT(*)::BIGINT FROM bdm_tempo.stg_motor_keys
        UNION ALL SELECT 'motor_ranked_filas', COUNT(*)::BIGINT FROM bdm_tempo.stg_motor_ranked
    """)

    muestras = q(cur, """
        WITH ranked AS (
          SELECT t.*,
            ROW_NUMBER() OVER (PARTITION BY t.escenario ORDER BY t.cod_dw_persona_ubic) AS rn
          FROM bdm_tempo.diag_r2_trace t
        )
        SELECT r.escenario, r.cod_dw_persona_ubic AS hija, r.id_padre AS padre,
               rh.id_buro_persona, ue_h.texto_ubicacion,
               tud.descripcion_tipo_ubicacion_dir AS tipo,
               df_h.complemento AS comp_hija, df_p.complemento AS comp_padre,
               rh.cod_tipo_ident_fte
        FROM ranked r
        JOIN bdm_tempo.v_xpm_relacion_persona_ubicacion rh
          ON rh.cod_dw_persona_ubic = r.cod_dw_persona_ubic
        JOIN bdm_tempo.v_xpm_relacion_persona_ubicacion rp
          ON rp.cod_dw_persona_ubic = r.id_padre
        JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ue_h ON rh.cod_dw_ubic = ue_h.cod_dw_ubic
        LEFT JOIN bdm_tempo.v_xpm_direccion_fisica df_h ON rh.cod_dw_direccion_fisica = df_h.cod_dw_direccion_fisica
        LEFT JOIN bdm_tempo.v_xpm_direccion_fisica df_p ON rp.cod_dw_direccion_fisica = df_p.cod_dw_direccion_fisica
        LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rh.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
        WHERE r.rn <= 3
        ORDER BY r.escenario, r.rn
    """)

    motor_muestras = q(cur, """
        SELECT id_buro_persona, cod_dw_persona_ubic, complemento_motor, generada_enriquecida, cod_tipo_ident_fte
        FROM bdm_tempo.stg_motor_insumo
        LIMIT 5
    """)

    total_trace = sum(r["filas"] for r in por_escenario)

    report = {
        "timings_seg": timings,
        "salida_unificacion": salida,
        "por_escenario": por_escenario,
        "total_trace": total_trace,
        "motor": motor,
        "muestras_escenarios": muestras,
        "muestras_motor": motor_muestras,
    }

    lines = [
        "# Audit R2 — escenarios, motor y tiempos (consumidor DEV)\n\n",
        f"## Tiempos de ejecución (segundos)\n\n```json\n{json.dumps(timings, indent=2)}\n```\n\n",
        f"## Salida unificacion_direccion\n\n```json\n{json.dumps(salida, indent=2, default=str)}\n```\n\n",
        f"## Conteo por escenario (trace audit)\n\n```json\n{json.dumps(por_escenario, indent=2, default=str)}\n```\n\n",
        f"## Motor de direcciones\n\n```json\n{json.dumps(motor, indent=2, default=str)}\n```\n\n",
        "### Muestras motor\n\n```json\n",
        json.dumps(motor_muestras, indent=2, default=str),
        "\n```\n\n### Muestras por escenario\n\n```json\n",
        json.dumps(muestras, indent=2, default=str),
        "\n```\n",
    ]
    OUT.write_text("".join(lines), encoding="utf-8")
    print(json.dumps(report, indent=2, default=str))
    print(f"\nReport: {OUT}")
    cur.close()
    conn.close()


if __name__ == "__main__":
    main()
