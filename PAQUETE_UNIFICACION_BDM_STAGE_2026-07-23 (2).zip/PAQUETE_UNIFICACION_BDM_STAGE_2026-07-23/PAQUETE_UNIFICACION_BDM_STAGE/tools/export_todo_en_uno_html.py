#!/usr/bin/env python3
"""Genera Documentacion/RECONOCER_TODO_EN_UNO.html (E2E + mapas unificación/ordenamiento)."""
from __future__ import annotations

import html as htmllib
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "Documentacion"


def main() -> None:
    e2e = (DOCS / "PROCESO_RECONOCER_END_TO_END.html").read_text(encoding="utf-8")
    unif = (DOCS / "MAPA_UNIFICACION_EDF_VIEWS_NEGOCIO.html").read_text(encoding="utf-8")
    ord_ = (DOCS / "MAPA_ORDENAMIENTO_EDF_VIEWS_NEGOCIO.html").read_text(encoding="utf-8")

    strip = [
        '<a href="PROCESO_RECONOCER_END_TO_END.html" style="font-size:.65rem;color:#1d6fdc;margin-left:.5rem;font-weight:600">Proceso E2E</a>',
        ' <a href="PROCESO_RECONOCER_END_TO_END.html" style="color:#1d6fdc;margin-left:.4rem">Proceso E2E</a> ·',
    ]
    for s in strip:
        unif = unif.replace(s, "")
        ord_ = ord_.replace(s, "")

    m = re.search(r"<main>(.*?)</main>", e2e, re.S)
    e2e_main = m.group(1) if m else e2e
    unif_esc = htmllib.escape(unif)
    ord_esc = htmllib.escape(ord_)

    out = f"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Reconocer Batch — Todo en uno (E2E · Unificación · Ordenamiento)</title>
<style>
:root {{
  --bg:#f0f3f7; --white:#fff; --text:#1a2332; --muted:#5c6b7a;
  --line:#d5dde6; --accent:#1d6fdc; --accent-soft:#e8f1fc;
  --ok:#0d9f6e; --ok-soft:#e6f7f1; --warn:#b86e00; --warn-soft:#fef6e6;
  --prod:#232f3e; --geo:#7c5cbf;
  --sans:"Segoe UI",system-ui,sans-serif; --mono:Consolas,monospace;
  --shadow:0 6px 24px rgba(26,35,50,.08); --radius:14px;
  --shell-h:48px;
}}
* {{ box-sizing:border-box; margin:0; padding:0; }}
html, body {{ height:100%; overflow:hidden; font-family:var(--sans); background:var(--bg); color:var(--text); }}
.shell {{
  position:fixed; top:0; left:0; right:0; height:var(--shell-h); z-index:1000;
  background:var(--white); border-bottom:1px solid var(--line);
  display:flex; align-items:center; gap:.55rem; padding:0 .75rem;
}}
.shell h1 {{ font-size:.95rem; font-weight:800; white-space:nowrap; }}
.tabs {{ display:flex; gap:.3rem; flex:1; min-width:0; overflow-x:auto; }}
.tab {{
  border:1px solid var(--line); background:var(--bg); color:var(--muted);
  font:600 .78rem var(--sans); padding:.35rem .85rem; border-radius:999px; cursor:pointer;
  white-space:nowrap;
}}
.tab:hover {{ color:var(--accent); border-color:var(--accent); background:var(--accent-soft); }}
.tab.active {{ background:var(--accent); color:#fff; border-color:var(--accent); }}
.badge {{
  font-size:.65rem; font-weight:700; padding:.18rem .5rem; border-radius:999px;
  background:var(--ok-soft); color:var(--ok); border:1px solid #b6e8d4; white-space:nowrap;
}}
.badge.warn {{ background:var(--warn-soft); color:var(--warn); border-color:#f0d59a; }}
.panel {{
  position:fixed; top:var(--shell-h); left:0; right:0; bottom:0;
  display:none; background:var(--bg);
}}
.panel.on {{ display:block; }}
.panel iframe {{ width:100%; height:100%; border:0; display:block; background:#fff; }}
#panel-e2e {{ overflow:auto; }}
#panel-e2e .wrap {{ max-width:1100px; margin:0 auto; padding:1.1rem 1rem 2.5rem; }}
#panel-e2e section {{
  background:var(--white); border:1px solid var(--line); border-radius:var(--radius);
  box-shadow:var(--shadow); padding:1.1rem 1.2rem; margin-bottom:.9rem;
}}
#panel-e2e h2 {{ font-size:1.02rem; margin-bottom:.55rem; }}
#panel-e2e h3 {{ font-size:.86rem; color:var(--muted); margin:.85rem 0 .35rem; }}
#panel-e2e p, #panel-e2e li {{ font-size:.88rem; }}
#panel-e2e .muted {{ color:var(--muted); font-size:.8rem; }}
#panel-e2e .flow {{ display:flex; flex-wrap:wrap; gap:.4rem; align-items:center; margin:.55rem 0 0; }}
#panel-e2e .chip {{
  padding:.4rem .65rem; border-radius:10px; font-size:.76rem; font-weight:700;
  border:1px solid var(--line); background:var(--bg);
}}
#panel-e2e .chip.edf {{ background:#fff8e6; border-color:#f0c14b; }}
#panel-e2e .chip.share {{ background:#f3eeff; border-color:#8c4fff; color:#5b2db0; }}
#panel-e2e .chip.unif {{ background:var(--accent-soft); border-color:var(--accent); color:var(--accent); }}
#panel-e2e .chip.ord {{ background:var(--ok-soft); border-color:var(--ok); color:var(--ok); }}
#panel-e2e .chip.geo {{ background:#efe8ff; border-color:var(--geo); color:var(--geo); }}
#panel-e2e .arrow {{ color:var(--muted); font-weight:700; }}
#panel-e2e .grid2 {{ display:grid; grid-template-columns:1fr 1fr; gap:.7rem; }}
@media (max-width:800px) {{ #panel-e2e .grid2 {{ grid-template-columns:1fr; }} }}
#panel-e2e .card {{ border:1px solid var(--line); border-radius:12px; padding:.75rem .85rem; background:var(--bg); }}
#panel-e2e .card h4 {{ font-size:.8rem; margin-bottom:.3rem; }}
#panel-e2e .card ul {{ margin-left:1.05rem; }}
#panel-e2e .card li {{ font-size:.78rem; margin:.12rem 0; }}
#panel-e2e table {{ width:100%; border-collapse:collapse; font-size:.8rem; margin-top:.45rem; }}
#panel-e2e th, #panel-e2e td {{ border:1px solid var(--line); padding:.35rem .5rem; text-align:left; vertical-align:top; }}
#panel-e2e th {{ background:var(--bg); }}
#panel-e2e td.num {{ text-align:right; font-family:var(--mono); font-weight:700; }}
#panel-e2e .ok {{ color:var(--ok); font-weight:700; }}
#panel-e2e .warn {{ color:var(--warn); font-weight:700; }}
#panel-e2e .repo {{ display:flex; gap:.35rem; flex-wrap:wrap; margin-top:.45rem; }}
#panel-e2e .repo span {{
  font-family:var(--mono); font-size:.7rem; padding:.3rem .5rem; border-radius:8px;
  background:var(--prod); color:#fff;
}}
#panel-e2e .repo span:nth-child(2) {{ background:var(--accent); }}
#panel-e2e .repo span:nth-child(3) {{ background:var(--ok); }}
#panel-e2e pre {{
  background:#1a2332; color:#e8eef5; padding:.7rem .85rem; border-radius:10px;
  font-family:var(--mono); font-size:.72rem; overflow-x:auto; margin-top:.45rem;
}}
#panel-e2e .jump {{ display:inline-flex; gap:.4rem; flex-wrap:wrap; margin-top:.55rem; }}
#panel-e2e .jump button {{
  font:600 .75rem var(--sans); padding:.35rem .75rem; border-radius:999px; cursor:pointer;
  border:1px solid var(--accent); background:var(--accent-soft); color:var(--accent);
}}
#panel-e2e .links a {{ display:inline-block; margin:.2rem .45rem .2rem 0; font-size:.8rem; color:var(--accent); }}
</style>
</head>
<body>
<header class="shell">
  <h1>Reconocer Batch</h1>
  <nav class="tabs" role="tablist">
    <button class="tab active" data-panel="e2e" type="button">1 · Proceso E2E</button>
    <button class="tab" data-panel="unif" type="button">2 · Unificación</button>
    <button class="tab" data-panel="ord" type="button">3 · Ordenamiento</button>
  </nav>
  <span class="badge">Cierre = data real (edf_views)</span>
  <span class="badge warn">Mock = laboratorio opcional</span>
</header>

<div id="panel-e2e" class="panel on" role="tabpanel">
  <div class="wrap">
{e2e_main}
  </div>
</div>

<div id="panel-unif" class="panel" role="tabpanel">
  <iframe title="Mapa Unificación" srcdoc="{unif_esc}"></iframe>
</div>

<div id="panel-ord" class="panel" role="tabpanel">
  <iframe title="Mapa Ordenamiento" srcdoc="{ord_esc}"></iframe>
</div>

<script>
(function(){{
  function show(id){{
    document.querySelectorAll('.panel').forEach(p => p.classList.toggle('on', p.id === 'panel-' + id));
    document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.panel === id));
    try {{ history.replaceState(null, '', '#' + id); }} catch(e) {{}}
  }}
  document.querySelectorAll('[data-panel]').forEach(el => {{
    el.addEventListener('click', () => show(el.dataset.panel));
  }});
  document.querySelectorAll('#panel-e2e a[href*="MAPA_UNIFICACION"]').forEach(a => {{
    a.href = '#unif'; a.addEventListener('click', e => {{ e.preventDefault(); show('unif'); }});
  }});
  document.querySelectorAll('#panel-e2e a[href*="MAPA_ORDENAMIENTO"]').forEach(a => {{
    a.href = '#ord'; a.addEventListener('click', e => {{ e.preventDefault(); show('ord'); }});
  }});
  document.querySelectorAll('#panel-e2e a[href*="PROCESO_RECONOCER"]').forEach(a => {{
    a.href = '#e2e'; a.addEventListener('click', e => {{ e.preventDefault(); show('e2e'); }});
  }});
  var hash = (location.hash || '#e2e').replace('#','');
  if (['e2e','unif','ord'].indexOf(hash) >= 0) show(hash);
}})();
</script>
</body>
</html>
"""
    out_path = DOCS / "RECONOCER_TODO_EN_UNO.html"
    out_path.write_text(out, encoding="utf-8")
    print(f"Wrote {out_path} ({out_path.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
