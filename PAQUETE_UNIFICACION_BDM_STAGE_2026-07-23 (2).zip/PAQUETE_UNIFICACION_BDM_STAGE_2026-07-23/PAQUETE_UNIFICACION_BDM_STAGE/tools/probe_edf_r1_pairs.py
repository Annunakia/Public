import os, psycopg2
from psycopg2.extras import RealDictCursor

c = psycopg2.connect(
    host="eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com",
    port=5440, dbname="dba_batch", user="c32525e",
    password=os.environ.get("REDSHIFT_PASSWORD", "b27YWI2FL"), sslmode="require",
)
c.autocommit = True
cur = c.cursor(cursor_factory=RealDictCursor)

cur.execute("""
    SELECT COUNT(*) n FROM (
      SELECT id_buro_persona, texto_ubicacion, cod_dw_ciudad, COUNT(DISTINCT cod_dw_tipo_ubicacion_dir) tipos
      FROM bdm_tempo.v_xpm_contacto_direccion
      WHERE texto_ubicacion IS NOT NULL
      GROUP BY 1,2,3
      HAVING COUNT(DISTINCT cod_dw_tipo_ubicacion_dir) > 1
    ) x
""")
print("multi tipo same address:", cur.fetchone())

cur.execute("""
    SELECT COUNT(DISTINCT id_buro_persona) n
    FROM bdm_tempo.v_xpm_contacto_direccion
    WHERE texto_ubicacion IS NOT NULL AND cod_dw_ciudad IS NOT NULL
""")
print("personas con texto y dane:", cur.fetchone())

cur.execute("""
    SELECT COUNT(*) n FROM bdm_tempo.v_xpm_contacto_direccion
    WHERE cod_dw_ciudad IS NOT NULL
""")
print("con dane:", cur.fetchone())

cur.execute("""
    SELECT id_buro_persona, texto_ubicacion, cod_dw_ciudad,
           LISTAGG(DISTINCT cod_dw_tipo_ubicacion_dir::varchar, ',') tipos,
           COUNT(*) n
    FROM bdm_tempo.v_xpm_contacto_direccion
    WHERE texto_ubicacion IS NOT NULL
    GROUP BY 1,2,3
    HAVING COUNT(DISTINCT cod_dw_tipo_ubicacion_dir) > 1
    LIMIT 5
""")
print("samples multi tipo:", cur.fetchall())

# manual CALL r1 and check stg before drop - run inline insumo count
cur.execute("""
    SELECT COUNT(*) n FROM (
      SELECT rpu.cod_dw_persona_ubic, rpu.id_buro_persona, ubi.texto_ubicacion,
             ubi.cod_dw_ciudad, rpu.cod_dw_tipo_ubicacion_dir,
             COALESCE(ciiu.cod_act_econo_ciiu_fte, '') AS ciiu,
             COUNT(DISTINCT rep.id_buro_suscriptor) AS ent
      FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
      JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
      LEFT JOIN bdm_tempo.v_xpm_direccion_fisica df
        ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
      JOIN bdm_tempo.v_xpm_reporte_relacion_persona_ubica rep
        ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
      LEFT JOIN bdm_tempo.v_xpm_ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona
      LEFT JOIN bdm_datos.tipo_ubicacion_dir tud
        ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
      WHERE rpu.ind_unificacion IS NULL AND ubi.texto_ubicacion IS NOT NULL
      GROUP BY 1,2,3,4,5,6, tud.descripcion_tipo_ubicacion_dir
    ) q
""")
print("insumo rows:", cur.fetchone())

c.close()
