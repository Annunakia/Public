"""Quick IFR counts on procesosbatch DEV (productor)."""
import os
import psycopg2

HOST = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
PWD = os.environ.get("REDSHIFT_PRODUCER_PASSWORD", os.environ.get("REDSHIFT_PASSWORD", ""))

c = psycopg2.connect(
    host=HOST, port=5440, dbname="dba_batch", user="c32525e",
    password=PWD, sslmode="require", connect_timeout=30,
)
cur = c.cursor()
for t in [
    "ifr_data.xpm",
    "ifr_data.xpm_location",
    "ifr_data.xpm_location_val_contactinformations",
    "ifr_data.xpm_counterparties",
]:
    cur.execute(f"SELECT COUNT(*) FROM {t}")
    print(t, cur.fetchone()[0])
cur.execute("SELECT share_name FROM svv_datashares LIMIT 10")
print("datashares", cur.fetchall())
c.close()
