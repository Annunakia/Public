import os, psycopg2
from psycopg2.extras import RealDictCursor

c = psycopg2.connect(
    host="eec-aws-us-eits-procesosbatch-qa-redshift.cwefyckvccgy.us-east-1.redshift.amazonaws.com",
    port=5440,
    dbname="dba_batch",
    user="c32525e",
    password=os.environ["REDSHIFT_PASSWORD"],
    sslmode="require",
    connect_timeout=45,
)
cur = c.cursor(cursor_factory=RealDictCursor)
cur.execute(
    """
    SELECT x.t FROM (
      SELECT DISTINCT CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) AS t
      FROM ifr_data.xpm xpm
      JOIN ifr_data.xpm_location loc
        ON xpm.location = loc.id AND xpm.relationalizelastupdate = loc.relationalizelastupdate
      JOIN ifr_data.xpm_location_val_contactinformations ci
        ON loc."location.val.contactinformations" = ci.id
       AND loc.relationalizelastupdate = ci.relationalizelastupdate
      WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7)
    ) x
    LEFT JOIN bdm_stage.tipo_ubicacion_dir t ON x.t = t.cod_dw_tipo_ubicacion_dir
    WHERE t.cod_dw_tipo_ubicacion_dir IS NULL
    """
)
print("missing_catalog_type:", cur.fetchall())
cur.execute("SELECT cod_dw_tipo_ubicacion_dir, descripcion_tipo_ubicacion_dir FROM bdm_stage.tipo_ubicacion_dir ORDER BY 1")
print("bdm_stage.tipo_ubicacion_dir:", cur.fetchall())
cur.execute(
    """
    SELECT CAST(loc."location.val.personidtype" AS INTEGER) AS cod_tipo_ident_fte, COUNT(*) AS c
    FROM ifr_data.xpm xpm
    JOIN ifr_data.xpm_location loc
      ON xpm.location = loc.id AND xpm.relationalizelastupdate = loc.relationalizelastupdate
    JOIN ifr_data.xpm_location_val_contactinformations ci
      ON loc."location.val.contactinformations" = ci.id
     AND loc.relationalizelastupdate = ci.relationalizelastupdate
    WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7)
    GROUP BY 1 ORDER BY 1
    """
)
print("personidtype_dist:", cur.fetchall())
