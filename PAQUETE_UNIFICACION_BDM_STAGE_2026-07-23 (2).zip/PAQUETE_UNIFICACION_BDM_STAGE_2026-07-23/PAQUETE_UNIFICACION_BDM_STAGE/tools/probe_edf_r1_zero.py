"""Debug why R1/R2/R3 produced 0 rows on edf_views."""
import os, psycopg2
from psycopg2.extras import RealDictCursor

c = psycopg2.connect(
    host="eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com",
    port=5440, dbname="dba_batch", user="c32525e",
    password=os.environ.get("REDSHIFT_PASSWORD", "b27YWI2FL"), sslmode="require",
)
c.autocommit = True
cur = c.cursor(cursor_factory=RealDictCursor)

queries = [
    ("contacto con texto", """
        SELECT COUNT(*) n FROM bdm_tempo.v_xpm_contacto_direccion
        WHERE texto_ubicacion IS NOT NULL AND LENGTH(TRIM(texto_ubicacion)) > 0
    """),
    ("rpu rows", "SELECT COUNT(*) n FROM bdm_tempo.v_xpm_relacion_persona_ubicacion"),
    ("reportes rows", "SELECT COUNT(*) n FROM bdm_tempo.v_xpm_reporte_relacion_persona_ubica"),
    ("join r1 insumo pattern", """
        SELECT COUNT(*) n
        FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
        JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
        JOIN bdm_tempo.v_xpm_reporte_relacion_persona_ubica rep
          ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
        WHERE rpu.ind_unificacion IS NULL
    """),
    ("tipo_ubicacion match", """
        SELECT rpu.cod_dw_tipo_ubicacion_dir, tud.descripcion_tipo_ubicacion_dir, COUNT(*) n
        FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
        LEFT JOIN bdm_datos.tipo_ubicacion_dir tud
          ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
        GROUP BY 1,2 ORDER BY n DESC LIMIT 10
    """),
    ("stg_regla1 exists", """
        SELECT COUNT(*) n FROM pg_tables
        WHERE schemaname='bdm_tempo' AND tablename LIKE 'stg_regla1%'
    """),
]
for name, q in queries:
    print(f"\n--- {name} ---")
    try:
        cur.execute(q)
        print(cur.fetchall())
    except Exception as e:
        print("ERR", str(e).split("\n")[0][:150])

# try manual r1 insumo count with group by
cur.execute("""
    SELECT COUNT(*) n FROM (
      SELECT rpu.cod_dw_persona_ubic
      FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
      JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
      LEFT JOIN bdm_tempo.v_xpm_direccion_fisica df
        ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
      JOIN bdm_tempo.v_xpm_reporte_relacion_persona_ubica rep
        ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
      LEFT JOIN bdm_tempo.v_xpm_ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona
      LEFT JOIN bdm_datos.tipo_ubicacion_dir tud
        ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
      WHERE rpu.ind_unificacion IS NULL
      GROUP BY 1,2,3,4,5,6,7,9
    ) x
""")
print("\n--- grouped insumo rows (broken?) ---", cur.fetchone())

c.close()
