"""
IFR + public schema — deploy and run.

Modes:
  --producer (default)  Productor dba_batch.public + local ifr_data
  --reconocer           Reconocer dba.public + db_ifr_shared (needs datashare)
  --reconocer-deploy-only  Reconocer: prereq + ddl + SPs only
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path

import psycopg2
from psycopg2.extras import RealDictCursor

ROOT = Path(__file__).resolve().parents[1]
PUB = ROOT / "sql" / "dev_ifr_datasharing_public"
DOC = ROOT / "Documentacion" / "Evidencias_DEV_IFR_PUBLIC.md"

PRODUCER_HOST = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
PRODUCER_DB = "dba_batch"
CONSUMER_HOST = "eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com"
CONSUMER_DB = "dba"
USER = "c32525e"
PORT = 5440


def connect(host: str, db: str, pwd: str):
    return psycopg2.connect(
        host=host, port=PORT, dbname=db, user=USER, password=pwd,
        sslmode="require", connect_timeout=60,
    )


def exec_sql(cur, sql: str, label: str) -> dict:
    try:
        cur.execute(sql)
        return {"step": label, "ok": True}
    except Exception as e:
        cur.connection.rollback()
        return {"step": label, "ok": False, "error": str(e).split("\n")[0][:300]}


def exec_file(cur, path: Path, label: str) -> dict:
    return exec_sql(cur, path.read_text(encoding="utf-8"), label)


def _split_create_views(sql: str) -> list[str]:
    parts = re.split(r"(?=CREATE OR REPLACE VIEW)", sql, flags=re.I)
    return [p.strip() for p in parts if p.strip() and "CREATE OR REPLACE VIEW" in p.upper()]


def run_pipeline(cur, use_local_ifr: bool, deploy_only: bool) -> list[dict]:
    log = []
    for label, path in [
        ("prereq", PUB / "00_prerequisitos_public.sql"),
        ("ddl", PUB / "01_ddl_unificacion_direccion.sql"),
    ]:
        log.append(exec_file(cur, path, label))
        if not log[-1]["ok"]:
            return log

    vistas = (PUB / "00_vistas_insumo_bdm.sql").read_text(encoding="utf-8")
    if use_local_ifr:
        vistas = vistas.replace("db_ifr_shared.ifr_data", "ifr_data")
    vista_ok = True
    for i, stmt in enumerate(_split_create_views(vistas)):
        r = exec_sql(cur, stmt if stmt.endswith(";") else stmt + ";", f"vistas_{i}")
        log.append(r)
        if not r["ok"]:
            vista_ok = False
            break
    if not vista_ok and not deploy_only:
        return log

    for sp in ("05_sp_regla1.sql", "06_sp_regla2.sql", "07_sp_regla3.sql"):
        r = exec_file(cur, PUB / sp, sp)
        log.append(r)
        if not r["ok"]:
            return log

    if deploy_only:
        log.append({"step": "execute", "ok": True, "error": "skipped deploy-only"})
        return log

    log.append(exec_file(cur, PUB / "08_ejecucion_secuencial.sql", "execute"))
    return log


def summary(cur) -> dict:
    out = {}
    try:
        cur.execute("SELECT COUNT(*) AS n FROM public.v_xpm_contacto_direccion")
        out["vista_contactos"] = dict(cur.fetchone())
        cur.execute("""
            SELECT unifica_atributos, COUNT(*) AS n
            FROM public.unificacion_direccion GROUP BY 1 ORDER BY 1
        """)
        out["unificacion"] = [dict(r) for r in cur.fetchall()]
    except Exception as e:
        out["error"] = str(e).split("\n")[0][:120]
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--reconocer", action="store_true")
    ap.add_argument("--producer", action="store_true")
    ap.add_argument("--reconocer-deploy-only", action="store_true")
    args = ap.parse_args()

    if args.reconocer or args.reconocer_deploy_only:
        host, db = CONSUMER_HOST, CONSUMER_DB
        pwd = os.environ.get("REDSHIFT_CONSUMER_PASSWORD", os.environ.get("REDSHIFT_PASSWORD", ""))
        local = False
        mode = "reconocer-deploy" if args.reconocer_deploy_only else "reconocer"
        deploy_only = args.reconocer_deploy_only
    else:
        host, db = PRODUCER_HOST, PRODUCER_DB
        pwd = os.environ.get("REDSHIFT_PRODUCER_PASSWORD", os.environ.get("REDSHIFT_PASSWORD", ""))
        local = True
        mode = "producer"
        deploy_only = False

    if not pwd:
        print("Set REDSHIFT_PASSWORD")
        return 1

    print(f"Mode={mode} {host} / {db}")
    conn = connect(host, db, pwd)
    conn.autocommit = True
    cur = conn.cursor(cursor_factory=RealDictCursor)
    log = run_pipeline(cur, use_local_ifr=local, deploy_only=deploy_only)

    for x in log:
        print(f"  [{x['step']}] {'OK' if x['ok'] else 'FAIL'}", (x.get("error") or "")[:90])

    summ = summary(cur) if all(x["ok"] for x in log) else {}
    if summ:
        print("Summary:", summ)

    cur.close()
    conn.close()

    lines = [f"# Evidencias IFR public ({mode})\n", f"Fecha: {datetime.now().isoformat(timespec='seconds')}\n\n"]
    for x in log:
        lines.append(f"- **{x['step']}**: {'OK' if x['ok'] else 'FAIL'}\n")
        if x.get("error") and x["step"] != "execute":
            lines.append(f"  - {x['error'][:200]}\n")
    if summ:
        lines.append(f"\n```json\n{json.dumps(summ, indent=2, default=str)}\n```\n")
    DOC.write_text("".join(lines), encoding="utf-8")
    print(f"Report: {DOC}")
    return 0 if all(x["ok"] for x in log) else 1


if __name__ == "__main__":
    sys.exit(main())
