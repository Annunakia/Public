import os, json, psycopg2
from psycopg2.extras import RealDictCursor

h = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
c = psycopg2.connect(
    host=h, port=5440, dbname="dba_batch", user="c32525e",
    password=os.environ["REDSHIFT_PASSWORD"], sslmode="require",
)
cur = c.cursor(cursor_factory=RealDictCursor)
cur.execute(
    """
    SELECT column_name, data_type
    FROM information_schema.columns
    WHERE table_schema='bdm_stage' AND table_name='direccion_fisica'
    ORDER BY ordinal_position
    """
)
print("df_cols", json.dumps(cur.fetchall(), default=str))
cur.execute(
    """
    SELECT id_buro_persona, COUNT(*) AS n
    FROM bdm_stage.relacion_persona_ubicacion
    WHERE id_buro_persona IN (930001,930008,930010)
    GROUP BY 1 ORDER BY 1
    """
)
print("personas", json.dumps(cur.fetchall(), default=str))
for pid in (930001, 930008, 930010):
    cur.execute(
        """
        SELECT COUNT(*) AS v
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion r
          ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        WHERE r.id_buro_persona = %s AND u.unifica_atributos = 3
        """,
        (pid,),
    )
    print(f"unif_{pid}", cur.fetchone())
c.close()
