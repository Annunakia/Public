"""Tablas ejemplo + narrativa por escenario — Ordenamiento (estilo mapa unificación)."""
from __future__ import annotations


def _n(n: int | float | None) -> str:
    if n is None:
        return "—"
    return f"{int(n):,}".replace(",", ".")


def _tbl(title: str, headers: list[str], rows: list[list]) -> dict:
    return {"title": title, "headers": headers, "rows": rows}


def pack_escenario(regla: str, escenario: str, k: dict) -> dict:
    """Adjunta tablas paso a paso y ejemplos según código de escenario."""
    c = k["canales"]
    extra: dict = {}
    code = escenario.upper()

    if code in ("ORD-RESUMEN", "RESUMEN"):
        extra["_tabla_pasos"] = _tbl(
            "Ordenamiento vs Unificación — qué hace cada proceso",
            ["Proceso", "Pregunta", "Entrada", "Salida", "¿Compite en ranking?"],
            [
                [
                    "Unificación R1/R2/R3",
                    "¿Son la misma dirección?",
                    "Varias RPUs de la misma persona",
                    "Padre gana · hija ind_unificacion=1",
                    "Solo el padre (ganador)",
                ],
                [
                    "Ordenamiento DIR",
                    "¿Qué dirección contactar primero?",
                    "RPUs ganadoras (varias calles posibles)",
                    "lugar 1, 2, 3… por score",
                    "Todas las ganadoras del canal",
                ],
                [
                    "Ordenamiento TEL/CEL/EMA",
                    "¿Qué teléfono/cel/email primero?",
                    "Contactos XPM de la persona",
                    "lugar por canal (independiente)",
                    "No mezcla con DIR ni entre canales",
                ],
            ],
        )
        extra["_tabla_ejemplo"] = _tbl(
            "Ejemplo conceptual — persona con 3 direcciones tras unificación",
            ["RPU", "Calle", "ind_unificacion", "¿Entra a ordenamiento?", "Por qué"],
            [
                ["10001", "Calle 10 #20", "NULL (ganadora)", "Sí ✓", "Vigente; compite por score DIR"],
                ["10002", "Calle 10 #20 apto 3", "1 (hija)", "No ✗", "Absorbida en R2; solo trazabilidad"],
                ["10003", "Carrera 5 #1", "NULL (sin unificar)", "Sí ✓", "Otra ganadora; puede ser lugar 2"],
            ],
        )
        extra["_conclusion"] = (
            f"En DEV: {k['rpu_ganadoras']:,} RPUs ganadoras compiten · "
            f"{k['rpu_hijas']:,} hijas excluidas (F3-02)."
        )

    elif code in ("ORD-FLUJO", "FLUJO"):
        extra["_tabla_pasos"] = _tbl(
            "Pipeline DEV (Opción A) — paso a paso",
            ["Paso", "SP / objeto", "Qué hace", "Por qué así"],
            [
                ["1", "Unificación previa", "R1/R2/R3 → unificacion_direccion", "Ordenamiento no redefine pares padre-hija"],
                ["2", "sp_preparar_insumos_edf", "stg_rpu + stg_insumo_*", "1 lectura datashare; sin copia permanente"],
                ["3", "sp_scoring_*_edf (×4)", "score_ordenamiento por canal", "Misma persona, rankings separados"],
                ["4", "sp_consolidacion_edf", "rpu_orden_prioridad", "Persiste mejor lugar (hoy desde scores)"],
                ["5", "sp_drop_staging_edf", "DROP stg_*", "Staging solo vive una corrida"],
            ],
        )
        extra["_conclusion"] = (
            f"Tiempo DEV: preparar ~{k['preparar_seg']}s · scoring ~{k['scoring_seg']}s · "
            f"{k['total_scores']:,} scores totales."
        )

    elif code in ("ORD-F1-CT", "INSUMO-CT"):
        extra["_tabla_ejemplo"] = _tbl(
            "contactType XPM → canal — quién entra y quién no",
            ["contactType", "Canal", "¿Entra?", "Por qué sí", "Por qué no"],
            [
                ["1,2,3,7,8", "DIR", "Sí ✓", "Dirección física en RPU ganadora", "—"],
                ["4, 5, 8", "TEL", "Sí ✓", "Teléfono fijo en persona con DIR ganadora", "Type 8 también es token dirección en unif."],
                ["9", "CEL", "Sí ✓", "Celular válido", f"Solo {c['CEL']['personas']:,} personas en DEV (cobertura baja)"],
                ["10", "EMA", "Sí ✓", "Email con @", "Sin @ → NO VALIDA en preparar"],
                ["Otros", "—", "No ✗", "—", "No mapeados al modelo de ordenamiento"],
            ],
        )
        extra["_conclusion"] = "TEL/CEL/EMA exigen persona con al menos una dirección ganadora post-unificación."

    elif code in ("ORD-F1-RPU", "RPU-STG"):
        extra["_tabla_ejemplo"] = _tbl(
            "stg_rpu_post_unificacion — elegibilidad fila a fila",
            ["Caso", "ind_unificacion", "¿En staging ganadoras?", "¿Recibe score?", "Por qué"],
            [
                ["Padre R1", "0 o NULL", "Sí ✓", "Sí ✓", "Ganó unificación; dirección vigente"],
                ["Hija absorbida", "1", "Filtrada ✗", "No ✗", "Doc v2.0 F3-02: no ranking como vigente"],
                ["Sin unificar (empate)", "NULL", "Sí ✓", "Sí ✓", "Nunca fue hija; compite normal"],
                ["Motor enriquecida", "NULL", "Sí ✓", "Sí ✓", "RPU nueva vigente post-R2"],
            ],
        )
        extra["_conclusion"] = (
            f"Check DEV: 0 hijas con orden_prioridad · {k['rpu_hijas']:,} hijas sin orden."
        )

    elif code in ("ORD-F1-BETA", "BETAS"):
        extra["_tabla_ejemplo"] = _tbl(
            "Betas — quién define vs quién aplica",
            ["Responsable", "Qué hace", "Artefacto", "Estado DEV"],
            [
                ["Experian", "Define coeficientes y vigencia", "v_beta_ordenamiento_dir/tel/cel/ema", "Pendiente datashare"],
                ["Implementación Redshift", "JOIN y aplica en fórmula score", "bdm_datos.beta_ordenamiento", f"Mock {k['betas']} filas"],
                ["Implementación Redshift", "No recalibra ni redefine características", "SPs scoring", "OK ✓"],
            ],
        )
        extra["_conclusion"] = "Paridad Teradata solo tiene sentido si Experian certifica mismos betas en ambas plataformas."

    elif code in ("ORD-F3-HIJA", "ELEG-HIJA"):
        extra["_tabla_ejemplo"] = _tbl(
            "Caso F3-02 — dirección hija de unificación",
            ["Campo", "Valor hija", "Valor padre ganador", "Regla"],
            [
                ["ind_unificacion", "1", "NULL", "Hija marcada en unificación"],
                ["score_ordenamiento", "— (no existe)", "0.72 (ej.)", "Solo ganadoras reciben score"],
                ["orden_prioridad", "NULL", "1", "Prioridad solo en vigentes"],
                ["unificacion_direccion", "Apunta al padre", "—", "Trazabilidad; ordenamiento no la borra"],
            ],
        )
        extra["_conclusion"] = (
            "Por qué no: la hija ya no es contacto vigente; el negocio contacta al padre. "
            f"DEV: {k['rpu_hijas']:,} hijas sin orden."
        )

    elif code in ("ORD-F3-BLOQ", "ELEG-BLOQ"):
        extra["_tabla_ejemplo"] = _tbl(
            "Bloqueos y NO VÁLIDO — fuera del ranking (F3-01 / F3-03)",
            ["Condición", "¿Compite?", "Por qué sí", "Por qué no", "Dónde se aplica hoy"],
            [
                ["Hija unificación", "No ✗", "—", "No es vigente", "Filtro stg_rpu ind<>1"],
                ["descripcion_gestion = NO VALIDA", "Parcial", "Algunos canales filtran reportes", "Dato DQ no vigente", "TEL en agregación"],
                ["Registro bloqueado", "No ✗", "—", "Excluido antes scoring (doc)", "Upstream IFR (no en SP)"],
                ["Email sin @", "No ✗", "—", "Formato inválido", "05_sp_preparar CASE"],
            ],
        )
        extra["_conclusion"] = "F1-08 (carga/bloqueos upstream) no es alcance del SP; se consume estado ya procesado."

    elif code in ("ORD-DIR-RANK", "DIR-RANK"):
        extra["_tabla_ejemplo"] = _tbl(
            "Caso RANK-01 — dos direcciones, scores distintos (misma persona)",
            ["Dirección", "Score DIR", "lugar", "orden_prioridad", "Por qué"],
            [
                ["Calle 10 #20", "0.84", "1", "1", "Mayor score → primer intento de contacto"],
                ["Carrera 5 #1", "0.71", "2", "2", "Vigente pero menos prioritaria"],
                ["Calle 10 apto 3 (hija)", "—", "—", "NULL", "Excluida por unificación"],
            ],
        )
        extra["_tabla_pasos"] = _tbl(
            "Cómo se calcula el score DIR (resumen)",
            ["Paso", "Ejemplo", "Efecto en ranking"],
            [
                ["Agregar reportes", "12 meses, sector financiero, tipo RES", "Métricas CO00DIR*"],
                ["Categorizar", "Valor → bin 1..4", "Comparación con umbrales fijos"],
                ["Ponderar", "(cat/4) × Beta", "Suma = score"],
                ["Rankear", "ROW_NUMBER por persona", "lugar 1 = máximo score"],
            ],
        )
        extra["_conclusion"] = (
            f"DEV: {c['DIR']['scores']:,} scores DIR · rango {c['DIR']['min']}–{c['DIR']['max']}."
        )

    elif code in ("ORD-DIR-EMP", "DIR-EMPATE"):
        extra["_tabla_ejemplo"] = _tbl(
            "Caso RANK-02 — empate de score (doc v2.0)",
            ["Dirección A", "Dirección B", "Score", "Desempate doc", "Qué hace Redshift"],
            [
                ["Dir A", "Dir B", "0.75", "0.75", "No hay regla funcional nueva"],
                ["—", "—", "Igual", "Preservar baseline Teradata", "ROW_NUMBER — orden no determinístico"],
            ],
        )
        extra["_conclusion"] = "Si en paridad hay diferencia por empate, se registra hallazgo; no se inventa criterio."

    elif code in ("ORD-TEL-02", "TEL-02"):
        extra["_tabla_ejemplo"] = _tbl(
            "Caso TEL-02 — TEL020 (coincidencia geo) fuera de la suma",
            ["Variable", "Se calcula", "Categoriza", "¿Suma al score?", "Estado SP"],
            [
                ["TEL010", "Sí ✓", "Sí ✓", "Sí ✓", "OK"],
                ["TEL020", "Sí ✓", "Sí ✓", "No ✗ (baseline)", "OK ✓ — corregido"],
                ["Resto TEL*", "Sí ✓", "Sí ✓", "Sí ✓", "OK"],
            ],
        )
        extra["_tabla_pasos"] = _tbl(
            "Fórmula Teradata SCORE (Caracteristicas.txt)",
            ["Componente", "En SUM SCORE Teradata", "En SUM Redshift hoy"],
            [
                ["TEL001–TEL019, TEL023, TEL025", "Sí", "Sí ✓"],
                ["TEL020", "No", "No ✓ (corregido 2026-09-04)"],
            ],
        )
        extra["_conclusion"] = (
            "Por qué: baseline calcula TEL020 para trazabilidad pero Sumatoria_Score_Tel lo omite. "
            f"DEV TEL rango {c['TEL']['min']}–{c['TEL']['max']} tras corrección."
        )

    elif code in ("ORD-TEL-RANK", "TEL-RANK"):
        extra["_tabla_ejemplo"] = _tbl(
            "Ranking TEL — independiente de DIR",
            ["Persona", "Teléfono", "Score TEL", "lugar TEL", "¿Afecta orden_prioridad DIR?"],
            [
                ["P-100", "6012345678", "0.62", "1", "No — canales separados"],
                ["P-100", "6019876543", "0.55", "2", "No"],
                ["P-100", "Calle 10 (DIR)", "0.84", "1 (DIR)", "Sí — solo DIR escribe orden_prioridad"],
            ],
        )
        extra["_conclusion"] = f"DEV: {c['TEL']['scores']:,} scores TEL · {c['TEL']['personas']:,} personas."

    elif code in ("ORD-CEL-02", "CEL-02"):
        extra["_tabla_ejemplo"] = _tbl(
            "Caso CEL-02 — CO01CEL018 desde catálogo operador",
            ["Prefijo", "Catálogo", "Valor bruto", "CEL018 (=×100)", "¿Excluir?"],
            [
                ["310", "CLARO", "0.62", "62.0", "No ✓"],
                ["300", "COMCEL", "0.55", "55.0", "No ✓"],
                ["999", "Sin mapeo", "—", "22.0 (default 0.22)", "No ✓"],
            ],
        )
        extra["_tabla_pasos"] = _tbl(
            "Teradata vs Redshift — semántica CEL018",
            ["Plataforma", "Cálculo CO01CEL018", "Default sin operador"],
            [
                ["Teradata", "100 × V_Operador_Ord_Cel.Valor", "0 (excluye en Orden_TM)"],
                ["Redshift doc v2.0", "100 × COALESCE(catalogo.valor, 0.22)", "0.22 ✓"],
            ],
        )
        extra["_conclusion"] = (
            f"DEV: {c['CEL']['personas']:,} personas CEL · {c['CEL']['scores']:,} scores. "
            "catalogo_operador_ord_cel en 02_catalogos_ordenamiento.sql."
        )

    elif code in ("ORD-EMA-03", "EMA-03"):
        extra["_tabla_ejemplo"] = _tbl(
            "Caso EMA-03 — características fuera de la suma final",
            ["Característica", "Calcula", "¿En SUM score?", "Teradata", "Redshift hoy"],
            [
                ["EMA003", "Sí ✓", "No ✗", "No en Sumatoria_Score_Email", "No ✓"],
                ["EMA007", "Sí ✓", "No ✗", "No en Sumatoria_Score_Email", "No ✓"],
                ["EMA018", "Sí ✓", "No ✗", "Hardcoded 0 en suma", "No ✓"],
                ["EMA025", "Sí ✓", "No ✗", "Hardcoded 0 en suma", "No ✓"],
                ["EMA010", "Sí ✓", "Sí ✓", "Sí", "Sí ✓"],
            ],
        )
        extra["_conclusion"] = (
            f"DEV EMA: {c['EMA']['scores']:,} scores · rango {c['EMA']['min']}–{c['EMA']['max']} tras corrección."
        )

    elif code in ("ORD-SALIDA", "CONSOL"):
        extra["_tabla_pasos"] = _tbl(
            "Consolidación — de score a orden_prioridad",
            ["Paso", "Regla", "Por qué"],
            [
                ["1", "Tomar score_ordenamiento canal DIR", "Dirección es canal que alimenta RPU"],
                ["2", "JOIN stg_rpu ganadoras", "Evita escribir en hijas"],
                ["3", "MIN(lugar) por RPU", "Un orden por reporte"],
                ["4", "TRUNCATE + INSERT rpu_orden_prioridad", "Idempotencia por corrida"],
            ],
        )
        extra["_tabla_ejemplo"] = _tbl(
            "Ejemplo salida — persona con 2 direcciones ganadoras",
            ["cod_dw_persona_ubic", "Score", "lugar", "orden_prioridad"],
            [
                ["RPU-501", "0.84", "1", "1"],
                ["RPU-502", "0.71", "2", "2"],
            ],
        )
        extra["_conclusion"] = f"DEV: {k['rpu_con_orden']:,} RPUs con orden_prioridad."

    elif code in ("ORD-ALCANCE", "ALCANCE"):
        extra["_tabla_ejemplo"] = _tbl(
            "Alcance del proceso de ordenamiento en Redshift",
            ["Tema", "En alcance", "Estado DEV"],
            [
                ["DDL, SQL, SP", "Construcción y orquestación en Redshift", "OK ✓"],
                ["Aplicar betas Experian", "Leer catálogo vigente (no definir modelo)", "Parcial — mock local"],
                ["Paridad Teradata", "Solo si mismos betas en ambas plataformas", "Pendiente"],
                ["Procesos upstream", "Unificación, bloqueos, estandarización (consume resultado)", "OK ✓"],
                ["Fases 1–3 Teradata", "Solo si se adopta paridad Control-M completa", "Opción A activa"],
            ],
        )
        extra["_conclusion"] = (
            "Ordenamiento no reimplementa unificación ni carga de ubicaciones: "
            "lee el estado ya procesado en edf_views."
        )

    elif code in ("ORD-VAL", "VALID"):
        extra["_tabla_ejemplo"] = _tbl(
            "Matriz mínima de pruebas — estado DEV",
            ["ID", "Caso", "Esperado", "DEV", "Estado"],
            [
                ["F3-02", "Hija unificación", "Sin score ni orden", f"{k['rpu_hijas']:,} sin orden", "OK ✓"],
                ["RANK-01", "Score distinto", "Mayor → lugar 1", "ROW_NUMBER DESC", "OK ✓"],
                ["TEL-02", "Solo cambia TEL020", "Score igual", "TEL020 fuera SUM", "OK ✓"],
                ["EMA-03", "Solo EMA003/007", "Score igual", "003/007/018/025 fuera", "OK ✓"],
                ["CEL-02", "Sin operador", "Default 0.22", "COALESCE 0.22", "OK ✓"],
                ["MIG-01", "Paridad Teradata", "Condicional Experian", "No corrida", "N/A"],
            ],
        )

    elif code in ("ORD-SP-PREP", "SP-PREP"):
        extra["_tabla_pasos"] = _tbl(
            "sp_ordenamiento_preparar_insumos_edf — pasos internos",
            ["#", "CTAS", "Qué materializa", "Por qué"],
            [
                ["1", "stg_rpu_post_unificacion", "RPU + flag ind_unificacion", "Elegibilidad ganadoras/hijas"],
                ["2", "stg_persona_dir_ganadora", "DISTINCT id_buro_persona", "Filtro TEL/CEL/EMA"],
                ["3–4", "stg_contacto_*", "Canal + dirección RPU", "1 lectura v_xpm_contacto_canal"],
                ["5–8", "stg_insumo_dir/tel/cel/ema", "Filas listas para scoring", "Misma lógica que vistas insumo_*"],
            ],
        )
        extra["_conclusion"] = "Staging vive solo una corrida; drop al final del orquestador."

    elif code in ("ORD-SP-ORQ", "SP-ORQ"):
        extra["_tabla_pasos"] = _tbl(
            "sp_ordenamiento_ejecucion_edf — secuencia exacta",
            ["Orden", "CALL", "Tabla afectada", "Duración DEV"],
            [
                ["1", "sp_preparar_insumos_edf", "bdm_tempo.stg_*", "~78s"],
                ["2", "sp_scoring_dir_edf", "score_ordenamiento DIR", "—"],
                ["3", "sp_scoring_tel_edf", "score_ordenamiento TEL", "—"],
                ["4", "sp_scoring_cel_edf", "score_ordenamiento CEL", "—"],
                ["5", "sp_scoring_ema_edf", "score_ordenamiento EMA", "—"],
                ["6", "sp_consolidacion_edf", "rpu_orden_prioridad", "—"],
                ["7", "sp_drop_staging_edf", "DROP stg_*", "—"],
            ],
        )
        extra["_conclusion"] = f"Total scoring ~{k['scoring_seg']}s · {k['total_scores']:,} scores."

    elif code in ("ORD-BITBUCKET", "BITBUCKET"):
        extra["_tabla_pasos"] = _tbl(
            "Despliegue 3 repos — orden Jenkins",
            ["Orden", "Repo", "Qué despliega", "PR / rama"],
            [
                ["1", "db_rcncr_btch_rdshft_strct", "DDL + catálogos + vistas", "feature/ordenamiento"],
                ["2", "db_rcncr_btch_rdshft_pgm", "8 SPs divididos", "feature/ordenamiento"],
                ["3", "db_rcncr_btch_rdshft_dt", "run + validación", "feature/ordenamiento"],
            ],
        )
        extra["_conclusion"] = "Unificación en feature/unificacion-edf-views (PRs pendientes aprobación)."

    return extra


def esc_codigo(regla: str, escenario: str) -> str:
    if escenario.startswith("ORD-"):
        return escenario
    mapping = {
        "RESUMEN": "ORD-RESUMEN",
        "FLUJO": "ORD-FLUJO",
        "INSUMO-CT": "ORD-F1-CT",
        "RPU-STG": "ORD-F1-RPU",
        "BETAS": "ORD-F1-BETA",
        "ELEG-HIJA": "ORD-F3-HIJA",
        "ELEG-BLOQ": "ORD-F3-BLOQ",
        "DIR-RANK": "ORD-DIR-RANK",
        "DIR-EMPATE": "ORD-DIR-EMP",
        "TEL-02": "ORD-TEL-02",
        "TEL-RANK": "ORD-TEL-RANK",
        "CEL-02": "ORD-CEL-02",
        "EMA-03": "ORD-EMA-03",
        "CONSOL": "ORD-SALIDA",
        "ALCANCE": "ORD-ALCANCE",
        "VALID": "ORD-VAL",
        "SP-PREP": "ORD-SP-PREP",
        "SP-ORQ": "ORD-SP-ORQ",
        "BITBUCKET": "ORD-BITBUCKET",
    }
    return mapping.get(escenario, escenario or "—")
