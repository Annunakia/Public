"""Genera MAPA_ORDENAMIENTO_EDF_VIEWS_NEGOCIO.html — estilo mapa unificación."""
from __future__ import annotations

import json
import re
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "Documentacion" / "MAPA_ORDENAMIENTO_EDF_VIEWS_NEGOCIO.html"
UNIF = ROOT / "Documentacion" / "MAPA_UNIFICACION_EDF_VIEWS_NEGOCIO.html"

sys.path.insert(0, str(ROOT / "tools"))
from mapa_ordenamiento_lexico import (  # noqa: E402
    HEADERS,
    build_alcance,
    build_artefactos,
    build_brechas,
    build_fases_documento,
    build_guion_sesion,
    build_rows,
    build_volumenes,
    load_kpis,
)
from mapa_ordenamiento_sps import (  # noqa: E402
    build_arquitectura,
    build_contact_types,
    build_formulas,
    build_repos_bitbucket,
    build_sps_detalle,
)


def extract_css() -> str:
    text = UNIF.read_text(encoding="utf-8")
    m = re.search(r"<style>(.*?)</style>", text, re.S)
    if not m:
        raise RuntimeError("No se encontró CSS en mapa unificación")
    return m.group(1)


def finalize_row(d: dict) -> dict:
    regla = str(d.get("Regla", "")).replace("▶ ", "").strip()
    d["_regla"] = regla
    d["_section"] = False
    if not d.get("_esc_codigo"):
        d["_esc_codigo"] = d.get("Escenario", "")[:20]
    if not d.get("_titulo_corto"):
        d["_titulo_corto"] = d.get("Subescenario", d.get("Escenario", ""))
    if not d.get("_busca"):
        d["_busca"] = d.get("Qué espera (negocio)", "")
    ej = d.get("Ejemplo verificable (reporte + ID + query)", "")
    if not d.get("_conclusion_regla"):
        d["_conclusion_regla"] = ej if isinstance(ej, str) and "<table" not in ej else ""
    dev = d.get("Qué encontramos DEV", "")
    if not d.get("_dev") and dev and not d.get("_tabla_ejemplo") and not d.get("_tabla_pasos"):
        d["_dev"] = dev if isinstance(dev, str) and "<table" not in dev else ""
    if "_show_query" not in d:
        d["_show_query"] = bool(d.get("Query validación (copiar en dba_rncr_batch)"))
    return d


def render_html(payload: dict) -> str:
    css = extract_css()
    data_json = json.dumps(payload, ensure_ascii=False)
    today = date.today().isoformat()
    cel_personas = payload["kpis"]["canales"]["CEL"]["personas"]
    return f"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Ordenamiento edf_views — mapa DEV (8 SPs + 3 repos)</title>
<style>
{css}
#frame-home .rules-map {{ grid-template-columns: repeat(3, 1fr); }}
.scope-grid {{ display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.65rem; }}
.guion-grid {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.55rem; margin-top: 0.4rem; }}
.guion-card {{
  background: var(--bg); border: 1px solid var(--line); border-radius: 10px;
  padding: 0.55rem 0.7rem; border-left: 3px solid var(--accent, #2a6f97);
}}
.guion-card .paso {{ font-size: 0.72rem; font-weight: 700; color: var(--muted); letter-spacing: 0.04em; }}
.guion-card h4 {{ margin: 0.15rem 0 0.25rem; font-size: 0.92rem; }}
.guion-card p {{ margin: 0; font-size: 0.82rem; line-height: 1.35; color: var(--text); }}
.scope-card {{
  background: var(--bg); border: 1px solid var(--line); border-radius: 10px;
  padding: 0.65rem 0.75rem; border-left: 3px solid var(--line);
}}
.scope-card.ok {{ border-left-color: var(--ok); }}
.scope-card.parcial, .scope-card.pendiente {{ border-left-color: var(--warn); }}
.scope-card.na {{ border-left-color: var(--muted); opacity: 0.85; }}
.scope-card h4 {{ font-size: 0.78rem; margin-bottom: 0.25rem; }}
.scope-card .scope-id {{ font-size: 0.62rem; color: var(--muted); font-weight: 700; }}
.scope-card p {{ font-size: 0.7rem; color: var(--muted); line-height: 1.4; margin-top: 0.2rem; }}
.fases-table, .brechas-table, .artefactos-table {{
  width: 100%; border-collapse: collapse; font-size: 0.72rem;
}}
.fases-table th, .brechas-table th, .artefactos-table th {{
  text-align: left; padding: 0.45rem 0.5rem; background: #eef2f7;
  border-bottom: 1px solid var(--line); font-size: 0.65rem; text-transform: uppercase;
}}
.fases-table td, .brechas-table td, .artefactos-table td {{
  padding: 0.45rem 0.5rem; border-bottom: 1px solid var(--line); vertical-align: top;
}}
.pill {{ display: inline-block; padding: 0.1rem 0.4rem; border-radius: 4px; font-size: 0.62rem; font-weight: 700; }}
.pill.ok {{ background: var(--ok-soft); color: var(--ok); }}
.pill.parcial {{ background: var(--warn-soft); color: var(--warn); }}
.pill.no, .pill.pendiente {{ background: var(--block-soft); color: var(--block); }}
.pill.na {{ background: var(--bg); color: var(--muted); }}
.pill.alta {{ background: var(--block-soft); color: var(--block); }}
.pill.media {{ background: var(--warn-soft); color: var(--warn); }}
.doc-banner {{
  background: var(--accent-soft); border: 1px solid #b8d4f5; border-radius: 10px;
  padding: 0.65rem 0.85rem; font-size: 0.74rem; line-height: 1.45; color: var(--text);
  margin-bottom: 0.75rem;
}}
.doc-banner strong {{ color: var(--accent); }}
.frame-fit.rule-frame:not(#frame-sps) .scenario-nav-item .nav-title {{
  display: block;
  font-size: 0.58rem;
  color: var(--muted);
  line-height: 1.25;
  margin-top: 0.15rem;
  text-align: left;
  white-space: normal;
}}
.scenario-table td.ok {{ color: var(--ok); font-weight: 600; }}
.scenario-table td.fail {{ color: var(--block); font-weight: 600; }}
.formula-grid {{ display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.65rem; }}
.formula-card {{
  background: var(--bg); border: 1px solid var(--line); border-radius: 10px;
  padding: 0.65rem 0.75rem; font-size: 0.72rem;
}}
.formula-card h4 {{ font-size: 0.82rem; margin-bottom: 0.35rem; color: var(--accent); }}
.formula-card .mono {{ font-family: var(--mono); font-size: 0.65rem; color: var(--muted); }}
.formula-card ul {{ margin: 0.35rem 0 0 1rem; line-height: 1.45; }}
.formula-card .out {{ color: var(--block); }}
.arch-flow {{ display: flex; flex-wrap: wrap; gap: 0.4rem; margin: 0.5rem 0; }}
.arch-step {{
  flex: 1 1 140px; background: var(--accent-soft); border: 1px solid #b8d4f5;
  border-radius: 8px; padding: 0.45rem 0.55rem; font-size: 0.68rem;
}}
.arch-step b {{ display: block; font-size: 0.72rem; margin-bottom: 0.15rem; }}
.sp-catalog {{ font-size: 0.7rem; }}
.sp-catalog td code {{ font-size: 0.65rem; }}
.repo-block {{ margin-bottom: 0.75rem; padding: 0.55rem 0.65rem; background: var(--bg); border-radius: 8px; border: 1px solid var(--line); }}
.repo-block h4 {{ font-size: 0.78rem; margin-bottom: 0.3rem; }}
.sp-detail-card {{ font-size: 0.74rem; line-height: 1.45; }}
.sp-detail-card pre {{ background: #1a2332; color: #e8ecf1; padding: 0.5rem; border-radius: 6px; font-size: 0.65rem; overflow-x: auto; margin-top: 0.35rem; }}
#frame-sps.rule-frame {{ --scenario-nav-w: 14rem; }}
#frame-sps .sp-detail-card ol {{ margin: 0.25rem 0 0 1.1rem; }}
#frame-sps .sp-detail-card .conclusion-box {{ margin-top: 0.45rem; }}
@media (max-width: 1100px) {{
  #frame-home .rules-map {{ grid-template-columns: repeat(2, 1fr); }}
  .scope-grid, .formula-grid {{ grid-template-columns: 1fr; }}
}}
</style>
</head>
<body>

<header class="app-header">
  <h1>Ordenamiento</h1>
  <nav class="step-nav" id="stepNav"></nav>
  <span class="header-meta">DEV · {today}</span>
  <div class="progress"><i id="progressBar"></i></div>
</header>

<div class="viewport" id="viewport">
  <div class="canvas" id="canvas">

    <div class="frame frame-on" id="frame-home">
      <div class="frame-fit">
      <div class="frame-title">Cómo explicarlo — alineado a Mesa / Sesión Alineación</div>
      <div class="frame-sub">Opción A · post-unificación · betas catálogo RITM · 4 canales · edf_views</div>

      <div class="doc-banner" id="docBanner"></div>

      <section class="drill-section">
        <div class="drill-section-title">0 · Guión de reunión (2 minutos)</div>
        <p class="drill-section-note">Texto listo para decir en la mesa — mismo lenguaje de las transcripciones (ganadoras, catálogo betas, canales aparte).</p>
        <div class="guion-grid" id="guionGrid"></div>
      </section>

      <section class="drill-section">
        <div class="drill-section-title">1 · Alcance acordado en sesiones</div>
        <p class="drill-section-note">Qué sí construimos ahora vs qué quedó diferido (242, incremental, QA productor).</p>
        <div class="scope-grid" id="scopeGrid"></div>
      </section>

      <section class="drill-section">
        <div class="drill-section-title">2 · Fases para explicar (1 pregunta = 1 fase)</div>
        <p class="drill-section-note">Mapa de reunión Opción A. No es la F1 Teradata incremental (esa no corre aquí).</p>
        <div class="drill-matrix-wrap"><table class="fases-table" id="fasesTable"></table></div>
      </section>

      <section class="drill-section">
        <div class="drill-section-title">3 · Cierres técnicos vs diferidos</div>
        <p class="drill-section-note">TEL-02 / EMA-03 / CEL-02 y <strong>betas RITM</strong> cerrados. MIG-01 e incremental = fuera de alcance ahora (sesión).</p>
        <div class="drill-matrix-wrap"><table class="brechas-table" id="brechasTable"></table></div>
      </section>

      <section class="drill-section">
        <div class="drill-section-title">4 · Arquitectura datasharing (sin copia XPM)</div>
        <p class="drill-section-note">edf_views → staging temporal → scoring → orden_prioridad. Precondición: unificación R1/R2/R3.</p>
        <div class="arch-flow" id="archFlow"></div>
      </section>

      <section class="drill-section">
        <div class="drill-section-title">5 · contactType → canal</div>
        <div class="drill-matrix-wrap"><table class="fases-table" id="contactTypeTable"></table></div>
      </section>

      <section class="drill-section">
        <div class="drill-section-title">6 · Fórmulas de score por canal</div>
        <p class="drill-section-note">Score = Σ (categoría/max × Beta). Variables <span class="out">fuera de suma</span> se calculan pero no mueven ranking.</p>
        <div class="formula-grid" id="formulaGrid"></div>
      </section>

      <section class="drill-section">
        <div class="drill-section-title">7 · Qué estamos contando</div>
        <p class="drill-section-note">Score relativo por canal (DIR, TEL, CEL, EMA). No mezcla canales ni personas.</p>
        <div class="glossary" id="glossary"></div>
      </section>

      <section class="drill-section">
        <div class="drill-section-title">8 · Resumen DEV</div>
        <div class="kpi-row" id="kpiRow"></div>
      </section>

      <section class="drill-section">
        <div class="drill-section-title">9 · Cascada — insumo → score → orden_prioridad</div>
        <p class="drill-section-note">Cada caja es un paso del pipeline. Clic para ubicar en la matriz.</p>
        <div class="metric-toggle" id="metricToggle"></div>
        <div class="drill-cascade-panel">
          <div class="drill-cascade" id="drillCascade"></div>
        </div>
      </section>

      <section class="drill-section drill-section-matrix">
        <div class="drill-section-title">10 · Matriz drill-down</div>
        <p class="drill-matrix-note">Fase → canal → conteos DEV → justificación funcional.</p>
        <div class="drill-matrix-wrap">
          <div class="drill-scroll"><table class="drill-table" id="drillMatrix"></table></div>
        </div>
      </section>

      <section class="drill-section">
        <div class="drill-section-title">11 · Catálogo SP divididos (14 archivos)</div>
        <p class="drill-matrix-note">Un SP por responsabilidad — no monolito. Clic en pestaña <strong>SPs</strong> para detalle completo.</p>
        <div class="drill-matrix-wrap"><table class="artefactos-table sp-catalog" id="spsCatalogTable"></table></div>
      </section>

      <section class="drill-section">
        <div class="drill-section-title">12 · Despliegue Bitbucket (3 repos)</div>
        <div id="reposDeploy"></div>
      </section>

      <section class="drill-section">
        <div class="drill-section-title">13 · Artefactos SQL / SP (índice)</div>
        <div class="drill-matrix-wrap"><table class="artefactos-table" id="artefactosTable"></table></div>
      </section>

      <section class="drill-section">
        <div class="drill-section-title">14 · Preguntas de cierre (sesión)</div>
        <div class="strategic-box">
          <ol>
            <li>¿Confirmamos Opción A (scoring post-unificación EDF) como camino a certificar?</li>
            <li>¿Betas RITM5226589 (47 coefs) son la fuente oficial hasta datashare IFR?</li>
            <li>¿Merge PRs ya abiertos <code>feature/ordenamiento</code> (_strct #4 → _pgm #4 → _dt #8)?</li>
            <li>¿Desbloqueamos consumidor Reconocer DEV y re-evidenciamos con <code>ejecucion_edf(TRUE)</code>?</li>
            <li>¿Demo mesa: smoke 20001–20009 + KPIs DEV (1,22M scores · 0 hijas) con este HTML?</li>
            <li>¿Seguimos dejando fuera: incremental, malla 242, QA productor?</li>
          </ol>
        </div>
      </section>

      <section class="drill-section">
        <div class="drill-section-title">15 · Detalle por fase / canal</div>
        <div class="rules-map" id="rulesMap"></div>
      </section>
      </div>
    </div>

    <div class="frame frame-off" id="frame-fase1">
      <div class="frame-fit rule-frame">
      <div class="frame-title">Fase 1 — Armar candidatos (qué entra)</div>
      <div class="frame-sub">Solo ganadoras · contactType → canal · ejemplo: email sin @ no entra</div>
      <div class="rule-layout">
        <aside class="scenario-nav" id="nav-fase1"></aside>
        <div class="scenario-stage" id="stage-fase1"></div>
      </div>
      </div>
    </div>

    <div class="frame frame-off" id="frame-dir">
      <div class="frame-fit rule-frame">
      <div class="frame-title">Fase 2a — DIR · ¿Qué dirección primero?</div>
      <div class="frame-sub">Ejemplo: persona 20001 casa vs oficina · 20002 una sola calle · 20003 tres calles</div>
      <div class="rule-layout">
        <aside class="scenario-nav" id="nav-dir"></aside>
        <div class="scenario-stage" id="stage-dir"></div>
      </div>
      </div>
    </div>

    <div class="frame frame-off" id="frame-tel">
      <div class="frame-fit rule-frame">
      <div class="frame-title">Fase 2b — TEL · ¿Qué fijo primero?</div>
      <div class="frame-sub">Ejemplo: persona 20004 VALIDA vs NO VALIDA · TEL020 no suma al score</div>
      <div class="rule-layout">
        <aside class="scenario-nav" id="nav-tel"></aside>
        <div class="scenario-stage" id="stage-tel"></div>
      </div>
      </div>
    </div>

    <div class="frame frame-off" id="frame-cel">
      <div class="frame-fit rule-frame">
      <div class="frame-title">Fase 2c — CEL · ¿Qué celular primero?</div>
      <div class="frame-sub">Ejemplo: persona 20006 prefijo 310 vs 320 · sin operador → 0.22</div>
      <div class="rule-layout">
        <aside class="scenario-nav" id="nav-cel"></aside>
        <div class="scenario-stage" id="stage-cel"></div>
      </div>
      </div>
    </div>

    <div class="frame frame-off" id="frame-ema">
      <div class="frame-fit rule-frame">
      <div class="frame-title">Fase 2d — EMA · ¿Qué email primero?</div>
      <div class="frame-sub">Ejemplo: persona 20008 gmail vs corporativo · EMA003/007 no suman</div>
      <div class="rule-layout">
        <aside class="scenario-nav" id="nav-ema"></aside>
        <div class="scenario-stage" id="stage-ema"></div>
      </div>
      </div>
    </div>

    <div class="frame frame-off" id="frame-salida">
      <div class="frame-fit rule-frame">
      <div class="frame-title">Fase 3–4 — Guardar orden y limpiar</div>
      <div class="frame-sub">lugar → orden_prioridad · hijas = NULL · DROP stg_*</div>
      <div class="rule-layout">
        <aside class="scenario-nav" id="nav-salida"></aside>
        <div class="scenario-stage" id="stage-salida"></div>
      </div>
      </div>
    </div>

    <div class="frame frame-off" id="frame-sps">
      <div class="frame-fit rule-frame">
      <div class="frame-title">Catálogo SP — una fase / un archivo</div>
      <div class="frame-sub">Pregunta de negocio + ejemplo smoke · _strct · _pgm · _dt</div>
      <div class="rule-layout">
        <aside class="scenario-nav" id="nav-sps"></aside>
        <div class="scenario-stage" id="stage-sps"></div>
      </div>
      </div>
    </div>

  </div>
</div>

<div class="modal-backdrop" id="queryModal">
  <div class="modal">
    <div class="modal-head">
      <h2>Ver query</h2>
      <p id="modalSubtitle">Copiar y ejecutar en dba_rncr_batch</p>
    </div>
    <div class="modal-body"><pre id="modalSql"></pre></div>
    <div class="modal-foot">
      <button type="button" class="btn btn-primary" id="btnCopyQuery">Copiar query</button>
      <button type="button" class="btn" id="btnCloseModal">Cerrar</button>
    </div>
  </div>
</div>

<div class="toast" id="toast"></div>

<script>
const DATA = {data_json};

const FRAMES = [
  {{ id: 'home', label: 'Drill-down', el: 'frame-home', progress: 0 }},
  {{ id: 'fase1', label: '1 Insumos', el: 'frame-fase1', progress: 14 }},
  {{ id: 'dir', label: '2a DIR', el: 'frame-dir', progress: 28 }},
  {{ id: 'tel', label: '2b TEL', el: 'frame-tel', progress: 42 }},
  {{ id: 'cel', label: '2c CEL', el: 'frame-cel', progress: 56 }},
  {{ id: 'ema', label: '2d EMA', el: 'frame-ema', progress: 70 }},
  {{ id: 'salida', label: '3-4 Salida', el: 'frame-salida', progress: 84 }},
  {{ id: 'sps', label: 'SPs', el: 'frame-sps', progress: 100 }},
];

let currentFrame = 0;
let metricMode = 'ambos';

const RULE_FRAMES = [
  null,
  {{ regla: 'PUNTO DE PARTIDA', nav: 'nav-fase1', stage: 'stage-fase1', extra: ['ALCANCE', 'FASE 1', 'ARQUITECTURA SP', 'REPOS'] }},
  {{ regla: 'CANAL DIR', nav: 'nav-dir', stage: 'stage-dir' }},
  {{ regla: 'CANAL TEL', nav: 'nav-tel', stage: 'stage-tel' }},
  {{ regla: 'CANAL CEL', nav: 'nav-cel', stage: 'stage-cel' }},
  {{ regla: 'CANAL EMA', nav: 'nav-ema', stage: 'stage-ema' }},
  {{ regla: 'CONSOLIDACIÓN', nav: 'nav-salida', stage: 'stage-salida', extra: ['VALIDACIÓN'] }},
];
const SP_ITEMS = DATA.sps_detalle || [];
let spPos = 0;
const ruleRowMap = {{}};
const scenarioPos = {{ 1:0, 2:0, 3:0, 4:0, 5:0, 6:0 }};
let modalSqlText = '';

function fmt(n) {{ return Number(n).toLocaleString('es-CO'); }}
function esc(s) {{ const d=document.createElement('div'); d.textContent=s||''; return d.innerHTML; }}

function badgeClass(estado) {{
  const e = (estado||'').toLowerCase();
  if (e==='ok') return 'ok';
  if (['parcial','pendiente','warn'].some(x=>e.includes(x))) return 'warn';
  return 'neutral';
}}

function pill(estado) {{
  const e = (estado||'').toLowerCase();
  const lbl = {{ok:'OK', parcial:'Parcial', no:'No impl.', pendiente:'Pendiente', na:'N/A', alta:'Alta', media:'Media'}}[e] || estado;
  return `<span class="pill ${{e}}">${{esc(lbl)}}</span>`;
}}

function renderDocBanner() {{
  document.getElementById('docBanner').innerHTML = `
    <strong>Alineado a Mesa de Trabajo + Sesión Alineación</strong> —
    Unificación primero · solo ganadoras · 4 canales · betas = catálogo RITM · Opción A EDF.
    DEV: ${{fmt(DATA.kpis.total_scores)}} scores · 0 hijas mal ordenadas · fórmulas TEL/EMA/CEL OK.
    Empieza por el <strong>guión §0</strong>; luego pestañas Fase 1 → DIR → TEL → CEL → EMA → Salida → SPs.
  `;
}}

function renderGuion() {{
  const items = DATA.guion_sesion || [];
  document.getElementById('guionGrid').innerHTML = items.map(g => `
    <div class="guion-card">
      <div class="paso">PASO ${{esc(g.paso)}}</div>
      <h4>${{esc(g.titulo)}}</h4>
      <p>${{esc(g.decir)}}</p>
    </div>`).join('');
}}

function renderScope() {{
  const items = DATA.alcance || [];
  document.getElementById('scopeGrid').innerHTML = items.map(a => `
    <div class="scope-card ${{esc(a.estado)}}">
      <div class="scope-id">${{esc(a.id)}} · ${{esc(a.responsable)}}</div>
      <h4>${{esc(a.titulo)}}</h4>
      <p>${{pill(a.estado)}} ${{esc(a.detalle)}}</p>
    </div>`).join('');
}}

function renderFases() {{
  const rows = DATA.fases_doc || [];
  let html = `<thead><tr><th>Fase</th><th>Requiere (doc)</th><th>Implementado DEV</th><th>Estado</th><th>Nota</th></tr></thead><tbody>`;
  rows.forEach(f => {{
    html += `<tr>
      <td><strong>${{esc(f.fase)}}</strong><br/><span style="color:var(--muted)">${{esc(f.nombre)}}</span></td>
      <td>${{esc(f.requiere)}}</td>
      <td>${{esc(f.implementado)}}</td>
      <td>${{pill(f.estado)}}</td>
      <td style="color:var(--muted)">${{esc(f.nota)}}</td>
    </tr>`;
  }});
  html += '</tbody>';
  document.getElementById('fasesTable').innerHTML = html;
}}

function renderBrechas() {{
  const rows = DATA.brechas || [];
  let html = `<thead><tr><th>ID</th><th>Canal</th><th>Regla v2.0</th><th>Estado SP</th><th>Prio</th></tr></thead><tbody>`;
  rows.forEach(b => {{
    const st = b.estado === 'ok' ? pill('ok') : pill(b.prio);
    html += `<tr>
      <td><strong>${{esc(b.id)}}</strong></td>
      <td>${{esc(b.canal)}}</td>
      <td>${{esc(b.regla)}}</td>
      <td>${{esc(b.actual)}} ${{st}}</td>
      <td>${{pill(b.prio)}}</td>
    </tr>`;
  }});
  html += '</tbody>';
  document.getElementById('brechasTable').innerHTML = html;
}}

function renderArchFlow() {{
  const steps = DATA.arquitectura || [];
  document.getElementById('archFlow').innerHTML = steps.map(s => `
    <div class="arch-step">
      <b>Paso ${{s.paso}} · ${{esc(s.titulo)}}</b>
      <code>${{esc(s.objeto)}}</code><br/>
      ${{esc(s.detalle)}}
    </div>`).join('');
}}

function renderContactTypes() {{
  const rows = DATA.contact_types || [];
  let html = `<thead><tr><th>contactType</th><th>Canal</th><th>Unificación</th><th>Ordenamiento</th></tr></thead><tbody>`;
  rows.forEach(r => {{
    html += `<tr><td>${{esc(r.types)}}</td><td><strong>${{esc(r.canal)}}</strong></td>
      <td>${{esc(r.unificacion)}}</td><td>${{esc(r.ordenamiento)}}</td></tr>`;
  }});
  html += '</tbody>';
  document.getElementById('contactTypeTable').innerHTML = html;
}}

function renderFormulas() {{
  const items = DATA.formulas || [];
  document.getElementById('formulaGrid').innerHTML = items.map(f => `
    <div class="formula-card">
      <h4>${{esc(f.canal)}}</h4>
      <div class="mono">${{esc(f.formula)}}</div>
      <p><strong>En suma:</strong> ${{f.en_suma.map(x => esc(x)).join(', ')}}</p>
      ${{f.fuera_suma.length ? `<p class="out"><strong>Fuera suma:</strong> ${{f.fuera_suma.map(x => esc(x)).join('; ')}}</p>` : ''}}
      <p style="color:var(--muted);margin-top:0.35rem">${{esc(f.nota)}}</p>
      <p><strong>DEV:</strong> ${{esc(f.dev)}}</p>
    </div>`).join('');
}}

function renderSpsCatalog() {{
  const rows = DATA.sps_detalle || [];
  let html = `<thead><tr><th>ID</th><th>Fase</th><th>Repo</th><th>Archivo</th><th>Pregunta</th><th>Ejemplo</th></tr></thead><tbody>`;
  rows.forEach(s => {{
    html += `<tr><td>${{esc(s.id)}}</td><td>${{esc(s.fase || s.grupo)}}</td><td>${{esc(s.repo)}}</td>
      <td><code>${{esc(s.archivo)}}</code></td><td>${{esc(s.pregunta || s.rol)}}</td>
      <td style="color:var(--muted)">${{esc(s.ejemplo || '')}}</td></tr>`;
  }});
  html += '</tbody>';
  document.getElementById('spsCatalogTable').innerHTML = html;
}}

function renderReposDeploy() {{
  const repos = DATA.repos_bitbucket || [];
  document.getElementById('reposDeploy').innerHTML = repos.map(r => `
    <div class="repo-block">
      <h4>${{r.orden}}. ${{esc(r.repo)}} <span style="color:var(--muted)">(${{esc(r.rama)}})</span></h4>
      <p style="font-size:0.68rem;color:var(--muted);margin-bottom:0.35rem">${{esc(r.nota)}}</p>
      <table class="fases-table"><thead><tr><th>Archivo</th><th>Descripción</th></tr></thead><tbody>
        ${{r.archivos.map(a => `<tr><td><code>${{esc(a[0])}}</code></td><td>${{esc(a[1])}}</td></tr>`).join('')}}
      </tbody></table>
    </div>`).join('');
}}

function renderArtefactos() {{
  const rows = DATA.artefactos || [];
  let html = `<thead><tr><th>Tipo</th><th>Archivo</th><th>Rol</th></tr></thead><tbody>`;
  rows.forEach(a => {{
    html += `<tr><td>${{esc(a.tipo)}}</td><td><code>${{esc(a.archivo)}}</code></td><td>${{esc(a.rol)}}</td></tr>`;
  }});
  html += '</tbody>';
  document.getElementById('artefactosTable').innerHTML = html;
}}

function toast(msg) {{
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2200);
}}

function openQueryModal(sql, title) {{
  modalSqlText = sql || '';
  document.getElementById('modalSql').textContent = modalSqlText;
  document.getElementById('modalSubtitle').textContent = title || 'Validación en dba_rncr_batch';
  document.getElementById('queryModal').classList.add('open');
}}
function closeQueryModal() {{ document.getElementById('queryModal').classList.remove('open'); }}
document.getElementById('btnCloseModal').onclick = closeQueryModal;
document.getElementById('queryModal').onclick = (e) => {{ if (e.target.id==='queryModal') closeQueryModal(); }};
document.getElementById('btnCopyQuery').onclick = () => {{
  navigator.clipboard.writeText(modalSqlText).then(() => toast('Query copiada'));
}};

function fitRuleStage() {{
  const fr = document.querySelector('.frame.frame-on');
  if (!fr || fr.id === 'frame-sps' || !fr.querySelector('.rule-layout')) return;
  const stage = fr.querySelector('.scenario-stage');
  const item = stage?.querySelector('.scenario-item');
  if (!stage || !item) return;
  item.style.transform = '';
  item.style.width = '';
  const sh = stage.clientHeight, sw = stage.clientWidth;
  if (sh < 20 || sw < 20) return;
  const scale = Math.min(1, sw / Math.max(item.scrollWidth,1), sh / Math.max(item.scrollHeight,1));
  const s = Math.max(0.72, scale);
  if (s < 0.992) {{
    item.style.transform = `scale(${{s}})`;
    item.style.transformOrigin = 'top left';
    item.style.width = `${{100/s}}%`;
  }}
}}

function showFrame(idx) {{
  currentFrame = idx;
  const f = FRAMES[idx];
  document.getElementById('progressBar').style.width = f.progress + '%';
  document.querySelectorAll('.step-btn').forEach((b,i) => b.classList.toggle('active', i===idx));
  document.querySelectorAll('.frame').forEach(fr => {{
    const on = fr.id === f.el;
    fr.classList.toggle('frame-on', on);
    fr.classList.toggle('frame-off', !on);
  }});
  if (idx >= 1 && idx <= 6) showRuleScenario(idx, scenarioPos[idx], false);
  if (idx === 7) showSpDetail(spPos, false);
  requestAnimationFrame(() => requestAnimationFrame(fitRuleStage));
}}
function zoomToFrame(idx) {{ showFrame(idx); }}

function buildRuleRowMap() {{
  RULE_FRAMES.forEach((meta, fi) => {{
    if (!meta) return;
    const extras = meta.extra || [];
    ruleRowMap[fi] = DATA.rows.map((r,i) => ({{r,i}})).filter(x =>
      x.r._regla === meta.regla || extras.includes(x.r._regla)
    );
  }});
}}

function escCodigo(row) {{ return row._esc_codigo || row.Escenario || '—'; }}

function renderTabla(tbl, cls) {{
  if (!tbl) return '';
  if (typeof tbl === 'string') {{
    if (!tbl.includes('<table')) return '';
    return `<div class="tbl-block-full">${{tbl}}</div>`;
  }}
  if (!tbl.headers) return '';
  const head = tbl.headers.map(h => `<th>${{esc(h)}}</th>`).join('');
  const rows = (tbl.rows || []).map(r =>
    `<tr>${{r.map(c => {{
      const s = String(c ?? '');
      const cl = s.includes('✓') ? 'ok' : (s.includes('✗') ? 'fail' : '');
      return `<td class="${{cl}}">${{esc(s)}}</td>`;
    }}).join('')}}</tr>`
  ).join('');
  const cap = tbl.title ? `<div class="tbl-caption">${{esc(tbl.title)}}</div>` : '';
  return `${{cap}}<table class="${{cls || 'scenario-table'}}"><thead><tr>${{head}}</tr></thead><tbody>${{rows}}</tbody></table>`;
}}

function wrapTblBlock(tbl, role) {{
  if (!tbl) return '';
  const cls = role === 'ej-full' ? 'tbl-block-ej-full' : 'tbl-block-full';
  return `<div class="tbl-block ${{cls}}">${{renderTabla(tbl, 'scenario-table')}}</div>`;
}}

function renderScenarioCard(row, idx) {{
  const bc = badgeClass(row.Estado);
  const titulo = row._titulo_corto || row.Subescenario || row.Escenario;
  const busca = row._busca || '';
  const dev = row._dev || '';
  const conclusion = row._conclusion_regla || '';
  const q = row['Query validación (copiar en dba_rncr_batch)'] || '';
  const headQueryBtn = q && row._show_query ? `<button type="button" class="btn btn-query btn-head-query btn-card-query" data-idx="${{idx}}">Ver query</button>` : '';
  const tblPasos = wrapTblBlock(row._tabla_pasos, 'full');
  const tblEj = wrapTblBlock(row._tabla_ejemplo, 'ej-full');
  const buscaBlock = busca ? `<div class="scenario-section"><span class="sec-label">Regla de negocio</span><p class="busca-line">${{esc(busca)}}</p></div>` : '';
  const devBlock = dev ? `<div class="scenario-section dev-narrative"><span class="sec-label">Qué encontramos en DEV</span><p>${{esc(dev)}}</p></div>` : '';
  const conclBlock = conclusion ? `<div class="scenario-section conclusion-box"><span class="sec-label">Conclusión</span><p>${{esc(conclusion)}}</p></div>` : '';
  const accion = row['Acción / revisión'];
  const accionBlock = accion ? `<div class="scenario-section"><span class="sec-label">Siguiente paso</span><p>${{esc(accion)}}</p></div>` : '';
  return `<div class="scenario-item">
    <div class="esc-pill paso"><span class="esc-code">${{esc(escCodigo(row))}}</span><span class="esc-kind">Escenario</span></div>
    <div class="scenario-body">
      <div class="scenario-head">
        <div class="scenario-head-main">
          <span class="badge ${{bc}}">${{esc(row.Estado||'—')}}</span>
          <div class="scenario-head-text"><h4>${{esc(titulo)}}</h4></div>
        </div>
        ${{headQueryBtn}}
      </div>
      ${{buscaBlock}}${{tblPasos}}${{tblEj}}${{devBlock}}${{conclBlock}}${{accionBlock}}
    </div>
  </div>`;
}}

function showRuleScenario(frameIdx, pos, scroll) {{
  const meta = RULE_FRAMES[frameIdx];
  if (!meta) return;
  const items = ruleRowMap[frameIdx] || [];
  if (!items.length) return;
  const p = Math.max(0, Math.min(pos, items.length - 1));
  scenarioPos[frameIdx] = p;
  const {{r, i}} = items[p];
  document.getElementById(meta.nav).innerHTML = items.map((it, j) =>
    `<button type="button" class="scenario-nav-item ${{j===p?'active':''}}" data-pos="${{j}}">
      <span class="nav-code">${{esc(escCodigo(it.r))}}</span>
      <span class="nav-title">${{esc(it.r._titulo_corto || it.r.Subescenario || '')}}</span>
    </button>`
  ).join('');
  document.getElementById(meta.stage).innerHTML = renderScenarioCard(r, i);
  document.getElementById(meta.nav).querySelectorAll('.scenario-nav-item').forEach(btn => {{
    btn.onclick = () => showRuleScenario(frameIdx, +btn.dataset.pos, true);
  }});
  document.getElementById(meta.stage).querySelectorAll('.btn-card-query').forEach(btn => {{
    btn.onclick = (e) => {{
      e.stopPropagation();
      const row = DATA.rows[+btn.dataset.idx];
      openQueryModal(row['Query validación (copiar en dba_rncr_batch)'], row._titulo_corto);
    }};
  }});
  if (scroll) fitRuleStage();
}}

function initRuleFrames() {{
  buildRuleRowMap();
  [1,2,3,4,5,6].forEach(fi => showRuleScenario(fi, 0, false));
  initSpFrame();
}}

function renderSpCard(sp) {{
  const pasos = (sp.pasos || []).map((p,i) => `<li><strong>${{i+1}}.</strong> ${{esc(p)}}</li>`).join('');
  const pasosBlock = pasos
    ? `<div class="scenario-section"><span class="sec-label">Pasos internos</span><ol style="margin:0.25rem 0 0 1.1rem;padding:0;font-size:0.72rem;line-height:1.45">${{pasos}}</ol></div>`
    : '';
  const pregunta = sp.pregunta
    ? `<p style="margin:0.25rem 0;color:var(--accent);font-weight:700">${{esc(sp.pregunta)}}</p>`
    : '';
  const ejemplo = sp.ejemplo
    ? `<div class="scenario-section conclusion-box"><span class="sec-label">Ejemplo</span><p>${{esc(sp.ejemplo)}}</p></div>`
    : '';
  return `<div class="scenario-item sp-detail-card">
    <div class="esc-pill paso"><span class="esc-code">${{esc(sp.id)}}</span><span class="esc-kind">${{esc(sp.fase || sp.grupo)}}</span></div>
    <div class="scenario-body">
      <div class="scenario-head">
        <div class="scenario-head-main">
          <span class="badge ok">${{esc(sp.repo)}}</span>
          <div class="scenario-head-text"><h4><code>${{esc(sp.archivo)}}</code></h4></div>
        </div>
        <button type="button" class="btn btn-query btn-head-query btn-sp-query">Ver query</button>
      </div>
      <p style="margin:0.35rem 0"><strong>${{esc(sp.rol)}}</strong></p>
      ${{pregunta}}
      <dl>
        <dt>Entra</dt><dd>${{esc(sp.entra)}}</dd>
        <dt>Sale</dt><dd>${{esc(sp.sale)}}</dd>
        <dt>Lógica</dt><dd>${{esc(sp.logica)}}</dd>
      </dl>
      ${{pasosBlock}}
      ${{ejemplo}}
      <pre class="sp-query-pre">${{esc(sp.query)}}</pre>
    </div>
  </div>`;
}}

function showSpDetail(pos, scroll) {{
  if (!SP_ITEMS.length) return;
  const p = Math.max(0, Math.min(pos, SP_ITEMS.length - 1));
  spPos = p;
  const sp = SP_ITEMS[p];
  document.getElementById('nav-sps').innerHTML = SP_ITEMS.map((s, j) =>
    `<button type="button" class="scenario-nav-item ${{j===p?'active':''}}" data-pos="${{j}}">
      <span class="nav-code">${{esc(s.id)}}</span>
      <span class="nav-title">${{esc((s.fase ? s.fase + ' · ' : '') + (s.rol || s.archivo.replace('sp_','').replace('.sql','')))}}</span>
    </button>`
  ).join('');
  document.getElementById('stage-sps').innerHTML = renderSpCard(sp);
  document.getElementById('nav-sps').querySelectorAll('.scenario-nav-item').forEach(btn => {{
    btn.onclick = () => showSpDetail(+btn.dataset.pos, true);
  }});
  document.getElementById('stage-sps').querySelector('.btn-sp-query')?.addEventListener('click', () => {{
    openQueryModal(sp.query, sp.archivo);
  }});
  if (scroll) fitRuleStage();
}}

function initSpFrame() {{
  showSpDetail(0, false);
}}

const CASCADE_STEPS = [
  {{ regla: 'UNIVERSO', codigo: 'POST-UNIF', label: 'Ganadoras', hint: 'Compiten' }},
  {{ regla: 'UNIVERSO', codigo: 'HIJAS', label: 'Hijas excluidas', hint: 'Sin score' }},
  {{ regla: 'FASE 1', codigo: 'INSUMO-DIR', label: 'Insumo DIR', hint: 'Direcciones' }},
  {{ regla: 'DIR', codigo: 'SCORE', label: 'Score DIR', hint: 'Ranking' }},
  {{ regla: 'TEL', codigo: 'SCORE', label: 'Score TEL', hint: 'Teléfonos' }},
  {{ regla: 'CEL', codigo: 'SCORE', label: 'Score CEL', hint: 'Celulares' }},
  {{ regla: 'EMA', codigo: 'SCORE', label: 'Score EMA', hint: 'Emails' }},
  {{ regla: 'SALIDA', codigo: 'CONSOL', label: 'orden_prioridad', hint: 'Persistencia' }},
];

function volGet(regla, codigo) {{
  return (DATA.volumenes?.filas || []).find(f => f.regla === regla && f.codigo === codigo);
}}

function fmtMetric(f) {{
  if (!f) return '—';
  if (metricMode === 'personas') return fmt(f.personas);
  if (metricMode === 'contactos') return fmt(f.contactos);
  return `${{fmt(f.personas)}} pers · ${{fmt(f.contactos)}} filas`;
}}

function renderGlossary() {{
  const k = DATA.kpis;
  const nAbiertas = (DATA.brechas || []).filter(b => b.estado !== 'ok' && b.estado !== 'na').length;
  document.getElementById('glossary').innerHTML = `
    <div class="glossary-card"><h4>Score</h4><p>Suma (categoría/max × <strong>Beta del catálogo</strong>). Ranking por score DESC → lugar 1, 2, 3…</p></div>
    <div class="glossary-card"><h4>Opción A</h4><p>Acuerdo sesión: scoring directo post-unificación desde <strong>edf_views</strong>. Sin malla 242.</p></div>
    <div class="glossary-card"><h4>Ganadora</h4><p>RPU con ind_unificacion ≠ 1. Las <strong>${{fmt(k.rpu_hijas)}}</strong> hijas no compiten (mesa: unificación alimenta DIR).</p></div>
    <div class="glossary-card"><h4>Betas</h4><p>Catálogo RITM5226589 (47 coefs). <strong>${{nAbiertas}}</strong> brechas técnicas abiertas; MIG-01/F1 diferidos.</p></div>
  `;
}}

function renderMetricToggle() {{
  const el = document.getElementById('metricToggle');
  el.innerHTML = ['personas','contactos','ambos'].map(m =>
    `<button type="button" data-m="${{m}}" class="${{metricMode===m?'active':''}}">${{m==='personas'?'Personas':m==='contactos'?'Filas insumo/score':'Ambos'}}</button>`
  ).join('');
  el.querySelectorAll('button').forEach(b => {{
    b.onclick = () => {{ metricMode = b.dataset.m; renderMetricToggle(); renderCascade(); renderDrillMatrix(); }};
  }});
}}

function renderCascade() {{
  document.getElementById('drillCascade').innerHTML = CASCADE_STEPS.map((s,i) => {{
    const f = volGet(s.regla, s.codigo);
    return `<div class="cascade-step"><div class="step-num">Paso ${{i+1}}</div>
      <div class="cascade-box" data-regla="${{esc(s.regla)}}" data-codigo="${{esc(s.codigo)}}">
        <div class="lbl">${{esc(s.label)}}</div><div class="val">${{fmtMetric(f)}}</div>
        <div class="sub">${{esc(s.hint)}}</div>
      </div></div>`;
  }}).join('');
}}

function renderDrillMatrix() {{
  const filas = DATA.volumenes?.filas || [];
  const hdr = metricMode === 'personas' ? 'Personas' : metricMode === 'contactos' ? 'Filas' : 'Personas · Filas';
  let html = `<thead><tr><th>Fase</th><th>Código</th><th>Objeto</th><th class="num">${{hdr}}</th><th class="num">Ratio</th><th>Justificación</th></tr></thead><tbody>`;
  let last = '';
  filas.forEach(f => {{
    if (f.regla !== last) {{ html += `<tr class="section"><td colspan="6">${{esc(f.regla)}}</td></tr>`; last = f.regla; }}
    html += `<tr><td>${{esc(f.regla)}}</td><td>${{esc(f.codigo)}}</td><td>${{esc(f.escenario)}}</td>
      <td class="num">${{fmtMetric(f)}}</td><td class="num">${{f.ratio ?? '—'}}</td><td class="justif">${{esc(f.busca||'')}}</td></tr>`;
  }});
  html += '</tbody>';
  document.getElementById('drillMatrix').innerHTML = html;
}}

function renderHome() {{
  const k = DATA.kpis;
  const rules = [
    {{ title: '1 · Armar candidatos', tag: 'Ganadoras · XPM', desc: '¿Quién entra? Solo ganadoras. Email sin @ fuera. Ejemplo: hijas no compiten.', dev: `${{fmt(k.rpu_ganadoras)}} RPUs · ${{k.preparar_seg}}s`, frame: 1 }},
    {{ title: '2a · DIR', tag: '¿Calle primero?', desc: 'Persona 20001: casa vs oficina. 20003: tres calles → lugar 1/2/3.', dev: `${{fmt(k.canales.DIR.scores)}} scores`, frame: 2 }},
    {{ title: '2b · TEL', tag: '¿Fijo primero?', desc: 'Persona 20004: VALIDA vs NO VALIDA. Ranking aparte de DIR.', dev: `${{fmt(k.canales.TEL.personas)}} personas`, frame: 3 }},
    {{ title: '2c · CEL', tag: '¿Cel primero?', desc: 'Persona 20006: prefijo 310 vs 320. Sin operador → 0.22.', dev: `${{fmt(k.canales.CEL.personas)}} personas`, frame: 4 }},
    {{ title: '2d · EMA', tag: '¿Email primero?', desc: 'Persona 20008: gmail vs corporativo. Canales no se mezclan.', dev: `${{fmt(k.canales.EMA.scores)}} scores`, frame: 5 }},
    {{ title: '3–4 · Guardar y limpiar', tag: 'orden_prioridad', desc: 'lugar 1 → orden 1. Hijas NULL. Luego DROP stg_*.', dev: `${{fmt(k.rpu_con_orden)}} RPUs`, frame: 6 }},
    {{ title: 'SPs · paso a paso', tag: '14 archivos', desc: 'Cada SP: pregunta + pasos internos + ejemplo smoke.', dev: 'Ver FASES_ORDENAMIENTO_EXPLICADAS.md', frame: 7 }},
  ];
  document.getElementById('rulesMap').innerHTML = rules.map(r => `
    <div class="rules-card" data-frame="${{r.frame}}">
      <h3>${{esc(r.title)}}</h3><span class="esc-tag">${{esc(r.tag)}}</span>
      <p>${{esc(r.desc)}}</p><b>DEV: ${{esc(r.dev)}}</b>
    </div>`).join('');
  document.querySelectorAll('.rules-card').forEach(c => {{
    c.onclick = () => {{ scenarioPos[+c.dataset.frame] = 0; showFrame(+c.dataset.frame); }};
  }});
  document.getElementById('kpiRow').innerHTML = `
    <div class="kpi"><small>Personas</small><b>${{fmt(k.personas)}}</b><span>ganadoras</span></div>
    <div class="kpi"><small>Scores</small><b>${{fmt(k.total_scores)}}</b><span>4 canales</span></div>
    <div class="kpi"><small>orden_prioridad</small><b>${{fmt(k.rpu_con_orden)}}</b><span>RPUs</span></div>
    <div class="kpi"><small>Hijas sin orden</small><b>${{fmt(k.rpu_hijas)}}</b><span>excluidas OK</span></div>
    <div class="kpi"><small>Scoring</small><b>${{k.scoring_seg}}s</b><span>DEV</span></div>
  `;
  renderDocBanner();
  renderGuion();
  renderScope();
  renderFases();
  renderBrechas();
  renderArchFlow();
  renderContactTypes();
  renderFormulas();
  renderSpsCatalog();
  renderReposDeploy();
  renderArtefactos();
  renderGlossary();
  renderMetricToggle();
  renderCascade();
  renderDrillMatrix();
}}

function renderStepNav() {{
  document.getElementById('stepNav').innerHTML = FRAMES.map((f,i) =>
    `<button type="button" class="step-btn" data-idx="${{i}}">${{esc(f.label)}}</button>`
  ).join('');
  document.querySelectorAll('.step-btn').forEach(b => {{
    b.onclick = () => zoomToFrame(+b.dataset.idx);
  }});
}}

renderStepNav();
renderHome();
initRuleFrames();
window.addEventListener('resize', () => {{ showFrame(currentFrame); fitRuleStage(); }});
showFrame(0);
</script>
</body>
</html>"""


def main() -> int:
    k = load_kpis()
    vol = build_volumenes(k)
    rows = [finalize_row(r) for r in build_rows(k)]
    payload = {
        "generated": date.today().isoformat(),
        "kpis": k,
        "volumenes": vol,
        "rows": rows,
        "alcance": build_alcance(),
        "guion_sesion": build_guion_sesion(),
        "fases_doc": build_fases_documento(),
        "brechas": build_brechas(),
        "artefactos": build_artefactos(),
        "arquitectura": build_arquitectura(),
        "repos_bitbucket": build_repos_bitbucket(),
        "sps_detalle": build_sps_detalle(),
        "formulas": build_formulas(),
        "contact_types": build_contact_types(),
    }
    OUT.write_text(render_html(payload), encoding="utf-8")
    print(f"Exported: {OUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
