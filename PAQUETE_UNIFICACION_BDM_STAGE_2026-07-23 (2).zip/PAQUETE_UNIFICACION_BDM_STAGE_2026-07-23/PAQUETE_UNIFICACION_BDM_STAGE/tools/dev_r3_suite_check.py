"""
Suite completa de validación Regla 3 — mocks 930001/008/010 + 931002-931013.
"""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime

import psycopg2
from psycopg2.extras import RealDictCursor

from dev_load_r3_mocks import ALL_PIDS, EXPECT, HOST, MOCKS, PASSWORD, USER

CASES = [
    ("TC-R3-01", 930001, "Excluir Manzana"),
    ("TC-R3-02", 931002, "Geo + diccionario vía generadora"),
    ("TC-R3-03", 931003, "Sin geo — gana fecha reciente"),
    ("TC-R3-04", 931004, "Diccionario vía generadora (TV)"),
    ("TC-R3-05", 931005, "Fuera de rango puerta Δ>2"),
    ("TC-R3-06", 931006, "Excluir Rural"),
    ("TC-R3-07", 931007, "Excluir modificador BIS"),
    ("TC-R3-08", 930008, "Cuadrante N — puerta ±2"),
    ("TC-R3-09", 931009, "Solo uno con geo"),
    ("TC-R3-10", 930010, "Empate diccionario — no unifica"),
    ("TC-R3-11", 931011, "Diccionario desempata escenario 1"),
    ("TC-R3-12", 931012, "Puerta ±2 baseline con geo"),
    ("TC-R3-13", 931013, "Puerta Δ=1 — no unifica"),
]


def validate_persona(cur, pid):
    exp_count, exp_hijo, exp_padre = EXPECT[pid]
    cur.execute(
        """
        SELECT u.cod_dw_persona_ubic AS hijo, u.cod_dw_direccion_unificada AS padre
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion r
          ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        WHERE r.id_buro_persona = %s AND u.unifica_atributos = 3
        """,
        (pid,),
    )
    rows = [dict(r) for r in cur.fetchall()]
    count = len(rows)
    ok_count = count == exp_count
    ok_dir = True
    if exp_count == 1 and exp_hijo and exp_padre:
        ok_dir = any(r["hijo"] == exp_hijo and r["padre"] == exp_padre for r in rows)
    cur.execute(
        """
        SELECT COUNT(*) AS v
        FROM bdm_stage.unificacion_direccion u
        JOIN bdm_stage.relacion_persona_ubicacion r1
          ON r1.cod_dw_persona_ubic = u.cod_dw_persona_ubic
        JOIN bdm_stage.unificacion_direccion u2
          ON u2.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
         AND u2.cod_dw_direccion_unificada = u.cod_dw_persona_ubic
        WHERE r1.id_buro_persona = %s AND u.unifica_atributos = 3
        """,
        (pid,),
    )
    cross = cur.fetchone()["v"]
    status = "PASSED" if ok_count and ok_dir and cross == 0 else "FAILED"
    return {
        "id_buro_persona": pid,
        "unif_count": count,
        "expected_count": exp_count,
        "rows": rows,
        "expected_hijo": exp_hijo,
        "expected_padre": exp_padre,
        "cross_pairs": int(cross),
        "status": status,
    }


def main():
    if not PASSWORD:
        print("Set REDSHIFT_PASSWORD")
        sys.exit(1)

    reload = "--reload" in sys.argv
    conn = psycopg2.connect(
        host=HOST, port=5440, dbname="dba_batch", user=USER,
        password=PASSWORD, sslmode="require",
    )
    conn.autocommit = True

    report = {"host": HOST, "executed_at": datetime.now().isoformat(), "cases": []}

    if reload:
        wcur = conn.cursor()
        for pid in ALL_PIDS:
            wcur.execute(
                """
                DELETE FROM bdm_stage.unificacion_direccion
                WHERE cod_dw_persona_ubic IN (
                  SELECT cod_dw_persona_ubic FROM bdm_stage.relacion_persona_ubicacion
                  WHERE id_buro_persona = %s
                )
                """,
                (pid,),
            )
            wcur.execute(
                "UPDATE bdm_stage.relacion_persona_ubicacion SET ind_unificacion = NULL WHERE id_buro_persona = %s",
                (pid,),
            )
        wcur.execute("CALL bdm_stage.sp_unificacion_regla3()")
        wcur.close()
        report["r3_run"] = "ok"

    vcur = conn.cursor(cursor_factory=RealDictCursor)
    for case_id, pid, desc in CASES:
        if pid not in EXPECT:
            continue
        cur2 = conn.cursor(cursor_factory=RealDictCursor)
        cur2.execute(
            "SELECT COUNT(*) n FROM bdm_stage.relacion_persona_ubicacion WHERE id_buro_persona=%s",
            (pid,),
        )
        if cur2.fetchone()["n"] == 0:
            report["cases"].append({"case": case_id, "desc": desc, "status": "SKIPPED", "reason": "mock not loaded"})
            cur2.close()
            continue
        cur2.close()
        res = validate_persona(vcur, pid)
        report["cases"].append({"case": case_id, "desc": desc, **res})

    report["passed"] = sum(1 for c in report["cases"] if c.get("status") == "PASSED")
    report["skipped"] = sum(1 for c in report["cases"] if c.get("status") == "SKIPPED")
    report["total"] = len(report["cases"])
    report["failed"] = [c["case"] for c in report["cases"] if c.get("status") == "FAILED"]

    out_path = os.path.join(os.path.dirname(__file__), "dev_r3_suite_results.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, default=str)
    print(json.dumps(report, indent=2, default=str))
    vcur.close()
    conn.close()


if __name__ == "__main__":
    main()
