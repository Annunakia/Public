"""Convierte GUIA_ORDENAMIENTO_EJEMPLOS_BASICOS.md a PDF (HTML + Edge headless)."""
from __future__ import annotations

import re
import subprocess
from pathlib import Path

import markdown

ROOT = Path(__file__).resolve().parents[1]
MD = ROOT / "Documentacion" / "GUIA_ORDENAMIENTO_EJEMPLOS_BASICOS.md"
HTML_OUT = ROOT / "Documentacion" / "GUIA_ORDENAMIENTO_EJEMPLOS_BASICOS.html"
PDF_OUT = ROOT / "Documentacion" / "GUIA_ORDENAMIENTO_EJEMPLOS_BASICOS.pdf"

EDGE = Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe")
CHROME = Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe")


def md_to_html(text: str) -> str:
    text = re.sub(
        r"```mermaid\n.*?```",
        (
            "\n\n**Flujo:** Unificación previa → Fase 1 Insumos → "
            "Fase 2 Scoring (4 canales) → Salida Consolidación → Limpieza staging\n\n"
        ),
        text,
        flags=re.S,
    )
    body = markdown.markdown(
        text,
        extensions=["tables", "fenced_code", "nl2br", "sane_lists"],
    )
    return f"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8"/>
<title>Guía de ordenamiento — ejemplos básicos</title>
<style>
@page {{ margin: 18mm 14mm; }}
body {{
  font-family: "Segoe UI", Arial, sans-serif;
  font-size: 11pt;
  line-height: 1.5;
  color: #1a1a1a;
  max-width: 210mm;
  margin: 0 auto;
  padding: 12mm 10mm;
}}
h1 {{
  font-size: 22pt;
  color: #1558b0;
  border-bottom: 2px solid #1558b0;
  padding-bottom: 6px;
}}
h2 {{
  font-size: 14pt;
  color: #1558b0;
  margin-top: 20px;
  page-break-after: avoid;
}}
h3 {{
  font-size: 11.5pt;
  color: #333;
  margin-top: 14px;
  page-break-after: avoid;
}}
table {{
  border-collapse: collapse;
  width: 100%;
  margin: 10px 0 14px;
  font-size: 9.5pt;
}}
th, td {{
  border: 1px solid #c5cdd8;
  padding: 6px 8px;
  text-align: left;
  vertical-align: top;
}}
th {{ background: #eef2f7; font-weight: 700; }}
code {{
  font-family: Consolas, monospace;
  font-size: 9pt;
  background: #f4f6f8;
  padding: 1px 4px;
  border-radius: 3px;
}}
pre {{
  font-family: Consolas, monospace;
  font-size: 8.5pt;
  background: #f4f6f8;
  border: 1px solid #d8dee6;
  border-radius: 6px;
  padding: 10px;
  white-space: pre-wrap;
}}
pre code {{ background: transparent; padding: 0; }}
blockquote {{
  border-left: 4px solid #1558b0;
  margin: 10px 0;
  padding: 6px 14px;
  background: #f8fafc;
}}
hr {{ border: none; border-top: 1px solid #d8dee6; margin: 16px 0; }}
@media print {{
  body {{ padding: 0; }}
  h2, h3 {{ page-break-after: avoid; }}
  table, pre {{ page-break-inside: avoid; }}
}}
</style>
</head>
<body>{body}</body>
</html>"""


def browser_exe() -> Path:
    if EDGE.exists():
        return EDGE
    if CHROME.exists():
        return CHROME
    raise SystemExit("No se encontró Edge ni Chrome para generar PDF.")


def html_to_pdf(html_path: Path, pdf_path: Path) -> None:
    url = html_path.resolve().as_uri()
    browser = browser_exe()
    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    if pdf_path.exists():
        pdf_path.unlink()
    cmd = [
        str(browser),
        "--headless=new",
        "--disable-gpu",
        "--no-pdf-header-footer",
        f"--print-to-pdf={pdf_path.resolve()}",
        url,
    ]
    subprocess.run(cmd, check=True, capture_output=True, timeout=60)
    if not pdf_path.exists():
        raise RuntimeError("Edge/Chrome no generó el archivo PDF.")


def main() -> None:
    if not MD.exists():
        raise SystemExit(f"No existe: {MD}")
    HTML_OUT.write_text(md_to_html(MD.read_text(encoding="utf-8")), encoding="utf-8")
    html_to_pdf(HTML_OUT, PDF_OUT)
    print(f"HTML: {HTML_OUT}")
    print(f"PDF:  {PDF_OUT}")


if __name__ == "__main__":
    main()
