"""
DEV IFR datasharing — deploy + run pipeline on Reconocer Batch DEV.

Preflight → prerequisitos → DDL → vistas (db_ifr_shared) → smoke → SPs QA → R1/R2/R3 → validaciones.

Usage:
  set REDSHIFT_PASSWORD=...
  python tools/dev_ifr_datasharing_run.py
  python tools/dev_ifr_datasharing_run.py --preflight-only
  python tools/dev_ifr_datasharing_run.py --through smoke
  python tools/dev_ifr_datasharing_run.py --public-temp   # db=dba, schema public
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path

import psycopg2
from psycopg2.extras import RealDictCursor

ROOT = Path(__file__).resolve().parents[1]
DEV_SQL = ROOT / "sql" / "dev_ifr_datasharing"
QA_SQL = ROOT / "sql" / "qa_ifr_data"
DOC_OUT = ROOT / "Documentacion" / "Evidencias_DEV_IFR_DATASHARING.md"

HOST = os.environ.get(
    "REDSHIFT_CONSUMER_HOST",
    "eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com",
)
PRODUCER_HOST = os.environ.get(
    "REDSHIFT_PRODUCER_HOST",
    "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com",
)
PORT = int(os.environ.get("REDSHIFT_PORT", "5440"))
DB = os.environ.get("REDSHIFT_CONSUMER_DB", "dba_reconocerbatch")
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PASSWORD = os.environ.get("REDSHIFT_PASSWORD", "")
# Reconocer (consumidor) puede usar clave distinta a procesosbatch DEV
CONSUMER_PASSWORD = os.environ.get("REDSHIFT_CONSUMER_PASSWORD", PASSWORD)
PRODUCER_PASSWORD = os.environ.get("REDSHIFT_PRODUCER_PASSWORD", PASSWORD)
PRODUCER_DB = os.environ.get("REDSHIFT_PRODUCER_DB", "dba_batch")

STAGES = [
    ("preflight", None),
    ("prerequisitos", DEV_SQL / "00_prerequisitos_dev.sql"),
    ("ddl", DEV_SQL / "01_ddl_unificacion_direccion.sql"),
    ("vistas", DEV_SQL / "00_vistas_insumo_bdm.sql"),
    ("smoke", DEV_SQL / "00_validar_solo_lectura_ifr_data.sql"),
    ("deploy_sp_r1", QA_SQL / "05_sp_regla1.sql"),
    ("deploy_sp_r2", QA_SQL / "06_sp_regla2.sql"),
    ("deploy_sp_r3", QA_SQL / "07_sp_regla3.sql"),
    ("execute", QA_SQL / "08_ejecucion_secuencial.sql"),
    ("validaciones", QA_SQL / "03_validaciones_unificacion.sql"),
]

PREFLIGHT_QUERIES = [
    ("session", "SELECT current_user AS login_user, current_database() AS db_name"),
    ("datashares", "SELECT share_name, producer_account, producer_namespace FROM svv_datashares LIMIT 20"),
    ("external_dbs", "SELECT * FROM svv_external_databases LIMIT 20"),
    ("external_tables", "SELECT * FROM svv_external_tables LIMIT 20"),
    ("db_ifr_shared_exists", """
        SELECT datname FROM pg_database WHERE datname = 'db_ifr_shared'
    """),
    ("ifr_count_xpm", "SELECT COUNT(*) AS n FROM db_ifr_shared.ifr_data.xpm"),
    ("schemas_local", """
        SELECT schema_name FROM information_schema.schemata
        WHERE schema_name IN ('bdm_datos','bdm_tempo','ifr_data','rec_datos','rec_stage')
        ORDER BY 1
    """),
    ("perm_create_schema", """
        SELECT has_database_privilege('c32525e', current_database(), 'CREATE') AS can_create_in_db
    """),
    ("procs", """
        SELECT n.nspname AS schema, p.proname AS proc
        FROM pg_proc p JOIN pg_namespace n ON p.pronamespace = n.oid
        WHERE p.proname ILIKE '%unificacion%'
        ORDER BY 1, 2
    """),
]

PRODUCER_PREFLIGHT = [
    ("producer_datashares", "SELECT share_name, producer_account FROM svv_datashares LIMIT 20"),
    ("producer_share_objects", """
        SELECT share_name, object_name, object_type
        FROM svv_datashare_objects
        WHERE share_name ILIKE '%reconocer%' OR share_name ILIKE '%ifr%'
        LIMIT 30
    """),
    ("producer_ifr_local", """
        SELECT 'ifr_data.xpm' AS obj, COUNT(*) AS n FROM ifr_data.xpm
        UNION ALL SELECT 'ifr_data.xpm_location', COUNT(*) FROM ifr_data.xpm_location
    """),
]


def rows_to_dicts(cur) -> list[dict]:
    if not cur.description:
        return []
    rows = cur.fetchall()
    if rows and hasattr(rows[0], "keys"):
        return [dict(r) for r in rows]
    cols = [d[0] for d in cur.description]
    return [dict(zip(cols, r)) for r in rows]


def split_sql(text: str) -> list[str]:
    """Split SQL file into executable statements (skip comments-only blocks)."""
    parts = re.split(r";\s*\n", text)
    out = []
    for p in parts:
        stmt = p.strip()
        if not stmt:
            continue
        lines = [ln for ln in stmt.splitlines() if ln.strip() and not ln.strip().startswith("--")]
        if not lines:
            continue
        out.append(stmt if stmt.endswith(";") else stmt + ";")
    return out


def connect(host: str, dbname: str, password: str | None = None):
    return psycopg2.connect(
        host=host,
        port=PORT,
        dbname=dbname,
        user=USER,
        password=password or PASSWORD,
        sslmode="require",
        connect_timeout=45,
    )


def run_selects(cur, sql: str, label: str) -> dict:
    rows_all = []
    errors = []
    for stmt in split_sql(sql):
        try:
            cur.execute(stmt)
            if cur.description:
                rows = rows_to_dicts(cur)
                rows_all.append({"statement": stmt[:200], "rows": rows})
        except Exception as e:
            cur.connection.rollback()
            errors.append({"statement": stmt[:200], "error": str(e)})
    return {"label": label, "result_sets": rows_all, "errors": errors, "ok": len(errors) == 0}


def run_file(cur, path: Path, label: str) -> dict:
    sql = path.read_text(encoding="utf-8")
    if label.startswith("deploy_sp") or label in ("prerequisitos", "ddl", "vistas"):
        try:
            cur.execute(sql)
            return {"label": label, "file": str(path.name), "ok": True, "error": None}
        except Exception as e:
            cur.connection.rollback()
            return {"label": label, "file": str(path.name), "ok": False, "error": str(e)}
    return run_selects(cur, sql, label)


def preflight(cur) -> dict:
    out = {"checks": {}, "gaps": [], "ok": True}
    for name, sql in PREFLIGHT_QUERIES:
        try:
            cur.execute(sql)
            if cur.description:
                out["checks"][name] = rows_to_dicts(cur)
            else:
                out["checks"][name] = []
        except Exception as e:
            cur.connection.rollback()
            out["checks"][name] = {"error": str(e)}
            if name in ("db_ifr_shared_exists", "ifr_count_xpm"):
                out["gaps"].append(f"BLOQUEANTE: {name} — {e}")
                out["ok"] = False

    if not out["checks"].get("datashares") or (
        isinstance(out["checks"]["datashares"], list) and len(out["checks"]["datashares"]) == 0
    ):
        out["gaps"].append("BLOQUEANTE: svv_datashares vacío — DBA debe crear datashare y montar db_ifr_shared")

    ext = out["checks"].get("external_dbs")
    if isinstance(ext, list) and not any(
        r.get("database_name") == "db_ifr_shared" for r in ext if isinstance(r, dict)
    ):
        if "db_ifr_shared" not in str(out["checks"].get("db_ifr_shared_exists", "")):
            out["gaps"].append("BLOQUEANTE: database db_ifr_shared no montada en consumidor")

    perm = out["checks"].get("perm_create_schema", [])
    if isinstance(perm, list) and perm and not perm[0].get("can_create_in_db"):
        out["gaps"].append(
            "WARN: c32525e sin CREATE en DB — usar --public-temp (db=dba) o DBA ejecuta 00_grants_dba_reconocer.sql"
        )

    return out


def producer_preflight() -> dict:
    out = {"host": PRODUCER_HOST, "checks": {}, "gaps": []}
    try:
        conn = psycopg2.connect(
            host=PRODUCER_HOST,
            port=PORT,
            dbname=PRODUCER_DB,
            user=USER,
            password=PRODUCER_PASSWORD,
            sslmode="require",
            connect_timeout=45,
        )
        conn.autocommit = True
        cur = conn.cursor(cursor_factory=RealDictCursor)
        for name, sql in PRODUCER_PREFLIGHT:
            try:
                cur.execute(sql)
                out["checks"][name] = rows_to_dicts(cur)
            except Exception as e:
                cur.connection.rollback()
                out["checks"][name] = {"error": str(e)}
        cur.close()
        conn.close()
    except Exception as e:
        out["connection_error"] = str(e)
        out["gaps"].append(f"No se pudo conectar productor DEV: {e}")
    shares = out["checks"].get("producer_datashares", [])
    if isinstance(shares, list) and len(shares) == 0:
        out["gaps"].append("Productor DEV: sin datashares publicados aún (ds_reconocer_ifr_dev pendiente DBA)")
    return out


def analyze_gaps(report: dict) -> list[str]:
    gaps = list(report.get("preflight", {}).get("gaps", []))
    gaps.extend(report.get("producer_preflight", {}).get("gaps", []))
    for step in report.get("steps", []):
        if not step.get("ok", True):
            gaps.append(f"FALLÓ etapa {step.get('label')}: {step.get('error') or step.get('errors')}")
    return gaps


def write_markdown(report: dict, gaps: list[str]) -> None:
    pf_ifr = report.get("producer_preflight", {}).get("checks", {}).get("producer_ifr_local", [])
    lines = [
        "# Evidencias — DEV IFR Data Sharing (Reconocer)",
        "",
        f"**Ejecutado:** {report.get('executed_at')}  ",
        f"**Consumidor:** `{report.get('host')}` / `{report.get('database')}`  ",
        f"**Productor:** `{PRODUCER_HOST}` / `{PRODUCER_DB}`  ",
        f"**Usuario:** `{report.get('user')}`  ",
        "",
        "## Resumen ejecutivo",
        "",
        "| Ítem | Estado |",
        "|------|--------|",
        f"| IFR en productor DEV (`ifr_data.xpm*`) | ✅ Cargado ({pf_ifr[0].get('n', '?')} xpm) |" if pf_ifr else "| IFR productor DEV | ⚠️ no verificado |",
        "| Datashare `ds_reconocer_ifr_dev` publicado | ❌ Pendiente DBA |",
        "| `db_ifr_shared` montado en Reconocer | ❌ No existe |",
        "| Permisos `c32525e` CREATE schemas | ❌ `can_create_in_db=false` |",
        "| Deploy local (bdm_datos, vistas, SPs) | ❌ Bloqueado por permisos |",
        "| SPs R1/R2/R3 (qa_ifr_data) | ⏸ Listos en paquete, sin desplegar |",
        "",
        "**Conclusión:** Paquete SQL y runner listos. Falta ticket DBA (datashare + grants). Tras eso, re-ejecutar runner.",
        "",
        "## Preflight consumidor",
        "",
    ]
    pf = report.get("preflight", {}).get("checks", {})
    for k, v in pf.items():
        lines.append(f"### {k}")
        lines.append("```json")
        lines.append(json.dumps(v, indent=2, default=str)[:3000])
        lines.append("```")
        lines.append("")

    lines.extend(["## Preflight productor DEV", ""])
    pp = report.get("producer_preflight", {}).get("checks", {})
    for k, v in pp.items():
        lines.append(f"- **{k}:** `{json.dumps(v, default=str)[:500]}`")

    lines.extend(["", "## Etapas ejecutadas", ""])
    lines.append("| Etapa | OK | Detalle |")
    lines.append("|-------|-----|---------|")
    for s in report.get("steps", []):
        ok = "✅" if s.get("ok") else "❌"
        detail = s.get("error") or (
            f"{len(s.get('result_sets', []))} result sets"
            if s.get("result_sets") is not None
            else "OK"
        )
        if s.get("errors"):
            detail = str(s["errors"])[:120]
        lines.append(f"| {s.get('label')} | {ok} | {str(detail)[:120]} |")

    lines.extend(["", "## Qué falta (gaps)", ""])
    if gaps:
        for g in gaps:
            lines.append(f"- {g}")
    else:
        lines.append("- Ninguno detectado en esta corrida.")

    lines.extend(["", "## Próximos pasos DBA", ""])
    lines.extend([
        "1. Productor DEV (`cee2enck00mg`): `CREATE DATASHARE ds_reconocer_ifr_dev` + ADD tablas `ifr_data.xpm*`.",
        "2. GRANT namespace consumidor Reconocer (`pg_get_cluster_namespace()` en cz7jl1sn7m8z).",
        "3. Consumidor: `CREATE DATABASE db_ifr_shared FROM DATASHARE ds_reconocer_ifr_dev`.",
        "4. Ejecutar `sql/dev_ifr_datasharing/00_grants_dba_reconocer.sql` (schemas bdm_datos/bdm_tempo + SELECT datashare).",
        "5. Re-ejecutar: `py -3 tools/dev_ifr_datasharing_run.py`.",
    ])
    DOC_OUT.write_text("\n".join(lines), encoding="utf-8")


def build_stages(public_temp: bool) -> list:
    base = ROOT / "sql" / ("dev_ifr_datasharing_public" if public_temp else "dev_ifr_datasharing")
    qa = base if public_temp else QA_SQL
    pre = base / ("00_prerequisitos_public.sql" if public_temp else "00_prerequisitos_dev.sql")
    return [
        ("preflight", None),
        ("prerequisitos", pre),
        ("ddl", base / "01_ddl_unificacion_direccion.sql"),
        ("vistas", base / "00_vistas_insumo_bdm.sql"),
        ("smoke", base / "00_validar_solo_lectura_ifr_data.sql"),
        ("deploy_sp_r1", qa / "05_sp_regla1.sql"),
        ("deploy_sp_r2", qa / "06_sp_regla2.sql"),
        ("deploy_sp_r3", qa / "07_sp_regla3.sql"),
        ("execute", qa / "08_ejecucion_secuencial.sql"),
        ("validaciones", QA_SQL / "03_validaciones_unificacion.sql"),
    ]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight-only", action="store_true")
    parser.add_argument(
        "--public-temp",
        action="store_true",
        help="Reconocer db=dba, objects in public (sin bdm_datos/bdm_tempo)",
    )
    parser.add_argument(
        "--through",
        help="Stop after this stage",
    )
    args = parser.parse_args()

    global DB, DOC_OUT
    stages = build_stages(args.public_temp)
    if args.public_temp:
        DB = os.environ.get("REDSHIFT_DB", "dba")
        DOC_OUT = ROOT / "Documentacion" / "Evidencias_DEV_IFR_DATASHARING_PUBLIC.md"
    stage_choices = [s[0] for s in stages if s[0] != "preflight"]
    if args.through and args.through not in stage_choices:
        parser.error(f"--through must be one of {stage_choices}")

    if not PASSWORD:
        print("Set REDSHIFT_PASSWORD")
        sys.exit(1)

    report = {
        "executed_at": datetime.now().isoformat(),
        "host": HOST,
        "database": DB,
        "user": USER,
        "preflight": {},
        "producer_preflight": {},
        "steps": [],
    }

    print(f"=== Preflight productor ({PRODUCER_HOST}) ===")
    report["producer_preflight"] = producer_preflight()
    print(json.dumps(report["producer_preflight"], indent=2, default=str)[:4000])

    conn = connect(HOST, DB, CONSUMER_PASSWORD)
    conn.autocommit = True
    cur = conn.cursor(cursor_factory=RealDictCursor)

    print(f"\n=== Preflight consumidor ({HOST} / {DB}) ===")
    report["preflight"] = preflight(cur)
    print(json.dumps(report["preflight"], indent=2, default=str)[:4000])

    if args.preflight_only:
        gaps = analyze_gaps(report)
        write_markdown(report, gaps)
        print(f"\nGaps: {len(gaps)}")
        for g in gaps:
            print(f"  - {g}")
        print(f"\nReporte: {DOC_OUT}")
        cur.close()
        conn.close()
        sys.exit(0 if not report["preflight"].get("gaps") else 2)

    if report["preflight"].get("gaps"):
        print("\n*** BLOQUEADO por preflight — ejecutando etapas locales posibles (sin IFR) ***")

    stage_names = [s[0] for s in stages]
    stop_at = stage_names.index(args.through) if args.through else len(stage_names) - 1

    for idx, (name, path) in enumerate(stages):
        if name == "preflight":
            continue
        if idx > stop_at:
            break
        if name in ("smoke", "execute", "validaciones") and report["preflight"].get("gaps"):
            if name == "smoke":
                print(f"\n--- {name}: intentando validación IFR (puede fallar sin datashare) ---")
            elif name in ("execute", "validaciones"):
                step = {"label": name, "ok": False, "error": "Omitido: db_ifr_shared no disponible"}
                report["steps"].append(step)
                print(f"SKIP {name}: sin datashare")
                continue

        print(f"\n--- {name}: {path.name if path else '-'} ---")
        if path is None:
            continue
        if not path.exists():
            step = {"label": name, "ok": False, "error": f"Archivo no encontrado: {path}"}
        else:
            step = run_file(cur, path, name)
        report["steps"].append(step)
        print(json.dumps(step, indent=2, default=str)[:2500])
        if not step.get("ok") and name in ("deploy_sp_r1",):
            print(f"STOP: fallo crítico en {name}")
            break
        if not step.get("ok") and name == "vistas":
            print(f"WARN: {name} requiere db_ifr_shared — continuar deploy SPs")
            continue

    gaps = analyze_gaps(report)
    write_markdown(report, gaps)

    print(f"\n=== RESUMEN ===")
    print(f"Etapas OK: {sum(1 for s in report['steps'] if s.get('ok'))}/{len(report['steps'])}")
    print(f"Gaps: {len(gaps)}")
    for g in gaps:
        print(f"  - {g}")
    print(f"Reporte: {DOC_OUT}")

    cur.close()
    conn.close()
    sys.exit(0 if not gaps else 2)


if __name__ == "__main__":
    main()
