"""Genera SPs scoring EDF — leen staging temporal (misma lógica, sin vistas en scoring)."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "sql" / "ordenamiento"
OUT = ROOT / "sql" / "dev_edf_ordenamiento"

MAP = [
    ("11_sp_ordenamiento_scoring_dir.sql", "11_sp_ordenamiento_scoring_dir_edf.sql", "dir", "direccion"),
    ("12_sp_ordenamiento_scoring_tel.sql", "12_sp_ordenamiento_scoring_tel_edf.sql", "tel", "telefono"),
    ("13_sp_ordenamiento_scoring_cel.sql", "13_sp_ordenamiento_scoring_cel_edf.sql", "cel", "celular"),
    ("14_sp_ordenamiento_scoring_ema.sql", "14_sp_ordenamiento_scoring_ema_edf.sql", "ema", "email"),
]


def transform(src_name: str, dst_name: str, proc: str, insumo: str) -> str:
    text = (SRC / src_name).read_text(encoding="utf-8")
    text = text.replace(f"sp_ordenamiento_scoring_{proc}()", f"sp_ordenamiento_scoring_{proc}_edf()")
    text = text.replace(f"bdm_datos.insumo_{insumo}", f"bdm_tempo.stg_insumo_{insumo}")
    header = (
        f"-- {dst_name} (generado — staging EDF, una lectura datashare en preparar)\n"
        f"-- Regenerar: py -3 tools/gen_ordenamiento_sps_edf.py\n"
    )
    if "generado" in text.split("\n")[1]:
        lines = text.split("\n", 6)
        text = header + "\n".join(lines[6:]) if len(lines) > 6 else header + text
    else:
        text = header + text
    return text


def main() -> int:
    for src, dst, proc, insumo in MAP:
        out_path = OUT / dst
        out_path.write_text(transform(src, dst, proc, insumo), encoding="utf-8")
        print(f"Wrote {out_path.name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
