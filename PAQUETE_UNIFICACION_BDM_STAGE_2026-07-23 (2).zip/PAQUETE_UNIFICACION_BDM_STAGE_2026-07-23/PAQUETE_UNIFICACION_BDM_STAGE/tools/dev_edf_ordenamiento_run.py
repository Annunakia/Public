"""Ordenamiento completo — consumidor Reconocer + datashare edf_views (Fase 1 + 2)."""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from datetime import datetime
from pathlib import Path

import psycopg2
from psycopg2.extras import RealDictCursor

ROOT = Path(__file__).resolve().parents[1]
SQL = ROOT / "sql" / "dev_edf_ordenamiento"
SP_DIR = ROOT / "sql" / "ordenamiento"
OUT = ROOT / "Documentacion" / "Evidencias_DEV_ORDENAMIENTO_EDF_COMPLETO.md"

HOST = os.environ.get(
    "REDSHIFT_CONSUMER_HOST",
    "eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com",
)
DB = os.environ.get("REDSHIFT_CONSUMER_DB", "dba_rncr_batch")
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PWD = os.environ.get("REDSHIFT_CONSUMER_PASSWORD", os.environ.get("REDSHIFT_PASSWORD", ""))
PORT = int(os.environ.get("REDSHIFT_PORT", "5440"))

FASE1 = [
    ("ddl", SQL / "01_ddl_ordenamiento.sql"),
    ("betas", SQL / "02_carga_betas_ritm5226589.sql"),
    ("catalogos", SQL / "02b_catalogos_ordenamiento.sql"),
    ("vistas_canal", SQL / "03_vistas_contacto_canal.sql"),
    ("vistas_sin_copia", SQL / "04_vistas_sin_copia_productor.sql"),
    ("sp_preparar", SQL / "05_sp_preparar_insumos_edf.sql"),
]

FASE1_LEGACY_COPIA = [
    ("materializar_rpu", SQL / "04_materializar_rpu_post_unificacion.sql"),
    ("sp_preparar_legacy", SQL / "05_sp_preparar_insumos_edf_legacy.sql"),
]

FASE2_DEPLOY = [
    ("sp_scoring_dir_edf", SQL / "11_sp_ordenamiento_scoring_dir_edf.sql"),
    ("sp_scoring_tel_edf", SQL / "12_sp_ordenamiento_scoring_tel_edf.sql"),
    ("sp_scoring_cel_edf", SQL / "13_sp_ordenamiento_scoring_cel_edf.sql"),
    ("sp_scoring_ema_edf", SQL / "14_sp_ordenamiento_scoring_ema_edf.sql"),
    ("sp_consolidacion_edf", SQL / "07_sp_consolidacion_edf.sql"),
    ("sp_drop_staging", SQL / "08_sp_drop_staging_ordenamiento_edf.sql"),
    ("sp_ejecucion_edf", SQL / "06_sp_ordenamiento_ejecucion_edf.sql"),
]

EXEC_AS_BLOCK = {"ddl", "vistas_canal", "sp_preparar", "sp_ejecucion_edf", "sp_drop_staging"}
EXEC_AS_BLOCK |= {"vistas_sin_copia", "sp_preparar_legacy"}
EXEC_AS_BLOCK |= {x[0] for x in FASE2_DEPLOY if x[0].startswith("sp_")}


def split_sql(text: str) -> list[str]:
    parts: list[str] = []
    buf: list[str] = []
    in_dollar = False
    for line in text.splitlines():
        if re.search(r"\$\$", line):
            in_dollar = not in_dollar
        buf.append(line)
        if not in_dollar and line.rstrip().endswith(";"):
            stmt = "\n".join(buf).strip()
            if stmt:
                parts.append(stmt)
            buf = []
    tail = "\n".join(buf).strip()
    if tail:
        parts.append(tail)
    return parts


def split_statements(text: str) -> list[str]:
    parts = re.split(r";\s*\n", text)
    out = []
    for p in parts:
        stmt = p.strip()
        if not stmt:
            continue
        lines = [ln for ln in stmt.splitlines() if ln.strip() and not ln.strip().startswith("--")]
        if not lines:
            continue
        out.append(stmt if stmt.endswith(";") else stmt + ";")
    return out


def run_file(cur, path: Path, label: str) -> dict:
    sql = path.read_text(encoding="utf-8-sig")
    if label in EXEC_AS_BLOCK or "CREATE OR REPLACE PROCEDURE" in sql.upper():
        try:
            for stmt in split_sql(sql):
                cur.execute(stmt)
            return {"label": label, "ok": True}
        except Exception as e:
            cur.connection.rollback()
            return {"label": label, "ok": False, "error": str(e)}
    rows = []
    for stmt in split_statements(sql):
        try:
            cur.execute(stmt)
            if cur.description:
                rows.extend([dict(r) for r in cur.fetchall()])
        except Exception as e:
            cur.connection.rollback()
            return {"label": label, "ok": False, "error": str(e), "stmt": stmt[:120]}
    return {"label": label, "ok": True, "rows": rows}


def run_validation(cur, path: Path) -> list[dict]:
    out = []
    for stmt in split_statements(path.read_text(encoding="utf-8-sig")):
        cur.execute(stmt)
        if cur.description:
            out.append({"query": stmt.split("\n")[0][:80], "rows": [dict(r) for r in cur.fetchall()]})
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--fase1-only", action="store_true")
    ap.add_argument("--fase2-only", action="store_true")
    ap.add_argument(
        "--legacy-copia",
        action="store_true",
        help="Materializar RPU/insumos en tablas locales (no escalable; solo comparación)",
    )
    args = ap.parse_args()
    do_f1 = not args.fase2_only
    do_f2 = not args.fase1_only

    if not PWD:
        print("Set REDSHIFT_CONSUMER_PASSWORD", file=sys.stderr)
        return 1

    conn = psycopg2.connect(
        host=HOST, port=PORT, dbname=DB, user=USER, password=PWD, sslmode="require", connect_timeout=60
    )
    conn.autocommit = True
    cur = conn.cursor(cursor_factory=RealDictCursor)
    log: list[dict] = []
    timings: dict[str, float] = {}

    if do_f1:
        fase1_steps = list(FASE1)
        if args.legacy_copia:
            fase1_steps = fase1_steps[:4] + FASE1_LEGACY_COPIA
        for label, path in fase1_steps:
            print(f"[{label}] ...", end=" ", flush=True)
            r = run_file(cur, path, label)
            log.append(r)
            print("OK" if r["ok"] else "FAIL")
            if not r["ok"]:
                print(r.get("error"))
                break
        if all(x["ok"] for x in log) and args.legacy_copia:
            t0 = time.perf_counter()
            print("[call_preparar] ...", end=" ", flush=True)
            try:
                cur.execute("CALL bdm_datos.sp_ordenamiento_preparar_insumos_edf()")
                timings["preparar_seg"] = round(time.perf_counter() - t0, 1)
                log.append({"label": "call_preparar", "ok": True})
                print("OK")
            except Exception as e:
                cur.connection.rollback()
                log.append({"label": "call_preparar", "ok": False, "error": str(e)})
                print("FAIL", str(e).split("\n")[0])
        elif all(x["ok"] for x in log) and not args.legacy_copia:
            log.append({"label": "call_preparar", "ok": True, "skipped": "dentro de sp_ordenamiento_ejecucion_edf"})
            print("[call_preparar] defer -> ejecucion_edf (staging temporal)")

    if do_f2 and (not do_f1 or all(x.get("ok") for x in log)):
        for label, path in FASE2_DEPLOY:
            print(f"[{label}] ...", end=" ", flush=True)
            r = run_file(cur, path, label)
            log.append(r)
            print("OK" if r["ok"] else "FAIL")
            if not r["ok"]:
                print(r.get("error"))
                break

        if all(x.get("ok") for x in log):
            t0 = time.perf_counter()
            print("[call_ejecucion_edf] ...", end=" ", flush=True)
            try:
                cur.execute("CALL bdm_datos.sp_ordenamiento_ejecucion_edf(TRUE)")
                timings["scoring_total_seg"] = round(time.perf_counter() - t0, 1)
                log.append({"label": "call_ejecucion_edf", "ok": True})
                print(f"OK ({timings['scoring_total_seg']}s)")
            except Exception as e:
                cur.connection.rollback()
                log.append({"label": "call_ejecucion_edf", "ok": False, "error": str(e)})
                print("FAIL", str(e).split("\n")[0][:200])

    validation_f1, validation_f2 = [], []
    if all(x.get("ok") for x in log):
        if do_f1 and (SQL / "00_validar_fase1.sql").exists():
            validation_f1 = run_validation(cur, SQL / "00_validar_fase1.sql")
        if do_f2 and (SQL / "00_validar_fase2.sql").exists():
            validation_f2 = run_validation(cur, SQL / "00_validar_fase2.sql")

    cur.close()
    conn.close()

    ok = all(x.get("ok") for x in log)
    report = {"log": log, "timings": timings, "validation_f1": validation_f1, "validation_f2": validation_f2}
    lines = [
        f"# Evidencias Ordenamiento EDF completo (Reconocer consumidor)\n\n",
        f"Fecha: {datetime.now().isoformat(timespec='seconds')}\n\n",
        f"## Tiempos\n\n```json\n{json.dumps(timings, indent=2)}\n```\n\n",
        "## Stages\n",
    ]
    for r in log:
        lines.append(f"- **{r['label']}**: {'OK' if r.get('ok') else 'FAIL'}\n")
    if validation_f2:
        lines.append("\n## Validación Fase 2\n\n```json\n")
        lines.append(json.dumps(validation_f2, indent=2, default=str))
        lines.append("\n```\n")
    if validation_f1:
        lines.append("\n## Validación Fase 1\n\n```json\n")
        lines.append(json.dumps(validation_f1, indent=2, default=str))
        lines.append("\n```\n")
    OUT.write_text("".join(lines), encoding="utf-8")
    print(json.dumps(report, indent=2, default=str)[:8000])
    print(f"Report: {OUT}")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
