"""Genera SPs mock subdivididos (espejo de sql/unificacion_por_escenario).

Convención:
  sp_unificacion_*          → sp_unificacion_mock_*
  bdm_tempo.stg_regla*      → bdm_tempo.stg_mock_regla*
  bdm_tempo.stg_motor*      → bdm_tempo.stg_mock_motor*
  bdm_datos.unificacion_direccion → bdm_datos.unificacion_direccion_mock

Regenerar:
  py -3 tools/gen_unificacion_mock_sps.py
"""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "sql" / "unificacion_por_escenario"
OUT_SQL = ROOT / "sql" / "unificacion_mock_por_escenario"
OUT_DEPLOY = (
    ROOT
    / "deploy_bitbucket"
    / "db_rcncr_btch_rdshft_pgm"
    / "deploy"
    / "redshift"
    / "SQL"
)
OUT_DT = (
    ROOT
    / "deploy_bitbucket"
    / "db_rcncr_btch_rdshft_dt"
    / "deploy"
    / "redshift"
    / "SQL"
)
OUT_STRCT = (
    ROOT
    / "deploy_bitbucket"
    / "db_rcncr_btch_rdshft_strct"
    / "deploy"
    / "redshift"
    / "SQL"
)

# Orden deploy = mismo que reales
DEPLOY_ORDER_REAL = [
    "sp_unificacion_r1_preparar_insumo.sql",
    "sp_unificacion_r1_esc1_ciiu10_mismo_texto_padre_lab_crr.sql",
    "sp_unificacion_r1_esc2_ciiu81_90_mismo_texto_padre_res_crr.sql",
    "sp_unificacion_r1_esc3_otros_ciiu_mayor_entidades_reportan.sql",
    "sp_unificacion_regla1.sql",
    "sp_unificacion_r2_preparar_insumo.sql",
    "sp_unificacion_r2_esc1_complemento_vacio_esc2_substring_complemento.sql",
    "sp_unificacion_r2_esc3_sin_nit_misma_nomenclatura.sql",
    "sp_unificacion_r2_esc4_diccionario_frecuencia_complemento.sql",
    "sp_unificacion_r2_esc5_nomenclatura_menor_nivel_pierde.sql",
    "sp_unificacion_r2_esc6_frecuencia_complemento_gana.sql",
    "sp_unificacion_r2_motor_nit_empates_nuevas_direcciones.sql",
    "sp_unificacion_regla2.sql",
    "sp_unificacion_r3_esc1_geo_misma_via_puerta_cercana.sql",
    "sp_unificacion_regla3.sql",
]


def _to_mock_filename(name: str) -> str:
    if name.startswith("sp_unificacion_mock_"):
        return name
    if not name.startswith("sp_unificacion_"):
        raise ValueError(f"Unexpected SP file: {name}")
    return "sp_unificacion_mock_" + name[len("sp_unificacion_") :]


def _to_mock_proc(name: str) -> str:
    return _to_mock_filename(name).removesuffix(".sql")


def transform_sql(text: str) -> str:
    # Procedure / CALL names (avoid double-mock)
    text = re.sub(
        r"\bbdm_datos\.sp_unificacion_(?!mock_)",
        "bdm_datos.sp_unificacion_mock_",
        text,
    )
    text = re.sub(
        r"\bsp_unificacion_(?!mock_)",
        "sp_unificacion_mock_",
        text,
    )
    # Insumo MOCK (no edf_views / v_xpm_*)
    text = text.replace("bdm_tempo.v_xpm_", "bdm_tempo.v_mock_")
    # Catálogos del seed mock (bdm_stage), no los de corrida real
    text = text.replace(
        "bdm_datos.diccionario_complementos",
        "bdm_stage.diccionario_complementos",
    )
    text = text.replace("bdm_datos.nomenclatura", "bdm_stage.nomenclatura")
    text = text.replace("bdm_datos.tipo_ubicacion_dir", "bdm_stage.tipo_ubicacion_dir")
    # Staging aislado del path real
    text = text.replace("bdm_tempo.stg_regla", "bdm_tempo.stg_mock_regla")
    text = text.replace("bdm_tempo.stg_motor", "bdm_tempo.stg_mock_motor")
    # Salida mock (no pisar reales)
    text = re.sub(
        r"\bbdm_datos\.unificacion_direccion\b(?!_mock)",
        "bdm_datos.unificacion_direccion_mock",
        text,
    )
    text = text.replace(
        "-- Generado: tools/gen_unificacion_sps_por_escenario.py",
        "-- Generado: tools/gen_unificacion_mock_sps.py (espejo mock)",
    )
    text = text.replace("Prerequisito: vistas v_xpm_* desplegadas", "Prerequisito: vistas v_mock_* + seed bdm_stage")
    text = re.sub(
        r"(?m)^-- Fuente:.*$",
        "-- Fuente: bdm_stage → bdm_tempo.v_mock_* | Salida: bdm_datos.unificacion_direccion_mock | MODO MOCK",
        text,
        count=1,
    )
    # Una sola línea de modo mock al inicio
    lines = [ln for ln in text.splitlines() if not ln.strip().startswith("-- MODO MOCK")]
    if lines and lines[0].startswith("--"):
        lines.insert(1, "-- MODO MOCK — lee v_mock_*/bdm_stage; NO usa edf_views ni v_xpm_*")
    else:
        lines.insert(0, "-- MODO MOCK — lee v_mock_*/bdm_stage; NO usa edf_views ni v_xpm_*")
    return "\n".join(lines) + "\n"


def _ddl_mock() -> str:
    return """-- ============================================================
-- 01b_ddl_unificacion_direccion_mock.sql
-- Tabla de salida para SPs sp_unificacion_mock_* (Data Sharing)
-- ============================================================

CREATE TABLE IF NOT EXISTS bdm_datos.unificacion_direccion_mock (
  cod_dw_persona_ubic BIGINT,
  cod_dw_direccion_unificada BIGINT,
  unifica_atributos INTEGER,
  fecha_unificacion DATE,
  lote INTEGER,
  severidad INTEGER,
  usuario_bd VARCHAR(100)
)
DISTSTYLE KEY
DISTKEY (cod_dw_persona_ubic)
SORTKEY (cod_dw_persona_ubic);
"""


def _merge_deploy_par(par_path: Path, mock_files: list[str]) -> None:
    lines = []
    if par_path.exists():
        lines = [ln.strip() for ln in par_path.read_text(encoding="utf-8").splitlines() if ln.strip()]
    # quitar mock previos
    lines = [ln for ln in lines if not ln.startswith("sp_unificacion_mock_")]
    # asegurar reales + mock al final del bloque unificación (antes de ordenamiento si existe)
    mock_set = set(mock_files)
    out: list[str] = []
    inserted = False
    for ln in lines:
        if (ln.startswith("sp_ordenamiento_") or ln.startswith("sp_")) and not ln.startswith(
            "sp_unificacion_"
        ):
            if not inserted:
                out.extend(mock_files)
                inserted = True
            out.append(ln)
        else:
            out.append(ln)
    if not inserted:
        # insertar mock después del último sp_unificacion_ real
        last_uni = max((i for i, x in enumerate(out) if x.startswith("sp_unificacion_") and not x.startswith("sp_unificacion_mock_")), default=-1)
        if last_uni >= 0:
            out = out[: last_uni + 1] + mock_files + out[last_uni + 1 :]
        else:
            out.extend(mock_files)
    # dedupe preserving order
    seen: set[str] = set()
    final: list[str] = []
    for ln in out:
        if ln in seen:
            continue
        seen.add(ln)
        final.append(ln)
    # ensure all mock present
    for m in mock_files:
        if m not in seen:
            final.append(m)
    par_path.write_text("\n".join(final) + "\n", encoding="utf-8")


def _merge_strct_par(par_path: Path, names: list[str]) -> None:
    lines = []
    if par_path.exists():
        lines = [ln.strip() for ln in par_path.read_text(encoding="utf-8").splitlines() if ln.strip()]
    for ddl_name in names:
        if ddl_name in lines:
            continue
        out: list[str] = []
        placed = False
        anchor = "01_ddl_unificacion_direccion.sql" if ddl_name.startswith("01b_") else "02_vistas_insumo_edf_views.sql"
        for ln in lines:
            out.append(ln)
            if ln == anchor:
                out.append(ddl_name)
                placed = True
        if not placed:
            out.append(ddl_name)
        lines = out
    par_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    if not SRC.is_dir():
        raise SystemExit(f"Missing source: {SRC}")

    OUT_SQL.mkdir(parents=True, exist_ok=True)
    OUT_DEPLOY.mkdir(parents=True, exist_ok=True)
    OUT_DT.mkdir(parents=True, exist_ok=True)
    OUT_STRCT.mkdir(parents=True, exist_ok=True)

    mock_files: list[str] = []
    procs: list[str] = []

    for real_name in DEPLOY_ORDER_REAL:
        src_path = SRC / real_name
        if not src_path.exists():
            raise SystemExit(f"Missing real SP: {src_path}")
        mock_name = _to_mock_filename(real_name)
        content = transform_sql(src_path.read_text(encoding="utf-8"))
        (OUT_SQL / mock_name).write_text(content, encoding="utf-8")
        (OUT_DEPLOY / mock_name).write_text(content, encoding="utf-8")
        mock_files.append(mock_name)
        procs.append(_to_mock_proc(real_name))
        print(f"Wrote {mock_name}")

    # limpiar mock stale en OUT_SQL
    keep = set(mock_files)
    for old in OUT_SQL.glob("sp_unificacion_mock_*.sql"):
        if old.name not in keep:
            old.unlink()
            print(f"Removed stale {old.name}")

    _merge_deploy_par(OUT_DEPLOY.parent / "deploy.par", mock_files)
    print(f"Updated deploy.par (+{len(mock_files)} mock)")

    # rollback: append mock drops (reverse)
    rev = OUT_DEPLOY.parent / "RevSQL"
    rev.mkdir(parents=True, exist_ok=True)
    rb = rev / "rollback_drop_procedures.sql"
    existing = rb.read_text(encoding="utf-8") if rb.exists() else "-- Rollback SPs\n"
    # strip previous mock drops
    lines = [
        ln
        for ln in existing.splitlines()
        if "sp_unificacion_mock_" not in ln
    ]
    mock_drops = [
        f"DROP PROCEDURE IF EXISTS bdm_datos.{p}();" for p in reversed(procs)
    ]
    # insert mock drops at top (drop mock first)
    header = lines[0] if lines and lines[0].startswith("--") else "-- Rollback SPs unificación + mock"
    body = [ln for ln in lines[1:] if ln.strip()] if lines and lines[0].startswith("--") else [ln for ln in lines if ln.strip()]
    new_rb = [header, "-- Mock (orden inverso)", *mock_drops, "-- Reales / otros", *body]
    rb.write_text("\n".join(new_rb) + "\n", encoding="utf-8")
    print(f"Updated {rb}")

    # run mock
    run_mock = OUT_DT / "run_unificacion_mock_ejecucion_secuencial.sql"
    run_mock.write_text(
        """-- Orquestador mock — SPs sp_unificacion_mock_* (Data Sharing)
-- NO usar sp_unificacion_* (sin mock) en esta corrida.
TRUNCATE TABLE bdm_datos.unificacion_direccion_mock;

CALL bdm_datos.sp_unificacion_mock_regla1();
CALL bdm_datos.sp_unificacion_mock_regla2();
CALL bdm_datos.sp_unificacion_mock_regla3();
""",
        encoding="utf-8",
    )
    print(f"Wrote {run_mock.name}")

    # DDL mock table + vistas mock
    ddl_name = "01b_ddl_unificacion_direccion_mock.sql"
    vistas_mock = "02b_vistas_insumo_mock.sql"
    (OUT_STRCT / ddl_name).write_text(_ddl_mock(), encoding="utf-8")
    src_vistas = (
        ROOT
        / "deploy_bitbucket"
        / "db_rcncr_btch_rdshft_strct"
        / "deploy"
        / "redshift"
        / "SQL"
        / vistas_mock
    )
    if src_vistas.exists():
        (OUT_STRCT / vistas_mock).write_text(src_vistas.read_text(encoding="utf-8"), encoding="utf-8")
    pkg_ddl = ROOT / "sql" / "unificacion_mock_por_escenario" / ddl_name
    pkg_ddl.write_text(_ddl_mock(), encoding="utf-8")
    _merge_strct_par(OUT_STRCT.parent / "deploy.par", [ddl_name, vistas_mock])
    print(f"Wrote {ddl_name} + {vistas_mock} + strct deploy.par")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
