"""IFR/XPM read-only validation without CREATE VIEW (no bdm_tempo DDL needed)."""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime

import psycopg2
from psycopg2.extras import RealDictCursor

HOST = os.environ.get(
    "REDSHIFT_HOST",
    "eec-aws-us-eits-procesosbatch-qa-redshift.cwefyckvccgy.us-east-1.redshift.amazonaws.com",
)
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PASSWORD = os.environ.get("REDSHIFT_PASSWORD", "")

BASE_CTE = """
WITH contacto AS (
  SELECT
    xpm.pin,
    xpm.relationalizelastupdate,
    loc.id AS cod_dw_ubic,
    ci.id AS cod_dw_persona_ubic,
    ci.id AS cod_dw_direccion_fisica,
    FNV_HASH(xpm.pin) AS id_buro_persona,
    CAST(xpm.pin AS BIGINT) AS cod_pin_persona,
    CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) AS cod_dw_tipo_ubicacion_dir,
    ci."location.val.contactinformations.val.standardizedtextoubicacion" AS texto_ubicacion,
    CAST(ci."location.val.contactinformations.val.standardizeddanecode" AS INTEGER) AS cod_dw_ciudad,
    ci."location.val.contactinformations.val.standardizedcomplemento" AS complemento,
    CAST(loc."location.val.personidtype" AS INTEGER) AS cod_tipo_ident_fte,
    bdm_datos.convert_epoch_to_date(
      CAST(ci."location.val.contactinformations.val.contacteventlastupdated" AS BIGINT)
    ) AS fecha_relacion_persona_ubicaci
  FROM ifr_data.xpm xpm
  JOIN ifr_data.xpm_location loc
    ON xpm.location = loc.id
   AND xpm.relationalizelastupdate = loc.relationalizelastupdate
  JOIN ifr_data.xpm_location_val_contactinformations ci
    ON loc."location.val.contactinformations" = ci.id
   AND loc.relationalizelastupdate = ci.relationalizelastupdate
  WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7)
)
"""

CHECKS = [
    (
        "01_join_base",
        BASE_CTE + "SELECT COUNT(*) AS total FROM contacto",
        lambda r: r[0]["total"] == 1285,
    ),
    (
        "02_personidtype_informado",
        BASE_CTE
        + """
        SELECT SUM(CASE WHEN cod_tipo_ident_fte IS NOT NULL THEN 1 ELSE 0 END) AS con_tipo
        FROM contacto
        """,
        lambda r: r[0]["con_tipo"] > 0,
    ),
    (
        "03_personidtype_coherente",
        BASE_CTE
        + """
        SELECT SUM(CASE WHEN c.cod_tipo_ident_fte = CAST(loc."location.val.personidtype" AS INTEGER) THEN 1 ELSE 0 END) AS ok,
               SUM(CASE WHEN c.cod_tipo_ident_fte IS DISTINCT FROM CAST(loc."location.val.personidtype" AS INTEGER) THEN 1 ELSE 0 END) AS divergente
        FROM contacto c
        JOIN ifr_data.xpm_location loc
          ON c.cod_dw_ubic = loc.id
         AND c.relationalizelastupdate = loc.relationalizelastupdate
        """,
        lambda r: r[0]["divergente"] == 0,
    ),
    (
        "04_nit_tipo3",
        BASE_CTE
        + """
        SELECT COUNT(*) AS nit_rpu FROM contacto WHERE COALESCE(cod_tipo_ident_fte, 0) = 3
        """,
        lambda r: r[0]["nit_rpu"] >= 0,
    ),
    (
        "05_nit_con_complemento",
        BASE_CTE
        + """
        SELECT COUNT(*) AS total FROM contacto
        WHERE COALESCE(cod_tipo_ident_fte, 0) = 3
          AND complemento IS NOT NULL AND LENGTH(TRIM(complemento)) > 0
        """,
        lambda r: r[0]["total"] >= 0,
    ),
    (
        "06_join_reportes",
        """
        SELECT COUNT(*) AS total
        FROM ifr_data.xpm xpm
        JOIN ifr_data.xpm_location loc
          ON xpm.location = loc.id
         AND xpm.relationalizelastupdate = loc.relationalizelastupdate
        JOIN ifr_data.xpm_location_val_contactinformations ci
          ON loc."location.val.contactinformations" = ci.id
         AND loc.relationalizelastupdate = ci.relationalizelastupdate
        JOIN ifr_data.xpm_counterparties cp
          ON xpm.counterparties = cp.id
         AND xpm.relationalizelastupdate = cp.relationalizelastupdate
        WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7)
        """,
        lambda r: r[0]["total"] > 0,
    ),
    (
        "07_r1_insumo_join",
        BASE_CTE
        + """
        , rep AS (
          SELECT ci.id AS cod_dw_persona_ubic,
                 CAST(cp."counterparties.val.counterpartyidnumber" AS INTEGER) AS id_buro_suscriptor
          FROM ifr_data.xpm xpm
          JOIN ifr_data.xpm_location loc
            ON xpm.location = loc.id AND xpm.relationalizelastupdate = loc.relationalizelastupdate
          JOIN ifr_data.xpm_location_val_contactinformations ci
            ON loc."location.val.contactinformations" = ci.id
           AND loc.relationalizelastupdate = ci.relationalizelastupdate
          JOIN ifr_data.xpm_counterparties cp
            ON xpm.counterparties = cp.id AND xpm.relationalizelastupdate = cp.relationalizelastupdate
          WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7)
        )
        SELECT COUNT(DISTINCT c.cod_dw_persona_ubic) AS total
        FROM contacto c
        JOIN rep ON c.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
        """,
        lambda r: r[0]["total"] > 0,
    ),
    (
        "08_complemento_no_vacio",
        BASE_CTE
        + """
        SELECT SUM(CASE WHEN complemento IS NOT NULL AND LENGTH(TRIM(complemento)) > 0 THEN 1 ELSE 0 END) AS con_comp
        FROM contacto
        """,
        lambda r: r[0]["con_comp"] > 0,
    ),
    (
        "09_tipo_ubicacion_catalogo",
        """
        SELECT COUNT(*) AS faltantes FROM (
          SELECT DISTINCT CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) AS t
          FROM ifr_data.xpm xpm
          JOIN ifr_data.xpm_location loc ON xpm.location = loc.id AND xpm.relationalizelastupdate = loc.relationalizelastupdate
          JOIN ifr_data.xpm_location_val_contactinformations ci
            ON loc."location.val.contactinformations" = ci.id AND loc.relationalizelastupdate = ci.relationalizelastupdate
          WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7)
        ) x
        LEFT JOIN bdm_stage.tipo_ubicacion_dir t ON x.t = t.cod_dw_tipo_ubicacion_dir
        WHERE t.cod_dw_tipo_ubicacion_dir IS NULL
        """,
        lambda r: r[0]["faltantes"] == 0,
    ),
    (
        "10_ciiu_join",
        """
        SELECT COUNT(*) AS total FROM ifr_data.xpm xpm
        WHERE xpm."bestpersonalinformation.mainisiccodeforproduct" IS NOT NULL
        """,
        lambda r: r[0]["total"] >= 0,
    ),
]


def main() -> int:
    if not PASSWORD:
        print("Set REDSHIFT_PASSWORD", file=sys.stderr)
        return 2

    conn = psycopg2.connect(
        host=HOST, port=5440, dbname="dba_batch", user=USER, password=PASSWORD,
        sslmode="require", connect_timeout=45,
    )
    conn.autocommit = True
    cur = conn.cursor(cursor_factory=RealDictCursor)

    results = []
    passed = failed = 0
    for name, sql, pred in CHECKS:
        try:
            cur.execute(sql)
            rows = [dict(r) for r in cur.fetchall()]
            ok = pred(rows)
            status = "PASS" if ok else "FAIL"
            if ok:
                passed += 1
            else:
                failed += 1
            print(f"{status} {name}: {rows}")
            results.append({"check": name, "ok": ok, "rows": rows, "error": None})
        except Exception as exc:  # noqa: BLE001
            cur.connection.rollback()
            failed += 1
            print(f"ERROR {name}: {exc}")
            results.append({"check": name, "ok": False, "rows": [], "error": str(exc)})

    out = {
        "timestamp": datetime.now().isoformat(),
        "host": HOST,
        "passed": passed,
        "failed": failed,
        "checks": results,
    }
    path = os.path.join(os.path.dirname(__file__), "qa_ifr_inline_results.json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=2, default=str)

    print(f"\nSUMMARY: {passed} passed, {failed} failed/errored")
    cur.close()
    conn.close()
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
