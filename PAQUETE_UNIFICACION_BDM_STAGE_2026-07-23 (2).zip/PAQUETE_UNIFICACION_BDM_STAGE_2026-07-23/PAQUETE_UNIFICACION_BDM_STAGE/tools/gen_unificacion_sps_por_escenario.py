"""Genera SPs de unificación por escenario (no monolíticos) para pipeline _pgm.

Un SP = un escenario revisable. Orquestadores por regla encadenan CALLs.
Fuente lógica: sql/qa_ifr_data/05-07_sp_regla*.sql (edf_views vía v_xpm_*).

Regenerar:
  py -3 tools/gen_unificacion_sps_por_escenario.py
"""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC_R1 = ROOT / "sql" / "qa_ifr_data" / "05_sp_regla1.sql"
SRC_R2 = ROOT / "sql" / "qa_ifr_data" / "06_sp_regla2.sql"
SRC_R3 = ROOT / "sql" / "qa_ifr_data" / "07_sp_regla3.sql"
OUT_SQL = ROOT / "sql" / "unificacion_por_escenario"
OUT_DEPLOY = ROOT / "deploy_bitbucket" / "db_rcncr_btch_rdshft_pgm" / "deploy" / "redshift" / "SQL"
OUT_REVSQL = OUT_DEPLOY.parent / "RevSQL"

# Nombres dicientes: escenario + descripción funcional (archivo = nombre del SP)
SP_R1_PREP = "sp_unificacion_r1_preparar_insumo"
SP_R1_ESC1 = "sp_unificacion_r1_esc1_ciiu10_mismo_texto_padre_lab_crr"
SP_R1_ESC2 = "sp_unificacion_r1_esc2_ciiu81_90_mismo_texto_padre_res_crr"
SP_R1_ESC3 = "sp_unificacion_r1_esc3_otros_ciiu_mayor_entidades_reportan"
SP_R1_ORQ = "sp_unificacion_regla1"
SP_R2_PREP = "sp_unificacion_r2_preparar_insumo"
SP_R2_ESC12 = "sp_unificacion_r2_esc1_complemento_vacio_esc2_substring_complemento"
SP_R2_ESC3 = "sp_unificacion_r2_esc3_sin_nit_misma_nomenclatura"
SP_R2_ESC4 = "sp_unificacion_r2_esc4_diccionario_frecuencia_complemento"
SP_R2_ESC5 = "sp_unificacion_r2_esc5_nomenclatura_menor_nivel_pierde"
SP_R2_ESC6 = "sp_unificacion_r2_esc6_frecuencia_complemento_gana"
SP_R2_MOTOR = "sp_unificacion_r2_motor_nit_empates_nuevas_direcciones"
SP_R2_ORQ = "sp_unificacion_regla2"
SP_R3_ESC1 = "sp_unificacion_r3_esc1_geo_misma_via_puerta_cercana"
SP_R3_ORQ = "sp_unificacion_regla3"


def _sql_name(proc: str) -> str:
    return f"{proc}.sql"


def _header(name: str, escenario: str, prereq: str = "") -> str:
    pre = f"-- Prerequisito: {prereq}\n" if prereq else ""
    return f"""-- {name}
-- Escenario: {escenario}
-- Fuente: edf_views → bdm_tempo.v_xpm_* | Salida: bdm_datos.unificacion_direccion
{pre}-- Generado: tools/gen_unificacion_sps_por_escenario.py

"""


def _proc(name: str, body: str) -> str:
    return f"""CREATE OR REPLACE PROCEDURE bdm_datos.{name}()
LANGUAGE plpgsql
AS $$
BEGIN
{body}
END;
$$;
"""


def _extract_r1_insumo() -> str:
    return """
  DROP TABLE IF EXISTS bdm_tempo.stg_regla1_insumo;
  CREATE TABLE bdm_tempo.stg_regla1_insumo
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  SORTKEY(id_buro_persona, texto_ubicacion)
  AS
  SELECT
    rpu.cod_dw_persona_ubic,
    rpu.id_buro_persona,
    ubi.texto_ubicacion,
    df.complemento,
    ubi.cod_dw_ciudad,
    rpu.cod_dw_tipo_ubicacion_dir,
    COALESCE(ciiu.cod_act_econo_ciiu_fte, '') AS cod_act_econo_ciiu_fte,
    COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor), 0) AS numero_entidades_reportan,
    tud.descripcion_tipo_ubicacion_dir AS tipo_direccion
  FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
  JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  LEFT JOIN bdm_tempo.v_xpm_direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
  JOIN bdm_tempo.v_xpm_reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  LEFT JOIN bdm_tempo.v_xpm_ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona
  LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
  WHERE rpu.ind_unificacion IS NULL
  GROUP BY 1,2,3,4,5,6,7,9;
"""


def _r1_escenario_body(
    esc: str,
    ciiu_filter: str,
    score_expr: str,
    partition_esc: str,
) -> str:
    return f"""
  DROP TABLE IF EXISTS bdm_tempo.stg_regla1_scored;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla1_max;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla1_ganador;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla1_pares;

  CREATE TABLE bdm_tempo.stg_regla1_scored
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  SORTKEY(id_buro_persona, texto_ubicacion)
  AS
  SELECT *,
    '{esc}' AS escenario,
    {score_expr} AS score,
    ROW_NUMBER() OVER (
      PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_ciudad
      ORDER BY {score_expr} DESC, cod_dw_persona_ubic DESC
    ) AS orden
  FROM bdm_tempo.stg_regla1_insumo
  WHERE {ciiu_filter};

  CREATE TABLE bdm_tempo.stg_regla1_max
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT id_buro_persona, texto_ubicacion, cod_dw_ciudad, escenario, MAX(score) AS max_score
  FROM bdm_tempo.stg_regla1_scored
  GROUP BY 1, 2, 3, 4;

  CREATE TABLE bdm_tempo.stg_regla1_ganador
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT m.id_buro_persona, m.texto_ubicacion, m.cod_dw_ciudad, m.escenario
  FROM bdm_tempo.stg_regla1_max m
  JOIN bdm_tempo.stg_regla1_scored s
    ON s.id_buro_persona = m.id_buro_persona
   AND s.texto_ubicacion = m.texto_ubicacion
   AND s.cod_dw_ciudad = m.cod_dw_ciudad
   AND s.escenario = m.escenario
   AND s.score = m.max_score
  GROUP BY 1, 2, 3, 4
  HAVING COUNT(*) = 1;

  CREATE TABLE bdm_tempo.stg_regla1_pares
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT hijo.cod_dw_persona_ubic, padre.cod_dw_persona_ubic AS cod_dw_direccion_unificada
  FROM bdm_tempo.stg_regla1_scored padre
  JOIN bdm_tempo.stg_regla1_ganador g
    ON g.id_buro_persona = padre.id_buro_persona
   AND g.texto_ubicacion = padre.texto_ubicacion
   AND g.cod_dw_ciudad = padre.cod_dw_ciudad
   AND g.escenario = padre.escenario
  JOIN bdm_tempo.stg_regla1_scored hijo
    ON padre.id_buro_persona = hijo.id_buro_persona
   AND padre.texto_ubicacion = hijo.texto_ubicacion
   AND padre.cod_dw_ciudad = hijo.cod_dw_ciudad
   AND padre.escenario = hijo.escenario
   AND hijo.orden > 1
   AND padre.cod_dw_tipo_ubicacion_dir <> hijo.cod_dw_tipo_ubicacion_dir
  WHERE padre.orden = 1;

  INSERT INTO bdm_datos.unificacion_direccion
  SELECT cod_dw_persona_ubic, cod_dw_direccion_unificada, 1, CURRENT_DATE, 1, 1, CURRENT_USER
  FROM bdm_tempo.stg_regla1_pares;

  DROP TABLE IF EXISTS bdm_tempo.stg_regla1_scored;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla1_max;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla1_ganador;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla1_pares;
"""


def _r1_files() -> dict[str, str]:
    score1 = "CASE WHEN tipo_direccion IN ('LAB','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan"
    score2 = "CASE WHEN tipo_direccion IN ('RES','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan"
    score3 = "numero_entidades_reportan"
    return {
        _sql_name(SP_R1_PREP): _header(
            "R1 — materializar insumo", "común R1", "vistas v_xpm_* desplegadas"
        )
        + _proc(SP_R1_PREP, _extract_r1_insumo()),
        _sql_name(SP_R1_ESC1): _header(
            "R1 Esc1 — CIIU 10, mismo texto distinto tipo",
            "Padre LAB/CRR + más entidades reportan",
            SP_R1_PREP,
        )
        + _proc(
            SP_R1_ESC1,
            _r1_escenario_body("ESC1", "cod_act_econo_ciiu_fte = '10'", score1, "ESC1"),
        ),
        _sql_name(SP_R1_ESC2): _header(
            "R1 Esc2 — CIIU 81/82/90, mismo texto distinto tipo",
            "Padre RES/CRR + más entidades reportan",
            SP_R1_PREP,
        )
        + _proc(
            SP_R1_ESC2,
            _r1_escenario_body(
                "ESC2",
                "cod_act_econo_ciiu_fte IN ('81','82','90')",
                score2,
                "ESC2",
            ),
        ),
        _sql_name(SP_R1_ESC3): _header(
            "R1 Esc3 — otros CIIU, mismo texto distinto tipo",
            "Gana quien reportan más entidades",
            SP_R1_PREP,
        )
        + _proc(
            SP_R1_ESC3,
            _r1_escenario_body(
                "ESC3",
                "cod_act_econo_ciiu_fte NOT IN ('10','81','82','90')",
                score3,
                "ESC3",
            ),
        ),
        _sql_name(SP_R1_ORQ): _header(
            "Orquestador Regla 1", "CALL escenarios R1 en orden", ""
        )
        + _proc(
            SP_R1_ORQ,
            f"""
  CALL bdm_datos.{SP_R1_PREP}();
  CALL bdm_datos.{SP_R1_ESC1}();
  CALL bdm_datos.{SP_R1_ESC2}();
  CALL bdm_datos.{SP_R1_ESC3}();
  DROP TABLE IF EXISTS bdm_tempo.stg_regla1_insumo;
""",
        ),
    }


def _slice_r2_body(start_marker: str, end_marker: str | None = None) -> str:
    text = SRC_R2.read_text(encoding="utf-8")
    start = text.find(start_marker)
    if start < 0:
        raise ValueError(f"Marker not found: {start_marker}")
    if end_marker:
        end = text.find(end_marker, start)
        if end < 0:
            end = len(text)
        return text[start:end]
    tail = text.find("\n  -- Limpieza final de staging", start)
    return text[start:tail] if tail > 0 else text[start:]


def _r2_preparar() -> str:
    body = _slice_r2_body(
        "  CREATE TABLE bdm_tempo.stg_regla2_insumo",
        "  CREATE TABLE bdm_tempo.stg_regla2_esc1_pares",
    )
    return f"""
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_insumo;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e2;
{body}"""


def _wrap_r2_esc(name: str, title: str, esc: str, prereq: str, body: str, cleanup: str = "") -> str:
    return (
        _header(title, esc, prereq)
        + _proc(
            name,
            body + cleanup,
        )
    )


def _r2_files() -> dict[str, str]:
    esc12 = _slice_r2_body(
        "  CREATE TABLE bdm_tempo.stg_regla2_esc1_pares",
        "  CREATE TABLE bdm_tempo.stg_regla2_e03",
    )
    esc3 = _slice_r2_body(
        "  CREATE TABLE bdm_tempo.stg_regla2_e03",
        "  CREATE TABLE bdm_tempo.stg_regla2_e04",
    )
    esc4 = _slice_r2_body(
        "  CREATE TABLE bdm_tempo.stg_regla2_e04",
        "  CREATE TABLE bdm_tempo.stg_regla2_e05",
    )
    esc5 = _slice_r2_body(
        "  CREATE TABLE bdm_tempo.stg_regla2_e05",
        "  CREATE TABLE bdm_tempo.stg_regla2_e06_freq",
    )
    esc6 = _slice_r2_body(
        "  CREATE TABLE bdm_tempo.stg_regla2_e06_freq",
        "  -- Motor R2 (XPM real)",
    )
    motor = _slice_r2_body(
        "  -- Motor R2 (XPM real)",
        "  -- Limpieza final de staging de esta regla",
    )
    r2_cleanup = """
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_insumo;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_esc1_pares;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e1;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_esc2_pares;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e2;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03_a;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03_e1;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_a;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_c1;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_ganador;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_e;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_a;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_pares;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_freq;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_pares;
  DROP TABLE IF EXISTS bdm_tempo.stg_motor_keys;
  DROP TABLE IF EXISTS bdm_tempo.stg_motor_ranked;
  DROP TABLE IF EXISTS bdm_tempo.stg_motor_insumo;
"""
    return {
        _sql_name(SP_R2_PREP): _header(
            "R2 — materializar insumo", "común R2", "Regla 1 ejecutada"
        )
        + _proc(SP_R2_PREP, _r2_preparar()),
        _sql_name(SP_R2_ESC12): _wrap_r2_esc(
            SP_R2_ESC12,
            "R2 Esc1 — complemento vacío absorbe con complemento",
            "R2 Esc2 — substring de complemento en mismo texto",
            SP_R2_PREP,
            esc12,
        ),
        _sql_name(SP_R2_ESC3): _wrap_r2_esc(
            SP_R2_ESC3,
            "R2 Esc3 — misma nomenclatura sin NIT",
            "Excluye tipo identificación 3 (NIT)",
            SP_R2_ESC12,
            esc3,
        ),
        _sql_name(SP_R2_ESC4): _wrap_r2_esc(
            SP_R2_ESC4,
            "R2 Esc4 — diccionario de complementos",
            "Gana mayor frecuencia en diccionario; empate excluido",
            SP_R2_ESC3,
            esc4,
        ),
        _sql_name(SP_R2_ESC5): _wrap_r2_esc(
            SP_R2_ESC5,
            "R2 Esc5 — nivel de nomenclatura",
            "Nomenclaturas distintas: menor nivel pierde",
            SP_R2_ESC4,
            esc5,
        ),
        _sql_name(SP_R2_ESC6): _wrap_r2_esc(
            SP_R2_ESC6,
            "R2 Esc6 — frecuencia de complemento",
            "Mayor frecuencia en diccionario gana",
            SP_R2_ESC5,
            esc6,
        ),
        _sql_name(SP_R2_MOTOR): _wrap_r2_esc(
            SP_R2_MOTOR,
            "R2 Motor — NIT y empates (Esc3/Esc5/Esc6)",
            "Genera nuevas direcciones en staging stg_motor_insumo",
            SP_R2_ESC6,
            motor,
        ),
        _sql_name(SP_R2_ORQ): _header("Orquestador Regla 2", "CALL escenarios R2 en orden", "")
        + _proc(
            SP_R2_ORQ,
            f"""
  CALL bdm_datos.{SP_R2_PREP}();
  CALL bdm_datos.{SP_R2_ESC12}();
  CALL bdm_datos.{SP_R2_ESC3}();
  CALL bdm_datos.{SP_R2_ESC4}();
  CALL bdm_datos.{SP_R2_ESC5}();
  CALL bdm_datos.{SP_R2_ESC6}();
  CALL bdm_datos.{SP_R2_MOTOR}();
"""
            + r2_cleanup,
        ),
    }


def _r3_files() -> dict[str, str]:
    text = SRC_R3.read_text(encoding="utf-8")
    inner = text.split("AS $$", 1)[1].rsplit("END;", 1)[0]
    # Quitar wrapper BEGIN del monolito y limpieza duplicada al inicio
    inner = inner.strip()
    if inner.startswith("BEGIN"):
        inner = inner[5:].lstrip()
    inner = re.sub(
        r"^\s*DROP TABLE IF EXISTS bdm_tempo\.stg_regla3_\w+;\s*",
        "",
        inner,
        flags=re.MULTILINE,
    )
    inner = re.sub(
        r"\n\s*-- Limpieza final de staging.*",
        "",
        inner,
        flags=re.DOTALL,
    )
    cleanup = """
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_insumo;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_pares;
"""
    return {
        _sql_name(SP_R3_ESC1): _header(
            "R3 Esc1 — misma vía, puerta más cercana (±2)",
            "Unificación geo por proximidad de número de puerta",
            "Regla 2 ejecutada; lat/long en insumo",
        )
        + _proc(SP_R3_ESC1, inner + cleanup),
        _sql_name(SP_R3_ORQ): _header("Orquestador Regla 3", "CALL R3 geo", "")
        + _proc(
            SP_R3_ORQ,
            f"""
  CALL bdm_datos.{SP_R3_ESC1}();
""",
        ),
    }


def _deploy_par(files: list[str]) -> str:
    return "\n".join(files) + "\n"


DEPLOY_ORDER = [
    _sql_name(SP_R1_PREP),
    _sql_name(SP_R1_ESC1),
    _sql_name(SP_R1_ESC2),
    _sql_name(SP_R1_ESC3),
    _sql_name(SP_R1_ORQ),
    _sql_name(SP_R2_PREP),
    _sql_name(SP_R2_ESC12),
    _sql_name(SP_R2_ESC3),
    _sql_name(SP_R2_ESC4),
    _sql_name(SP_R2_ESC5),
    _sql_name(SP_R2_ESC6),
    _sql_name(SP_R2_MOTOR),
    _sql_name(SP_R2_ORQ),
    _sql_name(SP_R3_ESC1),
    _sql_name(SP_R3_ORQ),
]

ALL_PROCEDURES = [
    SP_R3_ORQ,
    SP_R3_ESC1,
    SP_R2_ORQ,
    SP_R2_MOTOR,
    SP_R2_ESC6,
    SP_R2_ESC5,
    SP_R2_ESC4,
    SP_R2_ESC3,
    SP_R2_ESC12,
    SP_R2_PREP,
    SP_R1_ORQ,
    SP_R1_ESC3,
    SP_R1_ESC2,
    SP_R1_ESC1,
    SP_R1_PREP,
]


def main() -> int:
    if not SRC_R2.exists():
        raise SystemExit(f"Missing source: {SRC_R2}")
    all_files: dict[str, str] = {}
    all_files.update(_r1_files())
    all_files.update(_r2_files())
    all_files.update(_r3_files())

    OUT_SQL.mkdir(parents=True, exist_ok=True)
    OUT_DEPLOY.mkdir(parents=True, exist_ok=True)

    for folder in (OUT_SQL, OUT_DEPLOY):
        for old in folder.glob("sp_unificacion_*.sql"):
            if old.name not in all_files:
                old.unlink()
                print(f"Removed stale {old.name}")

    for name, content in all_files.items():
        (OUT_SQL / name).write_text(content, encoding="utf-8")
        (OUT_DEPLOY / name).write_text(content, encoding="utf-8")
        print(f"Wrote {name}")

    par = OUT_DEPLOY.parent / "deploy.par"
    par.write_text(_deploy_par(DEPLOY_ORDER), encoding="utf-8")
    print(f"Wrote {par}")

    OUT_REVSQL.mkdir(parents=True, exist_ok=True)
    rollback = OUT_REVSQL / "rollback_drop_procedures.sql"
    rollback_lines = ["-- Rollback SPs unificación (orden inverso al deploy)"]
    rollback_lines += [f"DROP PROCEDURE IF EXISTS bdm_datos.{p}();" for p in ALL_PROCEDURES]
    rollback.write_text("\n".join(rollback_lines) + "\n", encoding="utf-8")
    print(f"Wrote {rollback}")

    run_dt = ROOT / "deploy_bitbucket" / "db_rcncr_btch_rdshft_dt" / "deploy" / "redshift" / "SQL" / "run_unificacion_ejecucion_secuencial.sql"
    run_dt.write_text(
        f"""-- Orquestador ejecución — unificación por regla (cada regla llama sus escenarios)
TRUNCATE TABLE bdm_datos.unificacion_direccion;

CALL bdm_datos.{SP_R1_ORQ}();
CALL bdm_datos.{SP_R2_ORQ}();
CALL bdm_datos.{SP_R3_ORQ}();
""",
        encoding="utf-8",
    )
    print(f"Wrote {run_dt.name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
