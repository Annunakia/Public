"""Carga mocks R3 nuevos, limpia unificaciones mock, corre R3 y valida suite completa."""
import json
import os
import subprocess
import sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
PY = sys.executable


def run(script, extra=None):
    cmd = [PY, str(TOOLS / script)]
    if extra:
        cmd.extend(extra)
    env = os.environ.copy()
    r = subprocess.run(cmd, capture_output=True, text=True, env=env)
    return r.returncode, r.stdout, r.stderr


def main():
    if not os.environ.get("REDSHIFT_PASSWORD"):
        print("Set REDSHIFT_PASSWORD")
        sys.exit(1)

    steps = []
    for label, script, args in [
        ("load", "dev_load_r3_mocks.py", None),
        ("validate", "dev_r3_suite_check.py", ["--reload"]),
    ]:
        code, out, err = run(script, args)
        steps.append({"step": label, "exit": code, "stderr": err.strip() or None})
        if code != 0 and label == "load":
            print(err or out)
            sys.exit(code)

    try:
        report = json.loads(out)
    except json.JSONDecodeError:
        report = {"raw": out}

    summary = {
        "load": steps[0],
        "validation": report,
        "passed": report.get("passed"),
        "total": report.get("total"),
        "failed": report.get("failed"),
    }
    out_file = TOOLS / "dev_r3_full_run_results.json"
    out_file.write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")
    print(json.dumps(summary, indent=2, default=str))


if __name__ == "__main__":
    main()
