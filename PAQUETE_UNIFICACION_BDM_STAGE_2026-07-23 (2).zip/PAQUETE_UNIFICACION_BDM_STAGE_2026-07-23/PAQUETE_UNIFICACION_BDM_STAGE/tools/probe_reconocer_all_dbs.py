"""Deep probe all databases on Reconocer DEV."""
import json, os, psycopg2
from psycopg2.extras import RealDictCursor

HOST = "eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z.us-east-1.redshift.amazonaws.com"
USER, PWD = "c32525e", os.environ.get("REDSHIFT_PASSWORD", "")

def scan_db(dbname):
    c = psycopg2.connect(host=HOST, port=5440, dbname=dbname, user=USER, password=PWD, sslmode="require", connect_timeout=20)
    cur = c.cursor(cursor_factory=RealDictCursor)
    r = {"database": dbname}
    for q, k in [
        ("SELECT nspname FROM pg_namespace WHERE nspname NOT LIKE 'pg_%%' AND nspname NOT IN ('information_schema','catalog_history') ORDER BY 1", "namespaces"),
        ("SELECT * FROM svv_datashares LIMIT 20", "datashares"),
        ("SELECT datname FROM pg_database ORDER BY 1", "all_dbs"),
    ]:
        try:
            cur.execute(q)
            r[k] = cur.fetchall() if k != "namespaces" else [x["nspname"] for x in cur.fetchall()]
        except Exception as e:
            r[k + "_err"] = str(e)[:150]
    for sch in r.get("namespaces", []):
        if sch in ("ifr_data", "bdm_stage", "bdm_datos", "bdm_tempo", "public"):
            try:
                cur.execute(
                    "SELECT tablename FROM pg_tables WHERE schemaname=%s ORDER BY 1 LIMIT 15", (sch,)
                )
                r[f"tables_{sch}"] = [x["tablename"] for x in cur.fetchall()]
            except Exception as e:
                r[f"tables_{sch}_err"] = str(e)[:100]
    c.close()
    return r

out = [scan_db(db) for db in ("dev", "dba_reconocerbatch", "dba_rncr_batch", "dba")]
print(json.dumps(out, indent=2, default=str))
