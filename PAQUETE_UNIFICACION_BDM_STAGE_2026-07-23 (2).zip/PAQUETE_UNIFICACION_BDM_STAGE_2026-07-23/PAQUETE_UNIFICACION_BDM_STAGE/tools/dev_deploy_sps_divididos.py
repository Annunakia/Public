"""Deploy Unificación SPs divididos (reales + mock) en DEV productor.

Solo objetos que el usuario puede CREATE: DDL mock, v_xpm_*, v_mock_*, 30 SPs.
No toca QA (sin CREATE allí).
"""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

import psycopg2

ROOT = Path(__file__).resolve().parents[1]
STRCT = ROOT / "deploy_bitbucket" / "db_rcncr_btch_rdshft_strct" / "deploy" / "redshift" / "SQL"
PGM = ROOT / "deploy_bitbucket" / "db_rcncr_btch_rdshft_pgm" / "deploy" / "redshift" / "SQL"
PAR = ROOT / "deploy_bitbucket" / "db_rcncr_btch_rdshft_pgm" / "deploy" / "redshift" / "deploy.par"
OUT = ROOT / "Documentacion" / "Evidencias_DEV_DEPLOY_SPS_DIVIDIDOS.md"

HOST = "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
USER = os.environ.get("REDSHIFT_USER", "c32525e")
PWD = os.environ.get("REDSHIFT_PASSWORD", "b27YWI2FL")

STRCT_FILES = [
    "01b_ddl_unificacion_direccion_mock.sql",
    "02_vistas_insumo_edf_views.sql",
    "02b_vistas_insumo_mock.sql",
]


def load_pgm_files() -> list[str]:
    names = []
    for line in PAR.read_text(encoding="utf-8").splitlines():
        name = line.strip()
        if not name or name.startswith("#"):
            continue
        if name.startswith("sp_unificacion_"):
            names.append(name)
    return names


def exec_sql_file(cur, path: Path, *, producer_local_edf: bool = False) -> dict:
    sql = path.read_text(encoding="utf-8")
    # En productor no existe ds_dba_rncr_batch; el datashare vive en consumidor.
    if producer_local_edf:
        sql = sql.replace("ds_dba_rncr_batch.edf_views", "edf_views")
    try:
        cur.execute(sql)
        return {"file": path.name, "ok": True}
    except Exception as e:
        return {
            "file": path.name,
            "ok": False,
            "error": str(e).split("\n")[0][:300],
        }


def main() -> int:
    report: dict = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "host": HOST,
        "db": "dba_batch",
        "strct": [],
        "pgm": [],
    }
    conn = psycopg2.connect(
        host=HOST,
        port=5440,
        dbname="dba_batch",
        user=USER,
        password=PWD,
        sslmode="require",
        connect_timeout=60,
    )
    conn.autocommit = True
    cur = conn.cursor()

    print("=== STRCT ===")
    for name in STRCT_FILES:
        path = STRCT / name
        r = exec_sql_file(
            cur,
            path,
            producer_local_edf=(name == "02_vistas_insumo_edf_views.sql"),
        )
        report["strct"].append(r)
        print(("OK" if r["ok"] else "FAIL"), name, r.get("error", ""))

    print("=== PGM (sp_unificacion_*) ===")
    for name in load_pgm_files():
        path = PGM / name
        if not path.exists():
            r = {"file": name, "ok": False, "error": "missing file"}
        else:
            r = exec_sql_file(cur, path)
        report["pgm"].append(r)
        print(("OK" if r["ok"] else "FAIL"), name, r.get("error", ""))

    # Inventory
    cur.execute(
        """
        SELECT n.nspname, p.proname
        FROM pg_proc p
        JOIN pg_namespace n ON n.oid = p.pronamespace
        WHERE n.nspname = 'bdm_datos'
          AND (
            p.proname LIKE 'sp_unificacion_r%'
            OR p.proname LIKE 'sp_unificacion_regla%'
            OR p.proname LIKE 'sp_unificacion_mock_%'
          )
        ORDER BY 1, 2
        """
    )
    sps = cur.fetchall()
    report["inventory_sps"] = [{"schema": a, "name": b} for a, b in sps]

    cur.execute(
        """
        SELECT table_name
        FROM information_schema.views
        WHERE table_schema = 'bdm_tempo'
          AND (table_name LIKE 'v_mock_%' OR table_name LIKE 'v_xpm_%')
        ORDER BY 1
        """
    )
    report["inventory_views"] = [r[0] for r in cur.fetchall()]

    # Confirm Esc4 fix present in deployed procs
    cur.execute(
        """
        SELECT p.proname,
               CASE
                 WHEN p.prosrc ILIKE '%%HAVING COUNT(*) = 1%%' THEN 'HAS_FIX'
                 ELSE 'NO_FIX'
               END AS fix
        FROM pg_proc p
        JOIN pg_namespace n ON n.oid = p.pronamespace
        WHERE n.nspname = 'bdm_datos'
          AND p.proname IN (
            'sp_unificacion_r2_esc4_diccionario_frecuencia_complemento',
            'sp_unificacion_mock_r2_esc4_diccionario_frecuencia_complemento'
          )
        ORDER BY 1
        """
    )
    report["esc4_fix"] = [{"name": a, "fix": b} for a, b in cur.fetchall()]

    # TC-R2-14 on legacy mock salida
    cur.execute(
        """
        SELECT COUNT(*) AS v
        FROM bdm_stage.perf_persona_meta m
        WHERE m.scenario_code = 'R2_EMPATE'
          AND EXISTS (
            SELECT 1
            FROM bdm_stage.relacion_persona_ubicacion r
            JOIN bdm_stage.unificacion_direccion u
              ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic
             AND u.unifica_atributos = 2
            WHERE r.id_buro_persona = m.id_buro_persona
          )
        """
    )
    report["tc_r2_14_bdm_stage"] = int(cur.fetchone()[0])

    # Real gates snapshot (no re-run)
    cur.execute(
        """
        SELECT
          SUM(CASE WHEN unifica_atributos = 2 THEN 1 ELSE 0 END) AS r2,
          SUM(CASE WHEN cod_dw_direccion_unificada IS NULL THEN 1 ELSE 0 END) AS c03,
          SUM(CASE WHEN cod_dw_persona_ubic = cod_dw_direccion_unificada THEN 1 ELSE 0 END) AS c04
        FROM bdm_datos.unificacion_direccion
        """
    )
    r2, c03, c04 = cur.fetchone()
    report["real_gates"] = {
        "r2": int(r2 or 0),
        "c03": int(c03 or 0),
        "c04": int(c04 or 0),
    }

    cur.close()
    conn.close()

    ok_strct = all(x["ok"] for x in report["strct"])
    ok_pgm = all(x["ok"] for x in report["pgm"])
    n_real = sum(1 for x in report["inventory_sps"] if "mock" not in x["name"])
    n_mock = sum(1 for x in report["inventory_sps"] if "mock" in x["name"])
    report["summary"] = {
        "strct_ok": ok_strct,
        "pgm_ok": ok_pgm,
        "sps_reales": n_real,
        "sps_mock": n_mock,
        "views": len(report["inventory_views"]),
    }

    lines = [
        "# Evidencias — Deploy DEV productor SPs divididos",
        "",
        f"- **Fecha (UTC):** {report['ts']}",
        f"- **Host:** `{HOST}` / `dba_batch` / usuario `{USER}`",
        f"- **STRCT:** {'PASS' if ok_strct else 'FAIL'}",
        f"- **PGM:** {'PASS' if ok_pgm else 'FAIL'}",
        f"- **SPs reales en bdm_datos:** {n_real}",
        f"- **SPs mock en bdm_datos:** {n_mock}",
        f"- **Vistas v_xpm_/v_mock_:** {len(report['inventory_views'])}",
        f"- **Esc4 fix en cluster:** {report['esc4_fix']}",
        f"- **TC-R2-14 (bdm_stage salida legacy):** {report['tc_r2_14_bdm_stage']} (esperado 0)",
        f"- **Gates reales snapshot:** R2={report['real_gates']['r2']} C03={report['real_gates']['c03']} C04={report['real_gates']['c04']}",
        "",
        "## Fallos",
        "",
    ]
    fails = [x for x in report["strct"] + report["pgm"] if not x["ok"]]
    if not fails:
        lines.append("_Ninguno._")
    else:
        for f in fails:
            lines.append(f"- `{f['file']}`: {f.get('error')}")

    lines += [
        "",
        "## Inventario SPs",
        "",
        "```",
        "\n".join(f"{x['schema']}.{x['name']}" for x in report["inventory_sps"]),
        "```",
        "",
        "## Inventario vistas",
        "",
        "```",
        "\n".join(report["inventory_views"]),
        "```",
        "",
        "```json",
        json.dumps(report["summary"], indent=2),
        "```",
        "",
    ]
    OUT.write_text("\n".join(lines), encoding="utf-8")
    print("WROTE", OUT)
    print(json.dumps(report["summary"], indent=2))
    print("esc4", report["esc4_fix"])
    print("TC-R2-14", report["tc_r2_14_bdm_stage"])

    return 0 if ok_strct and ok_pgm else 1


if __name__ == "__main__":
    sys.exit(main())
