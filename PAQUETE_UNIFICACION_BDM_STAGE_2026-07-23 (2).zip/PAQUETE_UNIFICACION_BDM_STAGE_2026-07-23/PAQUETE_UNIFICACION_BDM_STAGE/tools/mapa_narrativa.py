"""Narrativas HTML — regla en simple + conclusión con ejemplo tácito. Sin referencias a query."""
from __future__ import annotations


def escenario_cierre(codigo: str, titulo: str) -> str:
    return f"Escenario: {codigo} — {titulo}."


def html_show_query(regla: str, esc: str, sub: str, estado: str, sql: str) -> bool:
    if regla == "PERFIL DE DATOS":
        return bool((sql or "").strip())
    if not (sql or "").strip():
        return False
    if sub.startswith("RESUMEN ·") or (esc == "Propósito" and "RESUMEN" in sub):
        return bool((sql or "").strip())
    if "Contacttype" in sub or "contacttype" in sub.lower():
        return True
    if estado in ("N/A", "Revisar"):
        return False
    if estado == "Info":
        return False
    if regla == "R3" and estado in ("Bloqueado", "Pendiente GEO", "Esperado"):
        return False
    if esc == "Definición" and sub == "Ubicaciones distintas":
        return False
    if esc == "Motor":
        return False
    return True


def con_univ_rpus(pid: int, rpu: int) -> str:
    return (
        f"En DEV contamos cientos de miles de RPUs: cada fila es una relación persona–dirección "
        f"antes de unificar (casa, trabajo, correspondencia, etc.). "
        f"Ejemplo tácito: id_buro_persona={pid} tiene al menos un RPU ({rpu}) en el insumo; "
        f"si esa persona tuviera otra dirección distinta, sería otro RPU aparte. "
        f"{escenario_cierre('TEMA', 'Total de direcciones (RPUs)')}"
    )


def con_univ_personas(pid: int, dir_txt: str, rpus: int, personas: int) -> str:
    ratio = rpus / max(personas, 1)
    return (
        f"En DEV hay {personas:,} personas distintas detrás de {rpus:,} RPUs "
        f"(~{ratio:.1f} RPUs por persona). "
        f"No son lo mismo: id_buro_persona={pid} concentra varios RPUs en «{dir_txt}» "
        f"(RES, LAB, CRR sobre el mismo texto). "
        f"Ejemplo tácito: una sola persona puede aportar 3 RPUs si reporta la misma calle "
        f"como residencia, laboral y correspondencia. "
        f"{escenario_cierre('TEMA', 'Personas distintas')}"
    )


def con_univ_ubics(ubics: int) -> str:
    return (
        f"En DEV hay {ubics:,} textos de ubicación distintos (cod_dw_ubic). "
        f"Ejemplo tácito: «CALLE 10 20 30» y «CALLE 10 20 32» son dos ubicaciones aunque "
        f"pertenezcan a personas distintas. "
        f"{escenario_cierre('TEMA', 'Ubicaciones distintas')}"
    )


def con_univ_post_r2(post: int, r2_n: int, hija: int, padre: int, comp: str) -> str:
    return (
        f"Tras R2 quedaron {post:,} RPUs «ganadores»: las {r2_n:,} hijas absorbidas ya no cuentan "
        f"como activas. "
        f"Ejemplo tácito del par que sí unificó: hija RPU {hija} (sin complemento) → "
        f"padre RPU {padre} (con «{comp}»). "
        f"{escenario_cierre('TEMA', 'Activas después de R2')}"
    )


def con_r1_general(
    personas_r1: int, rpus_r1: int, grupos: int, personas_total: int, rpus_total: int, pid: int
) -> str:
    pct_p = 100 * personas_r1 / max(personas_total, 1)
    pct_r = 100 * rpus_r1 / max(rpus_total, 1)
    return (
        f"R1 elige una dirección «oficial» cuando la misma persona repite el mismo texto de calle "
        f"en la misma ciudad con distinto uso (casa RES, trabajo LAB, correspondencia CRR). "
        f"En DEV entraron {personas_r1:,} personas ({pct_p:.2f}% de {personas_total:,}) "
        f"con {rpus_r1:,} RPUs ({pct_r:.2f}% de {rpus_total:,}), repartidos en {grupos:,} "
        f"combinaciones persona+calle+ciudad. Salida R1: 0 hijas (empate en todos los casos). "
        f"Ejemplo tácito: id_buro_persona={pid} con RES+LAB+CRR en la misma calle. "
        f"{escenario_cierre('RESUMEN', 'Qué hace la regla R1')}"
    )


def con_r1_contacttype(ct8: int, ct1: int, ct2: int, ct3: int, pid: int) -> str:
    return (
        f"Contacttype es la etiqueta cruda de edf_views por cada RPU: "
        f"1=residencia ({ct1:,}), 2=laboral ({ct2:,}), 3=correspondencia ({ct3:,}), "
        f"8=token masivo ({ct8:,} → se mapea a CRR). "
        f"No es ESC1 ni ESC2: es el insumo INSUMO antes de agrupar. "
        f"Ejemplo tácito: id_buro_persona={pid} puede traer contacttype 9 en filas de la misma calle; "
        f"el cuadro PRE-R1 «Personas que sí entran» explica cuándo califica para R1. "
        f"{escenario_cierre('INSUMO', 'Contacttype en la fuente')}"
    )


def con_r1_entra(
    s: dict,
    ids: dict,
    tipos: list,
    personas_r1: int,
    rpus_r1: int,
    grupos: int,
) -> str:
    requisitos = (
        "Requisitos: (1) misma persona, (2) mismo texto de calle, (3) misma ciudad, "
        "(4) al menos dos tipos de uso distintos (RES/LAB/CRR)."
    )
    if not tipos:
        return (
            f"{requisitos} En DEV cumplen {personas_r1:,} personas con {rpus_r1:,} RPUs "
            f"en {grupos:,} combinaciones persona+calle+ciudad. "
            f"Ejemplo tácito: RPU 100 RES + RPU 101 LAB en «CALLE 10 20 30». "
            f"{escenario_cierre('PRE-R1', 'Personas que sí entran')}"
        )
    det = "; ".join(
        f"RPU {t.get('cod_dw_persona_ubic')} ({t.get('tipo')})" for t in tipos[:4]
    )
    return (
        f"{requisitos} En DEV cumplen {personas_r1:,} personas ({rpus_r1:,} RPUs, "
        f"{grupos:,} combinaciones). "
        f"Ejemplo id_buro_persona={ids['pid']}: repite «{ids['dir']}» con tipos distintos ({det}). "
        f"Recién ahí aplican ESC1/ESC2/ESC3. "
        f"{escenario_cierre('PRE-R1', 'Personas que sí entran')}"
    )


def con_r1_fuera(
    ids: dict, personas_fuera: int, rpus_fuera: int, pct_p: float, pct_r: float
) -> str:
    if ids.get("rpu_fuera"):
        return (
            f"En DEV, id_buro_persona={ids['pid_fuera']}, RPU {ids['rpu_fuera']} NO entra a R1: "
            f"en «{ids['dir_fuera']}» solo hay tipo {ids['tipo_fuera']} para esa persona y ciudad. "
            f"Fuera de R1 quedan {personas_fuera:,} personas ({pct_p:.2f}%) y "
            f"{rpus_fuera:,} RPUs ({pct_r:.2f}%). "
            f"{escenario_cierre('PRE-R1', 'Personas que no entran')}"
        )
    return (
        f"Fuera de R1: {personas_fuera:,} personas ({pct_p:.2f}%) y {rpus_fuera:,} RPUs ({pct_r:.2f}%) "
        f"— no cumplen los tres requisitos juntos (un solo tipo en la calle, o calles distintas). "
        f"Ejemplo tácito: casa en «CRA 7» y oficina en «CL 80» no compiten entre sí en R1. "
        f"{escenario_cierre('PRE-R1', 'Personas que no entran')}"
    )


def con_r1_empate(s: dict, ids: dict, tipos: list, esc_label: str, esc: str, sub: str) -> str:
    det = ", ".join(f"{t.get('tipo')}" for t in tipos[:4]) if tipos else "RES, LAB, CRR"
    return (
        f"En DEV, id_buro_persona={ids['pid']} llegó al scoring R1 ({esc_label}) con tipos "
        f"{det}, pero ninguno ganó: empate en puntaje (mismo # de entidades reportando + bonus CIIU). "
        f"Ejemplo tácito de lo que faltaría para unificar: LAB con 5 reportes y CRR con 3, "
        f"o un CIIU que dé +100.000 solo a un tipo. "
        f"Hoy la data no trae ese desempate. "
        f"{escenario_cierre(esc, sub)}"
    )


def con_r1_politica(part: int, emp: int) -> str:
    pct = 100 * emp / max(part, 1)
    return (
        f"En DEV se evaluaron {part:,} particiones R1 y {emp:,} terminaron en empate "
        f"({pct:.0f}% sin ganador único). La política prefiere no unificar antes que elegir "
        f"un padre arbitrario. "
        f"Ejemplo tácito: tres tipos con score 100004 → 0 filas en unificacion_direccion. "
        f"Ejemplo tácito de salida: un solo tipo con score máximo distinto → 1 padre, N hijas. "
        f"{escenario_cierre('EMPATE', 'Sin desempate')}"
    )


def con_r1_total(pid: int) -> str:
    return (
        f"En DEV la salida R1 (unifica_atributos=1) es 0 filas. Las personas candidatas "
        f"(ej. id_buro_persona={pid}) terminaron en empate al puntuar. "
        f"Ejemplo tácito de fila que faltaría: hija RPU 501 → padre RPU 500, unifica_atributos=1. "
        f"{escenario_cierre('SALIDA', 'Resultado en unificacion_direccion')}"
    )


def con_r2_general(r2_n: int, rpus: int) -> str:
    pct = 100 * r2_n / max(rpus, 1)
    return (
        f"R2 unifica RPUs de la misma persona, mismo texto y mismo tipo cuando solo cambia "
        f"el complemento (apto, oficina, local). En DEV hubo {r2_n:,} hijas ({pct:.1f}% del universo); "
        f"el 100% salió por Escenario 1 (padre con complemento, hija sin). "
        f"Ejemplo tácito de entrada: dos RPUs CRR en «CL 84 C # 9 - 51», uno con «AP 601» y otro vacío. "
        f"Escenarios 2–6 quedaron en 0 porque ESC1 agotó los pares antes. "
        f"{escenario_cierre('RESUMEN', 'Qué hace la regla R2')}"
    )


def con_r2_ct8(r2_ct8: int, r2_n: int, hija: int, padre: int, comp: str) -> str:
    return (
        f"En DEV, {r2_ct8:,} de {r2_n:,} hijas R2 vienen de contacttype 8 (token CRR). "
        f"El complemento viaja en la cadena tokenizada. "
        f"Ejemplo tácito del par real: hija RPU {hija} sin complemento → padre RPU {padre} "
        f"con «{comp}». "
        f"{escenario_cierre('INSUMO', 'Contacttype 8 (token)')}"
    )


def con_r2_esc1(ids: dict, r2_n: int, rpus: int) -> str:
    pct = 100 * r2_n / max(rpus, 1)
    return (
        f"En DEV, hija RPU {ids['hija']} quedó absorbida por padre RPU {ids['padre']}: "
        f"misma persona, texto «{ids['dir_r2']}», mismo tipo CRR. "
        f"Padre trae «{ids['comp_padre']}»; hija no trae complemento. "
        f"Ejemplo tácito de lo que pide ESC1: RPU A complemento «OF 302», RPU B complemento vacío, "
        f"misma calle y tipo. Son {r2_n:,} casos ({pct:.1f}% del universo). "
        f"{escenario_cierre('ESC1', 'Padre con apto, hija sin apto')}"
    )


def con_r2_esc_no_aplica(esc: str, sub: str, hija: int, padre: int, ids: dict) -> str:
    base = ids.get("dir_r2") or "CL 84 C # 9 - 51"
    if " AP " in base:
        base = base.split(" AP ")[0].strip()
    comp = ids.get("comp_padre") or "AP 601"
    ejemplos: dict[str, str] = {
        "ESC2": (
            f"id_buro_persona=X · «{base}» · tipo CRR · RPU 501 «LOCAL 5 PISO 2» y "
            f"RPU 502 «LOCAL 5» (uno contiene al otro; ambos con complemento → ESC1 no aplica)"
        ),
        "ESC3": (
            f"id_buro_persona=X · persona NO NIT · «{base}» · tipo CRR · "
            f"RPU 601 «AP 601» y RPU 602 «AP 802» (misma nomenclatura AP, número distinto; "
            f"ninguno vacío → ESC1 no aplica; ninguno contiene al otro → ESC2 no aplica)"
        ),
        "ESC4": (
            f"id_buro_persona=X · «{base}» · dos RPUs con complementos distintos empatados "
            f"en ESC1–3 y un solo ganador por frecuencia en diccionario_complementos"
        ),
        "ESC5": (
            f"id_buro_persona=X · «{base}» · RPU A «ED 1 TORRE B» y RPU B «AP 601» "
            f"(nomenclaturas de distinto nivel; gana el nivel superior)"
        ),
        "ESC6": (
            f"id_buro_persona=X · «{base}» · empate tras ESC1–5 resuelto solo porque "
            f"un RPU acumula mayor frecuencia histórica que el otro"
        ),
    }
    perfil = ejemplos.get(
        esc,
        f"misma persona, mismo texto y tipo_dir, cumpliendo la regla propia de {esc}",
    )
    return (
        f"En DEV, {esc} tiene volumen 0. El par real hija RPU {hija} / padre RPU {padre} "
        f"ya fue resuelto por Escenario 1 (padre «{comp}», hija sin complemento). "
        f"No quedó remanente para {esc}. "
        f"Para que aplicara haría falta data así: {perfil}. "
        f"Esa combinación no existe hoy en unificacion_direccion. "
        f"{escenario_cierre(esc, sub)}"
    )


def con_r2_motor(hija: int, padre: int) -> str:
    return (
        f"En DEV el motor NIT generó 9 filas en staging y 0 en salida final. "
        f"Ejemplo tácito de lo que haría: persona NIT con dos complementos «LC 101» y «LC 205» "
        f"→ dirección enriquecida generada_enriquecida=1. "
        f"Par referencia sin persistir: hija RPU {hija} / padre RPU {padre}. "
        f"{escenario_cierre('MOTOR', 'NIT enriquecida')}"
    )


def con_r2_remanente(post: int, rpus: int, pid: int, rpu_res: int | None) -> str:
    pct = 100 * post / max(rpus, 1)
    rpu_txt = f"RPU {rpu_res}" if rpu_res else "sus RPUs"
    return (
        f"En DEV, {post:,} RPUs ({pct:.1f}%) no fueron hijas R2: no tenían par complemento "
        f"duplicado bajo la misma persona, texto y tipo. "
        f"Ejemplo tácito: id_buro_persona={pid} con {rpu_txt} candidato R1 pero sin duplicado "
        f"«con complemento / sin complemento» en la misma base. "
        f"{escenario_cierre('SIN PAR', 'No tuvo duplicado R2')}"
    )


def con_r2_total(r2_n: int) -> str:
    return (
        f"En DEV hay {r2_n:,} filas en unificacion_direccion con unifica_atributos=2. "
        f"Ejemplo tácito de cada fila: cod_dw_persona_ubic hija → cod_dw_direccion_unificada padre. "
        f"{escenario_cierre('SALIDA', 'Resultado en unificacion_direccion')}"
    )


def con_r3_general(r3_lat: int, r3_rpus: int, rpu: int, pid: int) -> str:
    return (
        f"R3 busca unificar direcciones muy parecidas de la misma persona en el mismo municipio "
        f"(misma vía, puerta ±1 o ±2), eligiendo la que más entidades reportan. "
        f"Requiere latitud y longitud. En DEV hay {r3_lat} RPUs con geo de {r3_rpus:,} (0%). "
        f"Ejemplo tácito de lo que faltaría: id_buro_persona={pid}, RPU {rpu}, "
        f"«CRA 7  10  20» lat 4.65 long -74.05 y otro RPU «CRA 7  10  21» en la misma cuadra. "
        f"{escenario_cierre('RESUMEN', 'Qué hace la regla R3')}"
    )


def con_r3_geo(r3_lat: int, r3_rpus: int, rpu: int, pid: int) -> str:
    return (
        f"En DEV, latitud y longitud vienen NULL en edf_views ({r3_lat} coordenadas de {r3_rpus:,} RPUs). "
        f"Sin geo, R3 no arranca. "
        f"Ejemplo tácito: RPU {rpu} (id_buro_persona={pid}) debería traer lat/long informadas; "
        f"hoy la query de geo devuelve NULL. "
        f"{escenario_cierre('PRE-R3', 'Coordenadas obligatorias')}"
    )


def con_r3_esc(rpu: int, pid: int) -> str:
    return (
        f"Con geo disponible, R3 emparejaría RPUs en la misma vía con puertas cercanas "
        f"(±1 o ±2) y más reportes en el padre. En DEV: 0 hijas. "
        f"Ejemplo tácito: persona X, municipio Y, «CL 10  20  30» puerta 20 vs «CL 10  20  32» "
        f"puerta 22, distancia válida, padre con más entidades reportando. "
        f"RPU {rpu} (id {pid}) no puede demostrarse por falta de coordenadas. "
        f"{escenario_cierre('ESC1', 'Cercanía vía y puerta')}"
    )


def con_r3_total() -> str:
    return (
        f"En DEV la salida R3 (unifica_atributos=3) es 0 filas — coherente con geo bloqueada. "
        f"Ejemplo tácito de fila futura: hija RPU 700 → padre RPU 701, unifica_atributos=3. "
        f"{escenario_cierre('SALIDA', 'Resultado en unificacion_direccion')}"
    )
