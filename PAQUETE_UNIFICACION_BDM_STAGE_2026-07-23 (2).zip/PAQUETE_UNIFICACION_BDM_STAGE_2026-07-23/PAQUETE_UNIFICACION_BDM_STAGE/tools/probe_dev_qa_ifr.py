import os, psycopg2
from psycopg2.extras import RealDictCursor

HOSTS = {
    "DEV": "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com",
    "QA": "eec-aws-us-eits-procesosbatch-qa-redshift.cwefyckvccgy.us-east-1.redshift.amazonaws.com",
}
pwd = os.environ.get("REDSHIFT_PASSWORD", "")
for label, host in HOSTS.items():
    try:
        c = psycopg2.connect(
            host=host, port=5440, dbname="dba_batch", user="c32525e",
            password=pwd, sslmode="require", connect_timeout=30,
        )
        cur = c.cursor(cursor_factory=RealDictCursor)
        cur.execute(
            "SELECT schema_name FROM information_schema.schemata "
            "WHERE schema_name IN ('ifr_data','bdm_stage','bdm_datos') ORDER BY 1"
        )
        schemas = [r["schema_name"] for r in cur.fetchall()]
        ifr_count = None
        if "ifr_data" in schemas:
            cur.execute("SELECT COUNT(*) AS n FROM ifr_data.xpm")
            ifr_count = cur.fetchone()["n"]
        cur.execute(
            "SELECT datname FROM pg_database "
            "WHERE datname ILIKE '%ifr%' OR datname ILIKE '%share%' LIMIT 10"
        )
        dbs = [r["datname"] for r in cur.fetchall()]
        print(f"{label}: schemas={schemas} ifr_xpm={ifr_count} extra_dbs={dbs}")
        c.close()
    except Exception as e:
        print(f"{label}: ERROR {e}")
