import os, json, psycopg2
from psycopg2.extras import RealDictCursor
h="eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
c=psycopg2.connect(host=h,port=5440,dbname="dba_batch",user="c32525e",password=os.environ["REDSHIFT_PASSWORD"],sslmode="require")
cur=c.cursor(cursor_factory=RealDictCursor)
cur.execute("SELECT id_buro_persona, cod_dw_persona_ubic FROM bdm_stage.relacion_persona_ubicacion WHERE id_buro_persona BETWEEN 888001 AND 888004 ORDER BY 1,2")
print("mocks_loaded", cur.fetchall())
for pid in [888001,888003,888004]:
 cur.execute("SELECT COUNT(*) n FROM bdm_stage.unificacion_direccion u JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic=u.cod_dw_persona_ubic WHERE r.id_buro_persona=%s",(pid,))
 print(pid,"unif_rows",cur.fetchone())
