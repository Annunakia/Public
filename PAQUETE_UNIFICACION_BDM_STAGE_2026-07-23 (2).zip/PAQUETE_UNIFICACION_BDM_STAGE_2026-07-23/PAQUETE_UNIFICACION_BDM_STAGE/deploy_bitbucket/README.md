# deploy_bitbucket — artefactos listos para los 3 repos

Copiar cada subcarpeta al repo homónimo en Bitbucket (`feature/unificacion-edf-views`).

**Convención:** nombres **sin ticket Jira** — solo orden + descripción (Manuel).

| Carpeta local | Repo Bitbucket |
|---------------|----------------|
| `db_rcncr_btch_rdshft_strct/` | [strct](https://code.experian.local/projects/COAWSPPR/repos/db_rcncr_btch_rdshft_strct) |
| `db_rcncr_btch_rdshft_pgm/` | [pgm](https://code.experian.local/projects/COAWSPPR/repos/db_rcncr_btch_rdshft_pgm) |
| `db_rcncr_btch_rdshft_dt/` | [dt](https://code.experian.local/projects/COAWSPPR/repos/db_rcncr_btch_rdshft_dt) |

Guía completa: `Documentacion/GUIA_REORGANIZACION_TRES_REPOS_UNIFICACION.md`
