-- R1 Esc2 — CIIU 81/82/90, mismo texto distinto tipo
-- MODO MOCK — lee v_mock_*/bdm_stage; NO usa edf_views ni v_xpm_*
-- Escenario: Padre RES/CRR + más entidades reportan
-- Fuente: bdm_stage → bdm_tempo.v_mock_* | Salida: bdm_datos.unificacion_direccion_mock | MODO MOCK
-- Prerequisito: sp_unificacion_mock_r1_preparar_insumo
-- Generado: tools/gen_unificacion_mock_sps.py (espejo mock)

CREATE OR REPLACE PROCEDURE bdm_datos.sp_unificacion_mock_r1_esc2_ciiu81_90_mismo_texto_padre_res_crr()
LANGUAGE plpgsql
AS $$
BEGIN

  DROP TABLE IF EXISTS bdm_tempo.stg_mock_regla1_scored;
  DROP TABLE IF EXISTS bdm_tempo.stg_mock_regla1_max;
  DROP TABLE IF EXISTS bdm_tempo.stg_mock_regla1_ganador;
  DROP TABLE IF EXISTS bdm_tempo.stg_mock_regla1_pares;

  CREATE TABLE bdm_tempo.stg_mock_regla1_scored
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  SORTKEY(id_buro_persona, texto_ubicacion)
  AS
  SELECT *,
    'ESC2' AS escenario,
    CASE WHEN tipo_direccion IN ('RES','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan AS score,
    ROW_NUMBER() OVER (
      PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_ciudad
      ORDER BY CASE WHEN tipo_direccion IN ('RES','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan DESC, cod_dw_persona_ubic DESC
    ) AS orden
  FROM bdm_tempo.stg_mock_regla1_insumo
  WHERE cod_act_econo_ciiu_fte IN ('81','82','90');

  CREATE TABLE bdm_tempo.stg_mock_regla1_max
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT id_buro_persona, texto_ubicacion, cod_dw_ciudad, escenario, MAX(score) AS max_score
  FROM bdm_tempo.stg_mock_regla1_scored
  GROUP BY 1, 2, 3, 4;

  CREATE TABLE bdm_tempo.stg_mock_regla1_ganador
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT m.id_buro_persona, m.texto_ubicacion, m.cod_dw_ciudad, m.escenario
  FROM bdm_tempo.stg_mock_regla1_max m
  JOIN bdm_tempo.stg_mock_regla1_scored s
    ON s.id_buro_persona = m.id_buro_persona
   AND s.texto_ubicacion = m.texto_ubicacion
   AND s.cod_dw_ciudad = m.cod_dw_ciudad
   AND s.escenario = m.escenario
   AND s.score = m.max_score
  GROUP BY 1, 2, 3, 4
  HAVING COUNT(*) = 1;

  CREATE TABLE bdm_tempo.stg_mock_regla1_pares
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT hijo.cod_dw_persona_ubic, padre.cod_dw_persona_ubic AS cod_dw_direccion_unificada
  FROM bdm_tempo.stg_mock_regla1_scored padre
  JOIN bdm_tempo.stg_mock_regla1_ganador g
    ON g.id_buro_persona = padre.id_buro_persona
   AND g.texto_ubicacion = padre.texto_ubicacion
   AND g.cod_dw_ciudad = padre.cod_dw_ciudad
   AND g.escenario = padre.escenario
  JOIN bdm_tempo.stg_mock_regla1_scored hijo
    ON padre.id_buro_persona = hijo.id_buro_persona
   AND padre.texto_ubicacion = hijo.texto_ubicacion
   AND padre.cod_dw_ciudad = hijo.cod_dw_ciudad
   AND padre.escenario = hijo.escenario
   AND hijo.orden > 1
   AND padre.cod_dw_tipo_ubicacion_dir <> hijo.cod_dw_tipo_ubicacion_dir
  WHERE padre.orden = 1;

  INSERT INTO bdm_datos.unificacion_direccion_mock
  SELECT cod_dw_persona_ubic, cod_dw_direccion_unificada, 1, CURRENT_DATE, 1, 1, CURRENT_USER
  FROM bdm_tempo.stg_mock_regla1_pares;

  DROP TABLE IF EXISTS bdm_tempo.stg_mock_regla1_scored;
  DROP TABLE IF EXISTS bdm_tempo.stg_mock_regla1_max;
  DROP TABLE IF EXISTS bdm_tempo.stg_mock_regla1_ganador;
  DROP TABLE IF EXISTS bdm_tempo.stg_mock_regla1_pares;

END;
$$;
