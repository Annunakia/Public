-- Orquestador Regla 3
-- Escenario: CALL R3 geo
-- Fuente: edf_views → bdm_tempo.v_xpm_* | Salida: bdm_datos.unificacion_direccion
-- Generado: tools/gen_unificacion_sps_por_escenario.py

CREATE OR REPLACE PROCEDURE bdm_datos.sp_unificacion_regla3()
LANGUAGE plpgsql
AS $$
BEGIN

  CALL bdm_datos.sp_unificacion_r3_esc1_geo_misma_via_puerta_cercana();

END;
$$;
