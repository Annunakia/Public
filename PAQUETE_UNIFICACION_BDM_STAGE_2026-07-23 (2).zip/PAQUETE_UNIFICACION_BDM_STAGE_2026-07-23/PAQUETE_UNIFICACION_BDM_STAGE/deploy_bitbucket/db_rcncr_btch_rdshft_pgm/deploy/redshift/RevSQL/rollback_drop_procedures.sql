-- Rollback SPs unificación (orden inverso al deploy)
-- Mock (orden inverso)
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_mock_regla3();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_mock_r3_esc1_geo_misma_via_puerta_cercana();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_mock_regla2();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_mock_r2_motor_nit_empates_nuevas_direcciones();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_mock_r2_esc6_frecuencia_complemento_gana();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_mock_r2_esc5_nomenclatura_menor_nivel_pierde();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_mock_r2_esc4_diccionario_frecuencia_complemento();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_mock_r2_esc3_sin_nit_misma_nomenclatura();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_mock_r2_esc1_complemento_vacio_esc2_substring_complemento();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_mock_r2_preparar_insumo();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_mock_regla1();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_mock_r1_esc3_otros_ciiu_mayor_entidades_reportan();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_mock_r1_esc2_ciiu81_90_mismo_texto_padre_res_crr();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_mock_r1_esc1_ciiu10_mismo_texto_padre_lab_crr();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_mock_r1_preparar_insumo();
-- Reales / otros
-- Mock (orden inverso)
-- Reales / otros
-- Mock (orden inverso)
-- Reales / otros
-- Mock (orden inverso)
-- Reales / otros
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_regla3();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_r3_esc1_geo_misma_via_puerta_cercana();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_regla2();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_r2_motor_nit_empates_nuevas_direcciones();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_r2_esc6_frecuencia_complemento_gana();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_r2_esc5_nomenclatura_menor_nivel_pierde();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_r2_esc4_diccionario_frecuencia_complemento();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_r2_esc3_sin_nit_misma_nomenclatura();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_r2_esc1_complemento_vacio_esc2_substring_complemento();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_r2_preparar_insumo();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_regla1();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_r1_esc3_otros_ciiu_mayor_entidades_reportan();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_r1_esc2_ciiu81_90_mismo_texto_padre_res_crr();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_r1_esc1_ciiu10_mismo_texto_padre_lab_crr();
DROP PROCEDURE IF EXISTS bdm_datos.sp_unificacion_r1_preparar_insumo();
