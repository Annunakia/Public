-- ============================================================
-- 07_sp_regla3.sql
-- Regla 3: unificación geográfica (vía generadora / puerta ±2)
-- Esquemas: bdm_stage (fuentes + salida), bdm_tempo (staging)
-- Fixes QA: TC-R3-01 Manzana/Rural, TC-R3-08 cuadrantes, TC-R3-10 empate
-- ============================================================

CREATE OR REPLACE PROCEDURE bdm_stage.sp_unificacion_regla3()
LANGUAGE plpgsql
AS $$
BEGIN
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_insumo;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_pares;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_diccionario_via;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_scored;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_ranked;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_ganadores;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_resultado;

  -- ==========================================================
  -- PASO 1: Insumo — solo tipo Vía, sin modificadores B/C/F/BIS
  -- Cuadrantes N/S/E/O se conservan (no excluyen la dirección).
  -- ==========================================================
  CREATE TABLE bdm_tempo.stg_regla3_insumo
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  SORTKEY(id_buro_persona, tipo_via_principal, via_principal)
  AS
  SELECT
    rpu.cod_dw_persona_ubic,
    rpu.id_buro_persona,
    ubi.texto_ubicacion,
    df.complemento,
    UPPER(COALESCE(df.tipo_via_principal, SPLIT_PART(ubi.texto_ubicacion, ' ', 1))) AS tipo_via_principal,
    COALESCE(df.via_principal, SPLIT_PART(ubi.texto_ubicacion, ' ', 2)) AS via_principal,
    COALESCE(df.via_generadora, SPLIT_PART(ubi.texto_ubicacion, ' ', 3)) AS via_generadora,
    COALESCE(df.numero_puerta, SPLIT_PART(ubi.texto_ubicacion, ' ', 4)) AS numero_puerta,
    CAST(
      NULLIF(
        REGEXP_REPLACE(
          COALESCE(df.numero_puerta, SPLIT_PART(ubi.texto_ubicacion, ' ', 4)),
          '[^0-9]',
          ''
        ),
        ''
      ) AS INTEGER
    ) AS numero_puerta_num,
    ubi.cod_dw_ciudad AS cod_dw_municipio,
    ubi.latitud,
    ubi.longitud,
    COALESCE(cnt.numero_entidades_reportan, 0) AS numero_entidades_reportan,
    COALESCE(MAX(rep.fecha_reporte), DATE '1900-01-01') AS fecha_ultima_actualizacion
  FROM bdm_stage.relacion_persona_ubicacion rpu
  JOIN bdm_stage.ubicacion_estandarizada ubi
    ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  LEFT JOIN bdm_stage.direccion_fisica df
    ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
  LEFT JOIN bdm_stage.reporte_relacion_persona_ubica rep
    ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  LEFT JOIN (
    SELECT cod_dw_persona_ubic, COUNT(DISTINCT id_buro_suscriptor) AS numero_entidades_reportan
    FROM bdm_stage.reporte_relacion_persona_ubica
    GROUP BY 1
  ) cnt
    ON rpu.cod_dw_persona_ubic = cnt.cod_dw_persona_ubic
  WHERE rpu.ind_unificacion IS NULL
    -- TC-R3-01: R3 solo aplica a direcciones tipo Vía (excluir Manzana/Rural)
    AND UPPER(COALESCE(df.tipo_via_principal, SPLIT_PART(ubi.texto_ubicacion, ' ', 1)))
        NOT IN ('MZ', 'MN', 'RURAL', 'FINCA', 'FCA')
    AND UPPER(COALESCE(ubi.texto_ubicacion, '')) NOT LIKE 'RURAL %'
    -- Excluir modificadores de puerta (B, C, F, BIS); NO excluir cuadrantes sueltos
    AND ubi.texto_ubicacion !~ '[0-9]{1,3}[A-Z]{1,5}'
    AND CAST(
      NULLIF(
        REGEXP_REPLACE(
          COALESCE(df.numero_puerta, SPLIT_PART(ubi.texto_ubicacion, ' ', 4)),
          '[^0-9]',
          ''
        ),
        ''
      ) AS INTEGER
    ) IS NOT NULL
  GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13;

  -- ==========================================================
  -- PASO 2: Pares candidatos (escenario 1: vía generadora; escenario 2: puerta ±2)
  -- ==========================================================
  CREATE TABLE bdm_tempo.stg_regla3_pares
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT T1.*, 1 AS id_u
  FROM bdm_tempo.stg_regla3_insumo T1
  JOIN bdm_tempo.stg_regla3_insumo T2
    ON T1.id_buro_persona = T2.id_buro_persona
   AND T1.cod_dw_municipio = T2.cod_dw_municipio
   AND T1.tipo_via_principal = T2.tipo_via_principal
   AND T1.via_principal = T2.via_principal
   AND T1.numero_puerta_num = T2.numero_puerta_num
   AND T1.via_generadora <> T2.via_generadora
   AND T1.cod_dw_persona_ubic <> T2.cod_dw_persona_ubic
  GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14

  UNION ALL

  SELECT T1.*, 2 AS id_u
  FROM bdm_tempo.stg_regla3_insumo T1
  JOIN bdm_tempo.stg_regla3_insumo T2
    ON T1.id_buro_persona = T2.id_buro_persona
   AND T1.cod_dw_municipio = T2.cod_dw_municipio
   AND T1.tipo_via_principal = T2.tipo_via_principal
   AND T1.via_principal = T2.via_principal
   AND T1.via_generadora = T2.via_generadora
   AND ABS(T1.numero_puerta_num - T2.numero_puerta_num) = 2
   AND T1.numero_puerta_num <> T2.numero_puerta_num
   AND T1.cod_dw_persona_ubic <> T2.cod_dw_persona_ubic
  GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14;

  -- ==========================================================
  -- PASO 3: Diccionario de vía (frecuencias)
  -- ==========================================================
  CREATE TABLE bdm_tempo.stg_regla3_diccionario_via
  DISTSTYLE ALL
  AS
  SELECT
    'Via_Generadora' AS tipo,
    df.tipo_via_principal || ' ' || df.via_principal || ' ' || CAST(df.numero_puerta AS VARCHAR) AS llave,
    df.via_generadora,
    p.cod_dw_municipio,
    COUNT(rep.cod_dw_persona_ubic) AS conteo
  FROM bdm_stage.direccion_fisica df
  JOIN bdm_stage.ubicacion_estandarizada ue
    ON df.cod_dw_ubic = ue.cod_dw_ubic
  JOIN bdm_tempo.stg_regla3_pares p
    ON p.texto_ubicacion = ue.texto_ubicacion
   AND p.id_u = 1
  JOIN bdm_stage.relacion_persona_ubicacion rpu
    ON df.cod_dw_ubic = rpu.cod_dw_ubic
   AND df.cod_dw_direccion_fisica = rpu.cod_dw_direccion_fisica
  JOIN bdm_stage.reporte_relacion_persona_ubica rep
    ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  GROUP BY 1, 2, 3, 4

  UNION ALL

  SELECT
    'Numero_Puerta' AS tipo,
    df.tipo_via_principal || ' ' || df.via_principal || ' ' || CAST(df.via_generadora AS VARCHAR) AS llave,
    df.numero_puerta AS via_generadora,
    p.cod_dw_municipio,
    COUNT(rep.cod_dw_persona_ubic) AS conteo
  FROM bdm_stage.direccion_fisica df
  JOIN bdm_stage.ubicacion_estandarizada ue
    ON df.cod_dw_ubic = ue.cod_dw_ubic
  JOIN bdm_tempo.stg_regla3_pares p
    ON p.texto_ubicacion = ue.texto_ubicacion
   AND p.id_u = 2
  JOIN bdm_stage.relacion_persona_ubicacion rpu
    ON df.cod_dw_ubic = rpu.cod_dw_ubic
   AND df.cod_dw_direccion_fisica = rpu.cod_dw_direccion_fisica
  JOIN bdm_stage.reporte_relacion_persona_ubica rep
    ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  GROUP BY 1, 2, 3, 4;

  DELETE FROM bdm_stage.diccionario_via;
  INSERT INTO bdm_stage.diccionario_via
  SELECT * FROM bdm_tempo.stg_regla3_diccionario_via;

  -- ==========================================================
  -- PASO 4: Score unificado
  -- ==========================================================
  CREATE TABLE bdm_tempo.stg_regla3_scored
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT
    v.*,
    CASE
      WHEN v.id_u = 1 THEN
        CASE
          WHEN NULLIF(v.latitud, 0) IS NOT NULL AND NULLIF(v.longitud, 0) IS NOT NULL
            THEN 100000000 + COALESCE(dvv.conteo, 0)
          ELSE 0
        END
        + CASE
          WHEN NULLIF(v.latitud, 0) IS NULL OR NULLIF(v.longitud, 0) IS NULL
            THEN COALESCE(
              CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR), '-', '') AS BIGINT),
              0
            )
          ELSE 0
        END
        + COALESCE(v.numero_entidades_reportan, 0)
      WHEN v.id_u = 2 THEN
        CASE
          WHEN NULLIF(v.latitud, 0) IS NOT NULL AND NULLIF(v.longitud, 0) IS NOT NULL
            THEN 100000000 + COALESCE(dvp.conteo, 0)
          ELSE 0
        END
        + CASE
          WHEN NULLIF(v.latitud, 0) IS NULL AND NULLIF(v.longitud, 0) IS NULL
            THEN COALESCE(
              CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR), '-', '') AS BIGINT),
              0
            )
          ELSE 0
        END
        + COALESCE(v.numero_entidades_reportan, 0)
      ELSE 0
    END AS id_unificacion
  FROM bdm_tempo.stg_regla3_pares v
  LEFT JOIN bdm_tempo.stg_regla3_diccionario_via dvv
    ON v.tipo_via_principal || ' ' || v.via_principal || ' ' || CAST(v.numero_puerta AS VARCHAR) = dvv.llave
   AND v.via_generadora = dvv.via_generadora
   AND v.cod_dw_municipio = dvv.cod_dw_municipio
   AND dvv.tipo = 'Via_Generadora'
  LEFT JOIN bdm_tempo.stg_regla3_diccionario_via dvp
    ON v.tipo_via_principal || ' ' || v.via_principal || ' ' || CAST(v.via_generadora AS VARCHAR) = dvp.llave
   AND CAST(v.numero_puerta AS VARCHAR) = CAST(dvp.via_generadora AS VARCHAR)
   AND dvp.tipo = 'Numero_Puerta';

  -- ==========================================================
  -- PASO 5: Ganador por grupo — empate en score => no unifica (TC-R3-10)
  -- ==========================================================
  CREATE TABLE bdm_tempo.stg_regla3_ranked
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT
    s.*,
    MAX(s.id_unificacion) OVER (
      PARTITION BY s.id_buro_persona, s.cod_dw_municipio, s.tipo_via_principal, s.via_principal,
        CASE WHEN s.id_u = 1 THEN CAST(s.numero_puerta_num AS VARCHAR) END,
        CASE WHEN s.id_u = 2 THEN s.via_generadora END
    ) AS max_score_grupo
  FROM bdm_tempo.stg_regla3_scored s;

  CREATE TABLE bdm_tempo.stg_regla3_ganadores
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT *
  FROM (
    SELECT
      r.*,
      SUM(
        CASE WHEN r.id_unificacion = r.max_score_grupo THEN 1 ELSE 0 END
      ) OVER (
        PARTITION BY r.id_buro_persona, r.cod_dw_municipio, r.tipo_via_principal, r.via_principal,
          CASE WHEN r.id_u = 1 THEN CAST(r.numero_puerta_num AS VARCHAR) END,
          CASE WHEN r.id_u = 2 THEN r.via_generadora END
      ) AS cnt_en_max
    FROM bdm_tempo.stg_regla3_ranked r
    WHERE r.id_unificacion = r.max_score_grupo
  ) g
  WHERE g.cnt_en_max = 1;

  -- ==========================================================
  -- PASO 6: Pares padre-hijo (solo hijo -> padre, score estrictamente menor)
  -- ==========================================================
  CREATE TABLE bdm_tempo.stg_regla3_resultado
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT DISTINCT
    p.cod_dw_persona_ubic,
    g.cod_dw_persona_ubic AS cod_dw_direccion_unificada
  FROM bdm_tempo.stg_regla3_ganadores g
  JOIN bdm_tempo.stg_regla3_scored p
    ON g.id_buro_persona = p.id_buro_persona
   AND g.cod_dw_municipio = p.cod_dw_municipio
   AND g.tipo_via_principal = p.tipo_via_principal
   AND g.via_principal = p.via_principal
   AND g.id_u = 1
   AND p.id_u = 1
   AND g.numero_puerta_num = p.numero_puerta_num
   AND g.via_generadora <> p.via_generadora
   AND p.id_unificacion < g.id_unificacion
   AND p.cod_dw_persona_ubic <> g.cod_dw_persona_ubic

  UNION ALL

  SELECT DISTINCT
    p.cod_dw_persona_ubic,
    g.cod_dw_persona_ubic AS cod_dw_direccion_unificada
  FROM bdm_tempo.stg_regla3_ganadores g
  JOIN bdm_tempo.stg_regla3_scored p
    ON g.id_buro_persona = p.id_buro_persona
   AND g.cod_dw_municipio = p.cod_dw_municipio
   AND g.tipo_via_principal = p.tipo_via_principal
   AND g.via_principal = p.via_principal
   AND g.id_u = 2
   AND p.id_u = 2
   AND g.via_generadora = p.via_generadora
   AND p.numero_puerta_num <> g.numero_puerta_num
   AND p.id_unificacion < g.id_unificacion
   AND p.cod_dw_persona_ubic <> g.cod_dw_persona_ubic;

  INSERT INTO bdm_stage.unificacion_direccion
  SELECT DISTINCT
    cod_dw_persona_ubic,
    cod_dw_direccion_unificada,
    3,
    CURRENT_DATE,
    1,
    1,
    LEFT(CURRENT_USER, 30)
  FROM bdm_tempo.stg_regla3_resultado;

  UPDATE bdm_stage.relacion_persona_ubicacion
  SET ind_unificacion = 1
  WHERE cod_dw_persona_ubic IN (
    SELECT cod_dw_persona_ubic FROM bdm_tempo.stg_regla3_resultado
  );

  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_insumo;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_pares;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_diccionario_via;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_scored;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_ranked;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_ganadores;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_resultado;
END;
$$;
