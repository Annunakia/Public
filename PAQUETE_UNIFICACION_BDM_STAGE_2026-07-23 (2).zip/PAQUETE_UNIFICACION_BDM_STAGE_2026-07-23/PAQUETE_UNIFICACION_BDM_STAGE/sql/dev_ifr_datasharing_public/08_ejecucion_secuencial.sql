-- ============================================================
-- 08_ejecucion_secuencial.sql  (QA / XPM real)
-- CALL R1 -> R2 -> R3 sobre public.*
--
-- Precondiciones:
-- 1. Vistas public.v_xpm_* desplegadas (00_vistas_insumo_bdm.sql)
-- 2. SPs 05, 06, 07 desplegados en bdm_datos
-- 3. Catálogos en bdm_datos
-- 4. Ejecutar vía pipeline QA
-- ============================================================

-- Reinicia la tabla de salida antes de la corrida secuencial
TRUNCATE TABLE public.unificacion_direccion;

CALL public.sp_unificacion_regla1();
CALL public.sp_unificacion_regla2();
CALL public.sp_unificacion_regla3();

-- ANALYZE requiere owner de la tabla; omitido en develop del cliente
-- ANALYZE public.unificacion_direccion;
