-- TEMPORAL public schema — revertir a bdm_datos cuando DBA otorgue grants
-- ============================================================
-- 05_sp_regla1.sql  (QA / XPM real)
-- SP: public.sp_unificacion_regla1
-- Fuentes: public.v_xpm_* (ifr_data) | Catálogos: bdm_datos | Salida: bdm_datos
-- Ref: Documentacion/configuracion_ifr_data_qa.md
-- Sync 2026-08-19: ganador R1/R2, UPDATE ind_unificacion, motor XPM (ifr_data)
-- ============================================================

CREATE OR REPLACE PROCEDURE public.sp_unificacion_regla1()
LANGUAGE plpgsql
AS $$
BEGIN
  -- Limpieza de staging de esta regla
  DROP TABLE IF EXISTS public.stg_regla1_insumo;
  DROP TABLE IF EXISTS public.stg_regla1_scored;
  DROP TABLE IF EXISTS public.stg_regla1_max;
  DROP TABLE IF EXISTS public.stg_regla1_ganador;
  DROP TABLE IF EXISTS public.stg_regla1_pares;

  -- ==========================================================
  -- REGLA 1
  -- ==========================================================

  CREATE TABLE public.stg_regla1_insumo
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  SORTKEY(id_buro_persona, texto_ubicacion)
  AS
  SELECT
    rpu.cod_dw_persona_ubic,
    rpu.id_buro_persona,
    ubi.texto_ubicacion,
    df.complemento,
    ubi.cod_dw_ciudad,
    rpu.cod_dw_tipo_ubicacion_dir,
    COALESCE(ciiu.cod_act_econo_ciiu_fte, '') AS cod_act_econo_ciiu_fte,
    COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor), 0) AS numero_entidades_reportan,
    tud.descripcion_tipo_ubicacion_dir AS tipo_direccion
  FROM public.v_xpm_relacion_persona_ubicacion rpu
  JOIN public.v_xpm_ubicacion_estandarizada ubi
    ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  LEFT JOIN public.v_xpm_direccion_fisica df
    ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
  JOIN public.v_xpm_reporte_relacion_persona_ubica rep
    ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  LEFT JOIN public.v_xpm_ciiu_persona ciiu
    ON rpu.id_buro_persona = ciiu.id_buro_persona
  LEFT JOIN public.tipo_ubicacion_dir tud
    ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
  WHERE rpu.ind_unificacion IS NULL
  GROUP BY 1,2,3,4,5,6,7,9;

  CREATE TABLE public.stg_regla1_scored
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  SORTKEY(id_buro_persona, texto_ubicacion)
  AS
  SELECT *,
    CASE
      WHEN cod_act_econo_ciiu_fte = '10' THEN 'ESC1'
      WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN 'ESC2'
      ELSE 'ESC3'
    END AS escenario,
    CASE
      WHEN cod_act_econo_ciiu_fte = '10' THEN
        CASE WHEN tipo_direccion IN ('LAB','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan
      WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN
        CASE WHEN tipo_direccion IN ('RES','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan
      ELSE numero_entidades_reportan
    END AS score,
    ROW_NUMBER() OVER (
      PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_ciudad,
        CASE
          WHEN cod_act_econo_ciiu_fte = '10' THEN 'ESC1'
          WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN 'ESC2'
          ELSE 'ESC3'
        END
      ORDER BY
        CASE
          WHEN cod_act_econo_ciiu_fte = '10' THEN
            CASE WHEN tipo_direccion IN ('LAB','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan
          WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN
            CASE WHEN tipo_direccion IN ('RES','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan
          ELSE numero_entidades_reportan
        END DESC,
        cod_dw_persona_ubic DESC
    ) AS orden
  FROM public.stg_regla1_insumo;

  -- Particiones con ganador unico (score max sin empate -> R1_EMPATE no unifica)
  CREATE TABLE public.stg_regla1_max
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT
    id_buro_persona,
    texto_ubicacion,
    cod_dw_ciudad,
    escenario,
    MAX(score) AS max_score
  FROM public.stg_regla1_scored
  GROUP BY 1, 2, 3, 4;

  CREATE TABLE public.stg_regla1_ganador
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT
    m.id_buro_persona,
    m.texto_ubicacion,
    m.cod_dw_ciudad,
    m.escenario
  FROM public.stg_regla1_max m
  JOIN public.stg_regla1_scored s
    ON s.id_buro_persona = m.id_buro_persona
   AND s.texto_ubicacion = m.texto_ubicacion
   AND s.cod_dw_ciudad = m.cod_dw_ciudad
   AND s.escenario = m.escenario
   AND s.score = m.max_score
  GROUP BY 1, 2, 3, 4
  HAVING COUNT(*) = 1;

  CREATE TABLE public.stg_regla1_pares
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT
    hijo.cod_dw_persona_ubic,
    padre.cod_dw_persona_ubic AS cod_dw_direccion_unificada
  FROM public.stg_regla1_scored padre
  JOIN public.stg_regla1_ganador g
    ON g.id_buro_persona = padre.id_buro_persona
   AND g.texto_ubicacion = padre.texto_ubicacion
   AND g.cod_dw_ciudad = padre.cod_dw_ciudad
   AND g.escenario = padre.escenario
  JOIN public.stg_regla1_scored hijo
    ON padre.id_buro_persona = hijo.id_buro_persona
   AND padre.texto_ubicacion = hijo.texto_ubicacion
   AND padre.cod_dw_ciudad = hijo.cod_dw_ciudad
   AND padre.escenario = hijo.escenario
   AND hijo.orden > 1
   AND padre.cod_dw_tipo_ubicacion_dir <> hijo.cod_dw_tipo_ubicacion_dir
  WHERE padre.orden = 1;

  INSERT INTO public.unificacion_direccion
  SELECT
    cod_dw_persona_ubic,
    cod_dw_direccion_unificada,
    1,
    CURRENT_DATE,
    1,
    1,
    CURRENT_USER
  FROM public.stg_regla1_pares;

  -- ind_unificacion en IFR: solo lectura vía v_xpm_* (NULL). Flag real lo materializa pipeline en ifr_data.

  -- Limpieza final de staging de esta regla
  DROP TABLE IF EXISTS public.stg_regla1_insumo;
  DROP TABLE IF EXISTS public.stg_regla1_scored;
  DROP TABLE IF EXISTS public.stg_regla1_max;
  DROP TABLE IF EXISTS public.stg_regla1_ganador;
  DROP TABLE IF EXISTS public.stg_regla1_pares;
END;
$$;
