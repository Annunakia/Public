# TEMPORAL — Reconocer DEV `dba` / schema `public`

Mientras DBA otorga `bdm_datos` / `bdm_tempo`, desplegar aquí.

| Conexión DBeaver | Valor |
|------------------|-------|
| Host | `eec-aws-us-eits-reconocerbatch-dev-redshift.cz7jl1sn7m8z...` |
| Database | **`dba`** (no `dba_reconocerbatch`) |
| Schema trabajo | **`public`** |
| IFR (cuando datashare listo) | `db_ifr_shared.ifr_data.*` |

Regenerar SPs/vistas: `py -3 tools/gen_reconocer_public_sql.py`

Runner: `py -3 tools/dev_ifr_datasharing_run.py --public-temp`
