-- TEMPORAL: Reconocer DEV db=dba, schema public (sin permisos bdm_datos/bdm_tempo)
-- catalog_history: solo sistema — no usar para objetos pipeline

CREATE OR REPLACE FUNCTION public.convert_epoch_to_date(val BIGINT)
RETURNS DATE
STABLE
AS $$
  SELECT DATE(TIMESTAMP 'epoch' + ($1 / 1000) * INTERVAL '1 second')
$$ LANGUAGE SQL;
