-- ============================================================
-- 03_validaciones_unificacion.sql  (QA / XPM real)
-- Fuentes: bdm_tempo.v_xpm_* | Salida: bdm_datos.unificacion_direccion
-- Ref: Documentacion/ESTADO_COMPLETO_UNIFICACION_BDM.md
-- ============================================================

-- ============================================================
-- A. Conteos de fuentes XPM (vistas BDM)
-- ============================================================
SELECT 'A01_relacion_persona_ubicacion' AS validacion, COUNT(*) AS total
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion;

SELECT 'A02_ubicacion_estandarizada' AS validacion, COUNT(*) AS total
FROM bdm_tempo.v_xpm_ubicacion_estandarizada;

SELECT 'A03_direccion_fisica' AS validacion, COUNT(*) AS total
FROM bdm_tempo.v_xpm_direccion_fisica;

SELECT 'A04_ciiu_persona' AS validacion, COUNT(*) AS total
FROM bdm_tempo.v_xpm_ciiu_persona;

SELECT 'A05_reporte_relacion_persona_ubica' AS validacion, COUNT(*) AS total
FROM bdm_tempo.v_xpm_reporte_relacion_persona_ubica;

SELECT 'A06_tipo_ubicacion_dir' AS validacion, COUNT(*) AS total
FROM bdm_datos.tipo_ubicacion_dir;

-- ============================================================
-- B. Conteos del resultado final
-- ============================================================
SELECT 'B01_total_unificaciones' AS validacion, COUNT(*) AS total
FROM bdm_datos.unificacion_direccion;

SELECT
  'B02_por_regla' AS validacion,
  unifica_atributos,
  COUNT(*) AS total
FROM bdm_datos.unificacion_direccion
GROUP BY 1, 2
ORDER BY 2;

SELECT
  'B03_padres_distintos' AS validacion,
  COUNT(DISTINCT cod_dw_direccion_unificada) AS total
FROM bdm_datos.unificacion_direccion;

SELECT
  'B04_hijos_distintos' AS validacion,
  COUNT(DISTINCT cod_dw_persona_ubic) AS total
FROM bdm_datos.unificacion_direccion;

-- ============================================================
-- C. Validaciones operativas
-- ============================================================
SELECT
  'C01_fechas_del_dia' AS validacion,
  COUNT(*) AS total
FROM bdm_datos.unificacion_direccion
WHERE fecha_unificacion = CURRENT_DATE;

SELECT
  'C02_usuarios_ejecucion' AS validacion,
  usuario_bd,
  COUNT(*) AS total
FROM bdm_datos.unificacion_direccion
GROUP BY 1, 2
ORDER BY 3 DESC, 2;

SELECT
  'C03_hijos_sin_padre' AS validacion,
  COUNT(*) AS total
FROM bdm_datos.unificacion_direccion
WHERE cod_dw_direccion_unificada IS NULL;

SELECT
  'C04_autoreferencia' AS validacion,
  COUNT(*) AS total
FROM bdm_datos.unificacion_direccion
WHERE cod_dw_persona_ubic = cod_dw_direccion_unificada;
