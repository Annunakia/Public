# QA — Unificación con datos reales (`ifr_data`)

Ref: `Documentacion/configuracion_ifr_data_qa.md`

## Arquitectura

```
ifr_data.xpm + xpm_location*     (XPM real, campos tokenizados val.*)
        ↓  00_vistas_insumo_bdm.sql
bdm_tempo.v_xpm_*                  (insumo BDM)
        ↓  SPs R1/R2/R3
bdm_datos.unificacion_direccion    (salida)
```

## Tablas origen en `ifr_data`

| Tabla | Uso |
|-------|-----|
| `xpm` | Raíz persona (pin, CIIU, FK location/counterparties) |
| `xpm_location` | Ubicación por persona |
| `xpm_location_val_contactinformations` | Direcciones tokenizadas (`val.standardized*`) |
| `xpm_counterparties` | Entidades que reportan |

## Orden de despliegue (pipeline QA)

| # | Script | Etapa |
|---|--------|-------|
| 1 | `01_ddl_unificacion_direccion.sql` | DDL salida + catálogos |
| 2 | `00_vistas_insumo_bdm.sql` | Vistas XPM → BDM |
| 3 | `00_smoke_ifr_data.sql` | Gate: conteos |
| 4–6 | `05` → `06` → `07` | Deploy SPs |
| 7 | `08_ejecucion_secuencial.sql` | TRUNCATE + CALL R1→R2→R3 |
| 8 | `03_validaciones_unificacion.sql` | Gate: calidad |

Modos: `SMOKE` (1–3) | `FULL` (1–8)

Índice: `00_EJECUTAR_QA_IFR_DATA.sql` · Alternativa sin SPs: `02_unificacion_sql_plano.sql`

## Mapeo esquemas

| Uso | Esquema |
|-----|---------|
| Fuentes XPM | `ifr_data` |
| Catálogos | `bdm_datos` (fallback `bdm_stage`) |
| Staging + vistas | `bdm_tempo` |
| Resultado | `bdm_datos.unificacion_direccion` |

**Regla:** `relationalizelastupdate` en todos los JOINs XPM.

## Advertencias

- Desplegar y correr **vía pipeline** QA (rol con permiso sobre `ifr_data`).
- Lat/long NULL en XPM → R3 geo limitado.
- Validar FK `xpm.counterparties` → `xpm_counterparties` si reportes salen vacíos.

## Relación con otros frentes

| Carpeta | Uso |
|---------|-----|
| `sql/` | Mock / develop (`bdm_stage`) |
| `sql/benchmark_20k/` | Cierre sintético 20K |
| `sql/qa_ifr_data/` | **Datos reales QA** (este frente) |
| `sql/dev_ifr_datasharing/` | **DEV Reconocer** — mismo SPs, vistas reapuntadas a `db_ifr_shared` |
| `sql/qa_xpm/` | Alias histórico — usar `qa_ifr_data/` |
