-- ============================================================
-- 00_validar_cod_tipo_ident.sql
-- Descubre valores de personIdType en XPM QA (solo SELECT)
-- Ejecutar tras 00_vistas_insumo_bdm.sql
-- Esperado BDM: cod_tipo_ident_fte = 3 → NIT (rama Esc3 motor)
-- ============================================================

-- A) Distribución directa en xpm_location (fuente canónica)
SELECT
  'A_personidtype_xpm_location' AS chk,
  CAST(loc."location.val.personidtype" AS INTEGER) AS cod_tipo_ident_fte,
  COUNT(*) AS filas_location
FROM ifr_data.xpm xpm
JOIN ifr_data.xpm_location loc
  ON xpm.location = loc.id
 AND xpm.relationalizelastupdate = loc.relationalizelastupdate
GROUP BY 1, 2
ORDER BY 2;

-- B) Distribución en vista RPU (hereda personidtype del location)
SELECT
  'B_personidtype_v_rpu' AS chk,
  cod_tipo_ident_fte,
  COUNT(*) AS rpu
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion
GROUP BY 1, 2
ORDER BY 2;

-- C) Cobertura: cuántos contactos tienen personidtype informado
SELECT
  'C_personidtype_no_nulo' AS chk,
  SUM(CASE WHEN cod_tipo_ident_fte IS NOT NULL THEN 1 ELSE 0 END) AS con_tipo,
  SUM(CASE WHEN cod_tipo_ident_fte IS NULL THEN 1 ELSE 0 END) AS sin_tipo,
  COUNT(*) AS total
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion;

-- D) Candidatos NIT (tipo = 3) con complemento (Esc3 motor potencial)
SELECT
  'D_nit_con_complemento' AS chk,
  COUNT(DISTINCT r.id_buro_persona) AS personas
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion r
JOIN bdm_tempo.v_xpm_direccion_fisica df
  ON r.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE COALESCE(r.cod_tipo_ident_fte, 0) = 3
  AND df.complemento IS NOT NULL
  AND LENGTH(TRIM(df.complemento)) > 0;

-- E) Alternativa descartada: counterpartyidtype (entidad reportante, NO persona)
SELECT
  'E_counterpartyidtype_NO_USAR' AS chk,
  CAST(loc."location.val.counterpartyidtype" AS INTEGER) AS counterparty_id_type,
  COUNT(*) AS filas
FROM ifr_data.xpm xpm
JOIN ifr_data.xpm_location loc
  ON xpm.location = loc.id
 AND xpm.relationalizelastupdate = loc.relationalizelastupdate
GROUP BY 1, 2
ORDER BY 2
LIMIT 20;

-- F) FK bestidentifications en raíz (tabla hija no incluida en catálogo pegado — explorar si existe)
SELECT
  'F_xpm_bestidentifications_existe' AS chk,
  CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END AS tabla_en_catalogo
FROM information_schema.tables
WHERE table_schema = 'ifr_data'
  AND table_name = 'xpm_bestidentifications';
