-- ============================================================
-- 00_validar_sp_joins_inline.sql
-- Valida JOINs/columnas de SPs 05/06/07 SIN CREATE VIEW ni DDL.
-- Solo SELECT sobre ifr_data (+ lectura catálogo bdm_stage si existe).
-- Ejecutar en DBeaver con conexión QA (ifr_data lectura).
-- ============================================================

-- Grafo base (equivale a bdm_tempo.v_xpm_contacto_direccion)
WITH contacto AS (
  SELECT
    xpm.pin,
    xpm.relationalizelastupdate,
    loc.id AS cod_dw_ubic,
    ci.id AS cod_dw_persona_ubic,
    ci.id AS cod_dw_direccion_fisica,
    FNV_HASH(xpm.pin) AS id_buro_persona,
    CAST(xpm.pin AS BIGINT) AS cod_pin_persona,
    CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) AS cod_dw_tipo_ubicacion_dir,
    ci."location.val.contactinformations.val.standardizedtextoubicacion" AS texto_ubicacion,
    CAST(ci."location.val.contactinformations.val.standardizeddanecode" AS INTEGER) AS cod_dw_ciudad,
    ci."location.val.contactinformations.val.standardizedcomplemento" AS complemento,
    CAST(loc."location.val.personidtype" AS INTEGER) AS cod_tipo_ident_fte,
    bdm_datos.convert_epoch_to_date(
      CAST(ci."location.val.contactinformations.val.contacteventlastupdated" AS BIGINT)
    ) AS fecha_relacion_persona_ubicaci
  FROM ifr_data.xpm xpm
  JOIN ifr_data.xpm_location loc
    ON xpm.location = loc.id
   AND xpm.relationalizelastupdate = loc.relationalizelastupdate
  JOIN ifr_data.xpm_location_val_contactinformations ci
    ON loc."location.val.contactinformations" = ci.id
   AND loc.relationalizelastupdate = ci.relationalizelastupdate
  WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7)
),
reporte AS (
  SELECT
    ci.id AS cod_dw_persona_ubic,
    CAST(cp."counterparties.val.counterpartyidnumber" AS INTEGER) AS id_buro_suscriptor
  FROM ifr_data.xpm xpm
  JOIN ifr_data.xpm_location loc
    ON xpm.location = loc.id
   AND xpm.relationalizelastupdate = loc.relationalizelastupdate
  JOIN ifr_data.xpm_location_val_contactinformations ci
    ON loc."location.val.contactinformations" = ci.id
   AND loc.relationalizelastupdate = ci.relationalizelastupdate
  JOIN ifr_data.xpm_counterparties cp
    ON xpm.counterparties = cp.id
   AND xpm.relationalizelastupdate = cp.relationalizelastupdate
  WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7)
)

-- SP05 / SP06 / SP07: insumo común (v_xpm_*)
SELECT 'SP_comun_insumo' AS chk, COUNT(DISTINCT c.cod_dw_persona_ubic) AS rpu
FROM contacto c
JOIN reporte rep ON c.cod_dw_persona_ubic = rep.cod_dw_persona_ubic;

-- SP05: + CIIU + tipo_ubicacion_dir (catálogo)
SELECT 'SP05_r1_insumo' AS chk, COUNT(DISTINCT c.cod_dw_persona_ubic) AS rpu
FROM contacto c
JOIN reporte rep ON c.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
LEFT JOIN (
  SELECT DISTINCT FNV_HASH(xpm.pin) AS id_buro_persona,
         xpm."bestpersonalinformation.mainisiccodeforproduct" AS cod_act_econo_ciiu_fte
  FROM ifr_data.xpm xpm
  WHERE xpm."bestpersonalinformation.mainisiccodeforproduct" IS NOT NULL
) ciiu ON c.id_buro_persona = ciiu.id_buro_persona
LEFT JOIN bdm_stage.tipo_ubicacion_dir tud
  ON c.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir;

-- SP06: Esc3 filtro NIT (cod_tipo_ident_fte <> 3)
SELECT 'SP06_esc3_excluye_nit' AS chk, COUNT(*) AS rpu_no_nit
FROM contacto c
WHERE COALESCE(c.cod_tipo_ident_fte, 0) <> 3;

SELECT 'SP06_motor_nit_keys' AS chk, COUNT(*) AS grupos
FROM (
  SELECT c.id_buro_persona, c.texto_ubicacion, c.cod_dw_tipo_ubicacion_dir, c.cod_dw_ciudad
  FROM contacto c
  WHERE COALESCE(c.cod_tipo_ident_fte, 0) = 3
    AND c.complemento IS NOT NULL AND LENGTH(TRIM(c.complemento)) > 0
  GROUP BY 1, 2, 3, 4
  HAVING COUNT(DISTINCT c.cod_dw_persona_ubic) >= 2
) t;

-- SP06: complemento + vía (JOIN df por cod_dw_direccion_fisica)
SELECT 'SP06_df_complemento' AS chk, COUNT(*) AS filas
FROM contacto c
WHERE c.complemento IS NOT NULL AND LENGTH(TRIM(c.complemento)) > 0;

-- SP07: geo (lat/long NULL en XPM hoy → insumo geo vacío, JOIN igualmente válido)
SELECT 'SP07_insumo_geo' AS chk,
       SUM(CASE WHEN CAST(NULL AS DECIMAL(10,6)) IS NOT NULL THEN 1 ELSE 0 END) AS con_latitud,
       COUNT(*) AS total_rpu
FROM contacto c
JOIN reporte rep ON c.cod_dw_persona_ubic = rep.cod_dw_persona_ubic;

-- Coherencia personidtype (vista → SP06 motor)
SELECT 'personidtype_coherente' AS chk,
       SUM(CASE WHEN c.cod_tipo_ident_fte = CAST(loc."location.val.personidtype" AS INTEGER) THEN 1 ELSE 0 END) AS ok,
       SUM(CASE WHEN c.cod_tipo_ident_fte IS DISTINCT FROM CAST(loc."location.val.personidtype" AS INTEGER) THEN 1 ELSE 0 END) AS divergente
FROM contacto c
JOIN ifr_data.xpm_location loc
  ON c.cod_dw_ubic = loc.id
 AND c.relationalizelastupdate = loc.relationalizelastupdate;

-- Catálogo: contacttype 7 (DIR) — aviso pipeline, no bloquea JOINs
SELECT 'catalogo_tipo7_faltante' AS chk, COUNT(*) AS faltantes
FROM (
  SELECT DISTINCT CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) AS t
  FROM ifr_data.xpm xpm
  JOIN ifr_data.xpm_location loc
    ON xpm.location = loc.id AND xpm.relationalizelastupdate = loc.relationalizelastupdate
  JOIN ifr_data.xpm_location_val_contactinformations ci
    ON loc."location.val.contactinformations" = ci.id
   AND loc.relationalizelastupdate = ci.relationalizelastupdate
  WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7)
) x
LEFT JOIN bdm_stage.tipo_ubicacion_dir t ON x.t = t.cod_dw_tipo_ubicacion_dir
WHERE t.cod_dw_tipo_ubicacion_dir IS NULL;
