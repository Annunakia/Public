-- ============================================================
-- 00_descubrir_columnas_ifr_data.sql
-- Solo lectura: nombres reales de columnas XPM en QA
-- ============================================================

-- A) Columnas xpm_location
SELECT 'xpm_location' AS tabla, columnname, external_type
FROM svv_external_columns
WHERE schemaname = 'ifr_data'
  AND tablename = 'xpm_location'
ORDER BY columnnum;

-- B) Columnas xpm_location_val_contactinformations
SELECT 'xpm_location_val_contactinformations' AS tabla, columnname, external_type
FROM svv_external_columns
WHERE schemaname = 'ifr_data'
  AND tablename = 'xpm_location_val_contactinformations'
ORDER BY columnnum;

-- C) Columnas xpm (raiz)
SELECT 'xpm' AS tabla, columnname, external_type
FROM svv_external_columns
WHERE schemaname = 'ifr_data'
  AND tablename = 'xpm'
ORDER BY columnnum;

-- D) Columnas xpm_counterparties
SELECT 'xpm_counterparties' AS tabla, columnname, external_type
FROM svv_external_columns
WHERE schemaname = 'ifr_data'
  AND tablename = 'xpm_counterparties'
ORDER BY columnnum;
