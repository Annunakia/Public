-- ============================================================
-- 00_validar_cadena_sp.sql
-- Valida cadena ifr_data → vistas → insumo SPs (antes de 05/06/07)
-- Ejecutar DESPUÉS de 00_vistas_insumo_bdm.sql
-- ============================================================

-- A) Tablas base ifr_data (ya confirmaste conteos > 0)
SELECT 'ifr_data.xpm' AS paso, COUNT(*) AS total FROM ifr_data.xpm
UNION ALL SELECT 'ifr_data.xpm_location', COUNT(*) FROM ifr_data.xpm_location
UNION ALL SELECT 'ifr_data.xpm_location_val_contactinformations', COUNT(*)
  FROM ifr_data.xpm_location_val_contactinformations
UNION ALL SELECT 'ifr_data.xpm_counterparties', COUNT(*) FROM ifr_data.xpm_counterparties;

-- B) JOIN base contactos (misma lógica que v_xpm_contacto_direccion)
SELECT 'B_join_contactos_direccion' AS paso, COUNT(*) AS total
FROM ifr_data.xpm xpm
JOIN ifr_data.xpm_location loc
  ON xpm.location = loc.id
 AND xpm.relationalizelastupdate = loc.relationalizelastupdate
JOIN ifr_data.xpm_location_val_contactinformations ci
  ON loc."location.val.contactinformations" = ci.id
 AND loc.relationalizelastupdate = ci.relationalizelastupdate
WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7);

-- C) JOIN reportes (misma lógica que v_xpm_reporte_relacion_persona_ubica)
SELECT 'C_join_reportes' AS paso, COUNT(*) AS total
FROM ifr_data.xpm xpm
JOIN ifr_data.xpm_location loc
  ON xpm.location = loc.id
 AND xpm.relationalizelastupdate = loc.relationalizelastupdate
  JOIN ifr_data.xpm_location_val_contactinformations ci
    ON loc."location.val.contactinformations" = ci.id
   AND loc.relationalizelastupdate = ci.relationalizelastupdate
  JOIN ifr_data.xpm_counterparties cp
    ON xpm.counterparties = cp.id
   AND xpm.relationalizelastupdate = cp.relationalizelastupdate
  WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7);

-- D) Vistas BDM (lo que leen los SPs 05/06/07)
SELECT 'D_v_xpm_relacion_persona_ubicacion' AS paso, COUNT(*) AS total
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion
UNION ALL SELECT 'D_v_xpm_reporte_relacion_persona_ubica', COUNT(*)
FROM bdm_tempo.v_xpm_reporte_relacion_persona_ubica
UNION ALL SELECT 'D_v_xpm_ciiu_persona', COUNT(*)
FROM bdm_tempo.v_xpm_ciiu_persona;

-- E) Catálogos que usan los SPs
SELECT 'E_bdm_datos.tipo_ubicacion_dir' AS paso, COUNT(*) AS total
FROM bdm_datos.tipo_ubicacion_dir
UNION ALL SELECT 'E_bdm_datos.nomenclatura', COUNT(*)
FROM bdm_datos.nomenclatura;

-- F) Simula insumo Regla 1 (misma lectura que sp_unificacion_regla1)
SELECT 'F_insumo_regla1_potencial' AS paso, COUNT(DISTINCT rpu.cod_dw_persona_ubic) AS total
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi
  ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_tempo.v_xpm_direccion_fisica df
  ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
JOIN bdm_tempo.v_xpm_reporte_relacion_persona_ubica rep
  ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
WHERE rpu.ind_unificacion IS NULL;

-- G) SPs desplegados
SELECT 'G_sp_regla1' AS paso,
  CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END AS total
FROM pg_proc p
JOIN pg_namespace n ON p.pronamespace = n.oid
WHERE n.nspname = 'bdm_datos' AND p.proname = 'sp_unificacion_regla1'
UNION ALL
SELECT 'G_sp_regla2',
  CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END
FROM pg_proc p
JOIN pg_namespace n ON p.pronamespace = n.oid
WHERE n.nspname = 'bdm_datos' AND p.proname = 'sp_unificacion_regla2'
UNION ALL
SELECT 'G_sp_regla3',
  CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END
FROM pg_proc p
JOIN pg_namespace n ON p.pronamespace = n.oid
WHERE n.nspname = 'bdm_datos' AND p.proname = 'sp_unificacion_regla3';
