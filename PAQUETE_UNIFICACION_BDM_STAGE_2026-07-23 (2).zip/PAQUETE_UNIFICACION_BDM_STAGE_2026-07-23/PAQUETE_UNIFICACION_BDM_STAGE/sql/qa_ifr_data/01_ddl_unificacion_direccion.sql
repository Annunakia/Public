-- ============================================================
-- 01_ddl_unificacion_direccion.sql  (QA / ifr_data)
-- Tabla resultado + catálogos mínimos si no existen en bdm_datos
-- Ref: Documentacion/configuracion_ifr_data_qa.md
-- ============================================================

CREATE TABLE IF NOT EXISTS bdm_datos.unificacion_direccion (
  cod_dw_persona_ubic BIGINT,
  cod_dw_direccion_unificada BIGINT,
  unifica_atributos INTEGER,
  fecha_unificacion DATE,
  lote INTEGER,
  severidad INTEGER,
  usuario_bd VARCHAR(100)
)
DISTSTYLE KEY
DISTKEY (cod_dw_persona_ubic)
SORTKEY (cod_dw_persona_ubic);

CREATE TABLE IF NOT EXISTS bdm_datos.diccionario_complementos (
  cod_dw_ubic BIGINT,
  id_buro_persona INTEGER,
  nomenclatura VARCHAR(50),
  nomen VARCHAR(10),
  valor VARCHAR(50),
  frecuencia INTEGER
)
DISTSTYLE KEY
DISTKEY (cod_dw_ubic)
SORTKEY (cod_dw_ubic, id_buro_persona);

-- Catálogos: si en QA están en bdm_stage, copiar a bdm_datos (SPs leen bdm_datos.*)
CREATE TABLE IF NOT EXISTS bdm_datos.tipo_ubicacion_dir (
  cod_dw_tipo_ubicacion_dir INTEGER,
  descripcion_tipo_ubicacion_dir VARCHAR(20)
)
DISTSTYLE ALL;

INSERT INTO bdm_datos.tipo_ubicacion_dir
SELECT s.cod_dw_tipo_ubicacion_dir, s.descripcion_tipo_ubicacion_dir
FROM bdm_stage.tipo_ubicacion_dir s
WHERE NOT EXISTS (SELECT 1 FROM bdm_datos.tipo_ubicacion_dir LIMIT 1);

INSERT INTO bdm_datos.tipo_ubicacion_dir
SELECT v.cod, v.des
FROM (
  SELECT 1 AS cod, 'RES' AS des UNION ALL
  SELECT 2, 'LAB' UNION ALL
  SELECT 3, 'CRR' UNION ALL
  SELECT 4, 'JUD' UNION ALL
  SELECT 5, 'CCL' UNION ALL
  SELECT 7, 'DIR'
) v
WHERE NOT EXISTS (SELECT 1 FROM bdm_datos.tipo_ubicacion_dir LIMIT 1);

CREATE TABLE IF NOT EXISTS bdm_datos.nomenclatura (
  nomenclatura VARCHAR(10),
  nivel_complemento INTEGER
)
DISTSTYLE ALL;

INSERT INTO bdm_datos.nomenclatura
SELECT s.nomenclatura, s.nivel_complemento
FROM bdm_stage.nomenclatura s
WHERE NOT EXISTS (SELECT 1 FROM bdm_datos.nomenclatura LIMIT 1);
