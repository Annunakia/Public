-- ============================================================
-- 00_EJECUTAR_QA_IFR_DATA.sql
-- Orden de despliegue QA — Unificación con XPM real (ifr_data)
-- Ref: Documentacion/configuracion_ifr_data_qa.md
-- ============================================================

-- Etapa 1: DDL resultado + catálogos
--   sql/qa_ifr_data/01_ddl_unificacion_direccion.sql

-- Etapa 2: Vistas insumo XPM → BDM (lee ifr_data.xpm*)
--   sql/qa_ifr_data/00_vistas_insumo_bdm.sql

-- Etapa 3: Smoke (gate conteos)
--   sql/qa_ifr_data/00_smoke_ifr_data.sql

-- Etapa 4: Stored procedures (secuencial)
--   sql/qa_ifr_data/05_sp_regla1.sql
--   sql/qa_ifr_data/06_sp_regla2.sql
--   sql/qa_ifr_data/07_sp_regla3.sql

-- Etapa 5: Ejecución R1 → R2 → R3
--   sql/qa_ifr_data/08_ejecucion_secuencial.sql

-- Etapa 6: Validaciones (gate calidad)
--   sql/qa_ifr_data/03_validaciones_unificacion.sql

-- Alternativa sin SPs (misma fuente/salida):
--   sql/qa_ifr_data/02_unificacion_sql_plano.sql
