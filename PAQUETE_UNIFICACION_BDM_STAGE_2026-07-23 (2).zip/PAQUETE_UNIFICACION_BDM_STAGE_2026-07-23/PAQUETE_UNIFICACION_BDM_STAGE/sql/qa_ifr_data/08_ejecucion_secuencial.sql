-- ============================================================
-- 08_ejecucion_secuencial.sql  (QA / XPM real)
-- CALL R1 -> R2 -> R3 sobre bdm_datos.*
--
-- Precondiciones:
-- 1. Vistas bdm_tempo.v_xpm_* desplegadas (00_vistas_insumo_bdm.sql)
-- 2. SPs 05, 06, 07 desplegados en bdm_datos
-- 3. Catálogos en bdm_datos
-- 4. Ejecutar vía pipeline QA
-- ============================================================

-- Reinicia la tabla de salida antes de la corrida secuencial
TRUNCATE TABLE bdm_datos.unificacion_direccion;

CALL bdm_datos.sp_unificacion_regla1();
CALL bdm_datos.sp_unificacion_regla2();
CALL bdm_datos.sp_unificacion_regla3();

-- ANALYZE requiere owner de la tabla; omitido en develop del cliente
-- ANALYZE bdm_datos.unificacion_direccion;
