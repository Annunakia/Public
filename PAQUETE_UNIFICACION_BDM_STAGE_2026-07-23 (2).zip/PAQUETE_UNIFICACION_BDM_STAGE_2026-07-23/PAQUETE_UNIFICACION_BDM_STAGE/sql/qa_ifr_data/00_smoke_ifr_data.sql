-- ============================================================
-- 00_smoke_ifr_data.sql
-- Verificar tablas XPM en ifr_data + vistas BDM antes de unificación
-- Ref: Documentacion/configuracion_ifr_data_qa.md
-- ============================================================

-- 1) Tablas XPM base (campos tokenizados)
SELECT 'ifr_data.xpm' AS obj, COUNT(*) AS total
FROM ifr_data.xpm
UNION ALL
SELECT 'ifr_data.xpm_location', COUNT(*) FROM ifr_data.xpm_location
UNION ALL
SELECT 'ifr_data.xpm_location_val_contactinformations', COUNT(*)
FROM ifr_data.xpm_location_val_contactinformations
UNION ALL
SELECT 'ifr_data.xpm_counterparties', COUNT(*) FROM ifr_data.xpm_counterparties;

-- 2) Vistas insumo BDM (requiere 00_vistas_insumo_bdm.sql desplegado)
SELECT 'v_xpm_relacion_persona_ubicacion' AS obj, COUNT(*) AS total
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion
UNION ALL
SELECT 'v_xpm_ubicacion_estandarizada', COUNT(*) FROM bdm_tempo.v_xpm_ubicacion_estandarizada
UNION ALL
SELECT 'v_xpm_direccion_fisica', COUNT(*) FROM bdm_tempo.v_xpm_direccion_fisica
UNION ALL
SELECT 'v_xpm_reporte_relacion_persona_ubica', COUNT(*) FROM bdm_tempo.v_xpm_reporte_relacion_persona_ubica
UNION ALL
SELECT 'v_xpm_ciiu_persona', COUNT(*) FROM bdm_tempo.v_xpm_ciiu_persona
UNION ALL
SELECT 'bdm_datos.tipo_ubicacion_dir', COUNT(*) FROM bdm_datos.tipo_ubicacion_dir
UNION ALL
SELECT 'bdm_datos.nomenclatura', COUNT(*) FROM bdm_datos.nomenclatura
UNION ALL
SELECT 'bdm_datos.unificacion_direccion', COUNT(*) FROM bdm_datos.unificacion_direccion;

-- 3) Muestra campos tokenizados (vista BDM)
SELECT
  rpu.cod_pin_persona,
  ue.texto_ubicacion,
  ue.texto_ubicacion_original,
  ue.score_estandarizacion,
  ue.cod_dw_ciudad,
  ue.latitud,
  ue.longitud,
  df.complemento,
  df.tipo_via_principal,
  df.via_principal,
  df.via_generadora,
  df.numero_puerta,
  rpu.cod_dw_tipo_ubicacion_dir
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ue
  ON rpu.cod_dw_ubic = ue.cod_dw_ubic
JOIN bdm_tempo.v_xpm_direccion_fisica df
  ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.cod_dw_tipo_ubicacion_dir IN (1, 2, 3)
  AND df.complemento IS NOT NULL
LIMIT 100;

-- 4) Cobertura complemento / geo (impacto R2/R3)
SELECT
  COUNT(*) AS rpu_dir,
  SUM(CASE WHEN df.complemento IS NOT NULL AND LENGTH(TRIM(df.complemento)) > 0 THEN 1 ELSE 0 END) AS con_complemento,
  SUM(CASE WHEN ue.latitud IS NOT NULL THEN 1 ELSE 0 END) AS con_lat
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ue ON rpu.cod_dw_ubic = ue.cod_dw_ubic
LEFT JOIN bdm_tempo.v_xpm_direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.cod_dw_tipo_ubicacion_dir IN (1, 2, 3, 7)
  AND rpu.ind_unificacion IS NULL;
