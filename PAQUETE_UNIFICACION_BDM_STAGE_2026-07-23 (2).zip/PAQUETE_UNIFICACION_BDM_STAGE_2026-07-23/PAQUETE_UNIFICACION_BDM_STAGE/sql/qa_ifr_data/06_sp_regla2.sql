-- ============================================================
-- 06_sp_regla2.sql  (QA / XPM real)
-- SP: bdm_datos.sp_unificacion_regla2
-- Fuentes: bdm_tempo.v_xpm_* (ifr_data) | Catálogos: bdm_datos | Salida: bdm_datos
-- Ref: Documentacion/configuracion_ifr_data_qa.md
-- Sync 2026-08-19: ganador R1/R2, UPDATE ind_unificacion, motor XPM (ifr_data)
-- ============================================================

CREATE OR REPLACE PROCEDURE bdm_datos.sp_unificacion_regla2()
LANGUAGE plpgsql
AS $$
BEGIN
  -- Limpieza de staging de esta regla
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_insumo;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_esc1_pares;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e1;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_esc2_pares;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e2;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03_a;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03_e1;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_a;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_c1;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_ganador;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_e;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_a;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_pares;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_freq;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_pares;
  DROP TABLE IF EXISTS bdm_tempo.stg_motor_keys;
  DROP TABLE IF EXISTS bdm_tempo.stg_motor_ranked;
  DROP TABLE IF EXISTS bdm_tempo.stg_motor_insumo;

  -- ==========================================================
  -- REGLA 2
  -- Version validada en la corrida 20K.
  -- ==========================================================

  CREATE TABLE bdm_tempo.stg_regla2_insumo
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT
    rpu.cod_dw_persona_ubic,
    rpu.cod_pin_persona,
    rpu.id_buro_persona,
    rpu.cod_dw_tipo_ubicacion_dir,
    rpu.cod_dw_ubic,
    ubi.texto_ubicacion,
    rpu.cod_dw_direccion_fisica,
    df.complemento,
    ubi.cod_dw_ciudad AS cod_dw_municipio,
    COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor), 0) AS numero_entidades_reportan,
    rpu.fecha_relacion_persona_ubicaci,
    rpu.cod_tipo_ident_fte,
    rpu.lote
  FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
  JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi
    ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  LEFT JOIN bdm_tempo.v_xpm_direccion_fisica df
    ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
  JOIN bdm_tempo.v_xpm_reporte_relacion_persona_ubica rep
    ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  WHERE rpu.ind_unificacion IS NULL
  GROUP BY 1,2,3,4,5,6,7,8,9,11,12,13;

  CREATE TABLE bdm_tempo.stg_regla2_esc1_pares
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT cod_dw_persona_ubic, id_padre
  FROM (
    SELECT
      b.cod_dw_persona_ubic,
      a.cod_dw_persona_ubic AS id_padre,
      ROW_NUMBER() OVER (PARTITION BY b.cod_dw_persona_ubic ORDER BY a.cod_dw_persona_ubic DESC) AS rn
    FROM bdm_tempo.stg_regla2_insumo a
    JOIN bdm_tempo.stg_regla2_insumo b
      ON a.id_buro_persona = b.id_buro_persona
     AND a.texto_ubicacion = b.texto_ubicacion
     AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
     AND a.cod_dw_municipio = b.cod_dw_municipio
     AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
    WHERE a.complemento IS NOT NULL
      AND LENGTH(a.complemento) > 0
      AND (b.complemento IS NULL OR LENGTH(b.complemento) = 0)
  )
  WHERE rn = 1;

  CREATE TABLE bdm_tempo.stg_regla2_e1
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT
    a.cod_dw_persona_ubic,
    b.id_padre,
    a.id_buro_persona,
    a.cod_dw_tipo_ubicacion_dir,
    a.cod_dw_ubic,
    a.texto_ubicacion,
    a.cod_dw_direccion_fisica,
    a.complemento,
    a.cod_dw_municipio,
    a.numero_entidades_reportan,
    a.fecha_relacion_persona_ubicaci,
    CASE WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S' ELSE 'N' END AS ind_unificacion,
    CASE WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'H1' END AS n_id,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.cod_dw_ubic,
        CASE WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S' ELSE 'N' END,
        a.cod_dw_tipo_ubicacion_dir
      ORDER BY a.complemento
    ) AS row_u
  FROM bdm_tempo.stg_regla2_insumo a
  LEFT JOIN bdm_tempo.stg_regla2_esc1_pares b
    ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic;

  CREATE TABLE bdm_tempo.stg_regla2_esc2_pares
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT cod_dw_persona_ubic, id_padre
  FROM (
    SELECT
      b.cod_dw_persona_ubic,
      a.cod_dw_persona_ubic AS id_padre,
      ROW_NUMBER() OVER (PARTITION BY b.cod_dw_persona_ubic ORDER BY b.cod_dw_persona_ubic DESC) AS rn
    FROM bdm_tempo.stg_regla2_e1 a
    JOIN bdm_tempo.stg_regla2_e1 b
      ON a.id_buro_persona = b.id_buro_persona
     AND a.texto_ubicacion = b.texto_ubicacion
     AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
     AND a.cod_dw_municipio = b.cod_dw_municipio
     AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
     AND a.complemento <> b.complemento
    WHERE a.complemento LIKE '%' || b.complemento || '%'
      AND a.ind_unificacion = 'N'
      AND b.ind_unificacion = 'N'
      AND LENGTH(b.complemento) > 0
  )
  WHERE rn = 1;

  CREATE TABLE bdm_tempo.stg_regla2_e2
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT
    a.cod_dw_persona_ubic,
    CASE WHEN a.id_padre IS NOT NULL THEN a.id_padre ELSE b.id_padre END AS id_padre,
    a.id_buro_persona,
    a.cod_dw_tipo_ubicacion_dir,
    a.cod_dw_ubic,
    a.texto_ubicacion,
    a.cod_dw_direccion_fisica,
    a.complemento,
    a.cod_dw_municipio,
    a.numero_entidades_reportan,
    a.fecha_relacion_persona_ubicaci,
    CASE WHEN a.ind_unificacion = 'S' THEN 'S'
         WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S'
         ELSE 'N' END AS ind_unificacion,
    CASE WHEN a.n_id IS NOT NULL THEN a.n_id
         WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'K2' END AS n_id,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.cod_dw_ubic,
        CASE WHEN a.ind_unificacion = 'S' THEN 'S'
             WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S'
             ELSE 'N' END,
        a.cod_dw_tipo_ubicacion_dir
      ORDER BY a.complemento
    ) AS row_u
  FROM bdm_tempo.stg_regla2_e1 a
  LEFT JOIN bdm_tempo.stg_regla2_esc2_pares b
    ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic;

  INSERT INTO bdm_datos.unificacion_direccion
  SELECT DISTINCT
    cod_dw_persona_ubic,
    id_padre,
    2,
    CURRENT_DATE,
    1,
    1,
    LEFT(CURRENT_USER, 30)
  FROM bdm_tempo.stg_regla2_e2
  WHERE ind_unificacion = 'S'
    AND id_padre IS NOT NULL;

  CREATE TABLE bdm_tempo.stg_regla2_e03
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT a.*
  FROM bdm_tempo.stg_regla2_e2 a
  JOIN bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
    ON a.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
  WHERE a.ind_unificacion = 'N'
    AND COALESCE(rpu.cod_tipo_ident_fte, 0) <> 3;

  CREATE TABLE bdm_tempo.stg_regla2_e03_a
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT u1.*
  FROM (
    SELECT
      a.cod_dw_persona_ubic,
      COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 19000101)
        + (COALESCE(a.numero_entidades_reportan, 0) + 10000000) AS id,
      a.texto_ubicacion,
      a.fecha_relacion_persona_ubicaci,
      nmc1.nomenclatura,
      a.id_buro_persona,
      a.cod_dw_tipo_ubicacion_dir,
      a.cod_dw_municipio,
      ROW_NUMBER() OVER (
        PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir,
          a.cod_dw_municipio, nmc1.nomenclatura
        ORDER BY COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 19000101)
          + (COALESCE(a.numero_entidades_reportan, 0) + 10000000)
      ) AS orden
    FROM bdm_tempo.stg_regla2_e03 a
    JOIN bdm_tempo.stg_regla2_e03 b
      ON a.id_buro_persona = b.id_buro_persona
     AND a.texto_ubicacion = b.texto_ubicacion
     AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
     AND a.cod_dw_municipio = b.cod_dw_municipio
     AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
     AND a.complemento <> b.complemento
    JOIN bdm_datos.nomenclatura nmc1
      ON a.complemento LIKE nmc1.nomenclatura || '%'
    JOIN bdm_datos.nomenclatura nmc2
      ON b.complemento LIKE nmc2.nomenclatura || '%'
    WHERE nmc1.nomenclatura = nmc2.nomenclatura
  ) u1;

  CREATE TABLE bdm_tempo.stg_regla2_e03_e1
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT DISTINCT
    b.cod_dw_persona_ubic,
    a.cod_dw_persona_ubic AS id_padre
  FROM bdm_tempo.stg_regla2_e03_a a
  JOIN bdm_tempo.stg_regla2_e03_a b
    ON a.id_buro_persona = b.id_buro_persona
   AND a.texto_ubicacion = b.texto_ubicacion
   AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
   AND a.cod_dw_municipio = b.cod_dw_municipio
   AND a.nomenclatura = b.nomenclatura
   AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
   AND a.id > b.id
  JOIN (
    SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, nomenclatura,
      MAX(orden) AS max_orden
    FROM bdm_tempo.stg_regla2_e03_a
    GROUP BY 1,2,3,4,5
  ) mx
    ON a.id_buro_persona = mx.id_buro_persona
   AND a.texto_ubicacion = mx.texto_ubicacion
   AND a.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir
   AND a.cod_dw_municipio = mx.cod_dw_municipio
   AND a.nomenclatura = mx.nomenclatura
   AND a.orden = mx.max_orden;

  INSERT INTO bdm_datos.unificacion_direccion
  SELECT DISTINCT
    cod_dw_persona_ubic,
    id_padre,
    2,
    CURRENT_DATE,
    1,
    1,
    LEFT(CURRENT_USER, 30)
  FROM bdm_tempo.stg_regla2_e03_e1;

  UPDATE bdm_tempo.stg_regla2_e2
  SET id_padre = stg.id_padre,
      ind_unificacion = 'S',
      n_id = 'L3'
  FROM bdm_tempo.stg_regla2_e03_e1 stg
  WHERE bdm_tempo.stg_regla2_e2.cod_dw_persona_ubic = stg.cod_dw_persona_ubic
    AND bdm_tempo.stg_regla2_e2.id_padre IS NULL;

  CREATE TABLE bdm_tempo.stg_regla2_e04
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT DISTINCT a.*
  FROM (SELECT * FROM bdm_tempo.stg_regla2_e2 WHERE ind_unificacion = 'N') a
  JOIN (SELECT * FROM bdm_tempo.stg_regla2_e2 WHERE ind_unificacion = 'N') b
    ON a.id_buro_persona = b.id_buro_persona
   AND a.texto_ubicacion = b.texto_ubicacion
   AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
   AND a.cod_dw_municipio = b.cod_dw_municipio
   AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
   AND a.complemento <> b.complemento;

  CREATE TABLE bdm_tempo.stg_regla2_e04_a
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT DISTINCT
    a.*,
    nmc1.nomenclatura AS nomenclatura_pri,
    nmc1.nivel_complemento AS nivel_pri
  FROM bdm_tempo.stg_regla2_e04 a
  LEFT JOIN bdm_datos.nomenclatura nmc1
    ON a.complemento LIKE TRIM(nmc1.nomenclatura) || ' %';

  CREATE TABLE bdm_tempo.stg_regla2_e04_c1
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT
    t1.cod_dw_persona_ubic,
    COALESCE(t2.conteo, 0) AS conteo
  FROM bdm_tempo.stg_regla2_e04_a t1
  LEFT JOIN (
    SELECT t1.cod_dw_persona_ubic, SUM(dc.frecuencia) AS conteo
    FROM bdm_tempo.stg_regla2_e04_a t1
    LEFT JOIN bdm_datos.diccionario_complementos dc
      ON t1.cod_dw_ubic = dc.cod_dw_ubic
     AND t1.complemento LIKE '%' || dc.nomenclatura || '%'
     AND t1.id_buro_persona = dc.id_buro_persona
    GROUP BY 1
  ) t2
    ON t1.cod_dw_persona_ubic = t2.cod_dw_persona_ubic;

  -- Esc4: solo unifica si un unico RPU tiene conteo maximo en diccionario (R2_EMPATE excluido)
  CREATE TABLE bdm_tempo.stg_regla2_e04_ganador
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT
    a.id_buro_persona,
    a.texto_ubicacion,
    a.cod_dw_tipo_ubicacion_dir,
    a.cod_dw_municipio
  FROM bdm_tempo.stg_regla2_e04_a a
  LEFT JOIN bdm_tempo.stg_regla2_e04_c1 c
    ON c.cod_dw_persona_ubic = a.cod_dw_persona_ubic
  JOIN (
    SELECT
      a.id_buro_persona,
      a.texto_ubicacion,
      a.cod_dw_tipo_ubicacion_dir,
      a.cod_dw_municipio,
      MAX(COALESCE(c.conteo, 0)) AS max_conteo
    FROM bdm_tempo.stg_regla2_e04_a a
    LEFT JOIN bdm_tempo.stg_regla2_e04_c1 c
      ON c.cod_dw_persona_ubic = a.cod_dw_persona_ubic
    GROUP BY 1, 2, 3, 4
  ) mx
    ON mx.id_buro_persona = a.id_buro_persona
   AND mx.texto_ubicacion = a.texto_ubicacion
   AND mx.cod_dw_tipo_ubicacion_dir = a.cod_dw_tipo_ubicacion_dir
   AND mx.cod_dw_municipio = a.cod_dw_municipio
   AND COALESCE(c.conteo, 0) = mx.max_conteo
  GROUP BY 1, 2, 3, 4
  HAVING COUNT(*) = 1;

  CREATE TABLE bdm_tempo.stg_regla2_e04_e
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT DISTINCT
    b.cod_dw_persona_ubic,
    a.cod_dw_persona_ubic AS id_padre
  FROM (
    SELECT
      a.cod_dw_persona_ubic,
      (COALESCE(b.conteo,0) + 10000000)
        + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR),'-','') AS BIGINT),0) AS id,
      a.id_buro_persona,
      a.cod_dw_tipo_ubicacion_dir,
      a.cod_dw_municipio,
      a.texto_ubicacion,
      ROW_NUMBER() OVER (
        PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
        ORDER BY (COALESCE(b.conteo,0) + 10000000)
          + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR),'-','') AS BIGINT),0)
      ) AS orden
    FROM bdm_tempo.stg_regla2_e04_a a
    LEFT JOIN bdm_tempo.stg_regla2_e04_c1 b
      ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
  ) a
  JOIN (
    SELECT
      a.cod_dw_persona_ubic,
      (COALESCE(b.conteo,0) + 10000000)
        + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR),'-','') AS BIGINT),0) AS id,
      a.id_buro_persona,
      a.cod_dw_tipo_ubicacion_dir,
      a.cod_dw_municipio,
      a.texto_ubicacion,
      ROW_NUMBER() OVER (
        PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
        ORDER BY (COALESCE(b.conteo,0) + 10000000)
          + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR),'-','') AS BIGINT),0)
      ) AS orden
    FROM bdm_tempo.stg_regla2_e04_a a
    LEFT JOIN bdm_tempo.stg_regla2_e04_c1 b
      ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
  ) b
    ON a.id_buro_persona = b.id_buro_persona
   AND a.texto_ubicacion = b.texto_ubicacion
   AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
   AND a.cod_dw_municipio = b.cod_dw_municipio
   AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
   AND a.id > b.id
  JOIN (
    SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, MAX(orden) AS max_orden
    FROM (
      SELECT
        a.cod_dw_persona_ubic,
        (COALESCE(b.conteo,0) + 10000000)
          + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR),'-','') AS BIGINT),0) AS id,
        a.id_buro_persona,
        a.cod_dw_tipo_ubicacion_dir,
        a.cod_dw_municipio,
        a.texto_ubicacion,
        ROW_NUMBER() OVER (
          PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
          ORDER BY (COALESCE(b.conteo,0) + 10000000)
            + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR),'-','') AS BIGINT),0)
        ) AS orden
      FROM bdm_tempo.stg_regla2_e04_a a
      LEFT JOIN bdm_tempo.stg_regla2_e04_c1 b
        ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
    ) tmp
    GROUP BY 1,2,3,4
  ) mx
    ON a.id_buro_persona = mx.id_buro_persona
   AND a.texto_ubicacion = mx.texto_ubicacion
   AND a.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir
   AND a.cod_dw_municipio = mx.cod_dw_municipio
   AND a.orden = mx.max_orden
  JOIN bdm_tempo.stg_regla2_e04_ganador g
    ON g.id_buro_persona = mx.id_buro_persona
   AND g.texto_ubicacion = mx.texto_ubicacion
   AND g.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir
   AND g.cod_dw_municipio = mx.cod_dw_municipio;

  INSERT INTO bdm_datos.unificacion_direccion
  SELECT DISTINCT
    cod_dw_persona_ubic,
    id_padre,
    2,
    CURRENT_DATE,
    1,
    1,
    LEFT(CURRENT_USER,30)
  FROM bdm_tempo.stg_regla2_e04_e;

  UPDATE bdm_tempo.stg_regla2_e2
  SET id_padre = e.id_padre,
      ind_unificacion = 'S',
      n_id = 'B5'
  FROM bdm_tempo.stg_regla2_e04_e e
  WHERE bdm_tempo.stg_regla2_e2.cod_dw_persona_ubic = e.cod_dw_persona_ubic
    AND bdm_tempo.stg_regla2_e2.id_padre IS NULL;

  CREATE TABLE bdm_tempo.stg_regla2_e05
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT DISTINCT a.*
  FROM (SELECT * FROM bdm_tempo.stg_regla2_e2 WHERE ind_unificacion = 'N') a
  JOIN (SELECT * FROM bdm_tempo.stg_regla2_e2 WHERE ind_unificacion = 'N') b
    ON a.id_buro_persona = b.id_buro_persona
   AND a.texto_ubicacion = b.texto_ubicacion
   AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
   AND a.cod_dw_municipio = b.cod_dw_municipio
   AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
   AND a.complemento <> b.complemento;

  CREATE TABLE bdm_tempo.stg_regla2_e05_a
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT DISTINCT
    a.*,
    nmc1.nomenclatura AS nomenclatura_pri,
    nmc1.nivel_complemento AS nivel_pri
  FROM bdm_tempo.stg_regla2_e05 a
  LEFT JOIN bdm_datos.nomenclatura nmc1
    ON a.complemento LIKE TRIM(nmc1.nomenclatura) || ' %';

  CREATE TABLE bdm_tempo.stg_regla2_e05_pares
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT DISTINCT
    b.cod_dw_persona_ubic,
    a.cod_dw_persona_ubic AS id_padre
  FROM bdm_tempo.stg_regla2_e05_a a
  JOIN bdm_tempo.stg_regla2_e05_a b
    ON a.id_buro_persona = b.id_buro_persona
   AND a.texto_ubicacion = b.texto_ubicacion
   AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
   AND a.cod_dw_municipio = b.cod_dw_municipio
   AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
   AND a.complemento <> b.complemento
   AND COALESCE(a.nivel_pri,99) < COALESCE(b.nivel_pri,99)
  WHERE a.nomenclatura_pri IS NOT NULL
    AND b.nomenclatura_pri IS NOT NULL
    AND a.nomenclatura_pri <> b.nomenclatura_pri;

  INSERT INTO bdm_datos.unificacion_direccion
  SELECT DISTINCT
    cod_dw_persona_ubic,
    id_padre,
    2,
    CURRENT_DATE,
    1,
    1,
    LEFT(CURRENT_USER,30)
  FROM bdm_tempo.stg_regla2_e05_pares;

  UPDATE bdm_tempo.stg_regla2_e2
  SET id_padre = e.id_padre,
      ind_unificacion = 'S',
      n_id = 'E5'
  FROM bdm_tempo.stg_regla2_e05_pares e
  WHERE bdm_tempo.stg_regla2_e2.cod_dw_persona_ubic = e.cod_dw_persona_ubic
    AND bdm_tempo.stg_regla2_e2.id_padre IS NULL;

  CREATE TABLE bdm_tempo.stg_regla2_e06_freq
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT
    a.cod_dw_persona_ubic,
    COALESCE(SUM(dc.frecuencia), 0) AS freq
  FROM (SELECT * FROM bdm_tempo.stg_regla2_e2 WHERE ind_unificacion = 'N') a
  LEFT JOIN bdm_datos.diccionario_complementos dc
    ON a.cod_dw_ubic = dc.cod_dw_ubic
   AND a.complemento LIKE '%' || dc.nomenclatura || '%'
   AND a.id_buro_persona = dc.id_buro_persona
  GROUP BY 1;

  CREATE TABLE bdm_tempo.stg_regla2_e06_pares
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT DISTINCT
    b.cod_dw_persona_ubic,
    a.cod_dw_persona_ubic AS id_padre
  FROM (SELECT * FROM bdm_tempo.stg_regla2_e2 WHERE ind_unificacion = 'N') a
  JOIN (SELECT * FROM bdm_tempo.stg_regla2_e2 WHERE ind_unificacion = 'N') b
    ON a.id_buro_persona = b.id_buro_persona
   AND a.texto_ubicacion = b.texto_ubicacion
   AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
   AND a.cod_dw_municipio = b.cod_dw_municipio
   AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
   AND a.complemento <> b.complemento
  JOIN bdm_tempo.stg_regla2_e06_freq fa
    ON a.cod_dw_persona_ubic = fa.cod_dw_persona_ubic
  JOIN bdm_tempo.stg_regla2_e06_freq fb
    ON b.cod_dw_persona_ubic = fb.cod_dw_persona_ubic
  WHERE fa.freq > fb.freq;

  INSERT INTO bdm_datos.unificacion_direccion
  SELECT DISTINCT
    cod_dw_persona_ubic,
    id_padre,
    2,
    CURRENT_DATE,
    1,
    1,
    LEFT(CURRENT_USER,30)
  FROM bdm_tempo.stg_regla2_e06_pares;

  -- Motor R2 (XPM real): Esc3 NIT / Esc5 / Esc6 -> ifr_data.generada_enriquecida=1 + RPU sintetica
  CREATE TABLE bdm_tempo.stg_motor_keys
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT DISTINCT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio
  FROM (
    SELECT e.id_buro_persona, e.texto_ubicacion, e.cod_dw_tipo_ubicacion_dir, e.cod_dw_municipio
    FROM bdm_tempo.stg_regla2_e2 e
    JOIN bdm_tempo.stg_regla2_insumo i ON i.cod_dw_persona_ubic = e.cod_dw_persona_ubic
    WHERE e.ind_unificacion = 'N' AND COALESCE(i.cod_tipo_ident_fte, 0) = 3
    GROUP BY 1, 2, 3, 4
    HAVING COUNT(DISTINCT e.cod_dw_persona_ubic) >= 2

    UNION

    SELECT DISTINCT a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
    FROM bdm_tempo.stg_regla2_e05_a a
    JOIN bdm_tempo.stg_regla2_e05_a b
      ON a.id_buro_persona = b.id_buro_persona
     AND a.texto_ubicacion = b.texto_ubicacion
     AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
     AND a.cod_dw_municipio = b.cod_dw_municipio
     AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
     AND COALESCE(a.nivel_pri, 99) <> COALESCE(b.nivel_pri, 99)
    WHERE a.nomenclatura_pri IS NOT NULL AND b.nomenclatura_pri IS NOT NULL

    UNION

    SELECT DISTINCT a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
    FROM (SELECT * FROM bdm_tempo.stg_regla2_e2 WHERE ind_unificacion = 'N') a
    JOIN (SELECT * FROM bdm_tempo.stg_regla2_e2 WHERE ind_unificacion = 'N') b
      ON a.id_buro_persona = b.id_buro_persona
     AND a.texto_ubicacion = b.texto_ubicacion
     AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
     AND a.cod_dw_municipio = b.cod_dw_municipio
     AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
     AND a.complemento <> b.complemento
    JOIN bdm_tempo.stg_regla2_e06_freq fa ON a.cod_dw_persona_ubic = fa.cod_dw_persona_ubic
    JOIN bdm_tempo.stg_regla2_e06_freq fb ON b.cod_dw_persona_ubic = fb.cod_dw_persona_ubic
    WHERE fa.freq = fb.freq
  ) motor_src;

  CREATE TABLE bdm_tempo.stg_motor_ranked
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT
    e.*,
    ROW_NUMBER() OVER (
      PARTITION BY e.id_buro_persona, e.texto_ubicacion, e.cod_dw_tipo_ubicacion_dir, e.cod_dw_municipio
      ORDER BY e.cod_dw_persona_ubic
    ) AS motor_rn
  FROM bdm_tempo.stg_regla2_e2 e
  JOIN bdm_tempo.stg_motor_keys k
    ON k.id_buro_persona = e.id_buro_persona
   AND k.texto_ubicacion = e.texto_ubicacion
   AND k.cod_dw_tipo_ubicacion_dir = e.cod_dw_tipo_ubicacion_dir
   AND k.cod_dw_municipio = e.cod_dw_municipio
  WHERE e.ind_unificacion = 'N';

  CREATE TABLE bdm_tempo.stg_motor_insumo
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT
    ra.id_buro_persona,
    i.cod_pin_persona,
    ra.cod_dw_ubic,
    ra.cod_dw_tipo_ubicacion_dir,
    ra.fecha_relacion_persona_ubicaci,
    i.lote,
    i.cod_tipo_ident_fte,
    dfa.tipo_via_principal,
    dfa.via_principal,
    dfa.via_generadora,
    dfa.numero_puerta,
    FNV_HASH(CAST(ra.id_buro_persona AS VARCHAR) || '|MOTOR|DF|' || ra.texto_ubicacion) AS cod_dw_direccion_fisica,
    FNV_HASH(CAST(ra.id_buro_persona AS VARCHAR) || '|MOTOR|RPU|' || ra.texto_ubicacion) AS cod_dw_persona_ubic,
    TRIM(
      TRIM(COALESCE(ra.complemento, '')) || ' ' || TRIM(COALESCE(rb.complemento, ''))
    ) AS complemento_motor,
    CAST(1 AS INTEGER) AS generada_enriquecida
  FROM bdm_tempo.stg_motor_ranked ra
  JOIN bdm_tempo.stg_motor_ranked rb
    ON ra.id_buro_persona = rb.id_buro_persona
   AND ra.texto_ubicacion = rb.texto_ubicacion
   AND ra.cod_dw_tipo_ubicacion_dir = rb.cod_dw_tipo_ubicacion_dir
   AND ra.cod_dw_municipio = rb.cod_dw_municipio
   AND ra.motor_rn = 1
   AND rb.motor_rn = 2
  JOIN bdm_tempo.stg_regla2_insumo i
    ON i.cod_dw_persona_ubic = ra.cod_dw_persona_ubic
  JOIN bdm_tempo.v_xpm_direccion_fisica dfa
    ON dfa.cod_dw_direccion_fisica = ra.cod_dw_direccion_fisica;

  -- Salida motor en staging (sin INSERT a ifr_data; pipeline materializa tablas físicas)

  -- Limpieza final de staging de esta regla
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_insumo;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_esc1_pares;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e1;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_esc2_pares;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e2;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03_a;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03_e1;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_a;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_c1;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_ganador;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_e;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_a;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_pares;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_freq;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_pares;
  DROP TABLE IF EXISTS bdm_tempo.stg_motor_keys;
  DROP TABLE IF EXISTS bdm_tempo.stg_motor_ranked;
  DROP TABLE IF EXISTS bdm_tempo.stg_motor_insumo;
END;
$$;
