-- ============================================================
-- diagnostico_r2_r3.sql
-- Solo lectura: por que Regla 2 / Regla 3 no aportan filas
-- en develop (tras R1 = 400).
-- ============================================================

-- ----------------------------------------------------------
-- R2-A) Calidad de complemento en candidatos
-- ----------------------------------------------------------
SELECT
  CASE
    WHEN df.complemento IS NULL THEN 'NULL'
    WHEN LENGTH(TRIM(df.complemento)) = 0 THEN 'VACIO'
    ELSE 'CON_VALOR'
  END AS estado_complemento,
  COUNT(*) AS total
FROM bdm_stage.relacion_persona_ubicacion rpu
LEFT JOIN bdm_stage.direccion_fisica df
  ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.ind_unificacion IS NULL
GROUP BY 1
ORDER BY 1;

-- ----------------------------------------------------------
-- R2-B) Pares mismo texto+tipo+municipio con complemento
--      lleno vs vacio (base del escenario 1 de Regla 2)
-- ----------------------------------------------------------
SELECT COUNT(*) AS pares_r2_esc1_potencial
FROM bdm_stage.relacion_persona_ubicacion a
JOIN bdm_stage.ubicacion_estandarizada ua ON a.cod_dw_ubic = ua.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica dfa ON a.cod_dw_direccion_fisica = dfa.cod_dw_direccion_fisica
JOIN bdm_stage.relacion_persona_ubicacion b
  ON a.id_buro_persona = b.id_buro_persona
 AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
 AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
 AND a.ind_unificacion IS NULL
 AND b.ind_unificacion IS NULL
JOIN bdm_stage.ubicacion_estandarizada ub ON b.cod_dw_ubic = ub.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica dfb ON b.cod_dw_direccion_fisica = dfb.cod_dw_direccion_fisica
WHERE ua.texto_ubicacion = ub.texto_ubicacion
  AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
  AND dfa.complemento IS NOT NULL
  AND LENGTH(TRIM(dfa.complemento)) > 0
  AND (dfb.complemento IS NULL OR LENGTH(TRIM(dfb.complemento)) = 0);

-- ----------------------------------------------------------
-- R2-C) Diccionarios que usa Regla 2 (esc 4/5/6)
-- ----------------------------------------------------------
SELECT 'nomenclatura' AS t, COUNT(*) AS total FROM bdm_stage.nomenclatura
UNION ALL
SELECT 'diccionario_complementos', COUNT(*) FROM bdm_stage.diccionario_complementos
UNION ALL
SELECT 'diccionario_via', COUNT(*) FROM bdm_stage.diccionario_via;

-- ----------------------------------------------------------
-- R3-A) Candidatos con lat/long
-- ----------------------------------------------------------
SELECT
  COUNT(*) AS total_candidatos,
  SUM(CASE WHEN ubi.latitud IS NOT NULL THEN 1 ELSE 0 END) AS con_lat,
  SUM(CASE WHEN ubi.latitud IS NULL THEN 1 ELSE 0 END) AS sin_lat
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi
  ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
WHERE rpu.ind_unificacion IS NULL;

-- ----------------------------------------------------------
-- R3-B) Pares R3 potenciales (misma via + numero cercano)
-- ----------------------------------------------------------
WITH insumo AS (
  SELECT
    rpu.cod_dw_persona_ubic,
    rpu.id_buro_persona,
    ubi.texto_ubicacion,
    ubi.cod_dw_ciudad AS cod_dw_municipio,
    ubi.latitud,
    COALESCE(cnt.numero_entidades_reportan, 0) AS numero_entidades_reportan
  FROM bdm_stage.relacion_persona_ubicacion rpu
  JOIN bdm_stage.ubicacion_estandarizada ubi
    ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  LEFT JOIN (
    SELECT cod_dw_persona_ubic, COUNT(DISTINCT id_buro_suscriptor) AS numero_entidades_reportan
    FROM bdm_stage.reporte_relacion_persona_ubica
    GROUP BY 1
  ) cnt
    ON rpu.cod_dw_persona_ubic = cnt.cod_dw_persona_ubic
  WHERE rpu.ind_unificacion IS NULL
    AND ubi.latitud IS NOT NULL
)
SELECT COUNT(*) AS pares_r3_potencial
FROM insumo a
JOIN insumo b
  ON a.id_buro_persona = b.id_buro_persona
 AND a.cod_dw_municipio = b.cod_dw_municipio
 AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
 AND SPLIT_PART(a.texto_ubicacion,' ',1) = SPLIT_PART(b.texto_ubicacion,' ',1)
 AND SPLIT_PART(a.texto_ubicacion,' ',2) = SPLIT_PART(b.texto_ubicacion,' ',2)
 AND (
   ABS(CAST(SPLIT_PART(a.texto_ubicacion,' ',3) AS INTEGER)
     - CAST(SPLIT_PART(b.texto_ubicacion,' ',3) AS INTEGER)) BETWEEN 1 AND 2
   OR ABS(CAST(SPLIT_PART(a.texto_ubicacion,' ',4) AS INTEGER)
     - CAST(SPLIT_PART(b.texto_ubicacion,' ',4) AS INTEGER)) BETWEEN 1 AND 2
 )
 AND a.numero_entidades_reportan > b.numero_entidades_reportan;

-- ----------------------------------------------------------
-- R3-C) Muestra textos de personas multi (para ver forma real)
-- ----------------------------------------------------------
SELECT
  rpu.id_buro_persona,
  ubi.texto_ubicacion,
  ubi.latitud,
  ubi.longitud,
  df.complemento
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.ind_unificacion IS NULL
  AND rpu.id_buro_persona IN (
    SELECT id_buro_persona
    FROM bdm_stage.relacion_persona_ubicacion
    WHERE ind_unificacion IS NULL
    GROUP BY 1
    HAVING COUNT(*) > 1
    LIMIT 5
  )
ORDER BY 1, 2;
