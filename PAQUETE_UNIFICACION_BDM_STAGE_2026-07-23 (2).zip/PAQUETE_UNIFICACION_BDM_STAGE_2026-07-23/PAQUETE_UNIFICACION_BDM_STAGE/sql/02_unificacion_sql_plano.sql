-- ============================================================
-- 02_unificacion_sql_plano.sql
-- Objetivo: ejecutar Regla 1, Regla 2 y Regla 3 en un solo
-- Redshift leyendo desde bdm_stage.
--
-- Adaptado desde:
--   ws-unificacion/demo_data_sharing/06_consumidor_sp_unificacion_completa.sql
-- ============================================================

-- Precondiciones:
-- 1. En sandbox: ejecutar primero 01_bdm_stage_mock_setup.sql
--    En develop cliente: NO ejecutar 01; usar fuentes ya existentes
-- 2. Tener schemas bdm_stage y bdm_tempo disponibles
-- 3. La tabla resultado es bdm_stage.unificacion_direccion
-- 4. Este script hace TRUNCATE de la tabla de salida

-- ==========================================================
-- LIMPIEZA INICIAL
-- ==========================================================
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_insumo;
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_scored;
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_max;
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_ganador;
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_pares;

DROP TABLE IF EXISTS bdm_tempo.stg_regla2_insumo;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_esc1_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e1;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_esc2_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e2;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03_a;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03_e1;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_a;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_c1;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_ganador;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_e;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_a;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_freq;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_insumo;

DROP TABLE IF EXISTS bdm_tempo.stg_regla3_insumo;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_diccionario_via;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_scored;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_ranked;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_ganadores;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_resultado;

TRUNCATE TABLE bdm_stage.unificacion_direccion;

  -- ==========================================================
  -- REGLA 1
  -- ==========================================================

  CREATE TABLE bdm_tempo.stg_regla1_insumo
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  SORTKEY(id_buro_persona, texto_ubicacion)
  AS
  SELECT
    rpu.cod_dw_persona_ubic,
    rpu.id_buro_persona,
    ubi.texto_ubicacion,
    df.complemento,
    ubi.cod_dw_ciudad,
    rpu.cod_dw_tipo_ubicacion_dir,
    COALESCE(ciiu.cod_act_econo_ciiu_fte, '') AS cod_act_econo_ciiu_fte,
    COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor), 0) AS numero_entidades_reportan,
    tud.descripcion_tipo_ubicacion_dir AS tipo_direccion
  FROM bdm_stage.relacion_persona_ubicacion rpu
  JOIN bdm_stage.ubicacion_estandarizada ubi
    ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  LEFT JOIN bdm_stage.direccion_fisica df
    ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
  JOIN bdm_stage.reporte_relacion_persona_ubica rep
    ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  LEFT JOIN bdm_stage.ciiu_persona ciiu
    ON rpu.id_buro_persona = ciiu.id_buro_persona
  LEFT JOIN bdm_stage.tipo_ubicacion_dir tud
    ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
  WHERE rpu.ind_unificacion IS NULL
  GROUP BY 1,2,3,4,5,6,7,9;

  CREATE TABLE bdm_tempo.stg_regla1_scored
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  SORTKEY(id_buro_persona, texto_ubicacion)
  AS
  SELECT *,
    CASE
      WHEN cod_act_econo_ciiu_fte = '10' THEN 'ESC1'
      WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN 'ESC2'
      ELSE 'ESC3'
    END AS escenario,
    CASE
      WHEN cod_act_econo_ciiu_fte = '10' THEN
        CASE WHEN tipo_direccion IN ('LAB','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan
      WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN
        CASE WHEN tipo_direccion IN ('RES','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan
      ELSE numero_entidades_reportan
    END AS score,
    ROW_NUMBER() OVER (
      PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_ciudad,
        CASE
          WHEN cod_act_econo_ciiu_fte = '10' THEN 'ESC1'
          WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN 'ESC2'
          ELSE 'ESC3'
        END
      ORDER BY
        CASE
          WHEN cod_act_econo_ciiu_fte = '10' THEN
            CASE WHEN tipo_direccion IN ('LAB','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan
          WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN
            CASE WHEN tipo_direccion IN ('RES','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan
          ELSE numero_entidades_reportan
        END DESC,
        cod_dw_persona_ubic DESC
    ) AS orden
  FROM bdm_tempo.stg_regla1_insumo;

  -- Particiones con ganador unico (score max sin empate -> R1_EMPATE no unifica)
  CREATE TABLE bdm_tempo.stg_regla1_max
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT
    id_buro_persona,
    texto_ubicacion,
    cod_dw_ciudad,
    escenario,
    MAX(score) AS max_score
  FROM bdm_tempo.stg_regla1_scored
  GROUP BY 1, 2, 3, 4;

  CREATE TABLE bdm_tempo.stg_regla1_ganador
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT
    m.id_buro_persona,
    m.texto_ubicacion,
    m.cod_dw_ciudad,
    m.escenario
  FROM bdm_tempo.stg_regla1_max m
  JOIN bdm_tempo.stg_regla1_scored s
    ON s.id_buro_persona = m.id_buro_persona
   AND s.texto_ubicacion = m.texto_ubicacion
   AND s.cod_dw_ciudad = m.cod_dw_ciudad
   AND s.escenario = m.escenario
   AND s.score = m.max_score
  GROUP BY 1, 2, 3, 4
  HAVING COUNT(*) = 1;

  CREATE TABLE bdm_tempo.stg_regla1_pares
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT
    hijo.cod_dw_persona_ubic,
    padre.cod_dw_persona_ubic AS cod_dw_direccion_unificada
  FROM bdm_tempo.stg_regla1_scored padre
  JOIN bdm_tempo.stg_regla1_ganador g
    ON g.id_buro_persona = padre.id_buro_persona
   AND g.texto_ubicacion = padre.texto_ubicacion
   AND g.cod_dw_ciudad = padre.cod_dw_ciudad
   AND g.escenario = padre.escenario
  JOIN bdm_tempo.stg_regla1_scored hijo
    ON padre.id_buro_persona = hijo.id_buro_persona
   AND padre.texto_ubicacion = hijo.texto_ubicacion
   AND padre.cod_dw_ciudad = hijo.cod_dw_ciudad
   AND padre.escenario = hijo.escenario
   AND hijo.orden > 1
   AND padre.cod_dw_tipo_ubicacion_dir <> hijo.cod_dw_tipo_ubicacion_dir
  WHERE padre.orden = 1;

  INSERT INTO bdm_stage.unificacion_direccion
  SELECT
    cod_dw_persona_ubic,
    cod_dw_direccion_unificada,
    1,
    CURRENT_DATE,
    1,
    1,
    CURRENT_USER
  FROM bdm_tempo.stg_regla1_pares;

  UPDATE bdm_stage.relacion_persona_ubicacion
  SET ind_unificacion = 1
  FROM bdm_tempo.stg_regla1_pares p
  WHERE bdm_stage.relacion_persona_ubicacion.cod_dw_persona_ubic = p.cod_dw_persona_ubic;

  -- ==========================================================
  -- REGLA 2
  -- Version validada en la corrida 20K.
  -- ==========================================================

  CREATE TABLE bdm_tempo.stg_regla2_insumo
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT
    rpu.cod_dw_persona_ubic,
    rpu.cod_pin_persona,
    rpu.id_buro_persona,
    rpu.cod_dw_tipo_ubicacion_dir,
    rpu.cod_dw_ubic,
    ubi.texto_ubicacion,
    rpu.cod_dw_direccion_fisica,
    df.complemento,
    ubi.cod_dw_ciudad AS cod_dw_municipio,
    COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor), 0) AS numero_entidades_reportan,
    rpu.fecha_relacion_persona_ubicaci
  FROM bdm_stage.relacion_persona_ubicacion rpu
  JOIN bdm_stage.ubicacion_estandarizada ubi
    ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  LEFT JOIN bdm_stage.direccion_fisica df
    ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
  JOIN bdm_stage.reporte_relacion_persona_ubica rep
    ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  WHERE rpu.ind_unificacion IS NULL
  GROUP BY 1,2,3,4,5,6,7,8,9,11;

  CREATE TABLE bdm_tempo.stg_regla2_esc1_pares
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT cod_dw_persona_ubic, id_padre
  FROM (
    SELECT
      b.cod_dw_persona_ubic,
      a.cod_dw_persona_ubic AS id_padre,
      ROW_NUMBER() OVER (PARTITION BY b.cod_dw_persona_ubic ORDER BY a.cod_dw_persona_ubic DESC) AS rn
    FROM bdm_tempo.stg_regla2_insumo a
    JOIN bdm_tempo.stg_regla2_insumo b
      ON a.id_buro_persona = b.id_buro_persona
     AND a.texto_ubicacion = b.texto_ubicacion
     AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
     AND a.cod_dw_municipio = b.cod_dw_municipio
     AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
    WHERE a.complemento IS NOT NULL
      AND LENGTH(a.complemento) > 0
      AND (b.complemento IS NULL OR LENGTH(b.complemento) = 0)
  )
  WHERE rn = 1;

  CREATE TABLE bdm_tempo.stg_regla2_e1
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT
    a.cod_dw_persona_ubic,
    b.id_padre,
    a.id_buro_persona,
    a.cod_dw_tipo_ubicacion_dir,
    a.cod_dw_ubic,
    a.texto_ubicacion,
    a.cod_dw_direccion_fisica,
    a.complemento,
    a.cod_dw_municipio,
    a.numero_entidades_reportan,
    a.fecha_relacion_persona_ubicaci,
    CASE WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S' ELSE 'N' END AS ind_unificacion,
    CASE WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'H1' END AS n_id,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.cod_dw_ubic,
        CASE WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S' ELSE 'N' END,
        a.cod_dw_tipo_ubicacion_dir
      ORDER BY a.complemento
    ) AS row_u
  FROM bdm_tempo.stg_regla2_insumo a
  LEFT JOIN bdm_tempo.stg_regla2_esc1_pares b
    ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic;

  CREATE TABLE bdm_tempo.stg_regla2_esc2_pares
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT cod_dw_persona_ubic, id_padre
  FROM (
    SELECT
      b.cod_dw_persona_ubic,
      a.cod_dw_persona_ubic AS id_padre,
      ROW_NUMBER() OVER (PARTITION BY b.cod_dw_persona_ubic ORDER BY b.cod_dw_persona_ubic DESC) AS rn
    FROM bdm_tempo.stg_regla2_e1 a
    JOIN bdm_tempo.stg_regla2_e1 b
      ON a.id_buro_persona = b.id_buro_persona
     AND a.texto_ubicacion = b.texto_ubicacion
     AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
     AND a.cod_dw_municipio = b.cod_dw_municipio
     AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
     AND a.complemento <> b.complemento
    WHERE a.complemento LIKE '%' || b.complemento || '%'
      AND a.ind_unificacion = 'N'
      AND b.ind_unificacion = 'N'
      AND LENGTH(b.complemento) > 0
  )
  WHERE rn = 1;

  CREATE TABLE bdm_tempo.stg_regla2_e2
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT
    a.cod_dw_persona_ubic,
    CASE WHEN a.id_padre IS NOT NULL THEN a.id_padre ELSE b.id_padre END AS id_padre,
    a.id_buro_persona,
    a.cod_dw_tipo_ubicacion_dir,
    a.cod_dw_ubic,
    a.texto_ubicacion,
    a.cod_dw_direccion_fisica,
    a.complemento,
    a.cod_dw_municipio,
    a.numero_entidades_reportan,
    a.fecha_relacion_persona_ubicaci,
    CASE WHEN a.ind_unificacion = 'S' THEN 'S'
         WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S'
         ELSE 'N' END AS ind_unificacion,
    CASE WHEN a.n_id IS NOT NULL THEN a.n_id
         WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'K2' END AS n_id,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.cod_dw_ubic,
        CASE WHEN a.ind_unificacion = 'S' THEN 'S'
             WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S'
             ELSE 'N' END,
        a.cod_dw_tipo_ubicacion_dir
      ORDER BY a.complemento
    ) AS row_u
  FROM bdm_tempo.stg_regla2_e1 a
  LEFT JOIN bdm_tempo.stg_regla2_esc2_pares b
    ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic;

  INSERT INTO bdm_stage.unificacion_direccion
  SELECT DISTINCT
    cod_dw_persona_ubic,
    id_padre,
    2,
    CURRENT_DATE,
    1,
    1,
    LEFT(CURRENT_USER, 30)
  FROM bdm_tempo.stg_regla2_e2
  WHERE ind_unificacion = 'S'
    AND id_padre IS NOT NULL;

  CREATE TABLE bdm_tempo.stg_regla2_e03
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT a.*
  FROM bdm_tempo.stg_regla2_e2 a
  JOIN bdm_stage.relacion_persona_ubicacion rpu
    ON a.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
  WHERE a.ind_unificacion = 'N'
    AND COALESCE(rpu.cod_tipo_ident_fte, 0) <> 3;

  CREATE TABLE bdm_tempo.stg_regla2_e03_a
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT u1.*
  FROM (
    SELECT
      a.cod_dw_persona_ubic,
      COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 19000101)
        + (COALESCE(a.numero_entidades_reportan, 0) + 10000000) AS id,
      a.texto_ubicacion,
      a.fecha_relacion_persona_ubicaci,
      nmc1.nomenclatura,
      a.id_buro_persona,
      a.cod_dw_tipo_ubicacion_dir,
      a.cod_dw_municipio,
      ROW_NUMBER() OVER (
        PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir,
          a.cod_dw_municipio, nmc1.nomenclatura
        ORDER BY COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 19000101)
          + (COALESCE(a.numero_entidades_reportan, 0) + 10000000)
      ) AS orden
    FROM bdm_tempo.stg_regla2_e03 a
    JOIN bdm_tempo.stg_regla2_e03 b
      ON a.id_buro_persona = b.id_buro_persona
     AND a.texto_ubicacion = b.texto_ubicacion
     AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
     AND a.cod_dw_municipio = b.cod_dw_municipio
     AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
     AND a.complemento <> b.complemento
    JOIN bdm_stage.nomenclatura nmc1
      ON a.complemento LIKE nmc1.nomenclatura || '%'
    JOIN bdm_stage.nomenclatura nmc2
      ON b.complemento LIKE nmc2.nomenclatura || '%'
    WHERE nmc1.nomenclatura = nmc2.nomenclatura
  ) u1;

  CREATE TABLE bdm_tempo.stg_regla2_e03_e1
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT DISTINCT
    b.cod_dw_persona_ubic,
    a.cod_dw_persona_ubic AS id_padre
  FROM bdm_tempo.stg_regla2_e03_a a
  JOIN bdm_tempo.stg_regla2_e03_a b
    ON a.id_buro_persona = b.id_buro_persona
   AND a.texto_ubicacion = b.texto_ubicacion
   AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
   AND a.cod_dw_municipio = b.cod_dw_municipio
   AND a.nomenclatura = b.nomenclatura
   AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
   AND a.id > b.id
  JOIN (
    SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, nomenclatura,
      MAX(orden) AS max_orden
    FROM bdm_tempo.stg_regla2_e03_a
    GROUP BY 1,2,3,4,5
  ) mx
    ON a.id_buro_persona = mx.id_buro_persona
   AND a.texto_ubicacion = mx.texto_ubicacion
   AND a.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir
   AND a.cod_dw_municipio = mx.cod_dw_municipio
   AND a.nomenclatura = mx.nomenclatura
   AND a.orden = mx.max_orden;

  INSERT INTO bdm_stage.unificacion_direccion
  SELECT DISTINCT
    cod_dw_persona_ubic,
    id_padre,
    2,
    CURRENT_DATE,
    1,
    1,
    LEFT(CURRENT_USER, 30)
  FROM bdm_tempo.stg_regla2_e03_e1;

  UPDATE bdm_tempo.stg_regla2_e2
  SET id_padre = stg.id_padre,
      ind_unificacion = 'S',
      n_id = 'L3'
  FROM bdm_tempo.stg_regla2_e03_e1 stg
  WHERE bdm_tempo.stg_regla2_e2.cod_dw_persona_ubic = stg.cod_dw_persona_ubic
    AND bdm_tempo.stg_regla2_e2.id_padre IS NULL;

  CREATE TABLE bdm_tempo.stg_regla2_e04
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT DISTINCT a.*
  FROM (SELECT * FROM bdm_tempo.stg_regla2_e2 WHERE ind_unificacion = 'N') a
  JOIN (SELECT * FROM bdm_tempo.stg_regla2_e2 WHERE ind_unificacion = 'N') b
    ON a.id_buro_persona = b.id_buro_persona
   AND a.texto_ubicacion = b.texto_ubicacion
   AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
   AND a.cod_dw_municipio = b.cod_dw_municipio
   AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
   AND a.complemento <> b.complemento;

  CREATE TABLE bdm_tempo.stg_regla2_e04_a
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT DISTINCT
    a.*,
    nmc1.nomenclatura AS nomenclatura_pri,
    nmc1.nivel_complemento AS nivel_pri
  FROM bdm_tempo.stg_regla2_e04 a
  LEFT JOIN bdm_stage.nomenclatura nmc1
    ON a.complemento LIKE TRIM(nmc1.nomenclatura) || ' %';

  CREATE TABLE bdm_tempo.stg_regla2_e04_c1
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT
    t1.cod_dw_persona_ubic,
    COALESCE(t2.conteo, 0) AS conteo
  FROM bdm_tempo.stg_regla2_e04_a t1
  LEFT JOIN (
    SELECT t1.cod_dw_persona_ubic, SUM(dc.frecuencia) AS conteo
    FROM bdm_tempo.stg_regla2_e04_a t1
    LEFT JOIN bdm_stage.diccionario_complementos dc
      ON t1.cod_dw_ubic = dc.cod_dw_ubic
     AND t1.complemento LIKE '%' || dc.nomenclatura || '%'
     AND t1.id_buro_persona = dc.id_buro_persona
    GROUP BY 1
  ) t2
    ON t1.cod_dw_persona_ubic = t2.cod_dw_persona_ubic;

  -- Esc4: solo unifica si un unico RPU tiene conteo maximo en diccionario (R2_EMPATE excluido)
  CREATE TABLE bdm_tempo.stg_regla2_e04_ganador
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT
    a.id_buro_persona,
    a.texto_ubicacion,
    a.cod_dw_tipo_ubicacion_dir,
    a.cod_dw_municipio
  FROM bdm_tempo.stg_regla2_e04_a a
  LEFT JOIN bdm_tempo.stg_regla2_e04_c1 c
    ON c.cod_dw_persona_ubic = a.cod_dw_persona_ubic
  JOIN (
    SELECT
      a.id_buro_persona,
      a.texto_ubicacion,
      a.cod_dw_tipo_ubicacion_dir,
      a.cod_dw_municipio,
      MAX(COALESCE(c.conteo, 0)) AS max_conteo
    FROM bdm_tempo.stg_regla2_e04_a a
    LEFT JOIN bdm_tempo.stg_regla2_e04_c1 c
      ON c.cod_dw_persona_ubic = a.cod_dw_persona_ubic
    GROUP BY 1, 2, 3, 4
  ) mx
    ON mx.id_buro_persona = a.id_buro_persona
   AND mx.texto_ubicacion = a.texto_ubicacion
   AND mx.cod_dw_tipo_ubicacion_dir = a.cod_dw_tipo_ubicacion_dir
   AND mx.cod_dw_municipio = a.cod_dw_municipio
   AND COALESCE(c.conteo, 0) = mx.max_conteo
  GROUP BY 1, 2, 3, 4
  HAVING COUNT(*) = 1;

  CREATE TABLE bdm_tempo.stg_regla2_e04_e
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT DISTINCT
    b.cod_dw_persona_ubic,
    a.cod_dw_persona_ubic AS id_padre
  FROM (
    SELECT
      a.cod_dw_persona_ubic,
      (COALESCE(b.conteo,0) + 10000000)
        + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR),'-','') AS BIGINT),0) AS id,
      a.id_buro_persona,
      a.cod_dw_tipo_ubicacion_dir,
      a.cod_dw_municipio,
      a.texto_ubicacion,
      ROW_NUMBER() OVER (
        PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
        ORDER BY (COALESCE(b.conteo,0) + 10000000)
          + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR),'-','') AS BIGINT),0)
      ) AS orden
    FROM bdm_tempo.stg_regla2_e04_a a
    LEFT JOIN bdm_tempo.stg_regla2_e04_c1 b
      ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
  ) a
  JOIN (
    SELECT
      a.cod_dw_persona_ubic,
      (COALESCE(b.conteo,0) + 10000000)
        + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR),'-','') AS BIGINT),0) AS id,
      a.id_buro_persona,
      a.cod_dw_tipo_ubicacion_dir,
      a.cod_dw_municipio,
      a.texto_ubicacion,
      ROW_NUMBER() OVER (
        PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
        ORDER BY (COALESCE(b.conteo,0) + 10000000)
          + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR),'-','') AS BIGINT),0)
      ) AS orden
    FROM bdm_tempo.stg_regla2_e04_a a
    LEFT JOIN bdm_tempo.stg_regla2_e04_c1 b
      ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
  ) b
    ON a.id_buro_persona = b.id_buro_persona
   AND a.texto_ubicacion = b.texto_ubicacion
   AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
   AND a.cod_dw_municipio = b.cod_dw_municipio
   AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
   AND a.id > b.id
  JOIN (
    SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, MAX(orden) AS max_orden
    FROM (
      SELECT
        a.cod_dw_persona_ubic,
        (COALESCE(b.conteo,0) + 10000000)
          + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR),'-','') AS BIGINT),0) AS id,
        a.id_buro_persona,
        a.cod_dw_tipo_ubicacion_dir,
        a.cod_dw_municipio,
        a.texto_ubicacion,
        ROW_NUMBER() OVER (
          PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
          ORDER BY (COALESCE(b.conteo,0) + 10000000)
            + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR),'-','') AS BIGINT),0)
        ) AS orden
      FROM bdm_tempo.stg_regla2_e04_a a
      LEFT JOIN bdm_tempo.stg_regla2_e04_c1 b
        ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
    ) tmp
    GROUP BY 1,2,3,4
  ) mx
    ON a.id_buro_persona = mx.id_buro_persona
   AND a.texto_ubicacion = mx.texto_ubicacion
   AND a.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir
   AND a.cod_dw_municipio = mx.cod_dw_municipio
   AND a.orden = mx.max_orden
  JOIN bdm_tempo.stg_regla2_e04_ganador g
    ON g.id_buro_persona = mx.id_buro_persona
   AND g.texto_ubicacion = mx.texto_ubicacion
   AND g.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir
   AND g.cod_dw_municipio = mx.cod_dw_municipio;

  INSERT INTO bdm_stage.unificacion_direccion
  SELECT DISTINCT
    cod_dw_persona_ubic,
    id_padre,
    2,
    CURRENT_DATE,
    1,
    1,
    LEFT(CURRENT_USER,30)
  FROM bdm_tempo.stg_regla2_e04_e;

  UPDATE bdm_tempo.stg_regla2_e2
  SET id_padre = e.id_padre,
      ind_unificacion = 'S',
      n_id = 'B5'
  FROM bdm_tempo.stg_regla2_e04_e e
  WHERE bdm_tempo.stg_regla2_e2.cod_dw_persona_ubic = e.cod_dw_persona_ubic
    AND bdm_tempo.stg_regla2_e2.id_padre IS NULL;

  CREATE TABLE bdm_tempo.stg_regla2_e05
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT DISTINCT a.*
  FROM (SELECT * FROM bdm_tempo.stg_regla2_e2 WHERE ind_unificacion = 'N') a
  JOIN (SELECT * FROM bdm_tempo.stg_regla2_e2 WHERE ind_unificacion = 'N') b
    ON a.id_buro_persona = b.id_buro_persona
   AND a.texto_ubicacion = b.texto_ubicacion
   AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
   AND a.cod_dw_municipio = b.cod_dw_municipio
   AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
   AND a.complemento <> b.complemento;

  CREATE TABLE bdm_tempo.stg_regla2_e05_a
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT DISTINCT
    a.*,
    nmc1.nomenclatura AS nomenclatura_pri,
    nmc1.nivel_complemento AS nivel_pri
  FROM bdm_tempo.stg_regla2_e05 a
  LEFT JOIN bdm_stage.nomenclatura nmc1
    ON a.complemento LIKE TRIM(nmc1.nomenclatura) || ' %';

  CREATE TABLE bdm_tempo.stg_regla2_e05_pares
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT DISTINCT
    b.cod_dw_persona_ubic,
    a.cod_dw_persona_ubic AS id_padre
  FROM bdm_tempo.stg_regla2_e05_a a
  JOIN bdm_tempo.stg_regla2_e05_a b
    ON a.id_buro_persona = b.id_buro_persona
   AND a.texto_ubicacion = b.texto_ubicacion
   AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
   AND a.cod_dw_municipio = b.cod_dw_municipio
   AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
   AND a.complemento <> b.complemento
   AND COALESCE(a.nivel_pri,99) < COALESCE(b.nivel_pri,99)
  WHERE a.nomenclatura_pri IS NOT NULL
    AND b.nomenclatura_pri IS NOT NULL
    AND a.nomenclatura_pri <> b.nomenclatura_pri;

  INSERT INTO bdm_stage.unificacion_direccion
  SELECT DISTINCT
    cod_dw_persona_ubic,
    id_padre,
    2,
    CURRENT_DATE,
    1,
    1,
    LEFT(CURRENT_USER,30)
  FROM bdm_tempo.stg_regla2_e05_pares;

  UPDATE bdm_tempo.stg_regla2_e2
  SET id_padre = e.id_padre,
      ind_unificacion = 'S',
      n_id = 'E5'
  FROM bdm_tempo.stg_regla2_e05_pares e
  WHERE bdm_tempo.stg_regla2_e2.cod_dw_persona_ubic = e.cod_dw_persona_ubic
    AND bdm_tempo.stg_regla2_e2.id_padre IS NULL;

  CREATE TABLE bdm_tempo.stg_regla2_e06_freq
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT
    a.cod_dw_persona_ubic,
    COALESCE(SUM(dc.frecuencia), 0) AS freq
  FROM (SELECT * FROM bdm_tempo.stg_regla2_e2 WHERE ind_unificacion = 'N') a
  LEFT JOIN bdm_stage.diccionario_complementos dc
    ON a.cod_dw_ubic = dc.cod_dw_ubic
   AND a.complemento LIKE '%' || dc.nomenclatura || '%'
   AND a.id_buro_persona = dc.id_buro_persona
  GROUP BY 1;

  CREATE TABLE bdm_tempo.stg_regla2_e06_pares
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT DISTINCT
    b.cod_dw_persona_ubic,
    a.cod_dw_persona_ubic AS id_padre
  FROM (SELECT * FROM bdm_tempo.stg_regla2_e2 WHERE ind_unificacion = 'N') a
  JOIN (SELECT * FROM bdm_tempo.stg_regla2_e2 WHERE ind_unificacion = 'N') b
    ON a.id_buro_persona = b.id_buro_persona
   AND a.texto_ubicacion = b.texto_ubicacion
   AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
   AND a.cod_dw_municipio = b.cod_dw_municipio
   AND a.cod_dw_persona_ubic <> b.cod_dw_persona_ubic
   AND a.complemento <> b.complemento
  JOIN bdm_tempo.stg_regla2_e06_freq fa
    ON a.cod_dw_persona_ubic = fa.cod_dw_persona_ubic
  JOIN bdm_tempo.stg_regla2_e06_freq fb
    ON b.cod_dw_persona_ubic = fb.cod_dw_persona_ubic
  WHERE fa.freq > fb.freq;

  INSERT INTO bdm_stage.unificacion_direccion
  SELECT DISTINCT
    cod_dw_persona_ubic,
    id_padre,
    2,
    CURRENT_DATE,
    1,
    1,
    LEFT(CURRENT_USER,30)
  FROM bdm_tempo.stg_regla2_e06_pares;

  -- Motor R2: Esc3 NIT / Esc5 / Esc6 -> nueva direccion generada_enriquecida=1 + RPU 3
  CREATE TABLE bdm_tempo.stg_motor_insumo
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT
    m.id_buro_persona,
    m.scenario_code,
    ra.cod_pin_persona,
    ra.cod_dw_ubic,
    ra.cod_dw_tipo_ubicacion_dir,
    ra.fecha_relacion_persona_ubicaci,
    ra.lote,
    ra.cod_tipo_ident_fte,
    dfa.tipo_via_principal,
    dfa.via_principal,
    dfa.via_generadora,
    dfa.numero_puerta,
    m.id_buro_persona * 1000 + 103 AS cod_dw_direccion_fisica,
    m.id_buro_persona * 1000 + 3 AS cod_dw_persona_ubic,
    TRIM(
      TRIM(COALESCE(dfa.complemento, '')) || ' ' || TRIM(COALESCE(dfb.complemento, ''))
    ) AS complemento_motor
  FROM bdm_stage.perf_persona_meta m
  JOIN bdm_stage.relacion_persona_ubicacion ra
    ON ra.id_buro_persona = m.id_buro_persona
   AND ra.orden_prioridad = 1
  JOIN bdm_stage.relacion_persona_ubicacion rb
    ON rb.id_buro_persona = m.id_buro_persona
   AND rb.orden_prioridad = 2
  JOIN bdm_stage.direccion_fisica dfa
    ON dfa.cod_dw_direccion_fisica = ra.cod_dw_direccion_fisica
  JOIN bdm_stage.direccion_fisica dfb
    ON dfb.cod_dw_direccion_fisica = rb.cod_dw_direccion_fisica
  WHERE m.scenario_code IN ('R2_ESC3_NIT', 'R2_ESC5_MOTOR', 'R2_ESC6_MOTOR')
    AND NOT EXISTS (
      SELECT 1
      FROM bdm_stage.relacion_persona_ubicacion r3
      WHERE r3.id_buro_persona = m.id_buro_persona
        AND r3.cod_dw_persona_ubic > m.id_buro_persona * 1000 + 2
    );

  INSERT INTO bdm_stage.direccion_fisica (
    cod_dw_direccion_fisica,
    complemento,
    cod_dw_ubic,
    tipo_via_principal,
    via_principal,
    via_generadora,
    numero_puerta,
    generada_enriquecida
  )
  SELECT
    cod_dw_direccion_fisica,
    complemento_motor,
    cod_dw_ubic,
    tipo_via_principal,
    via_principal,
    via_generadora,
    numero_puerta,
    1
  FROM bdm_tempo.stg_motor_insumo;

  INSERT INTO bdm_stage.relacion_persona_ubicacion (
    cod_dw_persona_ubic,
    id_buro_persona,
    cod_pin_persona,
    cod_dw_ubic,
    cod_dw_direccion_fisica,
    cod_dw_tipo_ubicacion_dir,
    ind_unificacion,
    orden_prioridad,
    fecha_relacion_persona_ubicaci,
    lote,
    cod_tipo_ident_fte
  )
  SELECT
    cod_dw_persona_ubic,
    id_buro_persona,
    cod_pin_persona,
    cod_dw_ubic,
    cod_dw_direccion_fisica,
    cod_dw_tipo_ubicacion_dir,
    NULL,
    3,
    fecha_relacion_persona_ubicaci,
    lote,
    cod_tipo_ident_fte
  FROM bdm_tempo.stg_motor_insumo;

  -- ==========================================================
  -- REGLA 3 — geolocalización (fixes QA TC-R3-01 / 08 / 10)
  -- ==========================================================

  CREATE TABLE bdm_tempo.stg_regla3_insumo
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  SORTKEY(id_buro_persona, tipo_via_principal, via_principal)
  AS
  SELECT
    rpu.cod_dw_persona_ubic,
    rpu.id_buro_persona,
    ubi.texto_ubicacion,
    df.complemento,
    UPPER(COALESCE(df.tipo_via_principal, SPLIT_PART(ubi.texto_ubicacion, ' ', 1))) AS tipo_via_principal,
    COALESCE(df.via_principal, SPLIT_PART(ubi.texto_ubicacion, ' ', 2)) AS via_principal,
    COALESCE(df.via_generadora, SPLIT_PART(ubi.texto_ubicacion, ' ', 3)) AS via_generadora,
    COALESCE(df.numero_puerta, SPLIT_PART(ubi.texto_ubicacion, ' ', 4)) AS numero_puerta,
    CAST(
      NULLIF(
        REGEXP_REPLACE(
          COALESCE(df.numero_puerta, SPLIT_PART(ubi.texto_ubicacion, ' ', 4)),
          '[^0-9]',
          ''
        ),
        ''
      ) AS INTEGER
    ) AS numero_puerta_num,
    ubi.cod_dw_ciudad AS cod_dw_municipio,
    ubi.latitud,
    ubi.longitud,
    COALESCE(cnt.numero_entidades_reportan, 0) AS numero_entidades_reportan,
    COALESCE(MAX(rep.fecha_reporte), DATE '1900-01-01') AS fecha_ultima_actualizacion
  FROM bdm_stage.relacion_persona_ubicacion rpu
  JOIN bdm_stage.ubicacion_estandarizada ubi
    ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  LEFT JOIN bdm_stage.direccion_fisica df
    ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
  LEFT JOIN bdm_stage.reporte_relacion_persona_ubica rep
    ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  LEFT JOIN (
    SELECT cod_dw_persona_ubic, COUNT(DISTINCT id_buro_suscriptor) AS numero_entidades_reportan
    FROM bdm_stage.reporte_relacion_persona_ubica
    GROUP BY 1
  ) cnt
    ON rpu.cod_dw_persona_ubic = cnt.cod_dw_persona_ubic
  WHERE rpu.ind_unificacion IS NULL
    AND UPPER(COALESCE(df.tipo_via_principal, SPLIT_PART(ubi.texto_ubicacion, ' ', 1)))
        NOT IN ('MZ', 'MN', 'RURAL', 'FINCA', 'FCA')
    AND UPPER(COALESCE(ubi.texto_ubicacion, '')) NOT LIKE 'RURAL %'
    AND ubi.texto_ubicacion !~ '[0-9]{1,3}[A-Z]{1,5}'
    AND CAST(
      NULLIF(
        REGEXP_REPLACE(
          COALESCE(df.numero_puerta, SPLIT_PART(ubi.texto_ubicacion, ' ', 4)),
          '[^0-9]',
          ''
        ),
        ''
      ) AS INTEGER
    ) IS NOT NULL
  GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13;

  CREATE TABLE bdm_tempo.stg_regla3_pares
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT T1.*, 1 AS id_u
  FROM bdm_tempo.stg_regla3_insumo T1
  JOIN bdm_tempo.stg_regla3_insumo T2
    ON T1.id_buro_persona = T2.id_buro_persona
   AND T1.cod_dw_municipio = T2.cod_dw_municipio
   AND T1.tipo_via_principal = T2.tipo_via_principal
   AND T1.via_principal = T2.via_principal
   AND T1.numero_puerta_num = T2.numero_puerta_num
   AND T1.via_generadora <> T2.via_generadora
   AND T1.cod_dw_persona_ubic <> T2.cod_dw_persona_ubic
  GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14

  UNION ALL

  SELECT T1.*, 2 AS id_u
  FROM bdm_tempo.stg_regla3_insumo T1
  JOIN bdm_tempo.stg_regla3_insumo T2
    ON T1.id_buro_persona = T2.id_buro_persona
   AND T1.cod_dw_municipio = T2.cod_dw_municipio
   AND T1.tipo_via_principal = T2.tipo_via_principal
   AND T1.via_principal = T2.via_principal
   AND T1.via_generadora = T2.via_generadora
   AND ABS(T1.numero_puerta_num - T2.numero_puerta_num) = 2
   AND T1.numero_puerta_num <> T2.numero_puerta_num
   AND T1.cod_dw_persona_ubic <> T2.cod_dw_persona_ubic
  GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14;

  CREATE TABLE bdm_tempo.stg_regla3_diccionario_via
  DISTSTYLE ALL
  AS
  SELECT
    'Via_Generadora' AS tipo,
    df.tipo_via_principal || ' ' || df.via_principal || ' ' || CAST(df.numero_puerta AS VARCHAR) AS llave,
    df.via_generadora,
    p.cod_dw_municipio,
    COUNT(rep.cod_dw_persona_ubic) AS conteo
  FROM bdm_stage.direccion_fisica df
  JOIN bdm_stage.ubicacion_estandarizada ue ON df.cod_dw_ubic = ue.cod_dw_ubic
  JOIN bdm_tempo.stg_regla3_pares p ON p.texto_ubicacion = ue.texto_ubicacion AND p.id_u = 1
  JOIN bdm_stage.relacion_persona_ubicacion rpu
    ON df.cod_dw_ubic = rpu.cod_dw_ubic AND df.cod_dw_direccion_fisica = rpu.cod_dw_direccion_fisica
  JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  GROUP BY 1, 2, 3, 4

  UNION ALL

  SELECT
    'Numero_Puerta' AS tipo,
    df.tipo_via_principal || ' ' || df.via_principal || ' ' || CAST(df.via_generadora AS VARCHAR) AS llave,
    df.numero_puerta AS via_generadora,
    p.cod_dw_municipio,
    COUNT(rep.cod_dw_persona_ubic) AS conteo
  FROM bdm_stage.direccion_fisica df
  JOIN bdm_stage.ubicacion_estandarizada ue ON df.cod_dw_ubic = ue.cod_dw_ubic
  JOIN bdm_tempo.stg_regla3_pares p ON p.texto_ubicacion = ue.texto_ubicacion AND p.id_u = 2
  JOIN bdm_stage.relacion_persona_ubicacion rpu
    ON df.cod_dw_ubic = rpu.cod_dw_ubic AND df.cod_dw_direccion_fisica = rpu.cod_dw_direccion_fisica
  JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  GROUP BY 1, 2, 3, 4;

  DELETE FROM bdm_stage.diccionario_via;
  INSERT INTO bdm_stage.diccionario_via SELECT * FROM bdm_tempo.stg_regla3_diccionario_via;

  CREATE TABLE bdm_tempo.stg_regla3_scored
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT
    v.*,
    CASE
      WHEN v.id_u = 1 THEN
        CASE WHEN NULLIF(v.latitud, 0) IS NOT NULL AND NULLIF(v.longitud, 0) IS NOT NULL
          THEN 100000000 + COALESCE(dvv.conteo, 0) ELSE 0 END
        + CASE WHEN NULLIF(v.latitud, 0) IS NULL OR NULLIF(v.longitud, 0) IS NULL
          THEN COALESCE(CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR), '-', '') AS BIGINT), 0) ELSE 0 END
        + COALESCE(v.numero_entidades_reportan, 0)
      WHEN v.id_u = 2 THEN
        CASE WHEN NULLIF(v.latitud, 0) IS NOT NULL AND NULLIF(v.longitud, 0) IS NOT NULL
          THEN 100000000 + COALESCE(dvp.conteo, 0) ELSE 0 END
        + CASE WHEN NULLIF(v.latitud, 0) IS NULL AND NULLIF(v.longitud, 0) IS NULL
          THEN COALESCE(CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR), '-', '') AS BIGINT), 0) ELSE 0 END
        + COALESCE(v.numero_entidades_reportan, 0)
      ELSE 0
    END AS id_unificacion
  FROM bdm_tempo.stg_regla3_pares v
  LEFT JOIN bdm_tempo.stg_regla3_diccionario_via dvv
    ON v.tipo_via_principal || ' ' || v.via_principal || ' ' || CAST(v.numero_puerta AS VARCHAR) = dvv.llave
   AND v.via_generadora = dvv.via_generadora
   AND v.cod_dw_municipio = dvv.cod_dw_municipio
   AND dvv.tipo = 'Via_Generadora'
  LEFT JOIN bdm_tempo.stg_regla3_diccionario_via dvp
    ON v.tipo_via_principal || ' ' || v.via_principal || ' ' || CAST(v.via_generadora AS VARCHAR) = dvp.llave
   AND CAST(v.numero_puerta AS VARCHAR) = CAST(dvp.via_generadora AS VARCHAR)
   AND dvp.tipo = 'Numero_Puerta';

  CREATE TABLE bdm_tempo.stg_regla3_ranked
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT
    s.*,
    MAX(s.id_unificacion) OVER (
      PARTITION BY s.id_buro_persona, s.cod_dw_municipio, s.tipo_via_principal, s.via_principal,
        CASE WHEN s.id_u = 1 THEN CAST(s.numero_puerta_num AS VARCHAR) END,
        CASE WHEN s.id_u = 2 THEN s.via_generadora END
    ) AS max_score_grupo
  FROM bdm_tempo.stg_regla3_scored s;

  CREATE TABLE bdm_tempo.stg_regla3_ganadores
  DISTSTYLE KEY DISTKEY(id_buro_persona)
  AS
  SELECT *
  FROM (
    SELECT
      r.*,
      SUM(CASE WHEN r.id_unificacion = r.max_score_grupo THEN 1 ELSE 0 END) OVER (
        PARTITION BY r.id_buro_persona, r.cod_dw_municipio, r.tipo_via_principal, r.via_principal,
          CASE WHEN r.id_u = 1 THEN CAST(r.numero_puerta_num AS VARCHAR) END,
          CASE WHEN r.id_u = 2 THEN r.via_generadora END
      ) AS cnt_en_max
    FROM bdm_tempo.stg_regla3_ranked r
    WHERE r.id_unificacion = r.max_score_grupo
  ) g
  WHERE g.cnt_en_max = 1;

  CREATE TABLE bdm_tempo.stg_regla3_resultado
  DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
  AS
  SELECT DISTINCT p.cod_dw_persona_ubic, g.cod_dw_persona_ubic AS cod_dw_direccion_unificada
  FROM bdm_tempo.stg_regla3_ganadores g
  JOIN bdm_tempo.stg_regla3_scored p
    ON g.id_buro_persona = p.id_buro_persona
   AND g.cod_dw_municipio = p.cod_dw_municipio
   AND g.tipo_via_principal = p.tipo_via_principal
   AND g.via_principal = p.via_principal
   AND g.id_u = 1 AND p.id_u = 1
   AND g.numero_puerta_num = p.numero_puerta_num
   AND g.via_generadora <> p.via_generadora
   AND p.id_unificacion < g.id_unificacion
   AND p.cod_dw_persona_ubic <> g.cod_dw_persona_ubic
  UNION ALL
  SELECT DISTINCT p.cod_dw_persona_ubic, g.cod_dw_persona_ubic AS cod_dw_direccion_unificada
  FROM bdm_tempo.stg_regla3_ganadores g
  JOIN bdm_tempo.stg_regla3_scored p
    ON g.id_buro_persona = p.id_buro_persona
   AND g.cod_dw_municipio = p.cod_dw_municipio
   AND g.tipo_via_principal = p.tipo_via_principal
   AND g.via_principal = p.via_principal
   AND g.id_u = 2 AND p.id_u = 2
   AND g.via_generadora = p.via_generadora
   AND p.numero_puerta_num <> g.numero_puerta_num
   AND p.id_unificacion < g.id_unificacion
   AND p.cod_dw_persona_ubic <> g.cod_dw_persona_ubic;

  INSERT INTO bdm_stage.unificacion_direccion
  SELECT DISTINCT
    cod_dw_persona_ubic,
    cod_dw_direccion_unificada,
    3,
    CURRENT_DATE,
    1,
    1,
    LEFT(CURRENT_USER, 30)
  FROM bdm_tempo.stg_regla3_resultado;

  UPDATE bdm_stage.relacion_persona_ubicacion
  SET ind_unificacion = 1
  WHERE cod_dw_persona_ubic IN (
    SELECT cod_dw_persona_ubic FROM bdm_tempo.stg_regla3_resultado
  );

  -- ==========================================================
  -- LIMPIEZA FINAL
  -- ==========================================================
  DROP TABLE IF EXISTS bdm_tempo.stg_regla1_insumo;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla1_scored;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla1_pares;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_insumo;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_esc1_pares;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e1;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_esc2_pares;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e2;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03_a;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03_e1;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_a;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_c1;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_e;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_a;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_pares;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_freq;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_pares;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_insumo;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_pares;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_diccionario_via;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_scored;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_ranked;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_ganadores;
  DROP TABLE IF EXISTS bdm_tempo.stg_regla3_resultado;

  -- ANALYZE requiere owner de la tabla; omitido en develop del cliente
  -- ANALYZE bdm_stage.unificacion_direccion;

