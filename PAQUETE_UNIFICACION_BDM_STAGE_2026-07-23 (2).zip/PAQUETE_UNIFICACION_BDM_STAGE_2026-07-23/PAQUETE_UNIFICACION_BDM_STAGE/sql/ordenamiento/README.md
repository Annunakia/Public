# Stored Procedures — Ordenamiento

SPs Redshift con las **reglas de scoring** de Public-main (`02_scoring_dir` … `06_consolidacion`).

## SPs

| SP | Equivalente Public-main | Canal / fase |
|----|---------------------------|--------------|
| `sp_ordenamiento_preparar_insumos` | mock 02b+03+04 | Pobla insumos desde `bdm_stage` |
| `sp_ordenamiento_scoring_dir` | `02_scoring_dir.sql` | DIR (12 características) |
| `sp_ordenamiento_scoring_tel` | `03_scoring_tel.sql` | TEL (11) |
| `sp_ordenamiento_scoring_cel` | `04_scoring_cel.sql` | CEL (11) |
| `sp_ordenamiento_scoring_ema` | `05_scoring_ema.sql` | EMA (13) |
| `sp_ordenamiento_consolidacion` | `06_consolidacion_persistencia.sql` | UPDATE `orden_prioridad` |
| `sp_ordenamiento_ejecucion` | Orquestador Control-M | Llama todos en secuencia |

## Deploy

```
01_schemas.sql + 02_mock_betas.sql   (ordenamiento_mock/)
10 → 16                              (este folder)
```

Regenerar desde Public-main cuando cambien las reglas:

```powershell
py tools/gen_ordenamiento_sps.py
```

## Prueba smoke (9 personas)

```sql
-- 1. Deploy SPs
-- 2. Cargar mock
\i sql/ordenamiento_mock/06_smoke_mock_9_personas.sql
-- 3. Ejecutar (insumos ya cargados)
CALL bdm_datos.sp_ordenamiento_ejecucion(FALSE);
-- 4. Validar
SELECT canal, COUNT(*), MIN(score), MAX(score) FROM bdm_datos.score_ordenamiento GROUP BY 1;
SELECT id_buro_persona, cod_dw_persona_ubic, orden_prioridad FROM bdm_datos.relacion_persona_ubicacion ORDER BY 1,3 LIMIT 30;
```

Esperado Kidar: ~15 filas en `score_ordenamiento`, `orden_prioridad` poblado.

## Mock alto 20K

Post-unificación en `bdm_stage`:

```sql
CALL bdm_datos.sp_ordenamiento_ejecucion(TRUE);
```

## Runner

```powershell
$env:REDSHIFT_PASSWORD="..."
py tools/ordenamiento_mock_run.py --smoke --deploy-sps
```
