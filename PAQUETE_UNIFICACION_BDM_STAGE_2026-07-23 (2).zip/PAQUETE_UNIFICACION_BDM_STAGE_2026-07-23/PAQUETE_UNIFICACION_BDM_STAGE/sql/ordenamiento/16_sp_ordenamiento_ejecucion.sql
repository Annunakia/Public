-- ============================================================
-- sp_ordenamiento_ejecucion.sql
-- Orquestador secuencial (Manuel / Control-M ORD_CU24.3 + P0027)
-- ============================================================

CREATE OR REPLACE PROCEDURE bdm_datos.sp_ordenamiento_ejecucion(
  p_preparar_insumos BOOLEAN
)
LANGUAGE plpgsql
AS $$
BEGIN
  IF p_preparar_insumos THEN
    CALL bdm_datos.sp_ordenamiento_preparar_insumos();
  END IF;

  CALL bdm_datos.sp_ordenamiento_scoring_dir();
  CALL bdm_datos.sp_ordenamiento_scoring_tel();
  CALL bdm_datos.sp_ordenamiento_scoring_cel();
  CALL bdm_datos.sp_ordenamiento_scoring_ema();
  CALL bdm_datos.sp_ordenamiento_consolidacion();
END;
$$;
