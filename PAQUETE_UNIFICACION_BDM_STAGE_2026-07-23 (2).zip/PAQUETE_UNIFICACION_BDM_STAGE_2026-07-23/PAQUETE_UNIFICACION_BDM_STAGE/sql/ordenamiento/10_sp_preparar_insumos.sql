-- ============================================================
-- sp_ordenamiento_preparar_insumos.sql
-- Pobla insumos DIR/TEL/CEL/EMA desde bdm_stage (post-unificación)
-- Equivalente mock: ordenamiento_mock/02b + 03 + 04
-- ============================================================

CREATE OR REPLACE PROCEDURE bdm_datos.sp_ordenamiento_preparar_insumos()
LANGUAGE plpgsql
AS $$
BEGIN
  TRUNCATE TABLE bdm_datos.relacion_persona_ubicacion;

  INSERT INTO bdm_datos.relacion_persona_ubicacion (
    cod_dw_persona_ubic, cod_pin_persona, id_buro_persona, cod_dw_ubic,
    orden_prioridad, fecha_relacion_persona_ubicaci, ind_unificacion
  )
  SELECT
    rpu.cod_dw_persona_ubic, rpu.cod_pin_persona, rpu.id_buro_persona, rpu.cod_dw_ubic,
    rpu.orden_prioridad, rpu.fecha_relacion_persona_ubicaci, rpu.ind_unificacion
  FROM bdm_stage.relacion_persona_ubicacion rpu
  WHERE COALESCE(rpu.ind_unificacion, 0) <> 1;

  TRUNCATE TABLE bdm_datos.insumo_direccion;

  INSERT INTO bdm_datos.insumo_direccion (
    cod_dw_persona_ubic, cod_pin_persona, id_buro_persona, direccion_fisica,
    complemento, tipo_ubicacion, cod_dane_ciudad, id_buro_suscriptor,
    fecha_reporte, meses_reporte, sector_financiero, conteo_direcciones
  )
  SELECT
    rpu.cod_dw_persona_ubic, rpu.cod_pin_persona, rpu.id_buro_persona,
    ubi.texto_ubicacion, df.complemento, tud.descripcion_tipo_ubicacion_dir,
    ubi.cod_dw_ciudad, rep.id_buro_suscriptor, rep.fecha_reporte,
    GREATEST(DATEDIFF(month, rep.fecha_reporte, CURRENT_DATE), 0),
    CASE WHEN rep.id_buro_suscriptor >= 901 THEN 1 ELSE 0 END,
    dir_cnt.conteo_direcciones
  FROM bdm_stage.relacion_persona_ubicacion rpu
  INNER JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
  INNER JOIN bdm_stage.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
  INNER JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  INNER JOIN (
    SELECT r2.id_buro_persona, COUNT(DISTINCT u2.texto_ubicacion) AS conteo_direcciones
    FROM bdm_stage.relacion_persona_ubicacion r2
    INNER JOIN bdm_stage.ubicacion_estandarizada u2 ON r2.cod_dw_ubic = u2.cod_dw_ubic
    WHERE COALESCE(r2.ind_unificacion, 0) <> 1
    GROUP BY 1
  ) dir_cnt ON dir_cnt.id_buro_persona = rpu.id_buro_persona
  WHERE COALESCE(rpu.ind_unificacion, 0) <> 1;

  TRUNCATE TABLE bdm_datos.insumo_telefono;

  INSERT INTO bdm_datos.insumo_telefono (
    cod_dw_persona_ubic, cod_pin_persona, id_buro_persona, direccion_fisica,
    cod_dane_ciudad, descripcion_gestion, id_buro_suscriptor, fecha_reporte,
    meses_reporte, coincidencia_geo, sector_financiero, tipo_cuenta
  )
  SELECT
    rpu.cod_dw_persona_ubic, rpu.cod_pin_persona, rpu.id_buro_persona, ubi.texto_ubicacion,
    ubi.cod_dw_ciudad,
    CASE WHEN MOD(rep.id_buro_suscriptor + rpu.cod_dw_persona_ubic, 10) = 0 THEN 'NO VALIDA' ELSE 'VALIDA' END,
    rep.id_buro_suscriptor, rep.fecha_reporte,
    GREATEST(DATEDIFF(month, rep.fecha_reporte, CURRENT_DATE), 0),
    CASE WHEN MOD(rpu.id_buro_persona, 3) = 0 THEN 1 ELSE 0 END,
    CASE WHEN rep.id_buro_suscriptor >= 901 THEN 1 ELSE 0 END,
    CASE WHEN MOD(rpu.id_buro_persona, 5) = 0 THEN 'MOVIL' ELSE 'FIJA' END
  FROM bdm_stage.relacion_persona_ubicacion rpu
  INNER JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  INNER JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  WHERE COALESCE(rpu.ind_unificacion, 0) <> 1;

  TRUNCATE TABLE bdm_datos.insumo_celular;

  INSERT INTO bdm_datos.insumo_celular (
    cod_dw_persona_ubic, cod_pin_persona, id_buro_persona, celular, texto_ubicacion,
    id_buro_suscriptor, fecha_reporte, meses_reporte, operador, sector_financiero, tipo_cuenta
  )
  WITH nums AS (SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3),
  rep_nums AS (SELECT 1 AS r UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5),
  winning AS (
    SELECT rpu.cod_dw_persona_ubic, rpu.cod_pin_persona, rpu.id_buro_persona, ubi.texto_ubicacion,
      ROW_NUMBER() OVER (PARTITION BY rpu.id_buro_persona ORDER BY rpu.cod_dw_persona_ubic) AS rpu_rank,
      COUNT(*) OVER (PARTITION BY rpu.id_buro_persona) AS rpu_cnt
    FROM bdm_stage.relacion_persona_ubicacion rpu
    INNER JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
    WHERE COALESCE(rpu.ind_unificacion, 0) <> 1
  ),
  contacts AS (
    SELECT w.*, n.n AS contact_n,
      CASE MOD(w.id_buro_persona + n.n, 4) WHEN 0 THEN '310' WHEN 1 THEN '320' WHEN 2 THEN '300' ELSE '315' END AS operador_prefix
    FROM winning w
    INNER JOIN nums n ON n.n <= 1 + MOD(w.id_buro_persona, 3)
    WHERE w.rpu_rank = MOD(n.n - 1, w.rpu_cnt) + 1
  )
  SELECT c.cod_dw_persona_ubic, c.cod_pin_persona, c.id_buro_persona,
    c.operador_prefix || RIGHT('0000000' || CAST(MOD(c.id_buro_persona * 10 + c.contact_n * 1000 + rn.r, 10000000) AS VARCHAR), 7),
    c.texto_ubicacion,
    900 + MOD(c.id_buro_persona + c.contact_n * 11 + rn.r, 50),
    DATEADD(month, -1 * GREATEST(MOD(c.id_buro_persona + c.contact_n * 7 + rn.r, 48) + 1, 1), CURRENT_DATE),
    GREATEST(MOD(c.id_buro_persona + c.contact_n * 7 + rn.r, 48) + 1, 1),
    c.operador_prefix,
    CASE WHEN MOD(c.id_buro_persona + rn.r, 3) <> 0 THEN 1 ELSE 0 END,
    CASE WHEN MOD(c.id_buro_persona + c.contact_n, 3) = 0 THEN 'POSPAGO' ELSE 'PREPAGO' END
  FROM contacts c
  INNER JOIN rep_nums rn ON rn.r <= 2 + MOD(c.id_buro_persona + c.contact_n, 4);

  TRUNCATE TABLE bdm_datos.insumo_email;

  INSERT INTO bdm_datos.insumo_email (
    cod_dw_persona_ubic, cod_pin_persona, id_buro_persona, email, dominio,
    id_buro_suscriptor, fecha_reporte, meses_reporte, sector_financiero, tipo_cuenta
  )
  WITH nums AS (SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3),
  rep_nums AS (SELECT 1 AS r UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5),
  winning AS (
    SELECT rpu.cod_dw_persona_ubic, rpu.cod_pin_persona, rpu.id_buro_persona,
      ROW_NUMBER() OVER (PARTITION BY rpu.id_buro_persona ORDER BY rpu.cod_dw_persona_ubic) AS rpu_rank,
      COUNT(*) OVER (PARTITION BY rpu.id_buro_persona) AS rpu_cnt
    FROM bdm_stage.relacion_persona_ubicacion rpu
    WHERE COALESCE(rpu.ind_unificacion, 0) <> 1
  ),
  contacts AS (
    SELECT w.cod_dw_persona_ubic, w.cod_pin_persona, w.id_buro_persona, n.n AS contact_n,
      CASE MOD(w.id_buro_persona + n.n, 5) WHEN 0 THEN 'gmail.com' WHEN 1 THEN 'hotmail.com'
        WHEN 2 THEN 'yahoo.com' WHEN 3 THEN 'outlook.com' ELSE 'empresa.co' END AS dominio
    FROM winning w
    INNER JOIN nums n ON n.n <= 1 + MOD(w.id_buro_persona, 3)
    WHERE w.rpu_rank = MOD(n.n - 1, w.rpu_cnt) + 1
  )
  SELECT c.cod_dw_persona_ubic, c.cod_pin_persona, c.id_buro_persona,
    'user' || CAST(MOD(c.id_buro_persona, 100000) AS VARCHAR) || '_' || CAST(c.contact_n AS VARCHAR) || '@' || c.dominio,
    c.dominio,
    900 + MOD(c.id_buro_persona + c.contact_n * 13 + rn.r, 50),
    DATEADD(month, -1 * GREATEST(MOD(c.id_buro_persona + c.contact_n * 5 + rn.r, 48) + 1, 1), CURRENT_DATE),
    GREATEST(MOD(c.id_buro_persona + c.contact_n * 5 + rn.r, 48) + 1, 1),
    CASE WHEN MOD(c.id_buro_persona + rn.r, 4) <> 0 THEN 1 ELSE 0 END,
    CASE WHEN c.dominio = 'empresa.co' THEN 'CORPORATIVO' ELSE 'PERSONAL' END
  FROM contacts c
  INNER JOIN rep_nums rn ON rn.r <= 2 + MOD(c.id_buro_persona + c.contact_n, 4);
END;
$$;
