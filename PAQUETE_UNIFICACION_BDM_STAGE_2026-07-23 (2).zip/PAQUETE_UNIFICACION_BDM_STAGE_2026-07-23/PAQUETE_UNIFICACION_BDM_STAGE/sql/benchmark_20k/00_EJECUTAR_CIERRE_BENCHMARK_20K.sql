-- ============================================================
-- 00_EJECUTAR_CIERRE_BENCHMARK_20K.sql
-- Orden para cerrar R1/R2/R3 con datos sinteticos (SPEC)
--
-- IMPORTANTE:
-- 1) Conexion Redshift sandbox / autorizado (A borra tablas bdm_stage)
-- 2) NO uses SQLite de ejemplo en DBeaver
-- 3) Ejecuta CADA archivo en orden (no este archivo como monolito:
--    Redshift/DBeaver mejor abrir cada script)
-- ============================================================

-- PASO 1 — Carga sintetica 20K
-- Abrir y ejecutar:
--   sql/benchmark_20k/A_data_load_sintetico.sql
-- Esperado al final:
--   personas = 20000 | rpu = 40000 | 22 scenario_code

-- PASO 2 — Unificacion (elige UNO)
-- Opcion plana:
--   sql/02_unificacion_sql_plano.sql
-- Opcion SPs:
--   sql/05_sp_regla1.sql
--   sql/06_sp_regla2.sql
--   sql/07_sp_regla3.sql
--   sql/08_ejecucion_secuencial.sql

-- PASO 3 — Revision resultados
--   sql/benchmark_20k/B_queries_tiempos_y_clasificacion.sql
-- Pegar aqui / enviar:
--   - absorciones por regla (8.2)
--   - por scenario_code (8.3)
--   - gate PASS/FAIL personas_20k / rpu_40k / escenarios_22

-- PASO 4 — Cleanup (opcional, al cerrar)
--   sql/benchmark_20k/C_cleanup_post_pruebas.sql

-- Check rapido post-PASO 1 (puedes pegarlo en DBeaver ahora):
SELECT 'personas' AS metric, COUNT(DISTINCT id_buro_persona) AS val
FROM bdm_stage.relacion_persona_ubicacion
UNION ALL
SELECT 'rpu_total', COUNT(*) FROM bdm_stage.relacion_persona_ubicacion
UNION ALL
SELECT 'escenarios', COUNT(DISTINCT scenario_code) FROM bdm_stage.perf_persona_meta;
