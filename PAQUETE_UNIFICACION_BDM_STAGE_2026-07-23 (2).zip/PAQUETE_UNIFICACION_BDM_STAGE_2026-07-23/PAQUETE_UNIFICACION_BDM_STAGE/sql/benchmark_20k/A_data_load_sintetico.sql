-- ============================================================
-- A_data_load_sintetico.sql
-- SPEC: SPEC_IA_DATOS_SINTETICOS_20K.md
-- Carga sintetica Benchmark 20K en bdm_stage (N=20000)
--
-- ADVERTENCIA: hace DROP+CREATE de tablas de negocio en bdm_stage.
-- NO ejecutar sobre datos reales de cliente sin backup / sandbox.
-- ============================================================

-- Schemas ya existen en develop; no crear (evita permission denied en dba_batch)
-- CREATE SCHEMA IF NOT EXISTS bdm_stage;
-- CREATE SCHEMA IF NOT EXISTS bdm_tempo;

-- ------------------------------------------------------------
-- Limpieza tablas de negocio / instrumentacion
-- ------------------------------------------------------------
DROP TABLE IF EXISTS bdm_stage.unificacion_direccion;
DROP TABLE IF EXISTS bdm_stage.relacion_persona_ubicacion;
DROP TABLE IF EXISTS bdm_stage.reporte_relacion_persona_ubica;
DROP TABLE IF EXISTS bdm_stage.ubicacion_estandarizada;
DROP TABLE IF EXISTS bdm_stage.direccion_fisica;
DROP TABLE IF EXISTS bdm_stage.ciiu_persona;
DROP TABLE IF EXISTS bdm_stage.tipo_ubicacion_dir;
DROP TABLE IF EXISTS bdm_stage.nomenclatura;
DROP TABLE IF EXISTS bdm_stage.diccionario_complementos;
DROP TABLE IF EXISTS bdm_stage.diccionario_via;
DROP TABLE IF EXISTS bdm_stage.relacion_ubicac_estandar_geo;
DROP TABLE IF EXISTS bdm_stage.bloqueo;
DROP TABLE IF EXISTS bdm_stage.perf_timings;
DROP TABLE IF EXISTS bdm_stage.perf_scenario_seed;
DROP TABLE IF EXISTS bdm_stage.perf_persona;
DROP TABLE IF EXISTS bdm_stage.perf_persona_meta;
DROP TABLE IF EXISTS bdm_stage.perf_digit;
DROP TABLE IF EXISTS bdm_stage.perf_nums;

-- ------------------------------------------------------------
-- Catalogos
-- ------------------------------------------------------------
CREATE TABLE bdm_stage.tipo_ubicacion_dir (
  cod_dw_tipo_ubicacion_dir INTEGER,
  descripcion_tipo_ubicacion_dir VARCHAR(20)
) DISTSTYLE ALL;

INSERT INTO bdm_stage.tipo_ubicacion_dir VALUES
  (1,'RES'),(2,'LAB'),(3,'CRR'),(4,'JUD'),(5,'CCL');

CREATE TABLE bdm_stage.nomenclatura (
  nomenclatura VARCHAR(10),
  nivel_complemento INTEGER
) DISTSTYLE ALL;

INSERT INTO bdm_stage.nomenclatura VALUES
  ('BR',1),('UR',1),('CJ',1),('UN',1),
  ('ED',2),('ZN',2),('SEC',2),
  ('MZ',3),('ET',3),
  ('TO',4),('BQ',4),
  ('PI',5),('CS',5),('IN',5),('BL',5),
  ('LC',6),('OF',6),('PL',6),
  ('AP',7),('GJ',7),('DP',7),('ST',7);

-- ------------------------------------------------------------
-- Tablas de negocio (DDL exacto SPEC §4)
-- ------------------------------------------------------------
CREATE TABLE bdm_stage.ubicacion_estandarizada (
  cod_dw_ubic BIGINT,
  texto_ubicacion VARCHAR(200),
  cod_dw_ciudad INTEGER,
  latitud DECIMAL(10,7),
  longitud DECIMAL(10,7)
) DISTSTYLE KEY DISTKEY(cod_dw_ubic) SORTKEY(cod_dw_ubic);

CREATE TABLE bdm_stage.direccion_fisica (
  cod_dw_direccion_fisica BIGINT,
  complemento VARCHAR(100),
  cod_dw_ubic BIGINT,
  tipo_via_principal VARCHAR(5),
  via_principal VARCHAR(10),
  via_generadora VARCHAR(10),
  numero_puerta VARCHAR(10),
  generada_enriquecida INTEGER
) DISTSTYLE KEY DISTKEY(cod_dw_direccion_fisica) SORTKEY(cod_dw_direccion_fisica);

CREATE TABLE bdm_stage.relacion_persona_ubicacion (
  cod_dw_persona_ubic BIGINT,
  id_buro_persona INTEGER,
  cod_pin_persona INTEGER,
  cod_dw_ubic BIGINT,
  cod_dw_direccion_fisica BIGINT,
  cod_dw_tipo_ubicacion_dir INTEGER,
  ind_unificacion INTEGER,
  orden_prioridad INTEGER,
  fecha_relacion_persona_ubicaci DATE,
  lote INTEGER,
  cod_tipo_ident_fte INTEGER
) DISTSTYLE KEY DISTKEY(id_buro_persona) SORTKEY(id_buro_persona, cod_dw_persona_ubic);

CREATE TABLE bdm_stage.ciiu_persona (
  id_buro_persona INTEGER,
  cod_act_econo_ciiu_fte VARCHAR(10)
) DISTSTYLE KEY DISTKEY(id_buro_persona);

CREATE TABLE bdm_stage.reporte_relacion_persona_ubica (
  cod_dw_persona_ubic BIGINT,
  id_buro_suscriptor INTEGER,
  fecha_reporte DATE,
  lote INTEGER
) DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic) SORTKEY(cod_dw_persona_ubic);

CREATE TABLE bdm_stage.unificacion_direccion (
  cod_dw_persona_ubic BIGINT,
  cod_dw_direccion_unificada BIGINT,
  unifica_atributos INTEGER,
  fecha_unificacion DATE,
  lote INTEGER,
  severidad INTEGER,
  usuario_bd VARCHAR(100)
) DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic) SORTKEY(cod_dw_persona_ubic);

CREATE TABLE bdm_stage.diccionario_complementos (
  cod_dw_ubic BIGINT,
  id_buro_persona INTEGER,
  nomenclatura VARCHAR(50),
  nomen VARCHAR(10),
  valor VARCHAR(50),
  frecuencia INTEGER
) DISTSTYLE KEY DISTKEY(cod_dw_ubic) SORTKEY(cod_dw_ubic, id_buro_persona);

CREATE TABLE bdm_stage.diccionario_via (
  tipo VARCHAR(20),
  llave VARCHAR(100),
  via_generadora VARCHAR(10),
  cod_dw_municipio INTEGER,
  conteo INTEGER
) DISTSTYLE ALL;

CREATE TABLE bdm_stage.relacion_ubicac_estandar_geo (
  cod_dw_ubic BIGINT,
  latitud DECIMAL(10,7),
  longitud DECIMAL(10,7)
);

CREATE TABLE bdm_stage.bloqueo (
  id_buro_persona INTEGER
);

-- ------------------------------------------------------------
-- Instrumentacion
-- ------------------------------------------------------------
CREATE TABLE bdm_stage.perf_timings (
  run_id VARCHAR(64),
  step_order INT,
  step_id VARCHAR(64),
  label VARCHAR(256),
  script_source VARCHAR(256),
  started_at TIMESTAMP,
  ended_at TIMESTAMP,
  duration_sec BIGINT,
  status VARCHAR(16)
);

CREATE TABLE bdm_stage.perf_scenario_seed (
  bucket_lo INT,
  bucket_hi INT,
  scenario_code VARCHAR(32),
  ciiu VARCHAR(10),
  tipo_a INT,
  tipo_b INT,
  comp_a VARCHAR(100),
  comp_b VARCHAR(100),
  same_ubic INT,
  tipo_via VARCHAR(5),
  via_base INT,
  gen_a INT,
  gen_b INT,
  puerta_a VARCHAR(10),
  puerta_b VARCHAR(10),
  lat_a DECIMAL(10,7),
  lon_a DECIMAL(10,7),
  lat_b DECIMAL(10,7),
  lon_b DECIMAL(10,7),
  nit_flag INT,
  hijo_a INT,
  rep_a INT,
  rep_b INT
);

-- Seed literal SPEC §5 (23 columnas; needs_dic se deriva por scenario_code)
INSERT INTO bdm_stage.perf_scenario_seed VALUES
(0,2,'R1_ESC1','10',1,2,'','',1,'CL',45,12,12,'33','33',NULL,NULL,NULL,NULL,1,0,2,5),
(3,4,'R1_ESC2','81',2,1,'','',1,'KR',7,80,80,'22','22',NULL,NULL,NULL,NULL,1,0,1,4),
(5,6,'R1_ESC3','55',1,3,'','',1,'AK',57,63,63,'45','45',NULL,NULL,NULL,NULL,1,0,2,6),
(7,8,'R1_EMPATE','10',2,3,'','',1,'KR',7,80,80,'22','22',NULL,NULL,NULL,NULL,1,0,3,3),
(9,11,'R1_HIJA','82',1,3,'','',1,'AK',57,63,63,'45','45',NULL,NULL,NULL,NULL,1,1,2,3),
(12,14,'R2_ESC1','10',1,1,'','AP 802',1,'DG',50,30,30,'10','10',NULL,NULL,NULL,NULL,1,0,2,3),
(15,17,'R2_ESC2','10',1,1,'AP 702','ED GALICIA AP 702',1,'TV',20,15,15,'40','40',NULL,NULL,NULL,NULL,1,0,2,4),
(18,20,'R2_ESC3_SIN_NIT','55',1,1,'AP 105','AP 404',1,'CL',22,27,27,'45','45',NULL,NULL,NULL,NULL,1,0,2,6),
(21,23,'R2_ESC4','10',1,1,'CS 5','PI 5',1,'CL',80,55,55,'18','18',NULL,NULL,NULL,NULL,1,0,3,2),
(24,29,'R2_EMPATE','10',1,1,'CS 8','PI 8',1,'CL',95,18,18,'42','42',NULL,NULL,NULL,NULL,1,0,2,2),
(30,32,'R2_ESC3_NIT','10',1,1,'LC 101','LC 205',1,'KR',10,20,20,'30','30',NULL,NULL,NULL,NULL,3,0,3,3),
(33,36,'R2_ESC5_MOTOR','10',1,1,'TO 3','AP 504',1,'KR',30,45,45,'12','12',NULL,NULL,NULL,NULL,1,0,2,3),
(37,39,'R2_ESC6_MOTOR','10',1,1,'ED 2 OF 301','OF 302',1,'DG',70,25,25,'88','88',NULL,NULL,NULL,NULL,1,0,3,2),
(40,42,'R2_ESC4_DIC','10',1,1,'CS 5','PI 5',1,'CL',80,55,55,'18','18',NULL,NULL,NULL,NULL,1,0,3,2),
(43,44,'R2_ESC5_DIC','10',1,1,'TO 5','PI 5',1,'CL',91,12,12,'34','34',NULL,NULL,NULL,NULL,1,0,3,2),
(45,47,'R2_ESC6_DIC','10',1,1,'LC 10 OF 200','OF 200',1,'KR',55,33,33,'22','22',NULL,NULL,NULL,NULL,1,0,4,2),
(48,50,'R3_GEO','10',1,1,'','',0,'CL',34,78,80,'52','52',4.6097100,-74.0817500,NULL,NULL,1,0,3,2),
(51,53,'R3_FECHA','10',1,1,'','',0,'KR',15,45,45,'33','35',NULL,NULL,NULL,NULL,1,0,2,4),
(54,56,'R3_DICC_VIA','10',1,1,'','',0,'TV',60,20,22,'44','44',4.6200000,-74.0900000,4.6201000,-74.0901000,1,0,3,8),
(57,59,'R3_FUERA','10',1,1,'','',0,'DG',90,10,10,'50','55',NULL,NULL,NULL,NULL,1,0,2,3),
(60,99,'CONTROL','10',1,1,'','',0,'CL',100,10,20,'30','40',NULL,NULL,NULL,NULL,1,0,1,1);

-- ------------------------------------------------------------
-- Paso A: numeros 1..N (N=20000)
-- ------------------------------------------------------------
CREATE TABLE bdm_stage.perf_digit (d INT);
INSERT INTO bdm_stage.perf_digit VALUES (0),(1),(2),(3),(4),(5),(6),(7),(8),(9);

CREATE TABLE bdm_stage.perf_nums AS
SELECT persona_seq
FROM (
  SELECT ROW_NUMBER() OVER (ORDER BY d1.d, d2.d, d3.d, d4.d, d5.d) AS persona_seq
  FROM bdm_stage.perf_digit d1
  CROSS JOIN bdm_stage.perf_digit d2
  CROSS JOIN bdm_stage.perf_digit d3
  CROSS JOIN bdm_stage.perf_digit d4
  CROSS JOIN bdm_stage.perf_digit d5
) s
WHERE persona_seq <= 20000;

-- ------------------------------------------------------------
-- Paso B: perf_persona
-- ------------------------------------------------------------
CREATE TABLE bdm_stage.perf_persona AS
SELECT
  n.persona_seq,
  (100000 + n.persona_seq) AS id_buro_persona,
  (900000 + n.persona_seq) AS cod_pin_persona,
  (n.persona_seq % 100) AS bucket,
  s.scenario_code,
  s.ciiu,
  s.tipo_a,
  s.tipo_b,
  s.comp_a,
  s.comp_b,
  s.same_ubic,
  s.tipo_via,
  s.via_base,
  (s.via_base + (n.persona_seq % 500)) AS via_num,
  CAST(s.gen_a AS VARCHAR(10)) AS gen_a,
  CAST(s.gen_b AS VARCHAR(10)) AS gen_b,
  s.puerta_a,
  s.puerta_b,
  s.lat_a,
  s.lon_a,
  s.lat_b,
  s.lon_b,
  s.nit_flag,
  s.hijo_a,
  s.rep_a,
  s.rep_b,
  (100000 + n.persona_seq) * 1000 + 1 AS ubic_a,
  (100000 + n.persona_seq) * 1000 + 2 AS ubic_b,
  (100000 + n.persona_seq) * 1000 + 101 AS dir_a,
  (100000 + n.persona_seq) * 1000 + 102 AS dir_b,
  (100000 + n.persona_seq) * 1000 + 1 AS rpu_a,
  (100000 + n.persona_seq) * 1000 + 2 AS rpu_b
FROM bdm_stage.perf_nums n
JOIN bdm_stage.perf_scenario_seed s
  ON (n.persona_seq % 100) BETWEEN s.bucket_lo AND s.bucket_hi;

-- ------------------------------------------------------------
-- Paso C: ubicacion_estandarizada (2 por persona)
-- ------------------------------------------------------------
INSERT INTO bdm_stage.ubicacion_estandarizada (cod_dw_ubic, texto_ubicacion, cod_dw_ciudad, latitud, longitud)
SELECT
  p.ubic_a,
  p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR(10)) || ' ' || p.gen_a || ' ' || p.puerta_a,
  1,
  p.lat_a,
  p.lon_a
FROM bdm_stage.perf_persona p;

INSERT INTO bdm_stage.ubicacion_estandarizada (cod_dw_ubic, texto_ubicacion, cod_dw_ciudad, latitud, longitud)
SELECT
  p.ubic_b,
  CASE
    WHEN p.scenario_code = 'CONTROL' THEN
      p.tipo_via || ' ' || CAST(p.via_num + 50 AS VARCHAR(10)) || ' ' || p.gen_b || ' ' || p.puerta_b
    WHEN p.same_ubic = 1 THEN
      p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR(10)) || ' ' || p.gen_a || ' ' || p.puerta_a
    WHEN p.scenario_code LIKE 'R3_%' THEN
      p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR(10)) || ' ' || p.gen_b || ' ' || p.puerta_b
    ELSE
      p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR(10)) || ' ' || p.gen_a || ' ' || p.puerta_a
  END,
  1,
  p.lat_b,
  p.lon_b
FROM bdm_stage.perf_persona p;

-- ------------------------------------------------------------
-- Paso D: direccion_fisica
-- ------------------------------------------------------------
INSERT INTO bdm_stage.direccion_fisica (
  cod_dw_direccion_fisica, complemento, cod_dw_ubic,
  tipo_via_principal, via_principal, via_generadora, numero_puerta, generada_enriquecida
)
SELECT
  p.dir_a,
  NULLIF(p.comp_a, ''),
  p.ubic_a,
  p.tipo_via,
  CAST(p.via_num AS VARCHAR(10)),
  p.gen_a,
  p.puerta_a,
  NULL
FROM bdm_stage.perf_persona p;

INSERT INTO bdm_stage.direccion_fisica (
  cod_dw_direccion_fisica, complemento, cod_dw_ubic,
  tipo_via_principal, via_principal, via_generadora, numero_puerta, generada_enriquecida
)
SELECT
  p.dir_b,
  NULLIF(p.comp_b, ''),
  CASE WHEN p.same_ubic = 1 THEN p.ubic_a ELSE p.ubic_b END,
  p.tipo_via,
  CASE
    WHEN p.scenario_code = 'CONTROL' THEN CAST(p.via_num + 50 AS VARCHAR(10))
    ELSE CAST(p.via_num AS VARCHAR(10))
  END,
  CASE WHEN p.same_ubic = 1 THEN p.gen_a ELSE p.gen_b END,
  CASE WHEN p.same_ubic = 1 THEN p.puerta_a ELSE p.puerta_b END,
  NULL
FROM bdm_stage.perf_persona p;

-- ------------------------------------------------------------
-- Paso E: ciiu_persona
-- ------------------------------------------------------------
INSERT INTO bdm_stage.ciiu_persona (id_buro_persona, cod_act_econo_ciiu_fte)
SELECT id_buro_persona, ciiu FROM bdm_stage.perf_persona;

-- ------------------------------------------------------------
-- Paso F: relacion_persona_ubicacion (2 RPU)
-- ------------------------------------------------------------
INSERT INTO bdm_stage.relacion_persona_ubicacion (
  cod_dw_persona_ubic, id_buro_persona, cod_pin_persona,
  cod_dw_ubic, cod_dw_direccion_fisica, cod_dw_tipo_ubicacion_dir,
  ind_unificacion, orden_prioridad, fecha_relacion_persona_ubicaci,
  lote, cod_tipo_ident_fte
)
SELECT
  p.rpu_a,
  p.id_buro_persona,
  p.cod_pin_persona,
  p.ubic_a,
  p.dir_a,
  p.tipo_a,
  CASE WHEN p.hijo_a = 1 THEN 1 ELSE NULL END,
  1,
  DATEADD(day, -(p.persona_seq % 30), DATE '2025-06-01'),
  1,
  p.nit_flag
FROM bdm_stage.perf_persona p;

INSERT INTO bdm_stage.relacion_persona_ubicacion (
  cod_dw_persona_ubic, id_buro_persona, cod_pin_persona,
  cod_dw_ubic, cod_dw_direccion_fisica, cod_dw_tipo_ubicacion_dir,
  ind_unificacion, orden_prioridad, fecha_relacion_persona_ubicaci,
  lote, cod_tipo_ident_fte
)
SELECT
  p.rpu_b,
  p.id_buro_persona,
  p.cod_pin_persona,
  CASE WHEN p.same_ubic = 1 THEN p.ubic_a ELSE p.ubic_b END,
  p.dir_b,
  p.tipo_b,
  NULL,
  2,
  DATEADD(day, (p.persona_seq % 60), DATE '2025-03-01'),
  1,
  p.nit_flag
FROM bdm_stage.perf_persona p;

-- ------------------------------------------------------------
-- Paso G: reportes
-- ------------------------------------------------------------
CREATE TABLE bdm_stage.perf_rep_n AS
SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4
UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8;

INSERT INTO bdm_stage.reporte_relacion_persona_ubica (cod_dw_persona_ubic, id_buro_suscriptor, fecha_reporte, lote)
SELECT
  p.rpu_a,
  900 + (n.n % 20),
  DATE '2025-05-01',
  1
FROM bdm_stage.perf_persona p
JOIN bdm_stage.perf_rep_n n ON n.n <= p.rep_a;

INSERT INTO bdm_stage.reporte_relacion_persona_ubica (cod_dw_persona_ubic, id_buro_suscriptor, fecha_reporte, lote)
SELECT
  p.rpu_b,
  900 + (n.n % 20),
  DATE '2025-06-01',
  1
FROM bdm_stage.perf_persona p
JOIN bdm_stage.perf_rep_n n ON n.n <= p.rep_b;

-- Extra R3_DICC_VIA sobre RPU A
INSERT INTO bdm_stage.reporte_relacion_persona_ubica (cod_dw_persona_ubic, id_buro_suscriptor, fecha_reporte, lote)
SELECT
  p.rpu_a,
  910 + n.n,
  DATE '2025-05-15',
  1
FROM bdm_stage.perf_persona p
JOIN bdm_stage.perf_rep_n n ON n.n IN (1, 2, 3)
WHERE p.scenario_code = 'R3_DICC_VIA';

-- ------------------------------------------------------------
-- Paso H: diccionario_complementos (por scenario_code)
-- ------------------------------------------------------------
INSERT INTO bdm_stage.diccionario_complementos (cod_dw_ubic, id_buro_persona, nomenclatura, nomen, valor, frecuencia)
SELECT p.ubic_a, p.id_buro_persona, 'CS 5', 'CS', '5', 10 FROM bdm_stage.perf_persona p WHERE p.scenario_code IN ('R2_ESC4','R2_ESC4_DIC')
UNION ALL
SELECT p.ubic_a, p.id_buro_persona, 'PI 5', 'PI', '5', 4 FROM bdm_stage.perf_persona p WHERE p.scenario_code IN ('R2_ESC4','R2_ESC4_DIC')
UNION ALL
SELECT p.ubic_a, p.id_buro_persona, 'LC 101', 'LC', '101', 8 FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC3_NIT'
UNION ALL
SELECT p.ubic_a, p.id_buro_persona, 'LC 205', 'LC', '205', 4 FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC3_NIT'
UNION ALL
SELECT p.ubic_a, p.id_buro_persona, 'TO 3', 'TO', '3', 8 FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC5_MOTOR'
UNION ALL
SELECT p.ubic_a, p.id_buro_persona, 'AP 504', 'AP', '504', 4 FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC5_MOTOR'
UNION ALL
SELECT p.ubic_a, p.id_buro_persona, 'ED 2 OF 301', 'ED', '2', 6 FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC6_MOTOR'
UNION ALL
SELECT p.ubic_a, p.id_buro_persona, 'ED 2 OF 301', 'OF', '301', 4 FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC6_MOTOR'
UNION ALL
SELECT p.ubic_a, p.id_buro_persona, 'OF 302', 'OF', '302', 4 FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC6_MOTOR'
UNION ALL
SELECT p.ubic_a, p.id_buro_persona, 'TO 5', 'TO', '5', 15 FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC5_DIC'
UNION ALL
SELECT p.ubic_a, p.id_buro_persona, 'PI 5', 'PI', '5', 6 FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC5_DIC'
UNION ALL
SELECT p.ubic_a, p.id_buro_persona, 'LC 10', 'LC', '10', 20 FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC6_DIC'
UNION ALL
SELECT p.ubic_a, p.id_buro_persona, 'OF 200', 'OF', '200', 8 FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC6_DIC'
UNION ALL
SELECT p.ubic_a, p.id_buro_persona, 'CS 8', 'CS', '8', 10 FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_EMPATE'
UNION ALL
SELECT p.ubic_a, p.id_buro_persona, 'PI 8', 'PI', '8', 10 FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_EMPATE';

-- ------------------------------------------------------------
-- Paso I: perf_persona_meta
-- ------------------------------------------------------------
CREATE TABLE bdm_stage.perf_persona_meta AS
SELECT id_buro_persona, persona_seq, scenario_code
FROM bdm_stage.perf_persona;

-- ------------------------------------------------------------
-- Paso J: diccionario_via (solo R3_DICC_VIA)
-- ------------------------------------------------------------
INSERT INTO bdm_stage.diccionario_via (tipo, llave, via_generadora, cod_dw_municipio, conteo)
SELECT
  'Via_Generadora',
  p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR(10)) || ' ' || p.puerta_a,
  p.gen_a,
  1,
  15
FROM bdm_stage.perf_persona p
WHERE p.scenario_code = 'R3_DICC_VIA'
UNION ALL
SELECT
  'Via_Generadora',
  p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR(10)) || ' ' || p.puerta_a,
  p.gen_b,
  1,
  8
FROM bdm_stage.perf_persona p
WHERE p.scenario_code = 'R3_DICC_VIA';

-- ------------------------------------------------------------
-- Paso K: auxiliares / checks
-- ------------------------------------------------------------
DROP TABLE IF EXISTS bdm_stage.perf_digit;
DROP TABLE IF EXISTS bdm_stage.perf_nums;
DROP TABLE IF EXISTS bdm_stage.perf_rep_n;
-- Se mantiene perf_persona y perf_persona_meta para validacion

-- Checks post-carga esperados @20K
SELECT 'personas' AS metric, COUNT(DISTINCT id_buro_persona) AS val
FROM bdm_stage.relacion_persona_ubicacion
UNION ALL
SELECT 'rpu_total', COUNT(*) FROM bdm_stage.relacion_persona_ubicacion
UNION ALL
SELECT 'ubicaciones', COUNT(*) FROM bdm_stage.ubicacion_estandarizada
UNION ALL
SELECT 'dir_fisica', COUNT(*) FROM bdm_stage.direccion_fisica;

SELECT scenario_code, COUNT(*) AS personas
FROM bdm_stage.perf_persona_meta
GROUP BY 1
ORDER BY 1;

-- PERF: marcar DATA_LOAD (opcional; si no hay permiso ANALYZE, omitir)
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at, ended_at, duration_sec, status)
VALUES (
  'benchmark_20k_batch_v1', 1, 'DATA_LOAD', 'Carga 20000 personas',
  'A_data_load_sintetico.sql', GETDATE(), GETDATE(), 0, 'OK'
);
