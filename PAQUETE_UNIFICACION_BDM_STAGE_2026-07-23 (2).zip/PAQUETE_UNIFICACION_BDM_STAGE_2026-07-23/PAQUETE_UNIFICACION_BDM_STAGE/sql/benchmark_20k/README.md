# Benchmark 20K — cierre SP Regla 1 / 2 / 3

Spec canónica: `Documentacion/SPEC_IA_DATOS_SINTETICOS_20K.md`

## Orden de ejecución

| Paso | Script | Qué hace |
|------|--------|----------|
| 1 | `A_data_load_sintetico.sql` | DROP+CREATE + carga sintética N=20000 (22 escenarios) |
| 2 | `../02_unificacion_sql_plano.sql` **o** `05→06→07` + `08` | Ejecuta unificación R1/R2/R3 |
| 3 | `B_queries_tiempos_y_clasificacion.sql` | Tiempos + clasificación por `scenario_code` |
| 4 | `C_cleanup_post_pruebas.sql` | Limpia mock/staging (opcional) |

## Advertencia

`A` y `C` **borran** tablas de negocio en `bdm_stage`.  
Usar en **sandbox** o solo si está autorizado reemplazar datos de develop.

## Checks post-carga (A)

- Personas: **20000**
- RPU: **40000**
- Escenarios en `perf_persona_meta`: **22**

## Nota sobre el pipeline completo

La SPEC describe también motor batch (Esc3 NIT / Esc5 / Esc6) y hitos de `perf_timings`.  
Los SPs actuales del paquete (`05`–`07`) cubren la lógica plana R1/R2/R3; el motor unificado completo puede requerir scripts adicionales del repo Benchmark_20K.
