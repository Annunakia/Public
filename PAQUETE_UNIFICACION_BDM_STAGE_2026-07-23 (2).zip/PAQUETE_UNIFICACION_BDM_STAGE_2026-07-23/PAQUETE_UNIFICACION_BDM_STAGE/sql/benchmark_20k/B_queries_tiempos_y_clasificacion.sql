-- ============================================================
-- B_queries_tiempos_y_clasificacion.sql
-- SPEC §§7–8 — Solo lectura / medicion post-pipeline
-- Precondicion: A_data_load + ejecucion R1/R2/R3 (02 o SPs)
-- ============================================================

-- ============================================================
-- 7.3 Tiempos (si se instrumentaron hitos en perf_timings)
-- ============================================================
SELECT step_order, step_id, label, duration_sec, started_at, ended_at, status, script_source
FROM bdm_stage.perf_timings
WHERE run_id = 'benchmark_20k_batch_v1'
ORDER BY step_order;

SELECT SUM(duration_sec) AS e2e_sec
FROM bdm_stage.perf_timings
WHERE run_id = 'benchmark_20k_batch_v1' AND status = 'OK';

SELECT step_id, duration_sec
FROM bdm_stage.perf_timings
WHERE run_id = 'benchmark_20k_batch_v1'
  AND step_id NOT IN ('DATA_LOAD','VALIDATION')
ORDER BY step_order;

SELECT
  CASE
    WHEN step_id = 'R1' THEN 'R1'
    WHEN step_id LIKE 'R2%' THEN 'R2'
    WHEN step_id = 'R3' THEN 'R3'
    ELSE 'OTRO'
  END AS familia,
  SUM(duration_sec) AS sec
FROM bdm_stage.perf_timings
WHERE run_id = 'benchmark_20k_batch_v1' AND status = 'OK'
GROUP BY 1
ORDER BY 1;

-- ============================================================
-- 8.1 Contadores globales
-- ============================================================
SELECT 'personas' AS metric, COUNT(DISTINCT id_buro_persona) AS val
FROM bdm_stage.relacion_persona_ubicacion
UNION ALL SELECT 'rpu_total', COUNT(*) FROM bdm_stage.relacion_persona_ubicacion
UNION ALL SELECT 'rpu_vigentes', COUNT(*) FROM bdm_stage.relacion_persona_ubicacion WHERE ind_unificacion IS NULL
UNION ALL SELECT 'rpu_hijas', COUNT(*) FROM bdm_stage.relacion_persona_ubicacion WHERE ind_unificacion = 1
UNION ALL SELECT 'unificaciones', COUNT(*) FROM bdm_stage.unificacion_direccion
UNION ALL SELECT 'generada_enriquecida', COUNT(*) FROM bdm_stage.direccion_fisica WHERE generada_enriquecida = 1;

-- ============================================================
-- 8.2 Absorciones por regla
-- ============================================================
SELECT unifica_atributos AS regla, COUNT(*) AS absorciones
FROM bdm_stage.unificacion_direccion
GROUP BY 1
ORDER BY 1;

-- ============================================================
-- 8.3 Por scenario_code
-- ============================================================
SELECT m.scenario_code,
  COUNT(DISTINCT m.id_buro_persona) AS personas,
  SUM(CASE WHEN u.cod_dw_persona_ubic IS NOT NULL THEN 1 ELSE 0 END) AS rpu_en_log_unificacion
FROM bdm_stage.perf_persona_meta m
LEFT JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
LEFT JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic
GROUP BY 1
ORDER BY 1;

-- ============================================================
-- 8.4 Por regla x escenario
-- ============================================================
SELECT m.scenario_code, u.unifica_atributos AS regla, COUNT(*) AS absorciones
FROM bdm_stage.perf_persona_meta m
JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic
GROUP BY 1, 2
ORDER BY 1, 2;

-- ============================================================
-- 8.5 Muestra roles por escenario (ej. R2_ESC1)
-- ============================================================
SELECT
  m.scenario_code,
  r.id_buro_persona,
  r.cod_dw_persona_ubic AS rpu,
  CASE
    WHEN r.ind_unificacion = 1 THEN 'HIJO'
    WHEN EXISTS (
      SELECT 1 FROM bdm_stage.unificacion_direccion u
      WHERE u.cod_dw_direccion_unificada = r.cod_dw_persona_ubic
    ) THEN 'PADRE'
    ELSE 'VIGENTE_SIN_HIJOS'
  END AS rol,
  u.cod_dw_direccion_unificada AS apunta_a_padre,
  u.unifica_atributos AS regla
FROM bdm_stage.perf_persona_meta m
JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
LEFT JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic
WHERE m.scenario_code = 'R2_ESC1'
ORDER BY r.id_buro_persona, r.cod_dw_persona_ubic
LIMIT 100;

-- ============================================================
-- 8.6 Detalle hijo -> padre (primer R1_ESC1)
-- ============================================================
SELECT
  hijo.id_buro_persona AS persona,
  hijo.cod_dw_persona_ubic AS rpu_hijo,
  padre.cod_dw_persona_ubic AS rpu_padre,
  u.unifica_atributos AS regla,
  m.scenario_code
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion hijo ON u.cod_dw_persona_ubic = hijo.cod_dw_persona_ubic
JOIN bdm_stage.relacion_persona_ubicacion padre ON u.cod_dw_direccion_unificada = padre.cod_dw_persona_ubic
JOIN bdm_stage.perf_persona_meta m ON m.id_buro_persona = hijo.id_buro_persona
WHERE hijo.id_buro_persona = 100001;

-- ============================================================
-- 8.7 Escenarios motor (~3 RPU/persona post-run completo)
-- ============================================================
SELECT m.scenario_code,
  COUNT(DISTINCT m.id_buro_persona) AS personas,
  COUNT(r.cod_dw_persona_ubic) AS rpu
FROM bdm_stage.perf_persona_meta m
LEFT JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
WHERE m.scenario_code IN ('R2_ESC3_NIT','R2_ESC5_MOTOR','R2_ESC6_MOTOR')
GROUP BY 1
ORDER BY 1;

-- ============================================================
-- 8.8 Escenarios que NO deben unificar
-- ============================================================
SELECT m.scenario_code, COUNT(u.cod_dw_persona_ubic) AS absorciones_inesperadas
FROM bdm_stage.perf_persona_meta m
LEFT JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
LEFT JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic
WHERE m.scenario_code IN ('R1_EMPATE','R1_HIJA','R2_EMPATE','R3_FUERA','CONTROL')
GROUP BY 1
ORDER BY 1;

-- ============================================================
-- 8.9 Invariantes (violaciones -> 0)
-- ============================================================
SELECT COUNT(*) AS violaciones_padre_hijo
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r
  ON r.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
WHERE r.ind_unificacion = 1;

SELECT COUNT(*) AS violaciones_control
FROM (
  SELECT m.id_buro_persona
  FROM bdm_stage.perf_persona_meta m
  LEFT JOIN bdm_stage.relacion_persona_ubicacion r
    ON r.id_buro_persona = m.id_buro_persona AND r.ind_unificacion IS NULL
  WHERE m.scenario_code = 'CONTROL'
  GROUP BY m.id_buro_persona
  HAVING COUNT(r.cod_dw_persona_ubic) <> 2
) t;

-- ============================================================
-- Gate rapido PASS/FAIL (carga sintetica)
-- ============================================================
SELECT
  CASE WHEN (SELECT COUNT(DISTINCT id_buro_persona) FROM bdm_stage.relacion_persona_ubicacion) = 20000
       THEN 'PASS' ELSE 'FAIL' END AS personas_20k,
  CASE WHEN (SELECT COUNT(*) FROM bdm_stage.relacion_persona_ubicacion) = 40000
       THEN 'PASS' ELSE 'FAIL' END AS rpu_40k,
  CASE WHEN (SELECT COUNT(DISTINCT scenario_code) FROM bdm_stage.perf_persona_meta) = 21
       THEN 'PASS' ELSE 'FAIL' END AS escenarios_21;
-- Nota: la SPEC habla de "22", pero el seed §5 tiene 21 scenario_code distintos.
