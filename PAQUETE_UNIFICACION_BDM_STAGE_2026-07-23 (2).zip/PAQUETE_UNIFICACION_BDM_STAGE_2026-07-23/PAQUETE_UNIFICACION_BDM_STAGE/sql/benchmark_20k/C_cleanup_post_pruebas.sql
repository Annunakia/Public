-- ============================================================
-- C_cleanup_post_pruebas.sql
-- SPEC §9 — Liberar staging + mock + instrumentacion
-- NO hace DROP SCHEMA bdm_stage
-- ============================================================

-- Staging R1 (paquete usa bdm_tempo; SPEC tambien menciona bdm_stage)
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_insumo;
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_scored;
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_pares;
DROP TABLE IF EXISTS bdm_stage.stg_regla1_insumo;
DROP TABLE IF EXISTS bdm_stage.stg_regla1_scored;
DROP TABLE IF EXISTS bdm_stage.stg_regla1_pares;

-- Staging R2
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_insumo;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_esc1_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e1;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_esc2_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e2;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03_a;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03_e1;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_a;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_c1;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_e;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_a;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_freq;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_pares;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_insumo;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_esc1_pares;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e1;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_esc2_pares;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e2;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_a;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_c;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_d;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e031;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_nit_pares;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub1;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_e;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_a;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_c;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub1;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub2;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_e;

-- Motor
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
DROP TABLE IF EXISTS bdm_stage.stg_motor_descomp;
DROP TABLE IF EXISTS bdm_stage.stg_motor_mdir;
DROP TABLE IF EXISTS bdm_stage.stg_motor_pares;
DROP TABLE IF EXISTS bdm_stage.stg_motor_resultado;
DROP TABLE IF EXISTS bdm_stage.stg_motor_final;
DROP TABLE IF EXISTS bdm_stage.stg_motor_max_ids;

-- Staging R3
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_insumo;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_pares;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_insumo;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_pares;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_diccionario_via;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_scored;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_resultado;

-- Instrumentacion / seed
DROP TABLE IF EXISTS bdm_stage.perf_timings;
DROP TABLE IF EXISTS bdm_stage.perf_scenario_seed;
DROP TABLE IF EXISTS bdm_stage.perf_persona;
DROP TABLE IF EXISTS bdm_stage.perf_persona_meta;
DROP TABLE IF EXISTS bdm_stage.perf_digit;
DROP TABLE IF EXISTS bdm_stage.perf_nums;
DROP TABLE IF EXISTS bdm_stage.perf_rep_n;

-- Tablas de negocio mock
DROP TABLE IF EXISTS bdm_stage.unificacion_direccion;
DROP TABLE IF EXISTS bdm_stage.relacion_persona_ubicacion;
DROP TABLE IF EXISTS bdm_stage.reporte_relacion_persona_ubica;
DROP TABLE IF EXISTS bdm_stage.ubicacion_estandarizada;
DROP TABLE IF EXISTS bdm_stage.direccion_fisica;
DROP TABLE IF EXISTS bdm_stage.ciiu_persona;
DROP TABLE IF EXISTS bdm_stage.tipo_ubicacion_dir;
DROP TABLE IF EXISTS bdm_stage.nomenclatura;
DROP TABLE IF EXISTS bdm_stage.diccionario_complementos;
DROP TABLE IF EXISTS bdm_stage.diccionario_via;
DROP TABLE IF EXISTS bdm_stage.relacion_ubicac_estandar_geo;
DROP TABLE IF EXISTS bdm_stage.bloqueo;

-- NO: DROP SCHEMA bdm_stage;
