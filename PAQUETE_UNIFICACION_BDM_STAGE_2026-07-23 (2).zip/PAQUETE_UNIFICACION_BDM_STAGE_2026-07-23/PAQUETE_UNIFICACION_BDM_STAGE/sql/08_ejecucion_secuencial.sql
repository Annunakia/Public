-- ============================================================
-- 08_ejecucion_secuencial.sql
-- Orquesta la unificacion via SPs (Regla 1 -> 2 -> 3).
--
-- Precondiciones:
-- 1. Fuentes disponibles en bdm_stage (en sandbox: correr 01 primero)
-- 2. Desplegar 05_sp_regla1.sql, 06_sp_regla2.sql, 07_sp_regla3.sql
-- 3. Este script hace TRUNCATE de bdm_stage.unificacion_direccion
-- ============================================================

-- Reinicia la tabla de salida antes de la corrida secuencial
TRUNCATE TABLE bdm_stage.unificacion_direccion;

CALL bdm_stage.sp_unificacion_regla1();
CALL bdm_stage.sp_unificacion_regla2();
CALL bdm_stage.sp_unificacion_regla3();

-- ANALYZE requiere owner de la tabla; omitido en develop del cliente
-- ANALYZE bdm_stage.unificacion_direccion;
