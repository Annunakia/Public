-- ============================================================
-- 00_validar_solo_lectura_ifr_data.sql  (DEV datasharing)
-- Solo SELECT sobre db_ifr_shared.ifr_data (misma cadena que QA)
-- ============================================================

SELECT paso, total FROM (

  SELECT '01_db_ifr_shared.ifr_data.xpm' AS paso, COUNT(*)::BIGINT AS total
  FROM db_ifr_shared.ifr_data.xpm

  UNION ALL SELECT '02_db_ifr_shared.ifr_data.xpm_location', COUNT(*)
  FROM db_ifr_shared.ifr_data.xpm_location

  UNION ALL SELECT '03_db_ifr_shared.ifr_data.xpm_location_val_contactinformations', COUNT(*)
  FROM db_ifr_shared.ifr_data.xpm_location_val_contactinformations

  UNION ALL SELECT '04_db_ifr_shared.ifr_data.xpm_counterparties', COUNT(*)
  FROM db_ifr_shared.ifr_data.xpm_counterparties

  UNION ALL
  SELECT '05_xpm_con_location_match', COUNT(*)
  FROM db_ifr_shared.ifr_data.xpm xpm
  JOIN db_ifr_shared.ifr_data.xpm_location loc
    ON xpm.location = loc.id
   AND xpm.relationalizelastupdate = loc.relationalizelastupdate

  UNION ALL
  SELECT '06_join_contactos_direccion', COUNT(*)
  FROM db_ifr_shared.ifr_data.xpm xpm
  JOIN db_ifr_shared.ifr_data.xpm_location loc
    ON xpm.location = loc.id
   AND xpm.relationalizelastupdate = loc.relationalizelastupdate
  JOIN db_ifr_shared.ifr_data.xpm_location_val_contactinformations ci
    ON loc."location.val.contactinformations" = ci.id
   AND loc.relationalizelastupdate = ci.relationalizelastupdate
  WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7)

  UNION ALL
  SELECT '07_join_reportes_R1_R2', COUNT(*)
  FROM db_ifr_shared.ifr_data.xpm xpm
  JOIN db_ifr_shared.ifr_data.xpm_location loc
    ON xpm.location = loc.id
   AND xpm.relationalizelastupdate = loc.relationalizelastupdate
  JOIN db_ifr_shared.ifr_data.xpm_location_val_contactinformations ci
    ON loc."location.val.contactinformations" = ci.id
   AND loc.relationalizelastupdate = ci.relationalizelastupdate
  JOIN db_ifr_shared.ifr_data.xpm_counterparties cp
    ON xpm.counterparties = cp.id
   AND xpm.relationalizelastupdate = cp.relationalizelastupdate
  WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7)

  UNION ALL
  SELECT '08_xpm_con_counterparty_match', COUNT(*)
  FROM db_ifr_shared.ifr_data.xpm xpm
  JOIN db_ifr_shared.ifr_data.xpm_counterparties cp
    ON xpm.counterparties = cp.id
   AND xpm.relationalizelastupdate = cp.relationalizelastupdate

  UNION ALL
  SELECT '09_con_complemento', SUM(
    CASE
      WHEN ci."location.val.contactinformations.val.standardizedcomplemento" IS NOT NULL
       AND LENGTH(TRIM(ci."location.val.contactinformations.val.standardizedcomplemento")) > 0
      THEN 1 ELSE 0
    END
  )
  FROM db_ifr_shared.ifr_data.xpm xpm
  JOIN db_ifr_shared.ifr_data.xpm_location loc
    ON xpm.location = loc.id
   AND xpm.relationalizelastupdate = loc.relationalizelastupdate
  JOIN db_ifr_shared.ifr_data.xpm_location_val_contactinformations ci
    ON loc."location.val.contactinformations" = ci.id
   AND loc.relationalizelastupdate = ci.relationalizelastupdate
  WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7)

  UNION ALL
  SELECT '10_con_texto_ubicacion', SUM(
    CASE
      WHEN ci."location.val.contactinformations.val.standardizedtextoubicacion" IS NOT NULL
       AND LENGTH(TRIM(ci."location.val.contactinformations.val.standardizedtextoubicacion")) > 0
      THEN 1 ELSE 0
    END
  )
  FROM db_ifr_shared.ifr_data.xpm xpm
  JOIN db_ifr_shared.ifr_data.xpm_location loc
    ON xpm.location = loc.id
   AND xpm.relationalizelastupdate = loc.relationalizelastupdate
  JOIN db_ifr_shared.ifr_data.xpm_location_val_contactinformations ci
    ON loc."location.val.contactinformations" = ci.id
   AND loc.relationalizelastupdate = ci.relationalizelastupdate
  WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7)

) q
ORDER BY paso;
