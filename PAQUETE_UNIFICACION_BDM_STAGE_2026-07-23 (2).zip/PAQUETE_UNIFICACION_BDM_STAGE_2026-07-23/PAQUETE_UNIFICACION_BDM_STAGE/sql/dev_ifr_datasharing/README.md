# Data Sharing DEV — `ifr_data` → Reconocer

Fuente oficial: **`ifr_data.xpm_*`** (modelo tokenizado igual QA).

## DBA

1. Productor: `00_datashare_producer.sql` → `ds_reconocer_ifr_dev`
2. Consumidor: `00_datashare_consumer.sql` → `db_ifr_shared`
3. Consumidor: `00_grants_dba_reconocer.sql`

Ticket: `Documentacion/TICKET_DATASHARING_DEV_DEV.md`

## Equipo

```powershell
$env:REDSHIFT_CONSUMER_PASSWORD="gl51TGx4nFhD"
$env:REDSHIFT_PRODUCER_PASSWORD="b27YWI2FL"
py -3 tools/dev_ifr_datasharing_run.py --preflight-only
py -3 tools/dev_ifr_datasharing_run.py
```

Vistas: `00_vistas_insumo_bdm.sql` → `db_ifr_shared.ifr_data.*`  
SPs: `sql/qa_ifr_data/05`–`07` sin cambios.

## DEV hoy

| Métrica | Valor |
|---------|------:|
| xpm | 144 |
| contactos tokenizados (tipos 1–3/7) | 33 |

Volumen bajo pero **estructura correcta** para validar datashare + pipeline end-to-end.
