-- ============================================================
-- 00_grants_dba_reconocer.sql
-- Ejecutar como admin en consumidor Reconocer DEV (cz7jl1sn7m8z)
-- Database: dba_reconocerbatch
-- Usuario pipeline: c32525e (o rol batch_reconocer_unificacion)
-- ============================================================

-- 1) Schemas locales Unificación (equivalente mock bdm_datos / bdm_tempo)
CREATE SCHEMA IF NOT EXISTS bdm_datos;
CREATE SCHEMA IF NOT EXISTS bdm_tempo;

GRANT USAGE ON SCHEMA bdm_datos TO c32525e;
GRANT USAGE ON SCHEMA bdm_tempo TO c32525e;
GRANT CREATE ON SCHEMA bdm_datos TO c32525e;
GRANT CREATE ON SCHEMA bdm_tempo TO c32525e;

-- Alternativa si prefieren convención Reconocer existente:
-- GRANT USAGE, CREATE ON SCHEMA rec_stage, rec_datos, rec_mtdat TO c32525e;

-- 2) Datashare montado (post CREATE DATABASE db_ifr_shared ...)
GRANT USAGE ON DATABASE db_ifr_shared TO c32525e;
GRANT USAGE ON SCHEMA db_ifr_shared.ifr_data TO c32525e;
GRANT SELECT ON ALL TABLES IN SCHEMA db_ifr_shared.ifr_data TO c32525e;
ALTER DEFAULT PRIVILEGES IN SCHEMA db_ifr_shared.ifr_data
  GRANT SELECT ON TABLES TO c32525e;

-- 3) Verificación post-grants
SELECT has_schema_privilege('c32525e', 'bdm_datos', 'CREATE') AS can_create_bdm_datos;
SELECT has_schema_privilege('c32525e', 'bdm_tempo', 'CREATE') AS can_create_bdm_tempo;
