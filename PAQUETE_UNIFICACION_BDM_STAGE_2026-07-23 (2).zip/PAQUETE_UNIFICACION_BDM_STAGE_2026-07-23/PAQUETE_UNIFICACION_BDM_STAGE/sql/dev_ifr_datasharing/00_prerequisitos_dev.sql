-- ============================================================
-- 00_prerequisitos_dev.sql
-- Schemas locales consumidor Reconocer DEV + utilidad epoch
-- Precondición DBA: CREATE DATABASE db_ifr_shared FROM DATASHARE ...
-- ============================================================

CREATE SCHEMA IF NOT EXISTS bdm_datos;
CREATE SCHEMA IF NOT EXISTS bdm_tempo;

-- Conversión epoch ms → DATE (misma lógica documentada en configuracion_ifr_data_qa.md)
CREATE OR REPLACE FUNCTION bdm_datos.convert_epoch_to_date(val BIGINT)
RETURNS DATE
STABLE
AS $$
  SELECT DATE(TIMESTAMP 'epoch' + ($1 / 1000) * INTERVAL '1 second')
$$ LANGUAGE SQL;
