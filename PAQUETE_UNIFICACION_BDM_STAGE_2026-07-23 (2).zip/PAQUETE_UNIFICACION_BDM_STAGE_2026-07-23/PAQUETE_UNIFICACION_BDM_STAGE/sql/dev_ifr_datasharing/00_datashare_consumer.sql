-- CONSUMIDOR DEV — Montar ifr_data compartido
-- Cluster Reconocer cz7jl1sn7m8z | Database dba_reconocerbatch

CREATE DATABASE db_ifr_shared FROM DATASHARE ds_reconocer_ifr_dev;

SELECT * FROM svv_external_databases LIMIT 10;
SELECT COUNT(*) AS xpm FROM db_ifr_shared.ifr_data.xpm;
SELECT COUNT(*) AS ci FROM db_ifr_shared.ifr_data.xpm_location_val_contactinformations;
