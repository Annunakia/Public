-- PRODUCTOR DEV — Data Sharing ifr_data → Reconocer DEV
-- Cluster procesosbatch cee2enck00mg | Database dba_batch

CREATE DATASHARE ds_reconocer_ifr_dev;

ALTER DATASHARE ds_reconocer_ifr_dev ADD SCHEMA ifr_data;

ALTER DATASHARE ds_reconocer_ifr_dev ADD TABLE ifr_data.xpm;
ALTER DATASHARE ds_reconocer_ifr_dev ADD TABLE ifr_data.xpm_location;
ALTER DATASHARE ds_reconocer_ifr_dev ADD TABLE ifr_data.xpm_location_val_contactinformations;
ALTER DATASHARE ds_reconocer_ifr_dev ADD TABLE ifr_data.xpm_counterparties;

-- GRANT USAGE ON DATASHARE ds_reconocer_ifr_dev TO NAMESPACE '<NAMESPACE_RECONOCER_DEV>';

SELECT share_name FROM svv_datashares WHERE share_name = 'ds_reconocer_ifr_dev';
SELECT share_name, object_name FROM svv_datashare_objects
WHERE share_name = 'ds_reconocer_ifr_dev' ORDER BY object_name;
