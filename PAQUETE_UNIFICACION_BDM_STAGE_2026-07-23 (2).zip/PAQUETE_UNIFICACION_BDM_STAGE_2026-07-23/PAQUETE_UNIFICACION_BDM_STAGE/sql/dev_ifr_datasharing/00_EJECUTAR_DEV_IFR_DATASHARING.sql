-- ============================================================
-- 00_EJECUTAR_DEV_IFR_DATASHARING.sql
-- Orden despliegue DEV→DEV — Reconocer consumidor + IFR datashare
-- SPs: reutilizar qa_ifr_data sin modificar (tests QA ya OK)
-- Ref: Documentacion/TICKET_DATASHARING_DEV_DEV.md
-- ============================================================

-- PRECONDICIÓN DBA (consumidor cz7jl1sn7m8z / dba_reconocerbatch):
--   CREATE DATABASE db_ifr_shared FROM DATASHARE ds_reconocer_ifr_dev ...;
--   GRANT SELECT ON db_ifr_shared.ifr_data.* TO <usuario_pipeline>;

-- Etapa 0: Schemas + función epoch
--   sql/dev_ifr_datasharing/00_prerequisitos_dev.sql

-- Etapa 1: DDL salida + catálogos locales
--   sql/dev_ifr_datasharing/01_ddl_unificacion_direccion.sql

-- Etapa 2: Vistas insumo — REAPUNTO db_ifr_shared.ifr_data.*
--   sql/dev_ifr_datasharing/00_vistas_insumo_bdm.sql

-- Etapa 3: Smoke / gate lectura datashare
--   sql/dev_ifr_datasharing/00_smoke_ifr_data.sql
--   sql/dev_ifr_datasharing/00_validar_solo_lectura_ifr_data.sql

-- Etapa 4: Stored procedures (SIN CAMBIOS vs QA)
--   sql/qa_ifr_data/05_sp_regla1.sql
--   sql/qa_ifr_data/06_sp_regla2.sql
--   sql/qa_ifr_data/07_sp_regla3.sql

-- Etapa 5: Ejecución R1 → R2 → R3
--   sql/qa_ifr_data/08_ejecucion_secuencial.sql

-- Etapa 6: Validaciones funcionales (mismas que QA)
--   sql/qa_ifr_data/03_validaciones_unificacion.sql
