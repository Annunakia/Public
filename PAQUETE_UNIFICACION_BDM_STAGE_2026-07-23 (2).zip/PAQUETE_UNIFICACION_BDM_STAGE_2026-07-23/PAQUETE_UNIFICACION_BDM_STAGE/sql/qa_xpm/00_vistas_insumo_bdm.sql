-- ============================================================
-- 00_vistas_insumo_bdm.sql
-- Capa XPM (ifr_data) → insumo BDM para Unificación R1/R2/R3
-- Ref: Documentacion/MAPEO_QA_IFR_TABLAS_COLUMNAS.md
--
-- Columnas QA (catálogo svv_external_columns):
--   loc."location.val.contactinformations" → ci.id
--   ci."location.val.contactinformations.val.*"
--   cp."counterparties.val.counterpartyidnumber"
--   loc."location.val.personidtype" → cod_tipo_ident_fte
--   loc."location.val.cutoffdate" (fecha reporte)
--
-- PRECONDICION: función bdm_datos.convert_epoch_to_date disponible
-- Vistas late-binding (ifr_data = tablas externas Spectrum/Glue)
-- ============================================================

-- ------------------------------------------------------------
-- Vista base: contactos de dirección (1 fila = 1 RPU candidato)
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW bdm_tempo.v_xpm_contacto_direccion AS
SELECT
  xpm.pin,
  xpm.relationalizelastupdate,
  loc.id                          AS cod_dw_ubic,
  ci.id                           AS cod_dw_persona_ubic,
  ci.id                           AS cod_dw_direccion_fisica,
  FNV_HASH(xpm.pin)               AS id_buro_persona,
  CAST(xpm.pin AS BIGINT)         AS cod_pin_persona,
  CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) AS cod_dw_tipo_ubicacion_dir,
  ci."location.val.contactinformations.val.standardizedtextoubicacion"     AS texto_ubicacion,
  ci."location.val.contactinformations.val.contactasreportedstandardized"  AS texto_ubicacion_normalizado,
  ci."location.val.contactinformations.val.contactasreported"              AS texto_ubicacion_original,
  CAST(ci."location.val.contactinformations.val.contactasstandardizedscore" AS DECIMAL(5,4)) AS score_estandarizacion,
  CAST(ci."location.val.contactinformations.val.standardizeddanecode" AS INTEGER) AS cod_dw_ciudad,
  ci."location.val.contactinformations.val.standardizeddepartment"         AS departamento,
  ci."location.val.contactinformations.val.standardizedmunicipality"       AS municipio,
  ci."location.val.contactinformations.val.standardizedtipo"               AS tipo_ubicacion,
  ci."location.val.contactinformations.val.standardizedcomplemento"         AS complemento,
  ci."location.val.contactinformations.val.standardizedtipoviaprincipal"   AS tipo_via_principal,
  ci."location.val.contactinformations.val.standardizedviaprincipal"       AS via_principal,
  ci."location.val.contactinformations.val.standardizedviageneradora"      AS via_generadora,
  ci."location.val.contactinformations.val.standardizednumeropuerta"       AS numero_puerta,
  bdm_datos.convert_epoch_to_date(
    CAST(ci."location.val.contactinformations.val.contacteventlastupdated" AS BIGINT)
  ) AS fecha_relacion_persona_ubicaci,
  bdm_datos.convert_epoch_to_date(
    CAST(ci."location.val.contactinformations.val.contactfirsteventdate" AS BIGINT)
  ) AS fecha_primera_relacion,
  CAST(NULL AS DECIMAL(10,6)) AS latitud,
  CAST(NULL AS DECIMAL(10,6)) AS longitud,
  CAST(loc."location.val.personidtype" AS INTEGER) AS cod_tipo_ident_fte,
  CAST(NULL AS INTEGER) AS lote
FROM ifr_data.xpm xpm
INNER JOIN ifr_data.xpm_location loc
  ON xpm.location = loc.id
 AND xpm.relationalizelastupdate = loc.relationalizelastupdate
INNER JOIN ifr_data.xpm_location_val_contactinformations ci
  ON loc."location.val.contactinformations" = ci.id
 AND loc.relationalizelastupdate = ci.relationalizelastupdate
WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7);

-- ------------------------------------------------------------
-- bdm_tempo.v_xpm_relacion_persona_ubicacion
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW bdm_tempo.v_xpm_relacion_persona_ubicacion AS
SELECT
  cod_dw_persona_ubic,
  id_buro_persona,
  cod_pin_persona,
  cod_dw_ubic,
  cod_dw_direccion_fisica,
  cod_dw_tipo_ubicacion_dir,
  CAST(NULL AS INTEGER) AS ind_unificacion,
  ROW_NUMBER() OVER (
    PARTITION BY id_buro_persona, cod_dw_ubic, cod_dw_tipo_ubicacion_dir
    ORDER BY fecha_relacion_persona_ubicaci DESC NULLS LAST, cod_dw_persona_ubic
  ) AS orden_prioridad,
  fecha_relacion_persona_ubicaci,
  lote,
  cod_tipo_ident_fte,
  CAST(0 AS SMALLINT) AS bloqueado
FROM bdm_tempo.v_xpm_contacto_direccion;

-- ------------------------------------------------------------
-- bdm_tempo.v_xpm_ubicacion_estandarizada
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW bdm_tempo.v_xpm_ubicacion_estandarizada AS
SELECT DISTINCT
  cod_dw_ubic,
  texto_ubicacion,
  texto_ubicacion_normalizado,
  texto_ubicacion_original,
  score_estandarizacion,
  cod_dw_ciudad,
  cod_dw_ciudad AS cod_dw_municipio,
  departamento,
  municipio,
  tipo_ubicacion,
  cod_dw_tipo_ubicacion_dir AS cod_dw_tipo_ubicacion,
  latitud,
  longitud
FROM bdm_tempo.v_xpm_contacto_direccion;

-- ------------------------------------------------------------
-- bdm_tempo.v_xpm_direccion_fisica
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW bdm_tempo.v_xpm_direccion_fisica AS
SELECT DISTINCT
  cod_dw_direccion_fisica,
  complemento,
  tipo_via_principal,
  via_principal,
  via_generadora,
  numero_puerta,
  cod_dw_ubic,
  CAST(0 AS INTEGER) AS generada_enriquecida
FROM bdm_tempo.v_xpm_contacto_direccion;

-- ------------------------------------------------------------
-- bdm_tempo.v_xpm_reporte_relacion_persona_ubica
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW bdm_tempo.v_xpm_reporte_relacion_persona_ubica AS
SELECT
  ci.id AS cod_dw_persona_ubic,
  CAST(cp."counterparties.val.counterpartyidnumber" AS INTEGER) AS id_buro_suscriptor,
  bdm_datos.convert_epoch_to_date(
    CAST(loc."location.val.cutoffdate" AS BIGINT)
  ) AS fecha_reporte
FROM ifr_data.xpm xpm
INNER JOIN ifr_data.xpm_location loc
  ON xpm.location = loc.id
 AND xpm.relationalizelastupdate = loc.relationalizelastupdate
INNER JOIN ifr_data.xpm_location_val_contactinformations ci
  ON loc."location.val.contactinformations" = ci.id
 AND loc.relationalizelastupdate = ci.relationalizelastupdate
INNER JOIN ifr_data.xpm_counterparties cp
  ON xpm.counterparties = cp.id
 AND xpm.relationalizelastupdate = cp.relationalizelastupdate
WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7);

-- ------------------------------------------------------------
-- bdm_tempo.v_xpm_ciiu_persona
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW bdm_tempo.v_xpm_ciiu_persona AS
SELECT DISTINCT
  FNV_HASH(xpm.pin) AS id_buro_persona,
  xpm."bestpersonalinformation.mainisiccodeforproduct" AS cod_act_econo_ciiu_fte
FROM ifr_data.xpm xpm
WHERE xpm."bestpersonalinformation.mainisiccodeforproduct" IS NOT NULL;
