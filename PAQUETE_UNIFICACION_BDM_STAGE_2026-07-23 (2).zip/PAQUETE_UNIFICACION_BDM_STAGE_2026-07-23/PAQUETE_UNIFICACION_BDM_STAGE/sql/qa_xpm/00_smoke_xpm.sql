-- ============================================================
-- 00_smoke_xpm.sql
-- Verificar vistas XPM + catálogos antes de unificación (pipeline)
-- Ref: Documentacion/ESTADO_COMPLETO_UNIFICACION_BDM.md
-- ============================================================

SELECT 'v_xpm_relacion_persona_ubicacion' AS obj, COUNT(*) AS total
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion
UNION ALL
SELECT 'v_xpm_ubicacion_estandarizada', COUNT(*) FROM bdm_tempo.v_xpm_ubicacion_estandarizada
UNION ALL
SELECT 'v_xpm_direccion_fisica', COUNT(*) FROM bdm_tempo.v_xpm_direccion_fisica
UNION ALL
SELECT 'v_xpm_reporte_relacion_persona_ubica', COUNT(*) FROM bdm_tempo.v_xpm_reporte_relacion_persona_ubica
UNION ALL
SELECT 'v_xpm_ciiu_persona', COUNT(*) FROM bdm_tempo.v_xpm_ciiu_persona
UNION ALL
SELECT 'bdm_datos.tipo_ubicacion_dir', COUNT(*) FROM bdm_datos.tipo_ubicacion_dir
UNION ALL
SELECT 'bdm_datos.nomenclatura', COUNT(*) FROM bdm_datos.nomenclatura
UNION ALL
SELECT 'bdm_datos.unificacion_direccion', COUNT(*) FROM bdm_datos.unificacion_direccion;

-- Cobertura complemento (impacto R2)
SELECT
  COUNT(*) AS rpu_dir,
  SUM(CASE WHEN df.complemento IS NOT NULL AND LENGTH(TRIM(df.complemento)) > 0 THEN 1 ELSE 0 END) AS con_complemento,
  SUM(CASE WHEN ue.latitud IS NOT NULL THEN 1 ELSE 0 END) AS con_lat
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ue ON rpu.cod_dw_ubic = ue.cod_dw_ubic
LEFT JOIN bdm_tempo.v_xpm_direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.cod_dw_tipo_ubicacion_dir IN (1, 2, 3, 7)
  AND rpu.ind_unificacion IS NULL;
