-- ============================================================
-- 00_EJECUTAR_QA_XPM.sql
-- Orden de despliegue QA — Unificación con XPM real (ifr_data)
-- Orquestación propuesta: Documentacion/ESTADO_COMPLETO_UNIFICACION_BDM.md
-- ============================================================

-- Etapa 1: DDL resultado + catálogos
--   sql/qa_xpm/01_ddl_unificacion_direccion.sql

-- Etapa 2: Vistas insumo XPM → BDM
--   sql/qa_xpm/00_vistas_insumo_bdm.sql

-- Etapa 3: Smoke (gate conteos)
--   sql/qa_xpm/00_smoke_xpm.sql

-- Etapa 4: Stored procedures (secuencial)
--   sql/qa_xpm/05_sp_regla1.sql
--   sql/qa_xpm/06_sp_regla2.sql
--   sql/qa_xpm/07_sp_regla3.sql

-- Etapa 5: Ejecución R1 → R2 → R3
--   sql/qa_xpm/08_ejecucion_secuencial.sql

-- Etapa 6: Validaciones (gate calidad)
--   sql/qa_xpm/03_validaciones_unificacion.sql

-- Alternativa sin SPs (misma fuente/salida):
--   sql/qa_xpm/02_unificacion_sql_plano.sql
