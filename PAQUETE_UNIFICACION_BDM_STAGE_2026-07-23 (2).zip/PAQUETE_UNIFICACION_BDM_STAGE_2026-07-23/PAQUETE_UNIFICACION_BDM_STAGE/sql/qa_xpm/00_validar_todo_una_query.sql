-- ============================================================
-- 00_validar_todo_una_query.sql
-- Una sola corrida: paso + total (QA ifr_data → vistas → SPs)
-- Ejecutar DESPUÉS de 01_ddl y 00_vistas_insumo_bdm.sql
-- ============================================================

SELECT paso, total FROM (

  SELECT '01_ifr_data.xpm' AS paso, COUNT(*)::BIGINT AS total FROM ifr_data.xpm
  UNION ALL SELECT '02_ifr_data.xpm_location', COUNT(*) FROM ifr_data.xpm_location
  UNION ALL SELECT '03_ifr_data.xpm_location_val_contactinformations', COUNT(*)
    FROM ifr_data.xpm_location_val_contactinformations
  UNION ALL SELECT '04_ifr_data.xpm_counterparties', COUNT(*) FROM ifr_data.xpm_counterparties

  UNION ALL
  SELECT '05_join_contactos_direccion', COUNT(*)
  FROM ifr_data.xpm xpm
  JOIN ifr_data.xpm_location loc
    ON xpm.location = loc.id
   AND xpm.relationalizelastupdate = loc.relationalizelastupdate
  JOIN ifr_data.xpm_location_val_contactinformations ci
    ON loc."location.val.contactinformations" = ci.id
   AND loc.relationalizelastupdate = ci.relationalizelastupdate
  WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7)

  UNION ALL
  SELECT '06_join_reportes_R1_R2', COUNT(*)
  FROM ifr_data.xpm xpm
  JOIN ifr_data.xpm_location loc
    ON xpm.location = loc.id
   AND xpm.relationalizelastupdate = loc.relationalizelastupdate
  JOIN ifr_data.xpm_location_val_contactinformations ci
    ON loc."location.val.contactinformations" = ci.id
   AND loc.relationalizelastupdate = ci.relationalizelastupdate
  JOIN ifr_data.xpm_counterparties cp
    ON xpm.counterparties = cp.id
   AND xpm.relationalizelastupdate = cp.relationalizelastupdate
  WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7)

  UNION ALL SELECT '07_v_xpm_relacion_persona_ubicacion', COUNT(*)
    FROM bdm_tempo.v_xpm_relacion_persona_ubicacion
  UNION ALL SELECT '08_v_xpm_ubicacion_estandarizada', COUNT(*)
    FROM bdm_tempo.v_xpm_ubicacion_estandarizada
  UNION ALL SELECT '09_v_xpm_direccion_fisica', COUNT(*)
    FROM bdm_tempo.v_xpm_direccion_fisica
  UNION ALL SELECT '10_v_xpm_reporte_relacion_persona_ubica', COUNT(*)
    FROM bdm_tempo.v_xpm_reporte_relacion_persona_ubica
  UNION ALL SELECT '11_v_xpm_ciiu_persona', COUNT(*)
    FROM bdm_tempo.v_xpm_ciiu_persona

  UNION ALL SELECT '12_bdm_datos.tipo_ubicacion_dir', COUNT(*)
    FROM bdm_datos.tipo_ubicacion_dir
  UNION ALL SELECT '13_bdm_datos.nomenclatura', COUNT(*)
    FROM bdm_datos.nomenclatura
  UNION ALL SELECT '14_bdm_datos.unificacion_direccion', COUNT(*)
    FROM bdm_datos.unificacion_direccion

  UNION ALL
  SELECT '15_insumo_regla1_potencial', COUNT(DISTINCT rpu.cod_dw_persona_ubic)
  FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
  JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi
    ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  LEFT JOIN bdm_tempo.v_xpm_direccion_fisica df
    ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
  JOIN bdm_tempo.v_xpm_reporte_relacion_persona_ubica rep
    ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  WHERE rpu.ind_unificacion IS NULL

  UNION ALL
  SELECT '16_rpu_con_complemento', SUM(
    CASE WHEN df.complemento IS NOT NULL AND LENGTH(TRIM(df.complemento)) > 0 THEN 1 ELSE 0 END
  )
  FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
  JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ue
    ON rpu.cod_dw_ubic = ue.cod_dw_ubic
  LEFT JOIN bdm_tempo.v_xpm_direccion_fisica df
    ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
  WHERE rpu.cod_dw_tipo_ubicacion_dir IN (1, 2, 3, 7)
    AND rpu.ind_unificacion IS NULL

  UNION ALL
  SELECT '17_rpu_con_latitud', SUM(CASE WHEN ue.latitud IS NOT NULL THEN 1 ELSE 0 END)
  FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
  JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ue
    ON rpu.cod_dw_ubic = ue.cod_dw_ubic
  WHERE rpu.cod_dw_tipo_ubicacion_dir IN (1, 2, 3, 7)
    AND rpu.ind_unificacion IS NULL

  UNION ALL
  SELECT '21_personidtype_informado', SUM(CASE WHEN cod_tipo_ident_fte IS NOT NULL THEN 1 ELSE 0 END)
  FROM bdm_tempo.v_xpm_relacion_persona_ubicacion

  UNION ALL
  SELECT '22_personidtype_nit_tipo3', SUM(CASE WHEN COALESCE(cod_tipo_ident_fte, 0) = 3 THEN 1 ELSE 0 END)
  FROM bdm_tempo.v_xpm_relacion_persona_ubicacion

  UNION ALL
  SELECT '23_esc3_nit_con_complemento', COUNT(DISTINCT r.cod_dw_persona_ubic)
  FROM bdm_tempo.v_xpm_relacion_persona_ubicacion r
  JOIN bdm_tempo.v_xpm_direccion_fisica df
    ON r.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
  WHERE COALESCE(r.cod_tipo_ident_fte, 0) = 3
    AND df.complemento IS NOT NULL
    AND LENGTH(TRIM(df.complemento)) > 0
    AND r.ind_unificacion IS NULL

  UNION ALL
  SELECT '18_sp_regla1_desplegado',
    CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END
  FROM pg_proc p
  JOIN pg_namespace n ON p.pronamespace = n.oid
  WHERE n.nspname = 'bdm_datos' AND p.proname = 'sp_unificacion_regla1'

  UNION ALL
  SELECT '19_sp_regla2_desplegado',
    CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END
  FROM pg_proc p
  JOIN pg_namespace n ON p.pronamespace = n.oid
  WHERE n.nspname = 'bdm_datos' AND p.proname = 'sp_unificacion_regla2'

  UNION ALL
  SELECT '20_sp_regla3_desplegado',
    CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END
  FROM pg_proc p
  JOIN pg_namespace n ON p.pronamespace = n.oid
  WHERE n.nspname = 'bdm_datos' AND p.proname = 'sp_unificacion_regla3'

) q
ORDER BY paso;
