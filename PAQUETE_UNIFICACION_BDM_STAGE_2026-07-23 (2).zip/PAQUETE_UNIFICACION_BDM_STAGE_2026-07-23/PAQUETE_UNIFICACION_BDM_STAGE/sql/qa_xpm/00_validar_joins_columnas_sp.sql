-- ============================================================
-- 00_validar_joins_columnas_sp.sql
-- Solo SELECT: valida columnas y JOINs usados por SPs 05/06 (sin escritura ifr_data)
-- Ejecutar DESPUÉS de 01_ddl y 00_vistas_insumo_bdm.sql
-- Esperado: errores = 0 filas; conteos > 0 donde aplique
-- ============================================================

-- A) JOIN base idéntico a v_xpm_contacto_direccion
SELECT 'A_join_vista_base' AS chk, COUNT(*) AS total
FROM ifr_data.xpm xpm
JOIN ifr_data.xpm_location loc
  ON xpm.location = loc.id
 AND xpm.relationalizelastupdate = loc.relationalizelastupdate
JOIN ifr_data.xpm_location_val_contactinformations ci
  ON loc."location.val.contactinformations" = ci.id
 AND loc.relationalizelastupdate = ci.relationalizelastupdate
WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7);

-- B) Vistas BDM (columnas expuestas a SPs)
SELECT 'B_v_rpu' AS chk, COUNT(*) AS total FROM bdm_tempo.v_xpm_relacion_persona_ubicacion
UNION ALL SELECT 'B_v_ubi', COUNT(*) FROM bdm_tempo.v_xpm_ubicacion_estandarizada
UNION ALL SELECT 'B_v_df', COUNT(*) FROM bdm_tempo.v_xpm_direccion_fisica
UNION ALL SELECT 'B_v_rep', COUNT(*) FROM bdm_tempo.v_xpm_reporte_relacion_persona_ubica
UNION ALL SELECT 'B_v_ciiu', COUNT(*) FROM bdm_tempo.v_xpm_ciiu_persona;

-- C) JOIN R1 insumo (mismo grafo que sp_unificacion_regla1)
SELECT 'C_r1_insumo_join' AS chk, COUNT(DISTINCT rpu.cod_dw_persona_ubic) AS total
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi
  ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_tempo.v_xpm_direccion_fisica df
  ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
JOIN bdm_tempo.v_xpm_reporte_relacion_persona_ubica rep
  ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
LEFT JOIN bdm_tempo.v_xpm_ciiu_persona ciiu
  ON rpu.id_buro_persona = ciiu.id_buro_persona
LEFT JOIN bdm_datos.tipo_ubicacion_dir tud
  ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
WHERE rpu.ind_unificacion IS NULL;

-- D) JOIN R2 insumo + complemento (Esc1/Esc2)
SELECT 'D_r2_insumo_join' AS chk, COUNT(*) AS total
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi
  ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_tempo.v_xpm_direccion_fisica df
  ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
JOIN bdm_tempo.v_xpm_reporte_relacion_persona_ubica rep
  ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
WHERE rpu.ind_unificacion IS NULL;

-- E) Catálogo tipo_ubicacion_dir cubre contacttype 1/2/3/7
SELECT 'E_tipo_ubicacion_faltantes' AS chk, COUNT(*) AS total
FROM (
  SELECT DISTINCT rpu.cod_dw_tipo_ubicacion_dir
  FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
  LEFT JOIN bdm_datos.tipo_ubicacion_dir tud
    ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
  WHERE tud.cod_dw_tipo_ubicacion_dir IS NULL
) t;
-- Esperado: 0

-- F) Columnas motor: complemento + vía desde mismo cod_dw_direccion_fisica
SELECT 'F_motor_join_df' AS chk, COUNT(*) AS total
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_direccion_fisica df
  ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE df.complemento IS NOT NULL AND LENGTH(TRIM(df.complemento)) > 0;

-- G) orden_prioridad calculado en vista
SELECT 'G_orden_prioridad_ok' AS chk,
       SUM(CASE WHEN orden_prioridad IS NULL THEN 1 ELSE 0 END) AS total
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion;
-- Esperado: 0

-- H) cod_dw_municipio alias en ubicacion
SELECT 'H_cod_dw_municipio_ok' AS chk,
       SUM(CASE WHEN cod_dw_municipio IS NULL THEN 1 ELSE 0 END) AS total
FROM bdm_tempo.v_xpm_ubicacion_estandarizada;

-- I) cod_tipo_ident_fte mapeado desde location.val.personidtype
SELECT 'I_personidtype_en_vista' AS chk,
       SUM(CASE WHEN cod_tipo_ident_fte IS NOT NULL THEN 1 ELSE 0 END) AS con_tipo,
       SUM(CASE WHEN cod_tipo_ident_fte IS NULL THEN 1 ELSE 0 END) AS sin_tipo,
       COUNT(*) AS total
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion;

-- J) Coherencia vista vs fuente IFR (mismo personidtype por location)
SELECT 'J_personidtype_coherente' AS chk,
       SUM(CASE WHEN r.cod_tipo_ident_fte = CAST(loc."location.val.personidtype" AS INTEGER) THEN 1 ELSE 0 END) AS ok,
       SUM(CASE WHEN r.cod_tipo_ident_fte IS DISTINCT FROM CAST(loc."location.val.personidtype" AS INTEGER) THEN 1 ELSE 0 END) AS divergente
FROM bdm_tempo.v_xpm_contacto_direccion r
JOIN ifr_data.xpm_location loc
  ON r.cod_dw_ubic = loc.id
 AND r.relationalizelastupdate = loc.relationalizelastupdate;

-- K) Candidatos motor Esc3 NIT (tipo=3 + complemento + >=2 RPU potencial)
SELECT 'K_esc3_nit_potencial' AS chk,
       COUNT(DISTINCT r.id_buro_persona || '|' || u.texto_ubicacion || '|' || r.cod_dw_tipo_ubicacion_dir || '|' || u.cod_dw_municipio) AS grupos
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion r
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada u
  ON r.cod_dw_ubic = u.cod_dw_ubic
JOIN bdm_tempo.v_xpm_direccion_fisica df
  ON r.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE COALESCE(r.cod_tipo_ident_fte, 0) = 3
  AND df.complemento IS NOT NULL
  AND LENGTH(TRIM(df.complemento)) > 0
  AND r.ind_unificacion IS NULL;
