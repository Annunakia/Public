# QA — Alias de `sql/qa_ifr_data/`

**Usar la carpeta `sql/qa_ifr_data/`** — es el frente activo para QA con tablas XPM en `ifr_data`.

Este directorio mantiene copias sincronizadas por compatibilidad histórica.
