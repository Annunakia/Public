-- ============================================================
-- 02b_sync_rpu_ganadoras.sql
-- Copia RPUs ganadoras (post-unificación) a bdm_datos para consolidación
-- PRECONDICIÓN: unificación R1/R2/R3 ejecutada en bdm_stage
-- ============================================================

TRUNCATE TABLE bdm_datos.relacion_persona_ubicacion;

INSERT INTO bdm_datos.relacion_persona_ubicacion (
  cod_dw_persona_ubic,
  cod_pin_persona,
  id_buro_persona,
  cod_dw_ubic,
  orden_prioridad,
  fecha_relacion_persona_ubicaci,
  ind_unificacion
)
SELECT
  rpu.cod_dw_persona_ubic,
  rpu.cod_pin_persona,
  rpu.id_buro_persona,
  rpu.cod_dw_ubic,
  rpu.orden_prioridad,
  rpu.fecha_relacion_persona_ubicaci,
  rpu.ind_unificacion
FROM bdm_stage.relacion_persona_ubicacion rpu
WHERE COALESCE(rpu.ind_unificacion, 0) <> 1;

ANALYZE bdm_datos.relacion_persona_ubicacion;

SELECT
  COUNT(*) AS rpu_ganadoras,
  COUNT(DISTINCT id_buro_persona) AS personas
FROM bdm_datos.relacion_persona_ubicacion;
