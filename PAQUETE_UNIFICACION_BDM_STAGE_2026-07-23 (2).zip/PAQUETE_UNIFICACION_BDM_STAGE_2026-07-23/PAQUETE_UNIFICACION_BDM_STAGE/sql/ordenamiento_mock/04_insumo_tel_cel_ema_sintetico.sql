-- ============================================================
-- 04_insumo_tel_cel_ema_sintetico.sql
-- Genera insumos TEL/CEL/EMA enlazados al mock unificación (bdm_stage)
-- Escala: ~1 fila TEL por reporte ganador; 1-3 contactos CEL/EMA por persona
-- Determinista vía MOD(id_buro_persona) — reproducible entre corridas
-- PRECONDICIONES: unificación ejecutada; 01_schemas + 02b_sync_rpu_ganadoras
-- ============================================================

TRUNCATE TABLE bdm_datos.insumo_telefono;
TRUNCATE TABLE bdm_datos.insumo_celular;
TRUNCATE TABLE bdm_datos.insumo_email;

-- ----------------------------------------------------------------
-- TEL: un reporte por fila de reporte_relacion_persona_ubica (ganadoras)
-- ----------------------------------------------------------------
INSERT INTO bdm_datos.insumo_telefono (
  cod_dw_persona_ubic,
  cod_pin_persona,
  id_buro_persona,
  direccion_fisica,
  cod_dane_ciudad,
  descripcion_gestion,
  id_buro_suscriptor,
  fecha_reporte,
  meses_reporte,
  coincidencia_geo,
  sector_financiero,
  tipo_cuenta
)
SELECT
  rpu.cod_dw_persona_ubic,
  rpu.cod_pin_persona,
  rpu.id_buro_persona,
  ubi.texto_ubicacion AS direccion_fisica,
  ubi.cod_dw_ciudad AS cod_dane_ciudad,
  CASE
    WHEN MOD(rep.id_buro_suscriptor + rpu.cod_dw_persona_ubic, 10) = 0 THEN 'NO VALIDA'
    ELSE 'VALIDA'
  END AS descripcion_gestion,
  rep.id_buro_suscriptor,
  rep.fecha_reporte,
  GREATEST(DATEDIFF(month, rep.fecha_reporte, CURRENT_DATE), 0) AS meses_reporte,
  CASE WHEN MOD(rpu.id_buro_persona, 3) = 0 THEN 1 ELSE 0 END AS coincidencia_geo,
  CASE WHEN rep.id_buro_suscriptor >= 901 THEN 1 ELSE 0 END AS sector_financiero,
  CASE WHEN MOD(rpu.id_buro_persona, 5) = 0 THEN 'MOVIL' ELSE 'FIJA' END AS tipo_cuenta
FROM bdm_stage.relacion_persona_ubicacion rpu
INNER JOIN bdm_stage.ubicacion_estandarizada ubi
  ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
INNER JOIN bdm_stage.reporte_relacion_persona_ubica rep
  ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
WHERE COALESCE(rpu.ind_unificacion, 0) <> 1;

-- ----------------------------------------------------------------
-- CEL / EMA: contactos sintéticos por persona (1-3) × 2-5 reportes c/u
-- cod_dw_persona_ubic = RPU ganadora real (rotación por contacto)
-- ----------------------------------------------------------------
WITH nums AS (
  SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3
),
rep_nums AS (
  SELECT 1 AS r UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5
),
winning AS (
  SELECT
    rpu.cod_dw_persona_ubic,
    rpu.cod_pin_persona,
    rpu.id_buro_persona,
    ubi.texto_ubicacion,
    ROW_NUMBER() OVER (
      PARTITION BY rpu.id_buro_persona
      ORDER BY rpu.cod_dw_persona_ubic
    ) AS rpu_rank,
    COUNT(*) OVER (PARTITION BY rpu.id_buro_persona) AS rpu_cnt
  FROM bdm_stage.relacion_persona_ubicacion rpu
  INNER JOIN bdm_stage.ubicacion_estandarizada ubi
    ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  WHERE COALESCE(rpu.ind_unificacion, 0) <> 1
),
contacts AS (
  SELECT
    w.cod_dw_persona_ubic,
    w.cod_pin_persona,
    w.id_buro_persona,
    w.texto_ubicacion,
    n.n AS contact_n,
    CASE MOD(w.id_buro_persona + n.n, 4)
      WHEN 0 THEN '310'
      WHEN 1 THEN '320'
      WHEN 2 THEN '300'
      ELSE '315'
    END AS operador_prefix,
    CASE MOD(w.id_buro_persona + n.n, 5)
      WHEN 0 THEN 'gmail.com'
      WHEN 1 THEN 'hotmail.com'
      WHEN 2 THEN 'yahoo.com'
      WHEN 3 THEN 'outlook.com'
      ELSE 'empresa.co'
    END AS dominio
  FROM winning w
  INNER JOIN nums n
    ON n.n <= 1 + MOD(w.id_buro_persona, 3)
  WHERE w.rpu_rank = MOD(n.n - 1, w.rpu_cnt) + 1
)
INSERT INTO bdm_datos.insumo_celular (
  cod_dw_persona_ubic,
  cod_pin_persona,
  id_buro_persona,
  celular,
  texto_ubicacion,
  id_buro_suscriptor,
  fecha_reporte,
  meses_reporte,
  operador,
  sector_financiero,
  tipo_cuenta
)
SELECT
  c.cod_dw_persona_ubic,
  c.cod_pin_persona,
  c.id_buro_persona,
  c.operador_prefix
    || RIGHT(
      '0000000'
      || CAST(MOD(c.id_buro_persona * 10 + c.contact_n * 1000 + rn.r, 10000000) AS VARCHAR),
      7
    ) AS celular,
  c.texto_ubicacion,
  900 + MOD(c.id_buro_persona + c.contact_n * 11 + rn.r, 50) AS id_buro_suscriptor,
  DATEADD(
    month,
    -1 * GREATEST(MOD(c.id_buro_persona + c.contact_n * 7 + rn.r, 48) + 1, 1),
    CURRENT_DATE
  ) AS fecha_reporte,
  GREATEST(MOD(c.id_buro_persona + c.contact_n * 7 + rn.r, 48) + 1, 1) AS meses_reporte,
  c.operador_prefix AS operador,
  CASE WHEN MOD(c.id_buro_persona + rn.r, 3) <> 0 THEN 1 ELSE 0 END AS sector_financiero,
  CASE WHEN MOD(c.id_buro_persona + c.contact_n, 3) = 0 THEN 'POSPAGO' ELSE 'PREPAGO' END AS tipo_cuenta
FROM contacts c
INNER JOIN rep_nums rn
  ON rn.r <= 2 + MOD(c.id_buro_persona + c.contact_n, 4);

WITH nums AS (
  SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3
),
rep_nums AS (
  SELECT 1 AS r UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5
),
winning AS (
  SELECT
    rpu.cod_dw_persona_ubic,
    rpu.cod_pin_persona,
    rpu.id_buro_persona,
    ubi.texto_ubicacion,
    ROW_NUMBER() OVER (
      PARTITION BY rpu.id_buro_persona
      ORDER BY rpu.cod_dw_persona_ubic
    ) AS rpu_rank,
    COUNT(*) OVER (PARTITION BY rpu.id_buro_persona) AS rpu_cnt
  FROM bdm_stage.relacion_persona_ubicacion rpu
  INNER JOIN bdm_stage.ubicacion_estandarizada ubi
    ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  WHERE COALESCE(rpu.ind_unificacion, 0) <> 1
),
contacts AS (
  SELECT
    w.cod_dw_persona_ubic,
    w.cod_pin_persona,
    w.id_buro_persona,
    n.n AS contact_n,
    CASE MOD(w.id_buro_persona + n.n, 5)
      WHEN 0 THEN 'gmail.com'
      WHEN 1 THEN 'hotmail.com'
      WHEN 2 THEN 'yahoo.com'
      WHEN 3 THEN 'outlook.com'
      ELSE 'empresa.co'
    END AS dominio
  FROM winning w
  INNER JOIN nums n
    ON n.n <= 1 + MOD(w.id_buro_persona, 3)
  WHERE w.rpu_rank = MOD(n.n - 1, w.rpu_cnt) + 1
)
INSERT INTO bdm_datos.insumo_email (
  cod_dw_persona_ubic,
  cod_pin_persona,
  id_buro_persona,
  email,
  dominio,
  id_buro_suscriptor,
  fecha_reporte,
  meses_reporte,
  sector_financiero,
  tipo_cuenta
)
SELECT
  c.cod_dw_persona_ubic,
  c.cod_pin_persona,
  c.id_buro_persona,
  'user'
    || CAST(MOD(c.id_buro_persona, 100000) AS VARCHAR)
    || '_'
    || CAST(c.contact_n AS VARCHAR)
    || '@'
    || c.dominio AS email,
  c.dominio,
  900 + MOD(c.id_buro_persona + c.contact_n * 13 + rn.r, 50) AS id_buro_suscriptor,
  DATEADD(
    month,
    -1 * GREATEST(MOD(c.id_buro_persona + c.contact_n * 5 + rn.r, 48) + 1, 1),
    CURRENT_DATE
  ) AS fecha_reporte,
  GREATEST(MOD(c.id_buro_persona + c.contact_n * 5 + rn.r, 48) + 1, 1) AS meses_reporte,
  CASE WHEN MOD(c.id_buro_persona + rn.r, 4) <> 0 THEN 1 ELSE 0 END AS sector_financiero,
  CASE
    WHEN c.dominio = 'empresa.co' THEN 'CORPORATIVO'
    ELSE 'PERSONAL'
  END AS tipo_cuenta
FROM contacts c
INNER JOIN rep_nums rn
  ON rn.r <= 2 + MOD(c.id_buro_persona + c.contact_n, 4);

ANALYZE bdm_datos.insumo_telefono;
ANALYZE bdm_datos.insumo_celular;
ANALYZE bdm_datos.insumo_email;

SELECT 'TEL' AS canal, COUNT(*) AS filas, COUNT(DISTINCT id_buro_persona) AS personas
FROM bdm_datos.insumo_telefono
UNION ALL
SELECT 'CEL', COUNT(*), COUNT(DISTINCT id_buro_persona) FROM bdm_datos.insumo_celular
UNION ALL
SELECT 'EMA', COUNT(*), COUNT(DISTINCT id_buro_persona) FROM bdm_datos.insumo_email
ORDER BY 1;
