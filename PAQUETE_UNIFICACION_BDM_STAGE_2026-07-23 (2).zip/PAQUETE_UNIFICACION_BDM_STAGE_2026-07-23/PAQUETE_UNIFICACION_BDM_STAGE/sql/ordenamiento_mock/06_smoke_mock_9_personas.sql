-- ============================================================
-- 06_smoke_mock_9_personas.sql
-- Smoke test Ordenamiento (9 personas) — Public-main mock_data_ordenamiento.sql
-- + RPUs en bdm_datos.relacion_persona_ubicacion para consolidación
-- PRECONDICIÓN: 01_schemas.sql + 02_mock_betas.sql
-- ============================================================

TRUNCATE TABLE bdm_datos.insumo_direccion;
TRUNCATE TABLE bdm_datos.insumo_telefono;
TRUNCATE TABLE bdm_datos.insumo_celular;
TRUNCATE TABLE bdm_datos.insumo_email;
TRUNCATE TABLE bdm_datos.score_ordenamiento;
TRUNCATE TABLE bdm_datos.relacion_persona_ubicacion;

-- Insumo DIR (personas 20001-20003)
INSERT INTO bdm_datos.insumo_direccion VALUES
(300001,90001,20001,'CL 22 27 45','AP 101','RES',11001,501,'2024-01-15',36,1,2),
(300002,90001,20001,'CL 22 27 45','AP 101','RES',11001,502,'2024-06-01',30,1,2),
(300003,90001,20001,'CL 22 27 45','AP 101','RES',11001,503,'2024-09-01',27,0,2),
(300004,90001,20001,'KR 15 80 22','OF 301','LAB',11001,501,'2025-06-01',6,0,1),
(300005,90001,20001,'KR 15 80 22','OF 301','LAB',11001,502,'2025-08-01',4,0,1),
(300006,90002,20002,'TV 70 114 55','BR SUBA','RES',11001,501,'2022-03-01',48,1,1),
(300007,90002,20002,'TV 70 114 55','BR SUBA','RES',11001,502,'2022-06-01',45,1,1),
(300008,90002,20002,'TV 70 114 55','BR SUBA','RES',11001,503,'2023-01-01',38,1,1),
(300009,90002,20002,'TV 70 114 55','BR SUBA','RES',11001,504,'2023-06-01',32,0,1),
(300010,90002,20002,'TV 70 114 55','BR SUBA','RES',11001,505,'2024-01-01',26,1,1),
(300011,90002,20002,'TV 70 114 55','BR SUBA','RES',11001,506,'2024-06-01',20,0,1),
(300012,90002,20002,'TV 70 114 55','BR SUBA','RES',11001,507,'2024-09-01',17,1,1),
(300013,90002,20002,'TV 70 114 55','BR SUBA','RES',11001,508,'2025-01-01',12,0,1),
(300014,90003,20003,'DG 50 30 10','TO 3','CRR',11001,501,'2024-06-01',12,0,3),
(300015,90003,20003,'DG 50 30 10','TO 3','CRR',11001,502,'2024-09-01',9,1,3),
(300016,90003,20003,'DG 50 30 10','TO 3','CRR',11001,503,'2025-01-01',6,0,3),
(300017,90003,20003,'KR 7 45 12','AP 504','RES',11001,501,'2025-09-01',3,0,3),
(300018,90003,20003,'AC 40 12 08','ED GALICIA','LAB',11001,501,'2024-01-01',24,1,3),
(300019,90003,20003,'AC 40 12 08','ED GALICIA','LAB',11001,502,'2024-06-01',18,1,3),
(300020,90003,20003,'AC 40 12 08','ED GALICIA','LAB',11001,503,'2024-09-01',15,0,3),
(300021,90003,20003,'AC 40 12 08','ED GALICIA','LAB',11001,504,'2025-01-01',12,1,3);

INSERT INTO bdm_datos.insumo_telefono VALUES
(400001,90004,20004,'CL 10 20 30',11001,'VALIDA',601,'2024-01-15',36,1,1,'FIJA'),
(400002,90004,20004,'CL 10 20 30',11001,'VALIDA',602,'2024-06-01',30,1,1,'FIJA'),
(400003,90004,20004,'CL 10 20 30',11001,'VALIDA',603,'2025-01-01',12,0,0,'FIJA'),
(400004,90004,20004,'KR 20 55 18',11001,'NO VALIDA',604,'2025-06-01',6,0,0,'FIJA'),
(400005,90005,20005,'TV 30 15 40',11001,'VALIDA',601,'2023-06-01',24,1,1,'FIJA'),
(400006,90005,20005,'TV 30 15 40',11001,'VALIDA',602,'2024-01-01',18,0,1,'FIJA');

INSERT INTO bdm_datos.insumo_celular VALUES
(500001,90006,20006,'3101234567','CL 22 27 45',701,'2024-03-01',24,'310',1,'PREPAGO'),
(500002,90006,20006,'3101234567','CL 22 27 45',702,'2024-09-01',18,'310',0,'PREPAGO'),
(500003,90006,20006,'3209876543','KR 15 80 22',703,'2025-06-01',6,'320',0,'POSPAGO'),
(500004,90007,20007,'3001112233','TV 70 114 55',701,'2024-01-01',18,'300',1,'POSPAGO'),
(500005,90007,20007,'3001112233','TV 70 114 55',702,'2024-06-01',12,'300',1,'POSPAGO');

INSERT INTO bdm_datos.insumo_email VALUES
(600001,90008,20008,'user1@gmail.com','gmail.com',801,'2024-01-01',24,1,'PERSONAL'),
(600002,90008,20008,'user1@gmail.com','gmail.com',802,'2024-06-01',18,1,'PERSONAL'),
(600003,90008,20008,'work@empresa.co','empresa.co',803,'2025-06-01',6,0,'CORPORATIVO'),
(600004,90009,20009,'otro@hotmail.com','hotmail.com',801,'2024-03-01',18,0,'PERSONAL'),
(600005,90009,20009,'otro@hotmail.com','hotmail.com',802,'2025-01-01',12,0,'PERSONAL');

-- RPUs destino consolidación (cod_dw_ubic ficticio = cod_dw_persona_ubic)
INSERT INTO bdm_datos.relacion_persona_ubicacion (
  cod_dw_persona_ubic, cod_pin_persona, id_buro_persona, cod_dw_ubic,
  orden_prioridad, fecha_relacion_persona_ubicaci, ind_unificacion
)
SELECT DISTINCT cod_dw_persona_ubic, cod_pin_persona, id_buro_persona, cod_dw_persona_ubic,
  CAST(NULL AS INTEGER), CURRENT_DATE, CAST(NULL AS INTEGER)
FROM (
  SELECT cod_dw_persona_ubic, cod_pin_persona, id_buro_persona FROM bdm_datos.insumo_direccion
  UNION
  SELECT cod_dw_persona_ubic, cod_pin_persona, id_buro_persona FROM bdm_datos.insumo_telefono
  UNION
  SELECT cod_dw_persona_ubic, cod_pin_persona, id_buro_persona FROM bdm_datos.insumo_celular
  UNION
  SELECT cod_dw_persona_ubic, cod_pin_persona, id_buro_persona FROM bdm_datos.insumo_email
) u;

ANALYZE bdm_datos.insumo_direccion;
ANALYZE bdm_datos.insumo_telefono;
ANALYZE bdm_datos.insumo_celular;
ANALYZE bdm_datos.insumo_email;
ANALYZE bdm_datos.relacion_persona_ubicacion;

SELECT 'insumo_dir' AS t, COUNT(*) FROM bdm_datos.insumo_direccion
UNION ALL SELECT 'insumo_tel', COUNT(*) FROM bdm_datos.insumo_telefono
UNION ALL SELECT 'insumo_cel', COUNT(*) FROM bdm_datos.insumo_celular
UNION ALL SELECT 'insumo_ema', COUNT(*) FROM bdm_datos.insumo_email
UNION ALL SELECT 'rpu_destino', COUNT(*) FROM bdm_datos.relacion_persona_ubicacion;

-- Ejecutar scoring vía SPs:
-- CALL bdm_datos.sp_ordenamiento_ejecucion(FALSE);
