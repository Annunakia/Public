-- ============================================================
-- 03_insumo_dir_desde_stage.sql
-- Pobla bdm_datos.insumo_direccion desde mock unificación (bdm_stage)
-- PRECONDICIONES:
--   1. 01_bdm_stage_mock_setup + unificación R1/R2/R3 ejecutada
--   2. 01_ordenamiento_schemas.sql (tabla insumo_direccion existe)
-- Solo RPUs ganadoras: ind_unificacion <> 1
-- ============================================================

TRUNCATE TABLE bdm_datos.insumo_direccion;

INSERT INTO bdm_datos.insumo_direccion (
  cod_dw_persona_ubic,
  cod_pin_persona,
  id_buro_persona,
  direccion_fisica,
  complemento,
  tipo_ubicacion,
  cod_dane_ciudad,
  id_buro_suscriptor,
  fecha_reporte,
  meses_reporte,
  sector_financiero,
  conteo_direcciones
)
SELECT
  rpu.cod_dw_persona_ubic,
  rpu.cod_pin_persona,
  rpu.id_buro_persona,
  ubi.texto_ubicacion AS direccion_fisica,
  df.complemento,
  tud.descripcion_tipo_ubicacion_dir AS tipo_ubicacion,
  ubi.cod_dw_ciudad AS cod_dane_ciudad,
  rep.id_buro_suscriptor,
  rep.fecha_reporte,
  GREATEST(
    DATEDIFF(month, rep.fecha_reporte, CURRENT_DATE),
    0
  ) AS meses_reporte,
  -- Mock sector financiero: suscriptores >= 901 (mock unificación usa 900=no fin, 901+=fin)
  CASE WHEN rep.id_buro_suscriptor >= 901 THEN 1 ELSE 0 END AS sector_financiero,
  dir_cnt.conteo_direcciones
FROM bdm_stage.relacion_persona_ubicacion rpu
INNER JOIN bdm_stage.ubicacion_estandarizada ubi
  ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df
  ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
INNER JOIN bdm_stage.tipo_ubicacion_dir tud
  ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
INNER JOIN bdm_stage.reporte_relacion_persona_ubica rep
  ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
INNER JOIN (
  SELECT
    id_buro_persona,
    COUNT(DISTINCT ubi2.texto_ubicacion) AS conteo_direcciones
  FROM bdm_stage.relacion_persona_ubicacion r2
  INNER JOIN bdm_stage.ubicacion_estandarizada ubi2
    ON r2.cod_dw_ubic = ubi2.cod_dw_ubic
  WHERE COALESCE(r2.ind_unificacion, 0) <> 1
  GROUP BY 1
) dir_cnt
  ON dir_cnt.id_buro_persona = rpu.id_buro_persona
WHERE COALESCE(rpu.ind_unificacion, 0) <> 1;

ANALYZE bdm_datos.insumo_direccion;

-- Gate rápido
SELECT COUNT(*) AS filas_insumo_dir FROM bdm_datos.insumo_direccion;
SELECT COUNT(DISTINCT id_buro_persona) AS personas FROM bdm_datos.insumo_direccion;
