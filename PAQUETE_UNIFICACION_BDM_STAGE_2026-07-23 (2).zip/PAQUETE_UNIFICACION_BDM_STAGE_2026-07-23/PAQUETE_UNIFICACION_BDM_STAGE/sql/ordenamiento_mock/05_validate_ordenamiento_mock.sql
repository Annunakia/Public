-- ============================================================
-- 05_validate_ordenamiento_mock.sql
-- Gates de volumen y coherencia post-carga de insumos
-- ============================================================

SELECT 'beta_ordenamiento' AS objeto, COUNT(*) AS filas
FROM bdm_datos.beta_ordenamiento
UNION ALL
SELECT 'insumo_direccion', COUNT(*) FROM bdm_datos.insumo_direccion
UNION ALL
SELECT 'insumo_telefono', COUNT(*) FROM bdm_datos.insumo_telefono
UNION ALL
SELECT 'insumo_celular', COUNT(*) FROM bdm_datos.insumo_celular
UNION ALL
SELECT 'insumo_email', COUNT(*) FROM bdm_datos.insumo_email
UNION ALL
SELECT 'rpu_ganadoras_bdm_datos', COUNT(*) FROM bdm_datos.relacion_persona_ubicacion;

-- Personas con los 4 canales
SELECT COUNT(*) AS personas_4_canales
FROM (
  SELECT id_buro_persona FROM bdm_datos.insumo_direccion GROUP BY 1
  INTERSECT
  SELECT id_buro_persona FROM bdm_datos.insumo_telefono GROUP BY 1
  INTERSECT
  SELECT id_buro_persona FROM bdm_datos.insumo_celular GROUP BY 1
  INTERSECT
  SELECT id_buro_persona FROM bdm_datos.insumo_email GROUP BY 1
) x;

-- RPUs insumo ⊆ RPUs ganadoras (consolidación no falla en silencio)
SELECT COUNT(*) AS insumos_sin_rpu
FROM (
  SELECT cod_dw_persona_ubic FROM bdm_datos.insumo_direccion
  UNION
  SELECT cod_dw_persona_ubic FROM bdm_datos.insumo_telefono
  UNION
  SELECT cod_dw_persona_ubic FROM bdm_datos.insumo_celular
  UNION
  SELECT cod_dw_persona_ubic FROM bdm_datos.insumo_email
) i
LEFT JOIN bdm_datos.relacion_persona_ubicacion r
  ON i.cod_dw_persona_ubic = r.cod_dw_persona_ubic
WHERE r.cod_dw_persona_ubic IS NULL;

-- Distribución TEL gestión
SELECT descripcion_gestion, COUNT(*) AS filas
FROM bdm_datos.insumo_telefono
GROUP BY 1
ORDER BY 2 DESC;

-- Muestra por persona (top 5 scores tras scoring — ejecutar después de 02-06 Public)
-- SELECT id_buro_persona, canal, score, lugar
-- FROM bdm_datos.score_ordenamiento
-- ORDER BY id_buro_persona, lugar
-- LIMIT 20;
