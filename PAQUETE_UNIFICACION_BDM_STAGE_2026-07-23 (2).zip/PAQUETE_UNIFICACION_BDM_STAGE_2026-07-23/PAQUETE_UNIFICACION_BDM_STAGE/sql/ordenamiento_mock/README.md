# Ordenamiento — mock alto (20K)

Base de prueba enlazada al mock de **Unificación** (`bdm_stage`). Genera insumos para los 4 canales (DIR/TEL/CEL/EMA) a escala completa.

## Orden de ejecución

### 1. Unificación (si no está hecha)

```
sql/benchmark_20k/A_data_load_sintetico.sql
sql/02_unificacion_sql_plano.sql
```

Gate: ~20.000 personas, ~40.000+ RPU post-motor.

### 2. Mock ordenamiento

| # | Script | Qué hace |
|---|--------|----------|
| 01 | `01_schemas.sql` | DDL `bdm_datos.*` + `relacion_persona_ubicacion` destino |
| 02 | `02_mock_betas.sql` | 47 betas DIR/TEL/CEL/EMA |
| 02b | `02b_sync_rpu_ganadoras.sql` | Copia RPUs ganadoras → `bdm_datos` (consolidación) |
| 03 | `03_insumo_dir_desde_stage.sql` | DIR desde mock unificación |
| 04 | `04_insumo_tel_cel_ema_sintetico.sql` | TEL/CEL/EMA sintéticos (deterministas) |
| 05 | `05_validate_ordenamiento_mock.sql` | Gates volumen/coherencia |

### 3. Scoring vía SPs (recomendado)

Desplegar `sql/ordenamiento/10`–`16` (ver `sql/ordenamiento/README.md`).

```sql
-- Smoke 9 personas (insumos ya cargados):
CALL bdm_datos.sp_ordenamiento_ejecucion(FALSE);

-- Mock alto 20K (post-unificación bdm_stage):
CALL bdm_datos.sp_ordenamiento_ejecucion(TRUE);
```

Alternativa SQL plano Public-main: `02_scoring_dir` … `06_consolidacion`.

## Volúmenes esperados @ 20K

| Insumo | Origen | Escala aprox. |
|--------|--------|---------------|
| DIR | Reportes RPUs ganadoras | ~40K–80K filas |
| TEL | 1:1 con reportes DIR | ~40K–80K filas |
| CEL | 1–3 celulares × 2–5 reportes/persona | ~80K–200K filas |
| EMA | 1–3 emails × 2–5 reportes/persona | ~80K–200K filas |

## Smoke (9 personas)

Antes de escalar, usar `Public-main/.../mock_data_ordenamiento.sql` tras `01`+`02` (sin 03/04).

## Runner Python (opcional)

```powershell
$env:REDSHIFT_PASSWORD="..."
python tools/ordenamiento_mock_run.py
python tools/ordenamiento_mock_run.py --with-scoring
```

## Análisis

`Documentacion/ANALISIS_ORDENAMIENTO_MOCK.md`
