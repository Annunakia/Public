-- ============================================================
-- 04_cleanup.sql
-- Limpieza para repetir la prueba MOCK en sandbox.
-- NO usar en develop del cliente (borraría fuentes reales).
-- ============================================================

DROP TABLE IF EXISTS bdm_tempo.stg_regla1_insumo;
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_scored;
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_pares;

DROP TABLE IF EXISTS bdm_tempo.stg_regla2_insumo;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_esc1_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e1;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_esc2_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e2;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03_a;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03_e1;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_a;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_c1;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_e;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_a;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_freq;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_pares;

DROP TABLE IF EXISTS bdm_tempo.stg_regla3_insumo;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_diccionario_via;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_scored;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_ranked;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_ganadores;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_resultado;

TRUNCATE TABLE bdm_stage.unificacion_direccion;

DROP TABLE IF EXISTS bdm_stage.tipo_ubicacion_dir;
DROP TABLE IF EXISTS bdm_stage.nomenclatura;
DROP TABLE IF EXISTS bdm_stage.ubicacion_estandarizada;
DROP TABLE IF EXISTS bdm_stage.direccion_fisica;
DROP TABLE IF EXISTS bdm_stage.relacion_persona_ubicacion;
DROP TABLE IF EXISTS bdm_stage.ciiu_persona;
DROP TABLE IF EXISTS bdm_stage.reporte_relacion_persona_ubica;
DROP TABLE IF EXISTS bdm_stage.diccionario_complementos;
DROP TABLE IF EXISTS bdm_stage.diccionario_via;
