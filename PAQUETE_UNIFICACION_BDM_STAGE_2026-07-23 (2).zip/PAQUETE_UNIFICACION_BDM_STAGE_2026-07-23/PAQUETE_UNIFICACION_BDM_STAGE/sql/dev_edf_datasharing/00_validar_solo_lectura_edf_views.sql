-- Gate lectura ds_dba_rncr_batch.edf_views (sin relationalizelastupdate)
SELECT paso, total FROM (
  SELECT '01_ds_dba_rncr_batch.edf_views.xpm' AS paso, COUNT(*)::BIGINT AS total
  FROM ds_dba_rncr_batch.edf_views.xpm
  UNION ALL SELECT '02_xpm_location', COUNT(*) FROM ds_dba_rncr_batch.edf_views.xpm_location
  UNION ALL SELECT '03_xpm_ci', COUNT(*) FROM ds_dba_rncr_batch.edf_views.xpm_location_val_contactinformations
  UNION ALL SELECT '04_xpm_cp', COUNT(*) FROM ds_dba_rncr_batch.edf_views.xpm_counterparties
  UNION ALL
  SELECT '05_xpm_con_location', COUNT(*)
  FROM ds_dba_rncr_batch.edf_views.xpm xpm
  JOIN ds_dba_rncr_batch.edf_views.xpm_location loc ON xpm.location = loc.id
  UNION ALL
  SELECT '06_join_contactos_tipo_8', COUNT(*)
  FROM ds_dba_rncr_batch.edf_views.xpm xpm
  JOIN ds_dba_rncr_batch.edf_views.xpm_location loc ON xpm.location = loc.id
  JOIN ds_dba_rncr_batch.edf_views.xpm_location_val_contactinformations ci
    ON loc."location.val.contactinformations" = ci.id
  WHERE NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::VARCHAR), '') = '8'
  UNION ALL
  SELECT '07_vista_contacto_direccion', COUNT(*)
  FROM bdm_tempo.v_xpm_contacto_direccion
  UNION ALL
  SELECT '08_vista_reportes', COUNT(*)
  FROM bdm_tempo.v_xpm_reporte_relacion_persona_ubica
) q
ORDER BY paso;
