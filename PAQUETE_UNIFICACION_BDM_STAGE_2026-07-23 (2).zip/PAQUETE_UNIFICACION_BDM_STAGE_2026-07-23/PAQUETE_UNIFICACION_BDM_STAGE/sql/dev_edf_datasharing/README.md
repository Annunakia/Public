# Data Sharing DEV→DEV — `edf_views` → Reconocer

Fuente confirmada por el equipo: **`edf_views.xpm_*`** en procesosbatch DEV.

## Orden de trabajo

| # | Quién | Script |
|---|-------|--------|
| 1 | Consumidor | `SELECT pg_get_cluster_namespace();` → enviar namespace al DBA productor |
| 2 | **DBA productor** (`dba_batch`) | `00_datashare_producer.sql` |
| 3 | **DBA consumidor** (`dba_rncr_batch`) | `00_datashare_consumer.sql` → BD compartida `ds_dba_rncr_batch` |
| 4 | **DBA consumidor** | `00_grants_dba_reconocer.sql` |
| 5 | Equipo | `py -3 tools/dev_edf_datasharing_run.py` |

## Runner

```powershell
$env:REDSHIFT_CONSUMER_PASSWORD="gl51TGx4nFhD"
$env:REDSHIFT_PRODUCER_PASSWORD="b27YWI2FL"
py -3 tools/dev_edf_datasharing_run.py --preflight-only
py -3 tools/dev_edf_datasharing_run.py
```

Ticket DBA: `Documentacion/TICKET_DATASHARING_EDF_VIEWS_DEV.md`

Drill-down Excel: `Documentacion/MAPA_UNIFICACION_EDF_VIEWS_NEGOCIO_DETALLADO.xlsx` · SQL: `00_drill_down_validaciones.sql`
