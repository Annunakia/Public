-- ============================================================
-- PRODUCTOR DEV — Data Sharing edf_views → Reconocer DEV
-- Cluster: eec-aws-us-eits-procesosbatch-dev-redshift (cee2enck00mg)
-- Cuenta AWS: 651706752126
-- Database: dba_batch
-- Rol: ADMIN productor
-- ============================================================
-- Configuración validada: datashare ds_reconocer_procesosbatch_dev
-- publica schema edf_views completo (34 tablas). Unificación usa 4 tablas XPM.

-- Paso 0 (consumidor): SELECT pg_get_cluster_namespace(); entregar al DBA productor

-- CREATE DATASHARE ds_reconocer_procesosbatch_dev;
-- ALTER DATASHARE ds_reconocer_procesosbatch_dev ADD SCHEMA edf_views;

-- Tablas mínimas Unificación R1/R2/R3:
-- ALTER DATASHARE ds_reconocer_procesosbatch_dev ADD TABLE edf_views.xpm;
-- ALTER DATASHARE ds_reconocer_procesosbatch_dev ADD TABLE edf_views.xpm_location;
-- ALTER DATASHARE ds_reconocer_procesosbatch_dev ADD TABLE edf_views.xpm_location_val_contactinformations;
-- ALTER DATASHARE ds_reconocer_procesosbatch_dev ADD TABLE edf_views.xpm_counterparties;

-- Cross-account consumidor Reconocer (647096294147):
-- ALTER DATASHARE ds_reconocer_procesosbatch_dev ADD ACCOUNT '647096294147' NAMESPACE '<NAMESPACE_RECONOCER_DEV>';

SELECT share_name, producer_account, producer_namespace
FROM svv_datashares
WHERE share_name = 'ds_reconocer_procesosbatch_dev';

SELECT share_name, object_name, object_type
FROM svv_datashare_objects
WHERE share_name = 'ds_reconocer_procesosbatch_dev'
ORDER BY object_name;

SELECT 'edf_views.xpm' AS t, COUNT(*) AS n FROM edf_views.xpm
UNION ALL SELECT 'edf_views.xpm_ci', COUNT(*) FROM edf_views.xpm_location_val_contactinformations;
