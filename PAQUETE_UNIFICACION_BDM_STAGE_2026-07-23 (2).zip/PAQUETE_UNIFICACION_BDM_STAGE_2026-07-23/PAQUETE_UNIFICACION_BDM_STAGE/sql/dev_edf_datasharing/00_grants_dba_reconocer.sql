-- ============================================================
-- 00_grants_dba_reconocer.sql — consumidor Reconocer DEV
-- Database sesión: dba_rncr_batch | Usuario: c32525e
-- BD compartida: ds_dba_rncr_batch
-- ============================================================

CREATE SCHEMA IF NOT EXISTS bdm_datos;
CREATE SCHEMA IF NOT EXISTS bdm_tempo;

GRANT USAGE ON SCHEMA bdm_datos TO c32525e;
GRANT USAGE ON SCHEMA bdm_tempo TO c32525e;
GRANT CREATE ON SCHEMA bdm_datos TO c32525e;
GRANT CREATE ON SCHEMA bdm_tempo TO c32525e;

GRANT USAGE ON DATABASE ds_dba_rncr_batch TO c32525e;
GRANT USAGE ON SCHEMA ds_dba_rncr_batch.edf_views TO c32525e;
GRANT SELECT ON ALL TABLES IN SCHEMA ds_dba_rncr_batch.edf_views TO c32525e;

SELECT has_schema_privilege('c32525e', 'bdm_datos', 'CREATE') AS can_create_bdm_datos;
SELECT has_schema_privilege('c32525e', 'bdm_tempo', 'CREATE') AS can_create_bdm_tempo;
