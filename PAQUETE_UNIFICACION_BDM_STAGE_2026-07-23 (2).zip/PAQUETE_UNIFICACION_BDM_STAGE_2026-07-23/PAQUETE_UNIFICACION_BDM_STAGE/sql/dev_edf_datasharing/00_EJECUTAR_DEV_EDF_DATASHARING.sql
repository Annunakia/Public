-- ============================================================
-- 00_EJECUTAR_DEV_EDF_DATASHARING.sql
-- Orden despliegue DEV→DEV — Reconocer + edf_views datashare
-- Ref: Documentacion/TICKET_DATASHARING_EDF_VIEWS_DEV.md
-- ============================================================

-- PRECONDICIÓN DBA productor: sql/dev_edf_datasharing/00_datashare_producer.sql
-- PRECONDICIÓN DBA consumidor: 00_datashare_consumer.sql + 00_grants_dba_reconocer.sql

-- 0  sql/dev_edf_datasharing/00_prerequisitos_dev.sql
-- 1  sql/dev_edf_datasharing/01_ddl_unificacion_direccion.sql
-- 2  sql/dev_edf_datasharing/00_vistas_insumo_bdm.sql   → ds_dba_rncr_batch.edf_views.*
-- 3  sql/dev_edf_datasharing/00_validar_solo_lectura_edf_views.sql
-- 4  sql/qa_ifr_data/05_sp_regla1.sql
-- 5  sql/qa_ifr_data/06_sp_regla2.sql
-- 6  sql/qa_ifr_data/07_sp_regla3.sql
-- 7  sql/qa_ifr_data/08_ejecucion_secuencial.sql
-- 8  sql/qa_ifr_data/03_validaciones_unificacion.sql
