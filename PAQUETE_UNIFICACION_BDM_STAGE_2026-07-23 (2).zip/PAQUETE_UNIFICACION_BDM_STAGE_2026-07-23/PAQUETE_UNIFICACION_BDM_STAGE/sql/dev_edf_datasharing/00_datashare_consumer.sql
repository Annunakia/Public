-- ============================================================
-- CONSUMIDOR DEV — Montar edf_views compartido
-- Cluster: eec-aws-us-eits-reconocerbatch-dev-redshift (cz7jl1sn7m8z)
-- Cuenta AWS: 647096294147
-- Database sesión local: dba_rncr_batch
-- Rol: ADMIN consumidor
-- ============================================================
-- NOTA: dba_rncr_batch ya existe como BD local. Redshift no permite
-- dos BD con el mismo nombre; la compartida quedó como ds_dba_rncr_batch.

-- Namespace consumidor (entregar al productor):
-- SELECT pg_get_cluster_namespace() AS namespace_consumidor_reconocer_dev;

-- Cross-account (configuración validada Leonardo):
-- CREATE DATABASE ds_dba_rncr_batch
-- FROM DATASHARE ds_reconocer_procesosbatch_dev
-- OF ACCOUNT '651706752126'
-- NAMESPACE '<NAMESPACE_PRODUCTOR_DEV>';

SELECT * FROM svv_external_databases WHERE database_name = 'ds_dba_rncr_batch';
SELECT database_name, schema_name FROM svv_external_schemas WHERE database_name = 'ds_dba_rncr_batch';
SELECT database_name, schemaname, tablename
FROM svv_external_tables
WHERE database_name = 'ds_dba_rncr_batch'
ORDER BY tablename;

-- Gate lectura (4 tablas XPM usadas por Unificación)
SELECT 'xpm' AS t, COUNT(*) AS n FROM ds_dba_rncr_batch.edf_views.xpm
UNION ALL SELECT 'xpm_location', COUNT(*) FROM ds_dba_rncr_batch.edf_views.xpm_location
UNION ALL SELECT 'xpm_ci', COUNT(*) FROM ds_dba_rncr_batch.edf_views.xpm_location_val_contactinformations
UNION ALL SELECT 'xpm_cp', COUNT(*) FROM ds_dba_rncr_batch.edf_views.xpm_counterparties;
