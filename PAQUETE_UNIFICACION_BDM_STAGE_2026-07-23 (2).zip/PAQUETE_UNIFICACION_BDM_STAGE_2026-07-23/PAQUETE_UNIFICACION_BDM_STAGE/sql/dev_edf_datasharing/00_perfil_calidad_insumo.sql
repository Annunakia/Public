-- ============================================================
-- 00_perfil_calidad_insumo.sql
-- Data profiling insumo edf_views → vistas bdm_tempo (DEV)
-- Vacíos, NULL y columnas a revisar antes de R1/R2/R3
-- Ejecutar en dba_rncr_batch (solo lectura)
-- ============================================================

-- P0) Universo
SELECT COUNT(*)::BIGINT AS rpus
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion;

-- P1) Complemento (R2)
SELECT
  CASE
    WHEN df.complemento IS NULL THEN 'NULL'
    WHEN LENGTH(TRIM(df.complemento)) = 0 THEN 'VACIO'
    ELSE 'CON_VALOR'
  END AS estado_complemento,
  COUNT(*)::BIGINT AS n
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_direccion_fisica df
  ON df.cod_dw_direccion_fisica = rpu.cod_dw_persona_ubic
GROUP BY 1
ORDER BY 1;

-- P2) Texto ubicación
SELECT
  CASE
    WHEN ubi.texto_ubicacion IS NULL OR LENGTH(TRIM(ubi.texto_ubicacion)) = 0 THEN 'VACIO'
    ELSE 'OK'
  END AS estado_texto,
  COUNT(*)::BIGINT AS n
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
GROUP BY 1;

-- P3) Geo (R3)
SELECT
  SUM(CASE WHEN ubi.latitud IS NOT NULL AND ubi.longitud IS NOT NULL THEN 1 ELSE 0 END)::BIGINT AS con_geo,
  SUM(CASE WHEN ubi.latitud IS NULL OR ubi.longitud IS NULL THEN 1 ELSE 0 END)::BIGINT AS sin_geo,
  COUNT(*)::BIGINT AS total
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic;

-- P4) CIIU persona (R1)
SELECT
  SUM(CASE WHEN ciiu.cod_act_econo_ciiu_fte IS NULL OR TRIM(ciiu.cod_act_econo_ciiu_fte) = '' THEN 1 ELSE 0 END)::BIGINT AS sin_ciiu,
  COUNT(*)::BIGINT AS total
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
LEFT JOIN bdm_tempo.v_xpm_ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona;

-- P5) Score estandarización
SELECT
  SUM(CASE WHEN cd.score_estandarizacion IS NULL THEN 1 ELSE 0 END)::BIGINT AS sin_score,
  COUNT(*)::BIGINT AS total
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_contacto_direccion cd ON cd.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

-- P6) Ciudad / DANE
SELECT
  SUM(CASE WHEN ubi.cod_dw_ciudad IS NULL THEN 1 ELSE 0 END)::BIGINT AS sin_ciudad,
  COUNT(*)::BIGINT AS total
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
JOIN bdm_tempo.v_xpm_ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic;

-- P7) Contacttype crudo edf_views
SELECT
  CASE
    WHEN NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::VARCHAR), '') IS NULL THEN 'NULL'
    WHEN NULLIF(TRIM(ci."location.val.contactinformations.val.contacttype"::VARCHAR), '') IN ('1','2','3','7','8') THEN 'CATALOGO'
    ELSE 'FUERA_CATALOGO'
  END AS estado_ct,
  COUNT(*)::BIGINT AS n
FROM ds_dba_rncr_batch.edf_views.xpm xpm
JOIN ds_dba_rncr_batch.edf_views.xpm_location loc ON xpm.location = loc.id
JOIN ds_dba_rncr_batch.edf_views.xpm_location_val_contactinformations ci
  ON loc."location.val.contactinformations" = ci.id
GROUP BY 1
ORDER BY 1;
