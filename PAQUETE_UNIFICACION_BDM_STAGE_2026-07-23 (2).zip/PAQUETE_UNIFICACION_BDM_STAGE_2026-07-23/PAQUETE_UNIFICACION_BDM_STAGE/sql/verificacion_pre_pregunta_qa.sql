-- ============================================================
-- Verificación ANTES de preguntar a QA (Julian / TC-R2-14 / R3)
-- Ejecutar en DOS conexiones distintas (ver comentarios).
-- Una query por ejecución (Ctrl+Enter) o todo el bloque de una sección.
-- ============================================================

-- ─────────────────────────────────────────────────────────────
-- A) RECONOCER DEV — conexión: reconocer consumidor dev
--    Database: dba_rncr_batch  (NO dba_batch productor)
-- ─────────────────────────────────────────────────────────────

-- A1. Unificación real por regla (sign-off edf_views)
SELECT unifica_atributos, COUNT(*) AS total
FROM bdm_datos.unificacion_direccion
GROUP BY 1
ORDER BY 1;
-- Esperado: regla 2 ~72448, regla 3 = 0 (datos reales sin geo)

-- A2. Calidad C03 / C04 (deben ser 0)
SELECT
  SUM(CASE WHEN cod_dw_direccion_unificada IS NULL THEN 1 ELSE 0 END) AS c03_hijos_sin_padre,
  SUM(CASE WHEN cod_dw_persona_ubic = cod_dw_direccion_unificada THEN 1 ELSE 0 END) AS c04_autoreferencia
FROM bdm_datos.unificacion_direccion;


-- ─────────────────────────────────────────────────────────────
-- B) QA — conexión: QA (procesosbatch-qa)
--    Database: dba_batch
-- ─────────────────────────────────────────────────────────────

-- B1. ¿Existe mock 20K? (si 0 → suite TC no aplica)
SELECT COUNT(*) AS tabla_perf_existe
FROM information_schema.tables
WHERE table_schema = 'bdm_stage' AND table_name = 'perf_persona_meta';

-- B2. TC-R2-14 — violaciones empate R2 (Julian reportó 1200)
SELECT COUNT(*) AS tc_r2_14_violaciones
FROM bdm_stage.perf_persona_meta m
WHERE m.scenario_code = 'R2_EMPATE'
  AND EXISTS (
    SELECT 1
    FROM bdm_stage.relacion_persona_ubicacion r
    JOIN bdm_stage.unificacion_direccion u
      ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic
     AND u.unifica_atributos = 2
    WHERE r.id_buro_persona = m.id_buro_persona
  );
-- 0 = OK | 1200 = gap conocido mock 20K | error tabla = no corrieron mock

-- B3. ¿Hay datos geo para R3?
SELECT COUNT(*) AS rpu_con_lat_long
FROM bdm_stage.relacion_persona_ubicacion
WHERE latitud IS NOT NULL AND longitud IS NOT NULL;
-- 0 = R3 bloqueado por datos (lo que dijo Julian)

-- B4. Unificaciones mock por regla (si aplica)
SELECT unifica_atributos, COUNT(*) AS total
FROM bdm_stage.unificacion_direccion
GROUP BY 1
ORDER BY 1;
