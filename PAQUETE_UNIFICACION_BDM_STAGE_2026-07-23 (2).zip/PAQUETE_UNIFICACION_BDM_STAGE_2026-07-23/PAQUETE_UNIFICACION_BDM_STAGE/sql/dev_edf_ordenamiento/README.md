# Ordenamiento Fase 1 — datashare edf_views (Reconocer consumidor)

## Ejecutar

```powershell
$env:REDSHIFT_CONSUMER_PASSWORD="..."
py -3 tools/dev_edf_ordenamiento_run.py
```

**Precondición:** unificación R1/R2/R3 ya corrida (`dev_edf_datasharing_run.py`).

## Scripts (`sql/dev_edf_ordenamiento/`)

| # | Archivo | Qué hace |
|---|---------|----------|
| 1 | `01_ddl_ordenamiento.sql` | Tablas insumo/score/RPU (`BIGINT` id_buro_persona) |
| 2 | `02_mock_betas.sql` | 47 betas snapshot local |
| 3 | `03_vistas_contacto_canal.sql` | Vista TEL/CEL/EMA desde datashare |
| 4 | `04_vistas_sin_copia_productor.sql` | Contrato lectura: vistas `insumo_*` + `v_rpu_post_unificacion` |
| 5 | `05_sp_preparar_insumos_edf.sql` | Staging **temporal** `bdm_tempo.stg_*` + ANALYZE (1 pasada datashare) |
| — | `08_sp_drop_staging_ordenamiento_edf.sql` | Limpieza staging al cerrar corrida |
| — | `11–14_sp_*_edf.sql` | Scoring sobre staging (generar: `py -3 tools/gen_ordenamiento_sps_edf.py`) |
| — | `00_validar_fase1.sql` | Gate conteos |

## contactType → canal

| Types | Canal |
|-------|-------|
| 1,2,3,7,8 | DIR (unificación) |
| 4,5,8 | TEL |
| 9 | CEL |
| 10 | EMA |

TEL/CEL/EMA solo para personas con DIR ganadora post-unificación.

## Fase 2 — scoring (consumidor)

```powershell
py -3 tools/dev_edf_ordenamiento_run.py              # Fase 1 + 2
py -3 tools/dev_edf_ordenamiento_run.py --fase2-only  # solo scoring
CALL bdm_datos.sp_ordenamiento_ejecucion_edf(TRUE);  -- preparar stg + scoring + drop
```

**Rendimiento DEV (misma lógica, mismos 1.223.998 scores):** ~18 s total vs ~180 s leyendo vistas en cada SP vs ~12 s con tablas permanentes (no escalable).

Evidencias completas: `Documentacion/Evidencias_DEV_ORDENAMIENTO_EDF_COMPLETO.md`

Arquitectura: `Documentacion/ARQUITECTURA_DATASHARING_LECTURA_PRODUCTOR.md`

Mapa interactivo: `Documentacion/MAPA_ORDENAMIENTO_EDF_VIEWS_NEGOCIO.html` · `py -3 tools/export_mapa_ordenamiento_html.py`

Legacy (copia tablas, no escalable): `py -3 tools/dev_edf_ordenamiento_run.py --legacy-copia`
