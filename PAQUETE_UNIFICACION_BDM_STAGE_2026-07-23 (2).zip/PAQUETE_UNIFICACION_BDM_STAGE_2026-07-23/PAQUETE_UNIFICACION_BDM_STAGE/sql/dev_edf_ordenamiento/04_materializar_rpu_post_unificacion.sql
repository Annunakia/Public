-- ============================================================
-- 04_materializar_rpu_post_unificacion.sql
-- DEPRECADO — usar 04_vistas_sin_copia_productor.sql (lectura datashare, sin copia).
-- Se conserva solo para rollback / comparación legacy (--legacy-copia en runner).
-- ============================================================

TRUNCATE TABLE bdm_datos.relacion_persona_ubicacion;

INSERT INTO bdm_datos.relacion_persona_ubicacion (
  cod_dw_persona_ubic,
  cod_pin_persona,
  id_buro_persona,
  cod_dw_ubic,
  orden_prioridad,
  fecha_relacion_persona_ubicaci,
  ind_unificacion
)
SELECT
  rpu.cod_dw_persona_ubic,
  rpu.cod_pin_persona,
  rpu.id_buro_persona,
  rpu.cod_dw_ubic,
  CAST(NULL AS INTEGER) AS orden_prioridad,
  rpu.fecha_relacion_persona_ubicaci,
  CASE WHEN u.cod_dw_persona_ubic IS NOT NULL THEN 1 ELSE 0 END AS ind_unificacion
FROM bdm_tempo.v_xpm_relacion_persona_ubicacion rpu
LEFT JOIN bdm_datos.unificacion_direccion u
  ON u.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

SELECT
  'rpu_total' AS metric,
  COUNT(*)::BIGINT AS n
FROM bdm_datos.relacion_persona_ubicacion
UNION ALL
SELECT 'rpu_ganadoras', COUNT(*)
FROM bdm_datos.relacion_persona_ubicacion
WHERE COALESCE(ind_unificacion, 0) <> 1
UNION ALL
SELECT 'rpu_hijas_unificacion', COUNT(*)
FROM bdm_datos.relacion_persona_ubicacion
WHERE COALESCE(ind_unificacion, 0) = 1
UNION ALL
SELECT 'personas_ganadoras', COUNT(DISTINCT id_buro_persona)
FROM bdm_datos.relacion_persona_ubicacion
WHERE COALESCE(ind_unificacion, 0) <> 1;
