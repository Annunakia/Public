-- Legacy: materializa insumos en tablas locales (solo --legacy-copia)
CREATE OR REPLACE PROCEDURE bdm_datos.sp_ordenamiento_preparar_insumos_edf()
LANGUAGE plpgsql
AS $$
BEGIN
  TRUNCATE TABLE bdm_datos.insumo_direccion;

  INSERT INTO bdm_datos.insumo_direccion (
    cod_dw_persona_ubic, cod_pin_persona, id_buro_persona, direccion_fisica,
    complemento, tipo_ubicacion, cod_dane_ciudad, id_buro_suscriptor,
    fecha_reporte, meses_reporte, sector_financiero, conteo_direcciones
  )
  SELECT
    rpu.cod_dw_persona_ubic,
    rpu.cod_pin_persona,
    rpu.id_buro_persona,
    cd.texto_ubicacion,
    cd.complemento,
    tud.descripcion_tipo_ubicacion_dir,
    cd.cod_dw_ciudad,
    rep.id_buro_suscriptor,
    rep.fecha_reporte,
    GREATEST(DATEDIFF(month, rep.fecha_reporte, CURRENT_DATE), 0),
    COALESCE(sf.sector_financiero, 0),
    dir_cnt.conteo_direcciones
  FROM bdm_datos.relacion_persona_ubicacion rpu
  INNER JOIN bdm_tempo.v_xpm_contacto_direccion cd
    ON cd.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
  INNER JOIN bdm_datos.tipo_ubicacion_dir tud
    ON cd.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
  INNER JOIN bdm_tempo.v_xpm_reporte_relacion_persona_ubica rep
    ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  LEFT JOIN bdm_datos.catalogo_sector_financiero sf
    ON sf.id_buro_suscriptor = rep.id_buro_suscriptor
  INNER JOIN (
    SELECT r2.id_buro_persona, COUNT(DISTINCT cd2.texto_ubicacion) AS conteo_direcciones
    FROM bdm_datos.relacion_persona_ubicacion r2
    INNER JOIN bdm_tempo.v_xpm_contacto_direccion cd2
      ON cd2.cod_dw_persona_ubic = r2.cod_dw_persona_ubic
    WHERE COALESCE(r2.ind_unificacion, 0) <> 1
    GROUP BY 1
  ) dir_cnt ON dir_cnt.id_buro_persona = rpu.id_buro_persona
  WHERE COALESCE(rpu.ind_unificacion, 0) <> 1;

  TRUNCATE TABLE bdm_datos.insumo_telefono;
  INSERT INTO bdm_datos.insumo_telefono (
    cod_dw_persona_ubic, cod_pin_persona, id_buro_persona, direccion_fisica,
    cod_dane_ciudad, descripcion_gestion, id_buro_suscriptor, fecha_reporte,
    meses_reporte, coincidencia_geo, sector_financiero, tipo_cuenta
  )
  SELECT
    c.cod_dw_persona_ubic, c.cod_pin_persona, c.id_buro_persona,
    COALESCE(ref.dir_ref, c.texto_ubicacion_vinculo, c.valor_contacto),
    c.cod_dane_ciudad,
    CASE WHEN c.valor_contacto ~ '^[0-9]+$' AND LENGTH(TRIM(c.valor_contacto)) >= 7 THEN 'VALIDA' ELSE 'NO VALIDA' END,
    c.id_buro_suscriptor, COALESCE(c.fecha_contacto, CURRENT_DATE),
    GREATEST(DATEDIFF(month, COALESCE(c.fecha_contacto, CURRENT_DATE), CURRENT_DATE), 0),
    0, COALESCE(sf.sector_financiero, 0), COALESCE(tcat.tipo_cuenta, 'FIJA')
  FROM bdm_tempo.v_xpm_contacto_canal c
  INNER JOIN bdm_tempo.v_xpm_persona_dir_ganadora pg ON pg.id_buro_persona = c.id_buro_persona
  LEFT JOIN bdm_datos.catalogo_sector_financiero sf ON sf.id_buro_suscriptor = c.id_buro_suscriptor
  LEFT JOIN bdm_datos.catalogo_tipo_cuenta_tel tcat ON tcat.prefijo_operador = LEFT(LTRIM(c.valor_contacto, '0'), 3)
  LEFT JOIN (
    SELECT r.id_buro_persona, MIN(u.texto_ubicacion) AS dir_ref
    FROM bdm_datos.relacion_persona_ubicacion r
    INNER JOIN bdm_tempo.v_xpm_ubicacion_estandarizada u ON r.cod_dw_ubic = u.cod_dw_ubic
    WHERE COALESCE(r.ind_unificacion, 0) <> 1 GROUP BY 1
  ) ref ON ref.id_buro_persona = c.id_buro_persona
  WHERE c.contact_type IN ('4', '5', '8') AND c.valor_contacto IS NOT NULL;

  TRUNCATE TABLE bdm_datos.insumo_celular;
  INSERT INTO bdm_datos.insumo_celular (
    cod_dw_persona_ubic, cod_pin_persona, id_buro_persona, celular, texto_ubicacion,
    id_buro_suscriptor, fecha_reporte, meses_reporte, operador, sector_financiero, tipo_cuenta
  )
  SELECT
    c.cod_dw_persona_ubic, c.cod_pin_persona, c.id_buro_persona,
    LTRIM(c.valor_contacto, '0'), COALESCE(ref.dir_ref, c.texto_ubicacion_vinculo),
    c.id_buro_suscriptor, COALESCE(c.fecha_contacto, CURRENT_DATE),
    GREATEST(DATEDIFF(month, COALESCE(c.fecha_contacto, CURRENT_DATE), CURRENT_DATE), 0),
    LEFT(LTRIM(c.valor_contacto, '0'), 3), COALESCE(sf.sector_financiero, 0), COALESCE(tcat.tipo_cuenta, 'PREPAGO')
  FROM bdm_tempo.v_xpm_contacto_canal c
  INNER JOIN bdm_tempo.v_xpm_persona_dir_ganadora pg ON pg.id_buro_persona = c.id_buro_persona
  LEFT JOIN bdm_datos.catalogo_sector_financiero sf ON sf.id_buro_suscriptor = c.id_buro_suscriptor
  LEFT JOIN bdm_datos.catalogo_tipo_cuenta_tel tcat ON tcat.prefijo_operador = LEFT(LTRIM(c.valor_contacto, '0'), 3)
  LEFT JOIN (
    SELECT r.id_buro_persona, MIN(u.texto_ubicacion) AS dir_ref
    FROM bdm_datos.relacion_persona_ubicacion r
    INNER JOIN bdm_tempo.v_xpm_ubicacion_estandarizada u ON r.cod_dw_ubic = u.cod_dw_ubic
    WHERE COALESCE(r.ind_unificacion, 0) <> 1 GROUP BY 1
  ) ref ON ref.id_buro_persona = c.id_buro_persona
  WHERE c.contact_type = '9' AND c.valor_contacto IS NOT NULL;

  TRUNCATE TABLE bdm_datos.insumo_email;
  INSERT INTO bdm_datos.insumo_email (
    cod_dw_persona_ubic, cod_pin_persona, id_buro_persona, email, dominio,
    id_buro_suscriptor, fecha_reporte, meses_reporte, sector_financiero, tipo_cuenta
  )
  SELECT
    c.cod_dw_persona_ubic, c.cod_pin_persona, c.id_buro_persona,
    LOWER(TRIM(c.valor_contacto)), LOWER(SPLIT_PART(TRIM(c.valor_contacto), '@', 2)),
    c.id_buro_suscriptor, COALESCE(c.fecha_contacto, CURRENT_DATE),
    GREATEST(DATEDIFF(month, COALESCE(c.fecha_contacto, CURRENT_DATE), CURRENT_DATE), 0),
    COALESCE(sf.sector_financiero, 0),
    CASE WHEN LOWER(SPLIT_PART(TRIM(c.valor_contacto), '@', 2)) IN
      ('gmail.com','hotmail.com','yahoo.com','outlook.com') THEN 'PERSONAL' ELSE 'CORPORATIVO' END
  FROM bdm_tempo.v_xpm_contacto_canal c
  INNER JOIN bdm_tempo.v_xpm_persona_dir_ganadora pg ON pg.id_buro_persona = c.id_buro_persona
  LEFT JOIN bdm_datos.catalogo_sector_financiero sf ON sf.id_buro_suscriptor = c.id_buro_suscriptor
  WHERE c.contact_type = '10' AND c.valor_contacto LIKE '%@%';
END;
$$;
