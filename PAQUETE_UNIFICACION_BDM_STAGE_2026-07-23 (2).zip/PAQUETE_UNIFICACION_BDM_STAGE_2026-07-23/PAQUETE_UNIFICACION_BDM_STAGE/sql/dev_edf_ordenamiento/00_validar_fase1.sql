-- Gate Fase 1 — vistas insumo + datashare (sin copia local)
SELECT 'beta_ordenamiento' AS paso, COUNT(*)::BIGINT AS total FROM bdm_datos.beta_ordenamiento
UNION ALL SELECT 'rpu_ganadoras', COUNT(*) FROM bdm_tempo.v_rpu_post_unificacion WHERE COALESCE(ind_unificacion,0)<>1
UNION ALL SELECT 'rpu_hijas', COUNT(*) FROM bdm_tempo.v_rpu_post_unificacion WHERE COALESCE(ind_unificacion,0)=1
UNION ALL SELECT 'insumo_dir', COUNT(*) FROM bdm_datos.insumo_direccion
UNION ALL SELECT 'insumo_tel', COUNT(*) FROM bdm_datos.insumo_telefono
UNION ALL SELECT 'insumo_cel', COUNT(*) FROM bdm_datos.insumo_celular
UNION ALL SELECT 'insumo_ema', COUNT(*) FROM bdm_datos.insumo_email
UNION ALL SELECT 'personas_dir', COUNT(DISTINCT id_buro_persona) FROM bdm_datos.insumo_direccion
UNION ALL SELECT 'personas_tel', COUNT(DISTINCT id_buro_persona) FROM bdm_datos.insumo_telefono
UNION ALL SELECT 'personas_cel', COUNT(DISTINCT id_buro_persona) FROM bdm_datos.insumo_celular
UNION ALL SELECT 'personas_ema', COUNT(DISTINCT id_buro_persona) FROM bdm_datos.insumo_email
ORDER BY paso;
