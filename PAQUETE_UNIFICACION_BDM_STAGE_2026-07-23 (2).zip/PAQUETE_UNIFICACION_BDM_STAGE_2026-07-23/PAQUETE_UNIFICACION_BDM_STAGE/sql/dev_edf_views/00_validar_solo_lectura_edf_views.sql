-- Validación lectura edf_views (sin relationalizelastupdate)
SELECT paso, total FROM (
  SELECT '01_edf_views.xpm' AS paso, COUNT(*)::BIGINT AS total FROM edf_views.xpm
  UNION ALL SELECT '02_edf_views.xpm_location', COUNT(*) FROM edf_views.xpm_location
  UNION ALL SELECT '03_edf_views.xpm_location_val_contactinformations', COUNT(*)
    FROM edf_views.xpm_location_val_contactinformations
  UNION ALL SELECT '04_edf_views.xpm_counterparties', COUNT(*) FROM edf_views.xpm_counterparties
  UNION ALL
  SELECT '05_xpm_con_location_match', COUNT(*)
  FROM edf_views.xpm xpm
  JOIN edf_views.xpm_location loc ON xpm.location = loc.id
  UNION ALL
  SELECT '06_join_contactos_direccion', COUNT(*)
  FROM edf_views.xpm xpm
  JOIN edf_views.xpm_location loc ON xpm.location = loc.id
  JOIN edf_views.xpm_location_val_contactinformations ci
    ON loc."location.val.contactinformations" = ci.id
  WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7)
  UNION ALL
  SELECT '07_join_reportes_R1_R2', COUNT(*)
  FROM edf_views.xpm xpm
  JOIN edf_views.xpm_location loc ON xpm.location = loc.id
  JOIN edf_views.xpm_location_val_contactinformations ci
    ON loc."location.val.contactinformations" = ci.id
  JOIN edf_views.xpm_counterparties cp ON xpm.counterparties = cp.id
  WHERE CAST(ci."location.val.contactinformations.val.contacttype" AS INTEGER) IN (1, 2, 3, 7)
  UNION ALL
  SELECT '08_vista_contacto_direccion', COUNT(*)
  FROM bdm_tempo.v_xpm_contacto_direccion
  UNION ALL
  SELECT '09_vista_reportes', COUNT(*)
  FROM bdm_tempo.v_xpm_reporte_relacion_persona_ubica
) q
ORDER BY paso;
