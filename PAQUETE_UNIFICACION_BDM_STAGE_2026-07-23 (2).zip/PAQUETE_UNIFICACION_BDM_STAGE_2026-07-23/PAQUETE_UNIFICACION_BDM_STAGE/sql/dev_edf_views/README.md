# Unificación DEV con `edf_views` (procesosbatch)

Prueba end-to-end **sin datashare**: corre en **`dba_batch`** leyendo **`edf_views.xpm_*`**.

## Ejecutar

```powershell
cd PAQUETE_UNIFICACION_BDM_STAGE
$env:REDSHIFT_HOST="eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com"
$env:REDSHIFT_DB="dba_batch"
$env:REDSHIFT_PASSWORD="<procesosbatch DEV>"
py -3 tools/dev_edf_views_run.py
```

Evidencias: `Documentacion/Evidencias_DEV_EDF_VIEWS_RUN.md`

## Adaptaciones vs `ifr_data` (QA)

| Tema | Ajuste |
|------|--------|
| JOIN XPM | Sin `relationalizelastupdate` (no existe en `edf_views`) |
| Tokenización | Tipos 1–3: solo `contactasreported`; tipo **8**: campos `standardized*` |
| `contacttype` | Incluye **8** mapeado a tipo dir **3** (CRR) |
| DANE vacío | Fallback `FNV_HASH(cityname)` como `cod_dw_ciudad` |
| Reportes | `LEFT JOIN` counterparty + suscriptor sintético si falta ID |
| Texto vacío `''` | `NULLIF` + `COALESCE` entre campos standardized/reported |

## Resultado esperado (2026-08-25)

- Pipeline: DDL → vistas → SPs R1/R2/R3 → OK
- **R2 ~72k** unificaciones; R1/R3 0 (reglas de negocio + sin geo)
