-- ============================================================
-- mock_persona_res_lab.sql
-- Persona mock: 1ra dirección RES, 2da dirección LAB (misma puerta, CIIU 10)
-- Entorno: bdm_stage (Redshift QA/DEV)
-- Requiere permisos INSERT en tablas bdm_stage.*
-- ============================================================

-- IDs del registro mock
-- id_buro_persona .............. 888001
-- cod_pin_persona .............. 1888001
-- cod_dw_ubic (compartida) ..... 888001001
-- RPU RES (1ra dirección) ...... 888001001
-- RPU LAB (2da dirección) ...... 888001002
-- cod_dw_direccion_fisica RES ... 888001101
-- cod_dw_direccion_fisica LAB ... 888001102

-- Verificar que no exista
SELECT id_buro_persona, cod_dw_persona_ubic, cod_dw_tipo_ubicacion_dir
FROM bdm_stage.relacion_persona_ubicacion
WHERE id_buro_persona = 888001;

-- ------------------------------------------------------------
-- INSERT (omitir si ya existe)
-- ------------------------------------------------------------
INSERT INTO bdm_stage.ubicacion_estandarizada
  (cod_dw_ubic, texto_ubicacion, cod_dw_ciudad, latitud, longitud)
VALUES
  (888001001, 'CL 45 12 33 MOCK QA RES-LAB', 1, NULL, NULL);

INSERT INTO bdm_stage.direccion_fisica
  (cod_dw_direccion_fisica, complemento, cod_dw_ubic, tipo_via_principal,
   via_principal, via_generadora, numero_puerta, generada_enriquecida)
VALUES
  (888001101, '', 888001001, 'CL', '45', '12', '33', NULL),
  (888001102, '', 888001001, 'CL', '45', '12', '33', NULL);

INSERT INTO bdm_stage.ciiu_persona (id_buro_persona, cod_act_econo_ciiu_fte)
VALUES (888001, '10');

INSERT INTO bdm_stage.relacion_persona_ubicacion
  (cod_dw_persona_ubic, id_buro_persona, cod_pin_persona, cod_dw_ubic,
   cod_dw_direccion_fisica, cod_dw_tipo_ubicacion_dir, ind_unificacion,
   orden_prioridad, fecha_relacion_persona_ubicaci, lote, cod_tipo_ident_fte)
VALUES
  -- 1ra dirección: RES
  (888001001, 888001, 1888001, 888001001, 888001101, 1, NULL, 1, DATE '2025-06-01', 99, 1),
  -- 2da dirección: LAB
  (888001002, 888001, 1888001, 888001001, 888001102, 2, NULL, 2, DATE '2025-06-01', 99, 1);

-- Entidades reportantes: RES=1, LAB=4 (LAB debería ganar en R1 CIIU 10)
INSERT INTO bdm_stage.reporte_relacion_persona_ubica
  (cod_dw_persona_ubic, id_buro_suscriptor, fecha_reporte, lote)
VALUES
  (888001001, 901, DATE '2025-05-01', 99),
  (888001002, 902, DATE '2025-05-01', 99),
  (888001002, 903, DATE '2025-05-01', 99),
  (888001002, 904, DATE '2025-05-01', 99),
  (888001002, 905, DATE '2025-05-01', 99);

-- ------------------------------------------------------------
-- Validación post-insert
-- ------------------------------------------------------------
SELECT
  r.cod_dw_persona_ubic AS rpu,
  t.descripcion_tipo_ubicacion_dir AS tipo_uso,
  r.cod_dw_direccion_fisica,
  u.texto_ubicacion,
  c.cod_act_econo_ciiu_fte AS ciiu,
  COUNT(DISTINCT rep.id_buro_suscriptor) AS entidades_reportan
FROM bdm_stage.relacion_persona_ubicacion r
JOIN bdm_stage.tipo_ubicacion_dir t
  ON t.cod_dw_tipo_ubicacion_dir = r.cod_dw_tipo_ubicacion_dir
JOIN bdm_stage.ubicacion_estandarizada u
  ON u.cod_dw_ubic = r.cod_dw_ubic
JOIN bdm_stage.ciiu_persona c
  ON c.id_buro_persona = r.id_buro_persona
LEFT JOIN bdm_stage.reporte_relacion_persona_ubica rep
  ON rep.cod_dw_persona_ubic = r.cod_dw_persona_ubic
WHERE r.id_buro_persona = 888001
GROUP BY 1, 2, 3, 4, 5
ORDER BY r.orden_prioridad;
