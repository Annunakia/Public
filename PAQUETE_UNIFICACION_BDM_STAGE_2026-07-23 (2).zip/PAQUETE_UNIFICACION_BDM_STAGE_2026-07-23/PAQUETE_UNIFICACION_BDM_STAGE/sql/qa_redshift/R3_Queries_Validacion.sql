-- =============================================================================
-- R3_Queries_Validacion.sql
-- Validación Regla 3 — Redshift DEV/QA (bdm_stage)
-- Personas QA: 930001 … 930010
--
-- PRECONDICIÓN: mocks QA cargados + SP desplegado:
--   sql/07_sp_regla3.sql  →  bdm_stage.sp_unificacion_regla3()
--
-- IMPORTANTE:
--   • R3 escribe unifica_atributos = 3 (R1=1, R2=2).
--   • Las queries de traza DEBEN filtrar unifica_atributos = 3;
--     si no, mezclan absorciones R1/R2 y el test falla en falso.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 0) Ejecución del proceso (nombre correcto del SP en paquete stage)
-- -----------------------------------------------------------------------------
CALL bdm_stage.sp_unificacion_regla3();


-- =============================================================================
-- RESUMEN EJECUTIVO — 10 casos (solo trazas R3, unifica_atributos = 3)
-- Esperado: columna estado = PASSED en todos tras SP corregido
-- =============================================================================
SELECT
  exp.caso,
  exp.persona,
  exp.descripcion,
  exp.exp_unif_r3,
  COALESCE(act.unif_r3, 0) AS unif_r3,
  act.id_hijo,
  act.id_padre,
  CASE
    WHEN COALESCE(act.unif_r3, 0) <> exp.exp_unif_r3 THEN 'FAILED'
    WHEN exp.exp_hijo IS NOT NULL
     AND (act.id_hijo <> exp.exp_hijo OR act.id_padre <> exp.exp_padre) THEN 'FAILED'
    WHEN exp.exp_unif_r3 = 0 AND COALESCE(cru.cruces, 0) > 0 THEN 'FAILED'
    ELSE 'PASSED'
  END AS estado
FROM (
  SELECT 'TC-R3-01' AS caso, 930001 AS persona, 'Exclusión Manzana/Rural' AS descripcion,
         0 AS exp_unif_r3, CAST(NULL AS BIGINT) AS exp_hijo, CAST(NULL AS BIGINT) AS exp_padre
  UNION ALL SELECT 'TC-R3-02', 930002, 'Geoloc parcial (esc.1 vía gen)', 1, 930002002, 930002001
  UNION ALL SELECT 'TC-R3-03', 930003, 'Sin GPS — gana fecha reciente', 1, 930003001, 930003002
  UNION ALL SELECT 'TC-R3-04', 930004, 'Diccionario vía generadora', 1, 930004001, 930004002
  UNION ALL SELECT 'TC-R3-05', 930005, 'Puerta Δ=2 con coords', 1, 930005001, 930005002
  UNION ALL SELECT 'TC-R3-06', 930006, 'Puerta Δ>2 (33 vs 38)', 0, NULL, NULL
  UNION ALL SELECT 'TC-R3-07', 930007, 'Modificador BIS (45BIS)', 0, NULL, NULL
  UNION ALL SELECT 'TC-R3-08', 930008, 'Cuadrante N — puerta Δ=2', 1, 930008001, 930008002
  UNION ALL SELECT 'TC-R3-09', 930009, 'Puerta Δ=1 sin coords', 0, NULL, NULL
  UNION ALL SELECT 'TC-R3-10', 930010, 'Empate diccionario vía', 0, NULL, NULL
) exp
LEFT JOIN (
  SELECT r.id_buro_persona,
         COUNT(*) AS unif_r3,
         MAX(u.cod_dw_persona_ubic) AS id_hijo,
         MAX(u.cod_dw_direccion_unificada) AS id_padre
  FROM bdm_stage.unificacion_direccion u
  JOIN bdm_stage.relacion_persona_ubicacion r
    ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
  WHERE u.unifica_atributos = 3
    AND r.id_buro_persona BETWEEN 930001 AND 930010
  GROUP BY 1
) act ON act.id_buro_persona = exp.persona
LEFT JOIN (
  SELECT r1.id_buro_persona, COUNT(*) AS cruces
  FROM bdm_stage.unificacion_direccion u
  JOIN bdm_stage.relacion_persona_ubicacion r1
    ON r1.cod_dw_persona_ubic = u.cod_dw_persona_ubic
  JOIN bdm_stage.unificacion_direccion u2
    ON u2.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
   AND u2.cod_dw_direccion_unificada = u.cod_dw_persona_ubic
  WHERE u.unifica_atributos = 3
    AND u2.unifica_atributos = 3
    AND r1.id_buro_persona BETWEEN 930001 AND 930010
  GROUP BY 1
) cru ON cru.id_buro_persona = exp.persona
ORDER BY exp.caso;


-- Trazas cruzadas R3 (TC-R3-10 — debe ser 0)
SELECT COUNT(*) AS trazas_cruzadas_r3_persona_930010
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r1
  ON r1.cod_dw_persona_ubic = u.cod_dw_persona_ubic
JOIN bdm_stage.unificacion_direccion u2
  ON u2.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
 AND u2.cod_dw_direccion_unificada = u.cod_dw_persona_ubic
WHERE r1.id_buro_persona = 930010
  AND u.unifica_atributos = 3
  AND u2.unifica_atributos = 3;


-- =============================================================================
-- DETALLE POR CASO
-- Por cada TC: (1) estado direcciones  (2) trazas SOLO R3 (unifica_atributos=3)
-- =============================================================================

-- ---------------------------------------------------------------------------
-- TC-R3-01 — Exclusión Manzana/Rural | persona 930001
-- Esperado R3: 0 trazas | MZ 10 20 30 vs MZ 10 22 30
-- Nota: puede existir traza R1 (unifica_atributos=1); no contar como R3
-- ---------------------------------------------------------------------------
SELECT rpu.cod_dw_persona_ubic, rpu.ind_unificacion, ubi.texto_ubicacion,
       ubi.latitud, ubi.longitud, df.tipo_via_principal, df.via_generadora, df.numero_puerta
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.id_buro_persona = 930001
ORDER BY rpu.cod_dw_persona_ubic;

SELECT u.cod_dw_persona_ubic AS id_hijo,
       u.cod_dw_direccion_unificada AS id_padre,
       u.unifica_atributos,
       u.fecha_unificacion,
       u.usuario_bd
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
WHERE r.id_buro_persona = 930001
  AND u.unifica_atributos = 3
ORDER BY 1, 2;


-- ---------------------------------------------------------------------------
-- TC-R3-02 — Geoloc parcial | persona 930002
-- Esperado R3: 1 traza | hijo 930002002 → padre 930002001 (con coords)
-- Escenario 1: misma puerta 15, distinta vía generadora 10 vs 12
-- ---------------------------------------------------------------------------
SELECT rpu.cod_dw_persona_ubic, rpu.ind_unificacion, ubi.texto_ubicacion,
       ubi.latitud, ubi.longitud, df.tipo_via_principal, df.via_generadora, df.numero_puerta
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.id_buro_persona = 930002
ORDER BY rpu.cod_dw_persona_ubic;

SELECT u.cod_dw_persona_ubic AS id_hijo,
       u.cod_dw_direccion_unificada AS id_padre,
       u.unifica_atributos,
       u.fecha_unificacion
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
WHERE r.id_buro_persona = 930002
  AND u.unifica_atributos = 3;


-- ---------------------------------------------------------------------------
-- TC-R3-03 — Sin GPS / fecha reciente | persona 930003
-- Esperado R3: 1 traza | hijo 930003001 → padre 930003002
-- ---------------------------------------------------------------------------
SELECT rpu.cod_dw_persona_ubic, rpu.ind_unificacion, ubi.texto_ubicacion,
       ubi.latitud, ubi.longitud, df.tipo_via_principal, df.via_generadora, df.numero_puerta
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.id_buro_persona = 930003
ORDER BY rpu.cod_dw_persona_ubic;

SELECT u.cod_dw_persona_ubic AS id_hijo,
       u.cod_dw_direccion_unificada AS id_padre,
       u.unifica_atributos,
       u.fecha_unificacion
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
WHERE r.id_buro_persona = 930003
  AND u.unifica_atributos = 3;


-- ---------------------------------------------------------------------------
-- TC-R3-04 — Diccionario de vía | persona 930004
-- Esperado R3: 1 traza | hijo 930004001 → padre 930004002
-- ---------------------------------------------------------------------------
SELECT rpu.cod_dw_persona_ubic, rpu.ind_unificacion, ubi.texto_ubicacion,
       ubi.latitud, ubi.longitud, df.tipo_via_principal, df.via_generadora, df.numero_puerta
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.id_buro_persona = 930004
ORDER BY rpu.cod_dw_persona_ubic;

SELECT u.cod_dw_persona_ubic AS id_hijo,
       u.cod_dw_direccion_unificada AS id_padre,
       u.unifica_atributos,
       u.fecha_unificacion
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
WHERE r.id_buro_persona = 930004
  AND u.unifica_atributos = 3;


-- ---------------------------------------------------------------------------
-- TC-R3-05 — Puerta Δ=2 con coords | persona 930005
-- Esperado R3: 1 traza | hijo 930005001 (puerta 33) → padre 930005002 (puerta 35)
-- Escenario 2: misma vía generadora 45, |33-35|=2
-- ---------------------------------------------------------------------------
SELECT rpu.cod_dw_persona_ubic, rpu.ind_unificacion, ubi.texto_ubicacion,
       ubi.latitud, ubi.longitud, df.tipo_via_principal, df.via_generadora, df.numero_puerta
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.id_buro_persona = 930005
ORDER BY rpu.cod_dw_persona_ubic;

SELECT u.cod_dw_persona_ubic AS id_hijo,
       u.cod_dw_direccion_unificada AS id_padre,
       u.unifica_atributos,
       u.fecha_unificacion
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
WHERE r.id_buro_persona = 930005
  AND u.unifica_atributos = 3;


-- ---------------------------------------------------------------------------
-- TC-R3-06 — Puerta Δ>2 | persona 930006
-- Esperado R3: 0 trazas | puertas 33 vs 38 (Δ=5)
-- ---------------------------------------------------------------------------
SELECT rpu.cod_dw_persona_ubic, rpu.ind_unificacion, ubi.texto_ubicacion,
       ubi.latitud, ubi.longitud, df.tipo_via_principal, df.via_generadora, df.numero_puerta
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.id_buro_persona = 930006
ORDER BY rpu.cod_dw_persona_ubic;

SELECT u.cod_dw_persona_ubic AS id_hijo,
       u.cod_dw_direccion_unificada AS id_padre,
       u.unifica_atributos,
       u.fecha_unificacion
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
WHERE r.id_buro_persona = 930006
  AND u.unifica_atributos = 3;


-- ---------------------------------------------------------------------------
-- TC-R3-07 — Modificador BIS | persona 930007
-- Esperado R3: 0 trazas | CL 45BIS excluido del insumo R3
-- ---------------------------------------------------------------------------
SELECT rpu.cod_dw_persona_ubic, rpu.ind_unificacion, ubi.texto_ubicacion,
       ubi.latitud, ubi.longitud, df.tipo_via_principal, df.via_generadora, df.numero_puerta
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.id_buro_persona = 930007
ORDER BY rpu.cod_dw_persona_ubic;

SELECT u.cod_dw_persona_ubic AS id_hijo,
       u.cod_dw_direccion_unificada AS id_padre,
       u.unifica_atributos,
       u.fecha_unificacion
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
WHERE r.id_buro_persona = 930007
  AND u.unifica_atributos = 3;


-- ---------------------------------------------------------------------------
-- TC-R3-08 — Cuadrante N | persona 930008
-- Esperado R3: 1 traza | hijo 930008001 (33 N) → padre 930008002 (35 N)
-- Cuadrante NO excluye; solo modificadores B/C/F/BIS
-- ---------------------------------------------------------------------------
SELECT rpu.cod_dw_persona_ubic, rpu.ind_unificacion, ubi.texto_ubicacion,
       ubi.latitud, ubi.longitud, df.tipo_via_principal, df.via_generadora, df.numero_puerta
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.id_buro_persona = 930008
ORDER BY rpu.cod_dw_persona_ubic;

SELECT u.cod_dw_persona_ubic AS id_hijo,
       u.cod_dw_direccion_unificada AS id_padre,
       u.unifica_atributos,
       u.fecha_unificacion
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
WHERE r.id_buro_persona = 930008
  AND u.unifica_atributos = 3;


-- ---------------------------------------------------------------------------
-- TC-R3-09 — Puerta Δ=1 sin coords | persona 930009
-- Esperado R3: 0 trazas | puertas 10 vs 11 (Δ=1, regla exige Δ=2)
-- ---------------------------------------------------------------------------
SELECT rpu.cod_dw_persona_ubic, rpu.ind_unificacion, ubi.texto_ubicacion,
       ubi.latitud, ubi.longitud, df.tipo_via_principal, df.via_generadora, df.numero_puerta
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.id_buro_persona = 930009
ORDER BY rpu.cod_dw_persona_ubic;

SELECT u.cod_dw_persona_ubic AS id_hijo,
       u.cod_dw_direccion_unificada AS id_padre,
       u.unifica_atributos,
       u.fecha_unificacion
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
WHERE r.id_buro_persona = 930009
  AND u.unifica_atributos = 3;


-- ---------------------------------------------------------------------------
-- TC-R3-10 — Empate diccionario | persona 930010
-- Esperado R3: 0 trazas | TV 207 20 40 vs TV 207 22 40 (mismo score)
-- Sin trazas cruzadas R3; ambas vigentes respecto a R3
-- ---------------------------------------------------------------------------
SELECT rpu.cod_dw_persona_ubic, rpu.ind_unificacion, ubi.texto_ubicacion,
       ubi.latitud, ubi.longitud, df.tipo_via_principal, df.via_generadora, df.numero_puerta
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.id_buro_persona = 930010
ORDER BY rpu.cod_dw_persona_ubic;

SELECT u.cod_dw_persona_ubic AS id_hijo,
       u.cod_dw_direccion_unificada AS id_padre,
       u.unifica_atributos,
       u.fecha_unificacion
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
WHERE r.id_buro_persona = 930010
  AND u.unifica_atributos = 3;


-- =============================================================================
-- Diagnóstico: todas las trazas por persona (incluye R1/R2 para contraste)
-- =============================================================================
SELECT r.id_buro_persona,
       u.unifica_atributos,
       u.cod_dw_persona_ubic AS id_hijo,
       u.cod_dw_direccion_unificada AS id_padre
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
WHERE r.id_buro_persona BETWEEN 930001 AND 930010
ORDER BY 1, 2, 3;
