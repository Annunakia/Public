-- ============================================================
-- validar_mock_tc_r3_suite.sql
-- Ejecutar DESPUÉS de CALL bdm_stage.sp_unificacion_regla3()
-- Personas: legacy 930001/930008/930010 + nuevos 931002-931013
-- ============================================================

SELECT
  exp.caso,
  exp.persona,
  COALESCE(act.unif_real, 0) AS unif_real,
  exp.exp_unif,
  CASE WHEN COALESCE(act.unif_real, 0) = exp.exp_unif THEN 'PASSED' ELSE 'FAILED' END AS estado
FROM (
  SELECT 'TC-R3-01' AS caso, 930001 AS persona, 0 AS exp_unif
  UNION ALL SELECT 'TC-R3-02', 931002, 1
  UNION ALL SELECT 'TC-R3-03', 931003, 1
  UNION ALL SELECT 'TC-R3-04', 931004, 1
  UNION ALL SELECT 'TC-R3-05', 931005, 0
  UNION ALL SELECT 'TC-R3-06', 931006, 0
  UNION ALL SELECT 'TC-R3-07', 931007, 0
  UNION ALL SELECT 'TC-R3-08', 930008, 1
  UNION ALL SELECT 'TC-R3-09', 931009, 1
  UNION ALL SELECT 'TC-R3-10', 930010, 0
  UNION ALL SELECT 'TC-R3-11', 931011, 1
  UNION ALL SELECT 'TC-R3-12', 931012, 1
  UNION ALL SELECT 'TC-R3-13', 931013, 0
) exp
LEFT JOIN (
  SELECT r.id_buro_persona, COUNT(*) AS unif_real
  FROM bdm_stage.unificacion_direccion u
  JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
  WHERE u.unifica_atributos = 3
    AND r.id_buro_persona IN (
      930001,930008,930010,
      931002,931003,931004,931005,931006,931007,931009,931011,931012,931013
    )
  GROUP BY 1
) act ON act.id_buro_persona = exp.persona
ORDER BY exp.caso;

-- Detalle trazas
SELECT m.scenario_code, r.id_buro_persona, r.cod_dw_persona_ubic AS rpu,
       ubi.texto_ubicacion, u.cod_dw_direccion_unificada AS padre,
       COALESCE(r.ind_unificacion, 0) AS ind
FROM bdm_stage.perf_persona_meta m
JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
JOIN bdm_stage.ubicacion_estandarizada ubi ON ubi.cod_dw_ubic = r.cod_dw_ubic
LEFT JOIN bdm_stage.unificacion_direccion u
  ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic AND u.unifica_atributos = 3
WHERE m.scenario_code LIKE 'MOCK_TC_R3_%'
ORDER BY m.id_buro_persona, r.cod_dw_persona_ubic;

-- Mocks cargados
SELECT m.id_buro_persona, m.scenario_code, COUNT(*) AS n_rpu
FROM bdm_stage.perf_persona_meta m
JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
WHERE m.scenario_code LIKE 'MOCK_TC_R3_%'
GROUP BY 1, 2 ORDER BY 1;
