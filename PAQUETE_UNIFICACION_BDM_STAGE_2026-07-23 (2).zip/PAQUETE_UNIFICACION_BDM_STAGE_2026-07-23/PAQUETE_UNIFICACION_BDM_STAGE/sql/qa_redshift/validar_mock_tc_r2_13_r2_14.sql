-- ============================================================
-- validar_mock_tc_r2_13_r2_14.sql
-- Ejecutar DESPUÉS de correr Regla 2 sobre los mocks 888003 / 888004
-- ============================================================

-- ------------------------------------------------------------
-- TC-R2-13 MOCK (888003): DEBE existir 1 absorción R2; padre CS 5 (888003001)
-- ------------------------------------------------------------
SELECT
  'TC-R2-13_MOCK' AS caso,
  CASE
    WHEN COUNT(*) = 1
     AND MAX(u.cod_dw_direccion_unificada) = 888003001
     AND MAX(u.cod_dw_persona_ubic) = 888003002
     AND MAX(COALESCE(rh.ind_unificacion, 0)) = 1
    THEN 'PASSED'
    ELSE 'FAILED'
  END AS estado,
  COUNT(*) AS filas_unificacion,
  MAX(u.cod_dw_persona_ubic) AS rpu_hijo,
  MAX(u.cod_dw_direccion_unificada) AS rpu_padre
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic
WHERE rh.id_buro_persona = 888003
  AND u.unifica_atributos = 2;

-- Detalle TC-R2-13
SELECT
  rh.id_buro_persona,
  u.cod_dw_persona_ubic AS rpu_hijo,
  u.cod_dw_direccion_unificada AS rpu_padre,
  df_h.complemento AS comp_hijo,
  df_p.complemento AS comp_padre,
  rh.ind_unificacion,
  u.fecha_unificacion
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic
JOIN bdm_stage.relacion_persona_ubicacion rp ON rp.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
JOIN bdm_stage.direccion_fisica df_h ON df_h.cod_dw_direccion_fisica = rh.cod_dw_direccion_fisica
JOIN bdm_stage.direccion_fisica df_p ON df_p.cod_dw_direccion_fisica = rp.cod_dw_direccion_fisica
WHERE rh.id_buro_persona = 888003 AND u.unifica_atributos = 2;

-- Violación: persona 888003 sin unificación R2
SELECT COUNT(*) AS violaciones_tc_r2_13
FROM bdm_stage.perf_persona_meta m
WHERE m.id_buro_persona = 888003
  AND NOT EXISTS (
    SELECT 1 FROM bdm_stage.relacion_persona_ubicacion r
    JOIN bdm_stage.unificacion_direccion u
      ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic AND u.unifica_atributos = 2
    WHERE r.id_buro_persona = m.id_buro_persona
  );
-- Esperado: 0

-- Padre incorrecto: no CS 5 como padre
SELECT COUNT(*) AS violaciones_padre_incorrecto
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic
WHERE rh.id_buro_persona = 888003
  AND u.unifica_atributos = 2
  AND u.cod_dw_direccion_unificada <> 888003001;
-- Esperado: 0

-- ------------------------------------------------------------
-- TC-R2-14 MOCK (888004): NO debe existir absorción R2 (empate persistente)
-- ------------------------------------------------------------
SELECT
  'TC-R2-14_MOCK' AS caso,
  CASE WHEN COUNT(*) = 0 THEN 'PASSED' ELSE 'FAILED' END AS estado,
  COUNT(*) AS absorciones_indebidas
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion rh ON rh.cod_dw_persona_ubic = u.cod_dw_persona_ubic
WHERE rh.id_buro_persona = 888004
  AND u.unifica_atributos = 2;

-- Ambas direcciones deben seguir vigentes (ind_unificacion NULL)
SELECT
  r.cod_dw_persona_ubic AS rpu,
  df.complemento,
  r.ind_unificacion,
  CASE WHEN r.ind_unificacion IS NULL THEN 'VIGENTE_OK' ELSE 'HIJO_INESPERADO' END AS rol
FROM bdm_stage.relacion_persona_ubicacion r
JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
WHERE r.id_buro_persona = 888004
ORDER BY r.cod_dw_persona_ubic;

-- Empate diccionario + entidades (diagnóstico)
SELECT
  r.cod_dw_persona_ubic,
  df.complemento,
  COUNT(DISTINCT rep.id_buro_suscriptor) AS entidades,
  dc.nomen,
  dc.valor,
  dc.frecuencia
FROM bdm_stage.relacion_persona_ubicacion r
JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rep.cod_dw_persona_ubic = r.cod_dw_persona_ubic
LEFT JOIN bdm_stage.diccionario_complementos dc
  ON dc.cod_dw_ubic = r.cod_dw_ubic AND dc.id_buro_persona = r.id_buro_persona
  AND dc.nomen = SPLIT_PART(TRIM(df.complemento), ' ', 1)
  AND dc.valor = SPLIT_PART(TRIM(df.complemento), ' ', 2)
WHERE r.id_buro_persona = 888004
GROUP BY 1, 2, 4, 5, 6
ORDER BY 1;

-- ------------------------------------------------------------
-- Resumen ejecutivo mocks
-- ------------------------------------------------------------
SELECT '888003_TC-R2-13' AS mock,
       CASE WHEN EXISTS (
         SELECT 1 FROM bdm_stage.unificacion_direccion u
         JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
         WHERE r.id_buro_persona = 888003 AND u.unifica_atributos = 2
           AND u.cod_dw_direccion_unificada = 888003001 AND u.cod_dw_persona_ubic = 888003002
       ) THEN 'PASSED' ELSE 'FAILED' END AS estado
UNION ALL
SELECT '888004_TC-R2-14',
       CASE WHEN NOT EXISTS (
         SELECT 1 FROM bdm_stage.unificacion_direccion u
         JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_persona_ubic
         WHERE r.id_buro_persona = 888004 AND u.unifica_atributos = 2
       ) THEN 'PASSED' ELSE 'FAILED' END;
