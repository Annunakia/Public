-- ============================================================
-- mock_persona_ap301_in301.sql
-- Persona mock: 2 direcciones misma puerta
--   Dirección 1: complemento AP 301
--   Dirección 2: complemento IN 301
-- Esquema: bdm_stage (Redshift QA/DEV)
-- ============================================================

-- IDs del registro mock
-- id_buro_persona .............. 888002
-- cod_pin_persona .............. 1888002
-- cod_dw_ubic (compartida) ..... 888002001
-- RPU dirección 1 .............. 888002001  (complemento AP 301)
-- RPU dirección 2 .............. 888002002  (complemento IN 301)
-- cod_dw_direccion_fisica 1 .... 888002101
-- cod_dw_direccion_fisica 2 .... 888002102

SELECT id_buro_persona, cod_dw_persona_ubic, cod_dw_tipo_ubicacion_dir
FROM bdm_stage.relacion_persona_ubicacion
WHERE id_buro_persona = 888002;

-- ------------------------------------------------------------
-- INSERT (omitir bloque si ya existe)
-- ------------------------------------------------------------
INSERT INTO bdm_stage.ubicacion_estandarizada
  (cod_dw_ubic, texto_ubicacion, cod_dw_ciudad, latitud, longitud)
VALUES
  (888002001, 'CL 45 12 33 MOCK QA AP301-IN301', 1, NULL, NULL);

INSERT INTO bdm_stage.direccion_fisica
  (cod_dw_direccion_fisica, complemento, cod_dw_ubic, tipo_via_principal,
   via_principal, via_generadora, numero_puerta, generada_enriquecida)
VALUES
  (888002101, 'AP 301', 888002001, 'CL', '45', '12', '33', NULL),
  (888002102, 'IN 301', 888002001, 'CL', '45', '12', '33', NULL);

INSERT INTO bdm_stage.ciiu_persona (id_buro_persona, cod_act_econo_ciiu_fte)
VALUES (888002, '10');

INSERT INTO bdm_stage.relacion_persona_ubicacion
  (cod_dw_persona_ubic, id_buro_persona, cod_pin_persona, cod_dw_ubic,
   cod_dw_direccion_fisica, cod_dw_tipo_ubicacion_dir, ind_unificacion,
   orden_prioridad, fecha_relacion_persona_ubicaci, lote, cod_tipo_ident_fte)
VALUES
  (888002001, 888002, 1888002, 888002001, 888002101, 1, NULL, 1, DATE '2025-06-01', 99, 1),
  (888002002, 888002, 1888002, 888002001, 888002102, 1, NULL, 2, DATE '2025-06-01', 99, 1);

INSERT INTO bdm_stage.reporte_relacion_persona_ubica
  (cod_dw_persona_ubic, id_buro_suscriptor, fecha_reporte, lote)
VALUES
  (888002001, 901, DATE '2025-05-01', 99),
  (888002001, 902, DATE '2025-05-01', 99),
  (888002002, 903, DATE '2025-05-01', 99);

-- ------------------------------------------------------------
-- Validación post-insert
-- ------------------------------------------------------------
SELECT
  r.cod_dw_persona_ubic AS rpu,
  r.orden_prioridad       AS direccion_num,
  df.complemento,
  t.descripcion_tipo_ubicacion_dir AS tipo_uso,
  u.texto_ubicacion,
  COUNT(DISTINCT rep.id_buro_suscriptor) AS entidades_reportan
FROM bdm_stage.relacion_persona_ubicacion r
JOIN bdm_stage.direccion_fisica df
  ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
JOIN bdm_stage.tipo_ubicacion_dir t
  ON t.cod_dw_tipo_ubicacion_dir = r.cod_dw_tipo_ubicacion_dir
JOIN bdm_stage.ubicacion_estandarizada u
  ON u.cod_dw_ubic = r.cod_dw_ubic
LEFT JOIN bdm_stage.reporte_relacion_persona_ubica rep
  ON rep.cod_dw_persona_ubic = r.cod_dw_persona_ubic
WHERE r.id_buro_persona = 888002
GROUP BY 1, 2, 3, 4, 5
ORDER BY r.orden_prioridad;
