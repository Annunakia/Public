-- ============================================================
-- mock_tc_r2_13_r2_14.sql
-- Mocks aislados para probar TC-R2-13 y TC-R2-14
-- Esquema: bdm_stage (Redshift QA/DEV)
-- Requiere permisos INSERT
-- ============================================================
--
-- MOCK TC-R2-13 (888003): Esc4 + diccionario → DEBE unificar; gana CS 5 (freq 10 > PI 4)
-- MOCK TC-R2-14 (888004): Esc4 empate → NO debe unificar (CS 8 / PI 8, freq 10 = 10, rep 2 = 2)
--
-- Ejecutar ANTES de Regla 2: solo carga insumos
-- Ejecutar DESPUÉS de Regla 2: validar_mock_tc_r2_13_r2_14.sql
-- ============================================================

-- ============================================================
-- A. MOCK TC-R2-13 — id_buro_persona 888003
-- ============================================================
-- RPU 1 (888003001): complemento CS 5  — padre esperado post-R2
-- RPU 2 (888003002): complemento PI 5  — hija esperada post-R2
-- cod_dw_ubic ........ 888003001
-- Diccionario ........ CS/5/10, PI/5/4

SELECT 'MOCK_888003_existe' AS chk, COUNT(*) AS n
FROM bdm_stage.relacion_persona_ubicacion WHERE id_buro_persona = 888003;

-- Ubicación compartida
INSERT INTO bdm_stage.ubicacion_estandarizada
  (cod_dw_ubic, texto_ubicacion, cod_dw_ciudad, latitud, longitud)
VALUES
  (888003001, 'CL 80 55 18 MOCK TC-R2-13 CS5-PI5', 1, NULL, NULL);

INSERT INTO bdm_stage.direccion_fisica
  (cod_dw_direccion_fisica, complemento, cod_dw_ubic, tipo_via_principal,
   via_principal, via_generadora, numero_puerta, generada_enriquecida)
VALUES
  (888003101, 'CS 5', 888003001, 'CL', '80', '55', '18', NULL),
  (888003102, 'PI 5', 888003001, 'CL', '80', '55', '18', NULL);

INSERT INTO bdm_stage.ciiu_persona (id_buro_persona, cod_act_econo_ciiu_fte)
VALUES (888003, '10');

INSERT INTO bdm_stage.relacion_persona_ubicacion
  (cod_dw_persona_ubic, id_buro_persona, cod_pin_persona, cod_dw_ubic,
   cod_dw_direccion_fisica, cod_dw_tipo_ubicacion_dir, ind_unificacion,
   orden_prioridad, fecha_relacion_persona_ubicaci, lote, cod_tipo_ident_fte)
VALUES
  (888003001, 888003, 1888003, 888003001, 888003101, 1, NULL, 1, DATE '2025-06-01', 99, 1),
  (888003002, 888003, 1888003, 888003001, 888003102, 1, NULL, 2, DATE '2025-06-01', 99, 1);

-- Entidades: CS 5 con más reportes (3 vs 2) — coherente con Esc4_DIC
INSERT INTO bdm_stage.reporte_relacion_persona_ubica
  (cod_dw_persona_ubic, id_buro_suscriptor, fecha_reporte, lote)
VALUES
  (888003001, 911, DATE '2025-05-01', 99),
  (888003001, 912, DATE '2025-05-01', 99),
  (888003001, 913, DATE '2025-05-01', 99),
  (888003002, 914, DATE '2025-05-01', 99),
  (888003002, 915, DATE '2025-05-01', 99);

-- Diccionario: CS gana (10 > 4) — mismo patrón R2_ESC4_DIC del benchmark
INSERT INTO bdm_stage.diccionario_complementos
  (cod_dw_ubic, id_buro_persona, nomenclatura, nomen, valor, frecuencia)
VALUES
  (888003001, 888003, 'CS 5', 'CS', '5', 10),
  (888003001, 888003, 'PI 5', 'PI', '5', 4);

-- Metadata escenario (opcional; integra con validaciones por scenario_code)
INSERT INTO bdm_stage.perf_persona_meta (id_buro_persona, persona_seq, scenario_code)
SELECT 888003, 888003, 'MOCK_TC_R2_13'
WHERE NOT EXISTS (
  SELECT 1 FROM bdm_stage.perf_persona_meta WHERE id_buro_persona = 888003
);

-- ============================================================
-- B. MOCK TC-R2-14 — id_buro_persona 888004
-- ============================================================
-- RPU 1 (888004001): complemento CS 8
-- RPU 2 (888004002): complemento PI 8
-- Diccionario ........ CS/8/10, PI/8/10 (empate)
-- Entidades .......... 2 vs 2 (empate)

SELECT 'MOCK_888004_existe' AS chk, COUNT(*) AS n
FROM bdm_stage.relacion_persona_ubicacion WHERE id_buro_persona = 888004;

INSERT INTO bdm_stage.ubicacion_estandarizada
  (cod_dw_ubic, texto_ubicacion, cod_dw_ciudad, latitud, longitud)
VALUES
  (888004001, 'CL 95 18 42 MOCK TC-R2-14 CS8-PI8', 1, NULL, NULL);

INSERT INTO bdm_stage.direccion_fisica
  (cod_dw_direccion_fisica, complemento, cod_dw_ubic, tipo_via_principal,
   via_principal, via_generadora, numero_puerta, generada_enriquecida)
VALUES
  (888004101, 'CS 8', 888004001, 'CL', '95', '18', '42', NULL),
  (888004102, 'PI 8', 888004001, 'CL', '95', '18', '42', NULL);

INSERT INTO bdm_stage.ciiu_persona (id_buro_persona, cod_act_econo_ciiu_fte)
VALUES (888004, '10');

INSERT INTO bdm_stage.relacion_persona_ubicacion
  (cod_dw_persona_ubic, id_buro_persona, cod_pin_persona, cod_dw_ubic,
   cod_dw_direccion_fisica, cod_dw_tipo_ubicacion_dir, ind_unificacion,
   orden_prioridad, fecha_relacion_persona_ubicaci, lote, cod_tipo_ident_fte)
VALUES
  (888004001, 888004, 1888004, 888004001, 888004101, 1, NULL, 1, DATE '2025-06-01', 99, 1),
  (888004002, 888004, 1888004, 888004001, 888004102, 1, NULL, 2, DATE '2025-06-01', 99, 1);

INSERT INTO bdm_stage.reporte_relacion_persona_ubica
  (cod_dw_persona_ubic, id_buro_suscriptor, fecha_reporte, lote)
VALUES
  (888004001, 921, DATE '2025-05-01', 99),
  (888004001, 922, DATE '2025-05-01', 99),
  (888004002, 923, DATE '2025-05-01', 99),
  (888004002, 924, DATE '2025-05-01', 99);

INSERT INTO bdm_stage.diccionario_complementos
  (cod_dw_ubic, id_buro_persona, nomenclatura, nomen, valor, frecuencia)
VALUES
  (888004001, 888004, 'CS 8', 'CS', '8', 10),
  (888004001, 888004, 'PI 8', 'PI', '8', 10);

INSERT INTO bdm_stage.perf_persona_meta (id_buro_persona, persona_seq, scenario_code)
SELECT 888004, 888004, 'MOCK_TC_R2_14'
WHERE NOT EXISTS (
  SELECT 1 FROM bdm_stage.perf_persona_meta WHERE id_buro_persona = 888004
);

-- ============================================================
-- C. Verificación post-carga (antes de Regla 2)
-- ============================================================
SELECT
  m.scenario_code,
  r.id_buro_persona,
  r.cod_dw_persona_ubic AS rpu,
  df.complemento,
  COUNT(DISTINCT rep.id_buro_suscriptor) AS entidades,
  MAX(dc.frecuencia) AS max_freq_dic
FROM bdm_stage.perf_persona_meta m
JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
JOIN bdm_stage.direccion_fisica df ON df.cod_dw_direccion_fisica = r.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rep.cod_dw_persona_ubic = r.cod_dw_persona_ubic
LEFT JOIN bdm_stage.diccionario_complementos dc
  ON dc.cod_dw_ubic = r.cod_dw_ubic AND dc.id_buro_persona = r.id_buro_persona
  AND dc.nomen = CASE WHEN df.complemento LIKE 'CS%' THEN 'CS' WHEN df.complemento LIKE 'PI%' THEN 'PI' END
WHERE m.id_buro_persona IN (888003, 888004)
GROUP BY 1, 2, 3, 4
ORDER BY m.id_buro_persona, r.cod_dw_persona_ubic;
