-- Rollback de 08_ejecucion_secuencial.sql
-- Limpia el resultado de la corrida orquestada.
-- No elimina los SPs (usar rollbacks 05-07 para eso).

TRUNCATE TABLE bdm_stage.unificacion_direccion;
