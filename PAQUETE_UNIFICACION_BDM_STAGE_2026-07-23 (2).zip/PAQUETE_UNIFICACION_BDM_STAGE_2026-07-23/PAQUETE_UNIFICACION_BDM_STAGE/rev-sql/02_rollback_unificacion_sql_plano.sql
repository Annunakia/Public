-- Rollback de 02_unificacion_sql_plano.sql
-- Limpia temporales y deja la tabla final vacia para repetir la prueba.

DROP TABLE IF EXISTS bdm_tempo.stg_regla1_insumo;
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_scored;
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_insumo;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_esc1_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e1;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_esc2_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e2;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03_a;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03_e1;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_a;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_c1;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_e;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_a;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_freq;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_insumo;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_pares;
TRUNCATE TABLE bdm_stage.unificacion_direccion;
