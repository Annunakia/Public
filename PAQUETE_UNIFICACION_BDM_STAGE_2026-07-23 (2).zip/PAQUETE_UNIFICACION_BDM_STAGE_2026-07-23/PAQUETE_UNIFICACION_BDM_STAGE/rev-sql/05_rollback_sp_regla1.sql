-- Rollback de 05_sp_regla1.sql

DROP PROCEDURE IF EXISTS bdm_stage.sp_unificacion_regla1();

DROP TABLE IF EXISTS bdm_tempo.stg_regla1_insumo;
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_scored;
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_max;
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_ganador;
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_pares;
