-- Rollback de 07_sp_regla3.sql

DROP PROCEDURE IF EXISTS bdm_stage.sp_unificacion_regla3();

DROP TABLE IF EXISTS bdm_tempo.stg_regla3_insumo;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_diccionario_via;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_scored;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_ranked;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_ganadores;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_resultado;
