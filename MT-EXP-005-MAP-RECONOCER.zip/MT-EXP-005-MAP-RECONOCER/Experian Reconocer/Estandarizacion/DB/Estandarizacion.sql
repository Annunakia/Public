--<ScriptOptions statementTerminator=";"/>

REPLACE PROCEDURE REC_DATOS.PRO_StandardizationEmail
( IN P_Lote INTEGER 
 	,IN P_StartTimeStampPadre VARCHAR(20) 
 	,IN P_Nombre_Proceso_Padre VARCHAR(30) 
 	,IN P_BDDATOS VARCHAR(20) 
 	,IN P_BDVISTA VARCHAR(20) 
 	,IN P_BDSTAGE VARCHAR(20) 
 	,OUT P_ERROR VARCHAR(50) 
 	) 
 /*
 * ################################################################################
 * 
 * Objetivo:		Estandariza el correo electronico como ubicacion del insumo InsumoEmail.
 *			Dejando el resultado en Emails_Estandarizados
 * Fecha:		2016/11/09
 * Realizado por:	Luis E Ramirez
 * Proyecto:		Nuevo reconocer
 * Script:		PRO_StandardizationEmail
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha	Objetivo				                          Realizado por
 * 18-1-2018	#1 procesar solo e-mail validos    
 *              #2 Cast a 512
 * 05-03-2018 Ajustar reglas y corregir proceso para          Fernando Garrido M
 *            cumplir con los solitado por el negocio 
 * 16-11-2018 Se ajusta calculo de la extension y el dominio
 *            cuando estos contiene el caracter ";"           Fernando Garrido M
 * 28-11-2018 Se castea el campo  Decripcion_Excepcion_Mail a 
 *            varchar(100) para la creacion de la tabla 
 *            TMP_MailBuzonInvalido                          Fernando Garrido M
 * 29-11-2018 Se castea el campo  Decripcion_Excepcion_Mail a 
 *            varchar(100) para la creacion de la tabla 
 *            TMP_MailDominioCom                             Fernando Garrido M
 * 25-02-2020 Se modifica el SP para coloque siempre en la   Fernando Garrido M   
 *            Ubicacion_Standarizada el valor de ubicacion  
 *            original en el caso de no poder estandarizarla 
 * 03-06-2021   # 3 Incluir funcionalidad para excluir  EMAIL en el proceso y marcarlos como NO VALIDO  para no mostrar estos datos en la salida del cliente
 * 03-08-2022 #4 Se Adiciona Regla para la Antiguedad de los datos  John Bueno
 * 30/01/2023  Se reinician las variables vsentencia                Omar Delgado.
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */
BEGIN
------------------------
-- Declaracion de variables
------------------------
	DECLARE V_StartTimeStampPadre TIMESTAMP(6);
	DECLARE V_ERROR VARCHAR(30);
	DECLARE V_CADENA VARCHAR(32000);
	DECLARE Temp CHAR(30);
	DECLARE V_Sentencia VARCHAR(500);
	DECLARE V_Condicion VARCHAR(500);
	DECLARE V_Flag_Recursiva VARCHAR(1);
	DECLARE V_Cod_DW_Regla_Est_Ubica INTEGER;
	DECLARE V_COUNT INTEGER;
    DECLARE V_Contador INTEGER;
	
	DECLARE cur_reglas_select NO SCROLL CURSOR
	FOR the_statement;
	
	DECLARE cur_count_rec NO SCROLL CURSOR
	FOR the_statement_1;
	
	L1: BEGIN
		SET P_ERROR = '';
		SET V_StartTimeStampPadre = Cast(P_StartTimeStampPadre AS TIMESTAMP(6) Format 'yyyy-mm-ddhh:mi:ss');
		SET V_COUNT = 1;
		
		---------------------------
		-- Busca y borra si existe la tabla tmp_EmailsEstandarizados
		---------------------------
		SELECT TableName INTO :Temp
		FROM dbc.tables
		WHERE databasename =:P_BDSTAGE
		AND TableName = 'tmp_EmailsEstandarizados' ;
		 
		IF Activity_Count > 0 THEN
			SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_EmailsEstandarizados';
		 	CALL DBC.SysExecSQL(:V_CADENA);
		END IF;

		-----------------------------
		-- Se crea y carga la tabla tmp_EmailsEstandarizados
		-----------------------------
 		SET V_CADENA = '';
 		SET V_CADENA = 'CREATE MULTISET TABLE '||P_BDSTAGE || '.tmp_EmailsEstandarizados
						AS (SELECT	Cod_DW_Reporte_Ubic_Original
								,UPPER(Texto_Ubicacion_Original) Ubicacion_Stand
								,Texto_Ubicacion_Original
								,Cod_DW_Tipo_Ubicacion
								,Cod_DW_Fuente
								,Lote
								,Id_Buro_Suscriptor
								,Id_Buro_Persona
								,Cod_DW_Cta
								,Cod_DW_Hash
								,Cod_DW_Ubic
								,Valor
								,Texto_Ciudad
								,Codigo_Ciudad_Dane
								,Fecha_Reporte
								
								,Cod_DW_Ubicacion_Original
								,Cod_DW_Tipo_Ubicacion_Dir
								,Usuario_BD
							FROM '||P_BDSTAGE || '.InsumoEmail
						) WITH DATA
						PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';

		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
			,V_StartTimeStampPadre
			,:P_Nombre_Proceso_Padre
			,:V_CADENA 
			,'PRO_StandardizationEmail (1):. Crear y carga la tabla tmp_EmailsEstandarizados'
			,V_ERROR);
			
		SET P_ERROR = V_ERROR;
		
		IF Character_Length(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF;
		
		--------------------
		-- Actualiza estadisticas a tmp_EmailsEstandarizados
		--------------------
 		SET V_CADENA = '';
 		SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN(Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_EmailsEstandarizados';
 		--------------------
		 -- Ejecuta cadena
		 --------------------
		 
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
		 	,V_StartTimeStampPadre 
		 	,:P_Nombre_Proceso_Padre 
		 	,:V_CADENA 
		 	,'PRO_StandardizationEmail (2):. Actualizar estadisticas a la tabla tmp_EmailsEstandarizados' 
		 	,V_ERROR);
		 	
		 SET P_ERROR = V_ERROR;
		 
		 IF Character_Length(V_ERROR) > 0 THEN
		 	LEAVE L1;
		 END IF;
		 
		 --------------------
		-- Cursor de reglas, se identifica con una sola etapa. ETAPA IN (1)
		--------------------
		 SET V_CADENA = 'SELECT	Sentencia
								,Condicion
								,Flag_Recursiva
								,Cod_DW_Regla_Est_Ubica
							FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
							WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
									select Cod_DW_Atributo
									from '|| P_BDDATOS ||'.ATRIBUTO
									where Cod_DW_Tipo_Atributo in (
										select Cod_DW_Tipo_Atributo
										from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
										where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
									) AND Valor_Origen = ''Email''
								) AND  Flag_Activo = ''S'' AND ETAPA IN (1)
							ORDER BY Orden';
		
		SET V_Contador = 0;
		SET V_Sentencia = '';
		SET V_Condicion = '';
		SET V_Cod_DW_Regla_Est_Ubica = '';
		PREPARE the_statement FROM V_CADENA;
		
		OPEN cur_reglas_select;
		
		CUR1:LOOP 
			FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica;
			
			IF SqlState <> '00000' THEN LEAVE CUR1;
			END IF;
			
			SET V_Contador = V_Contador +1;
			
			SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.tmp_EmailsEstandarizados
								SET ' || V_Sentencia || '
							WHERE ' || V_Condicion;
							
		   
		    CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 						
											 ,V_StartTimeStampPadre 
											 ,:P_Nombre_Proceso_Padre 
											 ,:V_CADENA 
											 ,'PRO_StandardizationEmail(2.1):'||' Ejecucion de reglas iteracion: '||Trim(V_Contador)||' Regla:'||Trim(V_Cod_DW_Regla_Est_Ubica) 
											 ,V_ERROR); 
											 
		SET P_ERROR = V_ERROR; 
		IF Character_Length(V_ERROR) > 0 
		  THEN LEAVE CUR1; 
		END IF; 
		
		END LOOP CUR1;
		
		CLOSE cur_reglas_select;
		
		IF Character_Length(V_ERROR) > 0 
		THEN LEAVE L1; 
		END IF; 
		---------------------------
		-- Busca y borra si existe la tabla tmp_EmailsEstandarizados1_Ant
		---------------------------
		
		SELECT TableName INTO :Temp
		FROM dbc.tables
		WHERE databasename =:P_BDSTAGE
		AND TableName = 'tmp_EmailsEstandarizados1_Ant' ;
		 
		IF Activity_Count > 0 THEN
			SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_EmailsEstandarizados1_Ant';
		 	CALL DBC.SysExecSQL(:V_CADENA);
		END IF;

		-----------------------------
		-- Se crea y carga la tabla tmp_EmailsEstandarizados1_Ant
		-----------------------------
 		SET V_CADENA = '';
 		SET V_CADENA = 'CREATE MULTISET TABLE '||P_BDSTAGE || '.tmp_EmailsEstandarizados1_Ant
						 AS (
						SELECT	Cod_DW_Reporte_Ubic_Original
							,Buzon||''@''||CAST(DOMINIO_ANT as varchar(100) )||''.''||CAST(EXT AS VARCHAR(100) )Ubicacion_Stand      
							,Texto_Ubicacion_Original
							,Cod_DW_Tipo_Ubicacion
							,Cod_DW_Fuente
							,Lote
							,Id_Buro_Suscriptor
							,Id_Buro_Persona
							,Cod_DW_Cta
							,Cod_DW_Hash
							,Cod_DW_Ubic
							,Valor
							,Texto_Ciudad
							,Codigo_Ciudad_Dane
							,Fecha_Reporte
							,Cod_DW_Ubicacion_Original
							,Cod_DW_Tipo_Ubicacion_Dir
							,Usuario_BD
							,CASE WHEN TRIM(Ubicacion_Stand) <> ''NO VALIDA'' THEN 
								'||P_BDVISTA|| '.eListGetValByIdx(TRIM(Ubicacion_Stand), ''@'', 1)
								ELSE 
								''NO VALIDA'' 
							 END Buzon
							,COALESCE(CASE WHEN TRIM(Ubicacion_Stand) <> ''NO VALIDA'' THEN 
							   '||P_BDVISTA|| '.eListGetValByIdx('||P_BDVISTA|| '.eListGetValByIdx(TRIM(Ubicacion_Stand), ''@'', 2), ''.'', 1)
							   ELSE 
							   ''NO VALIDA'' 
							 END, ''SV'') Dominio_Ant1
                             ,CASE WHEN DOMINIO_ANT1 LIKE ''%;%'' THEN OREPLACE(DOMINIO_ANT1, '';'', ''.'')                       
							  ELSE DOMINIO_ANT1
							 END DOMINIO_ANT							 
							 ,CASE WHEN TRIM(Ubicacion_Stand) <> ''NO VALIDA'' THEN 
							   SUBSTRING(Ubicacion_Stand FROM CHAR(Buzon || ''@'' || Dominio_Ant1) +2 FOR CHAR(Ubicacion_Stand)) 
							   ELSE 
								''NO VALIDA'' 
							  END Ext_Ant
							  ,CASE WHEN Ext_Ant Like ''%;%''  THEN RegExp_Replace(Ext_Ant,''([;])\S+|[;]'','''') 
							        WHEN Ext_Ant Like ''%:%'' THEN RegExp_Replace(Ext_Ant,''([:])\S+|[:]'','''')                
							      Else Ext_Ant
							   END Ext							  
						FROM '||P_BDSTAGE || '.tmp_EmailsEstandarizados A							
						) WITH DATA
						PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original);';

		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
										,V_StartTimeStampPadre
										,:P_Nombre_Proceso_Padre
										,:V_CADENA 
										,'PRO_StandardizationEmail (3):. Crear y carga la tabla tmp_EmailsEstandarizados1_Ant'
										,V_ERROR);
			
		SET P_ERROR = V_ERROR;
		
		IF Character_Length(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF;
		
		SET V_CADENA = '';
 		SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN(Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_EmailsEstandarizados1_Ant';
 		--------------------
		 -- Ejecuta cadena
		 --------------------
		 
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
										,V_StartTimeStampPadre 
										,:P_Nombre_Proceso_Padre 
										,:V_CADENA 
										,'PRO_StandardizationEmail (4):. Actualizar estadisticas a la tabla tmp_EmailsEstandarizados1_Ant' 
										,V_ERROR);
		 	
		 SET P_ERROR = V_ERROR;
		 
		 IF Character_Length(V_ERROR) > 0 THEN
		 	LEAVE L1;
		 END IF;
		---------------------------
		-- Busca y borra si existe la tabla tmp_EmailsEstandarizados1
		---------------------------
		
		SELECT TableName INTO :Temp
		FROM dbc.tables
		WHERE databasename =:P_BDSTAGE
		AND TableName = 'tmp_EmailsEstandarizados1' ;
		 
		IF Activity_Count > 0 THEN
			SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_EmailsEstandarizados1';
		 	CALL DBC.SysExecSQL(:V_CADENA);
		END IF;

		-----------------------------
		-- Se crea y carga la tabla tmp_EmailsEstandarizados1
		-----------------------------
 		SET V_CADENA = '';
 		SET V_CADENA = 'CREATE MULTISET TABLE '||P_BDSTAGE || '.tmp_EmailsEstandarizados1
						 AS (
						SELECT	Cod_DW_Reporte_Ubic_Original
							,CASE WHEN '||P_BDVISTA|| '.VALIDATE_EXPRESSION_R  (TRIM(a.Ubicacion_Stand), ''^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9_.-]+\.[a-zA-Z]{1,4}'') = 1 THEN
								   CASE WHEN '||P_BDVISTA|| '.VALIDATE_EXPRESSION_R  (UPPER(TRIM(a.Ubicacion_Stand)), ''[NNN]{3}@|@[NNN]{3}|^[A-Z0-9._%+-]{1,2}@'' ) = 1 THEN
										 ''NO VALIDA'' 
									  ELSE  '||P_BDVISTA|| '.REPL_CHRS  (UPPER(TRIM(a.Ubicacion_Stand)))
									END
								  ELSE ''NO VALIDA'' 
							END Ubicacion_Stand
							,Texto_Ubicacion_Original
							,Cod_DW_Tipo_Ubicacion         
							,Cod_DW_Fuente                 
							,Lote                          
							,Id_Buro_Suscriptor            
							,Id_Buro_Persona               
							,Cod_DW_Cta                    
							,Cod_DW_Hash                   
							,Cod_DW_Ubic                   
							,Valor                         
							,Texto_Ciudad                  
							,Codigo_Ciudad_Dane            
							,Fecha_Reporte                 
							,Cod_DW_Ubicacion_Original     
							,Cod_DW_Tipo_Ubicacion_Dir     
							,Usuario_BD                    
							,Buzon                         
							,Dominio_Ant1                  
							,DOMINIO_ANT                   
							,Ext_Ant                       
							,Ext                           
						FROM '||P_BDSTAGE || '.tmp_EmailsEstandarizados1_Ant a							
						) WITH DATA
						PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original);';

		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
			,V_StartTimeStampPadre
			,:P_Nombre_Proceso_Padre
			,:V_CADENA 
			,'PRO_StandardizationEmail (5):. Crear y carga la tabla tmp_EmailsEstandarizados1'
			,V_ERROR);
			
		SET P_ERROR = V_ERROR;
		
		IF Character_Length(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF;
		
		SET V_CADENA = '';
 		SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN(Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_EmailsEstandarizados1';
 		--------------------
		 -- Ejecuta cadena
		 --------------------
		 
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
										,V_StartTimeStampPadre 
										,:P_Nombre_Proceso_Padre 
										,:V_CADENA 
										,'PRO_StandardizationEmail (6):. Actualizar estadisticas a la tabla tmp_EmailsEstandarizados1_Ant' 
										,V_ERROR);
		 	
		 SET P_ERROR = V_ERROR;
		 
		 IF Character_Length(V_ERROR) > 0 THEN
		 	LEAVE L1;
		 END IF;
		 		
		---------------------------
		-- Busca y borra si existe la tabla TMP_MailBuzonInvalido
		---------------------------
		
		SELECT TableName INTO :Temp
		FROM dbc.tables
		WHERE databasename =:P_BDSTAGE
		AND TableName = 'TMP_MailBuzonInvalido' ;
		 
		IF Activity_Count > 0 THEN
			SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.TMP_MailBuzonInvalido';
		 	CALL DBC.SysExecSQL(:V_CADENA);
		END IF;

		-----------------------------
		-- Se crea y carga la tabla TMP_MailBuzonInvalido
		-----------------------------
 		SET V_CADENA = '';
 		SET V_CADENA = 'CREATE MULTISET TABLE '||P_BDSTAGE || '.TMP_MailBuzonInvalido
						AS 
						(SELECT Cod_DW_Reporte_Ubic_Original, '||P_BDVISTA|| '.PorcSimilitud(upper(a.Buzon), ExecBuzon.buzon) PorcSimilitud,  a.buzon, ExecBuzon.buzon Excepcion
						FROM '||P_BDSTAGE || '.tmp_EmailsEstandarizados1 A
						INNER JOIN (SEL Upper(cast(Descripcion_Excepcion_Mail as varchar(100))) Buzon
									 From '||P_BDVISTA|| '.V_Excepcion_Mail ) ExecBuzon
						ON '||P_BDVISTA|| '.Similitud_Palabras(upper(a.Buzon), ExecBuzon.buzon,60) = ExecBuzon.buzon
						WHERE Ubicacion_Stand <> ''NO VALIDA'' 
						QUALIFY( Row_Number() Over( Partition by Cod_DW_Reporte_Ubic_Original order by PorcSimilitud DESC) = 1) 
						)WITH DATA
						PRIMARY INDEX(Cod_DW_Reporte_Ubic_Original);';


		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
										,V_StartTimeStampPadre
										,:P_Nombre_Proceso_Padre
										,:V_CADENA 
										,'PRO_StandardizationEmail (7):. Crear y carga la tabla TMP_MailBuzonInvalido'
										,V_ERROR);
			
		SET P_ERROR = V_ERROR;
		
		IF Character_Length(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF;
		
		SET V_CADENA = '';
 		SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.TMP_MailBuzonInvalido';
 		--------------------
		 -- Ejecuta cadena
		 --------------------
		 
		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
										,V_StartTimeStampPadre 
										,:P_Nombre_Proceso_Padre 
										,:V_CADENA 
										,'PRO_StandardizationEmail (8:. Actualizar estadisticas a la tabla TMP_MailBuzonInvalido' 
										,V_ERROR);
		 	
		SET P_ERROR = V_ERROR;
		 
		IF Character_Length(V_ERROR) > 0 THEN
		 	LEAVE L1;
		END IF;
		
		
		
		---------------------------
		-- Busca y borra si existe la tabla TMP_MailDominioCom
		---------------------------
		SELECT TableName INTO :Temp
		FROM dbc.tables
		WHERE databasename =:P_BDSTAGE
		AND TableName = 'TMP_MailDominioCom' ;
		 
		IF Activity_Count > 0 THEN
			SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.TMP_MailDominioCom';
		 	CALL DBC.SysExecSQL(:V_CADENA);
		END IF;

		-----------------------------
		-- Se crea y carga la tabla TMP_MailDominioCom
		-----------------------------
 		SET V_CADENA = '';
 		SET V_CADENA = 'CREATE MULTISET TABLE '||P_BDSTAGE || '.TMP_MailDominioCom
						AS 
						(SELECT Cod_DW_Reporte_Ubic_Original, COALESCE('||P_BDVISTA|| '.PorcSimilitud(a.Dominio_Ant, Dom.Dominio), 0)  PorcSimilitud,  a.Dominio_Ant, Dom.Dominio Dom_Comun
						FROM '||P_BDSTAGE || '.tmp_EmailsEstandarizados1 A
						INNER JOIN (SEL Upper(cast(Descripcion_Dominio_Comun as varchar(100))) Dominio
									 From '||P_BDVISTA|| '.V_Dominio_Comun ) Dom
						ON '||P_BDVISTA|| '.Similitud_Palabras(COALESCE(a.Dominio_Ant, ''SV''), Dom.Dominio,60) = Dom.Dominio  
						WHERE  Ubicacion_Stand <> ''NO VALIDA''         
						QUALIFY( Row_Number() Over( Partition by Cod_DW_Reporte_Ubic_Original order by PorcSimilitud DESC) = 1) 
						)WITH DATA
						PRIMARY INDEX(Cod_DW_Reporte_Ubic_Original);';


		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
										,V_StartTimeStampPadre
										,:P_Nombre_Proceso_Padre
										,:V_CADENA 
										,'PRO_StandardizationEmail (11):. Crear y carga la tabla TMP_MailDominioCom'
										,V_ERROR);
			
		SET P_ERROR = V_ERROR;
		
		IF Character_Length(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF;
		
		SET V_CADENA = '';
 		SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.TMP_MailDominioCom';
		
 		--------------------
		-- Ejecuta cadena
		-------------------- 
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
										,V_StartTimeStampPadre 
										,:P_Nombre_Proceso_Padre 
										,:V_CADENA 
										,'PRO_StandardizationEmail (12):. Actualizar estadisticas a la tabla TMP_MailDominioCom' 
										,V_ERROR);
		 	
		 SET P_ERROR = V_ERROR;
		 
		 IF Character_Length(V_ERROR) > 0 THEN
		 	LEAVE L1;
		 END IF;
		
	
		---------------------------
		-- Busca y borra si existe la tabla TMP_MailDominioInvalido
		---------------------------
		SELECT TableName INTO :Temp
		FROM dbc.tables
		WHERE databasename =:P_BDSTAGE
		AND TableName = 'TMP_MailDominioInvalido' ;
		 
		IF Activity_Count > 0 THEN
			SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.TMP_MailDominioInvalido';
		 	CALL DBC.SysExecSQL(:V_CADENA);
		END IF;

		-----------------------------
		-- Se crea y carga la tabla TMP_MailDominioInvalido
		-----------------------------
 		SET V_CADENA = '';
 		SET V_CADENA = 	'CREATE MULTISET TABLE '||P_BDSTAGE || '.TMP_MailDominioInvalido
						AS 
						(SELECT Cod_DW_Reporte_Ubic_Original, '||P_BDVISTA|| '.PorcSimilitud(a.Dominio_Ant, ExecDominio.Dominio) PorcSimilitud,  a.Dominio_Ant Dominio, ExecDominio.Dominio Excepcion
						FROM '||P_BDSTAGE || '.tmp_EmailsEstandarizados1 A
						INNER JOIN (SEL Upper(CAST(Descripcion_Excepcion_Mail as varchar(100))) Dominio
									 From '||P_BDVISTA|| '.V_Excepcion_Mail ) ExecDominio
						ON '||P_BDVISTA|| '.Similitud_Palabras(a.Dominio_Ant, ExecDominio.Dominio,60) = ExecDominio.Dominio
						WHERE Ubicacion_Stand <> ''NO VALIDA'' 
						QUALIFY( Row_Number() Over( Partition by Cod_DW_Reporte_Ubic_Original order by PorcSimilitud DESC) = 1) 
						)WITH DATA
						PRIMARY INDEX(Cod_DW_Reporte_Ubic_Original);';


		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
										,V_StartTimeStampPadre
										,:P_Nombre_Proceso_Padre
										,:V_CADENA 
										,'PRO_StandardizationEmail (13):. Crear y carga la tabla TMP_MailDominioInvalido'
										,V_ERROR);
			
		SET P_ERROR = V_ERROR;
		
		IF Character_Length(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF;
		
		SET V_CADENA = '';
 		SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.TMP_MailDominioInvalido';
		
 		--------------------
		-- Ejecuta cadena
		-------------------- 
		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
										,V_StartTimeStampPadre 
										,:P_Nombre_Proceso_Padre 
										,:V_CADENA 
										,'PRO_Standardizati
 onEmail (14):. Actualizar estadisticas a la tabla TMP_MailDominioInvalido' 
										,V_ERROR);
		 	
		SET P_ERROR = V_ERROR;
		 
		IF Character_Length(V_ERROR) > 0 THEN
		 	LEAVE L1;
		END IF;
		 
		---------------------------
		-- Busca y borra si existe la tabla TMP_MailDominioInvalido
		---------------------------
		
		SELECT TableName INTO :Temp
		FROM dbc.tables
		WHERE databasename =:P_BDSTAGE
		AND TableName = 'TMP_MailExtesionCo' ;
		 
		IF Activity_Count > 0 THEN
			SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.TMP_MailExtesionCo';
		 	CALL DBC.SysExecSQL(:V_CADENA);
		END IF;

		-----------------------------
		-- Se crea y carga la tabla TMP_MailExtesionCo
		-----------------------------
 		SET V_CADENA = '';
 		SET V_CADENA = 	'CREATE MULTISET TABLE '||P_BDSTAGE || '.TMP_MailExtesionCo
						AS 
						(SEL  '||P_BDVISTA|| '.PorcSimilitud(a.Ext, Extension.Extension) PorcSimilitud, Ext, Extension.Extension 
						FROM (Select Ext  From '||P_BDSTAGE || '.tmp_EmailsEstandarizados1  Where Ext is not null  AND Char(Ext) > 1  Group by 1 )  A
						INNER JOIN (SEL Upper(cast(Descripcion_Extension_Dominio as varchar(100))) Extension 
									 From '||P_BDVISTA|| '.v_extension_dominio ) Extension
						ON '||P_BDVISTA|| '.Similitud_Palabras(a.Ext, Extension.Extension,60) = Extension.Extension
						AND CHAR(A.Ext) < CHAR(Extension.Extension)
						AND PorcSimilitud BETWEEN 70 AND 99
						QUALIFY( Row_Number() Over( Partition by Ext order by PorcSimilitud DESC) = 1) 
						)WITH DATA
						PRIMARY INDEX(Ext);';


		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
										,V_StartTimeStampPadre
										,:P_Nombre_Proceso_Padre
										,:V_CADENA 
										,'PRO_StandardizationEmail (15):. Crear y carga la tabla TMP_MailExtesionCo'
										,V_ERROR);
			
		SET P_ERROR = V_ERROR;
		
		IF Character_Length(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF;
		
		SET V_CADENA = '';
 		SET V_CADENA = 'COLLECT STAT INDEX (Ext) ON ' || P_BDSTAGE ||'.TMP_MailExtesionCo';
 		--------------------
		 -- Ejecuta cadena
		 --------------------
		 
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
										,V_StartTimeStampPadre 
										,:P_Nombre_Proceso_Padre 
										,:V_CADENA 
										,'PRO_StandardizationEmail (16):. Actualizar estadisticas a la tabla TMP_MailExtesionCo' 
										,V_ERROR);
		 	
		 SET P_ERROR = V_ERROR;
		 
		 IF Character_Length(V_ERROR) > 0 THEN
		 	LEAVE L1;
		 END IF;	
         	
		 		
		---------------------------
		-- Busca y borra si existe la tabla tmp_EmailsEstandarizados2
		---------------------------
 		SELECT TableName INTO :Temp
 		FROM dbc.tables
 		WHERE databasename =:P_BDSTAGE
 		AND TableName = 'tmp_EmailsEstandarizados2' ;
 		
 		IF Activity_Count > 0 THEN
 			SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_EmailsEstandarizados2';
 			CALL DBC.SysExecSQL(:V_CADENA);
 		END IF;
		
 	 	
 	 	SET V_CADENA = ''; 
		SET V_CADENA = 'CREATE MULTISET TABLE '||P_BDSTAGE || '.tmp_EmailsEstandarizados2
					AS 
					(SELECT A.Cod_DW_Reporte_Ubic_Original  							   
						   ,UPPER(A.Ubicacion_Stand)  Ubicacion_Stand 
						   ,texto_Ubicacion_Original             
						   ,Cod_DW_Tipo_Ubicacion         
						   ,Cod_DW_Fuente                 
						   ,Lote                          
						   ,Id_Buro_Suscriptor            
						   ,Id_Buro_Persona               
						   ,Cod_DW_Cta                    
						   ,Cod_DW_Hash                   
						   ,Cod_DW_Ubic                   
						   ,Valor                         
						   ,Texto_Ciudad                  
						   ,Codigo_Ciudad_Dane            
						   ,Fecha_Reporte                 
						   ,Cod_DW_Ubicacion_Original     
						   ,Cod_DW_Tipo_Ubicacion_Dir     
						   ,Usuario_BD                    
						   ,A.Buzon             
						   ,CASE WHEN DomComun.Cod_DW_Reporte_Ubic_Original Is not null 
							 THEN DomComun.Dom_Comun
							 ELSE A.Dominio_Ant                          
							END  Dominio_Ant2     
						   ,CASE WHEN (UPPER(TRIM(COALESCE(a.Buzon, ''SV'')))(CASESPECIFIC) <> LOWER(TRIM(COALESCE(a.Buzon, ''SV''))) (CASESPECIFIC))
							  THEN 1
							ELSE 0
						   END ValBuzon
						   ,cast(Dominio_ant2 as varchar(100)) || ''.'' || CAST(COALESCE(ExtCom.Extension, A.Ext) AS varchar(100) ) Dominio                   						   
						   ,A.Ext 
					FROM '||P_BDSTAGE || '.tmp_EmailsEstandarizados1 A

					LEFT JOIN  '||P_BDSTAGE || '.TMP_MailDominioCom DomComun
					ON a.Cod_DW_Reporte_Ubic_Original = DomComun.Cod_DW_Reporte_Ubic_Original					

					LEFT JOIN '||P_BDSTAGE || '.TMP_MailExtesionCo ExtCom
					ON A.Ext = ExtCom.Ext

					)WITH DATA 
					PRIMARY INDEX(Cod_DW_Reporte_Ubic_Original);';

		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
										,V_StartTimeStampPadre 
										,:P_Nombre_Proceso_Padre 
										,:V_CADENA 
										,'PRO_StandardizationEmail (17):. Crear y carga la tabla tmp_EmailsEstandarizados2'
										,V_ERROR);
				
		 SET P_ERROR = V_ERROR;
		
		 IF Character_Length(V_ERROR) > 0 THEN
		 	LEAVE L1;
		 END IF;
				
		SET V_CADENA = '';
 		SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_EmailsEstandarizados2';
 		--------------------
		 -- Ejecuta cadena
		 --------------------
		 
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
										,V_StartTimeStampPadre 
										,:P_Nombre_Proceso_Padre 
										,:V_CADENA 
										,'PRO_StandardizationEmail (18):. Actualizar estadisticas a la tabla tmp_EmailsEstandarizados2' 
										,V_ERROR);
		 	
		 SET P_ERROR = V_ERROR;
		 
		 IF Character_Length(V_ERROR) > 0 THEN
		 	LEAVE L1;
		 END IF;
			 			
 	 	---------------------------
		-- Busca y borra si existe la tabla TMP_Valores_Atributo
		---------------------------
 		SELECT TableName INTO :Temp
 		FROM dbc.tables
 		WHERE databasename =:P_BDSTAGE
 		AND TableName = 'TMP_Valores_Atributo' ;
 		
 		IF Activity_Count > 0 THEN
 			SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.TMP_Valores_Atributo';
 			CALL DBC.SysExecSQL(:V_CADENA);
 		END IF;
		
 	 	
 	 	SET V_CADENA = ''; 
		SET V_CADENA = 'CREATE MULTISET TABLE '||P_BDSTAGE || '.TMP_Valores_Atributo
						As
						(select Valor_Origen, Descripcion_Atributo, Cod_DW_Atributo,Descripcion_Tipo_Atributo
						 from '||P_BDDATOS || '.ATRIBUTO A
						 INNER JOIN '||P_BDDATOS || '.TIPO_ATRIBUTO B
						 ON A.Cod_DW_Tipo_Atributo = B.Cod_DW_Tipo_Atributo
						 where Descripcion_Tipo_Atributo IN ( ''Excepciones'', ''Tipo_Correo'', ''Servidor_Correo'',  ''Extension_Dominio'')        
						)WITH DATA
						PRIMARY INDEX(Valor_Origen);';

		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
				,V_StartTimeStampPadre 
				,:P_Nombre_Proceso_Padre 
				,:V_CADENA 
				,'PRO_StandardizationEmail (19):. Crear y carga la tabla TMP_Valores_Atributo'
				,V_ERROR);
				
		SET P_ERROR = V_ERROR;
		
		 IF Character_Length(V_ERROR) > 0 THEN
		 	LEAVE L1;
		 END IF;
					
		SET V_CADENA = '';
 		SET V_CADENA = 'COLLECT STAT INDEX (Valor_Origen) ON ' || P_BDSTAGE ||'.TMP_Valores_Atributo';
 		--------------------
		 -- Ejecuta cadena
		 --------------------
		 
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
		 	,V_StartTimeStampPadre 
		 	,:P_Nombre_Proceso_Padre 
		 	,:V_CADENA 
		 	,'PRO_StandardizationEmail (20):. Actualizar estadisticas a la tabla TMP_Valores_Atributo' 
		 	,V_ERROR);
		 	
		 SET P_ERROR = V_ERROR;
		 
		 IF Character_Length(V_ERROR) > 0 THEN
		 	LEAVE L1;
		 END IF;

		---------------------------
		-- Busca y borra si existe la tabla Emails_Estandarizados
		---------------------------
 		SELECT TableName INTO :Temp
 		FROM dbc.tables
 		WHERE databasename =:P_BDSTAGE
 		AND TableName = 'Emails_Estandarizados' ;
 		
 		IF Activity_Count > 0 THEN
 			SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.Emails_Estandarizados';
 			CALL DBC.SysExecSQL(:V_CADENA);
 		END IF;
		
		SET V_CADENA = ''; 
		SET V_CADENA = 'CREATE MULTISET TABLE '||P_BDSTAGE || '.Emails_Estandarizados
						AS (
						SELECT	mails.Cod_DW_Reporte_Ubic_Original
						,COALESCE(CAST(lower(mails.Buzon)|| ''@''|| lower(COALESCE( ACEP.Normalizado, mails.Dominio )) AS VARCHAR(512)),OTR.Texto_Ubicacion_Original)  Ubicacion_Stand2								
						,OTR.Texto_Ubicacion_Original
						,OTR.Cod_DW_Tipo_Ubicacion
						,OTR.Cod_DW_Fuente                      
						,OTR.Lote
						,OTR.Id_Buro_Suscriptor
						,OTR.Id_Buro_Persona
						,OTR.Cod_DW_Cta
						,OTR.Cod_DW_Hash
						,OTR.Cod_DW_Ubic
						,OTR.Valor
						,COALESCE( CAST(NULL AS VARCHAR(512) ), '''') Texto_Ciudad
						,COALESCE( CAST(NULL AS VARCHAR(20) ), '''') Codigo_Ciudad_Dane
						,OTR.Fecha_Reporte								
						,OTR.Cod_DW_Ubicacion_Original
						,OTR.Cod_DW_Tipo_Ubicacion_Dir
						,OTR.Usuario_BD
						,lower(mails.Buzon) Buzon
						,COALESCE( lower(ACEP.Normalizado), lower(mails.Dominio) ) Dominio
						,COALESCE(TC.Cod_DW_Atributo, -1) Cod_Dw_Servidor_Correo
						,COALESCE(TCTC.Cod_DW_Atributo,-1) Cod_Dw_Tipo_Correo															
						,CASE WHEN (ExcDom.Valor_Origen IS NOT NULL 
								   OR ExcBuz.Valor_Origen IS NOT NULL OR mails.VALBUZON = 0 
								   OR mails.Ubicacion_Stand = ''NO VALIDA''
								   OR Buzon.Cod_DW_Reporte_Ubic_Original IS NOT NULL
								   OR Dominio.Cod_DW_Reporte_Ubic_Original IS NOT NULL 
                                   OR ExtDom.Descripcion_extension_Dominio IS NOT NULL
                                   OR '||P_BDVISTA|| '.VALIDATE_EXPRESSION_R  (mails.Buzon, ''([A-Za-z0-9])\1{3}'' ) = 1		
								   OR A.Descripcion_Exclusion_Email IS NOT NULL
							       ) THEN ''NO VALIDA''							  
						  ELSE ''VALIDA''
						END DIR_CB_VALIDA															
						FROM  '||P_BDSTAGE || '.tmp_EmailsEstandarizados2 mails
						LEFT JOIN (SELECT    P.Valor
											,P.Normalizado                                                               
									FROM '||P_BDDATOS || '.GRUPO_PARAMETRO AS GP
									INNER JOIN '||P_BDDATOS || '.TIPO_PARAMETRO AS TP 
									ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
									INNER JOIN  '||P_BDDATOS || '.SUBTIPO_PARAMETRO AS STP
									ON  TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
									LEFT JOIN '||P_BDDATOS || '.PARAMETRO AS P
									ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
									WHERE   GP.Nombre_Grupo_Parametro = ''ACEPCIONES''
									AND TP.Nombre_Tipo_Parametro = ''EMAIL''
									AND STP.Nombre_Subtipo_Parametro=''DOMINIO'') ACEP
						ON mails.Dominio = ACEP.Valor

						LEFT JOIN '||P_BDSTAGE || '.TMP_Valores_Atributo TC
						ON '||P_BDVISTA||'.eListGetValByIdx(mails.Dominio, ''.'', 1)= TC.Valor_Origen
						AND TC.Descripcion_Tipo_Atributo = ''Servidor_Correo''

						LEFT JOIN '||P_BDSTAGE || '.TMP_Valores_Atributo ExcDom
						ON COALESCE( ACEP.Normalizado, mails.Dominio ) = ExcDom.Valor_Origen
						AND ExcDom.Descripcion_Tipo_Atributo = ''Excepciones''

						LEFT JOIN '||P_BDSTAGE || '.TMP_MailBuzonInvalido Buzon
						ON mails.Cod_DW_Reporte_Ubic_Original = Buzon.Cod_DW_Reporte_Ubic_Original

						LEFT JOIN '||P_BDSTAGE || '.TMP_MailDominioInvalido Dominio
						ON mails.Cod_DW_Reporte_Ubic_Original = Dominio.Cod_DW_Reporte_Ubic_Original

						LEFT JOIN '||P_BDSTAGE || '.TMP_Valores_Atributo  ExcBuz
						ON mails.Buzon = ExcBuz.Valor_Origen
						AND ExcBuz.Descripcion_Tipo_Atributo = ''Excepciones''  

						LEFT JOIN  '||P_BDSTAGE || '.TMP_Valores_Atributo TCTC
						ON TC.Descripcion_Atributo = TCTC.Valor_Origen
						AND  TCTC.Descripcion_Tipo_Atributo = ''Tipo_Correo''

						LEFT JOIN '||P_BDVISTA||'.V_Extension_dominio ExtDom						
						ON REC_VISTA.eListGetValByIdx( COALESCE( lower(ACEP.Normalizado), lower(mails.Dominio) ), ''.'',1) = ExtDom.Descripcion_extension_Dominio
						AND ExtDom.Descripcion_extension_Dominio NOT Like ''%.%''
						
						INNER JOIN '||P_BDSTAGE || '.tmp_EmailsEstandarizados OTR
						ON OTR.Cod_DW_Reporte_Ubic_Original = mails.Cod_DW_Reporte_Ubic_Original
						
						LEFT JOIN (
												SELECT Descripcion_Exclusion_Email, Valor_Exclusion_Email 
												FROM '|| P_BDVISTA ||'.V_Exclusion_Email
								
											) A
						ON OTR.Texto_Ubicacion_Original = A.Valor_Exclusion_Email  /*#1*/

						) WITH DATA
						PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original);';

		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
										,V_StartTimeStampPadre 
										,:P_Nombre_Proceso_Padre 
										,:V_CADENA 
										,'PRO_StandardizationEmail (21):. Crear y carga la tabla Emails_Estandarizados'
										,V_ERROR);
				
		SET P_ERROR = V_ERROR;
		
		IF Character_Length(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF;
		
		--------------------
		-- Actualiza estadisticas a Emails_Estandarizados
		--------------------
 		SET V_CADENA = '';
 		SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.Emails_Estandarizados';
 		
 		--------------------
		-- Ejecuta cadena
		--------------------
 		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
 				,V_StartTimeStampPadre 
 				,:P_Nombre_Proceso_Padre 
 				,:V_CADENA 
 				,'PRO_StandardizationEmail (22):. Actualizar estadisticas a la tabla Emails_Estandarizados' 
 				,V_ERROR);
				
		------------------------------------------------------------------------------------
		--03/08/2022
		-- Cursor de reglas para ETAPA IN (2)
		-- Reglas de Antiguedad en los datos que se Validan si se cumple con la condicion
		------------------------------------------------------------------------------------
		SET V_CADENA = 'SELECT  Sentencia
				,Condicion
				,Flag_Recursiva
				,Cod_DW_Regla_Est_Ubica
				FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
				WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
							select Cod_DW_Atributo
							from '|| P_BDDATOS ||'.ATRIBUTO
							where Cod_DW_Tipo_Atributo in (
							select Cod_DW_Tipo_Atributo
							from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
							where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
					) AND Valor_Origen = ''Email''
					) AND  Flag_Activo = ''S'' AND ETAPA IN (2)
				ORDER BY Orden'; 

		SET V_Contador = 0;
		PREPARE the_statement FROM V_CADENA; 
		OPEN cur_reglas_select; 			
			CUR2: LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; 
			
		IF SQLCODE <> 0 THEN 
				LEAVE CUR2; 
		END IF;  

		SET V_Contador = V_Contador +1;
		SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.Emails_Estandarizados
				SET ' || V_Sentencia || '
				WHERE ' || V_Condicion;   


		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 						
				,V_StartTimeStampPadre 
				,:P_Nombre_Proceso_Padre 
				,:V_CADENA 
				,'PRO_StandardizationEmail(22):'||' Ejecucion de reglas 2 iteracion: '||trim(V_Contador)||' Regla:'||trim(V_Cod_DW_Regla_Est_Ubica) 
				,V_ERROR); 

		SET P_ERROR = V_ERROR; 
		IF CHARACTER_LENGTH(V_ERROR) > 0 
				THEN LEAVE CUR2; 
		END IF; 

		END LOOP CUR2;
		CLOSE cur_reglas_select;
		
		------------------------------------------------------------------------------------
		--03/08/2022
		-- FIN
		------------------------------------------------------------------------------------
				
				
				
 	END L1;
END;

REPLACE PROCEDURE REC_DATOS.PRO_StandardizationGeografica
( IN P_Lote INTEGER , IN P_StartTimeStampPadre VARCHAR(20) , IN P_Nombre_Proceso_Padre VARCHAR(30) , IN P_BDDATOS VARCHAR(20) , IN P_BDVISTA VARCHAR(20) , IN P_BDSTAGE VARCHAR(20) , OUT P_ERROR VARCHAR(32000) ) /*
 * ##################################################################################################
 * 
 * Objetivo:		Estandariza las direcciones fisicas como ubicacion del insumo
 *			InsumoDireccionFisica, dejando el resultado en DireccionFisica_Estandarizada
 * Fecha:		2016/11/09
 * Realizado por:	Luis E Ramirez
 * Proyecto:		Nuevo reconocer
 * Script:		PRO_StandardizationGeografica BCK 12 sept antes de a?adir campo de reglas a stg
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha	Objetivo				                            Realizado por
 * 2017/12/28	Agregar el codigo dane hasta la tabla	aariza - Capgemini
 *		DireccionFisica_Estandarizada
 * 2018/03/06	Se agrega el campo Tipo_Direccion y	Capgemini
 *		se elimina el calculo del cod dane	
 *
 * 2018/03/27	Los registros marcados como no validos	         Capgemini
 *		y enviados a la tabla tmp_Dire_Estan_Val
 *		ya no se excluyen del proceso de
 *		estandarizacion
 * 2018-05-08 #1 ajuste por bug en teradata pruebas	             Capgemini
 * 2018-05-09 #2 ajuste null por ubicaciÃ¸ÂŠÃ´Â³n original y nvl
 *		para armado de direcciÃ¸ÂŠÃ´Â³n		                         Capgemini
 * 2018-05-18 #3 ajuste no procesar nulos	                 	 Capgemini
 * 2018-05-18 #4 ajuste severidad nulos		                     Capgemini
 * 2018-09-27 #5 ajuste performance mantis 7036		             Capgemini
 * 2019-02-10 # Se ajusta le SP para que realice de mejor 
 *            forma la Gestion_Registro Valida/No Valida, 
 *            Mediante  las UDF ValidacionDirRural   y
 *            ValidacionDirVia,ValidacionDirMZ                    Fernando Garrido M
 * 30/01/2023  Se reinician las variables vsentencia                                    Omar Delgado.
 * 2021-02-10 #6 Se ajusta regla para calculo campo DIR_CB_VALIDA  Jeimmy Chavez
 * ---------------------------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ##################################################################################################
 */ ------------------------
 -- Declaracion de variables
 ------------------------
 BEGIN DECLARE V_DESC_ERR VARCHAR(1000); DECLARE V_SQL INTEGER; DECLARE V_STA VARCHAR(20); DECLARE V_StartTimeStampPadre TIMESTAMP(6); DECLARE V_FECHA_HORA_INI TIMESTAMP(6); DECLARE W_Log_TD_Detalle_ID INTEGER; DECLARE W_ERROR VARCHAR(32000); DECLARE V_ERROR VARCHAR(32000); DECLARE V_CADENA VARCHAR(32000); DECLARE V_CADENA1 VARCHAR(10000); DECLARE Temp CHAR(30); DECLARE V_Sentencia VARCHAR(500); DECLARE V_Condicion VARCHAR(500); DECLARE V_Flag_Recursiva VARCHAR(1); DECLARE V_COUNT INTEGER; DECLARE V_Contador INTEGER; DECLARE V_Cod_DW_Regla_Est_Ubica INTEGER; DECLARE cur_reglas_select NO SCROLL CURSOR FOR the_statement; DECLARE cur_count_rec NO SCROLL CURSOR FOR the_statement_1; DECLARE CONTINUE HANDLER FOR SQLEXCEPTION BEGIN SET V_SQL = SQLCODE; SET V_STA = SQLSTATE; END; L1: BEGIN SET P_ERROR = ''; SET V_StartTimeStampPadre = CAST(P_StartTimeStampPadre AS TIMESTAMP(6) FORMAT 'yyyy-mm-ddhh:mi:ss'); SET V_COUNT = 1; SET V_SQL = 0; SET V_STA = ''; --------------------------------------------------------------
 -- Busca y borra si existe la tabla tmp_EmailsEstandarizados
 -------------------------------------------------------------- 
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Estandarizada' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -------------------------------------------------------------- -------------------------------
 -- Se crea y carga la tabla tmp_DireFisica_Estandarizada
 -- Se hace la primera limpieza de caracteres especiales en la ciudad y el texto de la direccion
 -------------------------------------------------------------- --------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada
				 AS (
				SELECT	 dir.Cod_DW_Reporte_Ubic_Original
					,nvl(' || P_BDVISTA || '.REPLEXPREG( Ubicacion_Stand_Prev, ''[^A-Z^0-9^ ^-^. ' || 'D1'XC'F1'XC || ']'','' ''),Texto_Ubicacion_Original) as Ubicacion_Stand /*#2*/
					,dir.Texto_Ubicacion_Original
					,dir.Cod_DW_Tipo_Ubicacion
					,dir.Cod_DW_Fuente
					,dir.Lote
					,dir.Id_Buro_Suscriptor
					,dir.Id_Buro_Persona
					,dir.Cod_DW_Cta
					,dir.Cod_DW_Hash
					,dir.Cod_DW_Ubic
					,dir.Valor                               
					,GEO.Descripcion_Ciudad Ciudad
					,dir.Codigo_Ciudad_Dane 
					,dir.Fecha_Reporte
					
					,Cod_DW_Ubicacion_Original
					,Cod_DW_Tipo_Ubicacion_Dir
					,Usuario_BD
					,cast('''' as varchar(20)) Reglas
					,dir.Tipo_Direccion
				FROM (
					SELECT	a.*
						,' || P_BDVISTA || '.REPL_CHRS  (UPPER(Texto_Ubicacion_Original), ''GEO'') Ubicacion_Stand_Prev
						,' || P_BDVISTA || '.REPL_CHRS  (TRIM(' || P_BDVISTA || '.REPLEXPREG(' || P_BDVISTA || '.REPLEXPREG( UPPER(Texto_Ciudad), ''^[A-Za-z ]?$''),''[ ]{2,100}'', '' '') ), ''GEO'') Texto_Ciudad_Prev 
					FROM ' || P_BDSTAGE ||'.InsumoDireccionFisica a ) dir
				LEFT JOIN '|| P_BDVISTA ||'.V_Geografia GEO
					ON GEO.Cod_Dane_Ciudad = dir.Codigo_Ciudad_Dane
				
				) WITH DATA
				PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (1):. Crear y carga la tabla tmp_DireFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------
 -- Actualiza estadisticas a tmp_DireFisica_Estandarizada
 ------------------------------------------------------------
 SET V_CADENA = '';
 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN(Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada'; 
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Actualizar estadisticas a la tabla tmp_DireFisica_Estandarizada' ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; 
 END IF; 
 ------------------------------------------------------------
 -- Cursor de reglas para ETAPA IN (2)
 -- Reglas de limpieza basadas en patrones de texto
 ------------------------------------------------------------
 SET V_CADENA = 'SELECT	Sentencia
						,Condicion
						,Flag_Recursiva
						,Cod_DW_Regla_Est_Ubica
					FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
					WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
							select Cod_DW_Atributo
							from '|| P_BDDATOS ||'.ATRIBUTO
							where Cod_DW_Tipo_Atributo in (
								select Cod_DW_Tipo_Atributo
								from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
								where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
							) AND Valor_Origen = ''Geografica''
						) AND  Flag_Activo = ''S'' AND ETAPA IN (2)
					ORDER BY Orden';
					
 SET V_Sentencia = '';
 SET V_Condicion = '';
 SET V_Cod_DW_Regla_Est_Ubica = '';
 SET V_Contador = 0; 
 PREPARE the_statement FROM V_CADENA; 
 
 OPEN cur_reglas_select; 
 CUR1: LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; 
 
 IF SQLCODE <> 0 THEN LEAVE CUR1; 
 END IF; ---  Ini HAH
 
 SET V_FECHA_HORA_INI = CAST(CURRENT_TIMESTAMP AS TIMESTAMP(6)); --- Fin HAH
 SET V_Contador = V_Contador +1; 
 SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
				SET ' || V_Sentencia || '
					, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
				WHERE ' || V_Condicion ; 
 
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica(2.1):'||' Ejecucion de reglas 2 iteracion: '||trim(V_Contador)||' Regla:'||trim(V_Cod_DW_Regla_Est_Ubica) ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE CUR1; 
 END IF; 
 END LOOP CUR1; 
 CLOSE cur_reglas_select; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; 
 END IF; 
 --------------------------------------------------------------
 -- Reemplaza Toponimos
 -- Busca y borra si existe la tabla tmp_DireFisica_Topo_a
 --------------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Topo_a' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo_a'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_a
				 AS
				(
					SELECT	a.Cod_DW_Reporte_Ubic_Original
						,CASE WHEN b.Valor IS NULL
								THEN Ubicacion_Stand
							  ELSE OREPLACE(Ubicacion_Stand, b.Valor, b.Normalizado)
						END Ubicacion_Stand
						,a.Ciudad
						,a.Codigo_Ciudad_Dane
						,a.Tipo_Direccion
					FROM  (
						select *
						from '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
						qualify row_number() over(partition by Cod_DW_Reporte_Ubic_Original
								order by Cod_DW_Reporte_Ubic_Original) = 1
						) a
					LEFT JOIN (
						SELECT   P.Valor
							,P.Normalizado
						FROM '|| P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
							INNER JOIN '|| P_BDDATOS ||'.TIPO_PARAMETRO AS TP
							ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
							INNER JOIN  '|| P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
							ON  TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
							INNER JOIN '|| P_BDDATOS ||'.PARAMETRO AS P
							ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
						WHERE   GP.Nombre_Grupo_Parametro = ''TOPONIMOS''
								  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
						  ) b
						   ON a.Ubicacion_Stand like ''%'' || b.Valor || ''%''
				) WITH DATA
				PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Crea la tabla tmp_DireFisica_Topo_a' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------
 -- Actualiza estadisticas a tmp_DireFisica_Estandarizada
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_a'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo_a' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------
 -- Busca y borra si existe la tabla tmp_DireFisica_Topo
 ------------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Topo' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo'; CALL DBC.SysExecSQL(:V_CADENA); END IF; ------------------------------------------------------------
 -- Se crea y carga la tabla tmp_DireFisica_Topo
 -- Separacion del texto de la direccion en palabras
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo
				 AS (
				 WITH RECURSIVE Text_Dir_Palabras
				 (Cod_DW_Reporte_Ubic_Original
				 ,ID_S
				 ,POS
				 ,PALABRA
				 ,Ubicacion_Stand
				 ,Ciudad
				 ,Codigo_Ciudad_Dane
				 ,Tipo_Direccion
				) AS
				(
					SELECT Cod_DW_Reporte_Ubic_Original
						,0
						,0
						, cast('''' as varchar(100))
						,Ubicacion_Stand  
						,Ciudad
						,Codigo_Ciudad_Dane
						,Tipo_Direccion
					from '||P_BDSTAGE || '.tmp_DireFisica_Topo_a
					UNION ALL
					SELECT Cod_DW_Reporte_Ubic_Original
						,ID_S+1
						,CASE WHEN POSITION('' '' IN Ubicacion_Stand) > 0
								THEN POSITION('' '' IN Ubicacion_Stand)
							 ELSE CHARACTER_LENGTH(Ubicacion_Stand)
						END POS1
						,TRIM(BOTH '' '' FROM SUBSTR(Ubicacion_Stand, 0, POS1+1))
						,TRIM(SUBSTR(Ubicacion_Stand, POS1+1))
						,Ciudad
						,Codigo_Ciudad_Dane
						,Tipo_Direccion
					FROM Text_Dir_Palabras
					WHERE POS1 > 0
				)
				SELECT Cod_DW_Reporte_Ubic_Original
					,ID_S
					,PALABRA 
					,Ciudad
					,Codigo_Ciudad_Dane
					,Ubicacion_Stand
					,Tipo_Direccion
				FROM Text_Dir_Palabras
				WHERE ID_S > 0
				
				) WITH DATA
				PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)'; CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (3):. Crear y carga la tabla tmp_DireFisica_Topo' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------
 -- Actualiza estadisticas a tmp_DireFisica_Topo
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (4):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; /*
		BEGIN ETAPA TOPONIMO
		begin tmp_DireFisica_Topo
		*/ -----------------------------------------------------------
 -- Busca y borra si existe la tabla tmp_DireFisica_Topo_II
 -----------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Topo_II' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo_II'; CALL DBC.SysExecSQL(:V_CADENA); END IF; ---------------------------------------------------------------------------------------
 -- Se crea y carga la tabla tmp_DireFisica_Topo_II
 -- Se aplican acepciones y no existe, se llama la funcion GENACCEPAUT para
 --  intentar crearla
 ---------------------------------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II
				AS (
				SELECT	A.Cod_DW_Reporte_Ubic_Original
				,A.ID_S
				,CASE WHEN ACEP.Valor IS NULL
						AND ' || P_BDVISTA || '.VALIDATE_EXPRESSION_R(A.PALABRA, ''^[A-Za-z]{3,20}*$'')=1
						AND A.PALABRA IS NOT NULL
						AND ACEP.Valor IS NULL
					THEN ' || P_BDVISTA || '.GENACCEPAUT(A.PALABRA, SOUNDEX(A.PALABRA))
				END NEW_ACEPCION
				,CASE WHEN ACEP.Valor IS NOT NULL
					THEN ACEP.Normalizado
					  WHEN NEW_ACEPCION IS NOT NULL AND CHAR(NEW_ACEPCION) <> 0
					THEN NEW_ACEPCION
					  ELSE A.PALABRA
				END PALABRA
				,A.Ubicacion_Stand
				,A.PALABRA PALABRA_ORI
				,A.Ciudad
				,A.Codigo_Ciudad_Dane
				,A.Tipo_Direccion
				FROM ' || P_BDSTAGE ||'.tmp_DireFisica_Topo A
				LEFT JOIN (
				SELECT	P.Valor
					,P.Normalizado
				FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
				INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
					ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
				INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
					ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
				INNER JOIN ' || P_BDDATOS ||'.PARAMETRO AS P
					ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
				WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
						  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
					) ACEP
				ON TRIM(A.PALABRA) = ACEP.Valor /*#1*/
				) WITH DATA
				PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)'; CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (5):. Crear y carga la tabla tmp_DireFisica_Topo_II' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------
 -- Actualiza estadisticas a tmp_DireFisica_Topo
 -------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (6):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo_II' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------
 -- Inserta las nuevas acepciones en parametros
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'INSERT INTO ' || P_BDDATOS ||'.PARAMETRO
				SELECT	P.Cod_DW_Parametro + SUM( 1 ) OVER (ROWS UNBOUNDED PRECEDING) Cod_DW_Parametro
					,A.PALABRA_ORI Valor
					,A.PALABRA Normalizado
					,'|| P_Lote || '
					,NULL
					,1
					,USER
					,STP1.Cod_DW_Subtipo_Parametro
					,NULL
					,date
				FROM (SELECT *
					FROM ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II
					WHERE NEW_ACEPCION IS NOT NULL AND CHAR(NEW_ACEPCION) <> 0
					QUALIFY ROW_NUMBER() OVER(PARTITION BY PALABRA_ORI, PALABRA ORDER BY PALABRA_ORI) = 1
				   ) A
				CROSS JOIN (
					SELECT STP.Cod_DW_Subtipo_Parametro
					FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
					INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
						ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
					INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
						ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
					WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
				
						  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
					) STP1
				CROSS JOIN (SELECT MAX(Cod_DW_Parametro) Cod_DW_Parametro
						FROM ' || P_BDDATOS ||'.PARAMETRO
					) P
				LEFT JOIN (
					SELECT    P.Valor
						,P.Normalizado
						FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
						INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
						ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
						INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
						ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
						INNER JOIN ' || P_BDDATOS ||'.PARAMETRO AS P
						ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
						WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
							  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
				  ) EXT
					ON EXT.Valor = 			trim(A.PALABRA_ORI) /*#1*/
					AND EXT.Normalizado = 	trim(A.PALABRA) /*#1*/
				WHERE EXT.Valor IS NULL'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (7):. Inserta las nuevas acepciones en PARAMETRO' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------------------------------------
 -- Actualiza estadisticas a paramtros
 ---------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Parametro) ON ' || P_BDDATOS ||'.PARAMETRO'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (8):. Actualizar estadisticas a la tabla PARAMETRO' ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; 
 END IF; /*end tmp_DireFisica_Topo_II
		*/ /*
		END ETAPA TOPONIMO
		*/ ------------------------------------------------------------
 -- Busca y borra si existe la tabla tmp_DireFisica_TopoUpd
 ------------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_TopoUpd' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd'; CALL DBC.SysExecSQL(:V_CADENA); END IF; ------------------------------------------------------------
 -- Se crea y carga la tabla tmp_DireFisica_TopoUpd
 -- Rearma la direccion
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_TopoUpd
	AS (
	WITH RECURSIVE Text_Dir_PalabrasT
	(Cod_DW_Reporte_Ubic_Original
	,ID_S
	,PALABRA
	,Ubicacion_Stand
	,Ciudad
	,Codigo_Ciudad_Dane
	,Reglas
	,Tipo_Direccion
	) AS
	(
	SELECT Cod_DW_Reporte_Ubic_Original
		,ID_S
		,PALABRA
		,CAST(PALABRA AS VARCHAR(500)) Ubicacion_Stand     
		,Ciudad
		,Codigo_Ciudad_Dane
		,CAST('''' AS VARCHAR(50)) as Reglas
		,Tipo_Direccion
	from '||P_BDSTAGE || '.tmp_DireFisica_Topo_II
	QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
					ORDER BY ID_S ASC) = 1
	UNION ALL
	SELECT A.Cod_DW_Reporte_Ubic_Original
		,B.ID_S
		,B.PALABRA
		,nvl(A.Ubicacion_Stand,'''') || '' '' || nvl(B.PALABRA,'''') /*#2*/
		,B.Ciudad
		,B.Codigo_Ciudad_Dane
		,CAST('''' AS VARCHAR(50)) as Reglas
		,B.Tipo_Direccion
	FROM '||P_BDSTAGE || '.tmp_DireFisica_Topo_II B
	INNER JOIN Text_Dir_PalabrasT A
		ON A.Cod_DW_Reporte_Ubic_Original = B.Cod_DW_Reporte_Ubic_Original
		AND (A.ID_S + 1) = B.ID_S
	WHERE B.ID_S IS NOT NULL
	)
	SELECT Cod_DW_Reporte_Ubic_Original
	,Ubicacion_Stand
	,Ciudad
	,Codigo_Ciudad_Dane
	,Reglas
	,Tipo_Direccion
	FROM Text_Dir_PalabrasT
	QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
				ORDER BY ID_S DESC, Ubicacion_Stand DESC) = 1
	
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (9):. Crear y carga la tabla tmp_DireFisica_TopoUpd' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ----------------------------------------------------
 -- Actualiza estadisticas a tmp_DireFisica_TopoUpd
 ----------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN (Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_DireFisica_TopoUpd'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (10):. Actualizar estadisticas a la tabla tmp_DireFisica_TopoUpd' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------------------------------
 -- Cursor de reglas para ETAPA IN (5)
 -- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones
 ------------------------------------------------------------------------------------
 SET V_CADENA = 'SELECT  Sentencia
				,Condicion
				,Flag_Recursiva
				,Cod_DW_Regla_Est_Ubica
				
			FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
			WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
					select Cod_DW_Atributo
					from '|| P_BDDATOS ||'.ATRIBUTO
					where Cod_DW_Tipo_Atributo in (
						select Cod_DW_Tipo_Atributo
						from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
						where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
					) AND Valor_Origen = ''Geografica''
				) AND  Flag_Activo = ''S'' AND ETAPA IN (5)
			ORDER BY Orden'; SET V_Contador = 0; PREPARE the_statement FROM V_CADENA; OPEN cur_reglas_select; CUR2: LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; IF SQLCODE <> 0 THEN LEAVE CUR2; END IF; SET V_Contador = V_Contador +1; SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
					SET ' || V_Sentencia || '
						, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
					WHERE    ' || V_Condicion ||' AND Ubicacion_Stand  IS NOT NULL /*#3*/ '; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica(10.1):'||' Ejecucion de reglas 5 iteracion: '||trim(V_Contador)||' Regla:'||trim(V_Cod_DW_Regla_Est_Ubica) ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE CUR2; END IF; END LOOP CUR2; CLOSE cur_reglas_select; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------------------------------------------------------------------------
 -- Se ordenan las particulas en formato DANE con la funcion ADDRESS_NORMALIZATION
 -- esta funcion develve una serie de campos donde el ultimo se emplea para tipificar
 -- la direccion  como valida, invalida  
 -- Busca y borra si existe la tabla tmp_DireFisica_Nor
 --------------------------------------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Nor' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Nor'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Nor
					AS
					(
					SELECT	Cod_DW_Reporte_Ubic_Original
						,Ubicacion_Stand
						,'|| P_BDVISTA ||'.ADDRESS_NORMALIZATION(oreplace(Ubicacion_Stand,''?'', ''''), Ciudad, 300, COALESCE(Codigo_Ciudad_Dane, ''''), Tipo_Direccion) ADDR_NORM
						,Ciudad
						,Codigo_Ciudad_Dane
					FROM '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
					) WITH DATA
					PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------
 -- Actualiza estadisticas a tmp_DireFisica_Nor
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Nor'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (12):. Actualizar estadisticas a la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------------------------------------------------------
 -- Genera posibles direcciones para las direcciones marcadas como ""X VALIDAR VIAS"" y ""NO VALIDA"" 
 --
 -- Busca y borra si existe la tabla tmp_Direcc_No_Validas
 ------------------------------------------------------------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Direcc_No_Validas' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Direcc_No_Validas'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas
				AS
				(
				SELECT	Cod_DW_Reporte_Ubic_Original
					,Ubicacion_Stand
					,Codigo_Ciudad_Dane
				FROM '||P_BDSTAGE || '.tmp_DireFisica_Nor
				WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''NO VALIDA 2''
				) WITH DATA
				PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (13):. Crea la tabla tmp_Direcc_No_Validas' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ----------------------------------------------------------------------------------------------
 -- Procesa las direcciones marcadas como ""X VALIDAR VIAS"" y genera un registro por cada una 
 --
 -- Busca y borra si existe la tabla tmp_Direcc_X_Validar_Vias
 ----------------------------------------------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Direcc_X_Validar_Vias' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Direcc_X_Validar_Vias'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias
				 AS
				(
				WITH RECURSIVE New_Direc
				 (Cod_DW_Reporte_Ubic_Original
				 ,ID_S
				 ,Direc_New
				 ,Dir
				 ,Ubicacion_Stand
				 ,Codigo_Ciudad_Dane
				) AS
				(
					SELECT Cod_DW_Reporte_Ubic_Original
						,0 ID_S
						, CAST(NULL AS VARCHAR(100))Direc_New
						, '|| P_BDVISTA ||'.DESC_ADDRESS_MORE_ADDRESS(Ubicacion_Stand, Ciudad, 300, Codigo_Ciudad_Dane) Dir
						, Ubicacion_Stand
						,Codigo_Ciudad_Dane
					from '||P_BDSTAGE || '.tmp_DireFisica_Nor
					WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''X VALIDAR VIAS''
					UNION ALL
					SELECT Cod_DW_Reporte_Ubic_Original
						,ID_S+1 ID_S1
						,'|| P_BDVISTA ||'.eListGetValByIdx(DIR, ''/'', ID_S1) Direc_New1
						, DIR
						,Ubicacion_Stand
						,Codigo_Ciudad_Dane
					FROM New_Direc
					WHERE Direc_New1 is not null
				)
				SELECT	Cod_DW_Reporte_Ubic_Original
					,ID_S
					,Ubicacion_Stand
					,Direc_New
					,Codigo_Ciudad_Dane
				FROM New_Direc
				WHERE Direc_New is not null
				
				
				) WITH DATA
				PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (14):. Crea la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------
 -- Actualiza estadisticas a tmp_Direcc_X_Validar_Vias
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (15):. Actualizar estadisticas a la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; -------------------------------------------------------------------
 -- Marca si alguna de la direcciones puede ser tenia como valida -- 
 ------------------------------------------------------------------- 
 ----------------------------------------------- INICIO AJUSTE #5 -----------------------------------------------
SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Direcc_X_Validar_Vias1' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Direcc_X_Validar_Vias1'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = 'CREATE MULTISET TABLE REC_STAGE.tmp_Direcc_X_Validar_Vias1 AS (
				SELECT Cod_DW_Reporte_Ubic_Original  
				 ,ID_S                          
				 ,Ubicacion_Stand               
				 ,Direc_New                     
				 ,Codigo_Ciudad_Dane            
				 ,TRIM(REC_VISTA.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) AS DirFun_2
				 ,TRIM(REC_VISTA.eListGetValByIdx(Dir.Direc_New, ''&'', 1)) AS DirFun_1
				FROM '||P_BDSTAGE || '.tmp_Direcc_X_Validar_Vias  DIR  
				) WITH DATA;'; CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (16):. Crea la tabla tmp_DirVal_X_Validar_Vias1' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; SET V_CADENA = 'COLLECT STATISTICS COLUMN (DIRFUN_2) ,COLUMN (DIRFUN_1) ,INDEX (COD_DW_REPORTE_UBIC_ORIGINAL)   ON   REC_STAGE.tmp_Direcc_X_Validar_Vias1;'; CALL DBC.SysExecSQL(:V_CADENA); SET V_CADENA = 'COLLECT STATISTICS COLUMN (COD_DW_TIPO_UBICACION) ON REC_STAGE.tmp_DireFisica_Estandarizada;'; CALL DBC.SysExecSQL(:V_CADENA); SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DirVal_X_Validar_Vias' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DirVal_X_Validar_Vias'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = 'CREATE MULTISET TABLE REC_STAGE.tmp_DirVal_X_Validar_Vias
				 AS
				(
				SELECT	Dir.Cod_DW_Reporte_Ubic_Original
					,Dir.Ubicacion_Stand
					,Dir.Direc_New
					,CASE WHEN (VUE.Flag_Geo IS NOT NULL
								AND VUE.Flag_Geo = ''S''
								AND Dir.DirFun_2 <> ''''
								AND VDF.Cod_DW_Ubic IS NOT NULL)
							AND VRPU.Cod_DW_Ubic IS NOT NULL
						   THEN 1
						   WHEN (VUE.Flag_Geo IS NOT NULL
								AND VUE.Flag_Geo = ''S''
								AND Dir.DirFun_2 <> ''''
								AND VDF.Cod_DW_Ubic IS NOT NULL)
							OR VRPU.Cod_DW_Ubic IS NOT NULL
						   THEN 2
						   ELSE 3
					 END Ind_Val
					 ,Dir.Codigo_Ciudad_Dane
				
				FROM	REC_STAGE.tmp_Direcc_X_Validar_Vias1 Dir
				INNER JOIN REC_STAGE.tmp_DireFisica_Estandarizada TMP
					ON TMP.Cod_DW_Reporte_Ubic_Original = Dir.Cod_DW_Reporte_Ubic_Original
				LEFT JOIN REC_VISTA.V_Ubicacion_Estandarizada VUE
					ON DIR.DirFun_1 = VUE.Texto_Ubicacion
					AND TMP.Cod_DW_Tipo_Ubicacion = VUE.Cod_Dw_Tipo_Ubicacion 
				LEFT JOIN REC_VISTA.V_DIRECCION_FISICA VDF
					ON VUE.Cod_DW_Ubic = VDF.Cod_DW_Ubic
					AND DIR.DirFun_2 = VDF.Complemento
				LEFT JOIN REC_VISTA.V_RELACION_PERSONA_UBICACION VRPU
					ON VUE.Cod_DW_Ubic = VRPU.Cod_DW_Ubic
					
				QUALIFY ROW_NUMBER() OVER(PARTITION BY Dir.Cod_DW_Reporte_Ubic_Original, Dir.Direc_New
							ORDER BY Dir.Cod_DW_Reporte_Ubic_Original) = 1
				
				) WITH DATA
				PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original);' ; CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (17):. Crea la tabla tmp_DirVal_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------ FIN AJUSTE #5 ---------------------------------
 -- Actualiza estadisticas a tmp_Direcc_No_Validas
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (17):. Actualizar estadisticas a la tabla tmp_DirVal_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------------------------------------------------------------------
 -- Completa las direcciones no validas en tmp_Direcc_No_Validas con las direcciones que no se pudieron clasificar
 ------------------------------------------------------------------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'INSERT INTO ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas
				SELECT	DISTINCT
				Cod_DW_Reporte_Ubic_Original
				,Ubicacion_Stand
				,Codigo_Ciudad_Dane
				FROM	' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias A
				WHERE Ind_Val = 3
				AND NOT EXISTS (
					SELECT 1
					FROM ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias B
					WHERE A.Cod_DW_Reporte_Ubic_Original = B.Cod_DW_Reporte_Ubic_Original
					AND B.Ind_Val in (1,2)
				)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (18):. Completa direcciones invalidas en tmp_Direcc_No_Validas' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------
 -- Actualiza estadisticas a tmp_Direcc_No_Validas
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (19):. Actualizar estadisticas a la tabla tmp_Direcc_No_Validas' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------
 -- Une todas las direcciones validas en tmp_Dire_Estan_Val
 -- Busca y borra si existe la tabla tmp_Dire_Estan_Val
 ------------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Dire_Estan_Val' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Dire_Estan_Val'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val
					AS (
					SELECT	Cod_DW_Reporte_Ubic_Original
						,oreplace(ADDR_NORM, ''NO VALIDA 2'',''NO VALIDA'') ADDR_NORM
						,Codigo_Ciudad_Dane
						,Ubicacion_Stand
					FROM '||P_BDSTAGE || '.tmp_DireFisica_Nor
					WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) <> ''X VALIDAR VIAS''
					UNION ALL
					SELECT	Cod_DW_Reporte_Ubic_Original
						,OREPLACE(OREPLACE(Direc_New, ''NO VALIDA 2'', ''VALIDA''), ''NO VALIDA'', ''VALIDA'')  Direc_New
						,Codigo_Ciudad_Dane
						,Ubicacion_Stand
					FROM '||P_BDSTAGE || '.tmp_DirVal_X_Validar_Vias
					QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
									ORDER BY Ind_Val) = 1
					
					) WITH DATA
					PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (20):. Crea la tabla tmp_Dire_Estan_Val' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------
 -- Actualiza estadisticas a tmp_Dire_Estan_Val
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (21):. Actualizar estadisticas a la tabla tmp_Dire_Estan_Val' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------------------------------------------------
 -- Busca y borra si existe la tabla DireccionFisica_Estandarizada
 --------------------------------------------
 -------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'DireccionFisica_Estandarizada' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.DireccionFisica_Estandarizada'; CALL DBC.SysExecSQL(:V_CADENA); END IF; ------------------------------------------------------------------------------------------------------------------------
 -- Unifica los datos de acuerdo Cod_DW_Reporte_Ubic_Original, el resultado en DireccionFisica_Estandarizada
 -- Se normaliza y ordena el texto de la direccion con la funcion ADDRESS_NORMALIZATION
 ------------------------------------------------------------------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.DireccionFisica_Estandarizada
				 AS (
					SELECT	dir.Cod_DW_Reporte_Ubic_Original
						,dir.Texto_Ubicacion_Original
						,coalesce(Est.Ubicacion_Stand, ''SV'')  Ubicacion_Stand_ant
						,dir.Cod_DW_Tipo_Ubicacion
						,dir.Cod_DW_Fuente
						,dir.Lote
						,dir.Id_Buro_Suscriptor
						,dir.Id_Buro_Persona
						,dir.Cod_DW_Cta
						,dir.Cod_DW_Hash
						,dir.Cod_DW_Ubic
						,dir.Valor
						,dir.Ciudad Texto_Ciudad
						,dir.Codigo_Ciudad_Dane
						,dir.Fecha_Reporte
						
						,dir.Cod_DW_Ubicacion_Original
						,dir.Cod_DW_Tipo_Ubicacion_Dir
						,dir.Usuario_BD
						
						,CASE WHEN Est.Cod_DW_Reporte_Ubic_Original IS NULL
																		   THEN dir.Texto_Ubicacion_Original
																		   ELSE COALESCE( NULLIF(TRIM( '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1)),''''), dir.Texto_Ubicacion_Original) --#4
														   END DIRE_GEO
						
						
						,TRIM(CAST('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 2) AS VARCHAR(4096))) DIRE_COMPLEMENTO
						,TRIM(CAST('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 3) AS VARCHAR(4096))) DIR_TIPO_DIRE
						,TRIM(CAST(CASE WHEN Est.Cod_DW_Reporte_Ubic_Original IS NULL
						 THEN dir.Tipo_Direccion
						 ELSE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 4)
						END AS VARCHAR(4096))) DIR_TIPOVIA
						,TRIM(CAST('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 5) AS VARCHAR(4096))) DIR_NUMVIAPPAL
						,TRIM(CAST('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 6) AS VARCHAR(4096))) DIR_NUMVIAGEN
						,TRIM(CAST('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 7) AS VARCHAR(4096))) DIR_NUMPLACA
						,TRIM(CAST(CASE WHEN Est.Cod_DW_Reporte_Ubic_Original IS NULL
						  OR '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1) IS NULL
						  OR '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1) = ''''
						 THEN ''NO VALIDA''
						 ELSE COALESCE ('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8),''NO VALIDA'') /*#6*/
						END AS VARCHAR(4096))) DIR_CB_VALIDA
						,TRIM(CAST(CASE WHEN Est.Cod_DW_Reporte_Ubic_Original IS NULL
						  OR '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1) IS NULL
						  OR '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1) = ''''
						 THEN dir.Texto_Ubicacion_Original || ''&&''|| dir.Tipo_Direccion ||''&&&&&NO VALIDA''
						 ELSE COALESCE(ADDR_NORM, dir.Ubicacion_Stand)
						END AS VARCHAR(4096))) Ubicacion_Stand
						,CAST('''' AS VARCHAR(20)) Reglas
					FROM	' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada dir
					LEFT JOIN ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val Est
						ON dir.Cod_DW_Reporte_Ubic_Original = Est.Cod_DW_Reporte_Ubic_Original
					QUALIFY ROW_NUMBER() OVER(PARTITION BY dir.Cod_DW_Reporte_Ubic_Original
								ORDER BY dir.Cod_DW_Reporte_Ubic_Original) = 1
				) WITH DATA
				PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (22):. Crear y carga la tabla DireccionFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------
 -- Actualiza estadisticas a tmp_DireFisica_Estand_Topo
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original ) ON ' || P_BDSTAGE ||'.DireccionFisica_Estandarizada'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (8):. Actualizar estadisticas a la tabla DireccionFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------
 -- Creando Tabla TMP_DirecionFisica_Complemento
 ------------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'TMP_DirecionFisica_Complemento' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.TMP_DirecionFisica_Complemento'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = 'Create Multiset table '||P_BDSTAGE || '.TMP_DirecionFisica_Complemento
				AS
				(Select  Dire_Complemento, '||P_BDVISTA || '.SetComplement( Dire_Complemento) Complemento_Ajustado
				From '||P_BDSTAGE || '.DireccionFisica_Estandarizada
				Where Dire_Complemento is not null
				AND Dire_Complemento <> Complemento_Ajustado
				Group by 1,2
				)With Data 
				Primary Index(Dire_Complemento);'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (9):. creando la tabla TMP_DirecionFisica_Complemento' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'TMP_DirecionFisica_Complemento' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.TMP_DirecionFisica_Complemento'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = 'Create Multiset table '||P_BDSTAGE || '.TMP_DirecionFisica_Complemento
				AS
				(Select  Dire_Complemento, '||P_BDVISTA || '.SetComplement( Dire_Complemento) Complemento_Ajustado
				From '||P_BDSTAGE || '.DireccionFisica_Estandarizada
				Where Dire_Complemento is not null
				AND Dire_Complemento <> Complemento_Ajustado
				Group by 1,2
				)With Data 
				Primary Index(Dire_Complemento);'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (9.1):. creando la tabla TMP_DirecionFisica_Complemento' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT  INDEX(Dire_Complemento) ON '||P_BDSTAGE || '.TMP_DirecionFisica_Complemento;'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (9.2):. Actualizar estadisticas a la tabla DireccionFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------
 -- Actualizando Complemento 
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'Update '||P_BDSTAGE || '.DireccionFisica_Estandarizada
				From '||P_BDSTAGE || '.TMP_DirecionFisica_Complemento  
					   Set Dire_Complemento = Complemento_Ajustado 
				Where DireccionFisica_Estandarizada.Dire_Complemento = TMP_DirecionFisica_Complemento.Dire_Complemento;' ; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (9.3):. Actualizar Dire_Complemento a la tabla DireccionFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------
 -- Creando Tabla TMP_DirecionFisica_via_GtnRtro
 ------------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'TMP_DirecionFisica_via_GtnRtro' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.TMP_DirecionFisica_via_GtnRtro'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = 'CREATE MULTISET TABLE '||P_BDSTAGE || '.TMP_DirecionFisica_via_GtnRtro
				 AS 
				 ( SEL DIRE_GEO, DIR_CB_VALIDA, DIR_CB_VALIDA_AJUSTADO, Codigo_Ciudad_Dane
				   FROM  (SEL  DIRE_GEO, DIR_CB_VALIDA, Codigo_Ciudad_Dane,  CASE WHEN char(Codigo_Ciudad_Dane) > 1 AND REC_VISTA.ValidacionDirVia(DIRE_GEO,300) = 3 THEN  ''VALIDA ''   ELSE ''NO VALIDA''  END  DIR_CB_VALIDA_AJUSTADO
								FROM '||P_BDSTAGE || '.DireccionFisica_Estandarizada
								WHERE DIR_TIPO_DIRE = ''VIA''
							   GROUP BY 1,2,3,4)  A
				  QUALIFY ( ROW_NUMBER() OVER ( Partition by  DIRE_GEO, DIR_CB_VALIDA, Codigo_Ciudad_Dane Order by  DIR_CB_VALIDA_AJUSTADO DESC ) = 1 ) 			   
				 )WITH DATA 
				 PRIMARY INDEX ( DIRE_GEO, DIR_CB_VALIDA);'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (10):. creando la tabla TMP_DirecionFisica_via_GtnRtro' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT  INDEX(DIRE_GEO, DIR_CB_VALIDA) ON '||P_BDSTAGE || '.TMP_DirecionFisica_via_GtnRtro;'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (10.1):. Actualizar estadisticas a la tabla TMP_DirecionFisica_via_GtnRtro' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------
 -- Actualizando Complemento 
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'Update '||P_BDSTAGE || '.DireccionFisica_Estandarizada
				From '||P_BDSTAGE || '.TMP_DirecionFisica_via_GtnRtro  
					   Set DIR_CB_VALIDA = DIR_CB_VALIDA_AJUSTADO 
				Where DireccionFisica_Estandarizada.DIRE_GEO = TMP_DirecionFisica_via_GtnRtro.DIRE_GEO
				AND DireccionFisica_Estandarizada.DIR_CB_VALIDA = TMP_DirecionFisica_via_GtnRtro.DIR_CB_VALIDA
				AND DireccionFisica_Estandarizada.Codigo_Ciudad_Dane =  TMP_DirecionFisica_via_GtnRtro.Codigo_Ciudad_Dane
				AND DireccionFisica_Estandarizada.DIR_TIPO_DIRE = ''VIA'';' ; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (10.2):. Actualizar DIR_CB_VALIDA a la tabla DireccionFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------
 -- Creando Tabla TMP_DirecionFisica_ral_GtnRtro
 ------------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'TMP_DirecionFisica_ral_GtnRtro' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.TMP_DirecionFisica_ral_GtnRtro'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = 'CREATE MULTISET TABLE '||P_BDSTAGE || '.TMP_DirecionFisica_ral_GtnRtro
				 AS 
				 (SEL  Cod_DW_Reporte_Ubic_Original
				       ,DIRE_GEO
				 	   ,CASE WHEN REC_VISTA.ValidacionDirRural(DIRE_GEO)  >= REC_VISTA.ValidacionDirRural(Ubicacion_Stand_ant) THEN  DIRE_GEO
                           ELSE   Ubicacion_Stand_ant
                        END DirRural_Definitiva
					   ,CASE WHEN REC_VISTA.ValidacionDirRural(DirRural_Definitiva) >  1 AND char(Codigo_Ciudad_Dane) > 1 THEN 
						 ''VALIDA''
						 ELSE ''NO VALIDA''		
					   END DIR_CB_VALIDA_AJUSTADO  
				   FROM '||P_BDSTAGE || '.DireccionFisica_Estandarizada
				   WHERE DIR_TIPO_DIRE = ''RURAL''				   
				 )WITH DATA 
				 PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original);'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. creando la tabla TMP_DirecionFisica_ral_GtnRtro' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT  INDEX(Cod_DW_Reporte_Ubic_Original) ON '||P_BDSTAGE || '.TMP_DirecionFisica_ral_GtnRtro;'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11.1):. Actualizar estadisticas a la tabla TMP_DirecionFisica_ral_GtnRtro' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------
 -- Actualizando Complemento 
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'Update '||P_BDSTAGE || '.DireccionFisica_Estandarizada
				From '||P_BDSTAGE || '.TMP_DirecionFisica_ral_GtnRtro  
						   Set DIR_CB_VALIDA = DIR_CB_VALIDA_AJUSTADO,
							   DIRE_GEO = DirRural_Definitiva
				Where DireccionFisica_Estandarizada.Cod_DW_Reporte_Ubic_Original = TMP_DirecionFisica_ral_GtnRtro.Cod_DW_Reporte_Ubic_Original
				AND DireccionFisica_Estandarizada.DIR_TIPO_DIRE = ''RURAL'';'; ------------------------------------------------------------
 -- Creando Tabla TMP_DirecionFisica_Mz_GtnRtro
 ------------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'TMP_DirecionFisica_Mz_GtnRtro' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.TMP_DirecionFisica_Mz_GtnRtro'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = 'CREATE MULTISET TABLE '||P_BDSTAGE || '.TMP_DirecionFisica_Mz_GtnRtro
				 AS 
				 (SEL  Cod_DW_Reporte_Ubic_Original
				       ,DIRE_GEO
				 	   ,CASE WHEN REC_VISTA.ValidacionDirMz(DIRE_GEO) >  2 AND char(Codigo_Ciudad_Dane) > 1 THEN 
						 ''VALIDA''
						 ELSE ''NO VALIDA''		
					   END DIR_CB_VALIDA_AJUSTADO  
				   FROM '||P_BDSTAGE || '.DireccionFisica_Estandarizada
				   WHERE DIR_TIPO_DIRE = ''MANZANA''				   
				 )WITH DATA 
				 PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original);'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (12):. creando la tabla TMP_DirecionFisica_Mz_GtnRtro' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT  INDEX(Cod_DW_Reporte_Ubic_Original) ON '||P_BDSTAGE || '.TMP_DirecionFisica_Mz_GtnRtro;'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (12.1):. Actualizar estadisticas a la tabla TMP_DirecionFisica_Mz_GtnRtro' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ------------------------------------------------------------
 -- Actualizando Complemento 
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'Update '||P_BDSTAGE || '.DireccionFisica_Estandarizada
				From '||P_BDSTAGE || '.TMP_DirecionFisica_Mz_GtnRtro  
			      Set DIR_CB_VALIDA = DIR_CB_VALIDA_AJUSTADO							   
				Where DireccionFisica_Estandarizada.Cod_DW_Reporte_Ubic_Original = TMP_DirecionFisica_Mz_GtnRtro.Cod_DW_Reporte_Ubic_Original
				AND DireccionFisica_Estandarizada.DIR_TIPO_DIRE = ''MANZANA'';'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (12.2):. Actualizar DIR_CB_VALIDA a la tabla DireccionFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------------------------------------------------------------------
 -- Cursor de reglas para ETAPA IN (6)
 -- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones
 -----------------------------------------------------------------------------------
 SET V_CADENA = 'SELECT	Sentencia
					,Condicion
					,Flag_Recursiva
					,Cod_DW_Regla_Est_Ubica
				FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
				WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
						select Cod_DW_Atributo
						from '|| P_BDDATOS ||'.ATRIBUTO
						where Cod_DW_Tipo_Atributo in (
							select Cod_DW_Tipo_Atributo
							from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
							where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
						) AND Valor_Origen = ''Geografica''
					) AND  Flag_Activo = ''S'' AND ETAPA IN (6)
				ORDER BY Orden'; SET V_Contador = 0; PREPARE the_statement FROM V_CADENA; OPEN cur_reglas_select; CUR3:LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; IF SQLCODE <> 0 THEN LEAVE CUR3; END IF;---  Ini HAH
 SET V_Contador = V_Contador +1; SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.DireccionFisica_Estandarizada
				 SET ' || V_Sentencia || '
						, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
				 WHERE ' || V_Condicion; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica(13):'||' Ejecucion de reglas 6 iteracion: '||trim(V_Contador)||' Regla:'||trim(V_Cod_DW_Regla_Est_Ubica) ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE CUR3; END IF; END LOOP CUR3; CLOSE cur_reglas_select; END L1; END;

create PROCEDURE REC_DATOS.PRO_StandardizationGeografica_2017_09_12_CAP ( IN P_Lote INTEGER ,IN P_StartTimeStampPadre VARCHAR(20) ,IN P_Nombre_Proceso_Padre VARCHAR(30) ,IN P_BDDATOS VARCHAR(20) ,IN P_BDVISTA VARCHAR(20) ,IN P_BDSTAGE VARCHAR(20) ,OUT P_ERROR VARCHAR(32000) ) /*
 * ################################################################################
 * 
 * Objetivo:		Estandariza las direcciones fisicas como ubicacion del insumo
 *			InsumoDireccionFisica, dejando el resultado en DireccionFisica_Estandarizada
 * Fecha:		2016/11/09
 * Realizado por:	Luis E Ramirez
 * Proyecto:		Nuevo reconocer
 * Script:		PRO_StandardizationGeografica BCK 12 sept antes de añadir campo de reglas a stg
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha		Objetivo			Realizado por
 * 
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */ BEGIN ------------------------
-- Declaracion de variables
------------------------
 DECLARE V_StartTimeStampPadre TIMESTAMP(6); DECLARE V_ERROR VARCHAR(30); DECLARE V_CADENA VARCHAR(32000); DECLARE V_CADENA1 VARCHAR(10000); DECLARE Temp CHAR(30); DECLARE V_Sentencia VARCHAR(500); DECLARE V_Condicion VARCHAR(500); DECLARE V_Flag_Recursiva VARCHAR(1); DECLARE V_COUNT INTEGER; DECLARE V_Cod_DW_Regla_Est_Ubica INTEGER; DECLARE cur_reglas_select NO SCROLL CURSOR FOR the_statement; DECLARE cur_count_rec NO SCROLL CURSOR FOR the_statement_1; L1: BEGIN SET P_ERROR = ''; 
 
 SET V_StartTimeStampPadre = CAST(P_StartTimeStampPadre AS TIMESTAMP(6) FORMAT 'yyyy-mm-ddhh:mi:ss');
 
 --SET V_StartTimeStampPadre =DATE;
 
 SET V_COUNT = 1; ---------------------------
-- Busca y borra si existe la tabla tmp_EmailsEstandarizados
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Estandarizada' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
-- Se crea y carga la tabla tmp_DireFisica_Estandarizada
-- Se hace la primera limpieza de caracteres especiales en la ciudad y el texto de la direccion
-----------------------------
 SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada
 AS (
SELECT	 dir.Cod_DW_Reporte_Ubic_Original
	,CASE WHEN (ACEP.Normalizado IS NOT NULL OR GEO.Cod_Dane_Ciudad  IS NOT NULL)
			THEN ' || P_BDVISTA || '.REPLEXPREG( Ubicacion_Stand_Prev, ''[^A-Z^0-9^ ^-^.]'','' '')
	      ELSE ''NO VALIDO''
	END Ubicacion_Stand
	,dir.Texto_Ubicacion_Original
	,dir.Cod_DW_Tipo_Ubicacion
	,dir.Cod_DW_Fuente
	,dir.Lote
	,dir.Id_Buro_Suscriptor
	,dir.Id_Buro_Persona
	,dir.Cod_DW_Cta
	,dir.Cod_DW_Hash
	,dir.Cod_DW_Ubic
	,dir.Valor                               
	,CASE WHEN ACEP.Normalizado IS NOT NULL
			THEN ACEP.Normalizado
	      WHEN GEO.Cod_Dane_Ciudad IS NOT NULL
	      		THEN geo.Descripcion_Ciudad
	      ELSE Texto_Ciudad_Prev
	END Ciudad
	,COALESCE(GEOC.Cod_Dane_Ciudad, dir.Codigo_Ciudad_Dane) Codigo_Ciudad_Dane 
	,dir.Fecha_Reporte
	
	,Cod_DW_Ubicacion_Original
	,Cod_DW_Tipo_Ubicacion_Dir
	,Usuario_BD
FROM (
	SELECT	a.*
		,' || P_BDVISTA || '.REPL_CHRS  (UPPER(Texto_Ubicacion_Original), ''GEO'') Ubicacion_Stand_Prev
		,' || P_BDVISTA || '.REPL_CHRS  (TRIM(' || P_BDVISTA || '.REPLEXPREG(' || P_BDVISTA || '.REPLEXPREG( UPPER(Texto_Ciudad), ''^[A-Za-z ]?$''),''[ ]{2,100}'', '' '') ), ''GEO'') Texto_Ciudad_Prev 
	FROM ' || P_BDSTAGE ||'.InsumoDireccionFisica a ) dir
LEFT JOIN (
		SELECT	DISTINCT  P.Valor
		,P.Normalizado
	FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
	INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
		ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
	INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
		ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
	INNER JOIN ' || P_BDDATOS ||'.PARAMETRO AS P
		ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
	WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
			  AND TP.Nombre_Tipo_Parametro = ''CIUDAD''
	    UNION 
    SELECT DISTINCT Descripcion_Ciudad AS VALOR, Descripcion_Ciudad AS NORMALIZADO
    FROM  ' || P_BDVISTA || '.V_Geografia
    WHERE  COD_DANE_CIUDAD LIKE ''%000''

	) ACEP
	ON dir.Texto_Ciudad_Prev = ACEP.Valor
LEFT JOIN '|| P_BDVISTA ||'.V_Geografia GEO
	ON GEO.Cod_Dane_Ciudad = dir.Codigo_Ciudad_Dane
LEFT JOIN '|| P_BDVISTA ||'.V_Geografia GEOC
	ON GEOC.Descripcion_Ciudad = ACEP.Normalizado AND GEOC.COD_DANE_CIUDAD LIKE ''%000''

) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (1):. Crear y carga la tabla tmp_DireFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a tmp_DireFisica_Estandarizada
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN(Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Actualizar estadisticas a la tabla tmp_DireFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Cursor de reglas para ETAPA IN (2)
-- Reglas de limpieza basadas en patrones de texto
--------------------
 SET V_CADENA = '
SELECT	Sentencia
	,Condicion
	,Flag_Recursiva
	,Cod_DW_Regla_Est_Ubica
FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
		select Cod_DW_Atributo
		from '|| P_BDDATOS ||'.ATRIBUTO
		where Cod_DW_Tipo_Atributo in (
			select Cod_DW_Tipo_Atributo
			from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
			where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
		) AND Valor_Origen = ''Geografica''
	) AND  Flag_Activo = ''S'' AND ETAPA IN (2)
ORDER BY Orden'; PREPARE the_statement FROM V_CADENA; OPEN cur_reglas_select; CUR1:LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; IF SQLCODE <> 0 THEN LEAVE CUR1; END IF; SET V_CADENA = '
UPDATE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
SET ' || V_Sentencia || '
WHERE ' || V_Condicion || '
	AND Ubicacion_Stand <> ''NO VALIDO'''; CALL DBC.SysExecSQL(:V_CADENA); IF SQLCODE NOT IN (0, 7632) THEN SET V_CADENA1 = V_CADENA; SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1; LEAVE L1; END IF; END LOOP CUR1; CLOSE cur_reglas_select; ---------------------------
-- Reemplaza Toponimos
-- Busca y borra si existe la tabla tmp_DireFisica_Topo_a
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Topo_a' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo_a'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_a
 AS
(
	SELECT	a.Cod_DW_Reporte_Ubic_Original
		,CASE WHEN b.Valor IS NULL
				THEN Ubicacion_Stand
		      ELSE OREPLACE(Ubicacion_Stand, b.Valor, b.Normalizado)
		END Ubicacion_Stand
		,a.Ciudad
	FROM  ( 
		select *
		from '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
		qualify row_number() over(partition by Cod_DW_Reporte_Ubic_Original
				order by Cod_DW_Reporte_Ubic_Original) = 1
		) a
	LEFT JOIN (
		SELECT   P.Valor
			,P.Normalizado
		FROM '|| P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
		    INNER JOIN '|| P_BDDATOS ||'.TIPO_PARAMETRO AS TP
		    	ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
		    INNER JOIN  '|| P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
		    	ON  TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
		    INNER JOIN '|| P_BDDATOS ||'.PARAMETRO AS P
		    	ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
		WHERE   GP.Nombre_Grupo_Parametro = ''TOPONIMOS''
				  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
                  ) b
               ON a.Ubicacion_Stand like ''%'' || b.Valor || ''%''
          WHERE a.Ubicacion_Stand <> ''NO VALIDO''
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Crea la tabla tmp_DireFisica_Topo_a' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a tmp_DireFisica_Estandarizada
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_a'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo_a' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
-- Busca y borra si existe la tabla tmp_DireFisica_Topo
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Topo' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
-- Se crea y carga la tabla tmp_DireFisica_Topo
-- Separacion del texto de la direccion en palabras
-----------------------------
 SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo
 AS (
 WITH RECURSIVE Text_Dir_Palabras
 (Cod_DW_Reporte_Ubic_Original
 ,ID_S
 ,POS
 ,PALABRA
 ,Ubicacion_Stand
 ,Ciudad
) AS
(
	SELECT Cod_DW_Reporte_Ubic_Original
		,0
		,0
		, cast('''' as varchar(100))
		,Ubicacion_Stand  
		,Ciudad
	from '||P_BDSTAGE || '.tmp_DireFisica_Topo_a
	UNION ALL
	SELECT Cod_DW_Reporte_Ubic_Original
		,ID_S+1
		,CASE WHEN POSITION('' '' IN Ubicacion_Stand) > 0
				THEN POSITION('' '' IN Ubicacion_Stand)
		     ELSE CHARACTER_LENGTH(Ubicacion_Stand)
		END POS1
		,TRIM(BOTH '' '' FROM SUBSTR(Ubicacion_Stand, 0, POS1+1))
		,TRIM(SUBSTR(Ubicacion_Stand, POS1+1))
		,Ciudad
	FROM Text_Dir_Palabras
	WHERE POS1 > 0
)
SELECT Cod_DW_Reporte_Ubic_Original
	,ID_S
	,PALABRA
	,Ciudad
	,Ubicacion_Stand
FROM Text_Dir_Palabras
WHERE ID_S > 0

) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (3):. Crear y carga la tabla tmp_DireFisica_Topo' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a tmp_DireFisica_Topo
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (4):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; /*

BEGIN ETAPA TOPONIMO
begin tmp_DireFisica_Topo
*/ ---------------------------
-- Busca y borra si existe la tabla tmp_DireFisica_Topo_II
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Topo_II' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo_II'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
-- Se crea y carga la tabla tmp_DireFisica_Topo_II
-- Se aplican acepciones y no existe, se llama la funcion GENACCEPAUT para
--  intentar crearla
-----------------------------
 SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II
 AS (
SELECT	A.Cod_DW_Reporte_Ubic_Original
	,A.ID_S
	,CASE WHEN ACEP.Valor IS NULL
			AND ' || P_BDVISTA || '.VALIDATE_EXPRESSION_R(A.PALABRA, ''^[A-Za-z]{3,20}*$'')=1
			AND A.PALABRA IS NOT NULL
			AND ACEP.Valor IS NULL
		THEN ' || P_BDVISTA || '.GENACCEPAUT(A.PALABRA, SOUNDEX(A.PALABRA))
	END NEW_ACEPCION
	,CASE WHEN ACEP.Valor IS NOT NULL
		THEN ACEP.Normalizado
	      WHEN NEW_ACEPCION IS NOT NULL AND CHAR(NEW_ACEPCION) <> 0
	      	THEN NEW_ACEPCION
	      ELSE A.PALABRA
	END PALABRA
	,A.Ubicacion_Stand
	,A.PALABRA PALABRA_ORI
	,A.Ciudad
FROM ' || P_BDSTAGE ||'.tmp_DireFisica_Topo A
LEFT JOIN (
	SELECT	P.Valor
		,P.Normalizado
	FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
	INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
		ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
	INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
		ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
	INNER JOIN ' || P_BDDATOS ||'.PARAMETRO AS P
		ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
	WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
			  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
		) ACEP
	ON A.PALABRA = ACEP.Valor
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (5):. Crear y carga la tabla tmp_DireFisica_Topo_II' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a tmp_DireFisica_Topo
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (6):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo_II' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Inserta las nuevas acepciones en parametros
--------------------
 SET V_CADENA = ''; SET V_CADENA = '
INSERT INTO ' || P_BDDATOS ||'.PARAMETRO
SELECT	P.Cod_DW_Parametro + SUM( 1 ) OVER (ROWS UNBOUNDED PRECEDING) Cod_DW_Parametro
	,A.PALABRA_ORI Valor
	,A.PALABRA Normalizado
	,'|| P_Lote || '
	,NULL
	,1
	,USER
	,STP1.Cod_DW_Subtipo_Parametro
	,NULL
	,date
FROM (SELECT *
	FROM ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II
	WHERE NEW_ACEPCION IS NOT NULL AND CHAR(NEW_ACEPCION) <> 0
	QUALIFY ROW_NUMBER() OVER(PARTITION BY PALABRA_ORI, PALABRA ORDER BY PALABRA_ORI) = 1
   ) A
CROSS JOIN (
	SELECT STP.Cod_DW_Subtipo_Parametro
	FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
	INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
		ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
	INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
		ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
	WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''

		  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
	) STP1
CROSS JOIN (SELECT MAX(Cod_DW_Parametro) Cod_DW_Parametro
	    FROM ' || P_BDDATOS ||'.PARAMETRO
	) P
LEFT JOIN (
	SELECT    P.Valor
		,P.Normalizado
	    FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
	    INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
		ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
	    INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
		ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
	    INNER JOIN ' || P_BDDATOS ||'.PARAMETRO AS P
		ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
	    WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
		      AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
  ) EXT
	ON EXT.Valor = A.PALABRA_ORI
	AND EXT.Normalizado = A.PALABRA
WHERE EXT.Valor IS NULL'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (7):. Inserta las nuevas acepciones en PARAMETRO' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a paramtros
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Parametro) ON ' || P_BDDATOS ||'.PARAMETRO'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (8):. Actualizar estadisticas a la tabla PARAMETRO' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; /*end tmp_DireFisica_Topo_II
*/ /*
END ETAPA TOPONIMO
*/ ---------------------------
-- Busca y borra si existe la tabla tmp_DireFisica_TopoUpd
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_TopoUpd' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
-- Se crea y carga la tabla tmp_DireFisica_TopoUpd
-- Rearma la direccion
-----------------------------
 SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_TopoUpd
 AS (
 WITH RECURSIVE Text_Dir_PalabrasT
 (Cod_DW_Reporte_Ubic_Original
 ,ID_S
 ,PALABRA
 ,Ubicacion_Stand
 ,Ciudad
 ,UltRegla
) AS
(
	SELECT Cod_DW_Reporte_Ubic_Original
		,ID_S
		,PALABRA
		,CAST(PALABRA AS VARCHAR(500)) Ubicacion_Stand     
		,Ciudad
		,CAST('''' AS VARCHAR(50)) as UltRegla
	from '||P_BDSTAGE || '.tmp_DireFisica_Topo_II
	QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
					ORDER BY ID_S ASC) = 1
	UNION ALL
	SELECT A.Cod_DW_Reporte_Ubic_Original
		,B.ID_S
		,B.PALABRA
		,A.Ubicacion_Stand || '' '' || B.PALABRA
		,B.Ciudad
		,CAST('''' AS VARCHAR(50)) as UltRegla
	FROM '||P_BDSTAGE || '.tmp_DireFisica_Topo_II B
	INNER JOIN Text_Dir_PalabrasT A
		ON A.Cod_DW_Reporte_Ubic_Original = B.Cod_DW_Reporte_Ubic_Original
		AND (A.ID_S + 1) = B.ID_S
	WHERE B.ID_S IS NOT NULL
)
SELECT Cod_DW_Reporte_Ubic_Original
	,Ubicacion_Stand
	,Ciudad
	,UltRegla
FROM Text_Dir_PalabrasT
QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
				ORDER BY ID_S DESC, Ubicacion_Stand DESC) = 1

) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (9):. Crear y carga la tabla tmp_DireFisica_TopoUpd' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a tmp_DireFisica_TopoUpd
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN (Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_DireFisica_TopoUpd'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (10):. Actualizar estadisticas a la tabla tmp_DireFisica_TopoUpd' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Cursor de reglas para ETAPA IN (5)
-- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones
--------------------
 SET V_CADENA = '
SELECT	Sentencia
	,Condicion
	,Flag_Recursiva
	,Cod_DW_Regla_Est_Ubica
	
FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
		select Cod_DW_Atributo
		from '|| P_BDDATOS ||'.ATRIBUTO
		where Cod_DW_Tipo_Atributo in (
			select Cod_DW_Tipo_Atributo
			from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
			where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
		) AND Valor_Origen = ''Geografica''
	) AND  Flag_Activo = ''S'' AND ETAPA IN (5)
ORDER BY Orden'; 

PREPARE the_statement FROM V_CADENA; OPEN cur_reglas_select; CUR2:LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; IF SQLCODE <> 0 THEN LEAVE CUR2; END IF; SET V_CADENA = '
UPDATE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
SET ' || V_Sentencia || ', UltRegla = UltRegla || + ' || V_Cod_DW_Regla_Est_Ubica || ' 
WHERE ' || V_Condicion || '
	AND Ubicacion_Stand <> ''NO VALIDO''';
	
	CALL DBC.SysExecSQL(:V_CADENA);
	
	IF SQLCODE NOT IN (0, 7632) THEN SET V_CADENA1 = V_CADENA;
	
	SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1; LEAVE L1; END IF; END LOOP CUR2; CLOSE cur_reglas_select; ---------------------------
-- Se ordenan las particulas en formato DANE con la funcion ADDRESS_NORMALIZATION
-- esta funcion develve una serie de campos donde el ultimo se emplea para tipificar
-- la direccion  como valida, invalida 
--
--
-- Busca y borra si existe la tabla tmp_DireFisica_Nor
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Nor' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Nor'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Nor
 AS
(
	SELECT	Cod_DW_Reporte_Ubic_Original
		,Ubicacion_Stand
		,'|| P_BDVISTA ||'.ADDRESS_NORMALIZATION(Ubicacion_Stand, Ciudad, 300) ADDR_NORM
		,Ciudad
	FROM '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; END IF; END IF; END IF; END IF; --------------------
-- Actualiza estadisticas a tmp_DireFisica_Nor
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Nor'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (12):. Actualizar estadisticas a la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
-- Genera posibles direcciones para las direcciones marcadas como "X VALIDAR VIAS" y "NO VALIDA" 
--
-- Busca y borra si existe la tabla tmp_Direcc_No_Validas
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Direcc_No_Validas' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Direcc_No_Validas'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas
 AS
(
	SELECT	Cod_DW_Reporte_Ubic_Original
		,Ubicacion_Stand
	FROM '||P_BDSTAGE || '.tmp_DireFisica_Nor
	WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''NO VALIDA''
		OR Ubicacion_Stand = ''NO VALIDO''
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (13):. Crea la tabla tmp_Direcc_No_Validas' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
-- Procesa las direcciones marcadas como "X VALIDAR VIAS" y genera un registro por cada una 
--
-- Busca y borra si existe la tabla tmp_Direcc_X_Validar_Vias
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Direcc_X_Validar_Vias' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Direcc_X_Validar_Vias'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias
 AS
(
WITH RECURSIVE New_Direc
 (Cod_DW_Reporte_Ubic_Original
 ,ID_S
 ,Direc_New
 ,Dir
 ,Ubicacion_Stand
) AS
(
	SELECT Cod_DW_Reporte_Ubic_Original
		,0 ID_S
		, CAST(NULL AS VARCHAR(100))Direc_New
		, '|| P_BDVISTA ||'.DESC_ADDRESS_MORE_ADDRESS(Ubicacion_Stand, Ciudad, 300) Dir
		, Ubicacion_Stand
	from '||P_BDSTAGE || '.tmp_DireFisica_Nor
	WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''X VALIDAR VIAS''
	UNION ALL
	SELECT Cod_DW_Reporte_Ubic_Original
		,ID_S+1 ID_S1
		,'|| P_BDVISTA ||'.eListGetValByIdx(DIR, ''/'', ID_S1) Direc_New1
		, DIR
		,Ubicacion_Stand
	FROM New_Direc
	WHERE Direc_New1 is not null
)
SELECT	Cod_DW_Reporte_Ubic_Original
	,ID_S
	,Ubicacion_Stand
	,Direc_New
FROM New_Direc
WHERE Direc_New is not null


) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (14):. Crea la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (14):. Crea la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (14):. Crea la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; LEAVE L1; END IF; END IF; --------------------
-- Actualiza estadisticas a tmp_Direcc_X_Validar_Vias
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (15):. Actualizar estadisticas a la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
-- Marca si alguna de la direcciones puede ser tenia como valida 
--
-- Busca y borra si existe la tabla tmp_DirVal_X_Validar_Vias
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DirVal_X_Validar_Vias' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DirVal_X_Validar_Vias'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias
 AS
(
SELECT	Dir.Cod_DW_Reporte_Ubic_Original
	,Dir.Ubicacion_Stand
	,Dir.Direc_New
	,CASE WHEN (VUE.Flag_Geo IS NOT NULL
				AND VUE.Flag_Geo = ''S''
				AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) <> ''''
				AND VDF.Cod_DW_Ubic IS NOT NULL)
			AND VRPU.Cod_DW_Ubic IS NOT NULL
		   THEN 1
	       WHEN (VUE.Flag_Geo IS NOT NULL
				AND VUE.Flag_Geo = ''S''
				AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) <> ''''
				AND VDF.Cod_DW_Ubic IS NOT NULL)
			OR VRPU.Cod_DW_Ubic IS NOT NULL
		   THEN 2
	       ELSE 3
	 END Ind_Val

FROM	' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias Dir
INNER JOIN ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada TMP
	ON TMP.Cod_DW_Reporte_Ubic_Original = Dir.Cod_DW_Reporte_Ubic_Original
LEFT JOIN ' || P_BDVISTA || '.V_Ubicacion_Estandarizada VUE
	ON TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 1)) = VUE.Texto_Ubicacion
	AND TMP.Cod_DW_Tipo_Ubicacion = VUE.Cod_Dw_Tipo_Ubicacion 
LEFT JOIN ' || P_BDVISTA || '.V_DIRECCION_FISICA VDF
	ON VUE.Cod_DW_Ubic = VDF.Cod_DW_Ubic
	AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) = VDF.Complemento
LEFT JOIN ' || P_BDVISTA || '.V_RELACION_PERSONA_UBICACION VRPU
	ON VUE.Cod_DW_Ubic = COALESCE(VRPU.Cod_DW_Ubic, -1)
	
QUALIFY ROW_NUMBER() OVER(PARTITION BY Dir.Cod_DW_Reporte_Ubic_Original, Dir.Direc_New
			ORDER BY Dir.Cod_DW_Reporte_Ubic_Original) = 1

) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (16):. Crea la tabla tmp_DirVal_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a tmp_Direcc_No_Validas
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (17):. Actualizar estadisticas a la tabla tmp_DirVal_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Completa las direcciones no validas en tmp_Direcc_No_Validas con las direcciones que no se pudieron clasificar
--------------------
 SET V_CADENA = ''; SET V_CADENA = '
INSERT INTO ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas
SELECT	DISTINCT
	Cod_DW_Reporte_Ubic_Original
	,Ubicacion_Stand
FROM	' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias A
WHERE Ind_Val = 3
	AND NOT EXISTS (
		SELECT 1
		FROM ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias B
		WHERE A.Cod_DW_Reporte_Ubic_Original = B.Cod_DW_Reporte_Ubic_Original
		AND B.Ind_Val in (1,2)
	)
'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (18):. Completa direcciones invalidas en tmp_Direcc_No_Validas' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a tmp_Direcc_No_Validas
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (19):. Actualizar estadisticas a la tabla tmp_Direcc_No_Validas' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Une todas las direcciones validas en tmp_Dire_Estan_Val
 -- Busca y borra si existe la tabla tmp_Dire_Estan_Val
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Dire_Estan_Val' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Dire_Estan_Val'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val
 AS (
	SELECT	Cod_DW_Reporte_Ubic_Original
		,ADDR_NORM
	FROM '||P_BDSTAGE || '.tmp_DireFisica_Nor
	WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''VALIDA''
	UNION ALL
	SELECT	Cod_DW_Reporte_Ubic_Original
		,Direc_New
	FROM '||P_BDSTAGE || '.tmp_DirVal_X_Validar_Vias
	WHERE Ind_Val < 3
	QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
					ORDER BY Ind_Val) = 1
	
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (20):. Crea la tabla tmp_Dire_Estan_Val' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a tmp_Dire_Estan_Val
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (21):. Actualizar estadisticas a la tabla tmp_Dire_Estan_Val' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
-- Busca y borra si existe la tabla DireccionFisica_Estandarizada
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'DireccionFisica_Estandarizada' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.DireccionFisica_Estandarizada'; CALL DBC.SysExecSQL(:V_CADENA); END IF; --------------------
-- Unifica los datos de acuerdo Cod_DW_Reporte_Ubic_Original, el resultado en DireccionFisica_Estandarizada
-- Se normaliza y ordena el texto de la direccion con la funcion ADDRESS_NORMALIZATION
--------------------
 SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.DireccionFisica_Estandarizada
 AS (
	SELECT	dir.Cod_DW_Reporte_Ubic_Original
		,dir.Texto_Ubicacion_Original
		,dir.Cod_DW_Tipo_Ubicacion
		,dir.Cod_DW_Fuente
		,dir.Lote
		,dir.Id_Buro_Suscriptor
		,dir.Id_Buro_Persona
		,dir.Cod_DW_Cta
		,dir.Cod_DW_Hash
		,dir.Cod_DW_Ubic
		,dir.Valor
		,dir.Ciudad Texto_Ciudad
		,dir.Codigo_Ciudad_Dane
		,dir.Fecha_Reporte
		
		,dir.Cod_DW_Ubicacion_Original
		,dir.Cod_DW_Tipo_Ubicacion_Dir
		,dir.Usuario_BD
		
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1)) DIRE_GEO
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 2)) DIRE_COMPLEMENTO
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 3)) DIR_TIPO_DIRE
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 4)) DIR_TIPOVIA
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 5)) DIR_NUMVIAPPAL
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 6)) DIR_NUMVIAGEN
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 7)) DIR_NUMPLACA
		,COALESCE(ADDR_NORM, dir.Ubicacion_Stand) Ubicacion_Stand
	FROM	' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada dir
	LEFT JOIN ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val Est
		ON dir.Cod_DW_Reporte_Ubic_Original = Est.Cod_DW_Reporte_Ubic_Original
	QUALIFY ROW_NUMBER() OVER(PARTITION BY dir.Cod_DW_Reporte_Ubic_Original
				ORDER BY dir.Cod_DW_Reporte_Ubic_Original) = 1
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (22):. Crear y carga la tabla DireccionFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a tmp_DireFisica_Estand_Topo
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original )
					ON ' || P_BDSTAGE ||'.DireccionFisica_Estandarizada'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (8):. Actualizar estadisticas a la tabla DireccionFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Cursor de reglas para ETAPA IN (6)
-- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones
--------------------
 SET V_CADENA = '
SELECT	Sentencia
	,Condicion
	,Flag_Recursiva
	,Cod_DW_Regla_Est_Ubica
FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
		select Cod_DW_Atributo
		from '|| P_BDDATOS ||'.ATRIBUTO
		where Cod_DW_Tipo_Atributo in (
			select Cod_DW_Tipo_Atributo
			from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
			where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
		) AND Valor_Origen = ''Geografica''
	) AND  Flag_Activo = ''S'' AND ETAPA IN (6)
ORDER BY Orden'; PREPARE the_statement FROM V_CADENA; OPEN cur_reglas_select; CUR3:LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; IF SQLCODE <> 0 THEN LEAVE CUR3; END IF; SET V_CADENA = '
UPDATE '||P_BDSTAGE || '.DireccionFisica_Estandarizada
SET ' || V_Sentencia || '
WHERE ' || V_Condicion || '
	AND Ubicacion_Stand <> ''NO VALIDO'''; CALL DBC.SysExecSQL(:V_CADENA); IF SQLCODE NOT IN (0, 7632) THEN SET V_CADENA1 = V_CADENA; SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1; LEAVE L1; END IF; END LOOP CUR3; CLOSE cur_reglas_select; END L1; END;

REPLACE PROCEDURE REC_DATOS.PRO_StandardizationGeografica_20180314
	(
		IN P_Lote INTEGER
		,IN P_StartTimeStampPadre VARCHAR(20)
		,IN P_Nombre_Proceso_Padre VARCHAR(30)
		,IN P_BDDATOS VARCHAR(20)
		,IN P_BDVISTA VARCHAR(20)
		,IN P_BDSTAGE VARCHAR(20)
		,OUT P_ERROR VARCHAR(32000) )
/*
 * ################################################################################
 * 
 * Objetivo:		Estandariza las direcciones fisicas como ubicacion del insumo
 *			InsumoDireccionFisica, dejando el resultado en DireccionFisica_Estandarizada
 * Fecha:		2016/11/09
 * Realizado por:	Luis E Ramirez
 * Proyecto:		Nuevo reconocer
 * Script:		PRO_StandardizationGeografica BCK 12 sept antes de a?adir campo de reglas a stg
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha	Objetivo				Realizado por
 * 2017/12/28	Agregar el codigo dane hasta la tabla	aariza - Capgemini
 *		DireccionFisica_Estandarizada
 * 2018/03/06	Se agrega el campo Tipo_Direccion y
 *		se elimina el calculo del cod dane	Capgemini
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */
 
BEGIN
------------------------
-- Declaracion de variables
------------------------
	DECLARE V_StartTimeStampPadre TIMESTAMP(6);
	DECLARE V_ERROR VARCHAR(30);
	DECLARE V_CADENA VARCHAR(32000);
	DECLARE V_CADENA1 VARCHAR(10000);
	DECLARE Temp CHAR(30);
	DECLARE V_Sentencia VARCHAR(500);
	DECLARE V_Condicion VARCHAR(500);
	DECLARE V_Flag_Recursiva VARCHAR(1);
	DECLARE V_COUNT INTEGER;
	DECLARE V_Cod_DW_Regla_Est_Ubica INTEGER;
	
	DECLARE cur_reglas_select NO SCROLL CURSOR FOR the_statement;
	DECLARE cur_count_rec NO SCROLL CURSOR FOR the_statement_1;
	
	L1: BEGIN
		SET P_ERROR = '';
		SET V_StartTimeStampPadre = CAST(P_StartTimeStampPadre AS TIMESTAMP(6) FORMAT 'yyyy-mm-ddhh:mi:ss');
		--SET V_StartTimeStampPadre =DATE;
		SET V_COUNT = 1;
		
		---------------------------
		-- Busca y borra si existe la tabla tmp_EmailsEstandarizados
		---------------------------
		SELECT TABLENAME INTO :Temp
		FROM dbc.tables
		WHERE databasename =:P_BDSTAGE
			AND TABLENAME = 'tmp_DireFisica_Estandarizada' ;
			
		IF ACTIVITY_COUNT > 0 THEN
			SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada';
			CALL DBC.SysExecSQL(:V_CADENA);
		END IF;
		
		-----------------------------
		-- Se crea y carga la tabla tmp_DireFisica_Estandarizada
		-- Se hace la primera limpieza de caracteres especiales en la ciudad y el texto de la direccion
		-----------------------------
 
		SET V_CADENA = '';
		SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada
 AS (
SELECT	 dir.Cod_DW_Reporte_Ubic_Original
	,CASE WHEN (GEO.Cod_Dane_Ciudad  IS NOT NULL)
			THEN ' || P_BDVISTA || '.REPLEXPREG( Ubicacion_Stand_Prev, ''[^A-Z^0-9^ ^-^. ' || 'D1'XC'F1'XC || ']'','' '')
	      ELSE ''NO VALIDO''
	END Ubicacion_Stand
	,dir.Texto_Ubicacion_Original
	,dir.Cod_DW_Tipo_Ubicacion
	,dir.Cod_DW_Fuente
	,dir.Lote
	,dir.Id_Buro_Suscriptor
	,dir.Id_Buro_Persona
	,dir.Cod_DW_Cta
	,dir.Cod_DW_Hash
	,dir.Cod_DW_Ubic
	,dir.Valor                               
	,GEO.Descripcion_Ciudad Ciudad
	,dir.Codigo_Ciudad_Dane 
	,dir.Fecha_Reporte
	
	,Cod_DW_Ubicacion_Original
	,Cod_DW_Tipo_Ubicacion_Dir
	,Usuario_BD
	,cast('''' as varchar(20)) Reglas
	,dir.Tipo_Direccion
FROM (
	SELECT	a.*
		,' || P_BDVISTA || '.REPL_CHRS  (UPPER(Texto_Ubicacion_Original), ''GEO'') Ubicacion_Stand_Prev
		,' || P_BDVISTA || '.REPL_CHRS  (TRIM(' || P_BDVISTA || '.REPLEXPREG(' || P_BDVISTA || '.REPLEXPREG( UPPER(Texto_Ciudad), ''^[A-Za-z ]?$''),''[ ]{2,100}'', '' '') ), ''GEO'') Texto_Ciudad_Prev 
	FROM ' || P_BDSTAGE ||'.InsumoDireccionFisica a ) dir
LEFT JOIN '|| P_BDVISTA ||'.V_Geografia GEO
	ON GEO.Cod_Dane_Ciudad = dir.Codigo_Ciudad_Dane

) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';

		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
					,V_StartTimeStampPadre
					,:P_Nombre_Proceso_Padre
					,:V_CADENA
					,'PRO_StandardizationGeografica (1):. Crear y carga la tabla tmp_DireFisica_Estandarizada' 
					,V_ERROR);
		SET P_ERROR = V_ERROR;
		
		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF;
		
		--------------------
		-- Actualiza estadisticas a tmp_DireFisica_Estandarizada
		--------------------
		
		SET V_CADENA = '';
		SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN(Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada';
		
		--------------------
		-- Ejecuta cadena
		--------------------
		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
					,V_StartTimeStampPadre
					,:P_Nombre_Proceso_Padre
					,:V_CADENA
					,'PRO_StandardizationGeografica (2):. Actualizar estadisticas a la tabla tmp_DireFisica_Estandarizada'
					,V_ERROR);
					
		SET P_ERROR = V_ERROR;
		
		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF;
		
		--------------------
		-- Cursor de reglas para ETAPA IN (2)
		-- Reglas de limpieza basadas en patrones de texto
		--------------------
		 SET V_CADENA = '
		SELECT	Sentencia
			,Condicion
			,Flag_Recursiva
			,Cod_DW_Regla_Est_Ubica
		FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
		WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
				select Cod_DW_Atributo
				from '|| P_BDDATOS ||'.ATRIBUTO
				where Cod_DW_Tipo_Atributo in (
					select Cod_DW_Tipo_Atributo
					from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
					where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
				) AND Valor_Origen = ''Geografica''
			) AND  Flag_Activo = ''S'' AND ETAPA IN (2)
		ORDER BY Orden';
		
		PREPARE the_statement FROM V_CADENA;
		
		OPEN cur_reglas_select;
		
		CUR1:LOOP
			FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica;
			
			IF SQLCODE <> 0 THEN 
				LEAVE CUR1;
			END IF;
			
			SET V_CADENA = '
		UPDATE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
		SET ' || V_Sentencia || '
			, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
		WHERE ' || V_Condicion || '
			AND Ubicacion_Stand <> ''NO VALIDO''';
	
			CALL DBC.SysExecSQL(:V_CADENA);
			
			IF SQLCODE NOT IN (0, 7632) THEN
				SET V_CADENA1 = V_CADENA;
				SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1;
				LEAVE L1;
			END IF;
		END LOOP CUR1;
		
		CLOSE cur_reglas_select; 
		
		---------------------------
		-- Reemplaza Toponimos
		-- Busca y borra si existe la tabla tmp_DireFisica_Topo_a
		---------------------------
		SELECT TABLENAME INTO :Temp
		FROM dbc.tables
		WHERE databasename =:P_BDSTAGE
			AND TABLENAME = 'tmp_DireFisica_Topo_a' ;
			
		IF ACTIVITY_COUNT > 0 THEN
			SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo_a';
			CALL DBC.SysExecSQL(:V_CADENA);
		END IF;
		
		SET V_CADENA = ''; 
		
		SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_a
 AS
(
	SELECT	a.Cod_DW_Reporte_Ubic_Original
		,CASE WHEN b.Valor IS NULL
				THEN Ubicacion_Stand
		      ELSE OREPLACE(Ubicacion_Stand, b.Valor, b.Normalizado)
		END Ubicacion_Stand
		,a.Ciudad
		,a.Codigo_Ciudad_Dane
		,a.Tipo_Direccion
	FROM  (
		select *
		from '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
		qualify row_number() over(partition by Cod_DW_Reporte_Ubic_Original
				order by Cod_DW_Reporte_Ubic_Original) = 1
		) a
	LEFT JOIN (
		SELECT   P.Valor
			,P.Normalizado
		FROM '|| P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
		    INNER JOIN '|| P_BDDATOS ||'.TIPO_PARAMETRO AS TP
		    	ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
		    INNER JOIN  '|| P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
		    	ON  TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
		    INNER JOIN '|| P_BDDATOS ||'.PARAMETRO AS P
		    	ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
		WHERE   GP.Nombre_Grupo_Parametro = ''TOPONIMOS''
				  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
                  ) b
               ON a.Ubicacion_Stand like ''%'' || b.Valor || ''%''
          WHERE a.Ubicacion_Stand <> ''NO VALIDO''
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';

		--------------------
		-- Ejecuta cadena
		--------------------
		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
					,V_StartTimeStampPadre 
					,:P_Nombre_Proceso_Padre 
					,:V_CADENA 
					,'PRO_StandardizationGeografica (2):. Crea la tabla tmp_DireFisica_Topo_a' 
					,V_ERROR);
					
		SET P_ERROR = V_ERROR;
		
		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF; 
		
		--------------------
		-- Actualiza estadisticas a tmp_DireFisica_Estandarizada
		--------------------
		SET V_CADENA = '';
		SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_a'; 
		
		--------------------
		-- Ejecuta cadena
		--------------------
		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
					,V_StartTimeStampPadre 
					,:P_Nombre_Proceso_Padre 
					,:V_CADENA 
					,'PRO_StandardizationGeografica (2):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo_a' 
					,V_ERROR);
					
		SET P_ERROR = V_ERROR; 
		
		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF; 
		
		---------------------------
		-- Busca y borra si existe la tabla tmp_DireFisica_Topo
		---------------------------
		SELECT TABLENAME INTO :Temp 
		FROM dbc.tables 
		WHERE databasename =:P_BDSTAGE
			AND TABLENAME = 'tmp_DireFisica_Topo' ;
			
		IF ACTIVITY_COUNT > 0 THEN
			SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo'; 
			CALL DBC.SysExecSQL(:V_CADENA);
		END IF; 
		
		-----------------------------
		-- Se crea y carga la tabla tmp_DireFisica_Topo
		-- Separacion del texto de la direccion en palabras
		-----------------------------
		SET V_CADENA = '';
		
		SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo
 AS (
 WITH RECURSIVE Text_Dir_Palabras
 (Cod_DW_Reporte_Ubic_Original
 ,ID_S
 ,POS
 ,PALABRA
 ,Ubicacion_Stand
 ,Ciudad
 ,Codigo_Ciudad_Dane
 ,Tipo_Direccion
) AS
(
	SELECT Cod_DW_Reporte_Ubic_Original
		,0
		,0
		, cast('''' as varchar(100))
		,Ubicacion_Stand  
		,Ciudad
		,Codigo_Ciudad_Dane
		,Tipo_Direccion
	from '||P_BDSTAGE || '.tmp_DireFisica_Topo_a
	UNION ALL
	SELECT Cod_DW_Reporte_Ubic_Original
		,ID_S+1
		,CASE WHEN POSITION('' '' IN Ubicacion_Stand) > 0
				THEN POSITION('' '' IN Ubicacion_Stand)
		     ELSE CHARACTER_LENGTH(Ubicacion_Stand)
		END POS1
		,TRIM(BOTH '' '' FROM SUBSTR(Ubicacion_Stand, 0, POS1+1))
		,TRIM(SUBSTR(Ubicacion_Stand, POS1+1))
		,Ciudad
		,Codigo_Ciudad_Dane
		,Tipo_Direccion
	FROM Text_Dir_Palabras
	WHERE POS1 > 0
)
SELECT Cod_DW_Reporte_Ubic_Original
	,ID_S
	,PALABRA
	,Ciudad
	,Codigo_Ciudad_Dane
	,Ubicacion_Stand
	,Tipo_Direccion
FROM Text_Dir_Palabras
WHERE ID_S > 0

) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)';

		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
					,V_StartTimeStampPadre 
					,:P_Nombre_Proceso_Padre 
					,:V_CADENA 
					,'PRO_StandardizationGeografica (3):. Crear y carga la tabla tmp_DireFisica_Topo' 
					,V_ERROR); 
					
		SET P_ERROR = V_ERROR;
		
		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
			LEAVE L1; 
		END IF; 
		
		--------------------
		-- Actualiza estadisticas a tmp_DireFisica_Topo
		--------------------
		SET V_CADENA = ''; 
		SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo';
		
		--------------------
		-- Ejecuta cadena
		--------------------
		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
					,V_StartTimeStampPadre 
					,:P_Nombre_Proceso_Padre 
					,:V_CADENA 
					,'PRO_StandardizationGeografica (4):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo' 
					,V_ERROR);
					
		SET P_ERROR = V_ERROR;
		
		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF;
		/*
		BEGIN ETAPA TOPONIMO
		begin tmp_DireFisica_Topo
		*/ ---------------------------
		 -- Busca y borra si existe la tabla tmp_DireFisica_Topo_II
		 ---------------------------
		 SELECT TABLENAME INTO :Temp
		 FROM dbc.tables
		 WHERE databasename =:P_BDSTAGE
		 	AND TABLENAME = 'tmp_DireFisica_Topo_II' ;
		 	
		 IF ACTIVITY_COUNT > 0 THEN
		 	SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo_II';
		 	CALL DBC.SysExecSQL(:V_CADENA);
		 END IF;
		 
		 -----------------------------
		 -- Se crea y carga la tabla tmp_DireFisica_Topo_II
		 -- Se aplican acepciones y no existe, se llama la funcion GENACCEPAUT para
		 --  intentar crearla
		 -----------------------------
		 SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II
 AS (
SELECT	A.Cod_DW_Reporte_Ubic_Original
	,A.ID_S
	,CASE WHEN ACEP.Valor IS NULL
			AND ' || P_BDVISTA || '.VALIDATE_EXPRESSION_R(A.PALABRA, ''^[A-Za-z]{3,20}*$'')=1
			AND A.PALABRA IS NOT NULL
			AND ACEP.Valor IS NULL
		THEN ' || P_BDVISTA || '.GENACCEPAUT(A.PALABRA, SOUNDEX(A.PALABRA))
	END NEW_ACEPCION
	,CASE WHEN ACEP.Valor IS NOT NULL
		THEN ACEP.Normalizado
	      WHEN NEW_ACEPCION IS NOT NULL AND CHAR(NEW_ACEPCION) <> 0
	      	THEN NEW_ACEPCION
	      ELSE A.PALABRA
	END PALABRA
	,A.Ubicacion_Stand
	,A.PALABRA PALABRA_ORI
	,A.Ciudad
	,A.Codigo_Ciudad_Dane
	,A.Tipo_Direccion
FROM ' || P_BDSTAGE ||'.tmp_DireFisica_Topo A
LEFT JOIN (
	SELECT	P.Valor
		,P.Normalizado
	FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
	INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
		ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
	INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
		ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
	INNER JOIN ' || P_BDDATOS ||'.PARAMETRO AS P
		ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
	WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
			  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
		) ACEP
	ON A.PALABRA = ACEP.Valor
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)';

		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (5):. Crear y carga la tabla tmp_DireFisica_Topo_II' ,V_ERROR);
		SET P_ERROR = V_ERROR;
		
		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF;
		
		--------------------
		 -- Actualiza estadisticas a tmp_DireFisica_Topo
		 --------------------
		 SET V_CADENA = '';
		 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II';
		 
		 --------------------
		 -- Ejecuta cadena
		 --------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (6):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo_II' ,V_ERROR);
		 SET P_ERROR = V_ERROR;
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
		 	LEAVE L1; 
		 END IF;
		 
		 --------------------
		 -- Inserta las nuevas acepciones en parametros
		 --------------------
		 SET V_CADENA = '';
		 SET V_CADENA = '
INSERT INTO ' || P_BDDATOS ||'.PARAMETRO
SELECT	P.Cod_DW_Parametro + SUM( 1 ) OVER (ROWS UNBOUNDED PRECEDING) Cod_DW_Parametro
	,A.PALABRA_ORI Valor
	,A.PALABRA Normalizado
	,'|| P_Lote || '
	,NULL
	,1
	,USER
	,STP1.Cod_DW_Subtipo_Parametro
	,NULL
	,date
FROM (SELECT *
	FROM ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II
	WHERE NEW_ACEPCION IS NOT NULL AND CHAR(NEW_ACEPCION) <> 0
	QUALIFY ROW_NUMBER() OVER(PARTITION BY PALABRA_ORI, PALABRA ORDER BY PALABRA_ORI) = 1
   ) A
CROSS JOIN (
	SELECT STP.Cod_DW_Subtipo_Parametro
	FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
	INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
		ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
	INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
		ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
	WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''

		  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
	) STP1
CROSS JOIN (SELECT MAX(Cod_DW_Parametro) Cod_DW_Parametro
	    FROM ' || P_BDDATOS ||'.PARAMETRO
	) P
LEFT JOIN (
	SELECT    P.Valor
		,P.Normalizado
	    FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
	    INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
		ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
	    INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
		ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
	    INNER JOIN ' || P_BDDATOS ||'.PARAMETRO AS P
		ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
	    WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
		      AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
  ) EXT
	ON EXT.Valor = A.PALABRA_ORI
	AND EXT.Normalizado = A.PALABRA
WHERE EXT.Valor IS NULL';
		--------------------
		 -- Ejecuta cadena
		 --------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (7):. Inserta las nuevas acepciones en PARAMETRO' ,V_ERROR);
		 SET P_ERROR = V_ERROR;
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 LEAVE L1; END IF;
		 
		 --------------------
		 -- Actualiza estadisticas a paramtros
		 --------------------
		 SET V_CADENA = '';
		 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Parametro) ON ' || P_BDDATOS ||'.PARAMETRO';
		 
		 --------------------
		 -- Ejecuta cadena
		 --------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (8):. Actualizar estadisticas a la tabla PARAMETRO' ,V_ERROR);
		 SET P_ERROR = V_ERROR; 
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 	LEAVE L1; 
		 END IF;
		 
		 /*end tmp_DireFisica_Topo_II
		*/ /*
		END ETAPA TOPONIMO
		*/ ---------------------------
		 -- Busca y borra si existe la tabla tmp_DireFisica_TopoUpd
		 ---------------------------
		 SELECT TABLENAME INTO :Temp 
		 FROM dbc.tables 
		 WHERE databasename =:P_BDSTAGE
		 	AND TABLENAME = 'tmp_DireFisica_TopoUpd' ;
		 	
		 IF ACTIVITY_COUNT > 0 THEN 
		 
		 	SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd'; 
		 	CALL DBC.SysExecSQL(:V_CADENA);
		 END IF;
		 -----------------------------
		 -- Se crea y carga la tabla tmp_DireFisica_TopoUpd
		 -- Rearma la direccion
		 -----------------------------
		 SET V_CADENA = '';
		 SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_TopoUpd
 AS (
 WITH RECURSIVE Text_Dir_PalabrasT
 (Cod_DW_Reporte_Ubic_Original
 ,ID_S
 ,PALABRA
 ,Ubicacion_Stand
 ,Ciudad
 ,Codigo_Ciudad_Dane
 ,Reglas
 ,Tipo_Direccion
) AS
(
	SELECT Cod_DW_Reporte_Ubic_Original
		,ID_S
		,PALABRA
		,CAST(PALABRA AS VARCHAR(500)) Ubicacion_Stand     
		,Ciudad
		,Codigo_Ciudad_Dane
		,CAST('''' AS VARCHAR(50)) as Reglas
		,Tipo_Direccion
	from '||P_BDSTAGE || '.tmp_DireFisica_Topo_II
	QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
					ORDER BY ID_S ASC) = 1
	UNION ALL
	SELECT A.Cod_DW_Reporte_Ubic_Original
		,B.ID_S
		,B.PALABRA
		,A.Ubicacion_Stand || '' '' || B.PALABRA
		,B.Ciudad
		,B.Codigo_Ciudad_Dane
		,CAST('''' AS VARCHAR(50)) as Reglas
		,B.Tipo_Direccion
	FROM '||P_BDSTAGE || '.tmp_DireFisica_Topo_II B
	INNER JOIN Text_Dir_PalabrasT A
		ON A.Cod_DW_Reporte_Ubic_Original = B.Cod_DW_Reporte_Ubic_Original
		AND (A.ID_S + 1) = B.ID_S
	WHERE B.ID_S IS NOT NULL
)
SELECT Cod_DW_Reporte_Ubic_Original
	,Ubicacion_Stand
	,Ciudad
	,Codigo_Ciudad_Dane
	,Reglas
	,Tipo_Direccion
FROM Text_Dir_PalabrasT
QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
				ORDER BY ID_S DESC, Ubicacion_Stand DESC) = 1

) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';

		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (9):. Crear y carga la tabla tmp_DireFisica_TopoUpd' ,V_ERROR);
		SET P_ERROR = V_ERROR; 
		
		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
			LEAVE L1; 
		END IF;
		
		--------------------
		 -- Actualiza estadisticas a tmp_DireFisica_TopoUpd
		 --------------------
		 SET V_CADENA = '';
		 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN (Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_DireFisica_TopoUpd';
		 
		 --------------------
		 -- Ejecuta cadena
		 --------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (10):. Actualizar estadisticas a la tabla tmp_DireFisica_TopoUpd' ,V_ERROR);
		 
		 SET P_ERROR = V_ERROR;
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 	LEAVE L1;
		 END IF;
		 
		 --------------------
		 -- Cursor de reglas para ETAPA IN (5)
		 -- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones
		 --------------------
		 SET V_CADENA = '
SELECT	Sentencia
	,Condicion
	,Flag_Recursiva
	,Cod_DW_Regla_Est_Ubica
	
FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
		select Cod_DW_Atributo
		from '|| P_BDDATOS ||'.ATRIBUTO
		where Cod_DW_Tipo_Atributo in (
			select Cod_DW_Tipo_Atributo
			from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
			where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
		) AND Valor_Origen = ''Geografica''
	) AND  Flag_Activo = ''S'' AND ETAPA IN (5)
ORDER BY Orden';

		PREPARE the_statement FROM V_CADENA;
		OPEN cur_reglas_select;
		
		CUR2:LOOP
			FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica;
			IF SQLCODE <> 0 THEN 
				LEAVE CUR2;
			END IF;
			
			SET V_CADENA = '
UPDATE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
SET ' || V_Sentencia || '
	, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
WHERE ' || V_Condicion || '
	AND Ubicacion_Stand <> ''NO VALIDO''';
	
			CALL DBC.SysExecSQL(:V_CADENA);
			
			IF SQLCODE NOT IN (0, 7632) THEN 
				SET V_CADENA1 = V_CADENA;
				SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1;
				LEAVE L1;
			END IF;
		END LOOP CUR2;
		
		CLOSE cur_reglas_select;
		
		---------------------------
		 -- Se ordenan las particulas en formato DANE con la funcion ADDRESS_NORMALIZATION
		 -- esta funcion develve una serie de campos donde el ultimo se emplea para tipificar
		 -- la direccion  como valida, invalida 
		 --
		 --
		 -- Busca y borra si existe la tabla tmp_DireFisica_Nor
		 ---------------------------
		 SELECT TABLENAME INTO :Temp 
		 FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Nor' ;
		 
		 IF ACTIVITY_COUNT > 0 THEN 
		 	SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Nor';
		 	CALL DBC.SysExecSQL(:V_CADENA);
		 END IF;
		 
		 SET V_CADENA = ''; 
		 SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Nor
 AS
(
	SELECT	Cod_DW_Reporte_Ubic_Original
		,Ubicacion_Stand
		,'|| P_BDVISTA ||'.ADDRESS_NORMALIZATION(oreplace(Ubicacion_Stand,''?'', ''''), Ciudad, 300, Codigo_Ciudad_Dane, Tipo_Direccion) ADDR_NORM
		,Ciudad
		,Codigo_Ciudad_Dane
	FROM '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';
		--------------------
		 -- Ejecuta cadena
		 --------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR);
		 
		 SET P_ERROR = V_ERROR;
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR);
		 	SET P_ERROR = V_ERROR; 
		 	
		 	IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
		 		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR);
		 		SET P_ERROR = V_ERROR;
		 		
		 		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 			CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR);
		 			SET P_ERROR = V_ERROR;
		 			
		 			IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 				CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR);
		 				SET P_ERROR = V_ERROR;
		 				
		 				IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 					LEAVE L1; 
		 				END IF; 
		 			END IF; 
		 		END IF; 
		 	END IF; 
		 END IF;
		 
		 --------------------
		 -- Actualiza estadisticas a tmp_DireFisica_Nor
		 --------------------
		 SET V_CADENA = '';
		 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Nor';
		 
		 --------------------
		 -- Ejecuta cadena
		 --------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (12):. Actualizar estadisticas a la tabla tmp_DireFisica_Nor' ,V_ERROR);
		 
		 SET P_ERROR = V_ERROR; 
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 	LEAVE L1; 
		 END IF;
		 
		 ---------------------------
		 -- Genera posibles direcciones para las direcciones marcadas como ""X VALIDAR VIAS"" y ""NO VALIDA"" 
		 --
		 -- Busca y borra si existe la tabla tmp_Direcc_No_Validas
		 ---------------------------
		 SELECT TABLENAME INTO :Temp 
		 FROM dbc.tables
		 WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Direcc_No_Validas' ;
		 
		 IF ACTIVITY_COUNT > 0 THEN
		 	SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Direcc_No_Validas';
		 	CALL DBC.SysExecSQL(:V_CADENA); 
		 END IF;
		 
		 SET V_CADENA = '';
		 SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas
 AS
(
	SELECT	Cod_DW_Reporte_Ubic_Original
		,Ubicacion_Stand
		,Codigo_Ciudad_Dane
	FROM '||P_BDSTAGE || '.tmp_DireFisica_Nor
	WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''NO VALIDA''
		OR Ubicacion_Stand = ''NO VALIDO''
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';
		--------------------
		 -- Ejecuta cadena
		 --------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (13):. Crea la tabla tmp_Direcc_No_Validas' ,V_ERROR);
		 SET P_ERROR = V_ERROR;
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
		 	LEAVE L1;
		 END IF; 
		 ---------------------------
		 -- Procesa las direcciones marcadas como ""X VALIDAR VIAS"" y genera un registro por cada una 
		 --
		 -- Busca y borra si existe la tabla tmp_Direcc_X_Validar_Vias
		 ---------------------------
		 SELECT TABLENAME INTO :Temp
		 FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Direcc_X_Validar_Vias' ; 
		 
		 IF ACTIVITY_COUNT > 0 THEN 
		 	SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Direcc_X_Validar_Vias'; 
		 	CALL DBC.SysExecSQL(:V_CADENA); 
		 	END IF;
		 SET V_CADENA = '';
		 SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias
 AS
(
WITH RECURSIVE New_Direc
 (Cod_DW_Reporte_Ubic_Original
 ,ID_S
 ,Direc_New
 ,Dir
 ,Ubicacion_Stand
 ,Codigo_Ciudad_Dane
) AS
(
	SELECT Cod_DW_Reporte_Ubic_Original
		,0 ID_S
		, CAST(NULL AS VARCHAR(100))Direc_New
		, '|| P_BDVISTA ||'.DESC_ADDRESS_MORE_ADDRESS(Ubicacion_Stand, Ciudad, 300, Codigo_Ciudad_Dane) Dir
		, Ubicacion_Stand
		,Codigo_Ciudad_Dane
	from '||P_BDSTAGE || '.tmp_DireFisica_Nor
	WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''X VALIDAR VIAS''
	UNION ALL
	SELECT Cod_DW_Reporte_Ubic_Original
		,ID_S+1 ID_S1
		,'|| P_BDVISTA ||'.eListGetValByIdx(DIR, ''/'', ID_S1) Direc_New1
		, DIR
		,Ubicacion_Stand
		,Codigo_Ciudad_Dane
	FROM New_Direc
	WHERE Direc_New1 is not null
)
SELECT	Cod_DW_Reporte_Ubic_Original
	,ID_S
	,Ubicacion_Stand
	,Direc_New
	,Codigo_Ciudad_Dane
FROM New_Direc
WHERE Direc_New is not null


) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)';
		--------------------
		 -- Ejecuta cadena
		 --------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (14):. Crea la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR);
		 SET P_ERROR = V_ERROR;
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
			CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (14):. Crea la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR);
			SET P_ERROR = V_ERROR;
			
			IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
				LEAVE L1; 
			END IF;
		 END IF;
		 --------------------
		 -- Actualiza estadisticas a tmp_Direcc_X_Validar_Vias
		 --------------------
		 SET V_CADENA = '';
		 
		 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias';
		 
		 --------------------
		 -- Ejecuta cadena
		 --------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (15):. Actualizar estadisticas a la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); 
		 
		 SET P_ERROR = V_ERROR;
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
			LEAVE L1;
		 END IF;
		 
		 ---------------------------
		 -- Marca si alguna de la direcciones puede ser tenia como valida 
		 --
		 -- Busca y borra si existe la tabla tmp_DirVal_X_Validar_Vias
		 ---------------------------
		 SELECT TABLENAME INTO :Temp 
		 FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DirVal_X_Validar_Vias' ; 
		 
		 IF ACTIVITY_COUNT > 0 THEN
			SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DirVal_X_Validar_Vias';
			CALL DBC.SysExecSQL(:V_CADENA); 
		 END IF; 
		 
		 SET V_CADENA = ''; 
		 
		 SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias
 AS
(
SELECT	Dir.Cod_DW_Reporte_Ubic_Original
	,Dir.Ubicacion_Stand
	,Dir.Direc_New
	,CASE WHEN (VUE.Flag_Geo IS NOT NULL
				AND VUE.Flag_Geo = ''S''
				AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) <> ''''
				AND VDF.Cod_DW_Ubic IS NOT NULL)
			AND VRPU.Cod_DW_Ubic IS NOT NULL
		   THEN 1
	       WHEN (VUE.Flag_Geo IS NOT NULL
				AND VUE.Flag_Geo = ''S''
				AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) <> ''''
				AND VDF.Cod_DW_Ubic IS NOT NULL)
			OR VRPU.Cod_DW_Ubic IS NOT NULL
		   THEN 2
	       ELSE 3
	 END Ind_Val
	 ,Dir.Codigo_Ciudad_Dane

FROM	' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias Dir
INNER JOIN ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada TMP
	ON TMP.Cod_DW_Reporte_Ubic_Original = Dir.Cod_DW_Reporte_Ubic_Original
LEFT JOIN ' || P_BDVISTA || '.V_Ubicacion_Estandarizada VUE
	ON TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 1)) = VUE.Texto_Ubicacion
	AND TMP.Cod_DW_Tipo_Ubicacion = VUE.Cod_Dw_Tipo_Ubicacion 
LEFT JOIN ' || P_BDVISTA || '.V_DIRECCION_FISICA VDF
	ON VUE.Cod_DW_Ubic = VDF.Cod_DW_Ubic
	AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(
Dir.
Direc_New, ''&'', 2)) = VDF.Complemento
LEFT JOIN ' || P_BDVISTA || '.V_RELACION_PERSONA_UBICACION VRPU
	ON VUE.Cod_DW_Ubic = COALESCE(VRPU.Cod_DW_Ubic, -1)
	
QUALIFY ROW_NUMBER() OVER(PARTITION BY Dir.Cod_DW_Reporte_Ubic_Original, Dir.Direc_New
			ORDER BY Dir.Cod_DW_Reporte_Ubic_Original) = 1

) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';
		--------------------
		 -- Ejecuta cadena
		 --------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (16):. Crea la tabla tmp_DirVal_X_Validar_Vias' ,V_ERROR); 
		 SET P_ERROR = V_ERROR; 
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
			LEAVE L1;
		 END IF;
		 
		 --------------------
		 -- Actualiza estadisticas a tmp_Direcc_No_Validas
		 --------------------
		 SET V_CADENA = '';
		 
		 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias'; 
		 
		 --------------------
		 -- Ejecuta cadena
		 --------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (17):. Actualizar estadisticas a la tabla tmp_DirVal_X_Validar_Vias' ,V_ERROR);
		 
		 SET P_ERROR = V_ERROR;
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
			LEAVE L1; 
		 END IF;
		 
		 --------------------
		 -- Completa las direcciones no validas en tmp_Direcc_No_Validas con las direcciones que no se pudieron clasificar
		 --------------------
		 SET V_CADENA = ''; 
		 SET V_CADENA = '
INSERT INTO ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas
SELECT	DISTINCT
	Cod_DW_Reporte_Ubic_Original
	,Ubicacion_Stand
	,Codigo_Ciudad_Dane
FROM	' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias A
WHERE Ind_Val = 3
	AND NOT EXISTS (
		SELECT 1
		FROM ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias B
		WHERE A.Cod_DW_Reporte_Ubic_Original = B.Cod_DW_Reporte_Ubic_Original
		AND B.Ind_Val in (1,2)
	)
	'; 
		
		--------------------
		 -- Ejecuta cadena
		 --------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (18):. Completa direcciones invalidas en tmp_Direcc_No_Validas' ,V_ERROR);
		 SET P_ERROR = V_ERROR; 
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
			LEAVE L1;
		 END IF;
		 
		 --------------------
		 -- Actualiza estadisticas a tmp_Direcc_No_Validas
		 --------------------
		 SET V_CADENA = ''; 
		 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas';
		 
		 --------------------
		 -- Ejecuta cadena
		 --------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (19):. Actualizar estadisticas a la tabla tmp_Direcc_No_Validas' ,V_ERROR);
		 
		 SET P_ERROR = V_ERROR;
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 	LEAVE L1;
		 END IF;
		 
		 --------------------
		 -- Une todas las direcciones validas en tmp_Dire_Estan_Val
		 -- Busca y borra si existe la tabla tmp_Dire_Estan_Val
		 ---------------------------
		 SELECT TABLENAME INTO :Temp 
		 FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Dire_Estan_Val' ;
		 
		 IF ACTIVITY_COUNT > 0 THEN
		 	SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Dire_Estan_Val'; 
		 	CALL DBC.SysExecSQL(:V_CADENA);
		 END IF; 
		 
		 SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val
 AS (
	SELECT	Cod_DW_Reporte_Ubic_Original
		,ADDR_NORM
		,Codigo_Ciudad_Dane
	FROM '||P_BDSTAGE || '.tmp_DireFisica_Nor
	WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''VALIDA''
	UNION ALL
	SELECT	Cod_DW_Reporte_Ubic_Original
		,Direc_New
		,Codigo_Ciudad_Dane
	FROM '||P_BDSTAGE || '.tmp_DirVal_X_Validar_Vias
	WHERE Ind_Val < 3
	QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
					ORDER BY Ind_Val) = 1
	
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';
		--------------------
		 -- Ejecuta cadena
		 --------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (20):. Crea la tabla tmp_Dire_Estan_Val' ,V_ERROR);
		 
		 SET P_ERROR = V_ERROR; 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 	LEAVE L1;
		 END IF; 
		 
		 --------------------
		 -- Actualiza estadisticas a tmp_Dire_Estan_Val
		 --------------------
		 SET V_CADENA = ''; 
		 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val';
		 
		 --------------------
		 -- Ejecuta cadena
		 --------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (21):. Actualizar estadisticas a la tabla tmp_Dire_Estan_Val' ,V_ERROR); 
		 
		 SET P_ERROR = V_ERROR;
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 	LEAVE L1; 
		 END IF; 
		 
		 ---------------------------
		 -- Busca y borra si existe la tabla DireccionFisica_Estandarizada
		 ---------------------------
		 SELECT TABLENAME INTO :Temp 
		 FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'DireccionFisica_Estandarizada' ; 
		 
		 IF ACTIVITY_COUNT > 0 THEN 
		 	SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.DireccionFisica_Estandarizada';
		 	CALL DBC.SysExecSQL(:V_CADENA); 
		 END IF;
		 
		 --------------------
		 -- Unifica los datos de acuerdo Cod_DW_Reporte_Ubic_Original, el resultado en DireccionFisica_Estandarizada
		 -- Se normaliza y ordena el texto de la direccion con la funcion ADDRESS_NORMALIZATION
		 --------------------
		 SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.DireccionFisica_Estandarizada
 AS (
	SELECT	dir.Cod_DW_Reporte_Ubic_Original
		,dir.Texto_Ubicacion_Original
		,dir.Cod_DW_Tipo_Ubicacion
		,dir.Cod_DW_Fuente
		,dir.Lote
		,dir.Id_Buro_Suscriptor
		,dir.Id_Buro_Persona
		,dir.Cod_DW_Cta
		,dir.Cod_DW_Hash
		,dir.Cod_DW_Ubic
		,dir.Valor
		,dir.Ciudad Texto_Ciudad
		,dir.Codigo_Ciudad_Dane
		,dir.Fecha_Reporte
		
		,dir.Cod_DW_Ubicacion_Original
		,dir.Cod_DW_Tipo_Ubicacion_Dir
		,dir.Usuario_BD
		
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1)) DIRE_GEO
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 2)) DIRE_COMPLEMENTO
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 3)) DIR_TIPO_DIRE
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 4)) DIR_TIPOVIA
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 5)) DIR_NUMVIAPPAL
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 6)) DIR_NUMVIAGEN
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 7)) DIR_NUMPLACA
		,COALESCE(ADDR_NORM, dir.Ubicacion_Stand) Ubicacion_Stand
		,cast('''' as varchar(20)) Reglas
	FROM	' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada dir
	LEFT JOIN ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val Est
		ON dir.Cod_DW_Reporte_Ubic_Original = Est.Cod_DW_Reporte_Ubic_Original
	QUALIFY ROW_NUMBER() OVER(PARTITION BY dir.Cod_DW_Reporte_Ubic_Original
				ORDER BY dir.Cod_DW_Reporte_Ubic_Original) = 1
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; 
		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (22):. Crear y carga la tabla DireccionFisica_Estandarizada' ,V_ERROR);
		
		SET P_ERROR = V_ERROR;
		
		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF;
		--------------------
		 -- Actualiza estadisticas a tmp_DireFisica_Estand_Topo
		 --------------------
		 SET V_CADENA = '';
		 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original )
							ON ' || P_BDSTAGE ||'.DireccionFisica_Estandarizada';
							
		--------------------
		 -- Ejecuta cadena
		 --------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (8):. Actualizar estadisticas a la tabla DireccionFisica_Estandarizada' ,V_ERROR);
		 SET P_ERROR = V_ERROR; 
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 	LEAVE L1;
		 END IF; 
		 
		 --------------------
		 -- Cursor de reglas para ETAPA IN (6)
		 -- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones
		 --------------------
		 SET V_CADENA = '
SELECT	Sentencia
	,Condicion
	,Flag_Recursiva
	,Cod_DW_Regla_Est_Ubica
FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
		select Cod_DW_Atributo
		from '|| P_BDDATOS ||'.ATRIBUTO
		where Cod_DW_Tipo_Atributo in (
			select Cod_DW_Tipo_Atributo
			from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
			where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
		) AND Valor_Origen = ''Geografica''
	) AND  Flag_Activo = ''S'' AND ETAPA IN (6)
ORDER BY Orden'; 
		PREPARE the_statement FROM V_CADENA;
		OPEN cur_reglas_select;
		CUR3:LOOP
			FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica;
			IF SQLCODE <> 0 THEN
				LEAVE CUR3;
			END IF;
			
			SET V_CADENA = '
UPDATE '||P_BDSTAGE || '.DireccionFisica_Estandarizada
SET ' || V_Sentencia || '
	, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
WHERE ' || V_Condicion || '
	AND Ubicacion_Stand <> ''NO VALIDO''';
		
			CALL DBC.SysExecSQL(:V_CADENA);
			
			IF SQLCODE NOT IN (0, 7632) THEN 
				SET V_CADENA1 = V_CADENA; 
				SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1;
				LEAVE L1; 
			END IF; 
		END LOOP CUR3; 
		CLOSE cur_reglas_select; 
		
	END L1;
END;

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
REPLACE PROCEDURE REC_DATOS.PRO_StandardizationGeografica_20180730 ( IN P_Lote INTEGER ,IN P_StartTimeStampPadre VARCHAR(20) ,IN P_Nombre_Proceso_Padre VARCHAR(30) ,IN P_BDDATOS VARCHAR(20) ,IN P_BDVISTA VARCHAR(20) ,IN P_BDSTAGE VARCHAR(20) ,OUT P_ERROR VARCHAR(32000) ) /*
 * ################################################################################
 * 
 * Objetivo:		Estandariza las direcciones fisicas como ubicacion del insumo
 *			InsumoDireccionFisica, dejando el resultado en DireccionFisica_Estandarizada
 * Fecha:		2016/11/09
 * Realizado por:	Luis E Ramirez
 * Proyecto:		Nuevo reconocer
 * Script:		PRO_StandardizationGeografica BCK 12 sept antes de a?adir campo de reglas a stg
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha	Objetivo				Realizado por
 * 2017/12/28	Agregar el codigo dane hasta la tabla	aariza - Capgemini
 *		DireccionFisica_Estandarizada
 * 2018/03/06	Se agrega el campo Tipo_Direccion y	Capgemini
 *		se elimina el calculo del cod dane	
 *
 * 2018/03/27	Los registros marcados como no validos	Capgemini
 *		y enviados a la tabla tmp_Dire_Estan_Val
 *		ya no se excluyen del proceso de
 *		estandarizacion
 * 2018-05-08 #1 ajuste por bug en teradata pruebas	Capgemini
 * 2018-05-09 #2 ajuste null por ubicación original y nvl
 *		para armado de dirección		Capgemini
 * 2018-05-18 #3 ajuste no procesar nulos		Capgemini
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */ BEGIN ------------------------
-- Declaracion de variables
------------------------
 DECLARE V_StartTimeStampPadre TIMESTAMP(6); DECLARE V_ERROR VARCHAR(32000); DECLARE V_CADENA VARCHAR(32000); DECLARE V_CADENA1 VARCHAR(10000); DECLARE Temp CHAR(30); DECLARE V_Sentencia VARCHAR(500); DECLARE V_Condicion VARCHAR(500); DECLARE V_Flag_Recursiva VARCHAR(1); DECLARE V_COUNT INTEGER; DECLARE V_Cod_DW_Regla_Est_Ubica INTEGER; DECLARE cur_reglas_select NO SCROLL CURSOR FOR the_statement; DECLARE cur_count_rec NO SCROLL CURSOR FOR the_statement_1; L1: BEGIN SET P_ERROR = ''; SET V_StartTimeStampPadre = CAST(P_StartTimeStampPadre AS TIMESTAMP(6) FORMAT 'yyyy-mm-ddhh:mi:ss'); --SET V_StartTimeStampPadre =DATE;
 SET V_COUNT = 1; ---------------------------
 -- Busca y borra si existe la tabla tmp_EmailsEstandarizados
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Estandarizada' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
 -- Se crea y carga la tabla tmp_DireFisica_Estandarizada
 -- Se hace la primera limpieza de caracteres especiales en la ciudad y el texto de la direccion
 -----------------------------
 SET V_CADENA = ''; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada
	 AS (
	SELECT	 dir.Cod_DW_Reporte_Ubic_Original
		,nvl(' || P_BDVISTA || '.REPLEXPREG( Ubicacion_Stand_Prev, ''[^A-Z^0-9^ ^-^. ' || 'D1'XC'F1'XC || ']'','' ''),Texto_Ubicacion_Original) as Ubicacion_Stand /*#2*/
		,dir.Texto_Ubicacion_Original
		,dir.Cod_DW_Tipo_Ubicacion
		,dir.Cod_DW_Fuente
		,dir.Lote
		,dir.Id_Buro_Suscriptor
		,dir.Id_Buro_Persona
		,dir.Cod_DW_Cta
		,dir.Cod_DW_Hash
		,dir.Cod_DW_Ubic
		,dir.Valor                               
		,GEO.Descripcion_Ciudad Ciudad
		,dir.Codigo_Ciudad_Dane 
		,dir.Fecha_Reporte
		
		,Cod_DW_Ubicacion_Original
		,Cod_DW_Tipo_Ubicacion_Dir
		,Usuario_BD
		,cast('''' as varchar(20)) Reglas
		,dir.Tipo_Direccion
	FROM (
		SELECT	a.*
			,' || P_BDVISTA || '.REPL_CHRS  (UPPER(Texto_Ubicacion_Original), ''GEO'') Ubicacion_Stand_Prev
			,' || P_BDVISTA || '.REPL_CHRS  (TRIM(' || P_BDVISTA || '.REPLEXPREG(' || P_BDVISTA || '.REPLEXPREG( UPPER(Texto_Ciudad), ''^[A-Za-z ]?$''),''[ ]{2,100}'', '' '') ), ''GEO'') Texto_Ciudad_Prev 
		FROM ' || P_BDSTAGE ||'.InsumoDireccionFisica a ) dir
	LEFT JOIN '|| P_BDVISTA ||'.V_Geografia GEO
		ON GEO.Cod_Dane_Ciudad = dir.Codigo_Ciudad_Dane
	
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (1):. Crear y carga la tabla tmp_DireFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_Estandarizada
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN(Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Actualizar estadisticas a la tabla tmp_DireFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Cursor de reglas para ETAPA IN (2)
 -- Reglas de limpieza basadas en patrones de texto
 --------------------
 SET V_CADENA = '
			SELECT	Sentencia
				,Condicion
				,Flag_Recursiva
				,Cod_DW_Regla_Est_Ubica
			FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
			WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
					select Cod_DW_Atributo
					from '|| P_BDDATOS ||'.ATRIBUTO
					where Cod_DW_Tipo_Atributo in (
						select Cod_DW_Tipo_Atributo
						from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
						where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
					) AND Valor_Origen = ''Geografica''
				) AND  Flag_Activo = ''S'' AND ETAPA IN (2)
			ORDER BY Orden'; PREPARE the_statement FROM V_CADENA; OPEN cur_reglas_select; CUR1:LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; IF SQLCODE <> 0 THEN LEAVE CUR1; END IF; SET V_CADENA = '
				UPDATE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
				SET ' || V_Sentencia || '
					, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
				WHERE ' || V_Condicion ; CALL DBC.SysExecSQL(:V_CADENA); IF SQLCODE NOT IN (0, 7632) THEN SET V_CADENA1 = V_CADENA; SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1; LEAVE L1; END IF; END LOOP CUR1; CLOSE cur_reglas_select; ---------------------------
 -- Reemplaza Toponimos
 -- Busca y borra si existe la tabla tmp_DireFisica_Topo_a
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Topo_a' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo_a'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_a
	 AS
	(
		SELECT	a.Cod_DW_Reporte_Ubic_Original
			,CASE WHEN b.Valor IS NULL
					THEN Ubicacion_Stand
			      ELSE OREPLACE(Ubicacion_Stand, b.Valor, b.Normalizado)
			END Ubicacion_Stand
			,a.Ciudad
			,a.Codigo_Ciudad_Dane
			,a.Tipo_Direccion
		FROM  (
			select *
			from '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
			qualify row_number() over(partition by Cod_DW_Reporte_Ubic_Original
					order by Cod_DW_Reporte_Ubic_Original) = 1
			) a
		LEFT JOIN (
			SELECT   P.Valor
				,P.Normalizado
			FROM '|| P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
			    INNER JOIN '|| P_BDDATOS ||'.TIPO_PARAMETRO AS TP
				ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
			    INNER JOIN  '|| P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
				ON  TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
			    INNER JOIN '|| P_BDDATOS ||'.PARAMETRO AS P
				ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
			WHERE   GP.Nombre_Grupo_Parametro = ''TOPONIMOS''
					  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
			  ) b
		       ON a.Ubicacion_Stand like ''%'' || b.Valor || ''%''
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Crea la tabla tmp_DireFisica_Topo_a' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_Estandarizada
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_a'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo_a' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Busca y borra si existe la tabla tmp_DireFisica_Topo
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Topo' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
 -- Se crea y carga la tabla tmp_DireFisica_Topo
 -- Separacion del texto de la direccion en palabras
 -----------------------------
 SET V_CADENA = ''; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo
	 AS (
	 WITH RECURSIVE Text_Dir_Palabras
	 (Cod_DW_Reporte_Ubic_Original
	 ,ID_S
	 ,POS
	 ,PALABRA
	 ,Ubicacion_Stand
	 ,Ciudad
	 ,Codigo_Ciudad_Dane
	 ,Tipo_Direccion
	) AS
	(
		SELECT Cod_DW_Reporte_Ubic_Original
			,0
			,0
			, cast('''' as varchar(100))
			,Ubicacion_Stand  
			,Ciudad
			,Codigo_Ciudad_Dane
			,Tipo_Direccion
		from '||P_BDSTAGE || '.tmp_DireFisica_Topo_a
		UNION ALL
		SELECT Cod_DW_Reporte_Ubic_Original
			,ID_S+1
			,CASE WHEN POSITION('' '' IN Ubicacion_Stand) > 0
					THEN POSITION('' '' IN Ubicacion_Stand)
			     ELSE CHARACTER_LENGTH(Ubicacion_Stand)
			END POS1
			,TRIM(BOTH '' '' FROM SUBSTR(Ubicacion_Stand, 0, POS1+1))
			,TRIM(SUBSTR(Ubicacion_Stand, POS1+1))
			,Ciudad
			,Codigo_Ciudad_Dane
			,Tipo_Direccion
		FROM Text_Dir_Palabras
		WHERE POS1 > 0
	)
	SELECT Cod_DW_Reporte_Ubic_Original
		,ID_S
		,PALABRA 
		,Ciudad
		,Codigo_Ciudad_Dane
		,Ubicacion_Stand
		,Tipo_Direccion
	FROM Text_Dir_Palabras
	WHERE ID_S > 0
	
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)'; CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (3):. Crear y carga la tabla tmp_DireFisica_Topo' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_Topo
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (4):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; /*
		BEGIN ETAPA TOPONIMO
		begin tmp_DireFisica_Topo
		*/ ---------------------------
 -- Busca y borra si existe la tabla tmp_DireFisica_Topo_II
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Topo_II' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo_II'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
 -- Se crea y carga la tabla tmp_DireFisica_Topo_II
 -- Se aplican acepciones y no existe, se llama la funcion GENACCEPAUT para
 --  intentar crearla
 -----------------------------
 SET V_CADENA = ''; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II
	AS (
	SELECT	A.Cod_DW_Reporte_Ubic_Original
	,A.ID_S
	,CASE WHEN ACEP.Valor IS NULL
			AND ' || P_BDVISTA || '.VALIDATE_EXPRESSION_R(A.PALABRA, ''^[A-Za-z]{3,20}*$'')=1
			AND A.PALABRA IS NOT NULL
			AND ACEP.Valor IS NULL
		THEN ' || P_BDVISTA || '.GENACCEPAUT(A.PALABRA, SOUNDEX(A.PALABRA))
	END NEW_ACEPCION
	,CASE WHEN ACEP.Valor IS NOT NULL
		THEN ACEP.Normalizado
	      WHEN NEW_ACEPCION IS NOT NULL AND CHAR(NEW_ACEPCION) <> 0
		THEN NEW_ACEPCION
	      ELSE A.PALABRA
	END PALABRA
	,A.Ubicacion_Stand
	,A.PALABRA PALABRA_ORI
	,A.Ciudad
	,A.Codigo_Ciudad_Dane
	,A.Tipo_Direccion
	FROM ' || P_BDSTAGE ||'.tmp_DireFisica_Topo A
	LEFT JOIN (
	SELECT	P.Valor
		,P.Normalizado
	FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
	INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
		ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
	INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
		ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
	INNER JOIN ' || P_BDDATOS ||'.PARAMETRO AS P
		ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
	WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
			  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
		) ACEP
	ON TRIM(A.PALABRA) = ACEP.Valor /*#1*/
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)'; CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (5):. Crear y carga la tabla tmp_DireFisica_Topo_II' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_Topo
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (6):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo_II' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Inserta las nuevas acepciones en parametros
 --------------------
 SET V_CADENA = ''; SET V_CADENA = '
	INSERT INTO ' || P_BDDATOS ||'.PARAMETRO
	SELECT	P.Cod_DW_Parametro + SUM( 1 ) OVER (ROWS UNBOUNDED PRECEDING) Cod_DW_Parametro
		,A.PALABRA_ORI Valor
		,A.PALABRA Normalizado
		,'|| P_Lote || '
		,NULL
		,1
		,USER
		,STP1.Cod_DW_Subtipo_Parametro
		,NULL
		,date
	FROM (SELECT *
		FROM ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II
		WHERE NEW_ACEPCION IS NOT NULL AND CHAR(NEW_ACEPCION) <> 0
		QUALIFY ROW_NUMBER() OVER(PARTITION BY PALABRA_ORI, PALABRA ORDER BY PALABRA_ORI) = 1
	   ) A
	CROSS JOIN (
		SELECT STP.Cod_DW_Subtipo_Parametro
		FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
		INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
			ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
		INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
			ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
		WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
	
			  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
		) STP1
	CROSS JOIN (SELECT MAX(Cod_DW_Parametro) Cod_DW_Parametro
		    FROM ' || P_BDDATOS ||'.PARAMETRO
		) P
	LEFT JOIN (
		SELECT    P.Valor
			,P.Normalizado
		    FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
		    INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
			ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
		    INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
			ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
		    INNER JOIN ' || P_BDDATOS ||'.PARAMETRO AS P
			ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
		    WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
			      AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
	  ) EXT
		ON EXT.Valor = 			trim(A.PALABRA_ORI) /*#1*/
		AND EXT.Normalizado = 	trim(A.PALABRA) /*#1*/
	WHERE EXT.Valor IS NULL'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (7):. Inserta las nuevas acepciones en PARAMETRO' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a paramtros
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Parametro) ON ' || P_BDDATOS ||'.PARAMETRO'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (8):. Actualizar estadisticas a la tabla PARAMETRO' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; /*end tmp_DireFisica_Topo_II
		*/ /*
		END ETAPA TOPONIMO
		*/ ---------------------------
 -- Busca y borra si existe la tabla tmp_DireFisica_TopoUpd
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_TopoUpd' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
 -- Se crea y carga la tabla tmp_DireFisica_TopoUpd
 -- Rearma la direccion
 -----------------------------
 SET V_CADENA = ''; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_TopoUpd
	AS (
	WITH RECURSIVE Text_Dir_PalabrasT
	(Cod_DW_Reporte_Ubic_Original
	,ID_S
	,PALABRA
	,Ubicacion_Stand
	,Ciudad
	,Codigo_Ciudad_Dane
	,Reglas
	,Tipo_Direccion
	) AS
	(
	SELECT Cod_DW_Reporte_Ubic_Original
		,ID_S
		,PALABRA
		,CAST(PALABRA AS VARCHAR(500)) Ubicacion_Stand     
		,Ciudad
		,Codigo_Ciudad_Dane
		,CAST('''' AS VARCHAR(50)) as Reglas
		,Tipo_Direccion
	from '||P_BDSTAGE || '.tmp_DireFisica_Topo_II
	QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
					ORDER BY ID_S ASC) = 1
	UNION ALL
	SELECT A.Cod_DW_Reporte_Ubic_Original
		,B.ID_S
		,B.PALABRA
		,nvl(A.Ubicacion_Stand,'''') || '' '' || nvl(B.PALABRA,'''') /*#2*/
		,B.Ciudad
		,B.Codigo_Ciudad_Dane
		,CAST('''' AS VARCHAR(50)) as Reglas
		,B.Tipo_Direccion
	FROM '||P_BDSTAGE || '.tmp_DireFisica_Topo_II B
	INNER JOIN Text_Dir_PalabrasT A
		ON A.Cod_DW_Reporte_Ubic_Original = B.Cod_DW_Reporte_Ubic_Original
		AND (A.ID_S + 1) = B.ID_S
	WHERE B.ID_S IS NOT NULL
	)
	SELECT Cod_DW_Reporte_Ubic_Original
	,Ubicacion_Stand
	,Ciudad
	,Codigo_Ciudad_Dane
	,Reglas
	,Tipo_Direccion
	FROM Text_Dir_PalabrasT
	QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
				ORDER BY ID_S DESC, Ubicacion_Stand DESC) = 1
	
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (9):. Crear y carga la tabla tmp_DireFisica_TopoUpd' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_TopoUpd
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN (Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_DireFisica_TopoUpd'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (10):. Actualizar estadisticas a la tabla tmp_DireFisica_TopoUpd' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Cursor de reglas para ETAPA IN (5)
 -- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones
 --------------------
 SET V_CADENA = '
	SELECT	Sentencia
		,Condicion
		,Flag_Recursiva
		,Cod_DW_Regla_Est_Ubica
		
	FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
	WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
			select Cod_DW_Atributo
			from '|| P_BDDATOS ||'.ATRIBUTO
			where Cod_DW_Tipo_Atributo in (
				select Cod_DW_Tipo_Atributo
				from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
				where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
			) AND Valor_Origen = ''Geografica''
		) AND  Flag_Activo = ''S'' AND ETAPA IN (5)
	ORDER BY Orden'; PREPARE the_statement FROM V_CADENA; OPEN cur_reglas_select; CUR2:LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; IF SQLCODE <> 0 THEN LEAVE CUR2; END IF; SET V_CADENA = '
		UPDATE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
		SET ' || V_Sentencia || '
			, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
		WHERE    ' || V_Condicion ||' AND Ubicacion_Stand  IS NOT NULL /*#3*/ '; CALL DBC.SysExecSQL(:V_CADENA); IF SQLCODE NOT IN (0, 7632) THEN SET V_CADENA1 = V_CADENA; SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1; LEAVE L1; END IF; END LOOP CUR2; CLOSE cur_reglas_select; ---------------------------
 -- Se ordenan las particulas en formato DANE con la funcion ADDRESS_NORMALIZATION
 -- esta funcion develve una serie de campos donde el ultimo se emplea para tipificar
 -- la direccion  como valida, invalida 
 --
 --
 -- Busca y borra si existe la tabla tmp_DireFisica_Nor
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Nor' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Nor'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Nor
	AS
	(
	SELECT	Cod_DW_Reporte_Ubic_Original
		,Ubicacion_Stand
		,'|| P_BDVISTA ||'.ADDRESS_NORMALIZATION(oreplace(Ubicacion_Stand,''?'', ''''), Ciudad, 300, COALESCE(Codigo_Ciudad_Dane, ''''), Tipo_Direccion) ADDR_NORM
		,Ciudad
		,Codigo_Ciudad_Dane
	FROM '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_Nor
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Nor'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (12):. Actualizar estadisticas a la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Genera posibles direcciones para las direcciones marcadas como ""X VALIDAR VIAS"" y ""NO VALIDA"" 
 --
 -- Busca y borra si existe la tabla tmp_Direcc_No_Validas
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Direcc_No_Validas' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Direcc_No_Validas'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas
	AS
	(
	SELECT	Cod_DW_Reporte_Ubic_Original
		,Ubicacion_Stand
		,Codigo_Ciudad_Dane
	FROM '||P_BDSTAGE || '.tmp_DireFisica_Nor
	WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''NO VALIDA 2''
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (13):. Crea la tabla tmp_Direcc_No_Validas' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Procesa las direcciones marcadas como ""X VALIDAR VIAS"" y genera un registro por cada una 
 --
 -- Busca y borra si existe la tabla tmp_Direcc_X_Validar_Vias
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Direcc_X_Validar_Vias' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Direcc_X_Validar_Vias'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias
	 AS
	(
	WITH RECURSIVE New_Direc
	 (Cod_DW_Reporte_Ubic_Original
	 ,ID_S
	 ,Direc_New
	 ,Dir
	 ,Ubicacion_Stand
	 ,Codigo_Ciudad_Dane
	) AS
	(
		SELECT Cod_DW_Reporte_Ubic_Original
			,0 ID_S
			, CAST(NULL AS VARCHAR(100))Direc_New
			, '|| P_BDVISTA ||'.DESC_ADDRESS_MORE_ADDRESS(Ubicacion_Stand, Ciudad, 300, Codigo_Ciudad_Dane) Dir
			, Ubicacion_Stand
			,Codigo_Ciudad_Dane
		from '||P_BDSTAGE || '.tmp_DireFisica_Nor
		WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''X VALIDAR VIAS''
		UNION ALL
		SELECT Cod_DW_Reporte_Ubic_Original
			,ID_S+1 ID_S1
			,'|| P_BDVISTA ||'.eListGetValByIdx(DIR, ''/'', ID_S1) Direc_New1
			, DIR
			,Ubicacion_Stand
			,Codigo_Ciudad_Dane
		FROM New_Direc
		WHERE Direc_New1 is not null
	)
	SELECT	Cod_DW_Reporte_Ubic_Original
		,ID_S
		,Ubicacion_Stand
		,Direc_New
		,Codigo_Ciudad_Dane
	FROM New_Direc
	WHERE Direc_New is not null
	
	
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (14):. Crea la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_Direcc_X_Validar_Vias
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (15):. Actualizar estadisticas a la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Marca si alguna de la direcciones puede ser tenia como valida 
 --
 -- Busca y borra si existe la tabla tmp_DirVal_X_Validar_Vias
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DirVal_X_Validar_Vias' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DirVal_X_Validar_Vias'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias
	 AS
	(
	SELECT	Dir.Cod_DW_Reporte_Ubic_Original
		,Dir.Ubicacion_Stand
		,Dir.Direc_New
		,CASE WHEN (VUE.Flag_Geo IS NOT NULL
					AND VUE.Flag_Geo = ''S''
					AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) <> ''''
					AND VDF.Cod_DW_Ubic IS NOT NULL)
				AND VRPU.Cod_DW_Ubic IS NOT NULL
			   THEN 1
		       WHEN (VUE.Flag_Geo IS NOT NULL
					AND VUE.Flag_Geo = ''S''
					AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) <> ''''
					AND VDF.Cod_DW_Ubic IS NOT NULL)
				OR VRPU.Cod_DW_Ubic IS NOT NULL
			   THEN 2
		       ELSE 3
		 END Ind_Val
		 ,Dir.Codigo_Ciudad_Dane
	
	FROM	' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias Dir
	INNER JOIN ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada TMP
		ON TMP.Cod_DW_Reporte_Ubic_Original = Dir.Cod_DW_Reporte_Ubic_Original
	LEFT JOIN ' || P_BDVISTA || '.V_Ubicacion_Estandarizada VUE
		ON TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 1)) = VUE.Texto_Ubicacion
		AND TMP.Cod_DW_Tipo_Ubicacion = VUE.Cod_Dw_Tipo_Ubicacion 
	LEFT JOIN ' || P_BDVISTA || '.V_DIRECCION_FISICA VDF
		ON VUE.Cod_DW_Ubic = VDF.Cod_DW_Ubic
		AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) = VDF.Complemento
	LEFT JOIN ' || P_BDVISTA || '.V_RELACION_PERSONA_UBICACION VRPU
		ON VUE.Cod_DW_Ubic = COALESCE(VRPU.Cod_DW_Ubic, -1)
		
	QUALIFY ROW_NUMBER() OVER(PARTITION BY Dir.Cod_DW_Reporte_Ubic_Original, Dir.Direc_New
				ORDER BY Dir.Cod_DW_Reporte_Ubic_Original) = 1
	
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (16):. Crea la tabla tmp_DirVal_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_Direcc_No_Validas
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (17):. Actualizar estadisticas a la tabla tmp_DirVal_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Completa las direcciones no validas en tmp_Direcc_No_Validas con las direcciones que no se pudieron clasificar
 --------------------
 SET V_CADENA = ''; SET V_CADENA = '
	INSERT INTO ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas
	SELECT	DISTINCT
	Cod_DW_Reporte_Ubic_Original
	,Ubicacion_Stand
	,Codigo_Ciudad_Dane
	FROM	' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias A
	WHERE Ind_Val = 3
	AND NOT EXISTS (
		SELECT 1
		FROM ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias B
		WHERE A.Cod_DW_Reporte_Ubic_Original = B.Cod_DW_Reporte_Ubic_Original
		AND B.Ind_Val in (1,2)
	)
	'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (18):. Completa direcciones invalidas en tmp_Direcc_No_Validas' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_Direcc_No_Validas
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (19):. Actualizar estadisticas a la tabla tmp_Direcc_No_Validas' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Une todas las direcciones validas en tmp_Dire_Estan_Val
 -- Busca y borra si existe la tabla tmp_Dire_Estan_Val
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Dire_Estan_Val' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Dire_Estan_Val'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val
	AS (
	SELECT	Cod_DW_Reporte_Ubic_Original
		,oreplace(ADDR_NORM, ''NO VALIDA 2'',''NO VALIDA'') ADDR_NORM
		,Codigo_Ciudad_Dane
	FROM '||P_BDSTAGE || '.tmp_DireFisica_Nor
	WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) <> ''X VALIDAR VIAS''
	UNION ALL
	SELECT	Cod_DW_Reporte_Ubic_Original
		,OREPLACE(OREPLACE(Direc_New, ''NO VALIDA 2'', ''VALIDA''), ''NO VALIDA'', ''VALIDA'')  Direc_New
		,Codigo_Ciudad_Dane
	FROM '||P_BDSTAGE || '.tmp_DirVal_X_Validar_Vias
	QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
					ORDER BY Ind_Val) = 1
	
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (20):. Crea la tabla tmp_Dire_Estan_Val' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_Dire_Estan_Val
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (21):. Actualizar estadisticas a la tabla tmp_Dire_Estan_Val' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Busca y borra si existe la tabla DireccionFisica_Estandarizada
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'DireccionFisica_Estandarizada' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.DireccionFisica_Estandarizada'; CALL DBC.SysExecSQL(:V_CADENA); END IF; --------------------
 -- Unifica los datos de acuerdo Cod_DW_Reporte_Ubic_Original, el resultado en DireccionFisica_Estandarizada
 -- Se normaliza y ordena el texto de la direccion con la funcion ADDRESS_NORMALIZATION
 --------------------
 SET V_CADENA = ''; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.DireccionFisica_Estandarizada
	 AS (
		SELECT	dir.Cod_DW_Reporte_Ubic_Original
			,dir.Texto_Ubicacion_Original
			,dir.Cod_DW_Tipo_Ubicacion
			,dir.Cod_DW_Fuente
			,dir.Lote
			,dir.Id_Buro_Suscriptor
			,dir.Id_Buro_Persona
			,dir.Cod_DW_Cta
			,dir.Cod_DW_Hash
			,dir.Cod_DW_Ubic
			,dir.Valor
			,dir.Ciudad Texto_Ciudad
			,dir.Codigo_Ciudad_Dane
			,dir.Fecha_Reporte
			
			,dir.Cod_DW_Ubicacion_Original
			,dir.Cod_DW_Tipo_Ubicacion_Dir
			,dir.Usuario_BD
			
			,TRIM(CAST(CASE WHEN Est.Cod_DW_Reporte_Ubic_Original IS NULL
			 THEN dir.Texto_Ubicacion_Original
			 ELSE COALESCE( '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1), dir.Texto_Ubicacion_Original)
			END AS VARCHAR(4096))) DIRE_GEO
			,TRIM(CAST('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 2) AS VARCHAR(4096))) DIRE_COMPLEMENTO
			,TRIM(CAST('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 3) AS VARCHAR(4096))) DIR_TIPO_DIRE
			,TRIM(CAST(CASE WHEN Est.Cod_DW_Reporte_Ubic_Original IS NULL
			 THEN dir.Tipo_Direccion
			 ELSE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 4)
			END AS VARCHAR(4096))) DIR_TIPOVIA
			,TRIM(CAST('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 5) AS VARCHAR(4096))) DIR_NUMVIAPPAL
			,TRIM(CAST('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 6) AS VARCHAR(4096))) DIR_NUMVIAGEN
			,TRIM(CAST('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 7) AS VARCHAR(4096))) DIR_NUMPLACA
			,TRIM(CAST(CASE WHEN Est.Cod_DW_Reporte_Ubic_Original IS NULL
			  OR '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1) IS NULL
			  OR '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1) = ''''
			 THEN ''NO VALIDA''
			 ELSE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8)
			END AS VARCHAR(4096))) DIR_CB_VALIDA
			,TRIM(CAST(CASE WHEN Est.Cod_DW_Reporte_Ubic_Original IS NULL
			  OR '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1) IS NULL
			  OR '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1) = ''''
			 THEN dir.Texto_Ubicacion_Original || ''&&''|| dir.Tipo_Direccion ||''&&&&&NO VALIDA''
			 ELSE COALESCE(ADDR_NORM, dir.Ubicacion_Stand)
			END AS VARCHAR(4096))) Ubicacion_Stand
			,CAST('''' AS VARCHAR(20)) Reglas
		FROM	' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada dir
		LEFT JOIN ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val Est
			ON dir.Cod_DW_Reporte_Ubic_Original = Est.Cod_DW_Reporte_Ubic_Original
		QUALIFY ROW_NUMBER() OVER(PARTITION BY dir.Cod_DW_Reporte_Ubic_Original
					ORDER BY dir.Cod_DW_Reporte_Ubic_Original) = 1
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (22):. Crear y carga la tabla DireccionFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_Estand_Topo
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original )
								ON ' || P_BDSTAGE ||'.DireccionFisica_Estandarizada'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (8):. Actualizar estadisticas a la tabla DireccionFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Cursor de reglas para ETAPA IN (6)
 -- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones
 --------------------
 SET V_CADENA = '
	SELECT	Sentencia
		,Condicion
		,Flag_Recursiva
		,Cod_DW_Regla_Est_Ubica
	FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
	WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
			select Cod_DW_Atributo
			from '|| P_BDDATOS ||'.ATRIBUTO
			where Cod_DW_Tipo_Atributo in (
				select Cod_DW_Tipo_Atributo
				from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
				where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
			) AND Valor_Origen = ''Geografica''
		) AND  Flag_Activo = ''S'' AND ETAPA IN (6)
	ORDER BY Orden'; PREPARE the_statement FROM V_CADENA; OPEN cur_reglas_select; CUR3:LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; IF SQLCODE <> 0 THEN LEAVE CUR3; END IF; SET V_CADENA = '
		UPDATE '||P_BDSTAGE || '.DireccionFisica_Estandarizada
		SET ' || V_Sentencia || '
			, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
		WHERE ' || V_Condicion; CALL DBC.SysExecSQL(:V_CADENA); IF SQLCODE NOT IN (0, 7632) THEN SET V_CADENA1 = V_CADENA; SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1; LEAVE L1; END IF; END LOOP CUR3; CLOSE cur_reglas_select; END L1; END;

REPLACE PROCEDURE REC_DATOS.PRO_StandardizationGeografica_CC ( IN P_Lote INTEGER ,IN P_StartTimeStampPadre VARCHAR(20) ,IN P_Nombre_Proceso_Padre VARCHAR(30) ,IN P_BDDATOS VARCHAR(20) ,IN P_BDVISTA VARCHAR(20) ,IN P_BDSTAGE VARCHAR(20) ,OUT P_ERROR VARCHAR(32000) ) /*
 * ################################################################################
 * 
 * Objetivo:		Estandariza las direcciones fisicas como ubicacion del insumo
 *			InsumoDireccionFisica, dejando el resultado en DireccionFisica_Estandarizada
 * Fecha:		2016/11/09
 * Realizado por:	Luis E Ramirez
 * Proyecto:		Nuevo reconocer
 * Script:		PRO_StandardizationGeografica
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha		Objetivo			Realizado por
 * 
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */ BEGIN ------------------------
-- Declaracion de variables
------------------------
 DECLARE V_StartTimeStampPadre TIMESTAMP(6); DECLARE V_ERROR VARCHAR(30); DECLARE V_CADENA VARCHAR(32000); DECLARE V_CADENA1 VARCHAR(10000); DECLARE Temp CHAR(30); DECLARE V_Sentencia VARCHAR(500); DECLARE V_Condicion VARCHAR(500); DECLARE V_Flag_Recursiva VARCHAR(1); DECLARE V_COUNT INTEGER; DECLARE V_Cod_DW_Regla_Est_Ubica INTEGER; DECLARE cur_reglas_select NO SCROLL CURSOR FOR the_statement; DECLARE cur_count_rec NO SCROLL CURSOR FOR the_statement_1; L1: BEGIN SET P_ERROR = ''; SET V_StartTimeStampPadre = CAST(P_StartTimeStampPadre AS TIMESTAMP(6) FORMAT 'yyyy-mm-ddhh:mi:ss'); --SET V_StartTimeStampPadre =DATE;
 SET V_COUNT = 1; ---------------------------
-- Busca y borra si existe la tabla tmp_EmailsEstandarizados
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Estandarizada' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
-- Se crea y carga la tabla tmp_DireFisica_Estandarizada
-- Se hace la primera limpieza de caracteres especiales en la ciudad y el texto de la direccion
-----------------------------
 SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada
 AS (
SELECT	 dir.Cod_DW_Reporte_Ubic_Original
	,CASE WHEN (ACEP.Normalizado IS NOT NULL OR GEO.Cod_Dane_Ciudad  IS NOT NULL)
			THEN ' || P_BDVISTA || '.REPLEXPREG( Ubicacion_Stand_Prev, ''[^A-Z^0-9^ ^-^.]'','' '')
	      ELSE ''NO VALIDO''
	END Ubicacion_Stand
	,dir.Texto_Ubicacion_Original
	,dir.Cod_DW_Tipo_Ubicacion
	,dir.Cod_DW_Fuente
	,dir.Lote
	,dir.Id_Buro_Suscriptor
	,dir.Id_Buro_Persona
	,dir.Cod_DW_Cta
	,dir.Cod_DW_Hash
	,dir.Cod_DW_Ubic
	,dir.Valor                               
	,CASE WHEN ACEP.Normalizado IS NOT NULL
			THEN ACEP.Normalizado
	      WHEN GEO.Cod_Dane_Ciudad IS NOT NULL
	      		THEN geo.Descripcion_Ciudad
	      ELSE Texto_Ciudad_Prev
	END Ciudad
	,COALESCE(GEOC.Cod_Dane_Ciudad, dir.Codigo_Ciudad_Dane) Codigo_Ciudad_Dane 
	,dir.Fecha_Reporte
	
	,Cod_DW_Ubicacion_Original
	,Cod_DW_Tipo_Ubicacion_Dir
	,Usuario_BD
	,CAST('''' as VARCHAR(10)) Reglas
FROM (
	SELECT	a.*
		,' || P_BDVISTA || '.REPL_CHRS  (UPPER(Texto_Ubicacion_Original), ''GEO'') Ubicacion_Stand_Prev
		,' || P_BDVISTA || '.REPL_CHRS  (TRIM(' || P_BDVISTA || '.REPLEXPREG(' || P_BDVISTA || '.REPLEXPREG( UPPER(Texto_Ciudad), ''^[A-Za-z ]?$''),''[ ]{2,100}'', '' '') ), ''GEO'') Texto_Ciudad_Prev 
	FROM ' || P_BDSTAGE ||'.InsumoDireccionFisica a ) dir
LEFT JOIN (
		SELECT	DISTINCT  P.Valor
		,P.Normalizado
	FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
	INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
		ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
	INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
		ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
	INNER JOIN ' || P_BDDATOS ||'.PARAMETRO AS P
		ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
	WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
			  AND TP.Nombre_Tipo_Parametro = ''CIUDAD''
	    UNION 
    SELECT DISTINCT Descripcion_Ciudad AS VALOR, Descripcion_Ciudad AS NORMALIZADO
    FROM  ' || P_BDVISTA || '.V_Geografia
    WHERE  COD_DANE_CIUDAD LIKE ''%000''

	) ACEP
	ON dir.Texto_Ciudad_Prev = ACEP.Valor
LEFT JOIN '|| P_BDVISTA ||'.V_Geografia GEO
	ON GEO.Cod_Dane_Ciudad = dir.Codigo_Ciudad_Dane
LEFT JOIN '|| P_BDVISTA ||'.V_Geografia GEOC
	ON GEOC.Descripcion_Ciudad = ACEP.Normalizado AND GEOC.COD_DANE_CIUDAD LIKE ''%000''

) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (1):. Crear y carga la tabla tmp_DireFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a tmp_DireFisica_Estandarizada
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN(Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Actualizar estadisticas a la tabla tmp_DireFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Cursor de reglas para ETAPA IN (2)
-- Reglas de limpieza basadas en patrones de texto
--------------------
 SET V_CADENA = '
SELECT	Sentencia
	,Condicion
	,Flag_Recursiva
	,Cod_DW_Regla_Est_Ubica
FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
		select Cod_DW_Atributo
		from '|| P_BDDATOS ||'.ATRIBUTO
		where Cod_DW_Tipo_Atributo in (
			select Cod_DW_Tipo_Atributo
			from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
			where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
		) AND Valor_Origen = ''Geografica''
	) AND  Flag_Activo = ''S'' AND ETAPA IN (2)
ORDER BY Orden'; PREPARE the_statement FROM V_CADENA; OPEN cur_reglas_select; CUR1:LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; IF SQLCODE <> 0 THEN LEAVE CUR1; END IF; SET V_CADENA = '
UPDATE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
SET ' || V_Sentencia || '
	,Reglas = Reglas || '' ' || V_Cod_DW_Regla_Est_Ubica || '''
WHERE ' || V_Condicion || '
	AND Ubicacion_Stand <> ''NO VALIDO'''; CALL DBC.SysExecSQL(:V_CADENA); IF SQLCODE NOT IN (0, 7632) THEN SET V_CADENA1 = V_CADENA; SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1; LEAVE L1; END IF; END LOOP CUR1; CLOSE cur_reglas_select; ---------------------------
-- Reemplaza Toponimos
-- Busca y borra si existe la tabla tmp_DireFisica_Topo_a
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Topo_a' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo_a'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_a
 AS
(
	SELECT	a.Cod_DW_Reporte_Ubic_Original
		,CASE WHEN b.Valor IS NULL
				THEN Ubicacion_Stand
		      ELSE OREPLACE(Ubicacion_Stand, b.Valor, b.Normalizado)
		END Ubicacion_Stand
		,a.Ciudad
		,Reglas
	FROM  ( 
		select *
		from '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
		qualify row_number() over(partition by Cod_DW_Reporte_Ubic_Original
				order by Cod_DW_Reporte_Ubic_Original) = 1
		) a
	LEFT JOIN (
		SELECT   P.Valor
			,P.Normalizado
		FROM '|| P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
		    INNER JOIN '|| P_BDDATOS ||'.TIPO_PARAMETRO AS TP
		    	ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
		    INNER JOIN  '|| P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
		    	ON  TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
		    INNER JOIN '|| P_BDDATOS ||'.PARAMETRO AS P
		    	ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
		WHERE   GP.Nombre_Grupo_Parametro = ''TOPONIMOS''
				  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
                  ) b
               ON a.Ubicacion_Stand like ''%'' || b.Valor || ''%''
          WHERE a.Ubicacion_Stand <> ''NO VALIDO''
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Crea la tabla tmp_DireFisica_Topo_a' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a tmp_DireFisica_Estandarizada
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_a'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo_a' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
-- Busca y borra si existe la tabla tmp_DireFisica_Topo
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Topo' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
-- Se crea y carga la tabla tmp_DireFisica_Topo
-- Separacion del texto de la direccion en palabras
-----------------------------
 SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo
 AS (
 WITH RECURSIVE Text_Dir_Palabras
 (Cod_DW_Reporte_Ubic_Original
 ,ID_S
 ,POS
 ,PALABRA
 ,Ubicacion_Stand
 ,Ciudad
 ,Reglas
) AS
(
	SELECT Cod_DW_Reporte_Ubic_Original
		,0
		,0
		, cast('''' as varchar(100))
		,Ubicacion_Stand  
		,Ciudad
		,Reglas
	from '||P_BDSTAGE || '.tmp_DireFisica_Topo_a
	UNION ALL
	SELECT Cod_DW_Reporte_Ubic_Original
		,ID_S+1
		,CASE WHEN POSITION('' '' IN Ubicacion_Stand) > 0
				THEN POSITION('' '' IN Ubicacion_Stand)
		     ELSE CHARACTER_LENGTH(Ubicacion_Stand)
		END POS1
		,TRIM(BOTH '' '' FROM SUBSTR(Ubicacion_Stand, 0, POS1+1))
		,TRIM(SUBSTR(Ubicacion_Stand, POS1+1))
		,Ciudad
		,Reglas
	FROM Text_Dir_Palabras
	WHERE POS1 > 0
)
SELECT Cod_DW_Reporte_Ubic_Original
	,ID_S
	,PALABRA
	,Ciudad
	,Ubicacion_Stand
	,Reglas
FROM Text_Dir_Palabras
WHERE ID_S > 0

) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)'; CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (3):. Crear y carga la tabla tmp_DireFisica_Topo' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a tmp_DireFisica_Topo
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (4):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; /*

BEGIN ETAPA TOPONIMO
begin tmp_DireFisica_Topo
*/ ---------------------------
-- Busca y borra si existe la tabla tmp_DireFisica_Topo_II
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Topo_II' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo_II'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
-- Se crea y carga la tabla tmp_DireFisica_Topo_II
-- Se aplican acepciones y no existe, se llama la funcion GENACCEPAUT para
--  intentar crearla
-----------------------------
 SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II
 AS (
SELECT	A.Cod_DW_Reporte_Ubic_Original
	,A.ID_S
	,CASE WHEN ACEP.Valor IS NULL
			AND ' || P_BDVISTA || '.VALIDATE_EXPRESSION_R(A.PALABRA, ''^[A-Za-z]{3,20}*$'')=1
			AND A.PALABRA IS NOT NULL
			AND ACEP.Valor IS NULL
		THEN ' || P_BDVISTA || '.GENACCEPAUT(A.PALABRA, SOUNDEX(A.PALABRA))
	END NEW_ACEPCION
	,CASE WHEN ACEP.Valor IS NOT NULL
		THEN ACEP.Normalizado
	      WHEN NEW_ACEPCION IS NOT NULL AND CHAR(NEW_ACEPCION) <> 0
	      	THEN NEW_ACEPCION
	      ELSE A.PALABRA
	END PALABRA
	,A.Ubicacion_Stand
	,A.PALABRA PALABRA_ORI
	,A.Ciudad
	,a.Reglas
FROM ' || P_BDSTAGE ||'.tmp_DireFisica_Topo A
LEFT JOIN (
	SELECT	P.Valor
		,P.Normalizado
	FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
	INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
		ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
	INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
		ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
	INNER JOIN ' || P_BDDATOS ||'.PARAMETRO AS P
		ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
	WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
			  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
		) ACEP
	ON A.PALABRA = ACEP.Valor
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (5):. Crear y carga la tabla tmp_DireFisica_Topo_II' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a tmp_DireFisica_Topo
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (6):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo_II' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Inserta las nuevas acepciones en parametros
--------------------
 SET V_CADENA = ''; SET V_CADENA = '
INSERT INTO ' || P_BDDATOS ||'.PARAMETRO
SELECT	P.Cod_DW_Parametro + SUM( 1 ) OVER (ROWS UNBOUNDED PRECEDING) Cod_DW_Parametro
	,A.PALABRA_ORI Valor
	,A.PALABRA Normalizado
	,'|| P_Lote || '
	,NULL
	,1
	,USER
	,STP1.Cod_DW_Subtipo_Parametro
	,NULL
	,date
FROM (SELECT *
	FROM ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II
	WHERE NEW_ACEPCION IS NOT NULL AND CHAR(NEW_ACEPCION) <> 0
	QUALIFY ROW_NUMBER() OVER(PARTITION BY PALABRA_ORI, PALABRA ORDER BY PALABRA_ORI) = 1
   ) A
CROSS JOIN (
	SELECT STP.Cod_DW_Subtipo_Parametro
	FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
	INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
		ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
	INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
		ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
	WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''

		  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
	) STP1
CROSS JOIN (SELECT MAX(Cod_DW_Parametro) Cod_DW_Parametro
	    FROM ' || P_BDDATOS ||'.PARAMETRO
	) P
LEFT JOIN (
	SELECT    P.Valor
		,P.Normalizado
	    FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
	    INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
		ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
	    INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
		ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
	    INNER JOIN ' || P_BDDATOS ||'.PARAMETRO AS P
		ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
	    WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
		      AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
  ) EXT
	ON EXT.Valor = A.PALABRA_ORI
	AND EXT.Normalizado = A.PALABRA
WHERE EXT.Valor IS NULL'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (7):. Inserta las nuevas acepciones en PARAMETRO' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a paramtros
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Parametro) ON ' || P_BDDATOS ||'.PARAMETRO'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (8):. Actualizar estadisticas a la tabla PARAMETRO' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; /*end tmp_DireFisica_Topo_II
*/ /*
END ETAPA TOPONIMO
*/ ---------------------------
-- Busca y borra si existe la tabla tmp_DireFisica_TopoUpd
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_TopoUpd' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
-- Se crea y carga la tabla tmp_DireFisica_TopoUpd
-- Rearma la direccion
-----------------------------
 SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_TopoUpd
 AS (
 WITH RECURSIVE Text_Dir_PalabrasT
 (Cod_DW_Reporte_Ubic_Original
 ,ID_S
 ,PALABRA
 ,Ubicacion_Stand
 ,Ciudad
 ,UltRegla
 ,Reglas
) AS
(
	SELECT Cod_DW_Reporte_Ubic_Original
		,ID_S
		,PALABRA
		,CAST(PALABRA AS VARCHAR(500)) Ubicacion_Stand     
		,Ciudad
		,CAST('''' AS VARCHAR(50)) as UltRegla
		,Reglas
	from '||P_BDSTAGE || '.tmp_DireFisica_Topo_II
	QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
					ORDER BY ID_S ASC) = 1
	UNION ALL
	SELECT A.Cod_DW_Reporte_Ubic_Original
		,B.ID_S
		,B.PALABRA
		,A.Ubicacion_Stand || '' '' || B.PALABRA
		,B.Ciudad
		,CAST('''' AS VARCHAR(50)) as UltRegla
		,B.Reglas
	FROM '||P_BDSTAGE || '.tmp_DireFisica_Topo_II B
	INNER JOIN Text_Dir_PalabrasT A
		ON A.Cod_DW_Reporte_Ubic_Original = B.Cod_DW_Reporte_Ubic_Original
		AND (A.ID_S + 1) = B.ID_S
	WHERE B.ID_S IS NOT NULL
)
SELECT Cod_DW_Reporte_Ubic_Original
	,Ubicacion_Stand
	,Ciudad
	,UltRegla
	,Reglas
FROM Text_Dir_PalabrasT
QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
				ORDER BY ID_S DESC, Ubicacion_Stand DESC) = 1

) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (9):. Crear y carga la tabla tmp_DireFisica_TopoUpd' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a tmp_DireFisica_TopoUpd
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN (Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_DireFisica_TopoUpd'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (10):. Actualizar estadisticas a la tabla tmp_DireFisica_TopoUpd' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Cursor de reglas para ETAPA IN (5)
-- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones
--------------------
 SET V_CADENA = '
SELECT	Sentencia
	,Condicion
	,Flag_Recursiva
	,Cod_DW_Regla_Est_Ubica
	
FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
		select Cod_DW_Atributo
		from '|| P_BDDATOS ||'.ATRIBUTO
		where Cod_DW_Tipo_Atributo in (
			select Cod_DW_Tipo_Atributo
			from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
			where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
		) AND Valor_Origen = ''Geografica''
	) AND  Flag_Activo = ''S'' AND ETAPA IN (5)
ORDER BY Orden'; PREPARE the_statement FROM V_CADENA; OPEN cur_reglas_select; CUR2:LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; IF SQLCODE <> 0 THEN LEAVE CUR2; END IF; SET V_CADENA = '
UPDATE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
SET ' || V_Sentencia || ', UltRegla = UltRegla || + ' || V_Cod_DW_Regla_Est_Ubica || ' 
	,Reglas = Reglas ||' '' || V_Cod_DW_Regla_Est_Ubica || '''
WHERE ' || V_Condicion || '
	AND Ubicacion_Stand <> ''NO VALIDO'''; CALL DBC.SysExecSQL(:V_CADENA); IF SQLCODE NOT IN (0, 7632) THEN SET V_CADENA1 = V_CADENA; SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1; LEAVE L1; END IF; END LOOP CUR2; CLOSE cur_reglas_select; ---------------------------
-- Se ordenan las particulas en formato DANE con la funcion ADDRESS_NORMALIZATION
-- esta funcion develve una serie de campos donde el ultimo se emplea para tipificar
-- la direccion  como valida, invalida 
--
--
-- Busca y borra si existe la tabla tmp_DireFisica_Nor
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Nor' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Nor'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Nor
 AS
(
	SELECT	Cod_DW_Reporte_Ubic_Original
		,Ubicacion_Stand
		,'|| P_BDVISTA ||'.ADDRESS_NORMALIZATION(Ubicacion_Stand, Ciudad, 300) ADDR_NORM
		,Ciudad
		,Reglas
	FROM '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; END IF; END IF; END IF; END IF; --------------------
-- Actualiza estadisticas a tmp_DireFisica_Nor
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Nor'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (12):. Actualizar estadisticas a la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
-- Genera posibles direcciones para las direcciones marcadas como "X VALIDAR VIAS" y "NO VALIDA" 
--
-- Busca y borra si existe la tabla tmp_Direcc_No_Validas
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Direcc_No_Validas' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Direcc_No_Validas'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas
 AS
(
	SELECT	Cod_DW_Reporte_Ubic_Original
		,Ubicacion_Stand
		,Reglas
	FROM '||P_BDSTAGE || '.tmp_DireFisica_Nor
	WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''NO VALIDA''
		OR Ubicacion_Stand = ''NO VALIDO''
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (13):. Crea la tabla tmp_Direcc_No_Validas' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
-- Procesa las direcciones marcadas como "X VALIDAR VIAS" y genera un registro por cada una 
--
-- Busca y borra si existe la tabla tmp_Direcc_X_Validar_Vias
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Direcc_X_Validar_Vias' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Direcc_X_Validar_Vias'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias
 AS
(
WITH RECURSIVE New_Direc
 (Cod_DW_Reporte_Ubic_Original
 ,ID_S
 ,Direc_New
 ,Dir
 ,Ubicacion_Stand
 ,Reglas
) AS
(
	SELECT Cod_DW_Reporte_Ubic_Original
		,0 ID_S
		, CAST(NULL AS VARCHAR(100))Direc_New
		, '|| P_BDVISTA ||'.DESC_ADDRESS_MORE_ADDRESS(Ubicacion_Stand, Ciudad, 300) Dir
		, Ubicacion_Stand
		,Reglas
	from '||P_BDSTAGE || '.tmp_DireFisica_Nor
	WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''X VALIDAR VIAS''
	UNION ALL
	SELECT Cod_DW_Reporte_Ubic_Original
		,ID_S+1 ID_S1
		,'|| P_BDVISTA ||'.eListGetValByIdx(DIR, ''/'', ID_S1) Direc_New1
		, DIR
		,Ubicacion_Stand
		,Reglas
	FROM New_Direc
	WHERE Direc_New1 is not null
)
SELECT	Cod_DW_Reporte_Ubic_Original
	,ID_S
	,Ubicacion_Stand
	,Direc_New
FROM New_Direc
WHERE Direc_New is not null


) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (14):. Crea la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (14):. Crea la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (14):. Crea la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; LEAVE L1; END IF; END IF; --------------------
-- Actualiza estadisticas a tmp_Direcc_X_Validar_Vias
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (15):. Actualizar estadisticas a la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
-- Marca si alguna de la direcciones puede ser tenia como valida 
--
-- Busca y borra si existe la tabla tmp_DirVal_X_Validar_Vias
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DirVal_X_Validar_Vias' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DirVal_X_Validar_Vias'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias
 AS
(
SELECT	Dir.Cod_DW_Reporte_Ubic_Original
	,Dir.Ubicacion_Stand
	,Dir.Direc_New
	,CASE WHEN (VUE.Flag_Geo IS NOT NULL
				AND VUE.Flag_Geo = ''S''
				AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) <> ''''
				AND VDF.Cod_DW_Ubic IS NOT NULL)
			AND VRPU.Cod_DW_Ubic IS NOT NULL
		   THEN 1
	       WHEN (VUE.Flag_Geo IS NOT NULL
				AND VUE.Flag_Geo = ''S''
				AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) <> ''''
				AND VDF.Cod_DW_Ubic IS NOT NULL)
			OR VRPU.Cod_DW_Ubic IS NOT NULL
		   THEN 2
	       ELSE 3
	 END Ind_Val
	 ,Dir.Reglas

FROM	' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias Dir
INNER JOIN ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada TMP
	ON TMP.Cod_DW_Reporte_Ubic_Original = Dir.Cod_DW_Reporte_Ubic_Original
LEFT JOIN ' || P_BDVISTA || '.V_Ubicacion_Estandarizada VUE
	ON TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 1)) = VUE.Texto_Ubicacion
	AND TMP.Cod_DW_Tipo_Ubicacion = VUE.Cod_Dw_Tipo_Ubicacion 
LEFT JOIN ' || P_BDVISTA || '.V_DIRECCION_FISICA VDF
	ON VUE.Cod_DW_Ubic = VDF.Cod_DW_Ubic
	AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) = VDF.Complemento
LEFT JOIN ' || P_BDVISTA || '.V_RELACION_PERSONA_UBICACION VRPU
	ON VUE.Cod_DW_Ubic = COALESCE(VRPU.Cod_DW_Ubic, -1)
	
QUALIFY ROW_NUMBER() OVER(PARTITION BY Dir.Cod_DW_Reporte_Ubic_Original, Dir.Direc_New
			ORDER BY Dir.Cod_DW_Reporte_Ubic_Original) = 1

) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (16):. Crea la tabla tmp_DirVal_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a tmp_Direcc_No_Validas
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (17):. Actualizar estadisticas a la tabla tmp_DirVal_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Completa las direcciones no validas en tmp_Direcc_No_Validas con las direcciones que no se pudieron clasificar
--------------------
 SET V_CADENA = ''; SET V_CADENA = '
INSERT INTO ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas
SELECT	DISTINCT
	Cod_DW_Reporte_Ubic_Original
	,Ubicacion_Stand
FROM	' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias A
WHERE Ind_Val = 3
	AND NOT EXISTS (
		SELECT 1
		FROM ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias B
		WHERE A.Cod_DW_Reporte_Ubic_Original = B.Cod_DW_Reporte_Ubic_Original
		AND B.Ind_Val in (1,2)
	)
'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (18):. Completa direcciones invalidas en tmp_Direcc_No_Validas' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a tmp_Direcc_No_Validas
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (19):. Actualizar estadisticas a la tabla tmp_Direcc_No_Validas' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Une todas las direcciones validas en tmp_Dire_Estan_Val
 -- Busca y borra si existe la tabla tmp_Dire_Estan_Val
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Dire_Estan_Val' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Dire_Estan_Val'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val
 AS (
	SELECT	Cod_DW_Reporte_Ubic_Original
		,ADDR_NORM
		,Reglas
	FROM '||P_BDSTAGE || '.tmp_DireFisica_Nor
	WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''VALIDA''
	UNION ALL
	SELECT	Cod_DW_Reporte_Ubic_Original
		,Direc_New
		,Reglas
	FROM '||P_BDSTAGE || '.tmp_DirVal_X_Validar_Vias
	WHERE Ind_Val < 3
	QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
					ORDER BY Ind_Val) = 1
	
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (20):. Crea la tabla tmp_Dire_Estan_Val' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a tmp_Dire_Estan_Val
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (21):. Actualizar estadisticas a la tabla tmp_Dire_Estan_Val' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
-- Busca y borra si existe la tabla DireccionFisica_Estandarizada
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'DireccionFisica_Estandarizada' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.DireccionFisica_Estandarizada'; CALL DBC.SysExecSQL(:V_CADENA); END IF; --------------------
-- Unifica los datos de acuerdo Cod_DW_Reporte_Ubic_Original, el resultado en DireccionFisica_Estandarizada
-- Se normaliza y ordena el texto de la direccion con la funcion ADDRESS_NORMALIZATION
--------------------
 SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.DireccionFisica_Estandarizada
 AS (
	SELECT	dir.Cod_DW_Reporte_Ubic_Original
		,dir.Texto_Ubicacion_Original
		,dir.Cod_DW_Tipo_Ubicacion
		,dir.Cod_DW_Fuente
		,dir.Lote
		,dir.Id_Buro_Suscriptor
		,dir.Id_Buro_Persona
		,dir.Cod_DW_Cta
		,dir.Cod_DW_Hash
		,dir.Cod_DW_Ubic
		,dir.Valor
		,dir.Ciudad Texto_Ciudad
		,dir.Codigo_Ciudad_Dane
		,dir.Fecha_Reporte
		
		,dir.Cod_DW_Ubicacion_Original
		,dir.Cod_DW_Tipo_Ubicacion_Dir
		,dir.Usuario_BD
		
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1)) DIRE_GEO
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 2)) DIRE_COMPLEMENTO
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 3)) DIR_TIPO_DIRE
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 4)) DIR_TIPOVIA
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 5)) DIR_NUMVIAPPAL
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 6)) DIR_NUMVIAGEN
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 7)) DIR_NUMPLACA
		,COALESCE(ADDR_NORM, dir.Ubicacion_Stand) Ubicacion_Stand
		,Est.Reglas
	FROM	' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada dir
	LEFT JOIN ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val Est
		ON dir.Cod_DW_Reporte_Ubic_Original = Est.Cod_DW_Reporte_Ubic_Original
	QUALIFY ROW_NUMBER() OVER(PARTITION BY dir.Cod_DW_Reporte_Ubic_Original
				ORDER BY dir.Cod_DW_Reporte_Ubic_Original) = 1
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (22):. Crear y carga la tabla DireccionFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a tmp_DireFisica_Estand_Topo
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original )
					ON ' || P_BDSTAGE ||'.DireccionFisica_Estandarizada'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES (:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (8):. Actualizar estadisticas a la tabla DireccionFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Cursor de reglas para ETAPA IN (6)
-- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones
--------------------
 SET V_CADENA = '
SELECT	Sentencia
	,Condicion
	,Flag_Recursiva
	,Cod_DW_Regla_Est_Ubica
FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
		select Cod_DW_Atributo
		from '|| P_BDDATOS ||'.ATRIBUTO
		where Cod_DW_Tipo_Atributo in (
			select Cod_DW_Tipo_Atributo
			from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
			where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
		) AND Valor_Origen = ''Geografica''
	) AND  Flag_Activo = ''S'' AND ETAPA IN (6)
ORDER BY Orden'; PREPARE the_statement FROM V_CADENA; OPEN cur_reglas_select; CUR3:LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; IF SQLCODE <> 0 THEN LEAVE CUR3; END IF; SET V_CADENA = '
UPDATE '||P_BDSTAGE || '.DireccionFisica_Estandarizada
SET ' || V_Sentencia || '
	,Reglas = Reglas || ' '' || V_Cod_DW_Regla_Est_Ubica || '''
WHERE ' || V_Condicion || '
	AND Ubicacion_Stand <> ''NO VALIDO'''; CALL DBC.SysExecSQL(:V_CADENA); IF SQLCODE NOT IN (0, 7632) THEN SET V_CADENA1 = V_CADENA; SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1; LEAVE L1; END IF; END LOOP CUR3; CLOSE cur_reglas_select; END L1; END;

REPLACE PROCEDURE REC_DATOS.PRO_StandardizationGeografica_FGM(IN P_Lote INTEGER
															,IN P_StartTimeStampPadre VARCHAR(20)
															,IN P_Nombre_Proceso_Padre VARCHAR(30)
															,IN P_BDDATOS VARCHAR(20)
															,IN P_BDVISTA VARCHAR(20)
															,IN P_BDSTAGE VARCHAR(20)
															,OUT P_ERROR VARCHAR(32000) 
)/*
 * ################################################################################
 * 
 * Objetivo:		Estandariza las direcciones fisicas como ubicacion del insumo
 *			InsumoDireccionFisica, dejando el resultado en DireccionFisica_Estandarizada
 * Fecha:		2016/11/09
 * Realizado por:	Luis E Ramirez
 * Proyecto:		Nuevo reconocer
 * Script:		PRO_StandardizationGeografica BCK 12 sept antes de a?adir campo de reglas a stg
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha	Objetivo				Realizado por
 * 2017/12/28	Agregar el codigo dane hasta la tabla	aariza - Capgemini
 *		DireccionFisica_Estandarizada
 * 2018/03/06	Se agrega el campo Tipo_Direccion y
 *		se elimina el calculo del cod dane	Capgemini
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */
 
BEGIN
------------------------
-- Declaracion de variables
------------------------
	DECLARE V_StartTimeStampPadre TIMESTAMP(6);
	DECLARE V_ERROR VARCHAR(50);
	DECLARE V_CADENA VARCHAR(32000);
	DECLARE V_CADENA1 VARCHAR(10000);
	DECLARE Temp CHAR(30);
	DECLARE V_Sentencia VARCHAR(500);
	DECLARE V_Condicion VARCHAR(500);
	DECLARE V_Flag_Recursiva VARCHAR(1);
	DECLARE V_COUNT INTEGER;
	DECLARE V_Cod_DW_Regla_Est_Ubica INTEGER;
	DECLARE V_Tipo_Via BYTEINT;
	DECLARE V_Tipo_Mz BYTEINT;
	DECLARE V_Tipo_RR BYTEINT;
	DECLARE V_General BYTEINT;
	DECLARE V_Contador Integer;
	
	DECLARE cur_reglas_select NO SCROLL CURSOR FOR the_statement;
	DECLARE cur_count_rec NO SCROLL CURSOR FOR the_statement_1;
	
	L1: BEGIN
		SET P_ERROR = '';
		SET V_StartTimeStampPadre = CAST(P_StartTimeStampPadre AS TIMESTAMP(6) FORMAT 'yyyy-mm-ddhh:mi:ss');		
		SET V_COUNT = 1;
		
		---------------------------
		-- Busca y borra si existe la tabla tmp_EmailsEstandarizados
		---------------------------
		SELECT TABLENAME INTO :Temp
		FROM dbc.tables
		WHERE databasename =:P_BDSTAGE
			AND TABLENAME = 'tmp_DireFisica_Estandarizada' ;
			
		IF ACTIVITY_COUNT > 0 THEN
			SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada';
			CALL DBC.SysExecSQL(:V_CADENA);
		END IF;
		
		-----------------------------
		-- Se crea y carga la tabla tmp_DireFisica_Estandarizada
		-- Se hace la primera limpieza de caracteres especiales en la ciudad y el texto de la direccion
		-----------------------------
 
		SET V_CADENA = '';
		SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada
						 AS 
						(SELECT dir.Cod_DW_Reporte_Ubic_Original
							   ,' || P_BDVISTA || '.REPLEXPREG( Ubicacion_Stand_Prev, ''[^A-Z^0-9^ ^-^. ' || 'D1'XC'F1'XC || ']'','' '')  Ubicacion_Stand
								,dir.Texto_Ubicacion_Original
								,dir.Cod_DW_Tipo_Ubicacion
								,dir.Cod_DW_Fuente
								,dir.Lote
								,dir.Id_Buro_Suscriptor
								,dir.Id_Buro_Persona
								,dir.Cod_DW_Cta
								,dir.Cod_DW_Hash
								,dir.Cod_DW_Ubic
								,dir.Valor                               
								,GEO.Descripcion_Ciudad Ciudad
								,dir.Codigo_Ciudad_Dane 
								,dir.Fecha_Reporte							
								,Cod_DW_Ubicacion_Original
								,Cod_DW_Tipo_Ubicacion_Dir
								,Usuario_BD
								,COALESCE(cast(NULL as varchar(20) ), '''') Reglas
								,dir.Tipo_Direccion
						FROM (SELECT	a.*
										,' || P_BDVISTA || '.REPL_CHRS  (UPPER(Texto_Ubicacion_Original), ''GEO'') Ubicacion_Stand_Prev
										,' || P_BDVISTA || '.REPL_CHRS  (TRIM(' || P_BDVISTA || '.REPLEXPREG(' || P_BDVISTA || '.REPLEXPREG( UPPER(Texto_Ciudad), ''^[A-Za-z ]?$''),''[ ]{2,100}'', '' '') ), ''GEO'') Texto_Ciudad_Prev 
							  FROM ' || P_BDSTAGE ||'.InsumoDireccionFisica a sample 100) dir
						LEFT JOIN '|| P_BDVISTA ||'.V_Geografia GEO
						ON GEO.Cod_Dane_Ciudad = dir.Codigo_Ciudad_Dane
						) WITH DATA
						PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';

		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
										,V_StartTimeStampPadre
										,:P_Nombre_Proceso_Padre
										,:V_CADENA
										,'PRO_StandardizationGeografica (1):. Crear y carga la tabla tmp_DireFisica_Estandarizada' 
										,V_ERROR);
		SET P_ERROR = V_ERROR;
		
		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF;
		
		--------------------
		-- Actualiza estadisticas a tmp_DireFisica_Estandarizada
		--------------------
		
		SET V_CADENA = '';
		SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN(Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada';
		
		--------------------
		-- Ejecuta cadena
		--------------------
		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
										,V_StartTimeStampPadre
										,:P_Nombre_Proceso_Padre
										,:V_CADENA
										,'PRO_StandardizationGeografica (2):. Actualizar estadisticas a la tabla tmp_DireFisica_Estandarizada'
										,V_ERROR);
					
		SET P_ERROR = V_ERROR;
		
		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF;
		
		--------------------------------------------------------------------------------
		-- Cursor de reglas para ETAPA IN (2)
		-- Reglas de limpieza basadas en patrones de texto General
		--------------------------------------------------------------------------------
		SET V_CADENA = 'SELECT	 Sentencia
								,Condicion
								,Flag_Recursiva
								,Cod_DW_Regla_Est_Ubica								
						FROM  '|| P_BDDATOS ||'.REGLA_EST_UBICACION
						WHERE Flag_Activo = ''S''
						AND General = 1
						AND ETAPA IN (2)
						AND Cod_DW_Tipo_Ubicacion_Dir IN ( Select Cod_DW_Atributo
															  From '|| P_BDDATOS ||'.ATRIBUTO
															  Where Valor_Origen = ''Geografica''									  
															  And Cod_DW_Tipo_Atributo in (Select Cod_DW_Tipo_Atributo
																							From '|| P_BDDATOS ||'.TIPO_ATRIBUTO
																							Where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion'')
													)
															 
						ORDER BY Orden';
		
		PREPARE the_statement FROM V_CADENA;		
		
		SET V_Contador = 0; 
		
		OPEN cur_reglas_select;
		
		 CUR1:LOOP
		 
			FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica;
			
			IF SQLCODE <> 0 THEN 
				LEAVE CUR1;
			END IF;
           
            SET V_Contador = V_Contador +1;
            
			SET V_CADENA =  'UPDATE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
							 SET ' || V_Sentencia || '
								 ,Reglas = Reglas || '' - ' || Trim(V_Cod_DW_Regla_Est_Ubica)|| '''
							 WHERE ' || V_Condicion;			
			
			
				
			CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
											,V_StartTimeStampPadre 
											,:P_Nombre_Proceso_Padre 
											,:V_CADENA 
											,'PRO_StandardizationGeografica (2.1):'||' Ejecucion de reglas de tipo Generales iteracion: '||trim(V_Contador)||' Regla:'||trim(V_Cod_DW_Regla_Est_Ubica) 
											,V_ERROR);
						
			
			IF SQLCODE NOT IN (0, 7632) THEN
				SET V_CADENA1 = V_CADENA;
				SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1;
				LEAVE L1;
			END IF;		
			
		END LOOP CUR1;
		
		CLOSE cur_reglas_select; 
		
		
		--------------------------------------------------------------------------------
		-- Cursor de reglas para ETAPA IN (2)
		-- Reglas de limpieza basadas en patrones de texto que aplican para dircciones tipo via
		--------------------------------------------------------------------------------
		SET V_CADENA = 'SELECT	 Sentencia
								,Condicion
								,Flag_Recursiva
								,Cod_DW_Regla_Est_Ubica								
						FROM  '|| P_BDDATOS ||'.REGLA_EST_UBICACION
						WHERE Cod_DW_Tipo_Ubicacion_Dir IN ( Select Cod_DW_Atributo
															  From '|| P_BDDATOS ||'.ATRIBUTO
															  Where Valor_Origen = ''Geografica''									  
															  And Cod_DW_Tipo_Atributo in (Select Cod_DW_Tipo_Atributo
																							From '|| P_BDDATOS ||'.TIPO_ATRIBUTO
																							Where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion'')
															 )
						AND Flag_Activo = ''S''
						AND Tipo_Via = 1
						AND ETAPA IN (2)
						ORDER BY Orden';
						
		SET V_Contador = 0; 
		
		PREPARE the_statement FROM V_CADENA;		
		
		OPEN cur_reglas_select;
		
		 CUR2:LOOP
		 
			FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica;
			
			IF SQLCODE <> 0 THEN 
				LEAVE CUR2;
			END IF;
			
			SET V_Contador = V_Contador +1;
           
			SET V_CADENA =  'UPDATE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
							 SET ' || V_Sentencia || '
								 ,Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
							 WHERE ' || V_Condicion;			
					
			
			CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
											,V_StartTimeStampPadre 
											,:P_Nombre_Proceso_Padre 
											,:V_CADENA 
											,'PRO_StandardizationGeografica (2.1):'||' Ejecucion de reglas de tipo via iteracion: '||trim(V_Contador)||' Regla:'||trim(V_Cod_DW_Regla_Est_Ubica) 
											,V_ERROR);
			
			IF SQLCODE NOT IN (0, 7632) THEN
				SET V_CADENA1 = V_CADENA;
				SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1;
				LEAVE L1;
			END IF;		
			
		END LOOP CUR2;
		
		CLOSE cur_reglas_select; 
		
		--------------------------------------------------------------------------------
		-- Cursor de reglas para ETAPA IN (2)
		-- Reglas de limpieza basadas en patrones de texto que aplican para dircciones tipo Manzana
		--------------------------------------------------------------------------------
		SET V_CADENA = 'SELECT	 Sentencia
								,Condicion
								,Flag_Recursiva
								,Cod_DW_Regla_Est_Ubica								
						FROM  '|| P_BDDATOS ||'.REGLA_EST_UBICACION
						WHERE Cod_DW_Tipo_Ubicacion_Dir IN ( Select Cod_DW_Atributo
															  From '|| P_BDDATOS ||'.ATRIBUTO
															  Where Valor_Origen = ''Geografica''									  
															  And Cod_DW_Tipo_Atributo in (Select Cod_DW_Tipo_Atributo
																							From '|| P_BDDATOS ||'.TIPO_ATRIBUTO
																							Where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion'')
															 )
						AND Flag_Activo = ''S''
						AND Tipo_Mz = 1
						AND ETAPA IN (2)
						ORDER BY Orden';
		
		SET V_Contador = 0;
		
		PREPARE the_statement FROM V_CADENA;		
		
		OPEN cur_reglas_select;
		
		 CUR3:LOOP
		 
			FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica;
			
			IF SQLCODE <> 0 THEN 
				LEAVE CUR3;
			END IF;
			
			SET V_Contador = V_Contador +1;
           
			SET V_CADENA =  'UPDATE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
							 SET ' || V_Sentencia || '
								 ,Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
							 WHERE ' || V_Condicion;			
			
			
			CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
											,V_StartTimeStampPadre 
											,:P_Nombre_Proceso_Padre 
											,:V_CADENA 
											,'PRO_StandardizationGeografica (2.1):'||' Ejecucion de reglas de tipo Manzana iteracion: '||trim(V_Contador)||' Regla:'||trim(V_Cod_DW_Regla_Est_Ubica) 
											,V_ERROR);
			
			IF SQLCODE NOT IN (0, 7632) THEN
				SET V_CADENA1 = V_CADENA;
				SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1;
				LEAVE L1;
			END IF;		
			
		END LOOP CUR3;
		
		CLOSE cur_reglas_select; 
		
		--------------------------------------------------------------------------------
		-- Cursor de reglas para ETAPA IN (2)
		-- Reglas de limpieza basadas en patrones de texto que aplican para dircciones tipo Rural
		--------------------------------------------------------------------------------
		SET V_CADENA = 'SELECT	 Sentencia
								,Condicion
								,Flag_Recursiva
								,Cod_DW_Regla_Est_Ubica								
						FROM  '|| P_BDDATOS ||'.REGLA_EST_UBICACION
						WHERE Cod_DW_Tipo_Ubicacion_Dir IN ( Select Cod_DW_Atributo
															  From '|| P_BDDATOS ||'.ATRIBUTO
															  Where Valor_Origen = ''Geografica''									  
															  And Cod_DW_Tipo_Atributo in (Select Cod_DW_Tipo_Atributo
																							From '|| P_BDDATOS ||'.TIPO_ATRIBUTO
																							Where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion'')
															 )
						AND Flag_Activo = ''S''
						AND Tipo_RR = 1
						AND ETAPA IN (2)
						ORDER BY Orden';
		
		
		SET V_Contador = 0;
		
		PREPARE the_statement FROM V_CADENA;		
		
		OPEN cur_reglas_select;
		
		 CUR4:LOOP
		 
			FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica;
			
			IF SQLCODE <> 0 THEN 
				LEAVE CUR4;
			END IF;
						
			SET V_Contador = V_Contador +1;
           
			SET V_CADENA =  'UPDATE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
							 SET ' || V_Sentencia || '
								 ,Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
							 WHERE ' || V_Condicion;			
			
			
			CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
											,V_StartTimeStampPadre 
											,:P_Nombre_Proceso_Padre 
											,:V_CADENA 
											,'PRO_StandardizationGeografica (2.1):'||' Ejecucion de reglas de Rural iteracion: '||trim(V_Contador)||' Regla:'||trim(V_Cod_DW_Regla_Est_Ubica) 
											,V_ERROR);
			
			IF SQLCODE NOT IN (0, 7632) THEN
				SET V_CADENA1 = V_CADENA;
				SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1;
				LEAVE L1;
			END IF;		
			
		END LOOP CUR4;
		
		CLOSE cur_reglas_select; 
				
		---------------------------------------------------------------------------------
		-- Reemplaza Toponimos
		-- Busca y borra si existe la tabla tmp_DireFisica_Topo_a
		---------------------------------------------------------------------------------
		
		SELECT TABLENAME INTO :Temp
		FROM dbc.tables
		WHERE databasename =:P_BDSTAGE
		AND TABLENAME = 'tmp_DireFisica_Topo_a' ;
			
		IF ACTIVITY_COUNT > 0 THEN
			SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo_a';
			CALL DBC.SysExecSQL(:V_CADENA);
		END IF;
		
		SET V_CADENA = ''; 
		
		SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_a
						 AS
						(SELECT	a.Cod_DW_Reporte_Ubic_Original
								,CASE WHEN b.Valor IS NULL
										THEN Ubicacion_Stand
									  ELSE OREPLACE(Ubicacion_Stand, b.Valor, b.Normalizado)
								END Ubicacion_Stand
								,a.Ciudad
								,a.Codigo_Ciudad_Dane
								,a.Tipo_Direccion
							FROM  (Select *	from '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
								   qualify row_number() over(partition by Cod_DW_Reporte_Ubic_Original
									order by Cod_DW_Reporte_Ubic_Original) = 1 ) a
							LEFT JOIN ( SELECT   P.Valor
												,P.Normalizado
										FROM '|| P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
										INNER JOIN '|| P_BDDATOS ||'.TIPO_PARAMETRO AS TP
										ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
										INNER JOIN  '|| P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
										ON  TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
										INNER JOIN '|| P_BDDATOS ||'.PARAMETRO AS P
										ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
										WHERE GP.Nombre_Grupo_Parametro = ''TOPONIMOS''
										AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
									    ) b
						    ON a.Ubicacion_Stand like ''%'' || b.Valor || ''%''							
						) WITH DATA
						PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';

		--------------------------------------------------------------------------------
		-- Ejecuta cadena
		--------------------------------------------------------------------------------
		
		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
										,V_StartTimeStampPadre 
										,:P_Nombre_Proceso_Padre 
										,:V_CADENA 
										,'PRO_StandardizationGeografica (2):. Crea la tabla tmp_DireFisica_Topo_a' 
										,V_ERROR);
					
		SET P_ERROR = V_ERROR;
		
		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF; 
		
		--------------------
		-- Actualiza estadisticas a tmp_DireFisica_Estandarizada
		--------------------
		SET V_CADENA = '';
		SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_a'; 
		
		--------------------------------------------------------------------------------
		-- Ejecuta cadena
		--------------------------------------------------------------------------------
		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
										,V_StartTimeStampPadre 
										,:P_Nombre_Proceso_Padre 
										,:V_CADENA 
										,'PRO_StandardizationGeografica (2):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo_a' 
										,V_ERROR);
					
		SET P_ERROR = V_ERROR; 
		
		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF; 
		
		-----------------------------------------------------------------------------------
		-- Busca y borra si existe la tabla tmp_DireFisica_Topo
		-----------------------------------------------------------------------------------
		
		SELECT TABLENAME INTO :Temp 
		FROM dbc.tables 
		WHERE databasename =:P_BDSTAGE
		AND TABLENAME = 'tmp_DireFisica_Topo' ;
			
		IF ACTIVITY_COUNT > 0 THEN
			SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo'; 
			CALL DBC.SysExecSQL(:V_CADENA);
		END IF; 
		
		-------------------------------------------------------------------------------------
		-- Se crea y carga la tabla tmp_DireFisica_Topo
		-- Separacion del texto de la direccion en palabras
		-------------------------------------------------------------------------------------
		SET V_CADENA = '';
		
		SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo
                       AS ( WITH RECURSIVE Text_Dir_Palabras
							 (Cod_DW_Reporte_Ubic_Original
							 ,ID_S
							 ,POS
							 ,PALABRA
							 ,Ubicacion_Stand
							 ,Ciudad
							 ,Codigo_Ciudad_Dane
							 ,Tipo_Direccion
							) AS
							(SELECT Cod_DW_Reporte_Ubic_Original
									,0
									,0
									, cast('''' as varchar(100))
									,Ubicacion_Stand  
									,Ciudad
									,Codigo_Ciudad_Dane
									,Tipo_Direccion
								from '||P_BDSTAGE || '.tmp_DireFisica_Topo_a
								UNION ALL
								SELECT Cod_DW_Reporte_Ubic_Original
									,ID_S+1
									,CASE WHEN POSITION('' '' IN Ubicacion_Stand) > 0
											THEN POSITION('' '' IN Ubicacion_Stand)
										 ELSE CHARACTER_LENGTH(Ubicacion_Stand)
									END POS1
									,TRIM(BOTH '' '' FROM SUBSTR(Ubicacion_Stand, 0, POS1+1))
									,TRIM(SUBSTR(Ubicacion_Stand, POS1+1))
									,Ciudad
									,Codigo_Ciudad_Dane
									,Tipo_Direccion
								FROM Text_Dir_Palabras
								WHERE POS1 > 0
							)SELECT Cod_DW_Reporte_Ubic_Original
									,ID_S
									,PALABRA
									,Ciudad
									,Codigo_Ciudad_Dane
									,Ubicacion_Stand
									,Tipo_Direccion
							FROM Text_Dir_Palabras
							WHERE ID_S > 0
							) WITH DATA
							PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)';

		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
										,V_StartTimeStampPadre 
										,:P_Nombre_Proceso_Padre 
										,:V_CADENA 
										,'PRO_StandardizationGeografica (3):. Crear y carga la tabla tmp_DireFisica_Topo' 
										,V_ERROR); 
					
		SET P_ERROR = V_ERROR;
		
		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
			LEAVE L1; 
		END IF; 
		
		----------------------------------------------------------------------------------
		-- Actualiza estadisticas a tmp_DireFisica_Topo
		----------------------------------------------------------------------------------
		SET V_CADENA = ''; 
		SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo';
		
		----------------------------------------------------------------------------------
		-- Ejecuta cadena
		----------------------------------------------------------------------------------
		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
										,V_StartTimeStampPadre 
										,:P_Nombre_Proceso_Padre 
										,:V_CADENA 
										,'PRO_StandardizationGeografica (4):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo' 
										,V_ERROR);
					
		SET P_ERROR = V_ERROR;
		
		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF;
		
		 ----------------------------------------------------------------------------------
		 -- Busca y borra si existe la tabla tmp_DireFisica_Topo_II
		 ----------------------------------------------------------------------------------
		 SELECT TABLENAME INTO :Temp
		 FROM dbc.tables
		 WHERE databasename =:P_BDSTAGE
		 AND TABLENAME = 'tmp_DireFisica_Topo_II' ;
		 	
		 IF ACTIVITY_COUNT > 0 THEN
		 	SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo_II';
		 	CALL DBC.SysExecSQL(:V_CADENA);
		 END IF;
		 
		 ----------------------------------------------------------------------------------
		 -- Se crea y carga la tabla tmp_DireFisica_Topo_II
		 -- Se aplican acepciones y no existe, se llama la funcion GENACCEPAUT para
		 --  intentar crearla
		 ----------------------------------------------------------------------------------
		 
		 SET V_CADENA = '';
		 SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II
						 AS (
						SELECT	A.Cod_DW_Reporte_Ubic_Original
							,A.ID_S
							,CASE WHEN ACEP.Valor IS NULL
									AND ' || P_BDVISTA || '.VALIDATE_EXPRESSION_R(A.PALABRA, ''^[A-Za-z]{3,20}*$'')=1
									AND A.PALABRA IS NOT NULL
									AND ACEP.Valor IS NULL
								THEN ' || P_BDVISTA || '.GENACCEPAUT(A.PALABRA, SOUNDEX(A.PALABRA))
							END NEW_ACEPCION
							,CASE WHEN ACEP.Valor IS NOT NULL
								THEN ACEP.Normalizado
								  WHEN NEW_ACEPCION IS NOT NULL AND CHAR(NEW_ACEPCION) <> 0
									THEN NEW_ACEPCION
								  ELSE A.PALABRA
							END PALABRA
							,A.Ubicacion_Stand
							,A.PALABRA PALABRA_ORI
							,A.Ciudad
							,A.Codigo_Ciudad_Dane
							,A.Tipo_Direccion
						FROM ' || P_BDSTAGE ||'.tmp_DireFisica_Topo A
						LEFT JOIN (
							SELECT	P.Valor
								,P.Normalizado
							FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
							INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
								ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
							INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
								ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
							INNER JOIN ' || P_BDDATOS ||'.PARAMETRO AS P
								ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
							WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
									  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
								) ACEP
							ON A.PALABRA = ACEP.Valor
						) WITH DATA
						PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)';

		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (5):. Crear y carga la tabla tmp_DireFisica_Topo_II' ,V_ERROR);
		SET P_ERROR = V_ERROR;
		
		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF;
		
		 ----------------------------------------------------------------------------------
		 -- Actualiza estadisticas a tmp_DireFisica_Topo
		 ----------------------------------------------------------------------------------
		 SET V_CADENA = '';
		 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II';
		 
		 ----------------------------------------------------------------------------------
		 -- Ejecuta cadena
		 ----------------------------------------------------------------------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (6):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo_II' ,V_ERROR);
		 SET P_ERROR = V_ERROR;
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
		 	LEAVE L1; 
		 END IF;
		 
		 ----------------------------------------------------------------------------------
		 -- Inserta las nuevas acepciones en parametros
		 ----------------------------------------------------------------------------------
		 SET V_CADENA = '';
		 SET V_CADENA = 'INSERT INTO ' || P_BDDATOS ||'.PARAMETRO
						SELECT	P.Cod_DW_Parametro + SUM( 1 ) OVER (ROWS UNBOUNDED PRECEDING) Cod_DW_Parametro
							,A.PALABRA_ORI Valor
							,A.PALABRA Normalizado
							,'|| P_Lote || '
							,NULL
							,1
							,USER
							,STP1.Cod_DW_Subtipo_Parametro
							,NULL
							,date
						FROM (SELECT *
							FROM ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II
							WHERE NEW_ACEPCION IS NOT NULL AND CHAR(NEW_ACEPCION) <> 0
							QUALIFY ROW_NUMBER() OVER(PARTITION BY PALABRA_ORI, PALABRA ORDER BY PALABRA_ORI) = 1
						   ) A
						CROSS JOIN (
							SELECT STP.Cod_DW_Subtipo_Parametro
							FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
							INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
								ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
							INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
								ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
							WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''

								  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
							) STP1
						CROSS JOIN (SELECT MAX(Cod_DW_Parametro) Cod_DW_Parametro
								FROM ' || P_BDDATOS ||'.PARAMETRO
							) P
						LEFT JOIN (
							SELECT    P.Valor
								,P.Normalizado
								FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
								INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
								ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
								INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
								ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
								INNER JOIN ' || P_BDDATOS ||'.PARAMETRO AS P
								ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
								WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
									  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
						  ) EXT
							ON EXT.Valor = A.PALABRA_ORI
							AND EXT.Normalizado = A.PALABRA
						WHERE EXT.Valor IS NULL';
		----------------------------------------------------------------------------------
		 -- Ejecuta cadena
		 ----------------------------------------------------------------------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (7):. Inserta las nuevas acepciones en PARAMETRO' ,V_ERROR);
		 SET P_ERROR = V_ERROR;
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 LEAVE L1; END IF;
		 
		 ----------------------------------------------------------------------------------
		 -- Actualiza estadisticas a paramtros
		 ----------------------------------------------------------------------------------
		 SET V_CADENA = '';
		 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Parametro) ON ' || P_BDDATOS ||'.PARAMETRO';
		 
		 ----------------------------------------------------------------------------------
		 -- Ejecuta cadena
		 ----------------------------------------------------------------------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (8):. Actualizar estadisticas a la tabla PARAMETRO' ,V_ERROR);
		 SET P_ERROR = V_ERROR; 
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 	LEAVE L1; 
		 END IF;
		 
		 ----------------------------------------------------------------------------------
		 -- Busca y borra si existe la tabla tmp_DireFisica_TopoUpd
		 ----------------------------------------------------------------------------------
		 
		 SELECT TABLENAME INTO :Temp 
		 FROM dbc.tables 
		 WHERE databasename =:P_BDSTAGE
		 AND TABLENAME = 'tmp_DireFisica_TopoUpd' ;
		 	
		 IF ACTIVITY_COUNT > 0 THEN 
		 
		 	SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd'; 
		 	CALL DBC.SysExecSQL(:V_CADENA);
		 END IF;
		 ----------------------------------------------------------------------------------
		 -- Se crea y carga la tabla tmp_DireFisica_TopoUpd
		 -- Rearma la direccion
		 ----------------------------------------------------------------------------------
		 SET V_CADENA = '';
		 SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_TopoUpd
						 AS (
						 WITH RECURSIVE Text_Dir_PalabrasT
						 (Cod_DW_Reporte_Ubic_Original
						 ,ID_S
						 ,PALABRA
						 ,Ubicacion_Stand
						 ,Ciudad
						 ,Codigo_Ciudad_Dane
						 ,Reglas
						 ,Tipo_Direccion
						) AS
						(
							SELECT Cod_DW_Reporte_Ubic_Original
								,ID_S
								,PALABRA
								,CAST(PALABRA AS VARCHAR(500)) Ubicacion_Stand     
								,Ciudad
								,Codigo_Ciudad_Dane
								,CAST('''' AS VARCHAR(50)) as Reglas
								,Tipo_Direccion
							from '||P_BDSTAGE || '.tmp_DireFisica_Topo_II
							QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
											ORDER BY ID_S ASC) = 1
							UNION ALL
							SELECT A.Cod_DW_Reporte_Ubic_Original
								,B.ID_S
								,B.PALABRA
								,A.Ubicacion_Stand || '' '' || B.PALABRA
								,B.Ciudad
								,B.Codigo_Ciudad_Dane
								,CAST('''' AS VARCHAR(50)) as Reglas
								,B.Tipo_Direccion
							FROM '||P_BDSTAGE || '.tmp_DireFisica_Topo_II B
							INNER JOIN Text_Dir_PalabrasT A
								ON A.Cod_DW_Reporte_Ubic_Original = B.Cod_DW_Reporte_Ubic_Original
								AND (A.ID_S + 1) = B.ID_S
							WHERE B.ID_S IS NOT NULL
						)
						SELECT Cod_DW_Reporte_Ubic_Original
							,Ubicacion_Stand
							,Ciudad
							,Codigo_Ciudad_Dane
							,Reglas
							,Tipo_Direccion
						FROM Text_Dir_PalabrasT
						QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
										ORDER BY ID_S DESC, Ubicacion_Stand DESC) = 1

						) WITH DATA
						PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';

		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (9):. Crear y carga la tabla tmp_DireFisica_TopoUpd' ,V_ERROR);
		SET P_ERROR = V_ERROR; 
		
		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
			LEAVE L1; 
		END IF;
		
		----------------------------------------------------------------------------------
		 -- Actualiza estadisticas a tmp_DireFisica_TopoUpd
		 ----------------------------------------------------------------------------------
		 SET V_CADENA = '';
		 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN (Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_DireFisica_TopoUpd';
		 
		 --------------------
		 -- Ejecuta cadena
		 --------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (10):. Actualizar estadisticas a la tabla tmp_DireFisica_TopoUpd' ,V_ERROR);
		 
		 SET P_ERROR = V_ERROR;
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 	LEAVE L1;
		 END IF;
		 
		
		 ----------------------------------------------------------------------------------
		 -- Cursor de reglas para ETAPA IN (5)
		 -- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones (General)
		 ----------------------------------------------------------------------------------
		 SET V_CADENA = 'SELECT	Sentencia
								,Condicion
								,Flag_Recursiva
								,Cod_DW_Regla_Est_Ubica								
						FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
						WHERE Cod_DW_Tipo_Ubicacion_Dir IN (Select Cod_DW_Atributo
															From '|| P_BDDATOS ||'.ATRIBUTO
															Where Cod_DW_Tipo_Atributo in (Select Cod_DW_Tipo_Atributo
																							From '|| P_BDDATOS ||'.TIPO_ATRIBUTO
																							Where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion'')									                         
   							                                AND Valor_Origen = ''Geografica'')
						AND  Flag_Activo = ''S'' 
						AND General = 1
						AND ETAPA IN (5)
						ORDER BY Orden';
						
		SET V_Contador = 0;

		PREPARE the_statement FROM V_CADENA;
		OPEN cur_reglas_select;
		
		CUR5:LOOP
			
			FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica;
			
			IF SQLCODE <> 0 THEN 
				LEAVE CUR5;
			END IF;
			
			SET V_Contador = V_Contador +1;
			
			SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
							SET ' || V_Sentencia || '
								, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
							WHERE ' || V_Condicion ;
							
        	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
										,V_StartTimeStampPadre 
										,:P_Nombre_Proceso_Padre 
										,:V_CADENA 
										,'PRO_StandardizationGeografica (10.1):'||' Ejecucion de reglas de tipo Generales iteracion: '||trim(V_Contador)||' Regla:'||trim(V_Cod_DW_Regla_Est_Ubica) 
										,V_ERROR);   
	          
			
			IF SQLCODE NOT IN (0, 7632) THEN 
				SET V_CADENA1 = V_CADENA;
				SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1;
				LEAVE L1;
			END IF;
		END LOOP CUR5;
		CLOSE cur_reglas_select;
		
		 ----------------------------------------------------------------------------------
		 -- Cursor de reglas para ETAPA IN (5)
		 -- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones (VIA)
		 ----------------------------------------------------------------------------------
		 SET V_CADENA = 'SELECT	Sentencia
								,Condicion
								,Flag_Recursiva
								,Cod_DW_Regla_Est_Ubica								
						FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
						WHERE Cod_DW_Tipo_Ubicacion_Dir IN (Select Cod_DW_Atributo
															From '|| P_BDDATOS ||'.ATRIBUTO
															Where Cod_DW_Tipo_Atributo in (Select Cod_DW_Tipo_Atributo
																							From '|| P_BDDATOS ||'.TIPO_ATRIBUTO
																							Where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion'')									                         
   							                                AND Valor_Origen = ''Geografica'')
						AND  Flag_Activo = ''S'' 
						AND Tipo_Via = 1
						AND ETAPA IN (5)
						ORDER BY Orden';
         
        SET V_Contador =0;  

		PREPARE the_statement FROM V_CADENA;
		OPEN cur_reglas_select;
		
		CUR6:LOOP
			
			FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica;
			
			IF SQLCODE <> 0 THEN 
				LEAVE CUR6;
			END IF;
			
			SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
							SET ' || V_Sentencia || '
								, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
							WHERE ' || V_Condicion ;
							
			
			SET V_Contador = V_Contador +1;
							
        	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
										,V_StartTimeStampPadre 
										,:P_Nombre_Proceso_Padre 
										,:V_CADENA 
										,'PRO_StandardizationGeografica (10.1):'||' Ejecucion de reglas de tipo via iteracion: '||trim(V_Contador)||' Regla:'||trim(V_Cod_DW_Regla_Est_Ubica) 
										,V_ERROR); 
							
	
			CALL DBC.SysExecSQL(:V_CADENA);
			
			IF SQLCODE NOT IN (0, 7632) THEN 
				SET V_CADENA1 = V_CADENA;
				SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1;
				LEAVE L1;
			END IF;
		END LOOP CUR6;
		CLOSE cur_reglas_select;
		
		 ----------------------------------------------------------------------------------
		 -- Cursor de reglas para ETAPA IN (5)
		 -- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones (Manzana)
		 ----------------------------------------------------------------------------------
		 SET V_CADENA = 'SELECT	Sentencia
								,Condicion
								,Flag_Recursiva
								,Cod_DW_Regla_Est_Ubica								
						FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
						WHERE Cod_DW_Tipo_Ubicacion_Dir IN (Select Cod_DW_Atributo
															From '|| P_BDDATOS ||'.ATRIBUTO
															Where Cod_DW_Tipo_Atributo in (Select Cod_DW_Tipo_Atributo
																							From '|| P_BDDATOS ||'.TIPO_ATRIBUTO
																							Where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion'')									                         
   							                                AND Valor_Origen = ''Geografica'')
						AND  Flag_Activo = ''S'' 
						AND Tipo_MZ = 1
						AND ETAPA IN (5)
						ORDER BY Orden';
						
		SET V_Contador = 0;

		PREPARE the_statement FROM V_CADENA;
		OPEN cur_reglas_select;
		
		CUR7:LOOP
			
			FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica;
			
			IF SQLCODE <> 0 THEN 
				LEAVE CUR7;
			END IF;
			
			SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
							SET ' || V_Sentencia || '
								, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
							WHERE ' || V_Condicion ;
							
	
			SET V_Contador = V_Contador +1;
							
        	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
										,V_StartTimeStampPadre 
										,:P_Nombre_Proceso_Padre 
										,:V_CADENA 
										,'PRO_StandardizationGeografica (10.1):'||' Ejecucion de reglas de tipo Manzana iteracion: '||trim(V_Contador)||' Regla:'||trim(V_Cod_DW_Regla_Est_Ubica) 
										,V_ERROR); 
							
			
			IF SQLCODE NOT IN (0, 7632) THEN 
				SET V_CADENA1 = V_CADENA;
				SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1;
				LEAVE L1;
			END IF;
		END LOOP CUR7;
		CLOSE cur_reglas_select;
		
		 ----------------------------------------------------------------------------------
		 -- Cursor de reglas para ETAPA IN (5)
		 -- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones (Rural)
		 ----------------------------------------------------------------------------------
		 
		 SET V_CADENA = 'SELECT	Sentencia
								,Condicion
								,Flag_Recursiva
								,Cod_DW_Regla_Est_Ubica								
						FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
						WHERE Cod_DW_Tipo_Ubicacion_Dir IN (Select Cod_DW_Atributo
															From '|| P_BDDATOS ||'.ATRIBUTO
															Where Cod_DW_Tipo_Atributo in (Select Cod_DW_Tipo_Atributo
																							From '|| P_BDDATOS ||'.TIPO_ATRIBUTO
																							Where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion'')									                         
   							                                AND Valor_Origen = ''Geografica'')
						AND  Flag_Activo = ''S'' 
						AND Tipo_RR = 1
						AND ETAPA IN (5)
						ORDER BY Orden';
		
		SET V_Contador = 0;
							

		PREPARE the_statement FROM V_CADENA;
		OPEN cur_reglas_select;
		
		CUR8:LOOP
			
			FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica;
			
			IF SQLCODE <> 0 THEN 
				LEAVE CUR8;
			END IF;
			
			SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
							SET ' || V_Sentencia || '
								, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
							WHERE ' || V_Condicion ;
							
	        
	        
			SET V_Contador = V_Contador +1;
							
        	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
										,V_StartTimeStampPadre 
										,:P_Nombre_Proceso_Padre 
										,:V_CADENA 
										,'PRO_StandardizationGeografica (10.1):'||' Ejecucion de reglas de Rural iteracion: '||trim(V_Contador)||' Regla:'||trim(V_Cod_DW_Regla_Est_Ubica) 
										,V_ERROR); 
										
			
			IF SQLCODE NOT IN (0, 7632) THEN 
				SET V_CADENA1 = V_CADENA;
				SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1;
				LEAVE L1;
			END IF;
		END LOOP CUR8;
		CLOSE cur_reglas_select;
		
		----------------------------------------------------------------------------------
		 -- Se ordenan las particulas en formato DANE con la funcion ADDRESS_NORMALIZATION
		 -- esta funcion develve una serie de campos donde el ultimo se emplea para tipificar
		 -- la direccion  como valida, invalida 
		 --
		 --
		 -- Busca y borra si existe la tabla tmp_DireFisica_Nor
		 ----------------------------------------------------------------------------------
		 
		 SELECT TABLENAME INTO :Temp 
		 FROM dbc.tables WHERE databasename =:P_BDSTAGE 
		 AND TABLENAME = 'tmp_DireFisica_Nor' ;
		 
		 IF ACTIVITY_COUNT > 0 THEN 
		 	SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Nor';
		 	CALL DBC.SysExecSQL(:V_CADENA);
		 END IF;
		 
		 SET V_CADENA = ''; 
		 SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Nor
						 AS
						(SELECT	Cod_DW_Reporte_Ubic_Original
								,Ubicacion_Stand
								,'|| P_BDVISTA ||'.ADDRESS_NORMALIZATION(oreplace(Ubicacion_Stand,''?'', ''''), Ciudad, 300, Codigo_Ciudad_Dane, Tipo_Direccion) ADDR_NORM
								,Ciudad
								,Codigo_Ciudad_Dane
						FROM '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
						) WITH DATA
						PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';
						
		----------------------------------------------------------------------------------
		 -- Ejecuta cadena
		 ---------------------------------------------------------------------------------
		 
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR);
		 
		 SET P_ERROR = V_ERROR;
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR);
		 	SET P_ERROR = V_ERROR; 
		 	
		 	IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
		 		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR);
		 		SET P_ERROR = V_ERROR;
		 		
		 		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 			CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR);
		 			SET P_ERROR = V_ERROR;
		 			
		 			IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 				CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR);
		 				SET P_ERROR = V_ERROR;
		 				
		 				IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 					LEAVE L1; 
		 				END IF; 
		 			END IF; 
		 		END IF; 
		 	END IF; 
		 END IF;
		 
		 ----------------------------------------------------------------------------------
		 -- Actualiza estadisticas a tmp_DireFisica_Nor
		 ----------------------------------------------------------------------------------
		 SET V_CADENA = '';
		 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Nor';
		 
		 ----------------------------------------------------------------------------------
		 -- Ejecuta cadena
		 ----------------------------------------------------------------------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (12):. Actualizar estadisticas a la tabla tmp_DireFisica_Nor' ,V_ERROR);
		 
		 SET P_ERROR = V_ERROR; 
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 	LEAVE L1; 
		 END IF;
		 
		 ----------------------------------------------------------------------------------
		 -- Genera posibles direcciones para las direcciones marcadas como ""X VALIDAR VIAS"" y ""NO VALIDA"" 
		 --
		 -- Busca y borra si existe la tabla tmp_Direcc_No_Validas
		 ----------------------------------------------------------------------------------
		 
		 SELECT TABLENAME INTO :Temp 
		 FROM dbc.tables
		 WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Direcc_No_Validas' ;
		 
		 IF ACTIVITY_COUNT > 0 THEN
		 	SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Direcc_No_Validas';
		 	CALL DBC.SysExecSQL(:V_CADENA); 
		 END IF;
		 
		 SET V_CADENA = '';
		 SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas
						 AS
						(SELECT	Cod_DW_Reporte_Ubic_Original
								,Ubicacion_Stand
								,Codigo_Ciudad_Dane
						FROM '||P_BDSTAGE || '.tmp_DireFisica_Nor
						WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''NO VALIDA''
						) WITH DATA
						PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';
		 
		 ----------------------------------------------------------------------------------
		 -- Ejecuta cadena
		 ----------------------------------------------------------------------------------
		 
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (13):. Crea la tabla tmp_Direcc_No_Validas' ,V_ERROR);
		 SET P_ERROR = V_ERROR;
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
		 	LEAVE L1;
		 END IF; 
		 ----------------------------------------------------------------------------------
		 -- Procesa las direcciones marcadas como ""X VALIDAR VIAS"" y genera un registro por cada una 
		 --
		 -- Busca y borra si existe la tabla tmp_Direcc_X_Validar_Vias
		 ----------------------------------------------------------------------------------
		 
		 SELECT TABLENAME INTO :Temp
		 FROM dbc.tables WHERE databasename =:P_BDSTAGE 
		 AND TABLENAME = 'tmp_Direcc_X_Validar_Vias' ; 
		 
		 IF ACTIVITY_COUNT > 0 THEN 
		 	SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Direcc_X_Validar_Vias'; 
		 	CALL DBC.SysExecSQL(:V_CADENA); 
		 	END IF;
		 
		 SET V_CADENA = '';
		 SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias
						 AS
						(WITH RECURSIVE New_Direc
						 (Cod_DW_Reporte_Ubic_Original
						 ,ID_S
						 ,Direc_New
						 ,Dir
						 ,Ubicacion_Stand
						 ,Codigo_Ciudad_Dane
						) AS
						(SELECT Cod_DW_Reporte_Ubic_Original
								,0 ID_S
								, CAST(NULL AS VARCHAR(100))Direc_New
								, '|| P_BDVISTA ||'.DESC_ADDRESS_MORE_ADDRESS(Ubicacion_Stand, Ciudad, 300, Codigo_Ciudad_Dane) Dir
								, Ubicacion_Stand
								,Codigo_Ciudad_Dane
							from '||P_BDSTAGE || '.tmp_DireFisica_Nor
							WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''X VALIDAR VIAS''
							UNION ALL
							SELECT Cod_DW_Reporte_Ubic_Original
								,ID_S+1 ID_S1
								,'|| P_BDVISTA ||'.eListGetValByIdx(DIR, ''/'', ID_S1) Direc_New1
								, DIR
								,Ubicacion_Stand
								,Codigo_Ciudad_Dane
						FROM New_Direc
						WHERE Direc_New1 is not null
						)SELECT	Cod_DW_Reporte_Ubic_Original
							,ID_S
							,Ubicacion_Stand
							,Direc_New
							,Codigo_Ciudad_Dane
						FROM New_Direc
						WHERE Direc_New is not null
						) WITH DATA
						PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)';
		
		 ----------------------------------------------------------------------------------
		 -- Ejecuta cadena
		 ----------------------------------------------------------------------------------
		 
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (14):. Crea la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR);
		 SET P_ERROR = V_ERROR;
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
			CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (14):. Crea la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR);
			SET P_ERROR = V_ERROR;
			
			IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
				LEAVE L1; 
			END IF;
		 END IF;
		 
		 ----------------------------------------------------------------------------------
		 -- Actualiza estadisticas a tmp_Direcc_X_Validar_Vias
		 ----------------------------------------------------------------------------------
		 SET V_CADENA = '';
		 
		 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias';
		 
		 --------------------
		 -- Ejecuta cadena
		 --------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (15):. Actualizar estadisticas a la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); 
		 
		 SET P_ERROR = V_ERROR;
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
			LEAVE L1;
		 END IF;
		 
		 ----------------------------------------------------------------------------------
		 -- Marca si alguna de la direcciones puede ser tenia como valida 
		 --
		 -- Busca y borra si existe la tabla tmp_DirVal_X_Validar_Vias
		 ----------------------------------------------------------------------------------
		 SELECT TABLENAME INTO :Temp 
		 FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DirVal_X_Validar_Vias' ; 
		 
		 IF ACTIVITY_COUNT > 0 THEN
			SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DirVal_X_Validar_Vias';
			CALL DBC.SysExecSQL(:V_CADENA); 
		 END IF; 
		 
		 SET V_CADENA = ''; 
		 
		 SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias
						 AS
						(SELECT	 Dir.Cod_DW_Reporte_Ubic_Original
								,Dir.Ubicacion_Stand
								,Dir.Direc_New
								,CASE WHEN (VUE.Flag_Geo IS NOT NULL
										AND VUE.Flag_Geo = ''S''
										AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) <> ''''
										AND VDF.Cod_DW_Ubic IS NOT NULL)
									AND VRPU.Cod_DW_Ubic IS NOT NULL
								   THEN 1
								   WHEN (VUE.Flag_Geo IS NOT NULL
										AND VUE.Flag_Geo = ''S''
										AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) <> ''''
										AND VDF.Cod_DW_Ubic IS NOT NULL)
									OR VRPU.Cod_DW_Ubic IS NOT NULL
								   THEN 2
								   ELSE 3
								END Ind_Val
								,Dir.Codigo_Ciudad_Dane
						FROM	' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias Dir
						INNER JOIN ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada TMP
							ON TMP.Cod_DW_Reporte_Ubic_Original = Dir.Cod_DW_Reporte_Ubic_Original
						LEFT JOIN ' || P_BDVISTA || '.V_Ubicacion_Estandarizada VUE
							ON TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 1)) = VUE.Texto_Ubicacion
							AND TMP.Cod_DW_Tipo_Ubicacion = VUE.Cod_Dw_Tipo_Ubicacion 
						LEFT JOIN ' || P_BDVISTA || '.V_DIRECCION_FISICA VDF
							ON VUE.Cod_DW_Ubic = VDF.Cod_DW_Ubic
							AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(
						Dir.
						Direc_New, ''&'', 2)) = VDF.Complemento
						LEFT JOIN ' || P_BDVISTA || '.V_RELACION_PERSONA_UBICACION VRPU
							ON VUE.Cod_DW_Ubic = COALESCE(VRPU.Cod_DW_Ubic, -1)
							
						QUALIFY ROW_NUMBER() OVER(PARTITION BY Dir.Cod_DW_Reporte_Ubic_Original, Dir.Direc_New
									ORDER BY Dir.Cod_DW_Reporte_Ubic_Original) = 1
						) WITH DATA
						PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';
		 ----------------------------------------------------------------------------------
		 -- Ejecuta cadena
		 ----------------------------------------------------------------------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (16):. Crea la tabla tmp_DirVal_X_Validar_Vias' ,V_ERROR); 
		 SET P_ERROR = V_ERROR; 
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
			LEAVE L1;
		 END IF;
		 
		 ----------------------------------------------------------------------------------
		 -- Actualiza estadisticas a tmp_Direcc_No_Validas
		 ----------------------------------------------------------------------------------
		 SET V_CADENA = '';
		 
		 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias'; 
		 
		 ----------------------------------------------------------------------------------
		 -- Ejecuta cadena
		 ----------------------------------------------------------------------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (17):. Actualizar estadisticas a la tabla tmp_DirVal_X_Validar_Vias' ,V_ERROR);
		 
		 SET P_ERROR = V_ERROR;
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
			LEAVE L1; 
		 END IF;
		 
		 ----------------------------------------------------------------------------------
		 -- Completa las direcciones no validas en tmp_Direcc_No_Validas con las direcciones que no se pudieron clasificar
		 ----------------------------------------------------------------------------------
		 SET V_CADENA = ''; 
		 SET V_CADENA = 'INSERT INTO ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas
						 SELECT	DISTINCT Cod_DW_Reporte_Ubic_Original
								,Ubicacion_Stand
								,Codigo_Ciudad_Dane
						FROM '|| P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias A
						WHERE Ind_Val = 3
						AND NOT EXISTS (SELECT 1
										FROM ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias B
										WHERE A.Cod_DW_Reporte_Ubic_Original = B.Cod_DW_Reporte_Ubic_Original
										AND B.Ind_Val in (1,2)
									   )'; 
		
		 ----------------------------------------------------------------------------------
		 -- Ejecuta cadena
		 ----------------------------------------------------------------------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (18):. Completa direcciones invalidas en tmp_Direcc_No_Validas' ,V_ERROR);
		 SET P_ERROR = V_ERROR; 
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
			LEAVE L1;
		 END IF;
		 
		 ----------------------------------------------------------------------------------
		 -- Actualiza estadisticas a tmp_Direcc_No_Validas
		 ----------------------------------------------------------------------------------
		 SET V_CADENA = ''; 
		 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas';
		 
		 ----------------------------------------------------------------------------------
		 -- Ejecuta cadena
		 ----------------------------------------------------------------------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (19):. Actualizar estadisticas a la tabla tmp_Direcc_No_Validas' ,V_ERROR);
		 
		 SET P_ERROR = V_ERROR;
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 	LEAVE L1;
		 END IF;
		 
		 ----------------------------------------------------------------------------------
		 -- Une todas las direcciones validas en tmp_Dire_Estan_Val
		 -- Busca y borra si existe la tabla tmp_Dire_Estan_Val
		 ----------------------------------------------------------------------------------
		 SELECT TABLENAME INTO :Temp 
		 FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Dire_Estan_Val' ;
		 
		 IF ACTIVITY_COUNT > 0 THEN
		 	SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Dire_Estan_Val'; 
		 	CALL DBC.SysExecSQL(:V_CADENA);
		 END IF; 
		 
		 SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val
						 AS (
							SELECT	Cod_DW_Reporte_Ubic_Original
								,ADDR_NORM
								,Codigo_Ciudad_Dane
							FROM '||P_BDSTAGE || '.tmp_DireFisica_Nor
							WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''VALIDA''
							UNION ALL
							SELECT	Cod_DW_Reporte_Ubic_Original
								,Direc_New
								,Codigo_Ciudad_Dane
							FROM '||P_BDSTAGE || '.tmp_DirVal_X_Validar_Vias
							WHERE Ind_Val < 3
							QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
											ORDER BY Ind_Val) = 1
							
						) WITH DATA
						PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';
		 ----------------------------------------------------------------------------------
		 -- Ejecuta cadena
		 ----------------------------------------------------------------------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (20):. Crea la tabla tmp_Dire_Estan_Val' ,V_ERROR);
		 
		 SET P_ERROR = V_ERROR; 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 	LEAVE L1;
		 END IF; 
		 
		 ----------------------------------------------------------------------------------
		 -- Actualiza estadisticas a tmp_Dire_Estan_Val
		 ----------------------------------------------------------------------------------
		 SET V_CADENA = ''; 
		 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val';
		 
		 ----------------------------------------------------------------------------------
		 -- Ejecuta cadena
		 ----------------------------------------------------------------------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (21):. Actualizar estadisticas a la tabla tmp_Dire_Estan_Val' ,V_ERROR); 
		 
		 SET P_ERROR = V_ERROR;
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 	LEAVE L1; 
		 END IF; 
		 
		 ----------------------------------------------------------------------------------
		 -- Busca y borra si existe la tabla DireccionFisica_Estandarizada
		 ----------------------------------------------------------------------------------
		 SELECT TABLENAME INTO :Temp 
		 FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'DireccionFisica_Estandarizada' ; 
		 
		 IF ACTIVITY_COUNT > 0 THEN 
		 	SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.DireccionFisica_Estandarizada';
		 	CALL DBC.SysExecSQL(:V_CADENA); 
		 END IF;
		 
		 ----------------------------------------------------------------------------------
		 -- Unifica los datos de acuerdo Cod_DW_Reporte_Ubic_Original, el resultado en DireccionFisica_Estandarizada
		 -- Se normaliza y ordena el texto de la direccion con la funcion ADDRESS_NORMALIZATION
		 ----------------------------------------------------------------------------------
		 
		 SET V_CADENA = ''; 
		 SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.DireccionFisica_Estandarizada
						 AS (SELECT	dir.Cod_DW_Reporte_Ubic_Original
									,dir.Texto_Ubicacion_Original
									,dir.Cod_DW_Tipo_Ubicacion
									,dir.Cod_DW_Fuente
									,dir.Lote
									,dir.Id_Buro_Suscriptor
									,dir.Id_Buro_Persona
									,dir.Cod_DW_Cta
									,dir.Cod_DW_Hash
									,dir.Cod_DW_Ubic
									,dir.Valor
									,dir.Ciudad Texto_Ciudad
									,dir.Codigo_Ciudad_Dane
									,dir.Fecha_Reporte									
									,dir.Cod_DW_Ubicacion_Original
									,dir.Cod_DW_Tipo_Ubicacion_Dir
									,dir.Usuario_BD									
									,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1)) DIRE_GEO
									,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 2)) DIRE_COMPLEMENTO
									,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 3)) DIR_TIPO_DIRE
									,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 4)) DIR_TIPOVIA
									,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 5)) DIR_NUMVIAPPAL
									,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 6)) DIR_NUMVIAGEN
									,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 7)) DIR_NUMPLACA									
									,COALESCE(ADDR_NORM, dir.Ubicacion_Stand) Ubicacion_Stand
									,cast('''' as varchar(20)) Reglas
									,CASE WHEN  Est.Cod_DW_Reporte_Ubic_Original is not null THEN ''VALIDA''
									      WHEN  Est.Cod_DW_Reporte_Ubic_Original is not null THEN ''NO VALIDA''
										ELSE ''SV''
									 END DIR_ESTADO	
                                    ,COALESCE(VREG.Cod_Dw_Gestion_Registro, -1 ) Cod_Dw_Gestion_Registro										
							FROM	' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada dir
							
							LEFT JOIN ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val Est
							ON dir.Cod_DW_Reporte_Ubic_Original = Est.Cod_DW_Reporte_Ubic_Original
							
							LEFT JOIN  ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas NoVal
							ON dir.Cod_DW_Reporte_Ubic_Original = NoVal.Cod_DW_Reporte_Ubic_Original
							
							LEFT JOIN ' || P_BDVISTA ||'.V_Gestion_Registro VReg
							ON DIR_ESTADO = VReg.Descripcion_Gestion_Registro
							
							QUALIFY ROW_NUMBER() OVER(PARTITION BY dir.Cod_DW_Reporte_Ubic_Original ORDER BY dir.Cod_DW_Reporte_Ubic_Original) = 1
							
						) WITH DATA
						PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; 
		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (22):. Crear y carga la tabla DireccionFisica_Estandarizada' ,V_ERROR);
		
		SET P_ERROR = V_ERROR;
		
		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
			LEAVE L1;
		END IF;
		 
		 ----------------------------------------------------------------------------------
		 -- Actualiza estadisticas a tmp_DireFisica_Estand_Topo
		 ----------------------------------------------------------------------------------
		 
		 SET V_CADENA = '';
		 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original )	ON ' || P_BDSTAGE ||'.DireccionFisica_Estandarizada';
							
		----------------------------------------------------------------------------------
		 -- Ejecuta cadena
		 ----------------------------------------------------------------------------------
		 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (23):. Actualizar estadisticas a la tabla DireccionFisica_Estandarizada' ,V_ERROR);
		 SET P_ERROR = V_ERROR; 
		 
		 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		 	LEAVE L1;
		 END IF; 
		 
		 ----------------------------------------------------------------------------------
		 -- Cursor de reglas para ETAPA IN (6)
		 -- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones Y Normalizacion(General)
		 ----------------------------------------------------------------------------------
		 SET V_CADENA = 'SELECT	Sentencia
								,Condicion
								,Flag_Recursiva
								,Cod_DW_Regla_Est_Ubica
						FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
						WHERE Cod_DW_Tipo_Ubicacion_Dir IN (Select Cod_DW_Atributo
															From '|| P_BDDATOS ||'.ATRIBUTO
															Where Cod_DW_Tipo_Atributo in (Select Cod_DW_Tipo_Atributo
																						   From '|| P_BDDATOS ||'.TIPO_ATRIBUTO
																						   Where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion'')
														   AND Valor_Origen = ''Geografica''
														   ) 
						AND  Flag_Activo = ''S'' 
						AND ETAPA IN (6)
						AND General = 1
						ORDER BY Orden'; 
		
		SET V_Contador = 0;
		
		PREPARE the_statement FROM V_CADENA;		
		OPEN cur_reglas_select;		
		
		CUR9:LOOP
			FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica;
			IF SQLCODE <> 0 THEN
				LEAVE CUR9;
			END IF;
			
			SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.DireccionFisica_Estandarizada
							SET ' || V_Sentencia || '
								, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
							WHERE ' || V_Condicion ;
		
			SET V_Contador = V_Contador +1;
							
        	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
										,V_StartTimeStampPadre 
										,:P_Nombre_Proceso_Padre 
										,:V_CADENA 
										,'PRO_StandardizationGeografica (23.1):'||' Ejecucion de reglas de tipo Generales iteracion: '||trim(V_Contador)||' Regla:'||trim(V_Cod_DW_Regla_Est_Ubica) 
										,V_ERROR); 
										
			
			IF SQLCODE NOT IN (0, 7632) THEN 
				SET V_CADENA1 = V_CADENA; 
				SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1;
				LEAVE L1; 
			END IF; 
		END LOOP CUR9; 
		CLOSE cur_reglas_select; 
		
		 ----------------------------------------------------------------------------------
		 -- Cursor de reglas para ETAPA IN (6)
		 -- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones Y Normalizacion(Via)
		 ----------------------------------------------------------------------------------
		 SET V_CADENA = 'SELECT	Sentencia
								,Condicion
								,Flag_Recursiva
								,Cod_DW_Regla_Est_Ubica
						FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
						WHERE Cod_DW_Tipo_Ubicacion_Dir IN (Select Cod_DW_Atributo
															From '|| P_BDDATOS ||'.ATRIBUTO
															Where Cod_DW_Tipo_Atributo in (Select Cod_DW_Tipo_Atributo
																						   From '|| P_BDDATOS ||'.TIPO_ATRIBUTO
																						   Where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion'')
														   AND Valor_Origen = ''Geografica''
														   ) 
						AND  Flag_Activo = ''S'' 
						AND ETAPA IN (6)
						AND Tipo_Via = 1
						ORDER BY Orden'; 
		
		SET V_Contador = 0;
		
		PREPARE the_statement FROM V_CADENA;		
		OPEN cur_reglas_select;		
		
		CUR10:LOOP
			FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica;
			IF SQLCODE <> 0 THEN
				LEAVE CUR10;
			END IF;
			
			SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.DireccionFisica_Estandarizada
							SET ' || V_Sentencia || '
								, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
							WHERE ' || V_Condicion ;
		
			SET V_Contador = V_Contador +1;
							
        	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
										,V_StartTimeStampPadre 
										,:P_Nombre_Proceso_Padre 
										,:V_CADENA 
										,'PRO_StandardizationGeografica (23.1):'||' Ejecucion de reglas de tipo via iteracion: '||trim(V_Contador)||' Regla:'||trim(V_Cod_DW_Regla_Est_Ubica) 
										,V_ERROR); 
			
			IF SQLCODE NOT IN (0, 7632) THEN 
				SET V_CADENA1 = V_CADENA; 
				SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1;
				LEAVE L1; 
			END IF; 
		END LOOP CUR10; 
		CLOSE cur_reglas_select; 
		
		 ----------------------------------------------------------------------------------
		 -- Cursor de reglas para ETAPA IN (6)
		 -- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones Y Normalizacion(Rural)
		 ----------------------------------------------------------------------------------
		 SET V_CADENA = 'SELECT	Sentencia
								,Condicion
								,Flag_Recursiva
								,Cod_DW_Regla_Est_Ubica
						FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
						WHERE Cod_DW_Tipo_Ubicacion_Dir IN (Select Cod_DW_Atributo
															From '|| P_BDDATOS ||'.ATRIBUTO
															Where Cod_DW_Tipo_Atributo in (Select Cod_DW_Tipo_Atributo
																						   From '|| P_BDDATOS ||'.TIPO_ATRIBUTO
																						   Where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion'')
														   AND Valor_Origen = ''Geografica''
														   ) 
						AND  Flag_Activo = ''S'' 
						AND ETAPA IN (6)
						AND Tipo_RR = 1
						ORDER BY Orden'; 
		
		
         SET V_Contador = 0;
		
		PREPARE the_statement FROM V_CADENA;		
		OPEN cur_reglas_select;		
		
		CUR12:LOOP
			FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica;
			IF SQLCODE <> 0 THEN
				LEAVE CUR12;
			END IF;
			
			SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.DireccionFisica_Estandarizada
							SET ' || V_Sentencia || '
								, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
							WHERE ' || V_Condicion ;
		
            SET V_Contador = V_Contador +1;
							
        	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 
										,V_StartTimeStampPadre 
										,:P_Nombre_Proceso_Padre 
										,:V_CADENA 
										,'PRO_StandardizationGeografica (23.1):'||' Ejecucion de reglas de tipo rural iteracion: '||trim(V_Contador)||' Regla:'||trim(V_Cod_DW_Regla_Est_Ubica) 
										,V_ERROR); 
			
			IF SQLCODE NOT IN (0, 7632) THEN 
				SET V_CADENA1 = V_CADENA; 
				SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1;
				LEAVE L1; 
			END IF; 
		END LOOP CUR12; 
		CLOSE cur_reglas_select; 	
		
	END L1;
END;

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
REPLACE PROCEDURE REC_DATOS.PRO_StandardizationGeografica_HAH ( IN P_Lote INTEGER , IN P_StartTimeStampPadre VARCHAR(20) , IN P_Nombre_Proceso_Padre VARCHAR(30) , IN P_BDDATOS VARCHAR(20) , IN P_BDVISTA VARCHAR(20) , IN P_BDSTAGE VARCHAR(20) , OUT P_ERROR VARCHAR(32000) ) /*
 * ################################################################################
 * 
 * Objetivo:		Estandariza las direcciones fisicas como ubicacion del insumo
 *			InsumoDireccionFisica, dejando el resultado en DireccionFisica_Estandarizada
 * Fecha:		2016/11/09
 * Realizado por:	Luis E Ramirez
 * Proyecto:		Nuevo reconocer
 * Script:		PRO_StandardizationGeografica BCK 12 sept antes de a?adir campo de reglas a stg
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha	Objetivo				Realizado por
 * 2017/12/28	Agregar el codigo dane hasta la tabla	aariza - Capgemini
 *		DireccionFisica_Estandarizada
 * 2018/03/06	Se agrega el campo Tipo_Direccion y	Capgemini
 *		se elimina el calculo del cod dane	
 *
 * 2018/03/27	Los registros marcados como no validos	Capgemini
 *		y enviados a la tabla tmp_Dire_Estan_Val
 *		ya no se excluyen del proceso de
 *		estandarizacion
 * 2018-05-08 #1 ajuste por bug en teradata pruebas	Capgemini
 * 2018-05-09 #2 ajuste null por ubicación original y nvl
 *		para armado de dirección		Capgemini
 * 2018-05-18 #3 ajuste no procesar nulos		Capgemini
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */ BEGIN ------------------------
-- Declaracion de variables
------------------------
 DECLARE V_StartTimeStampPadre TIMESTAMP(6); DECLARE V_FECHA_HORA_INI TIMESTAMP(6); DECLARE W_Log_TD_Detalle_ID INTEGER; DECLARE W_ERROR VARCHAR(32000); DECLARE V_ERROR VARCHAR(32000); DECLARE V_CADENA VARCHAR(32000); DECLARE V_CADENA1 VARCHAR(10000); DECLARE Temp CHAR(30); DECLARE V_Sentencia VARCHAR(500); DECLARE V_Condicion VARCHAR(500); DECLARE V_Flag_Recursiva VARCHAR(1); DECLARE V_COUNT INTEGER; DECLARE V_Cod_DW_Regla_Est_Ubica INTEGER; DECLARE cur_reglas_select NO SCROLL CURSOR FOR the_statement; DECLARE cur_count_rec NO SCROLL CURSOR FOR the_statement_1; L1: BEGIN SET P_ERROR = ''; SET V_StartTimeStampPadre = CAST(P_StartTimeStampPadre AS TIMESTAMP(6) FORMAT 'yyyy-mm-ddhh:mi:ss'); --SET V_StartTimeStampPadre =DATE;
 SET V_COUNT = 1; ---------------------------
 -- Busca y borra si existe la tabla tmp_EmailsEstandarizados
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Estandarizada' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
 -- Se crea y carga la tabla tmp_DireFisica_Estandarizada
 -- Se hace la primera limpieza de caracteres especiales en la ciudad y el texto de la direccion
 -----------------------------
 SET V_CADENA = ''; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada
	 AS (
	SELECT	 dir.Cod_DW_Reporte_Ubic_Original
		,nvl(' || P_BDVISTA || '.REPLEXPREG( Ubicacion_Stand_Prev, ''[^A-Z^0-9^ ^-^. ' || 'D1'XC'F1'XC || ']'','' ''),Texto_Ubicacion_Original) as Ubicacion_Stand /*#2*/
		,dir.Texto_Ubicacion_Original
		,dir.Cod_DW_Tipo_Ubicacion
		,dir.Cod_DW_Fuente
		,dir.Lote
		,dir.Id_Buro_Suscriptor
		,dir.Id_Buro_Persona
		,dir.Cod_DW_Cta
		,dir.Cod_DW_Hash
		,dir.Cod_DW_Ubic
		,dir.Valor                               
		,GEO.Descripcion_Ciudad Ciudad
		,dir.Codigo_Ciudad_Dane 
		,dir.Fecha_Reporte
		
		,Cod_DW_Ubicacion_Original
		,Cod_DW_Tipo_Ubicacion_Dir
		,Usuario_BD
		,cast('''' as varchar(20)) Reglas
		,dir.Tipo_Direccion
	FROM (
		SELECT	a.*
			,' || P_BDVISTA || '.REPL_CHRS  (UPPER(Texto_Ubicacion_Original), ''GEO'') Ubicacion_Stand_Prev
			,' || P_BDVISTA || '.REPL_CHRS  (TRIM(' || P_BDVISTA || '.REPLEXPREG(' || P_BDVISTA || '.REPLEXPREG( UPPER(Texto_Ciudad), ''^[A-Za-z ]?$''),''[ ]{2,100}'', '' '') ), ''GEO'') Texto_Ciudad_Prev 
		FROM ' || P_BDSTAGE ||'.InsumoDireccionFisica a ) dir
	LEFT JOIN '|| P_BDVISTA ||'.V_Geografia GEO
		ON GEO.Cod_Dane_Ciudad = dir.Codigo_Ciudad_Dane
	
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (1):. Crear y carga la tabla tmp_DireFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_Estandarizada
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN(Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Actualizar estadisticas a la tabla tmp_DireFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Cursor de reglas para ETAPA IN (2)
 -- Reglas de limpieza basadas en patrones de texto
 --------------------
 SET V_CADENA = '
			SELECT	Sentencia
				,Condicion
				,Flag_Recursiva
				,Cod_DW_Regla_Est_Ubica
			FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
			WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
					select Cod_DW_Atributo
					from '|| P_BDDATOS ||'.ATRIBUTO
					where Cod_DW_Tipo_Atributo in (
						select Cod_DW_Tipo_Atributo
						from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
						where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
					) AND Valor_Origen = ''Geografica''
				) AND  Flag_Activo = ''S'' AND ETAPA IN (2)
			ORDER BY Orden'; PREPARE the_statement FROM V_CADENA; OPEN cur_reglas_select; CUR1: LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; IF SQLCODE <> 0 THEN LEAVE CUR1; END IF; ---  Ini HAH
 SET V_FECHA_HORA_INI = CAST(CURRENT_TIMESTAMP AS TIMESTAMP(6) FORMAT 'yyyy-mm-ddhh:mi:ss'); --- Fin HAH
 SET V_CADENA = '
				UPDATE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
				SET ' || V_Sentencia || '
					, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
				WHERE ' || V_Condicion ; CALL DBC.SysExecSQL(:V_CADENA); END LOOP CUR1; IF SQLCODE <> '00000' THEN SET V_CADENA1 = V_CADENA; SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1; -------- Ini HAH
 SET W_ERROR = ''; SET W_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1; LOCKING REC_MTDAT.LOG_TD_DETALLE FOR ACCESS SELECT COALESCE ( MAX ( Log_TD_Detalle_ID ), 0 ) + 1 INTO :W_Log_TD_Detalle_ID FROM REC_MTDAT.LOG_TD_DETALLE WHERE Lote = :P_Lote ; INSERT INTO REC_MTDAT.LOG_TD_DETALLE ( Lote ,Log_TD_Detalle_ID ,StringSQL ,Fecha_Inicio ,Fecha_Fin ,Estado_Ejecucion ,Fecha_Hora_Inicio_Padre ,Nombre_Proceso_Padre ,Descripcion_Teradata_Error ) VALUES ( :P_Lote ,:W_Log_TD_Detalle_ID ,:V_CADENA1 ,NULL --:V_FECHA_HORA_INI
 ,CURRENT_TIMESTAMP ,'INICIO' ,:P_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:W_ERROR ); LEAVE L1; -------- Fin HAH
 END IF; CLOSE cur_reglas_select; ---------------------------
 -- Reemplaza Toponimos
 -- Busca y borra si existe la tabla tmp_DireFisica_Topo_a
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Topo_a' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo_a'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_a
	 AS
	(
		SELECT	a.Cod_DW_Reporte_Ubic_Original
			,CASE WHEN b.Valor IS NULL
					THEN Ubicacion_Stand
			      ELSE OREPLACE(Ubicacion_Stand, b.Valor, b.Normalizado)
			END Ubicacion_Stand
			,a.Ciudad
			,a.Codigo_Ciudad_Dane
			,a.Tipo_Direccion
		FROM  (
			select *
			from '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
			qualify row_number() over(partition by Cod_DW_Reporte_Ubic_Original
					order by Cod_DW_Reporte_Ubic_Original) = 1
			) a
		LEFT JOIN (
			SELECT   P.Valor
				,P.Normalizado
			FROM '|| P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
			    INNER JOIN '|| P_BDDATOS ||'.TIPO_PARAMETRO AS TP
				ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
			    INNER JOIN  '|| P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
				ON  TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
			    INNER JOIN '|| P_BDDATOS ||'.PARAMETRO AS P
				ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
			WHERE   GP.Nombre_Grupo_Parametro = ''TOPONIMOS''
					  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
			  ) b
		       ON a.Ubicacion_Stand like ''%'' || b.Valor || ''%''
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Crea la tabla tmp_DireFisica_Topo_a' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_Estandarizada
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_a'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo_a' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Busca y borra si existe la tabla tmp_DireFisica_Topo
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Topo' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
 -- Se crea y carga la tabla tmp_DireFisica_Topo
 -- Separacion del texto de la direccion en palabras
 -----------------------------
 SET V_CADENA = ''; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo
	 AS (
	 WITH RECURSIVE Text_Dir_Palabras
	 (Cod_DW_Reporte_Ubic_Original
	 ,ID_S
	 ,POS
	 ,PALABRA
	 ,Ubicacion_Stand
	 ,Ciudad
	 ,Codigo_Ciudad_Dane
	 ,Tipo_Direccion
	) AS
	(
		SELECT Cod_DW_Reporte_Ubic_Original
			,0
			,0
			, cast('''' as varchar(100))
			,Ubicacion_Stand  
			,Ciudad
			,Codigo_Ciudad_Dane
			,Tipo_Direccion
		from '||P_BDSTAGE || '.tmp_DireFisica_Topo_a
		UNION ALL
		SELECT Cod_DW_Reporte_Ubic_Original
			,ID_S+1
			,CASE WHEN POSITION('' '' IN Ubicacion_Stand) > 0
					THEN POSITION('' '' IN Ubicacion_Stand)
			     ELSE CHARACTER_LENGTH(Ubicacion_Stand)
			END POS1
			,TRIM(BOTH '' '' FROM SUBSTR(Ubicacion_Stand, 0, POS1+1))
			,TRIM(SUBSTR(Ubicacion_Stand, POS1+1))
			,Ciudad
			,Codigo_Ciudad_Dane
			,Tipo_Direccion
		FROM Text_Dir_Palabras
		WHERE POS1 > 0
	)
	SELECT Cod_DW_Reporte_Ubic_Original
		,ID_S
		,PALABRA 
		,Ciudad
		,Codigo_Ciudad_Dane
		,Ubicacion_Stand
		,Tipo_Direccion
	FROM Text_Dir_Palabras
	WHERE ID_S > 0
	
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)'; CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (3):. Crear y carga la tabla tmp_DireFisica_Topo' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_Topo
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (4):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; /*
		BEGIN ETAPA TOPONIMO
		begin tmp_DireFisica_Topo
		*/ ---------------------------
 -- Busca y borra si existe la tabla tmp_DireFisica_Topo_II
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Topo_II' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo_II'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
 -- Se crea y carga la tabla tmp_DireFisica_Topo_II
 -- Se aplican acepciones y no existe, se llama la funcion GENACCEPAUT para
 --  intentar crearla
 -----------------------------
 SET V_CADENA = ''; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II
	AS (
	SELECT	A.Cod_DW_Reporte_Ubic_Original
	,A.ID_S
	,CASE WHEN ACEP.Valor IS NULL
			AND ' || P_BDVISTA || '.VALIDATE_EXPRESSION_R(A.PALABRA, ''^[A-Za-z]{3,20}*$'')=1
			AND A.PALABRA IS NOT NULL
			AND ACEP.Valor IS NULL
		THEN ' || P_BDVISTA || '.GENACCEPAUT(A.PALABRA, SOUNDEX(A.PALABRA))
	END NEW_ACEPCION
	,CASE WHEN ACEP.Valor IS NOT NULL
		THEN ACEP.Normalizado
	      WHEN NEW_ACEPCION IS NOT NULL AND CHAR(NEW_ACEPCION) <> 0
		THEN NEW_ACEPCION
	      ELSE A.PALABRA
	END PALABRA
	,A.Ubicacion_Stand
	,A.PALABRA PALABRA_ORI
	,A.Ciudad
	,A.Codigo_Ciudad_Dane
	,A.Tipo_Direccion
	FROM ' || P_BDSTAGE ||'.tmp_DireFisica_Topo A
	LEFT JOIN (
	SELECT	P.Valor
		,P.Normalizado
	FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
	INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
		ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
	INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
		ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
	INNER JOIN ' || P_BDDATOS ||'.PARAMETRO AS P
		ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
	WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
			  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
		) ACEP
	ON TRIM(A.PALABRA) = ACEP.Valor /*#1*/
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)'; CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (5):. Crear y carga la tabla tmp_DireFisica_Topo_II' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_Topo
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (6):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo_II' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Inserta las nuevas acepciones en parametros
 --------------------
 SET V_CADENA = ''; SET V_CADENA = '
	INSERT INTO ' || P_BDDATOS ||'.PARAMETRO
	SELECT	P.Cod_DW_Parametro + SUM( 1 ) OVER (ROWS UNBOUNDED PRECEDING) Cod_DW_Parametro
		,A.PALABRA_ORI Valor
		,A.PALABRA Normalizado
		,'|| P_Lote || '
		,NULL
		,1
		,USER
		,STP1.Cod_DW_Subtipo_Parametro
		,NULL
		,date
	FROM (SELECT *
		FROM ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II
		WHERE NEW_ACEPCION IS NOT NULL AND CHAR(NEW_ACEPCION) <> 0
		QUALIFY ROW_NUMBER() OVER(PARTITION BY PALABRA_ORI, PALABRA ORDER BY PALABRA_ORI) = 1
	   ) A
	CROSS JOIN (
		SELECT STP.Cod_DW_Subtipo_Parametro
		FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
		INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
			ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
		INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
			ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
		WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
	
			  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
		) STP1
	CROSS JOIN (SELECT MAX(Cod_DW_Parametro) Cod_DW_Parametro
		    FROM ' || P_BDDATOS ||'.PARAMETRO
		) P
	LEFT JOIN (
		SELECT    P.Valor
			,P.Normalizado
		    FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
		    INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
			ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
		    INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
			ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
		    INNER JOIN ' || P_BDDATOS ||'.PARAMETRO AS P
			ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
		    WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
			      AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
	  ) EXT
		ON EXT.Valor = 			trim(A.PALABRA_ORI) /*#1*/
		AND EXT.Normalizado = 	trim(A.PALABRA) /*#1*/
	WHERE EXT.Valor IS NULL'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (7):. Inserta las nuevas acepciones en PARAMETRO' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a paramtros
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Parametro) ON ' || P_BDDATOS ||'.PARAMETRO'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (8):. Actualizar estadisticas a la tabla PARAMETRO' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; /*end tmp_DireFisica_Topo_II
		*/ /*
		END ETAPA TOPONIMO
		*/ ---------------------------
 -- Busca y borra si existe la tabla tmp_DireFisica_TopoUpd
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_TopoUpd' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
 -- Se crea y carga la tabla tmp_DireFisica_TopoUpd
 -- Rearma la direccion
 -----------------------------
 SET V_CADENA = ''; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_TopoUpd
	AS (
	WITH RECURSIVE Text_Dir_PalabrasT
	(Cod_DW_Reporte_Ubic_Original
	,ID_S
	,PALABRA
	,Ubicacion_Stand
	,Ciudad
	,Codigo_Ciudad_Dane
	,Reglas
	,Tipo_Direccion
	) AS
	(
	SELECT Cod_DW_Reporte_Ubic_Original
		,ID_S
		,PALABRA
		,CAST(PALABRA AS VARCHAR(500)) Ubicacion_Stand     
		,Ciudad
		,Codigo_Ciudad_Dane
		,CAST('''' AS VARCHAR(50)) as Reglas
		,Tipo_Direccion
	from '||P_BDSTAGE || '.tmp_DireFisica_Topo_II
	QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
					ORDER BY ID_S ASC) = 1
	UNION ALL
	SELECT A.Cod_DW_Reporte_Ubic_Original
		,B.ID_S
		,B.PALABRA
		,nvl(A.Ubicacion_Stand,'''') || '' '' || nvl(B.PALABRA,'''') /*#2*/
		,B.Ciudad
		,B.Codigo_Ciudad_Dane
		,CAST('''' AS VARCHAR(50)) as Reglas
		,B.Tipo_Direccion
	FROM '||P_BDSTAGE || '.tmp_DireFisica_Topo_II B
	INNER JOIN Text_Dir_PalabrasT A
		ON A.Cod_DW_Reporte_Ubic_Original = B.Cod_DW_Reporte_Ubic_Original
		AND (A.ID_S + 1) = B.ID_S
	WHERE B.ID_S IS NOT NULL
	)
	SELECT Cod_DW_Reporte_Ubic_Original
	,Ubicacion_Stand
	,Ciudad
	,Codigo_Ciudad_Dane
	,Reglas
	,Tipo_Direccion
	FROM Text_Dir_PalabrasT
	QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
				ORDER BY ID_S DESC, Ubicacion_Stand DESC) = 1
	
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (9):. Crear y carga la tabla tmp_DireFisica_TopoUpd' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_TopoUpd
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN (Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_DireFisica_TopoUpd'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (10):. Actualizar estadisticas a la tabla tmp_DireFisica_TopoUpd' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Cursor de reglas para ETAPA IN (5)
 -- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones
 --------------------
 SET V_CADENA = '
	SELECT	Sentencia
		,Condicion
		,Flag_Recursiva
		,Cod_DW_Regla_Est_Ubica
		
	FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
	WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
			select Cod_DW_Atributo
			from '|| P_BDDATOS ||'.ATRIBUTO
			where Cod_DW_Tipo_Atributo in (
				select Cod_DW_Tipo_Atributo
				from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
				where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
			) AND Valor_Origen = ''Geografica''
		) AND  Flag_Activo = ''S'' AND ETAPA IN (5)
	ORDER BY Orden'; PREPARE the_statement FROM V_CADENA; OPEN cur_reglas_select; CUR2: LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; IF SQLCODE <> 0 THEN LEAVE CUR2; END IF; ---  Ini HAH
 SET V_FECHA_HORA_INI = CAST(CURRENT_TIMESTAMP AS TIMESTAMP(6) FORMAT 'yyyy-mm-ddhh:mi:ss'); --- Fin HAH
 SET V_CADENA = '
		UPDATE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
		SET ' || V_Sentencia || '
			, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
		WHERE    ' || V_Condicion ||' AND Ubicacion_Stand  IS NOT NULL /*#3*/ '; CALL DBC.SysExecSQL(:V_CADENA); END LOOP CUR2; IF SQLCODE <> '00000' THEN SET V_CADENA1 = V_CADENA; SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1; -------- Ini HAH
 SET W_ERROR = ''; SET W_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1; LOCKING REC_MTDAT.LOG_TD_DETALLE FOR ACCESS SELECT COALESCE ( MAX ( Log_TD_Detalle_ID ), 0 ) + 1 INTO :W_Log_TD_Detalle_ID FROM REC_MTDAT.LOG_TD_DETALLE WHERE Lote = :P_Lote ; INSERT INTO REC_MTDAT.LOG_TD_DETALLE ( Lote ,Log_TD_Detalle_ID ,StringSQL ,Fecha_Inicio ,Fecha_Fin ,Estado_Ejecucion ,Fecha_Hora_Inicio_Padre ,Nombre_Proceso_Padre ,Descripcion_Teradata_Error ) VALUES ( :P_Lote ,:W_Log_TD_Detalle_ID ,:V_CADENA1 ,:V_FECHA_HORA_INI ,CURRENT_TIMESTAMP ,'INICIO' ,:P_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:W_ERROR ); LEAVE L1; -------- Fin HAH
 END IF; CLOSE cur_reglas_select; ---------------------------
 -- Se ordenan las particulas en formato DANE con la funcion ADDRESS_NORMALIZATION
 -- esta funcion develve una serie de campos donde el ultimo se emplea para tipificar
 -- la direccion  como valida, invalida 
 --
 --
 -- Busca y borra si existe la tabla tmp_DireFisica_Nor
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Nor' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Nor'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Nor
	AS
	(
	SELECT	Cod_DW_Reporte_Ubic_Original
		,Ubicacion_Stand
		,'|| P_BDVISTA ||'.ADDRESS_NORMALIZATION(oreplace(Ubicacion_Stand,''?'', ''''), Ciudad, 300, COALESCE(Codigo_Ciudad_Dane, ''''), Tipo_Direccion) ADDR_NORM
		,Ciudad
		,Codigo_Ciudad_Dane
	FROM '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_Nor
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Nor'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (12):. Actualizar estadisticas a la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Genera posibles direcciones para las direcciones marcadas como ""X VALIDAR VIAS"" y ""NO VALIDA"" 
 --
 -- Busca y borra si existe la tabla tmp_Direcc_No_Validas
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Direcc_No_Validas' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Direcc_No_Validas'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas
	AS
	(
	SELECT	Cod_DW_Reporte_Ubic_Original
		,Ubicacion_Stand
		,Codigo_Ciudad_Dane
	FROM '||P_BDSTAGE || '.tmp_DireFisica_Nor
	WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''NO VALIDA 2''
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (13):. Crea la tabla tmp_Direcc_No_Validas' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Procesa las direcciones marcadas como ""X VALIDAR VIAS"" y genera un registro por cada una 
 --
 -- Busca y borra si existe la tabla tmp_Direcc_X_Validar_Vias
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Direcc_X_Validar_Vias' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Direcc_X_Validar_Vias'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias
	 AS
	(
	WITH RECURSIVE New_Direc
	 (Cod_DW_Reporte_Ubic_Original
	 ,ID_S
	 ,Direc_New
	 ,Dir
	 ,Ubicacion_Stand
	 ,Codigo_Ciudad_Dane
	) AS
	(
		SELECT Cod_DW_Reporte_Ubic_Original
			,0 ID_S
			, CAST(NULL AS VARCHAR(100))Direc_New
			, '|| P_BDVISTA ||'.DESC_ADDRESS_MORE_ADDRESS(Ubicacion_Stand, Ciudad, 300, Codigo_Ciudad_Dane) Dir
			, Ubicacion_Stand
			,Codigo_Ciudad_Dane
		from '||P_BDSTAGE || '.tmp_DireFisica_Nor
		WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''X VALIDAR VIAS''
		UNION ALL
		SELECT Cod_DW_Reporte_Ubic_Original
			,ID_S+1 ID_S1
			,'|| P_BDVISTA ||'.eListGetValByIdx(DIR, ''/'', ID_S1) Direc_New1
			, DIR
			,Ubicacion_Stand
			,Codigo_Ciudad_Dane
		FROM New_Direc
		WHERE Direc_New1 is not null
	)
	SELECT	Cod_DW_Reporte_Ubic_Original
		,ID_S
		,Ubicacion_Stand
		,Direc_New
		,Codigo_Ciudad_Dane
	FROM New_Direc
	WHERE Direc_New is not null
	
	
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (14):. Crea la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_Direcc_X_Validar_Vias
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (15):. Actualizar estadisticas a la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Marca si alguna de la direcciones puede ser tenia como valida 
 --
 -- Busca y borra si existe la tabla tmp_DirVal_X_Validar_Vias
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DirVal_X_Validar_Vias' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DirVal_X_Validar_Vias'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias
	 AS
	(
	SELECT	Dir.Cod_DW_Reporte_Ubic_Original
		,Dir.Ubicacion_Stand
		,Dir.Direc_New
		,CASE WHEN (VUE.Flag_Geo IS NOT NULL
					AND VUE.Flag_Geo = ''S''
					AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) <> ''''
					AND VDF.Cod_DW_Ubic IS NOT NULL)
				AND VRPU.Cod_DW_Ubic IS NOT NULL
			   THEN 1
		       WHEN (VUE.Flag_Geo IS NOT NULL
					AND VUE.Flag_Geo = ''S''
					AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) <> ''''
					AND VDF.Cod_DW_Ubic IS NOT NULL)
				OR VRPU.Cod_DW_Ubic IS NOT NULL
			   THEN 2
		       ELSE 3
		 END Ind_Val
		 ,Dir.Codigo_Ciudad_Dane
	
	FROM	' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias Dir
	INNER JOIN ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada TMP
		ON TMP.Cod_DW_Reporte_Ubic_Original = Dir.Cod_DW_Reporte_Ubic_Original
	LEFT JOIN ' || P_BDVISTA || '.V_Ubicacion_Estandarizada VUE
		ON TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 1)) = VUE.Texto_Ubicacion
		AND TMP.Cod_DW_Tipo_Ubicacion = VUE.Cod_Dw_Tipo_Ubicacion 
	LEFT JOIN ' || P_BDVISTA || '.V_DIRECCION_FISICA VDF
		ON VUE.Cod_DW_Ubic = VDF.Cod_DW_Ubic
		AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) = VDF.Complemento
	LEFT JOIN ' || P_BDVISTA || '.V_RELACION_PERSONA_UBICACION VRPU
		ON VUE.Cod_DW_Ubic = COALESCE(VRPU.Cod_DW_Ubic, -1)
		
	QUALIFY ROW_NUMBER() OVER(PARTITION BY Dir.Cod_DW_Reporte_Ubic_Original, Dir.Direc_New
				ORDER BY Dir.Cod_DW_Reporte_Ubic_Original) = 1
	
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (16):. Crea la tabla tmp_DirVal_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_Direcc_No_Validas
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (17):. Actualizar estadisticas a la tabla tmp_DirVal_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Completa las direcciones no validas en tmp_Direcc_No_Validas con las direcciones que no se pudieron clasificar
 --------------------
 SET V_CADENA = ''; SET V_CADENA = '
	INSERT INTO ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas
	SELECT	DISTINCT
	Cod_DW_Reporte_Ubic_Original
	,Ubicacion_Stand
	,Codigo_Ciudad_Dane
	FROM	' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias A
	WHERE Ind_Val = 3
	AND NOT EXISTS (
		SELECT 1
		FROM ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias B
		WHERE A.Cod_DW_Reporte_Ubic_Original = B.Cod_DW_Reporte_Ubic_Original
		AND B.Ind_Val in (1,2)
	)
	'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (18):. Completa direcciones invalidas en tmp_Direcc_No_Validas' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_Direcc_No_Validas
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (19):. Actualizar estadisticas a la tabla tmp_Direcc_No_Validas' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Une todas las direcciones validas en tmp_Dire_Estan_Val
 -- Busca y borra si existe la tabla tmp_Dire_Estan_Val
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Dire_Estan_Val' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Dire_Estan_Val'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val
	AS (
	SELECT	Cod_DW_Reporte_Ubic_Original
		,oreplace(ADDR_NORM, ''NO VALIDA 2'',''NO VALIDA'') ADDR_NORM
		,Codigo_Ciudad_Dane
	FROM '||P_BDSTAGE || '.tmp_DireFisica_Nor
	WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) <> ''X VALIDAR VIAS''
	UNION ALL
	SELECT	Cod_DW_Reporte_Ubic_Original
		,OREPLACE(OREPLACE(Direc_New, ''NO VALIDA 2'', ''VALIDA''), ''NO VALIDA'', ''VALIDA'')  Direc_New
		,Codigo_Ciudad_Dane
	FROM '||P_BDSTAGE || '.tmp_DirVal_X_Validar_Vias
	QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
					ORDER BY Ind_Val) = 1
	
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (20):. Crea la tabla tmp_Dire_Estan_Val' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_Dire_Estan_Val
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (21):. Actualizar estadisticas a la tabla tmp_Dire_Estan_Val' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Busca y borra si existe la tabla DireccionFisica_Estandarizada
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'DireccionFisica_Estandarizada' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.DireccionFisica_Estandarizada'; CALL DBC.SysExecSQL(:V_CADENA); END IF; --------------------
 -- Unifica los datos de acuerdo Cod_DW_Reporte_Ubic_Original, el resultado en DireccionFisica_Estandarizada
 -- Se normaliza y ordena el texto de la direccion con la funcion ADDRESS_NORMALIZATION
 --------------------
 SET V_CADENA = ''; SET V_CADENA = '
	CREATE MULTISET TABLE ' || P_BDSTAGE ||'.DireccionFisica_Estandarizada
	 AS (
		SELECT	dir.Cod_DW_Reporte_Ubic_Original
			,dir.Texto_Ubicacion_Original
			,dir.Cod_DW_Tipo_Ubicacion
			,dir.Cod_DW_Fuente
			,dir.Lote
			,dir.Id_Buro_Suscriptor
			,dir.Id_Buro_Persona
			,dir.Cod_DW_Cta
			,dir.Cod_DW_Hash
			,dir.Cod_DW_Ubic
			,dir.Valor
			,dir.Ciudad Texto_Ciudad
			,dir.Codigo_Ciudad_Dane
			,dir.Fecha_Reporte
			
			,dir.Cod_DW_Ubicacion_Original
			,dir.Cod_DW_Tipo_Ubicacion_Dir
			,dir.Usuario_BD
			
			,TRIM(CAST(CASE WHEN Est.Cod_DW_Reporte_Ubic_Original IS NULL
			 THEN dir.Texto_Ubicacion_Original
			 ELSE COALESCE( '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1), dir.Texto_Ubicacion_Original)
			END AS VARCHAR(4096))) DIRE_GEO
			,TRIM(CAST('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 2) AS VARCHAR(4096))) DIRE_COMPLEMENTO
			,TRIM(CAST('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 3) AS VARCHAR(4096))) DIR_TIPO_DIRE
			,TRIM(CAST(CASE WHEN Est.Cod_DW_Reporte_Ubic_Original IS NULL
			 THEN dir.Tipo_Direccion
			 ELSE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 4)
			END AS VARCHAR(4096))) DIR_TIPOVIA
			,TRIM(CAST('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 5) AS VARCHAR(4096))) DIR_NUMVIAPPAL
			,TRIM(CAST('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 6) AS VARCHAR(4096))) DIR_NUMVIAGEN
			,TRIM(CAST('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 7) AS VARCHAR(4096))) DIR_NUMPLACA
			,TRIM(CAST(CASE WHEN Est.Cod_DW_Reporte_Ubic_Original IS NULL
			  OR '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1) IS NULL
			  OR '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1) = ''''
			 THEN ''NO VALIDA''
			 ELSE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8)
			END AS VARCHAR(4096))) DIR_CB_VALIDA
			,TRIM(CAST(CASE WHEN Est.Cod_DW_Reporte_Ubic_Original IS NULL
			  OR '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1) IS NULL
			  OR '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1) = ''''
			 THEN dir.Texto_Ubicacion_Original || ''&&''|| dir.Tipo_Direccion ||''&&&&&NO VALIDA''
			 ELSE COALESCE(ADDR_NORM, dir.Ubicacion_Stand)
			END AS VARCHAR(4096))) Ubicacion_Stand
			,CAST('''' AS VARCHAR(20)) Reglas
		FROM	' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada dir
		LEFT JOIN ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val Est
			ON dir.Cod_DW_Reporte_Ubic_Original = Est.Cod_DW_Reporte_Ubic_Original
		QUALIFY ROW_NUMBER() OVER(PARTITION BY dir.Cod_DW_Reporte_Ubic_Original
					ORDER BY dir.Cod_DW_Reporte_Ubic_Original) = 1
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (22):. Crear y carga la tabla DireccionFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_Estand_Topo
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original )
								ON ' || P_BDSTAGE ||'.DireccionFisica_Estandarizada'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (8):. Actualizar estadisticas a la tabla DireccionFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Cursor de reglas para ETAPA IN (6)
 -- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones
 --------------------
 SET V_CADENA = '
	SELECT	Sentencia
		,Condicion
		,Flag_Recursiva
		,Cod_DW_Regla_Est_Ubica
	FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
	WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
			select Cod_DW_Atributo
			from '|| P_BDDATOS ||'.ATRIBUTO
			where Cod_DW_Tipo_Atributo in (
				select Cod_DW_Tipo_Atributo
				from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
				where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
			) AND Valor_Origen = ''Geografica''
		) AND  Flag_Activo = ''S'' AND ETAPA IN (6)
	ORDER BY Orden'; PREPARE the_statement FROM V_CADENA; OPEN cur_reglas_select; CUR3: LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; IF SQLCODE <> 0 THEN LEAVE CUR3; END IF; ---  Ini HAH
 SET V_FECHA_HORA_INI = CAST(CURRENT_TIMESTAMP AS TIMESTAMP(6) FORMAT 'yyyy-mm-ddhh:mi:ss'); --- Fin HAH	
 SET V_CADENA = '
		UPDATE '||P_BDSTAGE || '.DireccionFisica_Estandarizada
		SET ' || V_Sentencia || '
			, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
		WHERE ' || V_Condicion; CALL DBC.SysExecSQL(:V_CADENA); END LOOP CUR3; IF SQLCODE <> '00000' THEN SET V_CADENA1 = V_CADENA; SET P_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1; -------- Ini HAH
 SET W_ERROR = ''; SET W_ERROR = 'ERROR: '|| SQLCODE || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1; LOCKING REC_MTDAT.LOG_TD_DETALLE FOR ACCESS SELECT COALESCE ( MAX ( Log_TD_Detalle_ID ), 0 ) + 1 INTO :W_Log_TD_Detalle_ID FROM REC_MTDAT.LOG_TD_DETALLE WHERE Lote = :P_Lote ; INSERT INTO REC_MTDAT.LOG_TD_DETALLE ( Lote ,Log_TD_Detalle_ID ,StringSQL ,Fecha_Inicio ,Fecha_Fin ,Estado_Ejecucion ,Fecha_Hora_Inicio_Padre ,Nombre_Proceso_Padre ,Descripcion_Teradata_Error ) VALUES ( :P_Lote ,:W_Log_TD_Detalle_ID ,:V_CADENA1 ,:V_FECHA_HORA_INI ,CURRENT_TIMESTAMP ,'INICIO' ,:P_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:W_ERROR ); -------- Fin HAH
 LEAVE L1; END IF; CLOSE cur_reglas_select; END L1; END;

REPLACE PROCEDURE REC_DATOS.PRO_StandardizationGeografica_VAL ( IN P_Lote INTEGER , IN P_StartTimeStampPadre VARCHAR(20) , IN P_Nombre_Proceso_Padre VARCHAR(30) , IN P_BDDATOS VARCHAR(20) , IN P_BDVISTA VARCHAR(20) , IN P_BDSTAGE VARCHAR(20) , OUT P_ERROR VARCHAR(32000) ) /*
 * ##################################################################################################
 * 
 * Objetivo:		Estandariza las direcciones fisicas como ubicacion del insumo
 *			InsumoDireccionFisica, dejando el resultado en DireccionFisica_Estandarizada
 * Fecha:		2016/11/09
 * Realizado por:	Luis E Ramirez
 * Proyecto:		Nuevo reconocer
 * Script:		PRO_StandardizationGeografica BCK 12 sept antes de a?adir campo de reglas a stg
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha	Objetivo				                            Realizado por
 * 2017/12/28	Agregar el codigo dane hasta la tabla	aariza - Capgemini
 *		DireccionFisica_Estandarizada
 * 2018/03/06	Se agrega el campo Tipo_Direccion y	Capgemini
 *		se elimina el calculo del cod dane	
 *
 * 2018/03/27	Los registros marcados como no validos	         Capgemini
 *		y enviados a la tabla tmp_Dire_Estan_Val
 *		ya no se excluyen del proceso de
 *		estandarizacion
 * 2018-05-08 #1 ajuste por bug en teradata pruebas	             Capgemini
 * 2018-05-09 #2 ajuste null por ubicaciÃ¸ÆÃ´Â³n original y nvl
 *		para armado de direcciÃ¸ÆÃ´Â³n		                         Capgemini
 * 2018-05-18 #3 ajuste no procesar nulos	                 	 Capgemini
 * 2018-05-18 #4 ajuste severidad nulos		                     Capgemini
 * 2018-09-27 #5 ajuste performance mantis 7036		             Capgemini
 * 2019-02-10 # Se ajusta le SP para que realice de mejor 
 *            forma la Gestion_Registro Valida/No Valida, 
 *            Mediante  las UDF ValidacionDirRural   y
 *            ValidacionDirVia,ValidacionDirMZ                    Fernando Garrido M
 * 2021-02-10 #6 Se ajusta regla para calculo campo DIR_CB_VALIDA  Jeimmy Chavez
 * ---------------------------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ##################################################################################################
 */
 ------------------------
 -- Declaracion de variables
 ------------------------
 BEGIN 
	 DECLARE V_DESC_ERR VARCHAR(1000);
	 DECLARE V_SQL INTEGER;
	 DECLARE V_STA VARCHAR(20);
	 DECLARE V_StartTimeStampPadre TIMESTAMP(6);
	 DECLARE V_FECHA_HORA_INI TIMESTAMP(6);
	 DECLARE W_Log_TD_Detalle_ID INTEGER;
	 DECLARE W_ERROR VARCHAR(32000);
	 DECLARE V_ERROR VARCHAR(32000);
	 DECLARE V_CADENA VARCHAR(32000);
	 DECLARE V_CADENA1 VARCHAR(10000);
	 DECLARE Temp CHAR(30);
	 DECLARE V_Sentencia VARCHAR(500);
	 DECLARE V_Condicion VARCHAR(500);
	 DECLARE V_Flag_Recursiva VARCHAR(1);
	 DECLARE V_COUNT INTEGER;
	 DECLARE V_Contador INTEGER;
	 DECLARE V_Cod_DW_Regla_Est_Ubica INTEGER;
	 DECLARE cur_reglas_select NO SCROLL CURSOR FOR the_statement;
	 DECLARE cur_count_rec NO SCROLL CURSOR FOR the_statement_1;
	 DECLARE CONTINUE HANDLER FOR SQLEXCEPTION BEGIN SET V_SQL = SQLCODE;  SET V_STA = SQLSTATE; 
 END;
 
L1: BEGIN 
 SET P_ERROR = '';
 SET V_StartTimeStampPadre = CAST(P_StartTimeStampPadre AS TIMESTAMP(6) FORMAT 'yyyy-mm-ddhh:mi:ss'); 
 SET V_COUNT = 1; 
 SET V_SQL = 0; 
 SET V_STA = '';
 --------------------------------------------------------------
 -- Busca y borra si existe la tabla tmp_EmailsEstandarizados
 -------------------------------------------------------------- 
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Estandarizada' ;
  IF ACTIVITY_COUNT > 0 THEN 
   SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada';
  CALL DBC.SysExecSQL(:V_CADENA);
 END IF;
  -------------------------------------------------------------- -------------------------------
 -- Se crea y carga la tabla tmp_DireFisica_Estandarizada
 -- Se hace la primera limpieza de caracteres especiales en la ciudad y el texto de la direccion
 -------------------------------------------------------------- --------------------------------
 SET V_CADENA = ''; 
 SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada
				 AS (
				SELECT	 dir.Cod_DW_Reporte_Ubic_Original
					,nvl(' || P_BDVISTA || '.REPLEXPREG( Ubicacion_Stand_Prev, ''[^A-Z^0-9^ ^-^. ' || 'D1'XC'F1'XC || ']'','' ''),Texto_Ubicacion_Original) as Ubicacion_Stand /*#2*/					
					,nvl(' || P_BDVISTA || '.REPLEXPREG( Ubicacion_Stand_Prev, ''[^A-Z^0-9^ ^-^. ' || 'D1'XC'F1'XC || ']'','' ''),Texto_Ubicacion_Original) as Ubicacion_Stand_VALIDACION /*#2*/
					,dir.Texto_Ubicacion_Original
					,dir.Cod_DW_Tipo_Ubicacion
					,dir.Cod_DW_Fuente
					,dir.Lote
					,dir.Id_Buro_Suscriptor
					,dir.Id_Buro_Persona
					,dir.Cod_DW_Cta
					,dir.Cod_DW_Hash
					,dir.Cod_DW_Ubic
					,dir.Valor                               
					,GEO.Descripcion_Ciudad Ciudad
					,dir.Codigo_Ciudad_Dane 
					,dir.Fecha_Reporte
					
					,Cod_DW_Ubicacion_Original
					,Cod_DW_Tipo_Ubicacion_Dir
					,Usuario_BD
					,cast('''' as varchar(20)) Reglas
					,dir.Tipo_Direccion
				FROM (
					SELECT	a.*
						,' || P_BDVISTA || '.REPL_CHRS  (UPPER(Texto_Ubicacion_Original), ''GEO'') Ubicacion_Stand_Prev
						,' || P_BDVISTA || '.REPL_CHRS  (TRIM(' || P_BDVISTA || '.REPLEXPREG(' || P_BDVISTA || '.REPLEXPREG( UPPER(Texto_Ciudad), ''^[A-Za-z ]?$''),''[ ]{2,100}'', '' '') ), ''GEO'') Texto_Ciudad_Prev 
					FROM ' || P_BDSTAGE ||'.InsumoDireccionFisica a ) dir
				LEFT JOIN '|| P_BDVISTA ||'.V_Geografia GEO
					ON GEO.Cod_Dane_Ciudad = dir.Codigo_Ciudad_Dane
				
				) WITH DATA
				PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';

 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (1):. Crear y carga la tabla tmp_DireFisica_Estandarizada' ,V_ERROR);

 SET P_ERROR = V_ERROR;
  IF CHARACTER_LENGTH(V_ERROR) > 0 
   THEN LEAVE L1; 
  END IF;
  
 ------------------------------------------------------------
 -- Actualiza estadisticas a tmp_DireFisica_Estandarizada
 ------------------------------------------------------------
 
 SET V_CADENA = ''; 
 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN(Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada'; 
 
 --------------------
 -- Ejecuta cadena
 --------------------
 
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Actualizar estadisticas a la tabla tmp_DireFisica_Estandarizada' ,V_ERROR);
 SET P_ERROR = V_ERROR;
  IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1;
 END IF;

 ------------------------------------------------------------
 -- Cursor de reglas para ETAPA IN (2)
 -- Reglas de limpieza basadas en patrones de texto
 ------------------------------------------------------------
 SET V_CADENA = 'SELECT	Sentencia
						,Condicion
						,Flag_Recursiva
						,Cod_DW_Regla_Est_Ubica
					FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
					WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
							select Cod_DW_Atributo
							from '|| P_BDDATOS ||'.ATRIBUTO
							where Cod_DW_Tipo_Atributo in (
								select Cod_DW_Tipo_Atributo
								from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
								where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
							) AND Valor_Origen = ''Geografica''
						) AND  Flag_Activo = ''S'' AND ETAPA IN (2)
					ORDER BY Orden'; 
					
 SET V_Contador = 0;
 PREPARE the_statement FROM V_CADENA; 
 OPEN cur_reglas_select; CUR1: 
 LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; 
   IF SQLCODE <> 0 THEN LEAVE CUR1; 
 END IF; ---  Ini HAH
 
 SET V_FECHA_HORA_INI = CAST(CURRENT_TIMESTAMP AS TIMESTAMP(6)); --- Fin HAH
 
 SET V_Contador = V_Contador +1;
 
 SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
				SET ' || V_Sentencia || '
					, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
				WHERE ' || V_Condicion ; 			
  
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 						
								 ,V_StartTimeStampPadre 
								 ,:P_Nombre_Proceso_Padre 
								 ,:V_CADENA 
								 ,'PRO_StandardizationGeografica(2.1):'||' Ejecucion de reglas 2 iteracion: '||trim(V_Contador)||' Regla:'||trim(V_Cod_DW_Regla_Est_Ubica) 
								 ,V_ERROR); 
 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 
  THEN LEAVE CUR1; 
 END IF; 
 END LOOP CUR1; 
 CLOSE cur_reglas_select; 
  
 IF CHARACTER_LENGTH(V_ERROR) > 0 
  THEN LEAVE L1; 
 END IF; 
 
 --------------------------------------------------------------
 -- Reemplaza Toponimos
 -- Busca y borra si existe la tabla tmp_DireFisica_Topo_a
 --------------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Topo_a' ;
 IF ACTIVITY_COUNT > 0 THEN 
   SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo_a';
   CALL DBC.SysExecSQL(:V_CADENA);
 END IF;
   
 SET V_CADENA = '';
 SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_a
				 AS
				(
					SELECT	a.Cod_DW_Reporte_Ubic_Original
						,CASE WHEN b.Valor IS NULL
								THEN Ubicacion_Stand
							  ELSE OREPLACE(Ubicacion_Stand, b.Valor, b.Normalizado)
						END Ubicacion_Stand
						,a.Ciudad
						,a.Codigo_Ciudad_Dane
						,a.Tipo_Direccion
					FROM  (
						select *
						from '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
						qualify row_number() over(partition by Cod_DW_Reporte_Ubic_Original
								order by Cod_DW_Reporte_Ubic_Original) = 1
						) a
					LEFT JOIN (
						SELECT   P.Valor
							,P.Normalizado
						FROM '|| P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
							INNER JOIN '|| P_BDDATOS ||'.TIPO_PARAMETRO AS TP
							ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
							INNER JOIN  '|| P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
							ON  TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
							INNER JOIN '|| P_BDDATOS ||'.PARAMETRO AS P
							ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
						WHERE   GP.Nombre_Grupo_Parametro = ''TOPONIMOS''
								  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
						  ) b
						   ON a.Ubicacion_Stand like ''%'' || b.Valor || ''%''
				) WITH DATA
				PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; 
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Crea la tabla tmp_DireFisica_Topo_a' ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 
  THEN LEAVE L1; 
 END IF; 
 ------------------------------------------------------------
 -- Actualiza estadisticas a tmp_DireFisica_Estandarizada
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_a'; 
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo_a' ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 
  THEN LEAVE L1; 
 END IF; 
 ------------------------------------------------------------
 -- Busca y borra si existe la tabla tmp_DireFisica_Topo
 ------------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Topo' ; 
 IF ACTIVITY_COUNT > 0 THEN 
   SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo'; 
   CALL DBC.SysExecSQL(:V_CADENA); 
 END IF; 
 ------------------------------------------------------------
 -- Se crea y carga la tabla tmp_DireFisica_Topo
 -- Separacion del texto de la direccion en palabras
 ------------------------------------------------------------
 SET V_CADENA = ''; 
 SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo
				 AS (
				 WITH RECURSIVE Text_Dir_Palabras
				 (Cod_DW_Reporte_Ubic_Original
				 ,ID_S
				 ,POS
				 ,PALABRA
				 ,Ubicacion_Stand
				 ,Ciudad
				 ,Codigo_Ciudad_Dane
				 ,Tipo_Direccion
				) AS
				(
					SELECT Cod_DW_Reporte_Ubic_Original
						,0
						,0
						, cast('''' as varchar(100))
						,Ubicacion_Stand  
						,Ciudad
						,Codigo_Ciudad_Dane
						,Tipo_Direccion
					from '||P_BDSTAGE || '.tmp_DireFisica_Topo_a
					UNION ALL
					SELECT Cod_DW_Reporte_Ubic_Original
						,ID_S+1
						,CASE WHEN POSITION('' '' IN Ubicacion_Stand) > 0
								THEN POSITION('' '' IN Ubicacion_Stand)
							 ELSE CHARACTER_LENGTH(Ubicacion_Stand)
						END POS1
						,TRIM(BOTH '' '' FROM SUBSTR(Ubicacion_Stand, 0, POS1+1))
						,TRIM(SUBSTR(Ubicacion_Stand, POS1+1))
						,Ciudad
						,Codigo_Ciudad_Dane
						,Tipo_Direccion
					FROM Text_Dir_Palabras
					WHERE POS1 > 0
				)
				SELECT Cod_DW_Reporte_Ubic_Original
					,ID_S
					,PALABRA 
					,Ciudad
					,Codigo_Ciudad_Dane
					,Ubicacion_Stand
					,Tipo_Direccion
				FROM Text_Dir_Palabras
				WHERE ID_S > 0
				
				) WITH DATA
				PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)'; 

 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (3):. Crear y carga la tabla tmp_DireFisica_Topo' ,V_ERROR); 
  
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 
    THEN LEAVE L1; 
 END IF;
 ------------------------------------------------------------
 -- Actualiza estadisticas a tmp_DireFisica_Topo
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo';
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (4):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo' ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 
  THEN LEAVE L1;
 END IF; /*
		BEGIN ETAPA TOPONIMO
		begin tmp_DireFisica_Topo
		*/ 
 -----------------------------------------------------------
 -- Busca y borra si existe la tabla tmp_DireFisica_Topo_II
 -----------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Topo_II' ; 
 IF ACTIVITY_COUNT > 0 THEN 
  SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo_II';
  CALL DBC.SysExecSQL(:V_CADENA); 
 END IF; 
 ---------------------------------------------------------------------------------------
 -- Se crea y carga la tabla tmp_DireFisica_Topo_II
 -- Se aplican acepciones y no existe, se llama la funcion GENACCEPAUT para
 --  intentar crearla
 ---------------------------------------------------------------------------------------
 SET V_CADENA = ''; 
 SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II
				AS (
				SELECT	A.Cod_DW_Reporte_Ubic_Original
				,A.ID_S
				,CASE WHEN ACEP.Valor IS NULL
						AND ' || P_BDVISTA || '.VALIDATE_EXPRESSION_R(A.PALABRA, ''^[A-Za-z]{3,20}*$'')=1
						AND A.PALABRA IS NOT NULL
						AND ACEP.Valor IS NULL
					THEN ' || P_BDVISTA || '.GENACCEPAUT(A.PALABRA, SOUNDEX(A.PALABRA))
				END NEW_ACEPCION
				,CASE WHEN ACEP.Valor IS NOT NULL
					THEN ACEP.Normalizado
					  WHEN NEW_ACEPCION IS NOT NULL AND CHAR(NEW_ACEPCION) <> 0
					THEN NEW_ACEPCION
					  ELSE A.PALABRA
				END PALABRA
				,A.Ubicacion_Stand
				,A.PALABRA PALABRA_ORI
				,A.Ciudad
				,A.Codigo_Ciudad_Dane
				,A.Tipo_Direccion
				FROM ' || P_BDSTAGE ||'.tmp_DireFisica_Topo A
				LEFT JOIN (
				SELECT	P.Valor
					,P.Normalizado
				FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
				INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
					ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
				INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
					ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
				INNER JOIN ' || P_BDDATOS ||'.PARAMETRO AS P
					ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
				WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
						  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
					) ACEP
				ON TRIM(A.PALABRA) = ACEP.Valor /*#1*/
				) WITH DATA
				PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)'; 
 
  CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (5):. Crear y carga la tabla tmp_DireFisica_Topo_II' ,V_ERROR); 
  SET P_ERROR = V_ERROR; 
  IF CHARACTER_LENGTH(V_ERROR) > 0 
   THEN LEAVE L1; 
  END IF; 
  ------------------------------------------------------------
 -- Actualiza estadisticas a tmp_DireFisica_Topo
 -------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II'; 
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (6):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo_II' ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0  
  THEN LEAVE L1;
 END IF; 
 ------------------------------------------------------------
 -- Inserta las nuevas acepciones en parametros
 ------------------------------------------------------------
 SET V_CADENA = ''; 
 SET V_CADENA = 'INSERT INTO ' || P_BDDATOS ||'.PARAMETRO
				SELECT	P.Cod_DW_Parametro + SUM( 1 ) OVER (ROWS UNBOUNDED PRECEDING) Cod_DW_Parametro
					,A.PALABRA_ORI Valor
					,A.PALABRA Normalizado
					,'|| P_Lote || '
					,NULL
					,1
					,USER
					,STP1.Cod_DW_Subtipo_Parametro
					,NULL
					,date
				FROM (SELECT *
					FROM ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II
					WHERE NEW_ACEPCION IS NOT NULL AND CHAR(NEW_ACEPCION) <> 0
					QUALIFY ROW_NUMBER() OVER(PARTITION BY PALABRA_ORI, PALABRA ORDER BY PALABRA_ORI) = 1
				   ) A
				CROSS JOIN (
					SELECT STP.Cod_DW_Subtipo_Parametro
					FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
					INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
						ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
					INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
						ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
					WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
				
						  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
					) STP1
				CROSS JOIN (SELECT MAX(Cod_DW_Parametro) Cod_DW_Parametro
						FROM ' || P_BDDATOS ||'.PARAMETRO
					) P
				LEFT JOIN (
					SELECT    P.Valor
						,P.Normalizado
						FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
						INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
						ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
						INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
						ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
						INNER JOIN ' || P_BDDATOS ||'.PARAMETRO AS P
						ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
						WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
							  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
				  ) EXT
					ON EXT.Valor = 			trim(A.PALABRA_ORI) /*#1*/
					AND EXT.Normalizado = 	trim(A.PALABRA) /*#1*/
				WHERE EXT.Valor IS NULL'; 
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (7):. Inserta las nuevas acepciones en PARAMETRO' ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 
  THEN LEAVE L1; 
 END IF; 
 ---------------------------------------------------------
 -- Actualiza estadisticas a paramtros
 ---------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Parametro) ON ' || P_BDDATOS ||'.PARAMETRO'; 
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (8):. Actualizar estadisticas a la tabla PARAMETRO' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; /*end tmp_DireFisica_Topo_II
		*/ /*
		END ETAPA TOPONIMO
		*/ 
 ------------------------------------------------------------
 -- Busca y borra si existe la tabla tmp_DireFisica_TopoUpd
 ------------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_TopoUpd' ;
 IF ACTIVITY_COUNT > 0 THEN 
  SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd';
  CALL DBC.SysExecSQL(:V_CADENA);
 END IF;
 ------------------------------------------------------------
 -- Se crea y carga la tabla tmp_DireFisica_TopoUpd
 -- Rearma la direccion
 ------------------------------------------------------------
 SET V_CADENA = ''; 
 SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_TopoUpd
	AS (
	WITH RECURSIVE Text_Dir_PalabrasT
	(Cod_DW_Reporte_Ubic_Original
	,ID_S
	,PALABRA
	,Ubicacion_Stand
	,Ciudad
	,Codigo_Ciudad_Dane
	,Reglas
	,Tipo_Direccion
	) AS
	(
	SELECT Cod_DW_Reporte_Ubic_Original
		,ID_S
		,PALABRA
		,CAST(PALABRA AS VARCHAR(500)) Ubicacion_Stand     
		,Ciudad
		,Codigo_Ciudad_Dane
		,CAST('''' AS VARCHAR(50)) as Reglas
		,Tipo_Direccion
	from '||P_BDSTAGE || '.tmp_DireFisica_Topo_II
	QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
					ORDER BY ID_S ASC) = 1
	UNION ALL
	SELECT A.Cod_DW_Reporte_Ubic_Original
		,B.ID_S
		,B.PALABRA
		,nvl(A.Ubicacion_Stand,'''') || '' '' || nvl(B.PALABRA,'''') /*#2*/
		,B.Ciudad
		,B.Codigo_Ciudad_Dane
		,CAST('''' AS VARCHAR(50)) as Reglas
		,B.Tipo_Direccion
	FROM '||P_BDSTAGE || '.tmp_DireFisica_Topo_II B
	INNER JOIN Text_Dir_PalabrasT A
		ON A.Cod_DW_Reporte_Ubic_Original = B.Cod_DW_Reporte_Ubic_Original
		AND (A.ID_S + 1) = B.ID_S
	WHERE B.ID_S IS NOT NULL
	)
	SELECT Cod_DW_Reporte_Ubic_Original
	,Ubicacion_Stand
	,Ciudad
	,Codigo_Ciudad_Dane
	,Reglas
	,Tipo_Direccion
	FROM Text_Dir_PalabrasT
	QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
				ORDER BY ID_S DESC, Ubicacion_Stand DESC) = 1
	
	) WITH DATA
	PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; 
	
   CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (9):. Crear y carga la tabla tmp_DireFisica_TopoUpd' ,V_ERROR); 
   SET P_ERROR = V_ERROR; 
   IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
    LEAVE L1;
   END IF; 
  ----------------------------------------------------
  -- Actualiza estadisticas a tmp_DireFisica_TopoUpd
  ----------------------------------------------------
  SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN (Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_DireFisica_TopoUpd'; 
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (10):. Actualizar estadisticas a la tabla tmp_DireFisica_TopoUpd' ,V_ERROR);
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
  LEAVE L1; 
 END IF; 
 ------------------------------------------------------------------------------------
 -- Cursor de reglas para ETAPA IN (5)
 -- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones
 ------------------------------------------------------------------------------------
 SET V_CADENA = 'SELECT  Sentencia
				,Condicion
				,Flag_Recursiva
				,Cod_DW_Regla_Est_Ubica
				
			FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
			WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
					select Cod_DW_Atributo
					from '|| P_BDDATOS ||'.ATRIBUTO
					where Cod_DW_Tipo_Atributo in (
						select Cod_DW_Tipo_Atributo
						from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
						where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
					) AND Valor_Origen = ''Geografica''
				) AND  Flag_Activo = ''S'' AND ETAPA IN (5)
			ORDER BY Orden'; 
			
SET V_Contador = 0;
PREPARE the_statement FROM V_CADENA; 
OPEN cur_reglas_select; 			
CUR2: LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; 
IF SQLCODE <> 0 THEN 
   LEAVE CUR2; 
END IF;  
  
  SET V_Contador = V_Contador +1;  
  
  SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
					SET ' || V_Sentencia || '
						, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
					WHERE    ' || V_Condicion ||' AND Ubicacion_Stand  IS NOT NULL /*#3*/ '; 
 
 
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 						
								 ,V_StartTimeStampPadre 
								 ,:P_Nombre_Proceso_Padre 
								 ,:V_CADENA 
								 ,'PRO_StandardizationGeografica(10.1):'||' Ejecucion de reglas 5 iteracion: '||trim(V_Contador)||' Regla:'||trim(V_Cod_DW_Regla_Est_Ubica) 
								 ,V_ERROR); 
								 
SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 
  THEN LEAVE CUR2; 
 END IF; 
 
END LOOP CUR2;
CLOSE cur_reglas_select;

 IF CHARACTER_LENGTH(V_ERROR) > 0 
   THEN LEAVE L1;
 END IF;
 --------------------------------------------------------------------------------------
 -- Se ordenan las particulas en formato DANE con la funcion ADDRESS_NORMALIZATION
 -- esta funcion develve una serie de campos donde el ultimo se emplea para tipificar
 -- la direccion  como valida, invalida  
 -- Busca y borra si existe la tabla tmp_DireFisica_Nor
 --------------------------------------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DireFisica_Nor' ;
 IF ACTIVITY_COUNT > 0 THEN 
  SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Nor'; 
  CALL DBC.SysExecSQL(:V_CADENA); 
 END IF; 
 
 SET V_CADENA = ''; 
 
 SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Nor
					AS
					(
					SELECT	Cod_DW_Reporte_Ubic_Original
						,Ubicacion_Stand
						,'|| P_BDVISTA ||'.ADDRESS_NORMALIZATION(oreplace(Ubicacion_Stand,''?'', ''''), Ciudad, 300, COALESCE(Codigo_Ciudad_Dane, ''''), Tipo_Direccion) ADDR_NORM
						,Ciudad
						,Codigo_Ciudad_Dane
					FROM '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
					) WITH DATA
					PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; 
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; 
 ------------------------------------------------------------
 -- Actualiza estadisticas a tmp_DireFisica_Nor
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Nor'; 
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (12):. Actualizar estadisticas a la tabla tmp_DireFisica_Nor' ,V_ERROR);
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 
   THEN LEAVE L1;
 END IF;
 ------------------------------------------------------------------------------------------------------------
 -- Genera posibles direcciones para las direcciones marcadas como ""X VALIDAR VIAS"" y ""NO VALIDA"" 
 --
 -- Busca y borra si existe la tabla tmp_Direcc_No_Validas
 ------------------------------------------------------------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Direcc_No_Validas' ; 
 IF ACTIVITY_COUNT > 0 THEN 
  SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Direcc_No_Validas';
   CALL DBC.SysExecSQL(:V_CADENA); 
 END IF; 

 SET V_CADENA = ''; 
 
 SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas
				AS
				(
				SELECT	Cod_DW_Reporte_Ubic_Original
					,Ubicacion_Stand
					,Codigo_Ciudad_Dane
				FROM '||P_BDSTAGE || '.tmp_DireFisica_Nor
				WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''NO VALIDA 2''
				) WITH DATA
				PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; 
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (13):. Crea la tabla tmp_Direcc_No_Validas' ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 
  THEN LEAVE L1;
 END IF;
 ----------------------------------------------------------------------------------------------
 -- Procesa las direcciones marcadas como ""X VALIDAR VIAS"" y genera un registro por cada una 
 --
 -- Busca y borra si existe la tabla tmp_Direcc_X_Validar_Vias
 ----------------------------------------------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Direcc_X_Validar_Vias' ;
 IF ACTIVITY_COUNT > 0 THEN
      SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Direcc_X_Validar_Vias'; 
	  CALL DBC.SysExecSQL(:V_CADENA);  
  END IF; 
  
  SET V_CADENA = ''; 
  SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias
				 AS
				(
				WITH RECURSIVE New_Direc
				 (Cod_DW_Reporte_Ubic_Original
				 ,ID_S
				 ,Direc_New
				 ,Dir
				 ,Ubicacion_Stand
				 ,Codigo_Ciudad_Dane
				) AS
				(
					SELECT Cod_DW_Reporte_Ubic_Original
						,0 ID_S
						, CAST(NULL AS VARCHAR(100))Direc_New
						, '|| P_BDVISTA ||'.DESC_ADDRESS_MORE_ADDRESS(Ubicacion_Stand, Ciudad, 300, Codigo_Ciudad_Dane) Dir
						, Ubicacion_Stand
						,Codigo_Ciudad_Dane
					from '||P_BDSTAGE || '.tmp_DireFisica_Nor
					WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''X VALIDAR VIAS''
					UNION ALL
					SELECT Cod_DW_Reporte_Ubic_Original
						,ID_S+1 ID_S1
						,'|| P_BDVISTA ||'.eListGetValByIdx(DIR, ''/'', ID_S1) Direc_New1
						, DIR
						,Ubicacion_Stand
						,Codigo_Ciudad_Dane
					FROM New_Direc
					WHERE Direc_New1 is not null
				)
				SELECT	Cod_DW_Reporte_Ubic_Original
					,ID_S
					,Ubicacion_Stand
					,Direc_New
					,Codigo_Ciudad_Dane
				FROM New_Direc
				WHERE Direc_New is not null
				
				
				) WITH DATA
				PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)';
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (14):. Crea la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 
   THEN LEAVE L1;
 END IF; 
 ------------------------------------------------------------
 -- Actualiza estadisticas a tmp_Direcc_X_Validar_Vias
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias';
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (15):. Actualizar estadisticas a la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 
  THEN LEAVE L1; 
 END IF;
 -------------------------------------------------------------------
 -- Marca si alguna de la direcciones puede ser tenia como valida -- 
 ------------------------------------------------------------------- 
 ----------------------------------------------- INICIO AJUSTE #5 -----------------------------------------------
SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Direcc_X_Validar_Vias1' ;

IF ACTIVITY_COUNT > 0 THEN 
 SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Direcc_X_Validar_Vias1';
 CALL DBC.SysExecSQL(:V_CADENA);
END IF;

SET V_CADENA = 'CREATE MULTISET TABLE REC_STAGE.tmp_Direcc_X_Validar_Vias1 AS (
				SELECT Cod_DW_Reporte_Ubic_Original  
				 ,ID_S                          
				 ,Ubicacion_Stand               
				 ,Direc_New                     
				 ,Codigo_Ciudad_Dane            
				 ,TRIM(REC_VISTA.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) AS DirFun_2
				 ,TRIM(REC_VISTA.eListGetValByIdx(Dir.Direc_New, ''&'', 1)) AS DirFun_1
				FROM '||P_BDSTAGE || '.tmp_Direcc_X_Validar_Vias  DIR  
				) WITH DATA;'; 

CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (16):. Crea la tabla tmp_DirVal_X_Validar_Vias1' ,V_ERROR);

SET P_ERROR = V_ERROR;

IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
 LEAVE L1;
END IF;

SET V_CADENA = 'COLLECT STATISTICS COLUMN (DIRFUN_2) ,COLUMN (DIRFUN_1) ,INDEX (COD_DW_REPORTE_UBIC_ORIGINAL)   ON   REC_STAGE.tmp_Direcc_X_Validar_Vias1;';
CALL DBC.SysExecSQL(:V_CADENA);

SET V_CADENA = 'COLLECT STATISTICS COLUMN (COD_DW_TIPO_UBICACION) ON REC_STAGE.tmp_DireFisica_Estandarizada;';
CALL DBC.SysExecSQL(:V_CADENA);

SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_DirVal_X_Validar_Vias' ;

IF ACTIVITY_COUNT > 0 THEN 
 SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DirVal_X_Validar_Vias';
 CALL DBC.SysExecSQL(:V_CADENA);
END IF;

SET V_CADENA = 'CREATE MULTISET TABLE REC_STAGE.tmp_DirVal_X_Validar_Vias
				 AS
				(
				SELECT	Dir.Cod_DW_Reporte_Ubic_Original
					,Dir.Ubicacion_Stand
					,Dir.Direc_New
					,CASE WHEN (VUE.Flag_Geo IS NOT NULL
								AND VUE.Flag_Geo = ''S''
								AND Dir.DirFun_2 <> ''''
								AND VDF.Cod_DW_Ubic IS NOT NULL)
							AND VRPU.Cod_DW_Ubic IS NOT NULL
						   THEN 1
						   WHEN (VUE.Flag_Geo IS NOT NULL
								AND VUE.Flag_Geo = ''S''
								AND Dir.DirFun_2 <> ''''
								AND VDF.Cod_DW_Ubic IS NOT NULL)
							OR VRPU.Cod_DW_Ubic IS NOT NULL
						   THEN 2
						   ELSE 3
					 END Ind_Val
					 ,Dir.Codigo_Ciudad_Dane
				
				FROM	REC_STAGE.tmp_Direcc_X_Validar_Vias1 Dir
				INNER JOIN REC_STAGE.tmp_DireFisica_Estandarizada TMP
					ON TMP.Cod_DW_Reporte_Ubic_Original = Dir.Cod_DW_Reporte_Ubic_Original
				LEFT JOIN REC_VISTA.V_Ubicacion_Estandarizada VUE
					ON DIR.DirFun_1 = VUE.Texto_Ubicacion
					AND TMP.Cod_DW_Tipo_Ubicacion = VUE.Cod_Dw_Tipo_Ubicacion 
				LEFT JOIN REC_VISTA.V_DIRECCION_FISICA VDF
					ON VUE.Cod_DW_Ubic = VDF.Cod_DW_Ubic
					AND DIR.DirFun_2 = VDF.Complemento
				LEFT JOIN REC_VISTA.V_RELACION_PERSONA_UBICACION VRPU
					ON VUE.Cod_DW_Ubic = VRPU.Cod_DW_Ubic
					
				QUALIFY ROW_NUMBER() OVER(PARTITION BY Dir.Cod_DW_Reporte_Ubic_Original, Dir.Direc_New
							ORDER BY Dir.Cod_DW_Reporte_Ubic_Original) = 1
				
				) WITH DATA
				PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original);' ;

	CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (17):. Crea la tabla tmp_DirVal_X_Validar_Vias' ,V_ERROR); 
	
	SET P_ERROR = V_ERROR; 
	IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
	 LEAVE L1; 
	 END IF;
 ------------ FIN AJUSTE #5 ---------------------------------
 -- Actualiza estadisticas a tmp_Direcc_No_Validas
 ------------------------------------------------------------
 SET V_CADENA = ''; 
 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias';
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (17):. Actualizar estadisticas a la tabla tmp_DirVal_X_Validar_Vias' ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
  LEAVE L1; 
 END IF; 
 ------------------------------------------------------------------------------------------------------------------------
 -- Completa las direcciones no validas en tmp_Direcc_No_Validas con las direcciones que no se pudieron clasificar
 ------------------------------------------------------------------------------------------------------------------------
 SET V_CADENA = ''; 
 SET V_CADENA = 'INSERT INTO ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas
				SELECT	DISTINCT
				Cod_DW_Reporte_Ubic_Original
				,Ubicacion_Stand
				,Codigo_Ciudad_Dane
				FROM	' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias A
				WHERE Ind_Val = 3
				AND NOT EXISTS (
					SELECT 1
					FROM ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias B
					WHERE A.Cod_DW_Reporte_Ubic_Original = B.Cod_DW_Reporte_Ubic_Original
					AND B.Ind_Val in (1,2)
				)';
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (18):. Completa direcciones invalidas en tmp_Direcc_No_Validas' ,V_ERROR); 
 SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; 
 ------------------------------------------------------------
 -- Actualiza estadisticas a tmp_Direcc_No_Validas
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas'; 
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (19):. Actualizar estadisticas a la tabla tmp_Direcc_No_Validas' ,V_ERROR); 
 SET P_ERROR = V_ERROR;
 IF CHARACTER_LENGTH(V_ERROR) > 0 
  THEN LEAVE L1;
 END IF;
 ------------------------------------------------------------
 -- Une todas las direcciones validas en tmp_Dire_Estan_Val
 -- Busca y borra si existe la tabla tmp_Dire_Estan_Val
 ------------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'tmp_Dire_Estan_Val' ;
 IF ACTIVITY_COUNT > 0 THEN 
  SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Dire_Estan_Val';
  CALL DBC.SysExecSQL(:V_CADENA);
 END IF;
 SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val
					AS (
					SELECT	Cod_DW_Reporte_Ubic_Original
						,oreplace(ADDR_NORM, ''NO VALIDA 2'',''NO VALIDA'') ADDR_NORM
						,Codigo_Ciudad_Dane
						,Ubicacion_Stand
					FROM '||P_BDSTAGE || '.tmp_DireFisica_Nor
					WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) <> ''X VALIDAR VIAS''
					UNION ALL
					SELECT	Cod_DW_Reporte_Ubic_Original
						,OREPLACE(OREPLACE(Direc_New, ''NO VALIDA 2'', ''VALIDA''), ''NO VALIDA'', ''VALIDA'')  Direc_New
						,Codigo_Ciudad_Dane
						,Ubicacion_Stand
					FROM '||P_BDSTAGE || '.tmp_DirVal_X_Validar_Vias
					QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
									ORDER BY Ind_Val) = 1
					
					) WITH DATA
					PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (20):. Crea la tabla tmp_Dire_Estan_Val' ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
  LEAVE L1; 
 END IF; 
 ------------------------------------------------------------
 -- Actualiza estadisticas a tmp_Dire_Estan_Val
 ------------------------------------------------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val'; 
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (21):. Actualizar estadisticas a la tabla tmp_Dire_Estan_Val' ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 
  THEN LEAVE L1;
 END IF;
 ---------------------------------------------------------------------
 -- Busca y borra si existe la tabla DireccionFisica_Estandarizada
 ---------------------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'DireccionFisica_Estandarizada' ; 
 IF ACTIVITY_COUNT > 0 THEN 
  SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.DireccionFisica_Estandarizada'; 
 CALL DBC.SysExecSQL(:V_CADENA); END IF; 
 ------------------------------------------------------------------------------------------------------------------------
 -- Unifica los datos de acuerdo Cod_DW_Reporte_Ubic_Original, el resultado en DireccionFisica_Estandarizada
 -- Se normaliza y ordena el texto de la direccion con la funcion ADDRESS_NORMALIZATION
 ------------------------------------------------------------------------------------------------------------------------
 SET V_CADENA = ''; 
 SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.DireccionFisica_Estandarizada
				 AS (
					SELECT	dir.Cod_DW_Reporte_Ubic_Original
						,dir.Texto_Ubicacion_Original
						,coalesce(Est.Ubicacion_Stand, ''SV'')  Ubicacion_Stand_ant
						,dir.Cod_DW_Tipo_Ubicacion
						,dir.Cod_DW_Fuente
						,dir.Lote
						,dir.Id_Buro_Suscriptor
						,dir.Id_Buro_Persona
						,dir.Cod_DW_Cta
						,dir.Cod_DW_Hash
						,dir.Cod_DW_Ubic
						,dir.Valor
						,dir.Ciudad Texto_Ciudad
						,dir.Codigo_Ciudad_Dane
						,dir.Fecha_Reporte
						
						,dir.Cod_DW_Ubicacion_Original
						,dir.Cod_DW_Tipo_Ubicacion_Dir
						,dir.Usuario_BD
						
						,CASE WHEN Est.Cod_DW_Reporte_Ubic_Original IS NULL
																		   THEN dir.Texto_Ubicacion_Original
																		   ELSE COALESCE( NULLIF(TRIM( '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1)),''''), dir.Texto_Ubicacion_Original) --#4
														   END DIRE_GEO
						
						
						,TRIM(CAST('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 2) AS VARCHAR(4096))) DIRE_COMPLEMENTO
						,TRIM(CAST('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 3) AS VARCHAR(4096))) DIR_TIPO_DIRE
						,TRIM(CAST(CASE WHEN Est.Cod_DW_Reporte_Ubic_Original IS NULL
						 THEN dir.Tipo_Direccion
						 ELSE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 4)
						END AS VARCHAR(4096))) DIR_TIPOVIA
						,TRIM(CAST('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 5) AS VARCHAR(4096))) DIR_NUMVIAPPAL
						,TRIM(CAST('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 6) AS VARCHAR(4096))) DIR_NUMVIAGEN
						,TRIM(CAST('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 7) AS VARCHAR(4096))) DIR_NUMPLACA
						,TRIM(CAST(CASE WHEN Est.Cod_DW_Reporte_Ubic_Original IS NULL
						  OR '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1) IS NULL
						  OR '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1) = ''''
						 THEN ''NO VALIDA''
						 ELSE COALESCE ('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8),''NO VALIDA'') /*#6*/
						END AS VARCHAR(4096))) DIR_CB_VALIDA
						,TRIM(CAST(CASE WHEN Est.Cod_DW_Reporte_Ubic_Original IS NULL
						  OR '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1) IS NULL
						  OR '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1) = ''''
						 THEN dir.Texto_Ubicacion_Original || ''&&''|| dir.Tipo_Direccion ||''&&&&&NO VALIDA''
						 ELSE COALESCE(ADDR_NORM, dir.Ubicacion_Stand)
						END AS VARCHAR(4096))) Ubicacion_Stand
						,CAST('''' AS VARCHAR(20)) Reglas
					FROM	' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada dir
					LEFT JOIN ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val Est
						ON dir.Cod_DW_Reporte_Ubic_Original = Est.Cod_DW_Reporte_Ubic_Original
					QUALIFY ROW_NUMBER() OVER(PARTITION BY dir.Cod_DW_Reporte_Ubic_Original
								ORDER BY dir.Cod_DW_Reporte_Ubic_Original) = 1
				) WITH DATA
				PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; 
				
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (22):. Crear y carga la tabla DireccionFisica_Estandarizada' ,V_ERROR); 
 
 SET P_ERROR = V_ERROR;  
 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
   LEAVE L1;
 END IF;
 ------------------------------------------------------------
 -- Actualiza estadisticas a tmp_DireFisica_Estand_Topo
 ------------------------------------------------------------
 SET V_CADENA = ''; 
 SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original ) ON ' || P_BDSTAGE ||'.DireccionFisica_Estandarizada';
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (8):. Actualizar estadisticas a la tabla DireccionFisica_Estandarizada' ,V_ERROR);
 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
   LEAVE L1;
 END IF; 
 ------------------------------------------------------------
 -- Creando Tabla TMP_DirecionFisica_Complemento
 ------------------------------------------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'TMP_DirecionFisica_Complemento' ; 
 
 IF ACTIVITY_COUNT > 0 THEN 
  SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.TMP_DirecionFisica_Complemento'; 
  CALL DBC.SysExecSQL(:V_CADENA); 
 END IF; 
 
 SET V_CADENA = ''; 
 SET V_CADENA = 'Create Multiset table '||P_BDSTAGE || '.TMP_DirecionFisica_Complemento
				AS
				(Select  Dire_Complemento, '||P_BDVISTA || '.SetComplement( Dire_Complemento) Complemento_Ajustado
				From '||P_BDSTAGE || '.DireccionFisica_Estandarizada
				Where Dire_Complemento is not null
				AND Dire_Complemento <> Complemento_Ajustado
				Group by 1,2
				)With Data 
				Primary Index(Dire_Complemento);'; 
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (9):. creando la tabla TMP_DirecionFisica_Complemento' ,V_ERROR); 
 SET P_ERROR = V_ERROR;
 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
   LEAVE L1; 
 END IF; 
 
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'TMP_DirecionFisica_Complemento' ; 
 IF ACTIVITY_COUNT > 0 THEN 
  SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.TMP_DirecionFisica_Complemento';   
  CALL DBC.SysExecSQL(:V_CADENA); 
 END IF; 
 
 SET V_CADENA = '';
 SET V_CADENA = 'Create Multiset table '||P_BDSTAGE || '.TMP_DirecionFisica_Complemento
				AS
				(Select  Dire_Complemento, '||P_BDVISTA || '.SetComplement( Dire_Complemento) Complemento_Ajustado
				From '||P_BDSTAGE || '.DireccionFisica_Estandarizada
				Where Dire_Complemento is not null
				AND Dire_Complemento <> Complemento_Ajustado
				Group by 1,2
				)With Data 
				Primary Index(Dire_Complemento);'; 
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (9.1):. creando la tabla TMP_DirecionFisica_Complemento' ,V_ERROR); 
 
 SET P_ERROR = V_ERROR;
 IF CHARACTER_LENGTH(V_ERROR) > 0 
   THEN LEAVE L1; END IF; 
 SET V_CADENA = ''; 
 SET V_CADENA = 'COLLECT STAT  INDEX(Dire_Complemento) ON '||P_BDSTAGE || '.TMP_DirecionFisica_Complemento;';  
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (9.2):. Actualizar estadisticas a la tabla DireccionFisica_Estandarizada' ,V_ERROR); 
 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 
  THEN LEAVE L1;
 END IF; 
 ------------------------------------------------------------
 -- Actualizando Complemento 
 ------------------------------------------------------------
 SET V_CADENA = ''; 
 SET V_CADENA = 'Update '||P_BDSTAGE || '.DireccionFisica_Estandarizada
				From '||P_BDSTAGE || '.TMP_DirecionFisica_Complemento  
					   Set Dire_Complemento = Complemento_Ajustado 
				Where DireccionFisica_Estandarizada.Dire_Complemento = TMP_DirecionFisica_Complemento.Dire_Complemento;' ;
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (9.3):. Actualizar Dire_Complemento a la tabla DireccionFisica_Estandarizada' ,V_ERROR);  
 SET P_ERROR = V_ERROR;  
 IF CHARACTER_LENGTH(V_ERROR) > 0 
  THEN LEAVE L1;
 END IF;
 
 ------------------------------------------------------------
 -- Creando Tabla TMP_DirecionFisica_via_GtnRtro
 ------------------------------------------------------------

 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'TMP_DirecionFisica_via_GtnRtro' ; 
 IF ACTIVITY_COUNT > 0 THEN 
  SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.TMP_DirecionFisica_via_GtnRtro';   
  CALL DBC.SysExecSQL(:V_CADENA); 
 END IF;  

 SET V_CADENA = '';
 SET V_CADENA = 'CREATE MULTISET TABLE '||P_BDSTAGE || '.TMP_DirecionFisica_via_GtnRtro
				 AS 
				 ( SEL DIRE_GEO, DIR_CB_VALIDA, DIR_CB_VALIDA_AJUSTADO, Codigo_Ciudad_Dane
				   FROM  (SEL  DIRE_GEO, DIR_CB_VALIDA, Codigo_Ciudad_Dane,  CASE WHEN char(Codigo_Ciudad_Dane) > 1 AND REC_VISTA.ValidacionDirVia(DIRE_GEO,300) = 3 THEN  ''VALIDA ''   ELSE ''NO VALIDA''  END  DIR_CB_VALIDA_AJUSTADO
								FROM '||P_BDSTAGE || '.DireccionFisica_Estandarizada
								WHERE DIR_TIPO_DIRE = ''VIA''
							   GROUP BY 1,2,3,4)  A
				  QUALIFY ( ROW_NUMBER() OVER ( Partition by  DIRE_GEO, DIR_CB_VALIDA, Codigo_Ciudad_Dane Order by  DIR_CB_VALIDA_AJUSTADO DESC ) = 1 ) 			   
				 )WITH DATA 
				 PRIMARY INDEX ( DIRE_GEO, DIR_CB_VALIDA);'; 
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (10):. creando la tabla TMP_DirecionFisica_via_GtnRtro' ,V_ERROR);

 SET P_ERROR = V_ERROR; 
 
 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
  LEAVE L1; 
 END IF; 
 SET V_CADENA = '';  
 SET V_CADENA = 'COLLECT STAT  INDEX(DIRE_GEO, DIR_CB_VALIDA) ON '||P_BDSTAGE || '.TMP_DirecionFisica_via_GtnRtro;';  
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (10.1):. Actualizar estadisticas a la tabla TMP_DirecionFisica_via_GtnRtro' ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 
 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
  LEAVE L1;
 END IF; 
 ------------------------------------------------------------
 -- Actualizando Complemento 
 ------------------------------------------------------------
 SET V_CADENA = ''; 
 SET V_CADENA = 'Update '||P_BDSTAGE || '.DireccionFisica_Estandarizada
				From '||P_BDSTAGE || '.TMP_DirecionFisica_via_GtnRtro  
					   Set DIR_CB_VALIDA = DIR_CB_VALIDA_AJUSTADO 
				Where DireccionFisica_Estandarizada.DIRE_GEO = TMP_DirecionFisica_via_GtnRtro.DIRE_GEO
				AND DireccionFisica_Estandarizada.DIR_CB_VALIDA = TMP_DirecionFisica_via_GtnRtro.DIR_CB_VALIDA
				AND DireccionFisica_Estandarizada.Codigo_Ciudad_Dane =  TMP_DirecionFisica_via_GtnRtro.Codigo_Ciudad_Dane
				AND DireccionFisica_Estandarizada.DIR_TIPO_DIRE = ''VIA'';' ;
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (10.2):. Actualizar DIR_CB_VALIDA a la tabla DireccionFisica_Estandarizada' ,V_ERROR); 
 SET P_ERROR = V_ERROR;  
 IF CHARACTER_LENGTH(V_ERROR) > 0 
  THEN LEAVE L1; 
 END IF;  
 ------------------------------------------------------------
 -- Creando Tabla TMP_DirecionFisica_ral_GtnRtro
 ------------------------------------------------------------

 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'TMP_DirecionFisica_ral_GtnRtro' ; 
 IF ACTIVITY_COUNT > 0 THEN 
  SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.TMP_DirecionFisica_ral_GtnRtro';   
  CALL DBC.SysExecSQL(:V_CADENA); 
 END IF;  

 SET V_CADENA = '';
 SET V_CADENA = 'CREATE MULTISET TABLE '||P_BDSTAGE || '.TMP_DirecionFisica_ral_GtnRtro
				 AS 
				 (SEL  Cod_DW_Reporte_Ubic_Original
				       ,DIRE_GEO
				 	   ,CASE WHEN REC_VISTA.ValidacionDirRural(DIRE_GEO)  >= REC_VISTA.ValidacionDirRural(Ubicacion_Stand_ant) THEN  DIRE_GEO
                           ELSE   Ubicacion_Stand_ant
                        END DirRural_Definitiva
					   ,CASE WHEN REC_VISTA.ValidacionDirRural(DirRural_Definitiva) >  1 AND char(Codigo_Ciudad_Dane) > 1 THEN 
						 ''VALIDA''
						 ELSE ''NO VALIDA''		
					   END DIR_CB_VALIDA_AJUSTADO  
				   FROM '||P_BDSTAGE || '.DireccionFisica_Estandarizada
				   WHERE DIR_TIPO_DIRE = ''RURAL''				   
				 )WITH DATA 
				 PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original);'; 
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. creando la tabla TMP_DirecionFisica_ral_GtnRtro' ,V_ERROR);

 SET P_ERROR = V_ERROR; 
 
 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
  LEAVE L1; 
 END IF; 
 SET V_CADENA = '';  
 SET V_CADENA = 'COLLECT STAT  INDEX(Cod_DW_Reporte_Ubic_Original) ON '||P_BDSTAGE || '.TMP_DirecionFisica_ral_GtnRtro;';  
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11.1):. Actualizar estadisticas a la tabla TMP_DirecionFisica_ral_GtnRtro' ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 
 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
  LEAVE L1;
 END IF; 
 ------------------------------------------------------------
 -- Actualizando Complemento 
 ------------------------------------------------------------
 SET V_CADENA = ''; 
 SET V_CADENA = 'Update '||P_BDSTAGE || '.DireccionFisica_Estandarizada
				From '||P_BDSTAGE || '.TMP_DirecionFisica_ral_GtnRtro  
						   Set DIR_CB_VALIDA = DIR_CB_VALIDA_AJUSTADO,
							   DIRE_GEO = DirRural_Definitiva
				Where DireccionFisica_Estandarizada.Cod_DW_Reporte_Ubic_Original = TMP_DirecionFisica_ral_GtnRtro.Cod_DW_Reporte_Ubic_Original
				AND DireccionFisica_Estandarizada.DIR_TIPO_DIRE = ''RURAL'';';
 ------------------------------------------------------------
 -- Creando Tabla TMP_DirecionFisica_Mz_GtnRtro
 ------------------------------------------------------------

 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'TMP_DirecionFisica_Mz_GtnRtro' ; 
 IF ACTIVITY_COUNT > 0 THEN 
  SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.TMP_DirecionFisica_Mz_GtnRtro';   
  CALL DBC.SysExecSQL(:V_CADENA); 
 END IF;  

 SET V_CADENA = '';
 SET V_CADENA = 'CREATE MULTISET TABLE '||P_BDSTAGE || '.TMP_DirecionFisica_Mz_GtnRtro
				 AS 
				 (SEL  Cod_DW_Reporte_Ubic_Original
				       ,DIRE_GEO
				 	   ,CASE WHEN REC_VISTA.ValidacionDirMz(DIRE_GEO) >  2 AND char(Codigo_Ciudad_Dane) > 1 THEN 
						 ''VALIDA''
						 ELSE ''NO VALIDA''		
					   END DIR_CB_VALIDA_AJUSTADO  
				   FROM '||P_BDSTAGE || '.DireccionFisica_Estandarizada
				   WHERE DIR_TIPO_DIRE = ''MANZANA''				   
				 )WITH DATA 
				 PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original);'; 
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (12):. creando la tabla TMP_DirecionFisica_Mz_GtnRtro' ,V_ERROR);

 SET P_ERROR = V_ERROR; 
 
 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
  LEAVE L1; 
 END IF; 
 SET V_CADENA = '';  
 SET V_CADENA = 'COLLECT STAT  INDEX(Cod_DW_Reporte_Ubic_Original) ON '||P_BDSTAGE || '.TMP_DirecionFisica_Mz_GtnRtro;';  
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (12.1):. Actualizar estadisticas a la tabla TMP_DirecionFisica_Mz_GtnRtro' ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 
 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
  LEAVE L1;
 END IF; 
 ------------------------------------------------------------
 -- Actualizando Complemento 
 ------------------------------------------------------------
 SET V_CADENA = ''; 
 SET V_CADENA = 'Update '||P_BDSTAGE || '.DireccionFisica_Estandarizada
				From '||P_BDSTAGE || '.TMP_DirecionFisica_Mz_GtnRtro  
			      Set DIR_CB_VALIDA = DIR_CB_VALIDA_AJUSTADO							   
				Where DireccionFisica_Estandarizada.Cod_DW_Reporte_Ubic_Original = TMP_DirecionFisica_Mz_GtnRtro.Cod_DW_Reporte_Ubic_Original
				AND DireccionFisica_Estandarizada.DIR_TIPO_DIRE = ''MANZANA'';';
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES( :P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (12.2):. Actualizar DIR_CB_VALIDA a la tabla DireccionFisica_Estandarizada' ,V_ERROR); 
 SET P_ERROR = V_ERROR;  
 IF CHARACTER_LENGTH(V_ERROR) > 0 
  THEN LEAVE L1; 
 END IF; 
--------------------------------------------------------------------------------
 -- Cursor de reglas para ETAPA IN (6)
 -- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones
 -----------------------------------------------------------------------------------
 SET V_CADENA = 'SELECT	Sentencia
					,Condicion
					,Flag_Recursiva
					,Cod_DW_Regla_Est_Ubica
				FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
				WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
						select Cod_DW_Atributo
						from '|| P_BDDATOS ||'.ATRIBUTO
						where Cod_DW_Tipo_Atributo in (
							select Cod_DW_Tipo_Atributo
							from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
							where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
						) AND Valor_Origen = ''Geografica''
					) AND  Flag_Activo = ''S'' AND ETAPA IN (6)
				ORDER BY Orden'; 	

 SET V_Contador = 0;				
 
 PREPARE the_statement FROM V_CADENA; 
  OPEN cur_reglas_select; CUR3:LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; 
    IF SQLCODE <> 0 
	 THEN LEAVE CUR3; 
    END IF;---  Ini HAH
 
 SET V_Contador = V_Contador +1;
 SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.DireccionFisica_Estandarizada
				 SET ' || V_Sentencia || '
						, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
				 WHERE ' || V_Condicion;   
				 
		
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 						
								 ,V_StartTimeStampPadre 
								 ,:P_Nombre_Proceso_Padre 
								 ,:V_CADENA 
								 ,'PRO_StandardizationGeografica(13):'||' Ejecucion de reglas 6 iteracion: '||trim(V_Contador)||' Regla:'||trim(V_Cod_DW_Regla_Est_Ubica) 
								 ,V_ERROR); 					 
  
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 
  THEN LEAVE CUR3; 
 END IF; 
 
 END LOOP CUR3;  
 CLOSE cur_reglas_select; 
 
 END L1; 
 END;

REPLACE PROCEDURE REC_DATOS.PRO_StandardizationGeograficaO ( IN P_Lote INTEGER ,IN P_StartTimeStampPadre VARCHAR(20) ,IN P_Nombre_Proceso_Padre VARCHAR(30) ,IN P_BDDATOS VARCHAR(20) ,IN P_BDVISTA VARCHAR(20) ,IN P_BDSTAGE VARCHAR(20) ,OUT P_ERROR VARCHAR(32000) ) /*
 * ################################################################################
 * 
 * Objetivo:		Estandariza las direcciones fisicas como ubicacion del insumo
 *			InsumoDireccionFisica, dejando el resultado en DireccionFisica_Estandarizada
 * Fecha:		2016/11/09
 * Realizado por:	Luis E Ramirez
 * Proyecto:		Nuevo reconocer
 * Script:		PRO_StandardizationGeografica BCK 12 sept antes de a?adir campo de reglas a stg
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha	Objetivo				Realizado por
 * 2017/12/28	Agregar el codigo dane hasta la tabla	aariza - Capgemini
 *		DireccionFisica_Estandarizada
 * 2018/03/06	Se agrega el campo Tipo_Direccion y	Capgemini
 *		se elimina el calculo del cod dane	
 *
 * 2018/03/27	Los registros marcados como no validos	Capgemini
 *		y enviados a la tabla tmp_Dire_Estan_Val
 *		ya no se excluyen del proceso de
 *		estandarizacion
 * 2018-05-08 #1 ajuste por bug en teradata pruebas			Capgemini
 * 2018-05-09 #2 ajuste null por ubicación original y nvl
 							para armado de dirección						Capgemini

 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */ BEGIN ------------------------
-- Declaracion de variables
------------------------
 DECLARE V_StartTimeStampPadre TIMESTAMP(6); DECLARE V_ERROR VARCHAR(30); DECLARE V_CADENA VARCHAR(32000); DECLARE V_CADENA1 VARCHAR(10000); DECLARE Temp CHAR(30); DECLARE V_Sentencia VARCHAR(500); DECLARE V_Condicion VARCHAR(500); DECLARE V_Flag_Recursiva VARCHAR(1); DECLARE V_COUNT INTEGER; DECLARE V_Cod_DW_Regla_Est_Ubica INTEGER; DECLARE cur_reglas_select NO SCROLL CURSOR FOR the_statement; DECLARE cur_count_rec NO SCROLL CURSOR FOR the_statement_1; L1: BEGIN SET P_ERROR = ''; SET V_StartTimeStampPadre = Cast(P_StartTimeStampPadre AS TIMESTAMP(6) Format 'yyyy-mm-ddhh:mi:ss'); --SET V_StartTimeStampPadre =DATE;
 SET V_COUNT = 1; ---------------------------
 -- Busca y borra si existe la tabla tmp_EmailsEstandarizados
 ---------------------------
 SELECT TableName INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TableName = 'tmp_DireFisica_Estandarizada' ; IF Activity_Count > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
 -- Se crea y carga la tabla tmp_DireFisica_Estandarizada
 -- Se hace la primera limpieza de caracteres especiales en la ciudad y el texto de la direccion
 -----------------------------
 SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada
 AS (
SELECT	 dir.Cod_DW_Reporte_Ubic_Original
	,nvl(' || P_BDVISTA || '.REPLEXPREG( Ubicacion_Stand_Prev, ''[^A-Z^0-9^ ^-^. ' || 'D1'XC'F1'XC || ']'','' ''),Texto_Ubicacion_Original) as Ubicacion_Stand /*#2*/
	,dir.Texto_Ubicacion_Original
	,dir.Cod_DW_Tipo_Ubicacion
	,dir.Cod_DW_Fuente
	,dir.Lote
	,dir.Id_Buro_Suscriptor
	,dir.Id_Buro_Persona
	,dir.Cod_DW_Cta
	,dir.Cod_DW_Hash
	,dir.Cod_DW_Ubic
	,dir.Valor                               
	,GEO.Descripcion_Ciudad Ciudad
	,dir.Codigo_Ciudad_Dane 
	,dir.Fecha_Reporte
	
	,Cod_DW_Ubicacion_Original
	,Cod_DW_Tipo_Ubicacion_Dir
	,Usuario_BD
	,cast('''' as varchar(20)) Reglas
	,dir.Tipo_Direccion
FROM (
	SELECT	a.*
		,' || P_BDVISTA || '.REPL_CHRS  (UPPER(Texto_Ubicacion_Original), ''GEO'') Ubicacion_Stand_Prev
		,' || P_BDVISTA || '.REPL_CHRS  (TRIM(' || P_BDVISTA || '.REPLEXPREG(' || P_BDVISTA || '.REPLEXPREG( UPPER(Texto_Ciudad), ''^[A-Za-z ]?$''),''[ ]{2,100}'', '' '') ), ''GEO'') Texto_Ciudad_Prev 
	FROM ' || P_BDSTAGE ||'.InsumoDireccionFisica a ) dir
LEFT JOIN '|| P_BDVISTA ||'.V_Geografia GEO
	ON GEO.Cod_Dane_Ciudad = dir.Codigo_Ciudad_Dane

) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (1):. Crear y carga la tabla tmp_DireFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_Estandarizada
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN(Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Actualizar estadisticas a la tabla tmp_DireFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Cursor de reglas para ETAPA IN (2)
 -- Reglas de limpieza basadas en patrones de texto
 --------------------
 SET V_CADENA = '
		SELECT	Sentencia
			,Condicion
			,Flag_Recursiva
			,Cod_DW_Regla_Est_Ubica
		FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
		WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
				select Cod_DW_Atributo
				from '|| P_BDDATOS ||'.ATRIBUTO
				where Cod_DW_Tipo_Atributo in (
					select Cod_DW_Tipo_Atributo
					from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
					where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
				) AND Valor_Origen = ''Geografica''
			) AND  Flag_Activo = ''S'' AND ETAPA IN (2)
		ORDER BY Orden'; PREPARE the_statement FROM V_CADENA; OPEN cur_reglas_select; CUR1:LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; IF SqlCode <> 0 THEN LEAVE CUR1; END IF; SET V_CADENA = '
		UPDATE '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
		SET ' || V_Sentencia || '
			, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
		WHERE ' || V_Condicion ; CALL DBC.SysExecSQL(:V_CADENA); IF SqlCode NOT IN (0, 7632) THEN SET V_CADENA1 = V_CADENA; SET P_ERROR = 'ERROR: '|| SqlCode || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1; LEAVE L1; END IF; END LOOP CUR1; CLOSE cur_reglas_select; ---------------------------
 -- Reemplaza Toponimos
 -- Busca y borra si existe la tabla tmp_DireFisica_Topo_a
 ---------------------------
 SELECT TableName INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TableName = 'tmp_DireFisica_Topo_a' ; IF Activity_Count > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo_a'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_a
 AS
(
	SELECT	a.Cod_DW_Reporte_Ubic_Original
		,CASE WHEN b.Valor IS NULL
				THEN Ubicacion_Stand
		      ELSE OREPLACE(Ubicacion_Stand, b.Valor, b.Normalizado)
		END Ubicacion_Stand
		,a.Ciudad
		,a.Codigo_Ciudad_Dane
		,a.Tipo_Direccion
	FROM  (
		select *
		from '||P_BDSTAGE || '.tmp_DireFisica_Estandarizada
		qualify row_number() over(partition by Cod_DW_Reporte_Ubic_Original
				order by Cod_DW_Reporte_Ubic_Original) = 1
		) a
	LEFT JOIN (
		SELECT   P.Valor
			,P.Normalizado
		FROM '|| P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
		    INNER JOIN '|| P_BDDATOS ||'.TIPO_PARAMETRO AS TP
		    	ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
		    INNER JOIN  '|| P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
		    	ON  TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
		    INNER JOIN '|| P_BDDATOS ||'.PARAMETRO AS P
		    	ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
		WHERE   GP.Nombre_Grupo_Parametro = ''TOPONIMOS''
				  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
                  ) b
               ON a.Ubicacion_Stand like ''%'' || b.Valor || ''%''
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Crea la tabla tmp_DireFisica_Topo_a' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_Estandarizada
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_a'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (2):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo_a' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Busca y borra si existe la tabla tmp_DireFisica_Topo
 ---------------------------
 SELECT TableName INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TableName = 'tmp_DireFisica_Topo' ; IF Activity_Count > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
 -- Se crea y carga la tabla tmp_DireFisica_Topo
 -- Separacion del texto de la direccion en palabras
 -----------------------------
 SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo
 AS (
 WITH RECURSIVE Text_Dir_Palabras
 (Cod_DW_Reporte_Ubic_Original
 ,ID_S
 ,POS
 ,PALABRA
 ,Ubicacion_Stand
 ,Ciudad
 ,Codigo_Ciudad_Dane
 ,Tipo_Direccion
) AS
(
	SELECT Cod_DW_Reporte_Ubic_Original
		,0
		,0
		, cast('''' as varchar(100))
		,Ubicacion_Stand  
		,Ciudad
		,Codigo_Ciudad_Dane
		,Tipo_Direccion
	from '||P_BDSTAGE || '.tmp_DireFisica_Topo_a
	UNION ALL
	SELECT Cod_DW_Reporte_Ubic_Original
		,ID_S+1
		,CASE WHEN POSITION('' '' IN Ubicacion_Stand) > 0
				THEN POSITION('' '' IN Ubicacion_Stand)
		     ELSE CHARACTER_LENGTH(Ubicacion_Stand)
		END POS1
		,TRIM(BOTH '' '' FROM SUBSTR(Ubicacion_Stand, 0, POS1+1))
		,TRIM(SUBSTR(Ubicacion_Stand, POS1+1))
		,Ciudad
		,Codigo_Ciudad_Dane
		,Tipo_Direccion
	FROM Text_Dir_Palabras
	WHERE POS1 > 0
)
SELECT Cod_DW_Reporte_Ubic_Original
	,ID_S
	,PALABRA 
	,Ciudad
	,Codigo_Ciudad_Dane
	,Ubicacion_Stand
	,Tipo_Direccion
FROM Text_Dir_Palabras
WHERE ID_S > 0

) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (3):. Crear y carga la tabla tmp_DireFisica_Topo' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_Topo
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (4):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; /*
		BEGIN ETAPA TOPONIMO
		begin tmp_DireFisica_Topo
		*/ ---------------------------
 -- Busca y borra si existe la tabla tmp_DireFisica_Topo_II
 ---------------------------
 SELECT TableName INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TableName = 'tmp_DireFisica_Topo_II' ; IF Activity_Count > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Topo_II'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
 -- Se crea y carga la tabla tmp_DireFisica_Topo_II
 -- Se aplican acepciones y no existe, se llama la funcion GENACCEPAUT para
 --  intentar crearla
 -----------------------------
 SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II
 AS (
SELECT	A.Cod_DW_Reporte_Ubic_Original
	,A.ID_S
	,CASE WHEN ACEP.Valor IS NULL
			AND ' || P_BDVISTA || '.VALIDATE_EXPRESSION_R(A.PALABRA, ''^[A-Za-z]{3,20}*$'')=1
			AND A.PALABRA IS NOT NULL
			AND ACEP.Valor IS NULL
		THEN ' || P_BDVISTA || '.GENACCEPAUT(A.PALABRA, SOUNDEX(A.PALABRA))
	END NEW_ACEPCION
	,CASE WHEN ACEP.Valor IS NOT NULL
		THEN ACEP.Normalizado
	      WHEN NEW_ACEPCION IS NOT NULL AND CHAR(NEW_ACEPCION) <> 0
	      	THEN NEW_ACEPCION
	      ELSE A.PALABRA
	END PALABRA
	,A.Ubicacion_Stand
	,A.PALABRA PALABRA_ORI
	,A.Ciudad
	,A.Codigo_Ciudad_Dane
	,A.Tipo_Direccion
FROM ' || P_BDSTAGE ||'.tmp_DireFisica_Topo A
LEFT JOIN (
	SELECT	P.Valor
		,P.Normalizado
	FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
	INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
		ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
	INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
		ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
	INNER JOIN ' || P_BDDATOS ||'.PARAMETRO AS P
		ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
	WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
			  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
		) ACEP
	ON TRIM(A.PALABRA) = ACEP.Valor /*#1*/
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (5):. Crear y carga la tabla tmp_DireFisica_Topo_II' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_Topo
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (6):. Actualizar estadisticas a la tabla tmp_DireFisica_Topo_II' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Inserta las nuevas acepciones en parametros
 --------------------
 SET V_CADENA = ''; SET V_CADENA = '
INSERT INTO ' || P_BDDATOS ||'.PARAMETRO
SELECT	P.Cod_DW_Parametro + SUM( 1 ) OVER (ROWS UNBOUNDED PRECEDING) Cod_DW_Parametro
	,A.PALABRA_ORI Valor
	,A.PALABRA Normalizado
	,'|| P_Lote || '
	,NULL
	,1
	,USER
	,STP1.Cod_DW_Subtipo_Parametro
	,NULL
	,date
FROM (SELECT *
	FROM ' || P_BDSTAGE ||'.tmp_DireFisica_Topo_II
	WHERE NEW_ACEPCION IS NOT NULL AND CHAR(NEW_ACEPCION) <> 0
	QUALIFY ROW_NUMBER() OVER(PARTITION BY PALABRA_ORI, PALABRA ORDER BY PALABRA_ORI) = 1
   ) A
CROSS JOIN (
	SELECT STP.Cod_DW_Subtipo_Parametro
	FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
	INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
		ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
	INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
		ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
	WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''

		  AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
	) STP1
CROSS JOIN (SELECT MAX(Cod_DW_Parametro) Cod_DW_Parametro
	    FROM ' || P_BDDATOS ||'.PARAMETRO
	) P
LEFT JOIN (
	SELECT    P.Valor
		,P.Normalizado
	    FROM ' || P_BDDATOS ||'.GRUPO_PARAMETRO AS GP
	    INNER JOIN ' || P_BDDATOS ||'.TIPO_PARAMETRO AS TP
		ON GP.Cod_DW_Grupo_Parametro = TP.Cod_DW_Grupo_Parametro
	    INNER JOIN  ' || P_BDDATOS ||'.SUBTIPO_PARAMETRO AS STP
		ON TP.Cod_DW_Tipo_Parametro =STP.Cod_DW_Tipo_Parametro
	    INNER JOIN ' || P_BDDATOS ||'.PARAMETRO AS P
		ON STP.Cod_DW_Subtipo_Parametro = P.Cod_DW_Subtipo_Parametro
	    WHERE   GP.Nombre_Grupo_Parametro =''ACEPCIONES''
		      AND TP.Nombre_Tipo_Parametro = ''DIRECCION''
  ) EXT
	ON EXT.Valor = 			trim(A.PALABRA_ORI) /*#1*/
	AND EXT.Normalizado = 	trim(A.PALABRA) /*#1*/
WHERE EXT.Valor IS NULL'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (7):. Inserta las nuevas acepciones en PARAMETRO' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a paramtros
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Parametro) ON ' || P_BDDATOS ||'.PARAMETRO'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (8):. Actualizar estadisticas a la tabla PARAMETRO' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; /*end tmp_DireFisica_Topo_II
		*/ /*
		END ETAPA TOPONIMO
		*/ ---------------------------
 -- Busca y borra si existe la tabla tmp_DireFisica_TopoUpd
 ---------------------------
 SELECT TableName INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TableName = 'tmp_DireFisica_TopoUpd' ; IF Activity_Count > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
 -- Se crea y carga la tabla tmp_DireFisica_TopoUpd
 -- Rearma la direccion
 -----------------------------
 SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_TopoUpd
 AS (
 WITH RECURSIVE Text_Dir_PalabrasT
 (Cod_DW_Reporte_Ubic_Original
 ,ID_S
 ,PALABRA
 ,Ubicacion_Stand
 ,Ciudad
 ,Codigo_Ciudad_Dane
 ,Reglas
 ,Tipo_Direccion
) AS
(
	SELECT Cod_DW_Reporte_Ubic_Original
		,ID_S
		,PALABRA
		,CAST(PALABRA AS VARCHAR(500)) Ubicacion_Stand     
		,Ciudad
		,Codigo_Ciudad_Dane
		,CAST('''' AS VARCHAR(50)) as Reglas
		,Tipo_Direccion
	from '||P_BDSTAGE || '.tmp_DireFisica_Topo_II
	QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
					ORDER BY ID_S ASC) = 1
	UNION ALL
	SELECT A.Cod_DW_Reporte_Ubic_Original
		,B.ID_S
		,B.PALABRA
		,nvl(A.Ubicacion_Stand,'''') || '' '' || nvl(B.PALABRA,'''') /*#2*/
		,B.Ciudad
		,B.Codigo_Ciudad_Dane
		,CAST('''' AS VARCHAR(50)) as Reglas
		,B.Tipo_Direccion
	FROM '||P_BDSTAGE || '.tmp_DireFisica_Topo_II B
	INNER JOIN Text_Dir_PalabrasT A
		ON A.Cod_DW_Reporte_Ubic_Original = B.Cod_DW_Reporte_Ubic_Original
		AND (A.ID_S + 1) = B.ID_S
	WHERE B.ID_S IS NOT NULL
)
SELECT Cod_DW_Reporte_Ubic_Original
	,Ubicacion_Stand
	,Ciudad
	,Codigo_Ciudad_Dane
	,Reglas
	,Tipo_Direccion
FROM Text_Dir_PalabrasT
QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
				ORDER BY ID_S DESC, Ubicacion_Stand DESC) = 1

) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (9):. Crear y carga la tabla tmp_DireFisica_TopoUpd' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_TopoUpd
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN (Ubicacion_Stand) ON ' || P_BDSTAGE ||'.tmp_DireFisica_TopoUpd'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (10):. Actualizar estadisticas a la tabla tmp_DireFisica_TopoUpd' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Cursor de reglas para ETAPA IN (5)
 -- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones
 --------------------
 SET V_CADENA = '
SELECT	Sentencia
	,Condicion
	,Flag_Recursiva
	,Cod_DW_Regla_Est_Ubica
	
FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
		select Cod_DW_Atributo
		from '|| P_BDDATOS ||'.ATRIBUTO
		where Cod_DW_Tipo_Atributo in (
			select Cod_DW_Tipo_Atributo
			from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
			where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
		) AND Valor_Origen = ''Geografica''
	) AND  Flag_Activo = ''S'' AND ETAPA IN (5)
ORDER BY Orden'; PREPARE the_statement FROM V_CADENA; OPEN cur_reglas_select; CUR2:LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; IF SqlCode <> 0 THEN LEAVE CUR2; END IF; SET V_CADENA = '
UPDATE '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
SET ' || V_Sentencia || '
	, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
WHERE ' || V_Condicion ; CALL DBC.SysExecSQL(:V_CADENA); IF SqlCode NOT IN (0, 7632) THEN SET V_CADENA1 = V_CADENA; SET P_ERROR = 'ERROR: '|| SqlCode || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1; LEAVE L1; END IF; END LOOP CUR2; CLOSE cur_reglas_select; ---------------------------
 -- Se ordenan las particulas en formato DANE con la funcion ADDRESS_NORMALIZATION
 -- esta funcion develve una serie de campos donde el ultimo se emplea para tipificar
 -- la direccion  como valida, invalida 
 --
 --
 -- Busca y borra si existe la tabla tmp_DireFisica_Nor
 ---------------------------
 SELECT TableName INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TableName = 'tmp_DireFisica_Nor' ; IF Activity_Count > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DireFisica_Nor'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DireFisica_Nor
 AS
(
	SELECT	Cod_DW_Reporte_Ubic_Original
		,Ubicacion_Stand
		,'|| P_BDVISTA ||'.ADDRESS_NORMALIZATION(oreplace(Ubicacion_Stand,''?'', ''''), Ciudad, 300, COALESCE(Codigo_Ciudad_Dane, ''''), Tipo_Direccion) ADDR_NORM
		,Ciudad
		,Codigo_Ciudad_Dane
	FROM '||P_BDSTAGE || '.tmp_DireFisica_TopoUpd
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (11):. Crea la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; END IF; END IF; END IF; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_Nor
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DireFisica_Nor'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (12):. Actualizar estadisticas a la tabla tmp_DireFisica_Nor' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Genera posibles direcciones para las direcciones marcadas como ""X VALIDAR VIAS"" y ""NO VALIDA"" 
 --
 -- Busca y borra si existe la tabla tmp_Direcc_No_Validas
 ---------------------------
 SELECT TableName INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TableName = 'tmp_Direcc_No_Validas' ; IF Activity_Count > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Direcc_No_Validas'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas
 AS
(
	SELECT	Cod_DW_Reporte_Ubic_Original
		,Ubicacion_Stand
		,Codigo_Ciudad_Dane
	FROM '||P_BDSTAGE || '.tmp_DireFisica_Nor
	WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''NO VALIDA 2''
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (13):. Crea la tabla tmp_Direcc_No_Validas' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Procesa las direcciones marcadas como ""X VALIDAR VIAS"" y genera un registro por cada una 
 --
 -- Busca y borra si existe la tabla tmp_Direcc_X_Validar_Vias
 ---------------------------
 SELECT TableName INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TableName = 'tmp_Direcc_X_Validar_Vias' ; IF Activity_Count > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Direcc_X_Validar_Vias'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias
 AS
(
WITH RECURSIVE New_Direc
 (Cod_DW_Reporte_Ubic_Original
 ,ID_S
 ,Direc_New
 ,Dir
 ,Ubicacion_Stand
 ,Codigo_Ciudad_Dane
) AS
(
	SELECT Cod_DW_Reporte_Ubic_Original
		,0 ID_S
		, CAST(NULL AS VARCHAR(100))Direc_New
		, '|| P_BDVISTA ||'.DESC_ADDRESS_MORE_ADDRESS(Ubicacion_Stand, Ciudad, 300, Codigo_Ciudad_Dane) Dir
		, Ubicacion_Stand
		,Codigo_Ciudad_Dane
	from '||P_BDSTAGE || '.tmp_DireFisica_Nor
	WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) = ''X VALIDAR VIAS''
	UNION ALL
	SELECT Cod_DW_Reporte_Ubic_Original
		,ID_S+1 ID_S1
		,'|| P_BDVISTA ||'.eListGetValByIdx(DIR, ''/'', ID_S1) Direc_New1
		, DIR
		,Ubicacion_Stand
		,Codigo_Ciudad_Dane
	FROM New_Direc
	WHERE Direc_New1 is not null
)
SELECT	Cod_DW_Reporte_Ubic_Original
	,ID_S
	,Ubicacion_Stand
	,Direc_New
	,Codigo_Ciudad_Dane
FROM New_Direc
WHERE Direc_New is not null


) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original, ID_S)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (14):. Crea la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (14):. Crea la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; END IF; --------------------
 -- Actualiza estadisticas a tmp_Direcc_X_Validar_Vias
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original, ID_S) ON ' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (15):. Actualizar estadisticas a la tabla tmp_Direcc_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Marca si alguna de la direcciones puede ser tenia como valida 
 --
 -- Busca y borra si existe la tabla tmp_DirVal_X_Validar_Vias
 ---------------------------
 SELECT TableName INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TableName = 'tmp_DirVal_X_Validar_Vias' ; IF Activity_Count > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_DirVal_X_Validar_Vias'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias
 AS
(
SELECT	Dir.Cod_DW_Reporte_Ubic_Original
	,Dir.Ubicacion_Stand
	,Dir.Direc_New
	,CASE WHEN (VUE.Flag_Geo IS NOT NULL
				AND VUE.Flag_Geo = ''S''
				AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) <> ''''
				AND VDF.Cod_DW_Ubic IS NOT NULL)
			AND VRPU.Cod_DW_Ubic IS NOT NULL
		   THEN 1
	       WHEN (VUE.Flag_Geo IS NOT NULL
				AND VUE.Flag_Geo = ''S''
				AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) <> ''''
				AND VDF.Cod_DW_Ubic IS NOT NULL)
			OR VRPU.Cod_DW_Ubic IS NOT NULL
		   THEN 2
	       ELSE 3
	 END Ind_Val
	 ,Dir.Codigo_Ciudad_Dane

FROM	' || P_BDSTAGE ||'.tmp_Direcc_X_Validar_Vias Dir
INNER JOIN ' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada TMP
	ON TMP.Cod_DW_Reporte_Ubic_Original = Dir.Cod_DW_Reporte_Ubic_Original
LEFT JOIN ' || P_BDVISTA || '.V_Ubicacion_Estandarizada VUE
	ON TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 1)) = VUE.Texto_Ubicacion
	AND TMP.Cod_DW_Tipo_Ubicacion = VUE.Cod_Dw_Tipo_Ubicacion 
LEFT JOIN ' || P_BDVISTA || '.V_DIRECCION_FISICA VDF
	ON VUE.Cod_DW_Ubic = VDF.Cod_DW_Ubic
	AND TRIM('|| P_BDVISTA ||'.eListGetValByIdx(Dir.Direc_New, ''&'', 2)) = VDF.Complemento
LEFT JOIN ' || P_BDVISTA || '.V_RELACION_PERSONA_UBICACION VRPU
	ON VUE.Cod_DW_Ubic = COALESCE(VRPU.Cod_DW_Ubic, -1)
	
QUALIFY ROW_NUMBER() OVER(PARTITION BY Dir.Cod_DW_Reporte_Ubic_Original, Dir.Direc_New
			ORDER BY Dir.Cod_DW_Reporte_Ubic_Original) = 1

) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (16):. Crea la tabla tmp_DirVal_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_Direcc_No_Validas
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (17):. Actualizar estadisticas a la tabla tmp_DirVal_X_Validar_Vias' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Completa las direcciones no validas en tmp_Direcc_No_Validas con las direcciones que no se pudieron clasificar
 --------------------
 SET V_CADENA = ''; SET V_CADENA = '
INSERT INTO ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas
SELECT	DISTINCT
	Cod_DW_Reporte_Ubic_Original
	,Ubicacion_Stand
	,Codigo_Ciudad_Dane
FROM	' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias A
WHERE Ind_Val = 3
	AND NOT EXISTS (
		SELECT 1
		FROM ' || P_BDSTAGE ||'.tmp_DirVal_X_Validar_Vias B
		WHERE A.Cod_DW_Reporte_Ubic_Original = B.Cod_DW_Reporte_Ubic_Original
		AND B.Ind_Val in (1,2)
	)
	'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (18):. Completa direcciones invalidas en tmp_Direcc_No_Validas' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_Direcc_No_Validas
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_Direcc_No_Validas'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (19):. Actualizar estadisticas a la tabla tmp_Direcc_No_Validas' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Une todas las direcciones validas en tmp_Dire_Estan_Val
 -- Busca y borra si existe la tabla tmp_Dire_Estan_Val
 ---------------------------
 SELECT TableName INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TableName = 'tmp_Dire_Estan_Val' ; IF Activity_Count > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_Dire_Estan_Val'; CALL DBC.SysExecSQL(:V_CADENA); END IF; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val
 AS (
	SELECT	Cod_DW_Reporte_Ubic_Original
		,oreplace(ADDR_NORM, ''NO VALIDA 2'',''NO VALIDA'') ADDR_NORM
		,Codigo_Ciudad_Dane
	FROM '||P_BDSTAGE || '.tmp_DireFisica_Nor
	WHERE '|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8) <> ''X VALIDAR VIAS''
	UNION ALL
	SELECT	Cod_DW_Reporte_Ubic_Original
		,Direc_New
		,Codigo_Ciudad_Dane
	FROM '||P_BDSTAGE || '.tmp_DirVal_X_Validar_Vias
	QUALIFY ROW_NUMBER() OVER(PARTITION BY Cod_DW_Reporte_Ubic_Original
					ORDER BY Ind_Val) = 1
	
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (20):. Crea la tabla tmp_Dire_Estan_Val' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_Dire_Estan_Val
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (21):. Actualizar estadisticas a la tabla tmp_Dire_Estan_Val' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Busca y borra si existe la tabla DireccionFisica_Estandarizada
 ---------------------------
 SELECT TableName INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TableName = 'DireccionFisica_Estandarizada' ; IF Activity_Count > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.DireccionFisica_Estandarizada'; CALL DBC.SysExecSQL(:V_CADENA); END IF; --------------------
 -- Unifica los datos de acuerdo Cod_DW_Reporte_Ubic_Original, el resultado en DireccionFisica_Estandarizada
 -- Se normaliza y ordena el texto de la direccion con la funcion ADDRESS_NORMALIZATION
 --------------------
 SET V_CADENA = ''; SET V_CADENA = '
CREATE MULTISET TABLE ' || P_BDSTAGE ||'.DireccionFisica_Estandarizada
 AS (
	SELECT	dir.Cod_DW_Reporte_Ubic_Original
		,dir.Texto_Ubicacion_Original
		,dir.Cod_DW_Tipo_Ubicacion
		,dir.Cod_DW_Fuente
		,dir.Lote
		,dir.Id_Buro_Suscriptor
		,dir.Id_Buro_Persona
		,dir.Cod_DW_Cta
		,dir.Cod_DW_Hash
		,dir.Cod_DW_Ubic
		,dir.Valor
		,dir.Ciudad Texto_Ciudad
		,dir.Codigo_Ciudad_Dane
		,dir.Fecha_Reporte
		
		,dir.Cod_DW_Ubicacion_Original
		,dir.Cod_DW_Tipo_Ubicacion_Dir
		,dir.Usuario_BD
		
		,CASE WHEN Est.Cod_DW_Reporte_Ubic_Original IS NULL
			THEN dir.Texto_Ubicacion_Original
			ELSE TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 1))
		END DIRE_GEO
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 2)) DIRE_COMPLEMENTO
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 3)) DIR_TIPO_DIRE
		,CASE WHEN Est.Cod_DW_Reporte_Ubic_Original IS NULL
			THEN dir.Tipo_Direccion
			ELSE TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 4))
		END DIR_TIPOVIA
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 5)) DIR_NUMVIAPPAL
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 6)) DIR_NUMVIAGEN
		,TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 7)) DIR_NUMPLACA
		,CASE WHEN Est.Cod_DW_Reporte_Ubic_Original IS NULL
			THEN ''NO VALIDA''
			ELSE TRIM('|| P_BDVISTA ||'.eListGetValByIdx(ADDR_NORM, ''&'', 8))
		END DIR_CB_VALIDA
		,COALESCE(ADDR_NORM, dir.Ubicacion_Stand) Ubicacion_Stand
		,cast('''' as varchar(20)) Reglas
	FROM	' || P_BDSTAGE ||'.tmp_DireFisica_Estandarizada dir
	LEFT JOIN ' || P_BDSTAGE ||'.tmp_Dire_Estan_Val Est
		ON dir.Cod_DW_Reporte_Ubic_Original = Est.Cod_DW_Reporte_Ubic_Original
	QUALIFY ROW_NUMBER() OVER(PARTITION BY dir.Cod_DW_Reporte_Ubic_Original
				ORDER BY dir.Cod_DW_Reporte_Ubic_Original) = 1
) WITH DATA
PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (22):. Crear y carga la tabla DireccionFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a tmp_DireFisica_Estand_Topo
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original )
							ON ' || P_BDSTAGE ||'.DireccionFisica_Estandarizada'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationGeografica (8):. Actualizar estadisticas a la tabla DireccionFisica_Estandarizada' ,V_ERROR); SET P_ERROR = V_ERROR; IF Character_Length(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Cursor de reglas para ETAPA IN (6)
 -- Reglas de limpieza basadas en patrones de texto posteriores en a las acepciones
 --------------------
 SET V_CADENA = '
SELECT	Sentencia
	,Condicion
	,Flag_Recursiva
	,Cod_DW_Regla_Est_Ubica
FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
		select Cod_DW_Atributo
		from '|| P_BDDATOS ||'.ATRIBUTO
		where Cod_DW_Tipo_Atributo in (
			select Cod_DW_Tipo_Atributo
			from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
			where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
		) AND Valor_Origen = ''Geografica''
	) AND  Flag_Activo = ''S'' AND ETAPA IN (6)
ORDER BY Orden'; PREPARE the_statement FROM V_CADENA; OPEN cur_reglas_select; CUR3:LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; IF SqlCode <> 0 THEN LEAVE CUR3; END IF; SET V_CADENA = '
UPDATE '||P_BDSTAGE || '.DireccionFisica_Estandarizada
SET ' || V_Sentencia || '
	, Reglas = Reglas || '' - ' || V_Cod_DW_Regla_Est_Ubica || '''
WHERE ' || V_Condicion; CALL DBC.SysExecSQL(:V_CADENA); IF SqlCode NOT IN (0, 7632) THEN SET V_CADENA1 = V_CADENA; SET P_ERROR = 'ERROR: '|| SqlCode || '. Aplicacion de reglas Cod_DW_Regla_Est_Ubica = ' || V_Cod_DW_Regla_Est_Ubica || ' ' || V_CADENA1; LEAVE L1; END IF; END LOOP CUR3; CLOSE cur_reglas_select; END L1; END;

REPLACE PROCEDURE REC_DATOS.PRO_StandardizationTelFijo
 ( IN P_Lote INTEGER ,IN P_StartTimeStampPadre VARCHAR(20) ,IN P_Nombre_Proceso_Padre VARCHAR(30) ,IN P_BDDATOS VARCHAR(20) ,IN P_BDVISTA VARCHAR(20) ,IN P_BDSTAGE VARCHAR(20) ,OUT P_ERROR VARCHAR(500) ) /*
 * ################################################################################
 * 
 * Objetivo:		Estandariza el telefono fijo como ubicacion del insumo InsumoTelefonoFijo.
 *			Dejando el resultado en TelefonoFijo_Estandarizado
 * Fecha:		2016/11/09
 * Realizado por:	Luis E Ramirez
 * Proyecto:		Nuevo reconocer
 * Script:		Create_PRO_StandardizationTelFijo.sql
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha		Objetivo			Realizado por
 *2018-08-27  #1 Ajuste tipo Bigint	Carlos Castillo 
 *2022-08-03 #2 Se Adiciona Regla para la Antiguedad de los datos  John Bueno
 *30/01/2023  Se reinician las variables vsentencia                Omar Delgado.
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */ BEGIN ------------------------
-- DeclaraciÃ¸ÂŠÃÂÃ¸ÂÃ¢ÂšÂÃ¸ÂŠÃ¢ÂšÂÃ¸ÂÝÃ´Â³n de variables
------------------------
DECLARE V_Sentencia VARCHAR(500);
DECLARE V_Condicion VARCHAR(500);
DECLARE V_Flag_Recursiva VARCHAR(1);
DECLARE V_Cod_DW_Regla_Est_Ubica INTEGER;
DECLARE V_COUNT INTEGER;
DECLARE V_Contador INTEGER;
DECLARE V_StartTimeStampPadre TIMESTAMP(6); 
DECLARE V_ERROR VARCHAR(30); 
DECLARE V_CADENA VARCHAR(32000); 
DECLARE Temp CHAR(30); 
DECLARE V_Patron VARCHAR(500); 
DECLARE V_Componente_Tel VARCHAR(500); 
DECLARE V_Componente_Aux VARCHAR(500); 
DECLARE V_Componente_Comp VARCHAR(500); 
DECLARE V_Cod_DW_Patron_Telefono INTEGER; -- Cursores


DECLARE cur_reglas_select NO SCROLL CURSOR
FOR the_statement;

 DECLARE cur_patrones_select NO SCROLL CURSOR FOR the_statement; L1: BEGIN SET P_ERROR = ''; SET V_StartTimeStampPadre = CAST(P_StartTimeStampPadre AS TIMESTAMP(6) FORMAT 'yyyy-mm-ddhh:mi:ss'); --	SET V_StartTimeStampPadre = DATE;


 ---------------------------
-- Busca y borra si existe la tabla TelefonoFijoEstandarizado
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'TelefonoFijoEstandarizado' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.TelefonoFijoEstandarizado'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
-- Se crea y carga la tabla TelefonoFijoEstandarizado
-----------------------------
 SET V_CADENA = ''; SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.TelefonoFijoEstandarizado
					 AS 
					(SELECT	Cod_DW_Reporte_Ubic_Original
							, ' || P_BDVISTA || '.REPLEXPREG(Texto_Ubicacion_Original, ''^[A-Za-z0-9]?$'') Ubicacion_Stand
							,Trim(Texto_Ubicacion_Original) Ubicacion_Stand01							
							,CAST(NULL AS VARCHAR(20)) Componente_Tel
							,CAST(GEO.Indicativo_Telefonico AS VARCHAR(20) ) Componente_Aux
							,CAST(NULL AS VARCHAR(20)) Componente_Comp
							,Texto_Ubicacion_Original
							,Cod_DW_Tipo_Ubicacion
							,Cod_DW_Fuente
							,Lote
							,Id_Buro_Suscriptor
							,Id_Buro_Persona
							,Cod_DW_Cta
							,Cod_DW_Hash
							,Cod_DW_Ubic
							,Valor
							,COALESCE(GEO.Descripcion_Ciudad, Tel.Texto_Ciudad)  Texto_Ciudad							
							,Codigo_Ciudad_Dane
							,Fecha_Reporte
							,Cod_DW_Ubicacion_Original
							,Cod_DW_Tipo_Ubicacion_Dir
							,Usuario_BD
                            ,COALESCE(NULL, ''NO VALIDA'') DIR_CB_VALIDA
					FROM ' || P_BDSTAGE ||'.InsumoTelefonoFijo Tel
					LEFT JOIN '|| P_BDVISTA ||'.V_Geografia GEO
	                ON GEO.Cod_Dane_Ciudad = Tel.Codigo_Ciudad_Dane			 
					) WITH DATA
					PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo (1):. Crear y carga la tabla TelefonoFijoEstandarizado' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a EmailsEstandarizados
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN(Ubicacion_Stand, Componente_Tel) ON ' || P_BDSTAGE ||'.TelefonoFijoEstandarizado'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo (2):. Actualizar estadisticas a la tabla TelefonoFijoEstandarizado' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Busca y borra si existe la tabla Tmp_SplitTelefonoFijo
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'Tmp_SplitTelefonoFijo' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
 -- Se crea y carga la tabla Tmp_SplitTelefonoFijo
 -----------------------------
 SET V_CADENA = ''; SET V_CADENA = 'CREATE MULTISET TABLE '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo
					AS
					(WITH PARAMS (cod_Dw_ubicacion_original
					,Ubicacion_Stand
					,Ubicacion_Stand0
					,Ubicacion_Stand00
					,Ubicacion_Stand1
					,Ubicacion_Stand2
					,INPUT_PARAMS
					,TEXTO
					) AS
					(SELECT cast(cod_dw_ubicacion_original as varchar(100)) as  cod_dw_ubicacion_original --Cod_DW_Reporte_Ubic_Original
							,Ubicacion_Stand01 Ubicacion_Stand
							,'||P_BDVISTA|| '.REPLEXPREG(Ubicacion_Stand01,''[(]'','''') Ubicacion_Stand0
							,'||P_BDVISTA|| '.REPLEXPREG(Ubicacion_Stand0,''[)]'','''') Ubicacion_Stand00	
							,'||P_BDVISTA|| '.REPLEXPREG(Ubicacion_Stand00,''([.]|[#]|[-]|[ -][*][/][\])'','' '') Ubicacion_Stand1
							,'||P_BDVISTA|| '.REPLEXPREG( '||P_BDVISTA|| '.REPLEXPREG(Ubicacion_Stand1,''[0-9]{1}[A-Za-z]{1}'','' '',-1, 1), ''[0-9]{1}[A-Za-z]{1}'','' '',-1, 1) Ubicacion_Stand2 		
							,1 Input_Params
							,'||P_BDVISTA|| '.REPLEXPREG(Ubicacion_Stand2,''[ ]{2,100}'', '' '') Texto
					 FROM '||P_BDSTAGE || '.TelefonoFijoEstandarizado	
					)		  
					   SELECT CAST(REGEXP_REPLACE(outkey,''^[0-9]'','''') AS BIGINT)  AS cod_Dw_ubicacion_original, /*#1*/
							   token_ndx,
							   Trim(token) token,          
							   CASE WHEN '||P_BDVISTA|| '.validate_expression_r(Token,''018000([0-9]{6})'') =1 
									THEN ''PBX''
									WHEN '||P_BDVISTA|| '.validate_Expression_r(Token,''3[0-9]{9}\b'')=1
									THEN  ''Celular''
									WHEN '||P_BDVISTA|| '.validate_expression_R(token,''([5]{1}[0-9]{2}|[5]{1}[0-9]{1}|[1-9])([2-9]{1}[0-9]{6})\b|[1-9]([2-9]{1}[0-9]{6})|[2-9][0-9]{6}\b'')=1 
									THEN ''Telefono''
									WHEN '||P_BDVISTA|| '.validate_expression_R(token,''[A-Za-z]{1,20}|[A-Za-z]{1,20}[0-9]{1,20}$|[A-Za-z]{1,20} [0-9]{1,20}$|[1-9]{1,6}'')=1
									THEN ''EXT''
								   ELSE ''SV''
							   END tipo           
					   FROM TABLE(RegExp_Split_To_Table
								  (params.cod_Dw_ubicacion_original,params.texto,'' '',''c'')
						RETURNS (outkey VARCHAR(100), token_ndx INTEGER, token VARCHAR(100))) AS dt
					)
					WITH DATA 
					PRIMARY INDEX (cod_Dw_ubicacion_original,token_ndx);'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo (3):. Crear y carga la tabla Tmp_SplitTelefonoFijo' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a EmailsEstandarizados
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (cod_Dw_ubicacion_original,token_ndx) ON ' || P_BDSTAGE ||'.Tmp_SplitTelefonoFijo'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo (4):. Actualizar estadisticas a la tabla Tmp_SplitTelefonoFijo' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Busca y borra si existe la tabla Tmp_SplitTelefonoFijo2
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'Tmp_SplitTelefonoFijo2' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo2'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
 -- Se crea y carga la tabla Tmp_SplitTelefonoFijo2
 -----------------------------
 SET V_CADENA = ''; SET V_CADENA = 'CREATE MULTISET TABLE '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo2
					AS
					(SELECT a.*
							,'||P_BDVISTA|| '.SUBSTREXPREG(Token,''[2-9][0-9]{6}\b'') Componente_Tel
							,CASE WHEN Length('||P_BDVISTA|| '.SUBSTREXPREG(Token,''([5]{1}[0-9]{2}|[5]{1}[0-9]{1}|[1-9])([2-9]{1}[0-9]{6})\b|[1-9]([2-9]{1}[0-9]{6})|[2-9][0-9]{6}\b''))>7 
										
											   THEN Substr(Token,1,Length('||P_BDVISTA|| '.SUBSTREXPREG(Token,''([5]{1}[0-9]{2}|[5]{1}[0-9]{1}|[1-9])([2-9]{1}[0-9]{6})|[2-9][0-9]{6}\b''))-7)
							
							ELSE   ''''
									
							END Componente_Aux
							,Cast ('''' AS VARCHAR(100)) Componente_Comp
							,Coalesce(b.token_ext, -1) token_ext
					FROM '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo a
					LEFT JOIN (SELECT cod_dw_ubicacion_original,
									   Min (token_ndx)-1 token_ext
								FROM '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo
								WHERE Tipo=''EXT''
								GROUP BY 1) b
					ON a.cod_Dw_ubicacion_original=b.cod_Dw_ubicacion_original
					WHERE Tipo=''Telefono''
					QUALIFY (Row_Number()Over(PARTITION BY a.cod_dw_ubicacion_original, tipo ORDER BY token_ndx ASC))=1
					)WITH DATA
					PRIMARY INDEX (cod_Dw_ubicacion_original,token_ndx);'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo (5):. Crear y carga la tabla Tmp_SplitTelefonoFijo2' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a EmailsEstandarizados
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (cod_Dw_ubicacion_original,token_ndx) ON ' || P_BDSTAGE ||'.Tmp_SplitTelefonoFijo2'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo (6):. Actualizar estadisticas a la tabla Tmp_SplitTelefonoFijo2' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Busca y borra si existe la tabla Tmp_SplitTelefonoFijo3
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'Tmp_SplitTelefonoFijo3' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo3'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
 -- Se crea y carga la tabla Tmp_SplitTelefonoFijo2
 -----------------------------
 SET V_CADENA = ''; SET V_CADENA = 'CREATE MULTISET TABLE '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo3
					AS 
					(WITH RECURSIVE temp_table (cod_dw_ubicacion_original,Texto_Ext,token_ndx) AS
					   ( SELECT r.cod_dw_ubicacion_original,
						  Cast('''' AS VARCHAR(100)) Texto_Ext
						  ,token_ext
						 FROM '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo2 r     
					   UNION ALL
						 SELECT i.cod_dw_ubicacion_original,d.Texto_Ext||'' ''||i.token,i.token_ndx
						 FROM temp_table d, '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo i
						 WHERE d.token_ndx+1= i.token_ndx
						 AND d.cod_Dw_ubicacion_original=i.cod_Dw_ubicacion_original
						 AND i.tipo=''EXT''
					   ) 
					   SELECT * FROM temp_table 
					)WITH DATA
					PRIMARY INDEX (cod_dw_ubicacion_original,token_ndx);'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo (7):. Crear y carga la tabla Tmp_SplitTelefonoFijo3' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a EmailsEstandarizados
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (cod_dw_ubicacion_original,token_ndx) ON ' || P_BDSTAGE ||'.Tmp_SplitTelefonoFijo3'; 
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo (8):. Actualizar estadisticas a la tabla Tmp_SplitTelefonoFijo2' ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; 
 END IF; 
 SET V_CADENA = ''; 
 SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.TelefonoFijoEstandarizado
					FROM (SELECT a.cod_Dw_ubicacion_original, b.Componente_Tel, B.Componente_Aux, trim(c.texto_Ext) Componente_Comp
							FROM '||P_BDSTAGE || '.TelefonoFijoEstandarizado  a
							INNER JOIN '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo2 b
							ON  a.cod_Dw_ubicacion_original= b.cod_Dw_ubicacion_original
							INNER JOIN '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo3 c
							ON a.cod_Dw_ubicacion_original=c.cod_Dw_ubicacion_original
							QUALIFY (Row_Number() Over (PARTITION BY a.cod_Dw_ubicacion_original ORDER BY b.token_ndx asc,  c.token_ndx DESC))=1 ) A		
					SET Componente_Tel = A.Componente_Tel,						 
						 Componente_Comp = A.Componente_Comp
					WHERE TelefonoFijoEstandarizado.cod_Dw_ubicacion_original = A.cod_Dw_ubicacion_original'; 
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo (9):. Actualizar valores en TelefonoFijoEstandarizado' ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; 
 END IF; 
 --Componente_Tel - Tel_N
 --Componente_Aux - Tel_Comp1
 --Componente_Comp - Tel_Comp2 y Tel_Comp3
 --------------------
 -- Cursor de patrones, pendiente agregar el filtro por tipo de telefono
 --------------------
 SET V_CADENA = 'SELECT	Cod_DW_Patron_Telefono, Patron, Componente_Tel, COALESCE(Componente_Aux, ''NULL'') Componente_Aux, COALESCE(Componente_Comp , ''NULL'') Componente_Comp
					FROM '|| P_BDDATOS ||'.PATRON_TELEFONO
					WHERE Tipo_Telefono = ''Fijo''
					ORDER BY Orden'; 
 PREPARE the_statement FROM V_CADENA; 
 
 SET V_Cod_DW_Patron_Telefono = '';
 SET V_Patron = '';
 SET V_Componente_Tel = '';
 SET V_Componente_Aux = '';
 SET V_Componente_Comp = '';
 
 OPEN cur_patrones_select; 
 CUR1:LOOP FETCH cur_patrones_select INTO V_Cod_DW_Patron_Telefono, V_Patron, V_Componente_Tel, V_Componente_Aux, V_Componente_Comp; 
 IF SQLSTATE <> '00000' THEN LEAVE CUR1; 
 END IF; 
 SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.TelefonoFijoEstandarizado
				SET Componente_Tel = ' || V_Componente_Tel || '								
				,Componente_Comp = ' || V_Componente_Comp || '
				WHERE ' || V_Patron || '
				AND Componente_Tel IS NULL'; 
 
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo(9.1):. Actualizando Componente_Tel, Componente_Aux, Componente_Comp mediate reglas' ,V_ERROR); 
 IF V_Cod_DW_Patron_Telefono IN (21,22) THEN SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.TelefonoFijoEstandarizado
				SET Componente_Tel = ' || V_Componente_Tel || '								
				,Componente_Comp = ' || V_Componente_Comp || '
				WHERE ' || V_Patron ; 
 
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo(9.11):. Actualizando Componente_Tel, Componente_Aux, Componente_Comp mediate reglas 21 y 22' ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; 
 END IF; 
 END IF; 
 END LOOP CUR1; 
 
 CLOSE cur_patrones_select; 
 SET V_CADENA = ''; 
 SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.TelefonoFijoEstandarizado
					SET DIR_CB_VALIDA = CASE  WHEN CHARACTER_LENGTH( TRIM(Componente_Tel) ) = 7 AND Codigo_Ciudad_Dane > 0 THEN 
											   ''VALIDA''
											 ELSE 
											  ''NO VALIDA''
										 END,
						Componente_Tel = CASE  WHEN CHARACTER_LENGTH( TRIM(Componente_Tel) ) <> 7 THEN 
						                          REC_VISTA.eListGetValByIdx(Componente_Tel, ''|'', 1) 
										    ELSE 
											  Componente_Tel
						                 END'; 
 --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo(10):. Validando si la linea de telefono es valida o no valida' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; SET V_CADENA = ''; SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.TelefonoFijoEstandarizado
					SET Componente_Tel = CASE WHEN Ubicacion_Stand01 Like ''%-%'' 
										   THEN REC_VISTA.eListGetValByIdx(Ubicacion_Stand01, ''-'', 1)   
										    ELSE Trim(Ubicacion_Stand01)
										  END  
					Where Componente_Tel is null'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo(11):. Actualizando Componente_Tel cuando no fue estandarizado' ,V_ERROR); 
 SET P_ERROR = V_ERROR; 
 IF CHARACTER_LENGTH(V_ERROR) > 0 THEN 
 		LEAVE L1; 
 END IF;
 
 		------------------------------------------------------------------------------------
		--03/08/2022
		-- Cursor de reglas para ETAPA IN (1)
		-- Reglas de Antiguedad en los datos que se Validan si se cumple con la condicion
		------------------------------------------------------------------------------------
		SET V_CADENA = 'SELECT  Sentencia
				,Condicion
				,Flag_Recursiva
				,Cod_DW_Regla_Est_Ubica
				FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
				WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
							select Cod_DW_Atributo
							from '|| P_BDDATOS ||'.ATRIBUTO
							where Cod_DW_Tipo_Atributo in (
							select Cod_DW_Tipo_Atributo
							from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
							where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
					) AND Valor_Origen = ''Telefono Fijo''
					) AND  Flag_Activo = ''S'' AND ETAPA IN (1)
				ORDER BY Orden'; 

		SET V_Contador = 0;
		SET V_Sentencia = '';
		SET V_Condicion = '';
		SET V_Cod_DW_Regla_Est_Ubica = '';
		
		PREPARE the_statement FROM V_CADENA; 
		OPEN cur_reglas_select; 			
		CUR2: LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; 
			
		IF SQLCODE <> 0 THEN 
				LEAVE CUR2; 
		END IF;  

		SET V_Contador = V_Contador +1;
		SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.TelefonoFijoEstandarizado
				SET ' || V_Sentencia || '
				WHERE ' || V_Condicion;   


		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 						
				,V_StartTimeStampPadre 
				,:P_Nombre_Proceso_Padre 
				,:V_CADENA 
				,'PRO_StandardizationTelFijo(12):'||' Ejecucion de reglas 1 iteracion: '||trim(V_Contador)||' Regla:'||trim(V_Cod_DW_Regla_Est_Ubica) 
				,V_ERROR); 

		SET P_ERROR = V_ERROR; 
		IF CHARACTER_LENGTH(V_ERROR) > 0 
				THEN LEAVE CUR2; 
		END IF; 

		END LOOP CUR2;
		CLOSE cur_reglas_select;
		
		------------------------------------------------------------------------------------
		--03/08/2022
		-- FIN
		------------------------------------------------------------------------------------
 
 	END L1;
 END;

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
REPLACE PROCEDURE REC_DATOS.PRO_StandardizationTelFijoHAH ( IN P_Lote INTEGER ,IN P_StartTimeStampPadre VARCHAR(20) ,IN P_Nombre_Proceso_Padre VARCHAR(30) ,IN P_BDDATOS VARCHAR(20) ,IN P_BDVISTA VARCHAR(20) ,IN P_BDSTAGE VARCHAR(20) ,OUT P_ERROR VARCHAR(500) ) /*
 * ################################################################################
 * 
 * Objetivo:		Estandariza el telefono fijo como ubicacion del insumo InsumoTelefonoFijo.
 *			Dejando el resultado en TelefonoFijo_Estandarizado
 * Fecha:		2016/11/09
 * Realizado por:	Luis E Ramirez
 * Proyecto:		Nuevo reconocer
 * Script:		Create_PRO_StandardizationTelFijo.sql
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha		Objetivo			Realizado por
 * 
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */ BEGIN ------------------------
-- DeclaraciÃ¸Â³n de variables
------------------------
 DECLARE V_StartTimeStampPadre TIMESTAMP(6); DECLARE V_ERROR VARCHAR(30); DECLARE V_CADENA VARCHAR(32000); DECLARE Temp CHAR(30); DECLARE V_Patron VARCHAR(500); DECLARE V_Componente_Tel VARCHAR(500); DECLARE V_Componente_Aux VARCHAR(500); DECLARE V_Componente_Comp VARCHAR(500); DECLARE V_Cod_DW_Patron_Telefono INTEGER; -- Cursores
 DECLARE cur_patrones_select NO SCROLL CURSOR FOR the_statement; L1: BEGIN SET P_ERROR = ''; SET V_StartTimeStampPadre = CAST(P_StartTimeStampPadre AS TIMESTAMP(6) FORMAT 'yyyy-mm-ddhh:mi:ss'); --	SET V_StartTimeStampPadre = DATE;
 ---------------------------
-- Busca y borra si existe la tabla TelefonoFijoEstandarizado
---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'TelefonoFijoEstandarizado' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.TelefonoFijoEstandarizado'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
-- Se crea y carga la tabla TelefonoFijoEstandarizado
-----------------------------
 SET V_CADENA = ''; SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.TelefonoFijoEstandarizado
					 AS 
					(SELECT	Cod_DW_Reporte_Ubic_Original
							, ' || P_BDVISTA || '.REPLEXPREG(Texto_Ubicacion_Original, ''^[A-Za-z0-9]?$'') Ubicacion_Stand
							,Trim(Texto_Ubicacion_Original) Ubicacion_Stand01							
							,CAST(NULL AS VARCHAR(20)) Componente_Tel
							,CAST(GEO.Indicativo_Telefonico AS VARCHAR(20) ) Componente_Aux
							,CAST(NULL AS VARCHAR(20)) Componente_Comp
							,Texto_Ubicacion_Original
							,Cod_DW_Tipo_Ubicacion
							,Cod_DW_Fuente
							,Lote
							,Id_Buro_Suscriptor
							,Id_Buro_Persona
							,Cod_DW_Cta
							,Cod_DW_Hash
							,Cod_DW_Ubic
							,Valor
							,COALESCE(GEO.Descripcion_Ciudad, Tel.Texto_Ciudad)  Texto_Ciudad							
							,Codigo_Ciudad_Dane
							,Fecha_Reporte
							,Cod_DW_Ubicacion_Original
							,Cod_DW_Tipo_Ubicacion_Dir
							,Usuario_BD
                            ,COALESCE(NULL, ''NO VALIDA'') DIR_CB_VALIDA
					FROM ' || P_BDSTAGE ||'.InsumoTelefonoFijo Tel
					LEFT JOIN '|| P_BDVISTA ||'.V_Geografia GEO
	                ON GEO.Cod_Dane_Ciudad = Tel.Codigo_Ciudad_Dane			 
					) WITH DATA
					PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo (1):. Crear y carga la tabla TelefonoFijoEstandarizado' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a EmailsEstandarizados
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN(Ubicacion_Stand, Componente_Tel) ON ' || P_BDSTAGE ||'.TelefonoFijoEstandarizado'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo (2):. Actualizar estadisticas a la tabla TelefonoFijoEstandarizado' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Busca y borra si existe la tabla Tmp_SplitTelefonoFijo
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'Tmp_SplitTelefonoFijo' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
 -- Se crea y carga la tabla Tmp_SplitTelefonoFijo
 -----------------------------
 SET V_CADENA = ''; SET V_CADENA = 'CREATE MULTISET TABLE '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo
					AS
					(WITH PARAMS (cod_Dw_ubicacion_original
					,Ubicacion_Stand
					,Ubicacion_Stand0
					,Ubicacion_Stand00
					,Ubicacion_Stand1
					,Ubicacion_Stand2
					,INPUT_PARAMS
					,TEXTO
					) AS
					(SELECT cod_dw_ubicacion_original--Cod_DW_Reporte_Ubic_Original
							,Ubicacion_Stand01 Ubicacion_Stand
							,'||P_BDVISTA|| '.REPLEXPREG(Ubicacion_Stand01,''[(]'','''') Ubicacion_Stand0
							,'||P_BDVISTA|| '.REPLEXPREG(Ubicacion_Stand0,''[)]'','''') Ubicacion_Stand00	
							,'||P_BDVISTA|| '.REPLEXPREG(Ubicacion_Stand00,''([.]|[#]|[-]|[ -][*][/][\])'','' '') Ubicacion_Stand1
							,'||P_BDVISTA|| '.REPLEXPREG( '||P_BDVISTA|| '.REPLEXPREG(Ubicacion_Stand1,''[0-9]{1}[A-Za-z]{1}'','' '',-1, 1), ''[0-9]{1}[A-Za-z]{1}'','' '',-1, 1) Ubicacion_Stand2 		
							,1 Input_Params
							,'||P_BDVISTA|| '.REPLEXPREG(Ubicacion_Stand2,''[ ]{2,100}'', '' '') Texto
					 FROM '||P_BDSTAGE || '.TelefonoFijoEstandarizado	
					)		  
					   SELECT outkey cod_Dw_ubicacion_original,
							   token_ndx,
							   Trim(token) token,          
							   CASE WHEN '||P_BDVISTA|| '.validate_expression_r(Token,''018000([0-9]{6})'') =1 
									THEN ''PBX''
									WHEN '||P_BDVISTA|| '.validate_Expression_r(Token,''3[0-9]{9}\b'')=1
									THEN  ''Celular''
									WHEN '||P_BDVISTA|| '.validate_expression_R(token,''([5]{1}[0-9]{2}|[5]{1}[0-9]{1}|[1-9])([2-9]{1}[0-9]{6})\b|[1-9]([2-9]{1}[0-9]{6})|[2-9][0-9]{6}\b'')=1 
									THEN ''Telefono''
									WHEN '||P_BDVISTA|| '.validate_expression_R(token,''[A-Za-z]{1,20}|[A-Za-z]{1,20}[0-9]{1,20}$|[A-Za-z]{1,20} [0-9]{1,20}$|[1-9]{1,6}'')=1
									THEN ''EXT''
								   ELSE ''SV''
							   END tipo           
					   FROM TABLE(RegExp_Split_To_Table
								  (params.cod_Dw_ubicacion_original,params.texto,'' '',''c'')
						RETURNS (outkey INTEGER, token_ndx INTEGER, token VARCHAR(100))) AS dt
					)
					WITH DATA 
					PRIMARY INDEX (cod_Dw_ubicacion_original,token_ndx);'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo (3):. Crear y carga la tabla Tmp_SplitTelefonoFijo' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a EmailsEstandarizados
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (cod_Dw_ubicacion_original,token_ndx) ON ' || P_BDSTAGE ||'.Tmp_SplitTelefonoFijo'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo (4):. Actualizar estadisticas a la tabla Tmp_SplitTelefonoFijo' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Busca y borra si existe la tabla Tmp_SplitTelefonoFijo2
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'Tmp_SplitTelefonoFijo2' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo2'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
 -- Se crea y carga la tabla Tmp_SplitTelefonoFijo2
 -----------------------------
 SET V_CADENA = ''; SET V_CADENA = 'CREATE MULTISET TABLE '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo2
					AS
					(SELECT a.*
							,'||P_BDVISTA|| '.SUBSTREXPREG(Token,''[2-9][0-9]{6}\b'') Componente_Tel
							,CASE WHEN Length('||P_BDVISTA|| '.SUBSTREXPREG(Token,''([5]{1}[0-9]{2}|[5]{1}[0-9]{1}|[1-9])([2-9]{1}[0-9]{6})\b|[1-9]([2-9]{1}[0-9]{6})|[2-9][0-9]{6}\b''))>7 
										
											   THEN Substr(Token,1,Length('||P_BDVISTA|| '.SUBSTREXPREG(Token,''([5]{1}[0-9]{2}|[5]{1}[0-9]{1}|[1-9])([2-9]{1}[0-9]{6})|[2-9][0-9]{6}\b''))-7)
							
							ELSE   ''''
									
							END Componente_Aux
							,Cast ('''' AS VARCHAR(100)) Componente_Comp
							,Coalesce(b.token_ext, -1) token_ext
					FROM '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo a
					LEFT JOIN (SELECT cod_dw_ubicacion_original,
									   Min (token_ndx)-1 token_ext
								FROM '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo
								WHERE Tipo=''EXT''
								GROUP BY 1) b
					ON a.cod_Dw_ubicacion_original=b.cod_Dw_ubicacion_original
					WHERE Tipo=''Telefono''
					QUALIFY (Row_Number()Over(PARTITION BY a.cod_dw_ubicacion_original, tipo ORDER BY token_ndx ASC))=1
					)WITH DATA
					PRIMARY INDEX (cod_Dw_ubicacion_original,token_ndx);'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo (5):. Crear y carga la tabla Tmp_SplitTelefonoFijo2' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
-- Actualiza estadisticas a EmailsEstandarizados
--------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (cod_Dw_ubicacion_original,token_ndx) ON ' || P_BDSTAGE ||'.Tmp_SplitTelefonoFijo2'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo (6):. Actualizar estadisticas a la tabla Tmp_SplitTelefonoFijo2' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; ---------------------------
 -- Busca y borra si existe la tabla Tmp_SplitTelefonoFijo3
 ---------------------------
 SELECT TABLENAME INTO :Temp FROM dbc.tables WHERE databasename =:P_BDSTAGE AND TABLENAME = 'Tmp_SplitTelefonoFijo3' ; IF ACTIVITY_COUNT > 0 THEN SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo3'; CALL DBC.SysExecSQL(:V_CADENA); END IF; -----------------------------
 -- Se crea y carga la tabla Tmp_SplitTelefonoFijo2
 -----------------------------
 SET V_CADENA = ''; SET V_CADENA = 'CREATE MULTISET TABLE '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo3
					AS 
					(WITH RECURSIVE temp_table (cod_dw_ubicacion_original,Texto_Ext,token_ndx) AS
					   ( SELECT r.cod_dw_ubicacion_original,
						  Cast('''' AS VARCHAR(100)) Texto_Ext
						  ,token_ext
						 FROM '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo2 r     
					   UNION ALL
						 SELECT i.cod_dw_ubicacion_original,d.Texto_Ext||'' ''||i.token,i.token_ndx
						 FROM temp_table d, '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo i
						 WHERE d.token_ndx+1= i.token_ndx
						 AND d.cod_Dw_ubicacion_original=i.cod_Dw_ubicacion_original
						 AND i.tipo=''EXT''
					   ) 
					   SELECT * FROM temp_table 
					)WITH DATA
					PRIMARY INDEX (cod_dw_ubicacion_original,token_ndx);'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo (7):. Crear y carga la tabla Tmp_SplitTelefonoFijo3' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --------------------
 -- Actualiza estadisticas a EmailsEstandarizados
 --------------------
 SET V_CADENA = ''; SET V_CADENA = 'COLLECT STAT INDEX (cod_dw_ubicacion_original,token_ndx) ON ' || P_BDSTAGE ||'.Tmp_SplitTelefonoFijo3'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo (8):. Actualizar estadisticas a la tabla Tmp_SplitTelefonoFijo2' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; SET V_CADENA = ''; SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.TelefonoFijoEstandarizado
					FROM (SELECT a.cod_Dw_ubicacion_original, b.Componente_Tel, B.Componente_Aux, trim(c.texto_Ext) Componente_Comp
							FROM '||P_BDSTAGE || '.TelefonoFijoEstandarizado  a
							INNER JOIN '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo2 b
							ON  a.cod_Dw_ubicacion_original= b.cod_Dw_ubicacion_original
							INNER JOIN '||P_BDSTAGE || '.Tmp_SplitTelefonoFijo3 c
							ON a.cod_Dw_ubicacion_original=c.cod_Dw_ubicacion_original
							QUALIFY (Row_Number() Over (PARTITION BY a.cod_Dw_ubicacion_original ORDER BY b.token_ndx asc,  c.token_ndx DESC))=1 ) A		
					SET Componente_Tel = A.Componente_Tel,						 
						 Componente_Comp = A.Componente_Comp
					WHERE TelefonoFijoEstandarizado.cod_Dw_ubicacion_original = A.cod_Dw_ubicacion_original'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo (9):. Actualizar valores en TelefonoFijoEstandarizado' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; --Componente_Tel - Tel_N
 --Componente_Aux - Tel_Comp1
 --Componente_Comp - Tel_Comp2 y Tel_Comp3
 --------------------
 -- Cursor de patrones, pendiente agregar el filtro por tipo de telefono
 --------------------
 SET V_CADENA = 'SELECT	Cod_DW_Patron_Telefono, Patron, Componente_Tel, COALESCE(Componente_Aux, ''NULL'') Componente_Aux, COALESCE(Componente_Comp , ''NULL'') Componente_Comp
					FROM '|| P_BDDATOS ||'.PATRON_TELEFONO
					WHERE Tipo_Telefono = ''Fijo''
					ORDER BY Orden'; PREPARE the_statement FROM V_CADENA; OPEN cur_patrones_select; CUR1:LOOP FETCH cur_patrones_select INTO V_Cod_DW_Patron_Telefono, V_Patron, V_Componente_Tel, V_Componente_Aux, V_Componente_Comp; IF SQLSTATE <> '00000' THEN LEAVE CUR1; END IF; SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.TelefonoFijoEstandarizado
						     SET Componente_Tel = ' || V_Componente_Tel || '								
								,Componente_Comp = ' || V_Componente_Comp || '
						WHERE ' || V_Patron || '
						AND Componente_Tel IS NULL'; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo(9.1):. Actualizando Componente_Tel, Componente_Aux, Componente_Comp mediate reglas' ,V_ERROR); IF V_Cod_DW_Patron_Telefono IN (21,22) THEN SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.TelefonoFijoEstandarizado
						     SET Componente_Tel = ' || V_Componente_Tel || '								
								,Componente_Comp = ' || V_Componente_Comp || '
						WHERE ' || V_Patron ; CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo(9.11):. Actualizando Componente_Tel, Componente_Aux, Componente_Comp mediate reglas 21 y 22' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; END IF; END LOOP CUR1; CLOSE cur_patrones_select; SET V_CADENA = ''; SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.TelefonoFijoEstandarizado
					SET DIR_CB_VALIDA = CASE  WHEN CHARACTER_LENGTH( TRIM(Componente_Tel) ) = 7 AND Codigo_Ciudad_Dane > 0 THEN 
											   ''VALIDA''
											 ELSE 
											  ''NO VALIDA''
										 END,
						Componente_Tel = CASE  WHEN CHARACTER_LENGTH( TRIM(Componente_Tel) ) <> 7 THEN 
						                          REC_VISTA.eListGetValByIdx(Componente_Tel, ''|'', 1) 
										    ELSE 
											  Componente_Tel
						                 END'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo(10):. Validando si la linea de telefono es valida o no valida' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; SET V_CADENA = ''; SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.TelefonoFijoEstandarizado
					SET Componente_Tel = CASE WHEN Ubicacion_Stand01 Like ''%-%'' 
										   THEN REC_VISTA.eListGetValByIdx(Ubicacion_Stand01, ''-'', 1)   
										    ELSE Trim(Ubicacion_Stand01)
										  END  
					Where Componente_Tel is null'; --------------------
 -- Ejecuta cadena
 --------------------
 CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote ,V_StartTimeStampPadre ,:P_Nombre_Proceso_Padre ,:V_CADENA ,'PRO_StandardizationTelFijo(11):. Actualizando Componente_Tel cuando no fue estandarizado' ,V_ERROR); SET P_ERROR = V_ERROR; IF CHARACTER_LENGTH(V_ERROR) > 0 THEN LEAVE L1; END IF; END L1; END;

REPLACE   PROCEDURE REC_DATOS.PRO_StandardizationTelMovil
 (IN	P_Lote			INTEGER
,IN	P_StartTimeStampPadre	VARCHAR(20)
,IN	P_Nombre_Proceso_Padre	VARCHAR(30)
,IN	P_BDDATOS		VARCHAR(20)
,IN	P_BDVISTA		VARCHAR(20)
,IN	P_BDSTAGE		VARCHAR(20)
,OUT	P_ERROR			VARCHAR(500)
)
/*
 * ############################################################################################
 * 
 * Objetivo:		Estandariza el telefono fijo como ubicacion del insumo InsumoTelefonoMovil.
 *			Dejando el resultado en TelefonoMovil_Estandarizado
 * Fecha:		2016/11/09
 * Realizado por:	Luis E Ramirez
 * Proyecto:		Nuevo reconocer
 * Script:		Create_PRO_StandardizationTelMovil.sql
 * 
 * 
 * 
 * BITACORA
 * ------------------------------------------------------------------------------------
 * Fecha		Objetivo			                                   Realizado por
 * 11-02-2021   Permitir visualizar en el log las reglas aplicadas.    Fernando Garrido. 
 * 20-05-2021   # 1 Incluir funcionalidad para excluir  celulares en el proceso y marcarlos como NO VALIDO  para no mostrar estos datos en la salida del cliente
 *2022-08-03 #2 Se Adiciona Regla para la Antiguedad de los datos  John Bueno
 *30/01/2023  Se reinician las variables vsentencia                Omar Delgado.
 * -------------------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ############################################################################################
 */
BEGIN
	

------------------------
-- Declaracion de variables
------------------------
	DECLARE V_StartTimeStampPadre	TIMESTAMP(6);
	DECLARE	V_ERROR			VARCHAR(30);
	DECLARE V_CADENA		VARCHAR(32000);
	DECLARE Temp CHAR(30);
	DECLARE V_Patron		VARCHAR(500);
	DECLARE V_Componente_Tel	VARCHAR(500);
	DECLARE V_Componente_Aux	VARCHAR(500);
	DECLARE V_Componente_Comp	VARCHAR(500);
	DECLARE Contador INTEGER; 
	DECLARE V_Sentencia VARCHAR(500);
	DECLARE V_Flag_Recursiva VARCHAR(1);
	DECLARE V_Cod_DW_Regla_Est_Ubica INTEGER;
	DECLARE V_Contador INTEGER;
	DECLARE V_Condicion VARCHAR(500);
	
	-- Cursores
	
	DECLARE cur_reglas_select NO SCROLL CURSOR
	FOR the_statement;

	DECLARE cur_patrones_select NO SCROLL CURSOR
	FOR the_statement;
	
L1:	BEGIN

	SET P_ERROR = '';
	SET V_StartTimeStampPadre = Cast(P_StartTimeStampPadre AS TIMESTAMP(6) Format 'yyyy-mm-ddhh:mi:ss');
	--SET V_StartTimeStampPadre =DATE;
	---------------------------
	-- Busca y borra si existe la tabla tmp_TeleMovilEstandarizado
	---------------------------
	SELECT TableName 
	INTO :Temp
	FROM dbc.tables
	WHERE databasename =:P_BDSTAGE 
	AND TableName = 'tmp_TeleMovilEstandarizado' ;
	
	IF Activity_Count > 0 THEN
		SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_TeleMovilEstandarizado';
		CALL DBC.SysExecSQL(:V_CADENA);
	END IF;
													
	-----------------------------
	-- Se crea y carga la tabla tmp_TeleMovilEstandarizado
	-----------------------------

	SET V_CADENA = '';
	SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_TeleMovilEstandarizado
					 AS (
					SELECT	Cod_DW_Reporte_Ubic_Original
						, ' || P_BDVISTA || '.REPLEXPREG(Texto_Ubicacion_Original, ''^[A-Za-z0-9]?$'') Ubicacion_Stand
						,cast(NULL AS VARCHAR(20)) Componente_Tel
						,cast(NULL AS VARCHAR(20)) Componente_Aux
						,cast(NULL AS VARCHAR(20)) Componente_Comp
						,Texto_Ubicacion_Original
						,Cod_DW_Tipo_Ubicacion
						,Cod_DW_Fuente
						,Lote
						,Id_Buro_Suscriptor
						,Id_Buro_Persona
						,Cod_DW_Cta
						,Cod_DW_Hash
						,Cod_DW_Ubic
						,Valor
						,Texto_Ciudad
						,Codigo_Ciudad_Dane
						,Fecha_Reporte	
						,Cod_DW_Ubicacion_Original
						,Cod_DW_Tipo_Ubicacion_Dir
						,Usuario_BD
						,COALESCE(NULL, ''NO VALIDA'') DIR_CB_VALIDA
					FROM ' || P_BDSTAGE ||'.InsumoTelefonoMovil
					) WITH DATA
					PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';
			
	
	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
									,V_StartTimeStampPadre
									,:P_Nombre_Proceso_Padre
									,:V_CADENA
									,'PRO_StandardizationTelMovil (1):. Crear y carga la tabla tmp_TeleMovilEstandarizado'
									,V_ERROR);
			
	SET P_ERROR = V_ERROR;
        
        IF Character_Length(V_ERROR) > 0 THEN
		LEAVE L1;
	END IF;
	--------------------
	-- Actualiza estadisticas a tmp_TeleMovilEstandarizado
	--------------------
	SET V_CADENA = '';
	SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN(Ubicacion_Stand, Componente_Tel) ON ' || P_BDSTAGE ||'.tmp_TeleMovilEstandarizado';
	
	--------------------
	-- Ejecuta cadena
	--------------------
	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
									,V_StartTimeStampPadre
									,:P_Nombre_Proceso_Padre
									,:V_CADENA
									,'PRO_StandardizationTelMovil (2):. Actualizar estadisticas a la tabla tmp_TeleMovilEstandarizado'
									,V_ERROR);
			
	SET P_ERROR = V_ERROR;
        
        IF Character_Length(V_ERROR) > 0 THEN
		LEAVE L1;
	END IF;
	--Componente_Tel - Tel_N
	--Componente_Aux - Tel_Comp1
	--Componente_Comp - Tel_Comp2 y Tel_Comp3
	--------------------
	-- Cursor de patrones, pendiente agregar el filtro por tipo de telefono
	--------------------
	SET V_CADENA = 'SELECT	Patron, Componente_Tel, COALESCE(Componente_Aux, ''NULL'') Componente_Aux, COALESCE(Componente_Comp , ''NULL'') Componente_Comp
					FROM '|| P_BDDATOS ||'.PATRON_TELEFONO
					WHERE Tipo_Telefono = ''Movil''
					ORDER BY Orden';
	
	SET Contador = 0;
	SET V_Patron = '';
	SET V_Componente_Tel = '';
	SET V_Componente_Aux = '';
	SET V_Componente_Comp = '';
	
	PREPARE the_statement FROM V_CADENA;
	
	OPEN cur_patrones_select;
	
	CUR1:LOOP
		FETCH cur_patrones_select INTO V_Patron, V_Componente_Tel, V_Componente_Aux, V_Componente_Comp;
		
		IF SqlState <> '00000' THEN LEAVE CUR1;
		END IF;
		
		SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.tmp_TeleMovilEstandarizado
						SET Componente_Tel = ' || V_Componente_Tel || '
							,Componente_Aux = ' || V_Componente_Aux || '
							,Componente_Comp = ' || V_Componente_Comp || '
						WHERE ' || V_Patron ;
			
		--CALL DBC.SysExecSQL(:V_CADENA);
		
		SET Contador = Contador+1;
		
		IF Contador < 10 THEN 
		  SET V_CADENA = V_CADENA || ' AND Componente_Tel IS NULL';
		END IF; 	
		
		
		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
									,V_StartTimeStampPadre
									,:P_Nombre_Proceso_Padre
									,:V_CADENA
									,'PRO_StandardizationTelMovil (3): Ejecutando Regla '||Trim(Contador)||' en tmp_TeleMovilEstandarizado'
									,V_ERROR);

	END LOOP CUR1;

	CLOSE cur_patrones_select;
	
	
	
    SET V_CADENA = '';
	SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.tmp_TeleMovilEstandarizado
					SET DIR_CB_VALIDA = CASE  WHEN CHARACTER_LENGTH( TRIM(Componente_Tel) ) = 10 THEN 
											   ''VALIDA''
											 ELSE 
											  ''NO VALIDA''
										 END,
					  Componente_Tel = CASE  WHEN CHARACTER_LENGTH( TRIM(Componente_Tel) ) <> 10 THEN 
						                          REC_VISTA.eListGetValByIdx(Componente_Tel, ''|'', 1) 
										    ELSE 
											  Componente_Tel
						                 END';
	
	--------------------
	-- Ejecuta cadena
	--------------------
	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
									,V_StartTimeStampPadre
									,:P_Nombre_Proceso_Padre
									,:V_CADENA
									,'PRO_StandardizationTelMovil(4):. Validando si la linea de celular es valida o no valida'
									,V_ERROR);
	---------------------------
	-- Busca y borra si existe la tabla tmp_TeleMovilEstandarizado
	---------------------------
	SELECT TableName 
	INTO :Temp
	FROM dbc.tables
	WHERE databasename =:P_BDSTAGE 
	AND TableName = 'TelefonoMovil_Estandarizado' ;
	
	IF Activity_Count > 0 THEN
		SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.TelefonoMovil_Estandarizado';
		CALL DBC.SysExecSQL(:V_CADENA);
	END IF;
	
	-----------------------------
	-- Se crea y carga la tabla TelefonoMovil_Estandarizado
	-----------------------------

	SET V_CADENA = '';
	SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.TelefonoMovil_Estandarizado
					 AS (
					SELECT	dir.Cod_DW_Reporte_Ubic_Original
						,CASE WHEN trim(dir.Ubicacion_Stand) = '''' OR dir.Ubicacion_Stand IS NULL THEN 
						    dir.Texto_Ubicacion_Original 
						   ELSE 
						    dir.Ubicacion_Stand
						 END Ubicacion_Stand
						,dir.Componente_Tel
						,dir.Componente_Aux
						,dir.Componente_Comp
						,dir.Texto_Ubicacion_Original
						,dir.Cod_DW_Tipo_Ubicacion
						,dir.Cod_DW_Fuente
						,dir.Lote
						,dir.Id_Buro_Suscriptor
						,dir.Id_Buro_Persona
						,dir.Cod_DW_Cta
						,dir.Cod_DW_Hash
						,dir.Cod_DW_Ubic
						,dir.Valor
						,dir.Texto_Ciudad
						,dir.Codigo_Ciudad_Dane
						,dir.Fecha_Reporte

						,dir.Cod_DW_Ubicacion_Original
						,dir.Cod_DW_Tipo_Ubicacion_Dir
						,dir.Usuario_BD
						,Rango.Cod_Dw_Rango_Operadora
						,CASE 
							WHEN A.Descripcion_Exclusion_Celular IS NOT NULL THEN ''NO VALIDA''
							ELSE dir.DIR_CB_VALIDA
						END DIR_CB_VALIDA /*#1*/
						
					FROM ' || P_BDSTAGE ||'.tmp_TeleMovilEstandarizado dir
					LEFT JOIN (
							select Valor_Origen, Descripcion_Atributo, Cod_DW_Atributo Cod_Dw_Rango_Operadora
							from '|| P_BDDATOS ||'.ATRIBUTO
							where Cod_DW_Tipo_Atributo in (
								select Cod_DW_Tipo_Atributo
								from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
								where Descripcion_Tipo_Atributo = ''Valor_Rango_Operadora''
							)
						) Rango
						ON substr(dir.Componente_Tel , 1 , 3) = Rango.Valor_Origen

					LEFT JOIN (
											SELECT Descripcion_Exclusion_Celular, Valor_Exclusion_Celular 
											FROM '|| P_BDVISTA ||'.V_Exclusion_Celular
							
										) A
						ON dir.Componente_Tel = A.Valor_Exclusion_Celular  /*#1*/
						
						
					) WITH DATA
					PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';

	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
									,V_StartTimeStampPadre
									,:P_Nombre_Proceso_Padre
									,:V_CADENA
									,'PRO_StandardizationTelMovil (5):. Actualizar estadisticas a la tabla TelefonoMovil_Estandarizado'
									,V_ERROR);
			
	SET P_ERROR = V_ERROR;
        
        IF Character_Length(V_ERROR) > 0 THEN
		LEAVE L1;
	END IF;
	
	--------------------
	-- Actualiza estadisticas a tmp_TeleMovilEstandarizado
	--------------------
	SET V_CADENA = '';
	SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.TelefonoMovil_Estandarizado';
	
	--------------------
	-- Ejecuta cadena
	--------------------
	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
			,V_StartTimeStampPadre
			,:P_Nombre_Proceso_Padre
			,:V_CADENA
			,'PRO_StandardizationTelMovil (6):. Actualizar estadisticas a la tabla TelefonoMovil_Estandarizado'
			,V_ERROR);
			
	SET P_ERROR = V_ERROR;
	
	 		------------------------------------------------------------------------------------
		--03/08/2022
		-- Cursor de reglas para ETAPA IN (1)
		-- Reglas de Antiguedad en los datos que se Validan si se cumple con la condicion
		------------------------------------------------------------------------------------
		SET V_CADENA = 'SELECT  Sentencia
				,Condicion
				,Flag_Recursiva
				,Cod_DW_Regla_Est_Ubica
				FROM '|| P_BDDATOS ||'.REGLA_EST_UBICACION
				WHERE Cod_DW_Tipo_Ubicacion_Dir IN (
							select Cod_DW_Atributo
							from '|| P_BDDATOS ||'.ATRIBUTO
							where Cod_DW_Tipo_Atributo in (
							select Cod_DW_Tipo_Atributo
							from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
							where Descripcion_Tipo_Atributo = ''Tipo_Ubicacion''
					) AND Valor_Origen = ''Telefono Movil''
					) AND  Flag_Activo = ''S'' AND ETAPA IN (1)
				ORDER BY Orden'; 

		SET V_Contador = 0;
		SET V_Sentencia = '';
		SET V_Condicion = '';
		SET V_Cod_DW_Regla_Est_Ubica = '';
		
		PREPARE the_statement FROM V_CADENA; 
		OPEN cur_reglas_select; 			
			CUR2: LOOP FETCH cur_reglas_select INTO V_Sentencia, V_Condicion, V_Flag_Recursiva, V_Cod_DW_Regla_Est_Ubica; 
			
		IF SQLCODE <> 0 THEN 
				LEAVE CUR2; 
		END IF;  

		SET V_Contador = V_Contador +1;
		SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.TelefonoMovil_Estandarizado
				SET ' || V_Sentencia || '
				WHERE ' || V_Condicion;   


		CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote 						
				,V_StartTimeStampPadre 
				,:P_Nombre_Proceso_Padre 
				,:V_CADENA 
				,'PRO_StandardizationTelMovil(7):'||' Ejecucion de reglas 1 iteracion: '||trim(V_Contador)||' Regla:'||trim(V_Cod_DW_Regla_Est_Ubica) 
				,V_ERROR); 

		SET P_ERROR = V_ERROR; 
		IF CHARACTER_LENGTH(V_ERROR) > 0 
				THEN LEAVE CUR2; 
		END IF; 

		END LOOP CUR2;
		CLOSE cur_reglas_select;
		
		------------------------------------------------------------------------------------
		--03/08/2022
		-- FIN
		------------------------------------------------------------------------------------
	
	
				
	END L1;
    
END;

REPLACE   PROCEDURE REC_DATOS.PRO_StandardizationTelMovilFGM
(IN	P_Lote			INTEGER
,IN	P_StartTimeStampPadre	VARCHAR(20)
,IN	P_Nombre_Proceso_Padre	VARCHAR(30)
,IN	P_BDDATOS		VARCHAR(20)
,IN	P_BDVISTA		VARCHAR(20)
,IN	P_BDSTAGE		VARCHAR(20)
,OUT	P_ERROR			VARCHAR(500)
)
/*
 * ################################################################################
 * 
 * Objetivo:		Estandariza el telefono fijo como ubicacion del insumo InsumoTelefonoMovil.
 *			Dejando el resultado en TelefonoMovil_EstandarizadoFGM
 * Fecha:		2016/11/09
 * Realizado por:	Luis E Ramirez
 * Proyecto:		Nuevo reconocer
 * Script:		Create_PRO_StandardizationTelMovil.sql
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha		Objetivo			Realizado por
 * 
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */
BEGIN
	

------------------------
-- Declaracion de variables
------------------------
	DECLARE V_StartTimeStampPadre	TIMESTAMP(6);
	DECLARE	V_ERROR			VARCHAR(30);
	DECLARE V_CADENA		VARCHAR(32000);
	DECLARE Temp CHAR(30);
	DECLARE V_Patron		VARCHAR(500);
	DECLARE V_Componente_Tel	VARCHAR(500);
	DECLARE V_Componente_Aux	VARCHAR(500);
	DECLARE V_Componente_Comp	VARCHAR(500);
	
	-- Cursores
	DECLARE cur_patrones_select NO SCROLL CURSOR
	FOR the_statement;
	
L1:	BEGIN

	SET P_ERROR = '';
	SET V_StartTimeStampPadre = cast(P_StartTimeStampPadre as timestamp(6) format 'yyyy-mm-ddhh:mi:ss');
	--SET V_StartTimeStampPadre =DATE;
	---------------------------
	-- Busca y borra si existe la tabla tmp_TeleMovilEstandarizadoFGM
	---------------------------
	SELECT tablename 
	INTO :Temp
	FROM dbc.tables
	WHERE databasename =:P_BDSTAGE 
	AND tablename = 'tmp_TeleMovilEstandarizadoFGM' ;
	
	IF ACTIVITY_COUNT > 0 THEN
		SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.tmp_TeleMovilEstandarizadoFGM';
		CALL DBC.SysExecSQL(:V_CADENA);
	END IF;
													
	-----------------------------
	-- Se crea y carga la tabla tmp_TeleMovilEstandarizadoFGM
	-----------------------------

	SET V_CADENA = '';
	SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.tmp_TeleMovilEstandarizadoFGM
					 AS (
					SELECT	Cod_DW_Reporte_Ubic_Original
						, ' || P_BDVISTA || '.REPLEXPREG(Texto_Ubicacion_Original, ''^[A-Za-z0-9]?$'') Ubicacion_Stand
						,cast(NULL AS VARCHAR(20)) Componente_Tel
						,cast(NULL AS VARCHAR(20)) Componente_Aux
						,cast(NULL AS VARCHAR(20)) Componente_Comp
						,Texto_Ubicacion_Original
						,Cod_DW_Tipo_Ubicacion
						,Cod_DW_Fuente
						,Lote
						,Id_Buro_Suscriptor
						,Id_Buro_Persona
						,Cod_DW_Cta
						,Cod_DW_Hash
						,Cod_DW_Ubic
						,Valor
						,Texto_Ciudad
						,Codigo_Ciudad_Dane
						,Fecha_Reporte	
						,Cod_DW_Ubicacion_Original
						,Cod_DW_Tipo_Ubicacion_Dir
						,Usuario_BD
						,COALESCE(NULL, ''NO VALIDA'') DIR_CB_VALIDA
					FROM ' || P_BDSTAGE ||'.InsumoTelefonoMovil
					) WITH DATA
					PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';
			
	
	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
									,V_StartTimeStampPadre
									,:P_Nombre_Proceso_Padre
									,:V_CADENA
									,'PRO_StandardizationTelMovil (1):. Crear y carga la tabla tmp_TeleMovilEstandarizadoFGM'
									,V_ERROR);
			
	SET P_ERROR = V_ERROR;
        
        IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		LEAVE L1;
	END IF;
	--------------------
	-- Actualiza estadisticas a tmp_TeleMovilEstandarizadoFGM
	--------------------
	SET V_CADENA = '';
	SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original), COLUMN(Ubicacion_Stand, Componente_Tel) ON ' || P_BDSTAGE ||'.tmp_TeleMovilEstandarizadoFGM';
	
	--------------------
	-- Ejecuta cadena
	--------------------
	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
									,V_StartTimeStampPadre
									,:P_Nombre_Proceso_Padre
									,:V_CADENA
									,'PRO_StandardizationTelMovil (2):. Actualizar estadisticas a la tabla tmp_TeleMovilEstandarizadoFGM'
									,V_ERROR);
			
	SET P_ERROR = V_ERROR;
        
        IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		LEAVE L1;
	END IF;
	--Componente_Tel - Tel_N
	--Componente_Aux - Tel_Comp1
	--Componente_Comp - Tel_Comp2 y Tel_Comp3
	--------------------
	-- Cursor de patrones, pendiente agregar el filtro por tipo de telefono
	--------------------
	SET V_CADENA = 'SELECT	Patron, Componente_Tel, COALESCE(Componente_Aux, ''NULL'') Componente_Aux, COALESCE(Componente_Comp , ''NULL'') Componente_Comp
					FROM '|| P_BDDATOS ||'.PATRON_TELEFONO
					WHERE Tipo_Telefono = ''Movil''
					ORDER BY Orden';
	
	PREPARE the_statement FROM V_CADENA;
	
	OPEN cur_patrones_select;
	
	CUR1:LOOP
		FETCH cur_patrones_select INTO V_Patron, V_Componente_Tel, V_Componente_Aux, V_Componente_Comp;
		
		IF SQLSTATE <> '00000' THEN LEAVE CUR1;
		END IF;
		
		SET V_CADENA = 'UPDATE '||P_BDSTAGE || '.tmp_TeleMovilEstandarizadoFGM
						SET Componente_Tel = ' || V_Componente_Tel || '
							,Componente_Aux = ' || V_Componente_Aux || '
							,Componente_Comp = ' || V_Componente_Comp || '
						WHERE ' || V_Patron || '
						AND Componente_Tel IS NULL';
			
		CALL DBC.SysExecSQL(:V_CADENA);

	END LOOP CUR1;

	CLOSE cur_patrones_select;
	
	---------------------------
	-- Busca y borra si existe la tabla tmp_TeleMovilEstandarizadoFGM
	---------------------------
	SELECT tablename 
	INTO :Temp
	FROM dbc.tables
	WHERE databasename =:P_BDSTAGE 
	AND tablename = 'TelefonoMovil_EstandarizadoFGM' ;
	
	IF ACTIVITY_COUNT > 0 THEN
		SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.TelefonoMovil_EstandarizadoFGM';
		CALL DBC.SysExecSQL(:V_CADENA);
	END IF;
	
	-----------------------------
	-- Se crea y carga la tabla TelefonoMovil_EstandarizadoFGM
	-----------------------------

	SET V_CADENA = '';
	SET V_CADENA = 'CREATE MULTISET TABLE ' || P_BDSTAGE ||'.TelefonoMovil_EstandarizadoFGM
					 AS (
					SELECT	dir.Cod_DW_Reporte_Ubic_Original
						,CASE WHEN trim(dir.Ubicacion_Stand) = '''' OR dir.Ubicacion_Stand IS NULL THEN 
						    dir.Texto_Ubicacion_Original 
						   ELSE 
						    dir.Ubicacion_Stand
						 END Ubicacion_Stand
						,dir.Componente_Tel
						,dir.Componente_Aux
						,dir.Componente_Comp
						,dir.Texto_Ubicacion_Original
						,dir.Cod_DW_Tipo_Ubicacion
						,dir.Cod_DW_Fuente
						,dir.Lote
						,dir.Id_Buro_Suscriptor
						,dir.Id_Buro_Persona
						,dir.Cod_DW_Cta
						,dir.Cod_DW_Hash
						,dir.Cod_DW_Ubic
						,dir.Valor
						,dir.Texto_Ciudad
						,dir.Codigo_Ciudad_Dane
						,dir.Fecha_Reporte

						,dir.Cod_DW_Ubicacion_Original
						,dir.Cod_DW_Tipo_Ubicacion_Dir
						,dir.Usuario_BD
						,Rango.Cod_Dw_Rango_Operadora
						,CASE WHEN (COALESCE( CHARACTER_LENGTH( TRIM(dir.Ubicacion_Stand)), 0)  = 10 AND Substr(Ubicacion_Stand,1,3) Between 300 AND 399) THEN 
						       ''VALIDA''
						  ELSE  Dir.DIR_CB_VALIDA
					     END DIR_CB_VALIDA
					FROM ' || P_BDSTAGE ||'.tmp_TeleMovilEstandarizadoFGM dir
					LEFT JOIN (
							select Valor_Origen, Descripcion_Atributo, Cod_DW_Atributo Cod_Dw_Rango_Operadora
							from '|| P_BDDATOS ||'.ATRIBUTO
							where Cod_DW_Tipo_Atributo in (
								select Cod_DW_Tipo_Atributo
								from '|| P_BDDATOS ||'.TIPO_ATRIBUTO
								where Descripcion_Tipo_Atributo = ''Valor_Rango_Operadora''
							)
						) Rango
						ON substr(dir.Componente_Tel , 1 , 3) = Rango.Valor_Origen
					) WITH DATA
					PRIMARY INDEX (Cod_DW_Reporte_Ubic_Original)';

	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
									,V_StartTimeStampPadre
									,:P_Nombre_Proceso_Padre
									,:V_CADENA
									,'PRO_StandardizationTelMovil (3):. Actualizar estadisticas a la tabla TelefonoMovil_EstandarizadoFGM'
									,V_ERROR);
			
	SET P_ERROR = V_ERROR;
        
        IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		LEAVE L1;
	END IF;
	
	--------------------
	-- Actualiza estadisticas a tmp_TeleMovilEstandarizadoFGM
	--------------------
	SET V_CADENA = '';
	SET V_CADENA = 'COLLECT STAT INDEX (Cod_DW_Reporte_Ubic_Original) ON ' || P_BDSTAGE ||'.TelefonoMovil_EstandarizadoFGM';
	
	--------------------
	-- Ejecuta cadena
	--------------------
	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
			,V_StartTimeStampPadre
			,:P_Nombre_Proceso_Padre
			,:V_CADENA
			,'PRO_StandardizationTelMovil (4):. Actualizar estadisticas a la tabla TelefonoMovil_EstandarizadoFGM'
			,V_ERROR);
			
	SET P_ERROR = V_ERROR;
				
	END L1;
    
END;

