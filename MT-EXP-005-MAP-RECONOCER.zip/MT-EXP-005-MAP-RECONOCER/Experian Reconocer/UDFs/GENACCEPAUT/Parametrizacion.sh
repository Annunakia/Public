awk -F"," -v ord=2 '
{if (val == ""){ val=ord+1} else {val=val+1}; print "\tNOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));";
print "\tstrcpy (NOM_STANDARD->word,\""$1"\");";
print "\tstrcpy (NOM_STANDARD->nomenclature,\""$2"\");";
print "\tstrcpy (NOM_STANDARD->LevelTrack1,\""$3"\");";
print "\tstrcpy (NOM_STANDARD->LevelTrack2,\""$4"\");";
print "\tstrcpy (NOM_STANDARD->LevelTrack3,\""$5"\");";
print "\tstrcpy (NOM_STANDARD->soundexWord,\""$6"\");";
print "\tStandardEnd->next=NOM_STANDARD;";
print "\tStandardEnd=NOM_STANDARD;\n"}' Nomenclatura.csv > Nomenclatura.c
