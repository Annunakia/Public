/*
 * ################################################################################
 * 
 * Objetivo:	  
 * Fecha:	  2017/01/17
 * Realizado por: Luis E Ramirez (Capgemini)
 * Parametros:	  
 * Proyecto:	  Experian - Reconocer
 * Script:	  GenerateAcceptance.c
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha	Objetivo				Realizado por
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */

#include "loadParamsAcepAut.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

// Funcion referenciada por Teradata
void GenerateAcceptance (
		VARCHAR_LATIN *inStr,
		VARCHAR_LATIN *sounDex,
		VARCHAR_LATIN *outStr,
		SQL_TEXT extname[129],
		SQL_TEXT specific_name[129],
		SQL_TEXT error_message[257])
{
	strcpy (outStr, "");
	
	//Estandar de nomenclaturas
	NOM_STANDARD = NOM_STANDARD_START = NULL;
	iniNOM_STANDARD ();
	
	//Reglas
	RULES = RULES_START = NULL;
	iniRULES ();
	
	if (strlen(inStr) >0 && strlen(sounDex) > 0)
	{
		identNomenclature(outStr, inStr, sounDex);
	
		if (outStr == NULL || strcmp(outStr, "") == 0)
			strcpy (outStr, "");
	}
	                                            
	freeNOM_STANDARD ();
	freeRULES ();

}
