/*
 * ################################################################################
 * 
 * Objetivo:	  Agrega un string newStr apartir de la posicion que marque el patron inExp 
 *		  mas la cantidad de posiciones que indique desp 
 *		  Funciona con el campo pos = -1
 *		  Cuando desp es menor que cero, india las veces que se deveulve el punto de partida
 *		     para agregar el string desde el final de la expresi�n.
 * Fecha:	  2016/27/14
 * Realizado por: Luis E Ramirez (Capgemini)
 * Parametros:	  inStr, inExp, newStr, pos, desp, outStr
 * Proyecto:	  Experian - Reconocer
 * Script:	  replExpRegO1.c
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha		Objetivo			Realizado por
 * 
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */
#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include "operationsString.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//Funciones
void replExpRegO1 (
			VARCHAR_LATIN *inStr,
			VARCHAR_LATIN *inExp,
			VARCHAR_LATIN *newStr,
			int	      *pos,
			int	      *desp,
			VARCHAR_LATIN *outStr,
			char sqlstate[6])
{
	int b,e, ba=0, ea=0,loop=3,recursive = 0;
	char *match, *aux, antMatch[100];
		
	strcpy (outStr, "");
	strcpy (outStr, inStr);
	strcpy (antMatch, "");
	
	match = (char*)malloc(100*sizeof(char));
	aux = (char*)malloc(512*sizeof(char)); 
	
	while (recursive <= 5 && loop > 0) 
	{
		sprintf (match, "");
		sprintf (aux, "");
		regexp(outStr,inExp,&b,&e, match);
		
		if (strcmp(match, "") != 0) {
			if (strcmp (match, antMatch) == 0)
			{
				loop=0;
				break;
			}
			
			strcpy(antMatch, match);
			
			if (*pos == -1) {
				if (*desp < 0)
					add_str_str(outStr, newStr, (int)*desp+e, aux);
				else
					add_str_str(outStr, newStr, *desp +b-1, aux);
					//sprintf (aux, "R:%d - O:%s - N:%s - P:%d",recursive, outStr, newStr, *desp +b-1);
					
				sprintf(outStr,"%s", aux);
			}
			
			recursive++;
			
		} else loop = 0;
	}
	
	free(match);
	free(aux);
	strcpy (antMatch, "");
}
