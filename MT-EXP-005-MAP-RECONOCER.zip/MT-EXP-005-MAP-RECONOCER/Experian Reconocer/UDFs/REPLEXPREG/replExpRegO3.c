/*
 * ################################################################################
 * 
 * Objetivo:	  Si la expresion es valida, reemplaza en el string  StrHost por 
 *		  newStr las veces que se repita.
 * Fecha:	  2016/27/14
 * Realizado por: Luis E Ramirez (Capgemini)
 * Parametros:	  inStr, inExp, StrHost, newStr, outStr
 * Proyecto:	  Experian - Reconocer
 * Script:	  replExpRegO3.c
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha		Objetivo			Realizado por
 * 
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */
#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include "operationsString.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//Funciones
void replExpRegO3 (
			VARCHAR_LATIN *inStr,
			VARCHAR_LATIN *inExp,
			VARCHAR_LATIN *StrHost,
			VARCHAR_LATIN *newStr,
			VARCHAR_LATIN *outStr,
			char sqlstate[6])
{
	int b,e,loop=1, recursive=0;
	char *match;
	
	strcpy (outStr, inStr);
	
	match = (char*)malloc(100*sizeof(char)); 
	sprintf (match, "");
	
	while (recursive <= 5 && loop == 1) 
	{
		regexp(outStr,inExp,&b,&e, match);
		
		if (strcmp(match, "") != 0)
			strcpy(outStr, replace_str(outStr, StrHost, newStr, 0));
		else loop = 0;
		
		recursive++;
	}
	
	free(match);
}
