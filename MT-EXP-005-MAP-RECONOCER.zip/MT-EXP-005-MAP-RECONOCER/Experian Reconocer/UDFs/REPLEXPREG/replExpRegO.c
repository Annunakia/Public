/*
 * ################################################################################
 * 
 * Objetivo:	  Reemplaza el caracter indicado por la patron de la expresion mas
 *		  la posicion de pos
 * Fecha:	  2016/27/14
 * Realizado por: Luis E Ramirez (Capgemini)
 * Parametros:	  inStr, inExp, outStr
 * Proyecto:	  Experian - Reconocer
 * Script:	  replExpRegO.c
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha		Objetivo			Realizado por
 * 
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */
#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include "operationsString.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//Funciones
void replExpRegO (
			VARCHAR_LATIN *inStr,
			VARCHAR_LATIN *inExp,
			VARCHAR_LATIN *newStr,
			int	      *pos,
			VARCHAR_LATIN *outStr,
			char sqlstate[6])
{
	int b,e,loop=1, recursive=0;
	char *match;
	
	strcpy (outStr, inStr);
	
	match = (char*)malloc(100*sizeof(char)); 
	sprintf (match, "");
	
	while (recursive <= 5 && loop == 1)
	{
		regexp(outStr,inExp,&b,&e, match);

		if (strcmp(match, "") == 0)
			loop =0;
		else
			sprintf (outStr, "%s", replace_str(outStr, match+1, newStr, 0));
	
		recursive++;
	}
	
	free(match);
}
