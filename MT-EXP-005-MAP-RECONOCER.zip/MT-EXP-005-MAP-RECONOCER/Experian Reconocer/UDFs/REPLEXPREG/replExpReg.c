/*
 * ################################################################################
 * 
 * Objetivo:	  Elimina caracteres que no cumpla con la expresion caracter
 * 		  sea un e-mail valido por el Cliente
 * Fecha:	  2016/27/14
 * Realizado por: Luis E Ramirez (Capgemini)
 * Parametros:	  inStr, inExp, outStr
 * Proyecto:	  Experian - Reconocer
 * Script:	  replExpReg.c
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha		Objetivo			Realizado por
 * 
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */
#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include "operationsString.h"
#include <stdio.h>
#include <regex.h>
#include <string.h>
#include <stdlib.h>

//Funciones
void replExpReg (
			VARCHAR_LATIN *inStr,
			VARCHAR_LATIN *inExp,
			VARCHAR_LATIN *outStr,
			char sqlstate[6])
{
	regex_t rgT;
	regmatch_t rgMT;
	
	s_replChrs chrs[12];
	
	strcpy(chrs[0].host, "�");
	strcpy(chrs[0].cd , "A");         
	strcpy(chrs[1].host , "�");
	strcpy(chrs[1].cd , "E");
	strcpy(chrs[2].host , "�");
	strcpy(chrs[2].cd , "I");
	strcpy(chrs[3].host , "�");
	strcpy(chrs[3].cd , "O");
	strcpy(chrs[4].host , "�");
	strcpy(chrs[4].cd , "U");
	strcpy(chrs[5].host , "�");
	strcpy(chrs[5].cd , "a");
	strcpy(chrs[6].host , "�");
	strcpy(chrs[6].cd , "e");
	strcpy(chrs[7].host , "�");
	strcpy(chrs[7].cd , "i");
	strcpy(chrs[8].host , "�");
	strcpy(chrs[8].cd , "o");
	strcpy(chrs[9].host , "�");
	strcpy(chrs[9].cd , "u");
	strcpy(chrs[10].host , "�");
	strcpy(chrs[10].cd , "n");
	strcpy(chrs[11].host , "�");
	strcpy(chrs[11].cd , "N");
	
	int i, recursive=0;
	char subStr[2];
	char tmp[strlen((char *) inStr)];
	strcpy(tmp,(char *) inStr);
	
	for (i=0; i<sizeof(chrs)/sizeof(s_replChrs) ; i++) {
		strcpy(tmp, replace_str(tmp, chrs[i].host, chrs[i].cd, recursive));
	}
	
	regcomp(&rgT,(char *)inExp,REG_EXTENDED);
	
	for (i=0;i < strlen(tmp); i++ ) {
		subStr[0] = '\0';
		subStr[0] = tmp[i];
		subStr[1] = '\0';		  

		if ((regexec(&rgT,subStr,1,&rgMT,0)) == 0) {
			strcat((char *)outStr,subStr);
		}
	}                              
	regfree(&rgT);	
}
