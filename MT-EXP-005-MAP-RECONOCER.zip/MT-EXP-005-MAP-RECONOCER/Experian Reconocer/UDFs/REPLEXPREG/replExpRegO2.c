/*
 * ################################################################################
 * 
 * Objetivo:	  Reemplaza el patron de la expresi�n con el nuevo String enviado. 
 * Fecha:	  2016/27/14
 * Realizado por: Luis E Ramirez (Capgemini)
 * Parametros:	  inStr, inExp, newStr, outStr
 * Proyecto:	  Experian - Reconocer
 * Script:	  replExpRegO2.c
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha		Objetivo			Realizado por
 * 
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */
#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include "operationsString.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//Funciones
void replExpRegO2 (
			VARCHAR_LATIN *inStr,
			VARCHAR_LATIN *inExp,
			VARCHAR_LATIN *newStr,
			VARCHAR_LATIN *outStr,
			char sqlstate[6])
{
	int b,e, loop=20;
	char *match;
	char str1[100]="";
	char str2[100]="";
	
	strcpy (outStr, inStr);
			
	while (loop > 0)
	{
		match = (char*)malloc(100*sizeof(char));
		sprintf (match, "");
		
		regexp(outStr,inExp,&b,&e, match);
		
		if (strcmp(match, "") != 0)
		{
			strncpy(str1, outStr+0, b);
			strncpy(str2, outStr+e, strlen(outStr));
			sprintf (outStr, "%s%s%s", str1,newStr,str2);
		} else loop = 1;
	
		loop--;
			
		free(match);
	}

}
