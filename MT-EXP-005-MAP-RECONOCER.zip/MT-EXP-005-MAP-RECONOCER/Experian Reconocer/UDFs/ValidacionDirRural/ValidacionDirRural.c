#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#include <regex.h>
#include <ctype.h>

int getCntPalabrasRural(char *cadena);
int getValorNomRural(char *pal);
int getVectorParticulasNom(char Dir[], char *Particulas[], char *pch );
int getDirsSeparadaRural(char *Particulas[],char aux3[], int i);
int getVectorSegmentosRural(char *Segmentos[], char *cadena, char *separador);
void generaVectorRural(char cadena[], char *result[], char *pch);
void generaVectorPR(char cadena[], char *result[], char *pch, char *seperador);

void ValidacionDirRural(VARCHAR_LATIN  *DirRural,
				   INTEGER  *outSalida,
				   SQL_TEXT  extname[129],
				   SQL_TEXT  specific_name[129],
				   SQL_TEXT  error_message[257],
				   char      sqlstate[6]) 
{    
  char Dir[500];
  char *Particulas[100];
  char *NomRural[100];
  char *Segmentos[100];  
  char *ParSegmentos[100];  
  char *SegmentosOrdenados[100]; 
  char *pch;
  int dirs=0;
  int i=0;
  char aux3[500];
  char auxRural[500];
  int j=0;
  int cdr=0;
  char *aux2;
  int CntNomenclaturaRural = 0; 
  char p[100];
  char dirrural[100];
  char *RespRral[100];
  char *Nom;
  int irural=0;
  strcpy (auxRural,"");
 
  *outSalida=0;
  
  strcpy(Dir,DirRural);
  
  i=getVectorParticulasNom(Dir,Particulas,pch);
  dirs=getDirsSeparadaRural(Particulas,aux3,i);
  
  cdr=getVectorSegmentosRural(Segmentos, aux3, "&&");
  
  for(i=0; i<cdr; i++){
      
      printf("SEGMENTOS[%d=%s]\n",i,Segmentos[i]);
      
    strcpy (dirrural,Segmentos[i]);
   
   if(getCntPalabrasRural(dirrural) > 1){
     strcpy (p,"");
     generaVectorRural(dirrural, RespRral, p);
     if(irural>0){
      strcat (auxRural,"&&");
     }
     if(getValorNomRural(RespRral[0]) > 0){
            strcat (auxRural,RespRral[0]);
            irural++;
         }
   }
  }
  
  generaVectorPR(auxRural,NomRural,aux3,"&&");
  
  for(i=0; i<irural; i++){
      if( strcmp(NomRural[i],NomRural[i+1]) != 0 ){
         CntNomenclaturaRural = CntNomenclaturaRural +1; 
      }
  }
    
  *outSalida = CntNomenclaturaRural;
  
}

int getCntPalabrasRural(char *cadena){
 int res=0; char *pch;
 pch = strtok( cadena, " " );
 while (pch != NULL)
  {
   pch = strtok (NULL, " "); 
   res++;
  }
 return res;
}

void generaVectorRural(char cadena[], char *result[], char *pch){
  pch = strtok( cadena, " " );
  int i=0; 
  while (pch != NULL)
  {
   result[i]=pch; 
   pch = strtok (NULL, " "); 
   i++;
  }
  result[i]="\0";
}

void generaVectorPR(char cadena[], char *result[], char *pch, char *seperador){
  pch = strtok( cadena, seperador);
  int i=0; 
  while (pch != NULL)
  {
   result[i]=pch; 
   pch = strtok (NULL, seperador); 
   i++;
  }
  result[i]="\0";
}

int getVectorParticulasNom(char Dir[], char *Particulas[], char *pch ){

  pch = strtok( Dir, " " );
  int i=0; 
  while (pch != NULL)
  {
   Particulas[i]=pch; 
   pch = strtok (NULL, " "); 
   i++;
  }
  Particulas[i]="\0";
  
  return i;
}

int getDirsSeparadaRural(char *Particulas[], char aux3[], int i){
 int j=0; int valor=0,valor1=0; int dirs = 0;   
 strcpy (aux3,"");
 strcat (aux3,Particulas[0]);
 strcat (aux3," ");
 for(j=1; j<i; j++){
      valor1=getValorNomRural(Particulas[j+1]);
      valor=getValorNomRural(Particulas[j]);
      if(valor>0){
          dirs=dirs+1;
          strcat (aux3,"&&");
          strcat (aux3,Particulas[j]);
          strcat (aux3," ");
      }else{
      strcat (aux3,Particulas[j]);      
       if(valor1<0 && j<i-1){
        strcat (aux3," ");
       }
      }
 }
    
return dirs;
}

int getVectorSegmentosRural(char *Segmentos[], char *cadena, char *separador){
  char *pch1;  int i1=0; int irural=0;
  pch1 = strtok( cadena, separador );
  while (pch1 != NULL)
  {
   Segmentos[i1]=pch1; 
   pch1 = strtok (NULL, separador); 
   i1++;
  }
 Segmentos[i1]="\0"; 
 return i1;
}

int getValorNomRural(char *pal){
 char v1[500]="KM,CT,VIA,RP,AU,VTE,TC,VEDA,FI,QDA,HC,CM,MUN,CO,CAS,CNO,ZN,BG,IP,LT,SEC";
 char v2[500]="1,2,2,2,2,2,2,3,4,4,4,5,5,6,8,9,10,11,12,13,14";
 char *nomenclaturas[21];
 char *valores[21];
 char *pch;
 char *pch1;   
 
  pch = strtok( v1, "," );
  int i=0; 
  while (pch != NULL)
  {
   nomenclaturas[i]=pch; 
   pch = strtok (NULL, ","); 
   i++;
  }
 
  pch1 = strtok( v2, "," );
  int i1=0; 
  while (pch1 != NULL)
  {
   valores[i1]=pch1; 
   pch1 = strtok (NULL, ","); 
   i1++;
  }

  int j=0;
  int pos=-1;
  for(j=0; j<21; j++){
      if( strcmp(nomenclaturas[j],pal) == 0 ){
   	    pos = j;
   	    break;   	    	
      }
  }
  int aux=-1;
  if(pos > -1){
      aux=atof(valores[pos]);
  }
  return aux;
}
