/*
 * ################################################################################
 * 
 * Objetivo:	  Validar que el String de entrada tenga el formato valido para que 
 * 		  sea un e-mail valido por el Cliente
 * Fecha:	  2016/27/14
 * Realizado por: Luis E Ramirez (Capgemini)
 * Parametros:	  inStr, inExp, outStr
 * Proyecto:	  Experian - Reconocer
 * Script:	  ValidateExpressionR.c
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha		Objetivo			Realizado por
 * 
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */
#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include <stdio.h>
#include <regex.h>

void ValidateExpressionR (
			VARCHAR_LATIN *inStr,
			VARCHAR_LATIN *inExp,
			INTEGER *outStr,
			SQL_TEXT extname[129],
			SQL_TEXT specific_name[129],
			SQL_TEXT error_message[257]) 
{
	regex_t rgT;
	regmatch_t rgMT;

	*outStr = 0;
	
	if (regcomp(&rgT,inExp,REG_EXTENDED) != 0) {
		regfree(&rgT);
		return ;
	}
	
	if ((regexec(&rgT,inStr,1,&rgMT,0)) == 0) 
		*outStr = 1;
	
	regfree(&rgT);

}
