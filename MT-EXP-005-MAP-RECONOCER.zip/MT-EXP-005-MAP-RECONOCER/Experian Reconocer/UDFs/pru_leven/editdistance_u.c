/**********************************************************************/
/*                                                                    */
/*  Copyright (c) 2003 by NCR Corporation.                            */
/*                                                                    */
/*  All Rights Reserved.                                              */
/*                                                                    */
/*  NCR CONFIDENTIAL AND TRADE SECRET                                 */
/*                                                                    */
/*  Function Name:  editdistance_u.c                                  */
/*                                                                    */
/*  Function Purpose:                                                 */
/*  editdistance is a measure of the similarity between               */
/*  two strings.  The editdistance function returns the               */
/*  minimum numbers of edit operations; insertions, deletions,        */
/*  substitutions and transpositions required to transform            */
/*  string1 into string2. The optional arguments specified            */
/*  the relative cost of an insert / delete / substitute / transpose. */
/*  A low number of deletions, insertions, substitutions or           */
/*  transpositions implies a high similarity.                         */
/*                                                                    */
/*  The editdistance_u scalar UDF consists of 2 overloading           */
/*  functions, one with 2 parameters and one with 6 parameters.       */
/*                                                                    */
/**********************************************************************/

#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include <string.h>
#include <stdlib.h>
#define MAX_STRING_LENGTH 255


/**
 * Get the minimum from the incoming inputs.
 * 
 */
INTEGER getMin(INTEGER mcs, 
               INTEGER mcd,  
               INTEGER mci, 
               INTEGER mct)
{
    INTEGER tmpMin = (mcs <= mcd) ? mcs : mcd;
            tmpMin = (tmpMin <= mci) ? tmpMin : mci;
    return (tmpMin <= mct) ? tmpMin : mct;
}

/* The Levenshtein distance function returns the minimum number */
/* of edit operations. Refer to header file for more details.   */

void editdistance_u(VARCHAR_LATIN *str1, 
                    VARCHAR_LATIN *str2, 
                    INTEGER *ci, 
                    INTEGER *cd, 
                    INTEGER *cs, 
                    INTEGER *ct, 
                    INTEGER *result, 
                    char sqlstate[6])
{
    unsigned short j, str1len, matrixW;
    unsigned short i, str2len, matrixH;
    INTEGER *distance;
    INTEGER mci, mcd, mcs, mct;
    unsigned short I, J;

    str1len = strlen((const char*)str1);
    str2len = strlen((const char*)str2);

    /* Only compare the first 255 characters */
    if (str1len > MAX_STRING_LENGTH)
        str1len = MAX_STRING_LENGTH;

    if (str2len > MAX_STRING_LENGTH)
        str2len = MAX_STRING_LENGTH;

    /* if either string is empty then the result is the       */
    /* (cost of insert)*(length of the other string)          */
    if (str1len == 0)
    {
        *result = (*ci) * str2len;
        return;
    }
    if (str2len == 0)
    {
        *result = (*ci) * str1len;
        return;
    }

    /* Build the matrix for computation */
    matrixH = str1len + 1;
    matrixW = str2len + 1;
    distance = (INTEGER*) malloc((matrixW) * 
               (matrixH) * (sizeof(INTEGER)));

    /* Initialize data for the cells that are used in computation */
    distance[0] = 0;

    /* Initialize the 1st column of the distance matrix */
    for (i = 1; i <= str1len; ++i)
    {
        distance[i*(matrixW)] = distance[(i - 1)*(matrixW)] + *cd;
    }

    /* Initialize the 1st row of the distance matrix */
    for (i = 1; i <= str2len; ++i)
    {
        distance[i] = distance[i-1] + *ci;
    }

    /* Compute the distance */
    for (i = 1; i <= str1len; ++i)
    {
        for (j = 1; j <= str2len; ++j)
        {
            I = i - 1;
            J = j - 1;

            /* Compute substitution cost,                     */
            /* cell diagonally above cell[i][j]               */
            if (str1[I] == str2[J]) /* no substitution needed */
            {
                mcs = distance[(I * matrixW) + J];
            }
            else
            {
                mcs = distance[(I * matrixW) + J] + *cs;
            }

            /* Compute deletion cost,                         */
            /* cell immediately above cell[i][j]              */
            mcd = distance[(I * matrixW) + j] + *cd;

            /* Compute insertion cost,                        */
            /* cell immediately to the left cell[i][j]        */
            mci = distance[(i * matrixW) + J] + *ci;

            /* Compute transposition cost,                    */
            /* cell[i-2][j-2] diagonally above cell[i][j]     */
            if (i > 1 && j > 1)
            {
                mct = distance[((i - 2) * matrixW) + (j - 2)] + *ct;
                /* if there is a substitution between         */
                /* str1[i-1] and str2[j]                      */
                if (str1[I] != str1[j])
                {
                    mct += *cs;
                }
                /* if there is a substitution between         */
                /* str1[i] and str2[j-1]                      */
                if (str1[i] != str1[J])
                {
                    mct += *cs;
                }
            }
            else
            {
                mct = mci;
            }
            distance[(i * matrixW) + j] = getMin(mcs, mcd, mci, mct);
        }
    }

    *result = distance[(matrixW) * (matrixH) - 1];
    free(distance);
}


