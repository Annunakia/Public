/*******************************************************************/
/*                                                                 */
/*  Copyright (c) 2003 by NCR Corporation.                         */
/*                                                                 */
/*  All Rights Reserved.                                           */
/*                                                                 */
/*  NCR CONFIDENTIAL AND TRADE SECRET                              */
/*                                                                 */
/*  Function Name:  ngramm_u.c                                     */
/*                                                                 */
/*  Function Purpose:                                              */
/*  n-gram match function returns the number of n-gram matches     */
/*  between string1 and string2.  The optional third argument      */
/*  specified that the n-gram is a positional n-gram match.  A     */
/*  high number of matching n-gram patterns implies a high         */
/*  similarity. Positional n-grams imply that the position as      */
/*  well as the pattern must match when measuring similarity.      */  
/*  The n-gram UDF consists of 2 overloading scalar                */
/*  functions, one with 3 parameters and the second with           */
/*  4 parameters.                                                  */
/*                                                                 */
/*******************************************************************/

#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include <string.h>
#include <stdlib.h>
#define MAX_STRING_PATTERN 255

void ngramm_u(VARCHAR_LATIN *inputS1,
              VARCHAR_LATIN *inputS2,
              int *N,
              int *result,
              char sqlstate[6])
{
    int I, s1len, s2len, Plen, count;
    char *Pptr, *S, *ngram;

    s1len = strlen((const char*)inputS1);    /* s1 length */
    s2len = strlen((const char*)inputS2);    /* s2 length */

    *result = 0;                         

    /* return 0 if either string == 0   */
    /* or ngramm length > either string */
    /* or ngramm length <= 0            */
    if (s1len == 0 || s2len == 0 ||  
        *N > s1len || *N > s2len ||   
        *N <= 0 )                     
        return;

    ngram = malloc(*N + 1);
    ngram[*N] = '\0';
    if(s1len >= s2len)          /* Pptr points to shorter string   */
    {
        S = ((char*)inputS1);            /* S is string to be searched      */
        Pptr = ((char*)inputS2);         /* Pptr points to pattern          */
    }
    else
    {
        Pptr = ((char*)inputS1); 
        S = ((char*)inputS2);
    }

    Plen = strlen(Pptr);        /* Pattern's length */

    /* Patterns beyond 255 length are ignored */
    if (Plen > MAX_STRING_PATTERN)  
        Plen = MAX_STRING_PATTERN;

    Plen = Plen - *N + 1;

    /* For each n-gramm, search S */
    for (I = 0, count=0; I < Plen ; I++, Pptr++)  
    {
        memcpy(ngram, Pptr, *N);
        if (strstr(S, ngram) != NULL) 
            count++;
    }

    free(ngram);
    *result = count;
}
