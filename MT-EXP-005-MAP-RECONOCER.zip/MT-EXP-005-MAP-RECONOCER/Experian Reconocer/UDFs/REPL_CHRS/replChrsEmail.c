/*
 * ################################################################################
 * 
 * Objetivo:	  Validar que el String de entrada tenga el formato valido para que 
 * 		  sea un e-mail valido por el Cliente
 * Fecha:	  2016/27/14
 * Realizado por: Luis E Ramirez (Capgemini)
 * Parametros:	  inStr, inExp, outStr
 * Proyecto:	  Experian - Reconocer
 * Script:	  ValidateExpressionR.c
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha		Objetivo			Realizado por
 * 
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */
#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include "operationsString.h"
#include <stdio.h>
#include <regex.h>
#include <string.h>
#include <stdlib.h>

void replChrsEmail (
			VARCHAR_LATIN *inStr,
			VARCHAR_LATIN *outStr,
			SQL_TEXT extname[129],
			SQL_TEXT specific_name[129],
			SQL_TEXT error_message[257])
{
	
	s_replChrs chrs[58];
	//Dominio
	strcpy( chrs[0].host , "&");
	strcpy( chrs[0].cd , "");
	
	strcpy( chrs[1].host , "()");
	strcpy( chrs[1].cd , "");
	
	strcpy( chrs[2].host , "*");
	strcpy( chrs[2].cd , "");
	
	strcpy( chrs[3].host , "()");
	strcpy( chrs[3].cd , "");
	
	strcpy( chrs[4].host , "/");
	strcpy( chrs[4].cd , "");
	
	strcpy( chrs[5].host , "/\"");
	strcpy( chrs[5].cd , "");
	
	strcpy( chrs[6].host , ":");
	strcpy( chrs[6].cd , "");
	
	strcpy( chrs[7].host , "?");
	strcpy( chrs[7].cd , "");
	
	strcpy( chrs[8].host , "\\");
	strcpy( chrs[8].cd , "");
	
	strcpy( chrs[9].host , "]");
	strcpy( chrs[9].cd , "");
	
	strcpy( chrs[10].host , "`");
	strcpy( chrs[10].cd , "");
	
	strcpy( chrs[11].host , "|");
	strcpy( chrs[11].cd , "");
	
	strcpy( chrs[12].host , "}");
	strcpy( chrs[12].cd , "");
	
	strcpy( chrs[13].host , "~");
	strcpy( chrs[13].cd , "");
	
	strcpy( chrs[14].host , "´ó");
	strcpy( chrs[14].cd , "");
	
	strcpy( chrs[15].host , "+");
	strcpy( chrs[15].cd , "");
	
	strcpy( chrs[16].host , "<");
	strcpy( chrs[16].cd , "");
	
	strcpy( chrs[17].host , "=");
	strcpy( chrs[17].cd , "");
	
	strcpy( chrs[18].host , ">");
	strcpy( chrs[18].cd , "");
	
	strcpy( chrs[19].host , "á");
	strcpy( chrs[19].cd , "");

	strcpy( chrs[20].host , "ç");
	strcpy( chrs[20].cd , "");
	
	strcpy( chrs[21].host , "í");
	strcpy( chrs[21].cd , "");
	
	strcpy( chrs[22].host , "ó");
	strcpy( chrs[22].cd , "");
	
	strcpy( chrs[23].host , "ø");
	strcpy( chrs[23].cd , "");
	
	strcpy( chrs[24].host , "ÿ");
	strcpy( chrs[24].cd , "");
	
	strcpy( chrs[25].host , "%");
	strcpy( chrs[25].cd , "");
	
	strcpy( chrs[26].host , "´");
	strcpy( chrs[26].cd , "");
	
	strcpy( chrs[27].host , ".--");
	strcpy( chrs[27].cd , "");

	strcpy( chrs[28].host , "¦");
	strcpy( chrs[28].cd , "n");
	
	strcpy( chrs[29].host , "ñ");
	strcpy( chrs[29].cd , "n");
	
	strcpy( chrs[30].host , "Ñ");
	strcpy( chrs[30].cd , "n");
	
	strcpy( chrs[31].host , "%");
	strcpy( chrs[31].cd , "ÿ");

	strcpy( chrs[32].host , "..");
	strcpy( chrs[32].cd , ".");
	
	strcpy( chrs[33].host , "--");
	strcpy( chrs[33].cd , "-");

	strcpy( chrs[34].host , ".com.co.");
	strcpy( chrs[34].cd , ".com.co");
	
	strcpy( chrs[35].host , ".com.o");
	strcpy( chrs[35].cd , ".com.co");
	
	strcpy( chrs[36].host , ".com.c");
	strcpy( chrs[36].cd , ".com.co");
	
	strcpy( chrs[37].host , "@c.com");
	strcpy( chrs[37].cd , ".com.co");

	strcpy( chrs[38].host , "@co.co");
	strcpy( chrs[38].cd , ".com.co");
	
	strcpy( chrs[39].host , "@c.co");
	strcpy( chrs[39].cd , ".com.co");
	
	strcpy( chrs[40].host , ".gov.c");
	strcpy( chrs[40].cd , ".gov.co");
	
	strcpy( chrs[41].host , "@edu");
	strcpy( chrs[41].cd , ".edu");
	
	strcpy( chrs[42].host , "@.");
	strcpy( chrs[42].cd , "@");
	
	strcpy( chrs[43].host , "@@");
	strcpy( chrs[43].cd , "@");
	
	strcpy( chrs[44].host , ".netc");
	strcpy( chrs[44].cd , ".net.co");
	
	strcpy( chrs[45].host , ".comc");
	strcpy( chrs[45].cd , ".com.co");
	
	strcpy( chrs[46].host , ".comco");
	strcpy( chrs[46].cd , ".com.co");
	
	strcpy( chrs[47].host , "..com");
	strcpy( chrs[47].cd , ".com");
	
	strcpy( chrs[48].host , ":com");
	strcpy( chrs[48].cd , ".com");
	
	strcpy( chrs[49].host , "@gov");
	strcpy( chrs[49].cd , ".gov");
	
	strcpy( chrs[50].host , ".com.c.o");
	strcpy( chrs[50].cd , ".com.co");
	
	strcpy( chrs[51].host , ".govco");
	strcpy( chrs[51].cd , ".gov.co");
	
	strcpy( chrs[52].host , ",");
	strcpy( chrs[52].cd , ".");
	
	// Buzon
	strcpy( chrs[53].host , "'");
	strcpy( chrs[53].cd , "");
	
	strcpy( chrs[54].host , "±");
	strcpy( chrs[54].cd , "n");
	
	strcpy( chrs[55].host , "µ");
	strcpy( chrs[55].cd , "n");
	// .. , tambien esta en el dominio
	strcpy( chrs[56].host , "ð");
	strcpy( chrs[56].cd , "n");
	
	strcpy( chrs[57].host , "ð");
	strcpy( chrs[57].cd , "n");

	int i;
	
	strcpy (outStr, inStr);
	
	for ( i=0; i<58; i++) {
		strcpy(outStr, replace_str(outStr, chrs[i].host, chrs[i].cd, 0));

	}
}
