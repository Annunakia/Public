/*
 * ################################################################################
 * 
 * Objetivo:	  Validar que el String de entrada tenga el formato valido para que 
 * 		  sea un e-mail valido por el Cliente
 * Fecha:	  2016/27/14
 * Realizado por: Luis E Ramirez (Capgemini)
 * Parametros:	  inStr, inExp, outStr
 * Proyecto:	  Experian - Reconocer
 * Script:	  ValidateExpressionR.c
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha		Objetivo			Realizado por
 * 2018/07/17		Eliminar el replace de " N "	Capgemini
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */
#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include "operationsString.h"
#include <stdio.h>
#include <regex.h>
#include <string.h>
#include <stdlib.h>

void replChrsGeo (
			VARCHAR_LATIN *inStr,
			VARCHAR_LATIN *inGeo,
			VARCHAR_LATIN *outStr,
			SQL_TEXT extname[129],
			SQL_TEXT specific_name[129],
			SQL_TEXT error_message[257])
{
	
	s_replChrs chrs[21];
	//Dominio
	strcpy( chrs[0].host , "Â");
	strcpy( chrs[0].cd , "A");
	
	strcpy( chrs[1].host , "'");
	strcpy( chrs[1].cd , " ");
	
	strcpy( chrs[2].host , "¶");
	strcpy( chrs[2].cd , "Ñ");
	
	strcpy( chrs[3].host , "SIN DEFINIR");
	strcpy( chrs[3].cd , " ");
	
	strcpy( chrs[4].host , "Á");
	strcpy( chrs[4].cd , "A");
	
	strcpy( chrs[5].host , "É");
	strcpy( chrs[5].cd , "E");
	
	strcpy( chrs[6].host , "Í");
	strcpy( chrs[6].cd , "I");
	
	strcpy( chrs[7].host , "Ó");
	strcpy( chrs[7].cd , "O");
	
	strcpy( chrs[8].host , "Ú");
	strcpy( chrs[8].cd , "U");
	
	/*strcpy( chrs[9].host , " N ");
	strcpy( chrs[9].cd , " ");*/
	
	strcpy( chrs[9].host , " DR ");
	strcpy( chrs[9].cd , " ");
	
	strcpy( chrs[10].host , "À");
	strcpy( chrs[10].cd , "A");
	
	strcpy( chrs[11].host , "È");
	strcpy( chrs[11].cd , "E");
	
	strcpy( chrs[12].host , "Ì");
	strcpy( chrs[12].cd , "I");
	
	strcpy( chrs[13].host , "Ò");
	strcpy( chrs[13].cd , "O");
	
	strcpy( chrs[14].host , "Ù");
	strcpy( chrs[14].cd , "U");
	
	strcpy( chrs[15].host , "NN  ");
	strcpy( chrs[15].cd , " ");
	
	strcpy( chrs[16].host , " CON");
	strcpy( chrs[16].cd , " ");
	
	strcpy( chrs[17].host , " ENTRE");
	strcpy( chrs[17].cd , " ");
	
	strcpy( chrs[18].host , "\t");
	strcpy( chrs[18].cd , " ");

	strcpy( chrs[19].host , " 0 ");
	strcpy( chrs[19].cd , " ");
	
	strcpy( chrs[20].host , " NÚMERO ");
	strcpy( chrs[20].cd , "NUEMRO");
	
	int i;
	
	strcpy (outStr, inStr);
	
	for ( i=0; i<21; i++) {
		strcpy(outStr, replace_str(outStr, chrs[i].host, chrs[i].cd, 0));

	}
}
