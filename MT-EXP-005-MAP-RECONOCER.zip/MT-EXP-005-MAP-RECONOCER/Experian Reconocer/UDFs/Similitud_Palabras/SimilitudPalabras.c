/*
 * ################################################################################
 * 
 * Objetivo:	  Comparar la palabra de entrada contra un listado de palabras separadas por una 
 * 		  coma (,), se toma la palabra del listado con mayor porcentaje y mayor
 *		  que el porcentaje de referencia del parametro
 * Fecha:	  2018/01/15
 * Realizado por: Carlos Castillo (Capgemini)
 * Parametros:	  
 * Proyecto:	  Experian - Reconocer
 * Script:	  SimilitudPalabras.c
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha	Objetivo				Realizado por
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2018 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */

#include "operationsString.h"
#include "loadParamsAcepAut.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

/*
soundex
Copyright 1994 Michael Lee <mikey@ontek.com>
Permission to use for any purpose granted.
Refer to Knuth, Art of Computer Programming Vol. 3, pp 391-392.
*/


 //Estructuras
 //Estructura para palabras
 typedef struct Palabra {
	char word[100]; // Palabra
	int porcentaje;
	struct Palabra *next; //Enlaza a la siguiente palabra de izquierda a derecha
	
} Palabra;	

void soundex(name, sound)
  char   * name;
  char   * sound;  /* supply at least 5 pre-allocated characters */
{
  char   * in = name,
         * out = sound;
  char   prev = '\0';
  int    is_first = 1;
  char   code;

  while (*in != '\0' && out - sound < 4)
  {
    switch(tolower(*in))
    {
      case 'b':
      case 'f':
      case 'p':
      case 'v':
        code = '1';
      break;

      case 'c':
      case 'g':
      case 'j':
      case 'k':
      case 'q':
      case 's':
      case 'x':
      case 'z':
        code = '2';
      break;

      case 'd':
      case 't':
        code = '3';
      break;

      case 'l':
        code = '4';
      break;

      case 'm':
      case 'n':
        code = '5';
      break;

      case 'r':
        code = '6';
      break;

      /* includes "aehiouwy", punctuation, numbers and control chars */
      default:
        code = 0;
      break;
    }

    if (is_first)
    {
      *out++ = toupper(*in);
      is_first = 0;
    }
    else if (code && prev != code)
      *out++ = code;
    prev = code;

    in++;
  }

  while (out - sound < 4)
    *out++ = '0';

  *out = '\0';

}

// Funcion referenciada por Teradata
void SimilitudPalabras (
		VARCHAR_LATIN *inPalabra,
		VARCHAR_LATIN *inListPalabras,
		INTEGER	*Porcentaje,
					
		VARCHAR_LATIN *outSimilitud,
		SQL_TEXT extname[129],
		SQL_TEXT specific_name[129],
		SQL_TEXT error_message[257],
		char sqlstate[6])
{
	
	sprintf (outSimilitud, "");
	
	//Define variables
	int porcentaje=0
		,porSoundex=0
		,posicion = 1
		,cantPalabras=1
		,maxPor=0;
		;
		
	INTEGER cost = 1
		, *outDistancia = NULL;
	
	char soundIn[10]="";
	char soundPalabra[10]="";
	char maxPorS[100]="", ListPalabraIn[100]="", *tmp;
	
	outDistancia = (INTEGER *) malloc(sizeof(INTEGER));
	tmp = (char *) malloc(100);
	
	struct Palabra *palabra=NULL, *listPalabra=NULL, *startPalabra=NULL;
	
	sprintf (ListPalabraIn, "%s", inListPalabras);
	
	//Identifica cantidad palabras
	while (*inListPalabras != '\0')
	{
		if (*inListPalabras == ',')
			cantPalabras++;
		
		inListPalabras++;
	}
	
	// Lista de palabras, genera cola
	while (posicion <= cantPalabras)
	{
		palabra=FNC_malloc (sizeof(Palabra));
		ListGetValByIdx(ListPalabraIn,",",posicion,tmp);
		sprintf(palabra->word, "%s", tmp);
		palabra->porcentaje=0;
		palabra->next=NULL;
		
		if (listPalabra==NULL)
			startPalabra=listPalabra=palabra;
		else listPalabra->next = palabra;
		
		listPalabra = palabra;
		posicion++;
	}
	free(tmp);
	
	//Soundex palabra
	soundex(inPalabra, soundIn);
	
	// Recorre lista de palabras para determinar porcentaje
	listPalabra=startPalabra;
	while (listPalabra != NULL)
	{
		
		//Identifica palbra del listado
		sprintf (soundPalabra, "");
		soundex(listPalabra->word, soundPalabra);	
		
		porSoundex = 0;
		// Define porcentaje por igualdad de soundex
		if (strcmp(soundIn, soundPalabra) == 0)
			porSoundex = 100;
		
		// Aplica, distancia de edicion
		editdistance_u(inPalabra, 
				listPalabra->word, 
				&cost, 
				&cost, 
				&cost, 
				&cost, 
				outDistancia, 
				sqlstate);
		
		// Pondera valores para buzon
		porcentaje = (((1-((*outDistancia*1.0) / (strlen(inPalabra)*1.0))) /*Distancia*/
					* 1.0)
				+ 0.00499)*100
				;
		listPalabra->porcentaje = porcentaje;
		
		listPalabra = listPalabra->next;
	}
	
	// Recorre lista de palabras para identificar el maximo porcentaje.
	listPalabra=startPalabra;
	while (listPalabra != NULL)
	{
		if (listPalabra->porcentaje > maxPor && listPalabra->porcentaje >= *Porcentaje)
		{
			maxPor = listPalabra->porcentaje;
			sprintf(maxPorS, "%s", listPalabra->word);
		}
		
		//sprintf (outSimilitud, "%s - %s:%d", outSimilitud, listPalabra->word, listPalabra->porcentaje);
		
		listPalabra = listPalabra->next;
			
	}
	
	//Limpia variable
	free(outDistancia);
	
	listPalabra=startPalabra;
	while (listPalabra != NULL)
	{
		palabra = listPalabra;
		
		listPalabra = listPalabra->next;
		FNC_free(palabra);
	}
	
	if (maxPor != 0)
		sprintf (outSimilitud, "%s", maxPorS);
	else sprintf (outSimilitud, "%s", inPalabra);

}
