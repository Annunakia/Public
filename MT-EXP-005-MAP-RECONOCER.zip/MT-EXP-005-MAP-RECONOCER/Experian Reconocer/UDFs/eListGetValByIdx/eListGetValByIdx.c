
/*
 * ========================================================================
 *  Copyright [2009-2010] eBay Inc. (http://www.ebay.com)
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 *   Original Authors:
 *       Subash Ramanathan 
 *       Michael Mcinitire 
 *
 *   2009-12-01     Initial Version
 * ========================================================================
 */


#define SQL_TEXT Latin_Text
#include <sqltypes_td.h>

#include <stdio.h>
#include <string.h>
#include <stdlib.h>


/*
DROP FUNCTION eListGetValByIdx ;
CREATE FUNCTION eListGetValByIdx (
         str_vec VARCHAR(4096)
        ,vec_delimit VARCHAR(1)
        ,vec_idx INTEGER
         )
RETURNS VARCHAR(4096)
LANGUAGE C
NO SQL
PARAMETER STYLE SQL
EXTERNAL NAME 'CS!eListGetValByIdx!eListGetValByIdx.c!F!eListGetValByIdx'
;

*/



void eListGetValByIdx (
         VARCHAR_LATIN *str_vec
        ,VARCHAR_LATIN *vec_delimit
        ,INTEGER *vec_idx
        ,VARCHAR_LATIN *result
        ,INTEGER *str_vec_isNULL
        ,INTEGER *vec_delimit_isNULL
        ,INTEGER *vec_idx_isNULL
        ,INTEGER *result_isNULL
        ,char sqlstate[6]
        ,SQL_TEXT fncname[129]
        ,SQL_TEXT sfncname[129]
        ,SQL_TEXT error_message[257]
         )
{

// Null indicator -1 NULL , 0 Not NULL


//checking NULL value for parameter:str_vec
if ( *str_vec_isNULL == -1 ) {
  *result_isNULL = -1;
  *result = 0;
  return;
}

//checking NULL value for parameter:vec_delimit
if ( *vec_delimit_isNULL == -1 ) {
  *result_isNULL = -1;
  *result = 0;
  return;
}

//checking NULL value for parameter:vec_idx
if ( *vec_idx_isNULL == -1 ) {
  *result_isNULL = -1;
  *result = 0;
  return;
}



//
// Insert your code
//
//

    short found=0;
    int idx=0;
    char *out;
    out=result;


    for (idx=0; *str_vec != '\0'; *str_vec++) {
    if ( *str_vec == *vec_delimit ) {
      idx++;
      if ( idx == *vec_idx ) {
        found=1;
        *out=0;
        break;
      }
      out=result;
    } else {
      *out++ = *str_vec ;
    }
    }

    //to handle the last column without ,
    if ( idx == (*vec_idx -1 ) 
        //&& *out != 0 
       ) {
        *out=0;
      found=1;
    }

    // if first idx then it gets entire input
    if ( ( *vec_idx != 1 ) && (found == 0)) {
      *result_isNULL = -1;
      *result = 0;
      return;
    }
    // if empty string
    if ( *result == 0 ) {
      *result_isNULL = -1;
      *result = 0;
    }


return;
}


