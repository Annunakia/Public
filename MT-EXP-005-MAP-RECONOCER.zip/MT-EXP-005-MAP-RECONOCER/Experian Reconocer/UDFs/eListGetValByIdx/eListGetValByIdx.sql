
/*
 * ========================================================================
 *  Copyright [2009-2010] eBay Inc. (http://www.ebay.com)
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 *   Original Authors:
 *       Subash Ramanathan 
 *       Michael Mcinitire 
 *
 *   2009-12-01     Initial Version
 * ========================================================================
 */


--DROP FUNCTION eListGetValByIdx ;
REPLACE FUNCTION REC_VISTA.eListGetValByIdx (
         str_vec VARCHAR(4096)
        ,vec_delimit VARCHAR(1)
        ,vec_idx INTEGER
         )
RETURNS VARCHAR(4096)
LANGUAGE C
NO SQL
PARAMETER STYLE SQL
EXTERNAL NAME 'CS!eListGetValByIdx!eListGetValByIdx.c!F!eListGetValByIdx'
;

/*
select REC_VISTA.eListGetValByIdx('abc,defc,hef',',',2);
select REC_VISTA.eListGetValByIdx('abc,defc,hef',',',5);
select REC_VISTA.eListGetValByIdx('abc,defc,hef,',',',4);
select REC_VISTA.eListGetValByIdx('abc,defc,hef,',',',3);
select REC_VISTA.eListGetValByIdx('abc,defc,hef',',',3);      

--alter function eListGetValByIdx    EXECUTE NOT PROTECTED ;
*/