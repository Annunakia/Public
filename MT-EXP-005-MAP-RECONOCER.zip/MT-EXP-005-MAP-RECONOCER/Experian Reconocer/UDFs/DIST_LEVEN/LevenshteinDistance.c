/*
 * ################################################################################
 * 
 * Objetivo:	  
 * Fecha:	  2017/01/23
 * Realizado por: Luis E Ramirez (Capgemini)
 * Parametros:	  
 * Proyecto:	  Experian - Reconocer
 * Script:	  LevenshteinDistance.c
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha	Objetivo				Realizado por
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */

#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include "loadParamsAcepAut.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>

// Funcion referenciada por Teradata
void LevenshteinDistance (
		VARCHAR_LATIN *Str1,
		VARCHAR_LATIN *Str2,
		INTEGER *outDist,
		SQL_TEXT extname[129],       
		SQL_TEXT specific_name[129],
		SQL_TEXT error_message[257],
		char sqlstate[6])
{
	INTEGER cost = 1;
	editdistance_u(Str1, 
			Str2, 
			&cost, 
			&cost, 
			&cost, 
			&cost, 
			outDist, 
			sqlstate);
}
