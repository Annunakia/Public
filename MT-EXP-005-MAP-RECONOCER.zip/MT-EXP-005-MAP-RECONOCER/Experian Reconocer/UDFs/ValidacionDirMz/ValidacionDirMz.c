#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#include <regex.h>
#include <ctype.h>
#include <time.h>

int getCntPalabrasMz(char *cadena);
void generaVectorMz(char cadena[], char *result[], char *pch);
void generaVectorPRMz(char cadena[], char *result[], char *pch, char *seperador);
int getValorNomMz(char *pal);
int getVectorParticulasNomMz(char Dir[], char *Particulas[], char *pch );
int getDirsSeparadaMz(char *Particulas[],char aux3[], int i);
int getVectorSegmentosMz(char *Segmentos[], char *cadena, char *separador);

void ValidacionDirMz(VARCHAR_LATIN *DirMzIn,                   
                      INTEGER *outSalida,
				      SQL_TEXT  extname[129],
				      SQL_TEXT  specific_name[129],
				      SQL_TEXT  error_message[257],
				      char      sqlstate[6]) 
{ 

  char Dir[500];       
  char *Particulas[100];
  char *NomMz[100];
  char *Segmentos[100];  
  char *ParSegmentos[100];  
  char *SegmentosOrdenados[100]; 
  char *pch;
  int dirs=0;
  int i=0;
  char aux3[500];
  char auxMz[500];
  int j=0;
  int cdr=0;
  char *aux2;
  int CntNomenclaturaMz = 0;
  char p[100];
  char dirMz[100];
  char *RespRral[100];
  char *Nom;
  int iMz=0;
  int isValida=0;
  strcpy (auxMz,"");
  
  *outSalida=0;
  
  strcpy(Dir,DirMzIn);    
    
  i=getVectorParticulasNomMz(Dir,Particulas,pch);

  dirs=getDirsSeparadaMz(Particulas,aux3,i);
      
  cdr=getVectorSegmentosMz(Segmentos, aux3, "&&");
  
  for(i=0; i<cdr; i++){
	  
    strcpy (dirMz,Segmentos[i]);
   
   if(getCntPalabrasMz(dirMz) > 1){
     strcpy (p,"");
     generaVectorMz(dirMz, RespRral, p);
     if(iMz>0){
      strcat (auxMz,"&&");
     }
     if(getValorNomMz(RespRral[0]) > 0){
            strcat (auxMz,RespRral[0]);
            iMz++;
            if( getValorNomMz(RespRral[0]) == 1){
                isValida = 1;
            }
         }
   }
  }
  
  generaVectorPRMz(auxMz,NomMz,aux2,"&&");
  
  for(i=0; i<iMz; i++){
           
      if( strcmp(NomMz[i],NomMz[i+1]) != 0 ){
        CntNomenclaturaMz = CntNomenclaturaMz +1; 
      }
 }
  
  if(isValida == 0 ) {
    CntNomenclaturaMz = CntNomenclaturaMz*-1;
  }
  
  *outSalida = CntNomenclaturaMz;		
	
}


int getCntPalabrasMz(char *cadena){
 int res=0; char *pch;
 pch = strtok( cadena, " " );
 while (pch != NULL)
  {
   pch = strtok (NULL, " "); 
   res++;
  }
 return res;
}

void generaVectorMz(char cadena[], char *result[], char *pch){
  pch = strtok( cadena, " " );
  int i=0; 
  while (pch != NULL)
  {
   result[i]=pch; 
   pch = strtok (NULL, " "); 
   i++;
  }
  result[i]="\0";
}

void generaVectorPRMz(char cadena[], char *result[], char *pch, char *seperador){
  pch = strtok( cadena, seperador);
  int i=0; 
  while (pch != NULL)
  {
   result[i]=pch; 
   pch = strtok (NULL, seperador); 
   i++;
  }
  result[i]="\0";
}

int getVectorParticulasNomMz(char Dir[], char *Particulas[], char *pch ){

  pch = strtok( Dir, " " );
  int i=0; 
  while (pch != NULL)
  {
   Particulas[i]=pch; 
   pch = strtok (NULL, " "); 
   i++;
  }
  Particulas[i]="\0";
  
  return i;
}

int getDirsSeparadaMz(char *Particulas[], char aux3[], int i){
 int j=0; int valor=0,valor1=0; int dirs = 0;   
 strcpy (aux3,"");
 strcat (aux3,Particulas[0]);
 strcat (aux3," ");
 for(j=1; j<i; j++){
      valor1=getValorNomMz(Particulas[j+1]);
      valor=getValorNomMz(Particulas[j]);
      if(valor>0){
          dirs=dirs+1;
          strcat (aux3,"&&");
          strcat (aux3,Particulas[j]);
          strcat (aux3," ");
      }else{
      strcat (aux3,Particulas[j]);      
       if(valor1<0 && j<i-1){
        strcat (aux3," ");
       }
      }
 }
    
return dirs;
}

int getVectorSegmentosMz(char *Segmentos[], char *cadena, char *separador){
  char *pch1;  int i1=0; int iMz=0;
  pch1 = strtok( cadena, separador );
  while (pch1 != NULL)
  {
   Segmentos[i1]=pch1; 
   pch1 = strtok (NULL, separador); 
   i1++;
  }
 Segmentos[i1]="\0"; 
 return i1;
}

int getValorNomMz(char *pal){
 char v1[500]="CONJ,CD,BR,UN,CDM,URB,ET,SEC,SM,MZ,LT,PA,EX,IN,AP,CS";
 char v2[500]="1,1,1,1,1,1,2,3,4,5,6,7,8,8,9,9";
 char *nomenclaturas[16];
 char *valores[16];
 char *pch;
 char *pch1;   
 
  pch = strtok( v1, "," );
  int i=0; 
  while (pch != NULL)
  {
   nomenclaturas[i]=pch; 
   pch = strtok (NULL, ","); 
   i++;
  }
 
  pch1 = strtok( v2, "," );
  int i1=0; 
  while (pch1 != NULL)
  {
   valores[i1]=pch1; 
   pch1 = strtok (NULL, ","); 
   i1++;
  }

  int j=0;
  int pos=-1;
  for(j=0; j<16; j++){
      if( strcmp(nomenclaturas[j],pal) == 0 ){
   	    pos = j;
   	    break;   	    	
      }
  }
  int aux=-1;
  if(pos > -1){
      aux=atof(valores[pos]);
  }
  return aux;
}