#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#include <regex.h>
#include <ctype.h>
#include <time.h>

int getCntPalabrasVia(char *cadena);
int getValorNomVia(char *pal);
int getVectorParticulasNomVia(char Dir[], char *Particulas[], char *pch );
int getDirsSeparadaVia(char *Particulas[],char aux3[], int i);
int getVectorSegmentosVia(char *Segmentos[], char *cadena, char *separador);
int getNomValor(char cadena[], char AuxDirVia[]);
void generaVectorVia(char cadena[], char *result[], char *pch);

void ValidacionDirVia(VARCHAR_LATIN *DirViaIn,                   
                      INTEGER *Max_Valor_Num_Via,
                      INTEGER *outSalida,
				      SQL_TEXT  extname[129],
				      SQL_TEXT  specific_name[129],
				      SQL_TEXT  error_message[257],
				      char      sqlstate[6]) 
{ 

  char Dir[500];       
  char *Particulas[100];
  char *NomVia[100];
  char *Segmentos[100];  
  char *ParSegmentos[100];  
  char *SegmentosOrdenados[100]; 
  char *pch;
  int dirs=0;
  int i=0;
  char aux3[500];
  char aux10[100];
  char auxVia[500];
  char auxNumero[6];
  char auxVia1[500];
  int j=0;
  int cdr=0;
  char *aux2;
  int CntNomenclaturaVia = 0;
  char p[100];
  char dirVia[100];
  char *RespRral[100];
  char *Nom;
  int iVia=0;
  int k=0;
  char cadena[500];
  char cadenaNom[500];
  char aux1[200];
  char aux_paso[2];
  int cntaux=0;
  strcpy (aux10,"");
  strcpy (auxVia,"");
  strcpy (aux1,"");
  char espacio='-';
  int cnt_valor_nom=0;
  int isnum = 0;
  int valExisteNomVia = 0;  
  int tiempo=(int)time(NULL);
  
  *outSalida=0;
  
  strcpy(Dir,DirViaIn);    
  
  i=getVectorParticulasNom(Dir,Particulas,pch);
  
  if( getValorNomVia(Particulas[0]) > 0  ){
      valExisteNomVia++;
  } 
  
  for(j=0; j<i; j++){        
      int lenDato = strlen(Particulas[j]);
      strcpy(cadena, Particulas[j] );
      k=0; 
      while(k<lenDato){	 
	     if(isdigit(cadena[k]) > 0 ) {
	      aux_paso[0]= cadena[k];
		  aux_paso[1]='\0';
	      strcat (aux1,aux_paso);
	      isnum = 1;
	     }
    	k++;
      }
      if( j<i-1 && isnum == 1){
        strcat (aux1, " ");     
      }
      isnum = 0;
  }
  
  
  dirs=getDirsSeparadaVia(Particulas,aux3,i);  
  cdr=getVectorSegmentosVia(Segmentos, aux3, "&&"); 
  char AuxDirVia[500];
  strcpy (cadenaNom,Segmentos[0] );
  cnt_valor_nom= getNomValor(cadenaNom, AuxDirVia);

  if( cnt_valor_nom > 1 &&  getValorNomVia(Particulas[0])  > 0 ){   	
	sprintf(aux10, "%d", tiempo);	
	strcat (auxVia, aux10);
  }
  
  if( strlen(aux1) > 0 ){
   strcat (auxVia, " ");
   strcat (auxVia, aux1);
  }
  
  int lenDato1 = strlen(auxVia);
  auxVia[lenDato1+1]='\0';
  
	
  strcpy (auxVia1,auxVia);
  generaVectorVia(auxVia, NomVia, pch);

  int n=0;
  int final=getCntPalabrasVia(auxVia1);
  int cnt_dir_num_validas=0;
  int valint = 0;

  for(n=0; n<final; n++){
	    strcpy(auxNumero,"");
		strcpy(auxNumero, NomVia[n]);
		valint = atoi(auxNumero); 
		if(valint>0){
		  if( (valint < *Max_Valor_Num_Via || valint == tiempo) && valExisteNomVia > 0  ){
			  cnt_dir_num_validas = cnt_dir_num_validas +1;   
		   }     
		}
	}

		
	*outSalida = cnt_dir_num_validas;
	
	free(Dir);;       
	free(Particulas);
	free(NomVia);
	free(Segmentos);  
	free(ParSegmentos);  
	free(SegmentosOrdenados); 
	free(pch);
	free(aux3);
	free(auxVia);
	free(auxNumero);
	free(auxVia1);
	free(aux2);
	free(p);
	free(dirVia);
	free(RespRral);
	free(Nom);
	free(cadena);
	free(cadenaNom);
	free(aux1);
	free(aux_paso);
}


int getNomValor(char cadena[], char AuxDirVia[]){
  int tam=strlen(cadena);  
  int index = 0; 
  int resp=0;
  while(index<tam){
        if(isdigit(cadena[index]) > 0 ) {
            break;
         }
        if(index+1<=tam && isdigit(cadena[index+1])== 0 ) {
            AuxDirVia[index]=cadena[index];        
        }
      index++;
    }
   AuxDirVia[index]='\0';	
   resp=getCntPalabrasVia(AuxDirVia);
   return resp;
}

int getCntPalabrasVia(char *cadena){
 int res=0; char *pch;
 pch = strtok( cadena, " " );
 while (pch != NULL)
  {
   pch = strtok (NULL, " ");  
   res++;
  }
 return res;
}

void generaVectorVia(char cadena[], char *result[], char *pch){
  pch = strtok( cadena, " " );
  int i=0; 
  while (pch != NULL)
  {
   result[i]=pch; 
   pch = strtok (NULL, " "); 
   i++;
  }
  result[i]="\0";
}

int getVectorParticulasNomVia(char Dir[], char *Particulas[], char *pch ){

  pch = strtok( Dir, " " );
  int i=0; 
  while (pch != NULL)
  {
   Particulas[i]=pch; 
   pch = strtok (NULL, " "); 
   i++;
  }
  Particulas[i]="\0";
  
  return i;
}

int getDirsSeparadaVia(char *Particulas[], char aux3[], int i){
 int j=0; int valor=0,valor1=0; int dirs = 0;   
 strcpy (aux3,"");
 strcat (aux3,Particulas[0]);
 strcat (aux3," ");
 for(j=1; j<i; j++){
      valor1=getValorNomVia(Particulas[j+1]);
      valor=getValorNomVia(Particulas[j]);
      if(valor>0){
          dirs=dirs+1;
          strcat (aux3,"&&");
          strcat (aux3,Particulas[j]);
          strcat (aux3," ");
      }else{
      strcat (aux3,Particulas[j]);      
       if(valor1<0 && j<i-1){
        strcat (aux3," ");
       }
      }
 }
    
return dirs;
}

int getVectorSegmentosVia(char *Segmentos[], char *cadena, char *separador){
  char *pch1;  int i1=0; int iVia=0;
  pch1 = strtok( cadena, separador );
  while (pch1 != NULL)
  {
   Segmentos[i1]=pch1; 
   pch1 = strtok (NULL, separador); 
   i1++;
  }
 Segmentos[i1]="\0"; 
 return i1;
}

int getValorNomVia(char *pal){
 char v1[500]="KR,VIA,PN,AU,CL,DG,TV,CV,CIR,CLJ,AV,BLV,PS,PSJ,PT,AER";
 char v2[500]="1,4,1,1,1,1,1,1,1,1,1,1,1,1,1,1";
 char *nomenclaturas[16];
 char *valores[16];
 char *pch;
 char *pch1;   
 
  pch = strtok( v1, "," );
  int i=0; 
  while (pch != NULL)
  {
   nomenclaturas[i]=pch; 
   pch = strtok (NULL, ","); 
   i++;
  }
 
  pch1 = strtok( v2, "," );
  int i1=0; 
  while (pch1 != NULL)
  {
   valores[i1]=pch1; 
   pch1 = strtok (NULL, ","); 
   i1++;
  }

  int j=0;
  int pos=-1;
  for(j=0; j<16; j++){
      if( strcmp(nomenclaturas[j],pal) == 0 ){
   	    pos = j;
   	    break;   	    	
      }
  }
  int aux=-1;
  if(pos > -1){
      aux=atof(valores[pos]);
  }
  return aux;
}
