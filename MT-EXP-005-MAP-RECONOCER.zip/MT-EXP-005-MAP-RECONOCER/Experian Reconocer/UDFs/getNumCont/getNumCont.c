#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#include <regex.h>
#include <ctype.h>

int getVector(char cadena[], char *result[], char *pch);
int ValNumero(char *dir);

int getNumCont(VARCHAR_LATIN  *Complement,                
                VARCHAR_LATIN *Par,
			    VARCHAR_LATIN *outSalida,
				SQL_TEXT extname[129],
				SQL_TEXT specific_name[129],
				SQL_TEXT error_message[257],
				char sqlstate[6])
{
	char Dir[500];    
    char *result[100];
    char *digComp[100];
    char *pch;    
    int j=0;
    int i=0;
    int k=0;
    int val=0;
    int val1=0;
    int n=0;
    char *aux,aux1[500];
    strcpy (aux1,"NO VALIDA");	
	
	strcpy (Dir,Complement);
    
    j=getVector(Dir, result, pch);    
   
   if(j>0 ){     
    for(i=j-1; i>0; i--){    
      val=ValNumero(result[i]);
      n=i-1;
      val1=ValNumero(result[n]);
      
      if( val==1 && val1==1 ) {		  
		 digComp[k]=result[n];
		 k=k+1;
		 digComp[k]=" ";
		 k=k+1;
		 digComp[k]=result[i];
		 k=k+1;
		 digComp[k]="|";
		 k=k+1;
		 digComp[k]=result[n];
		 k=k+1;
		 digComp[k]=" ";
		 k=k+1;
		 digComp[k]=result[i];
		 k=k+1;		 
		 break;
	  }
	  
	  n=i-2;
	  val=ValNumero(result[i]);
      val1=ValNumero(result[n]);
	  
	  if( val==1 && val1==1 ){		  
	     digComp[k]=result[n];
		 k=k+1;
		 digComp[k]=" ";
		 k=k+1;
		 digComp[k]=result[i];
		 k=k+1;
		 digComp[k]="|";
		 k=k+1;
		 digComp[k]=result[n-1];
		 k=k+1;
		 digComp[k]=" ";
		 k=k+1;
		 digComp[k]=result[n];
		 k=k+1;
		 digComp[k]=" ";
		 k=k+1;
		 digComp[k]=result[i-1];
		 k=k+1;
		 digComp[k]=" ";
		 k=k+1;
		 digComp[k]=result[i];
		 k=k+1;
		 break;		 
	  }
    }
    
  if(strcmp(Par,"1") == 0 && k>0){       
  strcpy (aux1,"");   
    for(n=0; n<k; n++){
       aux=digComp[n];
    if(strcmp(aux,"|") == 0){
      break;
    }
    strcat (aux1,aux);
    }   
  }
  
  if(strcmp(Par,"2") == 0 && k>0 ){
	 strcpy (aux1,"");    
    for(n=k-7; n<k; n++){
       aux=digComp[n];
    if(strcmp(aux,"|") == 0){
      break;
    }
    strcat (aux1,aux);
    }       
  }
  }   
   sprintf (outSalida,aux1);
}

int ValNumero(char *dir){
 char  cadena[200];
 int lenDato = strlen(dir);
 strcpy(cadena, dir );
 int i=0;
 int val=1;
 
 	while(i<lenDato){	 
	 if(isdigit(cadena[i]) == 0 ) {
	  val=0;
	 }
	i++;
	}
  return val;
}

int getVector(char cadena[], char *result[], char *pch){
  pch = strtok( cadena, " " );
  int i=0; 
  while (pch != NULL)
  {
   result[i]=pch; 
   pch = strtok (NULL, " "); 
   i++;
  }
  result[i]="\0";
  
  return i;
}
