#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#include <regex.h>
#include <ctype.h>

int  valNivel(char cadena[], char cadena1[], int pls);
int  getCntPalabras(char *cadena);
void generaVector(char cadena[], char *result[], char *pch);
int  getValorNom(char *pal);
int  LlenarVectorParticulas(char Dir[], char *Particulas[], char *pch );
int  getDirsSeparada(char *Particulas[], char aux3[], int i);
void LlenarVectorSegmentos(char *Segmentos[], char *cadena, char *separador);
void LlenarVectorParSegmentos(char *ParSegmentos[], char *cadena, char *separador, char *Segmento[],  int ubic);
void OrdenarSegmentos(char *Segmentos[], int tam);
int  OrdenarNomenclatura(char *Segmentos[], int tam, char *SegmentosOrdenados[]);
int  existeNivel(char *Segmentos1[], int tam, char *pal);

void SetComplement(VARCHAR_LATIN  *Complement,
				   VARCHAR_LATIN  *outSalida,
				   SQL_TEXT  extname[129],
				   SQL_TEXT  specific_name[129],
				   SQL_TEXT  error_message[257],
				   char      sqlstate[6]) 
{
  //Apuntadores.
  char Dir[200];
  char *Particulas[100];  
  char *Segmentos[100]; 
  char *ParSegmentos[100];    
  char *SegmentosOrdenados[100];
  char *pch;
  char *aux2;	
  char *aux;
  char *Resp[100];
  char *Resp1[100];
  
  //Variables:    
  char aux1[200];
  char aux3[200];
  char cadena[100];
  char cadena1[100];
  char p[100];
  char p1[100];
    
  int dirs=0;
  int i=0;  
  int j=0;
  int k=0;
  int n=0;
  int j1=0;
  int j2=0;
  int j3=0;
  int valor1=0;
  int valor2=0;
  int pls=0;  
  int pls1=0;   
  int jp=0;
  
  //Inicializando Complemento    
  strcpy (Dir,Complement);
  
  //Inicializando variable de salida.
  sprintf (outSalida, "");  
  
  //Llenando vector de particulas
  i=LlenarVectorParticulas(Dir,Particulas,pch);
  dirs=getDirsSeparada(Particulas,aux3,i);
  
  
  int i1=dirs+1;
  //Llenando vecto de segmentos
  LlenarVectorSegmentos(Segmentos, aux3, "&&");     
   
  
  for(jp=0; jp<dirs+1; jp++){
      strcpy (cadena1,Segmentos[jp]);
      LlenarVectorParSegmentos(ParSegmentos, cadena1, " ", Segmentos, jp);
  }
  
  int val=0;
  
   for(j=0; j<i1; j++){
     
	 j1=j+1;     	 
	 strcpy (cadena,Segmentos[j]);
     pls=getCntPalabras(cadena);
     
	 for(k=j1; k<i1; k++ ){
         
       strcpy (cadena,Segmentos[j]);
       strcpy (cadena1,Segmentos[k]);
       pls1 = getCntPalabras(cadena1);
       strcpy (cadena1,Segmentos[k]);
		 
       if(pls == pls1){          
		strcpy (p,"");
        strcpy (p1,"");
        generaVector(cadena, Resp, p);
        generaVector(cadena1, Resp1, p1);
        valor1 = getValorNom(Resp[0]);
        valor2 = getValorNom(Resp1[0]);
        val=0;           
		   if(valor1==valor2 && valor1 >0){
              for(j2=1; j2<pls; j2++){
                if( strcmp(Resp[j2],Resp1[j2]) != 0  ){
                  val=1;                    
                 }
              }			  
			  if(val==0){                   
				 if(valor1 < 7){
                    Segmentos[k]="R&P&Z";
                   }else{                       
                       if(j==k-1){
                         Segmentos[k]="R&P&Z";
                       }else{						   
							if( j > 0 ){							   
								strcpy(cadena,Segmentos[j-1]);
								pls=getCntPalabras(cadena);
								strcpy (cadena,Segmentos[j-1]);
								strcpy (cadena1,Segmentos[k-1]);
								
								pls1=getCntPalabras(cadena1);
								
								strcpy(cadena1,Segmentos[k-1]);
								strcpy(p,"");
								strcpy(p1,"");
								
								if(pls == pls1){							   
								   val=valNivel(cadena,cadena1,pls);
								   if(val==0){
									 Segmentos[k]="R&P&Z";    								 
								   }
								}
							}
                       }     
                    }//FIN ELSE
						
                 if(strcmp(cadena1,"R&P&Z") == 0 || valor1==1 ){                  
                   Segmentos[k]="R&P&Z";
                 }                     
               }//Fin IF VAL=0            
            }
          }
       }
    }
    
  strcpy (p,"");
  strcpy (p1,"");

  int h=dirs;
  int ordenar=0;
  int t1=0;
  int exit1=0;
  int cntwh=1;
  
  while(h>0){
	 aux=Segmentos[h];
	 if(strcmp(aux,"R&P&Z") != 0 ){
			strcpy (cadena,Segmentos[h]);
			exit1=0;
			while(exit1==0){
			 t1=h-cntwh;    
			 strcpy (cadena1,Segmentos[t1]);
			 if( strcmp(cadena1,"R&P&Z") != 0){
				exit1=1; 				
			  }
			  cntwh=cntwh+1;
		}
			
		generaVector(cadena, Resp, p);
		generaVector(cadena1, Resp1, p1);
		valor1 = getValorNom(Resp[0]);
		valor2 = getValorNom(Resp1[0]);		   
		if(valor1<valor2 && valor1>-1){
		   ordenar=OrdenarNomenclatura(Segmentos, dirs, SegmentosOrdenados);			   			   
		 }
		break;
	 }
	 h=h-1;
   }  
 
 if( ordenar > 0 ){
   for(n=0; n<ordenar; n++){
    aux=SegmentosOrdenados[n];  
     if(strcmp(aux,"R&P&Z") != 0 ){
	   if(n>0){
         strcat (aux1," ");    
        }
        strcat (aux1,aux);     
	}
   }  
 }else{
   for(n=0; n<dirs+1; n++){
    aux=Segmentos[n];  
     if(strcmp(aux,"R&P&Z") != 0 ){
	   if(n>0){
         strcat (aux1," ");    
       }
       strcat (aux1,aux);     
      }
     }
   }
  
  sprintf(outSalida,aux1);
  
  sprintf (aux1, "");  
  
  //Limpiando Apuntadores
  free(Dir);
  free(Particulas);
  //free(Segmentos);
  free(SegmentosOrdenados);
  free(pch);
  free(aux2);	
  free(aux);
  free(Resp);
  free(Resp1);
  
  //Variables:    
  free(aux1);
  free(aux3);
  free(cadena);
  free(cadena1);
  free(p);
  free(p1);
 
}


int valNivel(char cadena[], char cadena1[], int pls){
char *Resp[100];
char *Resp1[100];
char p[100];
char p1[100];
int valor1=0;
int valor2=0;
int j3=0;
int val=0;
      generaVector(cadena, Resp, p);
      generaVector(cadena1, Resp1, p1);
	  
      valor1 = getValorNom(Resp[0]);
      valor2 = getValorNom(Resp1[0]);
     if(valor1 == valor2 && valor1 > 0 ){
         for(j3=1; j3<pls; j3++){
              if( strcmp(Resp[j3],Resp1[j3]) != 0  ){               
                 val=1;                 
                }
         }
         
 if(valor1<valor2){
      val=0;
  }
 free(Resp);
 free(Resp1);
 free(p);
 free(p1); 
 return val;
 }
}



int getCntPalabras(char *cadena){
 int res=0; char *pch;
 pch = strtok( cadena, " " );
 while (pch != NULL)
  {
   pch = strtok (NULL, " "); 
   res++;
  }
 free(pch);
 return res;
}

void generaVector(char cadena[], char *result[], char *pch){
  pch = strtok( cadena, " " );
  int i=0; 
  while (pch != NULL)
  {
   result[i]=pch; 
   pch = strtok (NULL, " "); 
   i++;
  }
  free(pch);  
  result[i]="\0";
}

int LlenarVectorParticulas(char Dir[], char *Particulas[], char *pch ){

  pch = strtok( Dir, " " );
  int i=0; 
  while (pch != NULL)
  {
   Particulas[i]=pch; 
   pch = strtok (NULL, " "); 
   i++;
  }
  free(pch);
  Particulas[i]="\0";  
  return i;
}

int getDirsSeparada(char *Particulas[], char aux3[], int i){
 int j=0; int valor=0,valor1=0; int dirs = 0;   
 strcpy (aux3,"");
 strcat (aux3,Particulas[0]);
 strcat (aux3," ");
 for(j=1; j<i; j++){
      valor1=getValorNom(Particulas[j+1]);
      valor=getValorNom(Particulas[j]);
      if(valor>0){
          dirs=dirs+1;
          strcat (aux3,"&&");
          strcat (aux3,Particulas[j]);
          strcat (aux3," ");
      }else{
      strcat (aux3,Particulas[j]);      
       if(valor1<0 && j<i-1){
        strcat (aux3," ");
       }
      }
    }    
return dirs;
}

void LlenarVectorSegmentos(char *Segmentos[], char *cadena, char *separador){
  char *pch1;  int i1=0; 
  pch1 = strtok( cadena, separador );
  while (pch1 != NULL)
  {
   Segmentos[i1]=pch1; 
   pch1 = strtok (NULL, separador); 
   i1++;
  }
 free(pch1);
}

int getMinPos(int v[], int tam){
  int i=0;
  int aux=v[0];
    for(i=1;i<tam; i++){
        if(aux>v[i]){
            aux=v[i];
        }
    }
 return aux;
}

int getValorNom(char *pal){
 char v1[500]="UN,CDM,BR,CD,CONJ,CC,URB,ED,POR,PQ,SEC,MLT,ZN,SM,MZ,CU,ET,AG,MD,IN,TO,EX,NCO,BL,NI,PI,PL,PQD,TZ,SS,LC,AL,GS,MN,OF,SA,BG,AP,ST,SU,CS,CN,GJ,DP,PH,LT,PU,PD,PA,ESQ,AD,EN,ALC,CPO,BA,GR,IF,CEN";
 char v2[500]="1,1,1,1,1,1,1,2,2,2,2,2,2,2,3,4,4,4,5,5,5,5,5,5,6,6,6,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,8,9,9,9,10,10,10,11,11,11,12,13,99";
 char *nomenclaturas[58];
 char *valores[58];
 char *pch;
 char *pch1;   
 
  pch = strtok( v1, "," );
  int i=0; 
  while (pch != NULL)
  {
   nomenclaturas[i]=pch; 
   pch = strtok (NULL, ","); 
   i++;
  }
 
  pch1 = strtok( v2, "," );
  int i1=0; 
  while (pch1 != NULL)
  {
   valores[i1]=pch1; 
   pch1 = strtok (NULL, ","); 
   i1++;
  }

  int j=0;
  int pos=0;
  for(j=0; j<58; j++){
      if( strcmp(nomenclaturas[j],pal) == 0 ){
   	    pos = j;
   	    break;   	    	
      }
  }
  int aux=-1;
  if(pos > 0){
      aux=atof(valores[pos]);
  }
  free(nomenclaturas);
  free(pch);
  free(pch1);
  return aux;
  
}


int OrdenarNomenclatura(char *Segmentos[], int tam, char *Segmentos1[] ){
int NomOrden[tam]; int j=0, i=0, n=0, k=0,corden=0, cconteo=0;
char aux2[100];
char aux3[100];
char aux4[100];
char *v[100];
char p[100];
int cnt=0;
int cnt1=0;
int aux=0;
int valor1=0;
    
 for(j=0; j<tam+1; j++){ 
   strcpy (aux2,Segmentos[j]);
   strcpy (p,"");
   generaVector(aux2, v, p);
   valor1 = getValorNom(v[0]);
   if( valor1 > 0 ) {
    NomOrden[corden] =valor1;
    corden = corden+1;
    }             
 }
 
 for(n=0; n<corden; n++){
  k=n+1;
   for(i=k; i<corden; i++){
      if(NomOrden[i]<NomOrden[n]){
        aux=NomOrden[i];
        NomOrden[i]=NomOrden[n];
        NomOrden[n]=aux;
       }
    }
  }  
    
 //Inicializando vector Segmento: 
 for(n=0; n<=tam; n++){
    Segmentos1[n] = "R&P&Z";
 }
	 
 for(n=0; n<corden; n++){
	for(i=0; i<tam+1; i++){
	   strcpy (aux2,Segmentos[i]);
	   strcpy (p,"");
	   generaVector(aux2, v, p);
	   valor1 = getValorNom(v[0]);
		if( NomOrden[n]== valor1 && valor1>0  ){
		 if(n>0){
			 if( existeNivel(Segmentos1,n,Segmentos[i]) == -1){
			  Segmentos1[n]= Segmentos[i];
			 }   
			
		 }else{
		   if( strcmp(v[0],"BR") == 0 ){
			  Segmentos1[n]= Segmentos[i];        
			  break;    
			}else{
			  Segmentos1[n]= Segmentos[i];        
			}
		 }
		}
	}
	}  
 free(aux2);
 free(aux3);
 free(aux4);
 free(v);
 free(p);
 return corden;
}

int existeNivel(char *Segmentos1[], int tam, char *pal){
  int j=0;
  int pos=-1;
  for(j=0; j<tam; j++){
    if( strcmp(Segmentos1[j],pal) == 0 ){
   	  pos = j;
   	  break;   	    	
    }
  }
 return pos;
}




void LlenarVectorParSegmentos(char *ParSegmentos[], char *cadena, char *separador, char *Segmentos[],  int ubic){
  char *pch2,*auxp;  int i2=0; 
  pch2 = strtok( cadena, separador );
  while (pch2 != NULL)
  {
   ParSegmentos[i2]=pch2; 
   pch2 = strtok (NULL, separador); 
   i2++;
  }
  int i=0, j=0;   
  for( i=0; i<i2; i++){
      for ( j=1; j<i2; j++){
          if ( strcmp(ParSegmentos[i],ParSegmentos[j]) == 0 && j>i ){
              ParSegmentos[j] = "R&P&Z";              
          }
      }
  }
  
  char auxp1[500];
  strcpy (auxp1,"");  
  
  for( i=0; i<i2; i++){      
      auxp=ParSegmentos[i];  
     if(strcmp(auxp,"R&P&Z") != 0 ){
	   if(i>0){
        strcat (auxp1," ");    
       }
       strcat (auxp1,auxp);       
     }
  }
  
  strcpy (Segmentos[ubic],auxp1);
  
  free(pch2);
  free(auxp);
  free(auxp1);
}
