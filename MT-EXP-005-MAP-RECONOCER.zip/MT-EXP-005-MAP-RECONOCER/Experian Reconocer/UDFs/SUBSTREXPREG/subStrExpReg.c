/*
 * ################################################################################
 * 
 * Objetivo:	  Funcion subStrExpReg para extraer el texto del string enviado que
 * 		  cumpla con la expresion regular enviada
 * Fecha:	  2016/11/11
 * Realizado por: Luis E Ramirez (Capgemini)
 * Parametros:	  inStr, inExp, outStr
 * Proyecto:	  Experian - Nuevo Reconocer 3
 * Script:	  subStrExpReg.c
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha		Objetivo			Realizado por
 * 
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */

#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include "operationsString.h"
#include <stdio.h>
#include <string.h>

void subStrExpReg (
			VARCHAR_LATIN *inStr,
			VARCHAR_LATIN *inExp,
			VARCHAR_LATIN *outStr,
			SQL_TEXT extname[129],
			SQL_TEXT specific_name[129],
			SQL_TEXT error_message[257])
{
	int b,e;
	
	char *match;
	
	match = (char*)malloc(100*sizeof(char)); 
	sprintf (match, "");
	sprintf (outStr, "");
	
	regexp(inStr,inExp,&b,&e, match);
	
	if (match != NULL)
		strcpy (outStr,match);
	
	free(match);
}
