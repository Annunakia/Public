#ifndef _LOADPARAMACEPAUT_H
#define _LOADPARAMACEPAUT_H 1
/*
 * ################################################################################
 * 
 * Objetivo:	  Biblioteca para cargar los parametros definidos en el proceso
 *		  de generacion de acepciones
 * Fecha:	  2017/01/17
 * Realizado por: Luis E Ramirez (Capgemini)
 * Parametros:	  N/A
 * Proyecto:	  Experian - Nuevo Reconocer 3
 * Script:	  loadParamsAcepAut.h
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha		Objetivo			Realizado por
 * 
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */
 
#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
 
// Constantes 
#define NOM_MAXNAMELEN 50 // Iindica el tama�o maximo para string de s_nomStandard

//Estructuras
	//Estandar de nomenclaturas
typedef struct s_nomStandard 
{
		char word[NOM_MAXNAMELEN];
		char nomenclature[NOM_MAXNAMELEN];
		char LevelTrack1[NOM_MAXNAMELEN];
		char LevelTrack2[NOM_MAXNAMELEN];
		char LevelTrack3[NOM_MAXNAMELEN];
		char soundexWord[NOM_MAXNAMELEN];
		struct s_nomStandard *next;
} s_nomStandard;

	//Reglas para definir Acepciones
typedef struct s_ruleMeaning
{
	int idRule; // Id de la regla
	char soundexFull; // Soundex completo, letra y numeros {Y/N} -- 10
	char soundexNumerical; // Parte numerica del soundex {Y/N} -- 100
	char wordInNomenclature; // Palabra contenida en nomenclatura {Y/N} -- 1000
	char nomenclatureInWord; // Nomenclatura contenida en palabra {Y/N} --10000
	char track1; // Pista 1 contenida en palabra {Y/N} -- 100000
	char track2; // Pista 2 contenida en palabra {Y/N} -- 1000000
	char track3; // Pista 3 contenida en palabra {Y/N} -- 10000000
	int distanceLevenshtein; // valor maximo permitido para esta validaci�n, 0 sino aplica, si tiene 3, es el tercio de la palabra
	int validationValue; // Valor que indica el si la validacion fue exitosa, entonces, es el acumulado de todas las anteriores que
			     // tengan Y, por cada una se asigna 1, la suma de todos los 1, es el validationValue.
	struct s_ruleMeaning *next;
} s_ruleMeaning;

// Definiciones de variables
struct s_nomStandard *NOM_STANDARD, *NOM_STANDARD_START;
struct s_ruleMeaning *RULES, *RULES_START;

// Encabezados de funciones
// Recibe el registro de una nomclatura y aplica las reglas
// retorna 1 si cumple alguna de ella o 0 sino.
int validateRuleToNomenclature (struct s_nomStandard *Nomenclature, char *word, char *soundex);

//Recibe la palabra y el soundex, llama la funci�n validateRuleToNomenclature y
//retorna la nomenclatura seg�n sea el caso.
void identNomenclature (char *str, char *word, char *soundex); 

void iniNOM_STANDARD (); // Incializa parametros de nomenclatura

void freeNOM_STANDARD (); //Libera la  memoria de la colas de tipo s_nomStandard

void iniRULES (); // Incializa reglas
void freeRULES (); //Libera la  memoria de la colas de tipo s_ruleMeaning


/*
* La siguiente funciones descargads de internet, del siguiente link
*/

#define MAX_STRING_LENGTH 255

/**
 * Get the minimum from the incoming inputs.
 * 
 */
#define MIN3(a, b, c) ((a) < (b) ? ((a) < (c) ? (a) : (c)) : ((b) < (c) ? (b) : (c)))

/* The Levenshtein distance function returns the minimum number */
/* of edit operations. Refer to header file for more details.   */
void editdistance_u(VARCHAR_LATIN *str1,
                    VARCHAR_LATIN *str2,
                    INTEGER *ci,
                    INTEGER *cd,
                    INTEGER *cs,
                    INTEGER *ct,
                    INTEGER *result,
                    char sqlstate[6]);

#endif /* _LOADPARAMACEPAUT_1*/
