#include "loadParamsAcepAut.h"
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

/*
 * ################################################################################
 * 
 * Objetivo:	  Script que contiene las funciones para inicializar la variable NOM_STANDARD
 * Fecha:	  2017/01/17
 * Realizado por: Luis E Ramirez (Capgemini)
 * Parametros:	  N/A
 * Proyecto:	  Experian - Nuevo Reconocer 3
 * Script:	  loadParamsAcepAut.c
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha		Objetivo			Realizado por
 * 
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */

//Funciones         
// Incializa parametros de nomenclatura
void iniNOM_STANDARD ()              
{	
	struct s_nomStandard *StandardEnd = NULL;
	
	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));			
	strcpy (NOM_STANDARD->word,"BARRIO");  //[1]
	strcpy (NOM_STANDARD->nomenclature,"BR");
	strcpy (NOM_STANDARD->LevelTrack1,"BAR");
	strcpy (NOM_STANDARD->LevelTrack2,"ARR");  
	strcpy (NOM_STANDARD->LevelTrack3,"RIO");
	strcpy (NOM_STANDARD->soundexWord,"B600");
	StandardEnd = NOM_STANDARD_START = NOM_STANDARD; 
	
	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"CIUDADELA");  //[2]
	strcpy (NOM_STANDARD->nomenclature,"CD");
	strcpy (NOM_STANDARD->LevelTrack1,"CIU");
	strcpy (NOM_STANDARD->LevelTrack2,"DADE");
	strcpy (NOM_STANDARD->LevelTrack3,"ELA");
	strcpy (NOM_STANDARD->soundexWord,"C334");
	StandardEnd->next=NOM_STANDARD;
 	StandardEnd=NOM_STANDARD;

 	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"CONDOMINIO");  //[3]
	strcpy (NOM_STANDARD->nomenclature,"CDM");
	strcpy (NOM_STANDARD->LevelTrack1,"CON");
	strcpy (NOM_STANDARD->LevelTrack2,"DOM");
	strcpy (NOM_STANDARD->LevelTrack3,"INIO");
	strcpy (NOM_STANDARD->soundexWord,"C535");
	StandardEnd->next=NOM_STANDARD;
 	StandardEnd=NOM_STANDARD;
 	
 	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"CONJUNTO");
	strcpy (NOM_STANDARD->nomenclature,"CONJ");
	strcpy (NOM_STANDARD->LevelTrack1,"CON");
	strcpy (NOM_STANDARD->LevelTrack2,"NJU");
	strcpy (NOM_STANDARD->LevelTrack3,"NTO");
	strcpy (NOM_STANDARD->soundexWord,"C525");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"UNIDAD");
	strcpy (NOM_STANDARD->nomenclature,"UN");
	strcpy (NOM_STANDARD->LevelTrack1,"UNI");
	strcpy (NOM_STANDARD->LevelTrack2,"IDA");
	strcpy (NOM_STANDARD->LevelTrack3,"DAD");
	strcpy (NOM_STANDARD->soundexWord,"U533");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"URBANIZACION");
	strcpy (NOM_STANDARD->nomenclature,"URB");
	strcpy (NOM_STANDARD->LevelTrack1,"URBA");
	strcpy (NOM_STANDARD->LevelTrack2,"NIZA");
	strcpy (NOM_STANDARD->LevelTrack3,"ZACIO");
	strcpy (NOM_STANDARD->soundexWord,"U615");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"CENTRO COMERCIAL");
	strcpy (NOM_STANDARD->nomenclature,"CC");
	strcpy (NOM_STANDARD->LevelTrack1,"NULL");
	strcpy (NOM_STANDARD->LevelTrack2,"NULL");
	strcpy (NOM_STANDARD->LevelTrack3,"NULL");
	strcpy (NOM_STANDARD->soundexWord,"C536");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"EDIFICIO");
	strcpy (NOM_STANDARD->nomenclature,"ED");
	strcpy (NOM_STANDARD->LevelTrack1,"EDI");
	strcpy (NOM_STANDARD->LevelTrack2,"IFI");
	strcpy (NOM_STANDARD->LevelTrack3,"ICI");
	strcpy (NOM_STANDARD->soundexWord,"E312");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"MULTIFAMILIAR");
	strcpy (NOM_STANDARD->nomenclature,"MLT");
	strcpy (NOM_STANDARD->LevelTrack1,"MULT");
	strcpy (NOM_STANDARD->LevelTrack2,"TIFA");
	strcpy (NOM_STANDARD->LevelTrack3,"MILIA");
	strcpy (NOM_STANDARD->soundexWord,"M431");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"PORTERIA");
	strcpy (NOM_STANDARD->nomenclature,"POR");
	strcpy (NOM_STANDARD->LevelTrack1,"PORT");
	strcpy (NOM_STANDARD->LevelTrack2,"RTE");
	strcpy (NOM_STANDARD->LevelTrack3,"RIA");
	strcpy (NOM_STANDARD->soundexWord,"P636");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"PARQUE");
	strcpy (NOM_STANDARD->nomenclature,"PQ");
	strcpy (NOM_STANDARD->LevelTrack1,"PAR");
	strcpy (NOM_STANDARD->LevelTrack2,"RQU");
	strcpy (NOM_STANDARD->LevelTrack3,"QUE");
	strcpy (NOM_STANDARD->soundexWord,"P620");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"ZONA");
	strcpy (NOM_STANDARD->nomenclature,"ZN");
	strcpy (NOM_STANDARD->LevelTrack1,"ZO");
	strcpy (NOM_STANDARD->LevelTrack2,"ON");
	strcpy (NOM_STANDARD->LevelTrack3,"ONA");
	strcpy (NOM_STANDARD->soundexWord,"Z500");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"SECTOR");
	strcpy (NOM_STANDARD->nomenclature,"SEC");
	strcpy (NOM_STANDARD->LevelTrack1,"ECT");
	strcpy (NOM_STANDARD->LevelTrack2,"CTO");
	strcpy (NOM_STANDARD->LevelTrack3,"TOR");
	strcpy (NOM_STANDARD->soundexWord,"S236");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"SUPERMANZANA");
	strcpy (NOM_STANDARD->nomenclature,"SM");
	strcpy (NOM_STANDARD->LevelTrack1,"SUPE");
	strcpy (NOM_STANDARD->LevelTrack2,"RMAN");
	strcpy (NOM_STANDARD->LevelTrack3,"ZAN");
	strcpy (NOM_STANDARD->soundexWord,"S165");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"MANZANA");
	strcpy (NOM_STANDARD->nomenclature,"MZ");
	strcpy (NOM_STANDARD->LevelTrack1,"MAN");
	strcpy (NOM_STANDARD->LevelTrack2,"NZAN");
	strcpy (NOM_STANDARD->LevelTrack3,"ZANA");
	strcpy (NOM_STANDARD->soundexWord,"M525");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"ETAPA");
	strcpy (NOM_STANDARD->nomenclature,"ET");
	strcpy (NOM_STANDARD->LevelTrack1,"ETA");
	strcpy (NOM_STANDARD->LevelTrack2,"TAP");
	strcpy (NOM_STANDARD->LevelTrack3,"APA");
	strcpy (NOM_STANDARD->soundexWord,"E310");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"AGRUPACION");
	strcpy (NOM_STANDARD->nomenclature,"AG");
	strcpy (NOM_STANDARD->LevelTrack1,"AGRU");
	strcpy (NOM_STANDARD->LevelTrack2,"PA");
	strcpy (NOM_STANDARD->LevelTrack3,"CION");
	strcpy (NOM_STANDARD->soundexWord,"A261");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"CELULA");
	strcpy (NOM_STANDARD->nomenclature,"CU");
	strcpy (NOM_STANDARD->LevelTrack1,"CEL");
	strcpy (NOM_STANDARD->LevelTrack2,"LUL");
	strcpy (NOM_STANDARD->LevelTrack3,"ULA");
	strcpy (NOM_STANDARD->soundexWord,"C440");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"BLOQUE");
	strcpy (NOM_STANDARD->nomenclature,"BL");
	strcpy (NOM_STANDARD->LevelTrack1,"BLOQ");
	strcpy (NOM_STANDARD->LevelTrack2,"OQ");
	strcpy (NOM_STANDARD->LevelTrack3,"QUE");
	strcpy (NOM_STANDARD->soundexWord,"B420");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"MODULO");
	strcpy (NOM_STANDARD->nomenclature,"MD");
	strcpy (NOM_STANDARD->LevelTrack1,"MOD");
	strcpy (NOM_STANDARD->LevelTrack2,"ODU");
	strcpy (NOM_STANDARD->LevelTrack3,"ULO");
	strcpy (NOM_STANDARD->soundexWord,"M340");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"NUCLEO");
	strcpy (NOM_STANDARD->nomenclature,"NCO");
	strcpy (NOM_STANDARD->LevelTrack1,"NUC");
	strcpy (NOM_STANDARD->LevelTrack2,"UCLE");
	strcpy (NOM_STANDARD->LevelTrack3,"CLEO");
	strcpy (NOM_STANDARD->soundexWord,"N240");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"TORRE");
	strcpy (NOM_STANDARD->nomenclature,"TO");
	strcpy (NOM_STANDARD->LevelTrack1,"TOR");
	strcpy (NOM_STANDARD->LevelTrack2,"ORR");
	strcpy (NOM_STANDARD->LevelTrack3,"RRE");
	strcpy (NOM_STANDARD->soundexWord,"T600");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"EXTERIOR");
	strcpy (NOM_STANDARD->nomenclature,"EX");
	strcpy (NOM_STANDARD->LevelTrack1,"EXT");
	strcpy (NOM_STANDARD->LevelTrack2,"XTE");
	strcpy (NOM_STANDARD->LevelTrack3,"RIOR");
	strcpy (NOM_STANDARD->soundexWord,"E236");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"INTERIOR");
	strcpy (NOM_STANDARD->nomenclature,"IN");
	strcpy (NOM_STANDARD->LevelTrack1,"INT");
	strcpy (NOM_STANDARD->LevelTrack2,"TERI");
	strcpy (NOM_STANDARD->LevelTrack3,"IOR");
	strcpy (NOM_STANDARD->soundexWord,"I536");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"NIVEL");
	strcpy (NOM_STANDARD->nomenclature,"NI");
	strcpy (NOM_STANDARD->LevelTrack1,"NIV");
	strcpy (NOM_STANDARD->LevelTrack2,"IVE");
	strcpy (NOM_STANDARD->LevelTrack3,"VEL");
	strcpy (NOM_STANDARD->soundexWord,"N140");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"PISO");
	strcpy (NOM_STANDARD->nomenclature,"PI");
	strcpy (NOM_STANDARD->LevelTrack1,"PIS");
	strcpy (NOM_STANDARD->LevelTrack2,"IS");
	strcpy (NOM_STANDARD->LevelTrack3,"ISO");
	strcpy (NOM_STANDARD->soundexWord,"P200");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"PLANTA");
	strcpy (NOM_STANDARD->nomenclature,"PL");
	strcpy (NOM_STANDARD->LevelTrack1,"PLA");
	strcpy (NOM_STANDARD->LevelTrack2,"ANT");
	strcpy (NOM_STANDARD->LevelTrack3,"NTA");
	strcpy (NOM_STANDARD->soundexWord,"P453");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"ALTILLO");
	strcpy (NOM_STANDARD->nomenclature,"AL");
	strcpy (NOM_STANDARD->LevelTrack1,"ALT");
	strcpy (NOM_STANDARD->LevelTrack2,"TIL");
	strcpy (NOM_STANDARD->LevelTrack3,"LLO");
	strcpy (NOM_STANDARD->soundexWord,"A434");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"CONSULTORIO");
	strcpy (NOM_STANDARD->nomenclature,"CN");
	strcpy (NOM_STANDARD->LevelTrack1,"CONS");
	strcpy (NOM_STANDARD->LevelTrack2,"NSUL");
	strcpy (NOM_STANDARD->LevelTrack3,"ORIO");
	strcpy (NOM_STANDARD->soundexWord,"C524");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"DEPOSITO");
	strcpy (NOM_STANDARD->nomenclature,"DP");
	strcpy (NOM_STANDARD->LevelTrack1,"DEP");
	strcpy (NOM_STANDARD->LevelTrack2,"POS");
	strcpy (NOM_STANDARD->LevelTrack3,"ITO");
	strcpy (NOM_STANDARD->soundexWord,"D123");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"GARAJE");
	strcpy (NOM_STANDARD->nomenclature,"GJ");
	strcpy (NOM_STANDARD->LevelTrack1,"GAR");
	strcpy (NOM_STANDARD->LevelTrack2,"ARA");
	strcpy (NOM_STANDARD->LevelTrack3,"RAJE");
	strcpy (NOM_STANDARD->soundexWord,"G620");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"GARAJE SOTANO");
	strcpy (NOM_STANDARD->nomenclature,"GS");
	strcpy (NOM_STANDARD->LevelTrack1,"NULL");
	strcpy (NOM_STANDARD->LevelTrack2,"NULL");
	strcpy (NOM_STANDARD->LevelTrack3,"NULL");
	strcpy (NOM_STANDARD->soundexWord,"G620");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"LOCAL");
	strcpy (NOM_STANDARD->nomenclature,"LC");
	strcpy (NOM_STANDARD->LevelTrack1,"LOC");
	strcpy (NOM_STANDARD->LevelTrack2,"OCA");
	strcpy (NOM_STANDARD->LevelTrack3,"CAL");
	strcpy (NOM_STANDARD->soundexWord,"L240");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"MEZZANINE");
	strcpy (NOM_STANDARD->nomenclature,"MN");
	strcpy (NOM_STANDARD->LevelTrack1,"MEZ");
	strcpy (NOM_STANDARD->LevelTrack2,"ZANI");
	strcpy (NOM_STANDARD->LevelTrack3,"NINE");
	strcpy (NOM_STANDARD->soundexWord,"M255");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"OFICINA");
	strcpy (NOM_STANDARD->nomenclature,"OF");
	strcpy (NOM_STANDARD->LevelTrack1,"OFI");
	strcpy (NOM_STANDARD->LevelTrack2,"ICIN");
	strcpy (NOM_STANDARD->LevelTrack3,"CINA");
	strcpy (NOM_STANDARD->soundexWord,"O125");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"PENTHOUSE");
	strcpy (NOM_STANDARD->nomenclature,"PH");
	strcpy (NOM_STANDARD->LevelTrack1,"PEN");
	strcpy (NOM_STANDARD->LevelTrack2,"NTHO");
	strcpy (NOM_STANDARD->LevelTrack3,"OUSE");
	strcpy (NOM_STANDARD->soundexWord,"P532");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"SALON");
	strcpy (NOM_STANDARD->nomenclature,"SA");
	strcpy (NOM_STANDARD->LevelTrack1,"SAL");
	strcpy (NOM_STANDARD->LevelTrack2,"ALO");
	strcpy (NOM_STANDARD->LevelTrack3,"ON");
	strcpy (NOM_STANDARD->soundexWord,"S450");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"SEMISOTANO");
	strcpy (NOM_STANDARD->nomenclature,"SS");
	strcpy (NOM_STANDARD->LevelTrack1,"SEMI");
	strcpy (NOM_STANDARD->LevelTrack2,"SOTA");
	strcpy (NOM_STANDARD->LevelTrack3,"TANO");
	strcpy (NOM_STANDARD->soundexWord,"S523");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"SOTANO");
	strcpy (NOM_STANDARD->nomenclature,"ST");
	strcpy (NOM_STANDARD->LevelTrack1,"SOT");
	strcpy (NOM_STANDARD->LevelTrack2,"OTA");
	strcpy (NOM_STANDARD->LevelTrack3,"ANO");
	strcpy (NOM_STANDARD->soundexWord,"S350");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"SUITE");
	strcpy (NOM_STANDARD->nomenclature,"SU");
	strcpy (NOM_STANDARD->LevelTrack1,"SUI");
	strcpy (NOM_STANDARD->LevelTrack2,"UIT");
	strcpy (NOM_STANDARD->LevelTrack3,"ITE");
	strcpy (NOM_STANDARD->soundexWord,"S300");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"TERRAZA");
	strcpy (NOM_STANDARD->nomenclature,"TZ");
	strcpy (NOM_STANDARD->LevelTrack1,"TER");
	strcpy (NOM_STANDARD->LevelTrack2,"RRAZ");
	strcpy (NOM_STANDARD->LevelTrack3,"RAZA");
	strcpy (NOM_STANDARD->soundexWord,"T620");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"BODEGA");
	strcpy (NOM_STANDARD->nomenclature,"BG");
	strcpy (NOM_STANDARD->LevelTrack1,"BOD");
	strcpy (NOM_STANDARD->LevelTrack2,"DEG");
	strcpy (NOM_STANDARD->LevelTrack3,"EGA");
	strcpy (NOM_STANDARD->soundexWord,"B320");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"PARQUEADERO");
	strcpy (NOM_STANDARD->nomenclature,"PQD");
	strcpy (NOM_STANDARD->LevelTrack1,"PARQ");
	strcpy (NOM_STANDARD->LevelTrack2,"UEAD");
	strcpy (NOM_STANDARD->LevelTrack3,"DERO");
	strcpy (NOM_STANDARD->soundexWord,"P623");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"APARTAMENTO");
	strcpy (NOM_STANDARD->nomenclature,"AP");
	strcpy (NOM_STANDARD->LevelTrack1,"APAR");
	strcpy (NOM_STANDARD->LevelTrack2,"TAM");
	strcpy (NOM_STANDARD->LevelTrack3,"ENTO");
	strcpy (NOM_STANDARD->soundexWord,"A163");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"CASA");
	strcpy (NOM_STANDARD->nomenclature,"CS");
	strcpy (NOM_STANDARD->LevelTrack1,"CAS");
	strcpy (NOM_STANDARD->LevelTrack2,"AS");
	strcpy (NOM_STANDARD->LevelTrack3,"ASA");
	strcpy (NOM_STANDARD->soundexWord,"C200");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"LOTE");
	strcpy (NOM_STANDARD->nomenclature,"LT");
	strcpy (NOM_STANDARD->LevelTrack1,"LOT");
	strcpy (NOM_STANDARD->LevelTrack2,"OTE");
	strcpy (NOM_STANDARD->LevelTrack3,"TE");
	strcpy (NOM_STANDARD->soundexWord,"L300");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"PREDIO");
	strcpy (NOM_STANDARD->nomenclature,"PD");
	strcpy (NOM_STANDARD->LevelTrack1,"PRE");
	strcpy (NOM_STANDARD->LevelTrack2,"EDI");
	strcpy (NOM_STANDARD->LevelTrack3,"DIO");
	strcpy (NOM_STANDARD->soundexWord,"P630");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"PUESTO");
	strcpy (NOM_STANDARD->nomenclature,"PU");
	strcpy (NOM_STANDARD->LevelTrack1,"PUE");
	strcpy (NOM_STANDARD->LevelTrack2,"ES");
	strcpy (NOM_STANDARD->LevelTrack3,"STO");
	strcpy (NOM_STANDARD->soundexWord,"P230");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"ADMINISTRACION");
	strcpy (NOM_STANDARD->nomenclature,"AD");
	strcpy (NOM_STANDARD->LevelTrack1,"ADMI");
	strcpy (NOM_STANDARD->LevelTrack2,"NIS");
	strcpy (NOM_STANDARD->LevelTrack3,"TRAC");
	strcpy (NOM_STANDARD->soundexWord,"A355");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"ENTRADA");
	strcpy (NOM_STANDARD->nomenclature,"EN");
	strcpy (NOM_STANDARD->LevelTrack1,"ENT");
	strcpy (NOM_STANDARD->LevelTrack2,"NTRA");
	strcpy (NOM_STANDARD->LevelTrack3,"ADA");
	strcpy (NOM_STANDARD->soundexWord,"E536");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"ESQUINA");
	strcpy (NOM_STANDARD->nomenclature,"ESQ");
	strcpy (NOM_STANDARD->LevelTrack1,"ESQU");
	strcpy (NOM_STANDARD->LevelTrack2,"QUIN");
	strcpy (NOM_STANDARD->LevelTrack3,"INA");
	strcpy (NOM_STANDARD->soundexWord,"E250");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"ALCALDIA");
	strcpy (NOM_STANDARD->nomenclature,"ALC");
	strcpy (NOM_STANDARD->LevelTrack1,"ALCA");
	strcpy (NOM_STANDARD->LevelTrack2,"ALD");
	strcpy (NOM_STANDARD->LevelTrack3,"DIA");
	strcpy (NOM_STANDARD->soundexWord,"A424");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"BASE A�REA");
	strcpy (NOM_STANDARD->nomenclature,"BA");
	strcpy (NOM_STANDARD->LevelTrack1,"NULL");
	strcpy (NOM_STANDARD->LevelTrack2,"NULL");
	strcpy (NOM_STANDARD->LevelTrack3,"NULL");
	strcpy (NOM_STANDARD->soundexWord,"B200");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"COMPLEJO");
	strcpy (NOM_STANDARD->nomenclature,"CPO");
	strcpy (NOM_STANDARD->LevelTrack1,"COM");
	strcpy (NOM_STANDARD->LevelTrack2,"MPL");
	strcpy (NOM_STANDARD->LevelTrack3,"EJO");
	strcpy (NOM_STANDARD->soundexWord,"C514");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"GRADA");
	strcpy (NOM_STANDARD->nomenclature,"GR");
	strcpy (NOM_STANDARD->LevelTrack1,"GRA");
	strcpy (NOM_STANDARD->LevelTrack2,"RAD");
	strcpy (NOM_STANDARD->LevelTrack3,"ADA");
	strcpy (NOM_STANDARD->soundexWord,"G630");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"INFERIOR");
	strcpy (NOM_STANDARD->nomenclature,"IF");
	strcpy (NOM_STANDARD->LevelTrack1,"INF");
	strcpy (NOM_STANDARD->LevelTrack2,"FERI");
	strcpy (NOM_STANDARD->LevelTrack3,"RIOR");
	strcpy (NOM_STANDARD->soundexWord,"I516");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"KILOMETRO");
	strcpy (NOM_STANDARD->nomenclature,"KM");
	strcpy (NOM_STANDARD->LevelTrack1,"KILO");
	strcpy (NOM_STANDARD->LevelTrack2,"OME");
	strcpy (NOM_STANDARD->LevelTrack3,"ETRO");
	strcpy (NOM_STANDARD->soundexWord,"K453");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"AEROPUERTO");
	strcpy (NOM_STANDARD->nomenclature,"AER");
	strcpy (NOM_STANDARD->LevelTrack1,"AERO");
	strcpy (NOM_STANDARD->LevelTrack2,"PUER");
	strcpy (NOM_STANDARD->LevelTrack3,"ERTO");
	strcpy (NOM_STANDARD->soundexWord,"A616");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"AUTOPISTA");
	strcpy (NOM_STANDARD->nomenclature,"AU");
	strcpy (NOM_STANDARD->LevelTrack1,"AUT");
	strcpy (NOM_STANDARD->LevelTrack2,"TOP");
	strcpy (NOM_STANDARD->LevelTrack3,"ISTA");
	strcpy (NOM_STANDARD->soundexWord,"A312");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"AVENIDA");
	strcpy (NOM_STANDARD->nomenclature,"AV");
	strcpy (NOM_STANDARD->LevelTrack1,"AVE");
	strcpy (NOM_STANDARD->LevelTrack2,"NID");
	strcpy (NOM_STANDARD->LevelTrack3,"DA");
	strcpy (NOM_STANDARD->soundexWord,"A153");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"BULEVAR");
	strcpy (NOM_STANDARD->nomenclature,"BLV");
	strcpy (NOM_STANDARD->LevelTrack1,"BUL");
	strcpy (NOM_STANDARD->LevelTrack2,"LEV");
	strcpy (NOM_STANDARD->LevelTrack3,"VAR");
	strcpy (NOM_STANDARD->soundexWord,"B416");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"CIRCULAR");
	strcpy (NOM_STANDARD->nomenclature,"CIR");
	strcpy (NOM_STANDARD->LevelTrack1,"CIRC");
	strcpy (NOM_STANDARD->LevelTrack2,"RCUL");
	strcpy (NOM_STANDARD->LevelTrack3,"LAR");
	strcpy (NOM_STANDARD->soundexWord,"C624");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"CARRETERA");
	strcpy (NOM_STANDARD->nomenclature,"CT");
	strcpy (NOM_STANDARD->LevelTrack1,"CARR");
	strcpy (NOM_STANDARD->LevelTrack2,"RRET");
	strcpy (NOM_STANDARD->LevelTrack3,"TERA");
	strcpy (NOM_STANDARD->soundexWord,"C636");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"CALLE");
	strcpy (NOM_STANDARD->nomenclature,"CL");
	strcpy (NOM_STANDARD->LevelTrack1,"CAL");
	strcpy (NOM_STANDARD->LevelTrack2,"LLE");
	strcpy (NOM_STANDARD->LevelTrack3,"LL");
	strcpy (NOM_STANDARD->soundexWord,"C400");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"CALLEJON");
	strcpy (NOM_STANDARD->nomenclature,"CLJ");
	strcpy (NOM_STANDARD->LevelTrack1,"CALLE");
	strcpy (NOM_STANDARD->LevelTrack2,"LJO");
	strcpy (NOM_STANDARD->LevelTrack3,"JON");
	strcpy (NOM_STANDARD->soundexWord,"C425");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"CIRCUNVALAR");
	strcpy (NOM_STANDARD->nomenclature,"CV");
	strcpy (NOM_STANDARD->LevelTrack1,"CIRC");
	strcpy (NOM_STANDARD->LevelTrack2,"CUN");
	strcpy (NOM_STANDARD->LevelTrack3,"VALA");
	strcpy (NOM_STANDARD->soundexWord,"C625");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"DIAGONAL");
	strcpy (NOM_STANDARD->nomenclature,"DG");
	strcpy (NOM_STANDARD->LevelTrack1,"IAG");
	strcpy (NOM_STANDARD->LevelTrack2,"AGO");
	strcpy (NOM_STANDARD->LevelTrack3,"ONAL");
	strcpy (NOM_STANDARD->soundexWord,"D254");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"ROUND POINT");
	strcpy (NOM_STANDARD->nomenclature,"RP");
	strcpy (NOM_STANDARD->LevelTrack1,"ROU");
	strcpy (NOM_STANDARD->LevelTrack2,"UND");
	strcpy (NOM_STANDARD->LevelTrack3,"POI");
	strcpy (NOM_STANDARD->soundexWord,"R530");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"TRONCAL");
	strcpy (NOM_STANDARD->nomenclature,"TC");
	strcpy (NOM_STANDARD->LevelTrack1,"TRO");
	strcpy (NOM_STANDARD->LevelTrack2,"ONC");
	strcpy (NOM_STANDARD->LevelTrack3,"NCAL");
	strcpy (NOM_STANDARD->soundexWord,"T652");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"VIA");
	strcpy (NOM_STANDARD->nomenclature,"VIA");
	strcpy (NOM_STANDARD->LevelTrack1,"VI");
	strcpy (NOM_STANDARD->LevelTrack2,"IA");
	strcpy (NOM_STANDARD->LevelTrack3,"NULL");
	strcpy (NOM_STANDARD->soundexWord,"V000");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"VARIANTE");
	strcpy (NOM_STANDARD->nomenclature,"VTE");
	strcpy (NOM_STANDARD->LevelTrack1,"VAR");
	strcpy (NOM_STANDARD->LevelTrack2,"RIA");
	strcpy (NOM_STANDARD->LevelTrack3,"ANT");
	strcpy (NOM_STANDARD->soundexWord,"V653");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"CARRERA");
	strcpy (NOM_STANDARD->nomenclature,"KR");
	strcpy (NOM_STANDARD->LevelTrack1,"CAR");
	strcpy (NOM_STANDARD->LevelTrack2,"RRE");
	strcpy (NOM_STANDARD->LevelTrack3,"ERA");
	strcpy (NOM_STANDARD->soundexWord,"C660");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"VEREDA");
	strcpy (NOM_STANDARD->nomenclature,"VEDA");
	strcpy (NOM_STANDARD->LevelTrack1,"VER");
	strcpy (NOM_STANDARD->LevelTrack2,"ERE");
	strcpy (NOM_STANDARD->LevelTrack3,"EDA");
	strcpy (NOM_STANDARD->soundexWord,"V630");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"PUENTE");
	strcpy (NOM_STANDARD->nomenclature,"PN");
	strcpy (NOM_STANDARD->LevelTrack1,"PU");
	strcpy (NOM_STANDARD->LevelTrack2,"ENT");
	strcpy (NOM_STANDARD->LevelTrack3,"NTE");
	strcpy (NOM_STANDARD->soundexWord,"P530");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"FINCA");
	strcpy (NOM_STANDARD->nomenclature,"FI");
	strcpy (NOM_STANDARD->LevelTrack1,"FIN");
	strcpy (NOM_STANDARD->LevelTrack2,"INC");
	strcpy (NOM_STANDARD->LevelTrack3,"NCA");
	strcpy (NOM_STANDARD->soundexWord,"F520");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"HACIENDA");
	strcpy (NOM_STANDARD->nomenclature,"HC");
	strcpy (NOM_STANDARD->LevelTrack1,"HAC");
	strcpy (NOM_STANDARD->LevelTrack2,"CIEND");
	strcpy (NOM_STANDARD->LevelTrack3,"ENDA");
	strcpy (NOM_STANDARD->soundexWord,"H253");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"QUEBRADA");
	strcpy (NOM_STANDARD->nomenclature,"QDA");
	strcpy (NOM_STANDARD->LevelTrack1,"QUE");
	strcpy (NOM_STANDARD->LevelTrack2,"BRA");
	strcpy (NOM_STANDARD->LevelTrack3,"ADA");
	strcpy (NOM_STANDARD->soundexWord,"Q163");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"CABECERA MUNICIPAL");
	strcpy (NOM_STANDARD->nomenclature,"CM");
	strcpy (NOM_STANDARD->LevelTrack1,"CAB");
	strcpy (NOM_STANDARD->LevelTrack2,"ECE");
	strcpy (NOM_STANDARD->LevelTrack3,"ERA");
	strcpy (NOM_STANDARD->soundexWord,"C126");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"PASEO");
	strcpy (NOM_STANDARD->nomenclature,"PS");
	strcpy (NOM_STANDARD->LevelTrack1,"PAS");
	strcpy (NOM_STANDARD->LevelTrack2,"ASE");
	strcpy (NOM_STANDARD->LevelTrack3,"SEO");
	strcpy (NOM_STANDARD->soundexWord,"P200");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"PASAJE");
	strcpy (NOM_STANDARD->nomenclature,"PSJ");
	strcpy (NOM_STANDARD->LevelTrack1,"PAS");
	strcpy (NOM_STANDARD->LevelTrack2,"SAJ");
	strcpy (NOM_STANDARD->LevelTrack3,"AJE");
	strcpy (NOM_STANDARD->soundexWord,"P220");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"MUNICIPIO");
	strcpy (NOM_STANDARD->nomenclature,"MUN");
	strcpy (NOM_STANDARD->LevelTrack1,"MUN");
	strcpy (NOM_STANDARD->LevelTrack2,"NICI");
	strcpy (NOM_STANDARD->LevelTrack3,"IPIO");
	strcpy (NOM_STANDARD->soundexWord,"M521");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"PEATONAL");
	strcpy (NOM_STANDARD->nomenclature,"PT");
	strcpy (NOM_STANDARD->LevelTrack1,"PEA");
	strcpy (NOM_STANDARD->LevelTrack2,"TON");
	strcpy (NOM_STANDARD->LevelTrack3,"ONAL");
	strcpy (NOM_STANDARD->soundexWord,"P354");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"CORREGIMIENTO");
	strcpy (NOM_STANDARD->nomenclature,"CO");
	strcpy (NOM_STANDARD->LevelTrack1,"COR");
	strcpy (NOM_STANDARD->LevelTrack2,"REG");
	strcpy (NOM_STANDARD->LevelTrack3,"ENTO");
	strcpy (NOM_STANDARD->soundexWord,"C625");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"TRANSVERSAL");
	strcpy (NOM_STANDARD->nomenclature,"TV");
	strcpy (NOM_STANDARD->LevelTrack1,"TRAN");
	strcpy (NOM_STANDARD->LevelTrack2,"NSVE");
	strcpy (NOM_STANDARD->LevelTrack3,"RSAL");
	strcpy (NOM_STANDARD->soundexWord,"T652");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"PARCELA");
	strcpy (NOM_STANDARD->nomenclature,"PA");
	strcpy (NOM_STANDARD->LevelTrack1,"PARC");
	strcpy (NOM_STANDARD->LevelTrack2,"RCEL");
	strcpy (NOM_STANDARD->LevelTrack3,"CELA");
	strcpy (NOM_STANDARD->soundexWord,"P624");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"CENTRO");
	strcpy (NOM_STANDARD->nomenclature,"CEN");
	strcpy (NOM_STANDARD->LevelTrack1,"CENT");
	strcpy (NOM_STANDARD->LevelTrack2,"NTR");
	strcpy (NOM_STANDARD->LevelTrack3,"TRO");
	strcpy (NOM_STANDARD->soundexWord,"C536");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"CASERIO");
	strcpy (NOM_STANDARD->nomenclature,"CAS");
	strcpy (NOM_STANDARD->LevelTrack1,"CASE");
	strcpy (NOM_STANDARD->LevelTrack2,"SER");
	strcpy (NOM_STANDARD->LevelTrack3,"RIO");
	strcpy (NOM_STANDARD->soundexWord,"C260");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"CAMINO");
	strcpy (NOM_STANDARD->nomenclature,"CNO");
	strcpy (NOM_STANDARD->LevelTrack1,"CAM");
	strcpy (NOM_STANDARD->LevelTrack2,"MIN");
	strcpy (NOM_STANDARD->LevelTrack3,"INO");
	strcpy (NOM_STANDARD->soundexWord,"C550");
	StandardEnd->next=NOM_STANDARD;
	StandardEnd=NOM_STANDARD;

	NOM_STANDARD = (s_nomStandard*)malloc(sizeof(s_nomStandard));
	strcpy (NOM_STANDARD->word,"INSPECCION DE POLICIA");
	strcpy (NOM_STANDARD->nomenclature,"IP");
	strcpy (NOM_STANDARD->LevelTrack1,"INSP");
	strcpy (NOM_STANDARD->LevelTrack2,"ECCI");
	strcpy (NOM_STANDARD->LevelTrack3,"CION");
	strcpy (NOM_STANDARD->soundexWord,"I521");
	NOM_STANDARD->next = NULL;
	StandardEnd->next=NOM_STANDARD;
 	 	
 	NOM_STANDARD = NOM_STANDARD_START;
	
}    
