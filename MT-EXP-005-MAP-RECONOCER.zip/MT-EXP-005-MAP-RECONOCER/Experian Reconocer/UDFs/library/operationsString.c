#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <regex.h>
#include <ctype.h>
#include "operationsString.h"

//Funciones
// Reemplaza caracteres
char *replace_str(char *str, char *orig, char *rep, int recursive)
{
	static char buffer[500];
	char *p;     
	
	// Valida recursive, si igual a 5 retorna, sino incrementa
	
	if(recursive >= 5 || !(p = strstr(str, orig)))  // Is 'orig' even in 'str'?
		return str;

	recursive++;
	
	strncpy(buffer, str, p-str); // Copy characters from 'str' start to 'orig' st$
	
	char aux[strlen(p+strlen(orig))+1]; 

	strcpy(aux, p+strlen(orig));

	sprintf(buffer+(p-str), "%s%s", rep, aux);

        return replace_str(buffer, orig, rep,recursive);
}

//Substring, devuelve el string que cumple con la expresion
void regexp (char *string, char *patrn, int *begin, int *end, char *out)
{     
        int i, w=0, len;                  
        regex_t rgT;
        regmatch_t match;
        regcomp(&rgT,patrn,REG_EXTENDED);
        
        sprintf (out, "");
        if ((regexec(&rgT,string,1,&match,0)) == 0) {
                *begin = (int)match.rm_so;
                *end = (int)match.rm_eo;
                len = *end-*begin;
                for (i=*begin; i<*end; i++) {
                        out[w] = string[i];
                        w++; }
                out[w]=0;
        }
        regfree(&rgT);
}

// Adiciona un string a otro string apartir de una posicion
void add_str_str (char *str, char *nStr, int pos, char *out)
{
	char *buffer = 	NULL;
	buffer=malloc(strlen(str)+strlen(nStr)+1);
	int i, j, k=0;
	
	for (i=0;i<strlen(str);i++) {
		buffer[k]=str[i];
		k++;
		if (pos == i) {
			for (j=0;j<strlen(nStr);j++) {
				buffer[k]=nStr[j];
				k++;
			}
		}
	}
	buffer[k]='\0';
	sprintf (out, buffer);
	free(buffer);
}

// Valida si una expresion regular se cumple en un string
// Retorna 1 si cumple, 0 sino
int valExpRegStr (char *str, char *expR)
{
	regex_t rgT;
	regmatch_t rgMT;
	int out=0;
	
	if (regcomp(&rgT,expR,REG_EXTENDED) != 0) {
		regfree(&rgT);
		return out;
	}
	
	if ((regexec(&rgT,str,1,&rgMT,0)) == 0) 
		out = 1;
	
	regfree(&rgT);
	
	return out;
}

//Devuelve el substrig de acuerdo a los parametro start y end
char *subStr (char* input, int start, int end)
{
	char newString[MAX_SIZE_STRING]="", *r;
		
	int input_len = strlen (input);
	
	if (start + end > input_len)
		return 0;
	
	//strncpy (newString, input + start, end);
	strcpy(newString, "HOLA");
	r = newString;
	return r;
}

// Devuelve valor indicado por vec_idx de una cadena (str_vec) separada por vec_delimit
void ListGetValByIdx (
		char *str_vec
		,char *vec_delimit
		,int vec_idx
		,char *result
         )
{
	short found=0;
	int idx=0;
	char *out;
	out=result;


	for (idx=0; *str_vec != '\0'; *str_vec++) 
	{
		if ( *str_vec == *vec_delimit )
		{
			idx++;
			if ( idx == vec_idx )
			{
				found=1;
				*out=0;
				break;
			}
			out=result;
		} else {
			*out++ = *str_vec ;
		}
	}

	//to handle the last column without ,
	if ( idx == (vec_idx -1 )  )
	{
		*out=0;
		found=1;
	}

	// if first idx then it gets entire input
	if ( ( vec_idx != 1 ) && (found == 0))
	{
		*result = 0;
		return;
	}
	// if empty string
	if ( *result == 0 )
	{
		*result = 0;
	}
}
