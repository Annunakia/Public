#ifndef OPERATIONSSTRING_H
#define OPERATIONSSTRING_H 1
/*
 * ################################################################################
 * 
 * Objetivo:	  Biblioteca para operaciones con string como reemplazar caracteres.
 * Fecha:	  2016/11/16
 * Realizado por: Luis E Ramirez (Capgemini)
 * Parametros:	  N/A
 * Proyecto:	  Experian - Nuevo Reconocer 3
 * Script:	  operationsString.h
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha		Objetivo			Realizado por
 * 
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */
#define MAX_SIZE_ARR 50
#define MAX_SIZE_STRING 500
#define MAX_SIZE_WORK 100

 //Estructuras
typedef struct replChrs {
		char host[MAX_SIZE_ARR];
		char cd[MAX_SIZE_ARR];
	} s_replChrs;

//Cabeceras funciones
// Reemplaza caracteres
char *replace_str(char *str, char *orig, char *rep, int recursive);

//Substring, devuelve el string que cumple con la expresion
void regexp (char *string, char *patrn, int *begin, int *end, char *out);

//Agrega string a otro string
void add_str_str (char *str, char *nStr, int pos, char *out);

// Valida si una expresion regular se cumple en un string
// Retorna 1 si cumple, 0 sino
int valExpRegStr (char *str, char *expR);

//Devuelve el substrig de acuerdo a los parametro start y end
char *subStr (char* input, int start, int end);

// Devuelve valor indicado por vec_idx de una cadena (str_vec) separada por vec_delimit
void ListGetValByIdx (
		char *str_vec
		,char *vec_delimit
		,int vec_idx
		,char *result
         );

#endif /* OPERATIONSSTRING_H */
