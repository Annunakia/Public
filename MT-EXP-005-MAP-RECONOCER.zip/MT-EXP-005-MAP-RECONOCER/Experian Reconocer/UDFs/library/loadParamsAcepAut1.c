#include "loadParamsAcepAut.h"
#include "operationsString.h"
#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
/*
 * ################################################################################
 * 
 * Objetivo:	  Script que contiene las funciones para realizar operaciones con NOM_STANDARD
 * Fecha:	  2017/01/17
 * Realizado por: Luis E Ramirez (Capgemini)
 * Parametros:	  N/A
 * Proyecto:	  Experian - Nuevo Reconocer 3
 * Script:	  loadParamsAcepAut1.c
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha		Objetivo			Realizado por
 * 
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */
 
//Funciones
//
int validateRuleToNomenclature (struct s_nomStandard *Nomenclature, char *word, char *soundex)
{
	int ind_soundexFull, ind_soundexNumerical, ind_wordInNomenclature
		,ind_nomenclatureInWord, ind_track1, ind_track2
		,ind_track3,distanceLevenshtein, b, e, tot=0, id=0;
	INTEGER cost = 1, outDist=0, *outDist1 = NULL, dist = 0;
	char soundex1[5], soundex2[5], sqlstate[6], *r;
	VARCHAR_LATIN *str1, *str2;
	
	strcpy(soundex1, "");
	strcpy(soundex2, "");
	
	outDist1 = (INTEGER *) malloc(sizeof(INTEGER)); 
	
	while (RULES != NULL)
	{
		ind_soundexFull = 0;
		ind_soundexNumerical = 0;
		ind_wordInNomenclature = 0;
		ind_nomenclatureInWord = 0;
		ind_track1 = 0;
		ind_track2 = 0;
		ind_track3 = 0;
		distanceLevenshtein = 0;
		
		if (RULES->soundexFull == 'Y')
		{
			if (strcmp(Nomenclature->soundexWord, soundex) == 0)
				ind_soundexFull=10;
		}
		
		if (RULES->soundexNumerical == 'Y')
		{            
			r = Nomenclature->soundexWord;
			strncpy (soundex1, r+1,3);
			r = soundex;
			strncpy (soundex2, r+1,3);
			
			if (strcmp(soundex1, soundex2) == 0)
				ind_soundexNumerical=100;
			
		}
		
		if (RULES->wordInNomenclature == 'Y')
		{            
			if (strstr(Nomenclature->word, word) != NULL)
				ind_wordInNomenclature=1000;
		}
		
		if (RULES->nomenclatureInWord == 'Y')
		{            
			if (strstr(word, Nomenclature->word) != NULL)
				ind_nomenclatureInWord = 10000;
		}
		
		if (RULES->track1 == 'Y')
		{            
			if (strstr(word, Nomenclature->LevelTrack1) != NULL)
				ind_track1 = 100000;
		}
		
		if (RULES->track2 == 'Y')
		{
			if (strstr(word, Nomenclature->LevelTrack2) != NULL)
				ind_track2 = 1000000;
		}
		
		if (RULES->track3 == 'Y')
		{
			if (strstr(word, Nomenclature->LevelTrack3) != NULL)
				ind_track3 = 10000000;
		}
		
		if (RULES->distanceLevenshtein != 0)
		{
			
			if (RULES->distanceLevenshtein == 3)
				dist = (INTEGER) strlen(word)/3;
			else dist = (INTEGER) RULES->distanceLevenshtein;
			
			str1 = (VARCHAR_LATIN *)Nomenclature->word;
			str2 = (VARCHAR_LATIN *) word;
			
			editdistance_u(str1, 
					str2, 
					&cost, 
					&cost, 
					&cost, 
					&cost, 
					outDist1, 
					sqlstate);
			
			//outDist = *outDist1;
			//outDist = 3;
			
			if (*outDist1 <= dist)
				distanceLevenshtein = RULES->distanceLevenshtein;
			
			//free(outDist1);
		}
		
		tot = ind_soundexFull + ind_soundexNumerical + ind_wordInNomenclature +
			ind_nomenclatureInWord + ind_track1 + ind_track2 + ind_track3 +
			distanceLevenshtein;
		
		if (tot == RULES->validationValue)
		{
			id = RULES->idRule;
			RULES = RULES_START;
			free(outDist1);
			return id;
		}
		
		RULES = RULES->next;
	}
	
	RULES = RULES_START;
	free(outDist1);
			
	return 0;
}

//
void identNomenclature (char *str, char *word, char *soundex)
{
	int retu = 0;
	strcpy(str, "");
	
	//strcpy(str, "PRUEBA"); return;
	
	//Valida si la palabra existe
	while (NOM_STANDARD != NULL)
	{
		if (strcmp(NOM_STANDARD->word, word) == 0)
		 {
			strcpy(str, NOM_STANDARD->nomenclature);
			break;
		}
		
		NOM_STANDARD = NOM_STANDARD->next;
	}
	NOM_STANDARD=NOM_STANDARD_START;
	
	// Sino, aplica las reglas
	while (NOM_STANDARD != NULL && strcmp(str, "") == 0)
	{
		retu = validateRuleToNomenclature(NOM_STANDARD, word, soundex);
		
		if (retu != 0 )
		{
			strcpy(str, NOM_STANDARD->nomenclature);
			break;
		}
		
		NOM_STANDARD = NOM_STANDARD->next;
	}
	
	NOM_STANDARD=NOM_STANDARD_START;
}

// Libera la memoria
//Libera la  memoria de la colas de tipo s_nomStandard
void freeNOM_STANDARD ()
{
	if (NOM_STANDARD != NULL)
	{
		struct s_nomStandard *NOM_STANDARD_NEXT = NULL;
		NOM_STANDARD_NEXT = NOM_STANDARD;
		
		while (NOM_STANDARD_NEXT != NULL)
		{
			NOM_STANDARD = NOM_STANDARD_NEXT;
			NOM_STANDARD_NEXT = NOM_STANDARD_NEXT->next;
			
			if (NOM_STANDARD != NULL)
				free(NOM_STANDARD);
		}
	}
}

//Libera la  memoria de la colas de tipo s_ruleMeaning
void freeRULES ()
{
	if (RULES != NULL)
	{
		struct s_ruleMeaning *RULES_NEXT = NULL;
		RULES_NEXT = RULES;
		
		while (RULES_NEXT != NULL)
		{
			RULES = RULES_NEXT;
			RULES_NEXT = RULES_NEXT->next;
			
			if (RULES != NULL)
				free(RULES);
		}
	}
}

/*
* La siguiente funciones descargads de internet,
*/
/**********************************************************************/
/*                                                                    */
/*  Copyright (c) 2003 by NCR Corporation.                            */
/*                                                                    */
/*  All Rights Reserved.                                              */
/*                                                                    */
/*  NCR CONFIDENTIAL AND TRADE SECRET                                 */
/*                                                                    */
/*  Function Name:  editdistance_u.c                                  */
/*                                                                    */
/*  Function Purpose:                                                 */
/*  editdistance is a measure of the similarity between               */
/*  two strings.  The editdistance function returns the               */
/*  minimum numbers of edit operations; insertions, deletions,        */
/*  substitutions and transpositions required to transform            */
/*  string1 into string2. The optional arguments specified            */
/*  the relative cost of an insert / delete / substitute / transpose. */
/*  A low number of deletions, insertions, substitutions or           */
/*  transpositions implies a high similarity.                         */
/*                                                                    */
/*  The editdistance_u scalar UDF consists of 2 overloading           */
/*  functions, one with 2 parameters and one with 6 parameters.       */
/*                                                                    */
/**********************************************************************/

/* The Levenshtein distance function returns the minimum number */
/* of edit operations. Refer to header file for more details.   */

void editdistance_u(VARCHAR_LATIN *str1, 
                    VARCHAR_LATIN *str2, 
                    INTEGER *ci, 
                    INTEGER *cd, 
                    INTEGER *cs, 
                    INTEGER *ct, 
                    INTEGER *result, 
                    char sqlstate[6])
{
    unsigned int s1len, s2len, x, y, lastdiag, olddiag;
    s1len = strlen(str1);
    s2len = strlen(str2);
    unsigned int column[s1len+1];
    for (y = 1; y <= s1len; y++)
        column[y] = y;
    for (x = 1; x <= s2len; x++) {
        column[0] = x;
        for (y = 1, lastdiag = x-1; y <= s1len; y++) {
            olddiag = column[y];
            column[y] = MIN3(column[y] + 1, column[y-1] + 1, lastdiag + (str1[y-1] == str2[x-1] ? 0 : 1));
            lastdiag = olddiag;
        }
    }
   *result = (column[s1len]);
}
