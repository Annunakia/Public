#include "loadParamsAcepAut.h"
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

/*
 * ################################################################################
 * 
 * Objetivo:	  Script que contiene las funciones para inicializar la variable RULES
 * Fecha:	  2017/01/17
 * Realizado por: Luis E Ramirez (Capgemini)
 * Parametros:	  N/A
 * Proyecto:	  Experian - Nuevo Reconocer 3
 * Script:	  loadParamsAcepRules.c
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha		Objetivo			Realizado por
 * 
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */

//Funciones         
// Incializa reglas
void iniRULES ()              
{		
	struct s_ruleMeaning *RulesEnd = NULL;
	
	RULES = (s_ruleMeaning*)malloc(sizeof(s_ruleMeaning));
	RULES->idRule = 1;
	RULES->soundexFull = 'Y';  //10
	RULES->soundexNumerical = 'N';
	RULES->wordInNomenclature = 'Y'; //1000
	RULES->nomenclatureInWord = 'N';
	RULES->track1 = 'Y'; //100000
	RULES->track2 = 'Y'; //1000000
	RULES->track3 = 'Y'; //10.000.000
	RULES->distanceLevenshtein = 3;
	RULES->validationValue = 11101013;
	RulesEnd = RULES_START = RULES; 
	
	RULES = (s_ruleMeaning*)malloc(sizeof(s_ruleMeaning));
	RULES->idRule = 2;
	RULES->soundexFull = 'Y';  // 10
	RULES->soundexNumerical = 'N'; // 
	RULES->wordInNomenclature = 'N'; //
	RULES->nomenclatureInWord = 'Y'; // 10000
	RULES->track1 = 'Y'; // 100000
	RULES->track2 = 'Y'; // 1000000
	RULES->track3 = 'Y'; // 10000000
	RULES->distanceLevenshtein = 3;
	RULES->validationValue = 11110013;
	RulesEnd->next=RULES;
 	RulesEnd=RULES;

 	RULES = (s_ruleMeaning*)malloc(sizeof(s_ruleMeaning));
	RULES->idRule = 3;
	RULES->soundexFull = 'Y';  // 10
	RULES->soundexNumerical = 'N'; // 
	RULES->wordInNomenclature = 'N'; // 
	RULES->nomenclatureInWord = 'Y'; // 10.000
	RULES->track1 = 'Y'; // 100.000
	RULES->track2 = 'N'; // 
	RULES->track3 = 'Y'; // 10.000.000
	RULES->distanceLevenshtein = 3;
	RULES->validationValue = 10110016;
	RulesEnd->next=RULES;
 	RulesEnd=RULES;
 	
 	RULES = (s_ruleMeaning*)malloc(sizeof(s_ruleMeaning));
	RULES->idRule = 4;
	RULES->soundexFull = 'Y';  // 10
	RULES->soundexNumerical = 'N'; // 
	RULES->wordInNomenclature = 'N'; // 
	RULES->nomenclatureInWord = 'N'; // 
	RULES->track1 = 'Y'; // 100.000
	RULES->track2 = 'Y'; // 1.000.000
	RULES->track3 = 'Y'; // 10.000.000
	RULES->distanceLevenshtein = 3;
	RULES->validationValue = 11100013;
	RulesEnd->next=RULES;
 	RulesEnd=RULES;
 	
 	RULES = (s_ruleMeaning*)malloc(sizeof(s_ruleMeaning));
	RULES->idRule = 5;
	RULES->soundexFull = 'Y';  // 10
	RULES->soundexNumerical = 'N'; // 
	RULES->wordInNomenclature = 'N'; // 
	RULES->nomenclatureInWord = 'N'; // 
	RULES->track1 = 'Y'; // 100.000
	RULES->track2 = 'Y'; // 1.000.000
	RULES->track3 = 'N'; // 
	RULES->distanceLevenshtein = 3;
	RULES->validationValue = 1100013;
	RulesEnd->next=RULES;
 	RulesEnd=RULES;
 	
 	RULES = (s_ruleMeaning*)malloc(sizeof(s_ruleMeaning));
	RULES->idRule = 6;
	RULES->soundexFull = 'Y';  // 10
	RULES->soundexNumerical = 'N'; // 
	RULES->wordInNomenclature = 'N'; // 
	RULES->nomenclatureInWord = 'N'; // 
	RULES->track1 = 'N'; // 
	RULES->track2 = 'Y'; // 1.000.000
	RULES->track3 = 'Y'; // 10.000.000
	RULES->distanceLevenshtein = 3;
	RULES->validationValue = 11000013;
	RulesEnd->next=RULES;
 	RulesEnd=RULES;
 	
 	RULES = (s_ruleMeaning*)malloc(sizeof(s_ruleMeaning));
	RULES->idRule = 7;
	RULES->soundexFull = 'Y';  // 10
	RULES->soundexNumerical = 'N'; // 
	RULES->wordInNomenclature = 'N'; // 
	RULES->nomenclatureInWord = 'N'; // 
	RULES->track1 = 'Y'; // 100.000
	RULES->track2 = 'N'; // 
	RULES->track3 = 'Y'; // 10.000.000
	RULES->distanceLevenshtein = 3;
	RULES->validationValue = 10100013;
	RulesEnd->next=RULES;
 	RulesEnd=RULES;
 	
 	RULES = (s_ruleMeaning*)malloc(sizeof(s_ruleMeaning));
	RULES->idRule = 8;
	RULES->soundexFull = 'N';  // 
	RULES->soundexNumerical = 'Y'; // 100
	RULES->wordInNomenclature = 'N'; // 
	RULES->nomenclatureInWord = 'N'; // 
	RULES->track1 = 'Y'; // 100.000
	RULES->track2 = 'Y'; // 1.000.000
	RULES->track3 = 'Y'; // 10.000.000
	RULES->distanceLevenshtein = 3;
	RULES->validationValue = 11100103;
	RulesEnd->next=RULES;
 	RulesEnd=RULES;
 	
 	RULES = (s_ruleMeaning*)malloc(sizeof(s_ruleMeaning));
	RULES->idRule = 9;
	RULES->soundexFull = 'N';  // 
	RULES->soundexNumerical = 'Y'; // 100
	RULES->wordInNomenclature = 'N'; // 
	RULES->nomenclatureInWord = 'N'; // 
	RULES->track1 = 'N'; // 
	RULES->track2 = 'Y'; // 1.000.000
	RULES->track3 = 'Y'; // 10.000.000
	RULES->distanceLevenshtein = 1;
	RULES->validationValue = 11000101;
	RulesEnd->next=RULES;
 	RulesEnd=RULES;
 	
 	RULES = (s_ruleMeaning*)malloc(sizeof(s_ruleMeaning));
	RULES->idRule = 10;
	RULES->soundexFull = 'Y';  // 10
	RULES->soundexNumerical = 'N'; 
	RULES->wordInNomenclature = 'N';
	RULES->nomenclatureInWord = 'N';
	RULES->track1 = 'Y'; // 100.000
	RULES->track2 = 'N';
	RULES->track3 = 'N';
	RULES->distanceLevenshtein = 1;
	RULES->validationValue = 100011;
	RulesEnd->next=RULES;
 	RulesEnd=RULES;
 	
 	RULES = (s_ruleMeaning*)malloc(sizeof(s_ruleMeaning));
	RULES->idRule = 11;
	RULES->soundexFull = 'Y';  // 10
	RULES->soundexNumerical = 'N';
	RULES->wordInNomenclature = 'N';
	RULES->nomenclatureInWord = 'N';
	RULES->track1 = 'N';
	RULES->track2 = 'Y'; // 1.000.000
	RULES->track3 = 'N';
	RULES->distanceLevenshtein = 1;
	RULES->validationValue = 1000011;
	RulesEnd->next=RULES;
 	RulesEnd=RULES;
 	
 	RULES = (s_ruleMeaning*)malloc(sizeof(s_ruleMeaning));
	RULES->idRule = 12;
	RULES->soundexFull = 'Y';  // 10
	RULES->soundexNumerical = 'N';
	RULES->wordInNomenclature = 'N';
	RULES->nomenclatureInWord = 'N';
	RULES->track1 = 'N';
	RULES->track2 = 'N';
	RULES->track3 = 'Y'; // 10.000.000
	RULES->distanceLevenshtein = 1;
	RULES->validationValue = 10000011;
	RulesEnd->next=RULES;
 	RulesEnd=RULES;
 	
 	RULES = (s_ruleMeaning*)malloc(sizeof(s_ruleMeaning));
	RULES->idRule = 13;
	RULES->soundexFull = 'Y';  // 10
	RULES->soundexNumerical = 'N';
	RULES->wordInNomenclature = 'N';
	RULES->nomenclatureInWord = 'N';
	RULES->track1 = 'N';
	RULES->track2 = 'N';
	RULES->track3 = 'N';
	RULES->distanceLevenshtein = 1;
	RULES->validationValue = 11;
	RulesEnd->next=RULES;
 	RulesEnd=RULES;
 	
 	RULES = (s_ruleMeaning*)malloc(sizeof(s_ruleMeaning));
	RULES->idRule = 14;
	RULES->soundexFull = 'N';  //
	RULES->soundexNumerical = 'N';
	RULES->wordInNomenclature = 'N';
	RULES->nomenclatureInWord = 'N';
	RULES->track1 = 'Y'; // 100.000
	RULES->track2 = 'Y'; // 1.000.000
	RULES->track3 = 'Y'; // 10.000.000
	RULES->distanceLevenshtein = 2;
	RULES->validationValue = 11100002;
	RulesEnd->next=RULES;
 	RulesEnd=RULES;
 	
 	RULES = (s_ruleMeaning*)malloc(sizeof(s_ruleMeaning));
	RULES->idRule = 15;
	RULES->soundexFull = 'N';  //
	RULES->soundexNumerical = 'N';
	RULES->wordInNomenclature = 'Y'; // 1.000
	RULES->nomenclatureInWord = 'N';
	RULES->track1 = 'N';
	RULES->track2 = 'Y'; // 1.000.000
	RULES->track3 = 'Y'; // 10.000.000
	RULES->distanceLevenshtein = 1;
	RULES->validationValue = 11001001;
	RulesEnd->next=RULES;
 	RulesEnd=RULES;
 	
 	RULES = (s_ruleMeaning*)malloc(sizeof(s_ruleMeaning));
	RULES->idRule = 16;
	RULES->soundexFull = 'N';  //[1]
	RULES->soundexNumerical = 'N';
	RULES->wordInNomenclature = 'Y'; // 1.000
	RULES->nomenclatureInWord = 'N';
	RULES->track1 = 'Y'; // 100.000
	RULES->track2 = 'Y'; // 1.000.000
	RULES->track3 = 'N';
	RULES->distanceLevenshtein = 1;
	RULES->validationValue = 1101001;
	RulesEnd->next=RULES;
 	RulesEnd=RULES;
 	
 	RULES = (s_ruleMeaning*)malloc(sizeof(s_ruleMeaning));
	RULES->idRule = 17;
	RULES->soundexFull = 'N';  //[1]
	RULES->soundexNumerical = 'N';
	RULES->wordInNomenclature = 'N';
	RULES->nomenclatureInWord = 'N';
	RULES->track1 = 'N';
	RULES->track2 = 'Y'; // 1.000.000
	RULES->track3 = 'Y'; // 10.000.000
	RULES->distanceLevenshtein = 1;
	RULES->validationValue = 11000001;
	RulesEnd->next=RULES;
 	RulesEnd=RULES;
 	
 	RULES = (s_ruleMeaning*)malloc(sizeof(s_ruleMeaning));
	RULES->idRule = 18;
	RULES->soundexFull = 'N';  //[1]
	RULES->soundexNumerical = 'N';
	RULES->wordInNomenclature = 'N';
	RULES->nomenclatureInWord = 'N';
	RULES->track1 = 'Y'; // 100.000
	RULES->track2 = 'Y'; // 1.000.000
	RULES->track3 = 'N';
	RULES->distanceLevenshtein = 1;
	RULES->validationValue = 1100001;
	RulesEnd->next=RULES;
 	RulesEnd=RULES;
 	
 	RULES = (s_ruleMeaning*)malloc(sizeof(s_ruleMeaning));
	RULES->idRule = 19;
	RULES->soundexFull = 'N';  //[1]
	RULES->soundexNumerical = 'N';
	RULES->wordInNomenclature = 'N';
	RULES->nomenclatureInWord = 'N';
	RULES->track1 = 'Y'; // 100.000
	RULES->track2 = 'N'; 
	RULES->track3 = 'Y'; // 10.000.000
	RULES->distanceLevenshtein = 1;
	RULES->validationValue = 10100001;
	RulesEnd->next=RULES;
 	RulesEnd=RULES;
 	
 	RULES = (s_ruleMeaning*)malloc(sizeof(s_ruleMeaning));
 	RULES->idRule = 20;
	RULES->soundexFull = 'N';  //
	RULES->soundexNumerical = 'N'; // 
	RULES->wordInNomenclature = 'N'; //
	RULES->nomenclatureInWord = 'Y'; // 10000
	RULES->track1 = 'Y'; // 100000
	RULES->track2 = 'Y'; // 1000000
	RULES->track3 = 'Y'; // 10000000
	RULES->distanceLevenshtein = 2;
	RULES->validationValue = 11110002;
	RULES->next = NULL;
	RulesEnd->next=RULES;
	
 	
 	RULES = RULES_START;
	
}    
