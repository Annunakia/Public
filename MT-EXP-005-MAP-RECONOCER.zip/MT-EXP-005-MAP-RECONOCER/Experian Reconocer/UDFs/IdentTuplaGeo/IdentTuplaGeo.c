/*
 * ################################################################################
 * 
 * Objetivo:	  Funcion IdentTuplaGeo que recibe un complemento de ubicacion GEO
 *		  y devuelve un Str con todas las tuplas separadas por |
 * Fecha:	  2017/03/28
 * Realizado por: Luis E Ramirez (Capgemini)
 * Parametros:	  Str, retorna VARCHAR(512)
 * Proyecto:	  Experian - Reconocer
 * Script:	  IdentTuplaGeo.c
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha	Objetivo				Realizado por
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */
 
#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include <stdio.h>
#include <string.h>                   
#include <ctype.h>
#include <stdlib.h>
#include "operationsString.h"
#include "AddressNormalization.h"

// Funcion referenciada por Teradata
void IdentTuplaGeo (
		VARCHAR_LATIN *inCompl,
		VARCHAR_LATIN *outStr,
		SQL_TEXT extname[129],
		SQL_TEXT specific_name[129],
		SQL_TEXT error_message[257])
{
	
	strcpy(outStr, "");
	
	
	if (strcmp(inCompl, "") != 0)
	{
		// Definicion de variables para manejo de cadenas
		
		int loop, space = 0;
		char word[MAX_SIZE_STRING];
		char a[MAX_SIZE_WORK], b[MAX_SIZE_WORK], c[MAX_SIZE_WORK];
		
		// Estructura para la cola de palabras
		struct wordString *wordAct, *wordEnd=NULL, *wordStart=NULL;
		
		// Lista de particulas
		struct s_session *listSession=NULL
			, *listSessionStart=NULL
			, *listSessionEnd=NULL ;
			
		int id = 1; // Contador para la inicializacion de particulas
		
		strcpy(word, "");
		
		// Loop para recorrer el string de entrda e ir separandolo por palabras
		// almacenandolo en una cola
		for (loop = 0; loop<=strlen(inCompl); loop++)
		{
		
			if ((inCompl[loop] == ' ' || strlen(inCompl) == loop) && space == 1) 
			{
				// En una cola va agregando palabra por palabra
				wordAct =(wordString*)malloc(sizeof(wordString));
				
				strcpy(wordAct->word, word);
				wordAct->next = NULL;
				
				if ( wordEnd == NULL)
					wordEnd=wordStart=wordAct;
				else {
					wordEnd->next = wordAct;
					wordEnd=wordAct;
				}
				space = 0;
				strcpy(word, "");
			} else {
				if (inCompl[loop] != ' ') {
					sprintf (word, "%s%c",word, inCompl[loop]);
					space = 1;
				}
			}
			
		}
		
		// Apunta la cola al inicio de la misma, para recorrerla y realizar la clasificacion
		wordAct = wordStart;
		strcpy(a,"");
		
		//Inicia la Lista de sessiones
		while (id <= 97)
		{
			listSession=FNC_malloc (sizeof(s_session));
			//listSession=(struct s_session*) malloc(sizeof *listSession);
			
			initSessions (id, listSession);
			listSession->next=NULL;
				
			if (id == 1)
				listSessionStart = listSession;
			else
				listSessionEnd->next=listSession;
				
			listSessionEnd = listSession;
			id++;		
		}
		
		// Recorre la cola palabra por palabra para la clasificacion, 
		// con a se maneja el valor actual, con b, el siguiente y con
		// con c el siguiente del siguiente.
		
		while (wordAct) 
		{
			strcpy(a , wordAct->word);
			strcpy(b,"");
			strcpy(c,"");
						
			if (wordAct->next != NULL)
				strcpy( b, wordAct->next->word);
			
			if (strcmp(b, "") != 0 && wordAct->next->next != NULL)
				strcpy(c, wordAct->next->next->word);
			
			if (validateSession(a, listSessionStart) == 1)
			{
				if (strcmp(outStr, "") == 0)
					sprintf (outStr, "%s", a);
				else sprintf (outStr, "%s/%s", outStr, a);
			} else sprintf (outStr, "%s %s", outStr, a);
 
			wordAct = wordAct->next;
		}
		
		//Libera memoria
		
		wordAct = wordStart;
		while (wordAct != NULL)
		{
			wordStart = wordAct;
			wordAct = wordAct->next;
			free(wordStart);
		}
		wordAct = wordStart = wordEnd = NULL;
		
		while (listSessionStart)
		{
			listSession = listSessionStart;
			listSessionStart = listSessionStart->next;
			
			FNC_free(listSession);
		}	
	}	
	
}
