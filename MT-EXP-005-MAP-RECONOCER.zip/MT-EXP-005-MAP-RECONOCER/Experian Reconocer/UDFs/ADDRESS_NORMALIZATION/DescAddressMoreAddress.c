/*
 * ################################################################################
 * 
 * Objetivo:	  Funcion DescAddressMoreAddress para descomponer la direccion recibida en
 *		  inStr, para retornar por outStr todas las posibles direcciones separadas
 *		  por /
 * Fecha:	  207/01/31
 * Realizado por: Luis E Ramirez (Capgemini)
 * Parametros:	  inStr, inCity, inMaxRoad, outStr
 * Proyecto:	  Experian - Nuevo Reconocer 3
 * Script:	  DescAddressMoreAddress.c
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha	Objetivo				Realizado por
 * 2018/02/28	Se quita la logica de tipificacion, el 
 *		nuevo valor viene por un parametro	Cagemini
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */
 
#include "operationsString.h"
#include "AddressNormalization.h"
#include <stdio.h>
#include <string.h>                   
#include <regex.h>
#include <ctype.h>
#include <stdlib.h>

// Funcion referenciada por Teradata
void DescAddressMoreAddress (
		VARCHAR_LATIN *inStr,
		VARCHAR_LATIN *inCity,
		INTEGER *inMaxRoad,
		VARCHAR_LATIN *inDane,
		VARCHAR_LATIN *outStr,
		SQL_TEXT extname[129],
		SQL_TEXT specific_name[129],
		SQL_TEXT error_message[257])
{	
	//type = 2, descomposicion en mas direcciones
	Address_Normalization(inStr, inCity, outStr, *inMaxRoad, 2, inDane, "VIA");
	
}
