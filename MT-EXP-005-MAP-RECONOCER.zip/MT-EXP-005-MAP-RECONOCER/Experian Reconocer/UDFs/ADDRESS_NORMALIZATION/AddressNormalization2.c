#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <regex.h>
#include <ctype.h>
#include "AddressNormalization.h"
#include "operationsString.h"


//Agrega palabras a la cola.
void initSessions (int id, struct s_session *listSession)
{
	
	switch (id)
	{
		case 1:
			sprintf (listSession->session, "AER");
			sprintf (listSession->description, "TIPOVIAPPAL");
			listSession->orden_km = 26;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 1;
			sprintf (listSession->type_via, "G");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
			
		/*case 2:
			sprintf (listSession->session, "AU");
			sprintf (listSession->description, "CARRETERA");
			listSession->orden_km = 2;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 23;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");			
			break;*/
		case 2:
			sprintf (listSession->session, "AU");
			sprintf (listSession->description, "TIPOVIAPPAL");
			listSession->orden_km = 26;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 1;
			sprintf (listSession->type_via, "G");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");			
			break;
		
		case 3:
			sprintf (listSession->session, "AV");
			sprintf (listSession->description, "TIPOVIAPPAL");
			listSession->orden_km = 26;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 1;
			sprintf (listSession->type_via, "G");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 4:
			sprintf (listSession->session, "BLV");
			sprintf (listSession->description, "TIPOVIAPPAL");
			listSession->orden_km = 26;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 1;
			sprintf (listSession->type_via, "G");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 			
		case 5:
			sprintf (listSession->session, "CIR");
			sprintf (listSession->description, "TIPOVIAPPAL");
			listSession->orden_km = 26;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 1;
			sprintf (listSession->type_via, "G");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 6:
			sprintf (listSession->session, "CL");
			sprintf (listSession->description, "TIPOVIAPPAL");
			listSession->orden_km = 26;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 1;
			sprintf (listSession->type_via, "G");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N"); 			
			break;
 	
		case 7:
			sprintf (listSession->session, "CLJ");
			sprintf (listSession->description, "TIPOVIAPPAL");
			listSession->orden_km = 26;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 1;
			sprintf (listSession->type_via, "G");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 8:
			sprintf (listSession->session, "CV");
			sprintf (listSession->description, "TIPOVIAPPAL");
			listSession->orden_km = 26;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 1;
			sprintf (listSession->type_via, "G");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 9:
			sprintf (listSession->session, "DG");
			sprintf (listSession->description, "TIPOVIAPPAL");
			listSession->orden_km = 26;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 1;
			sprintf (listSession->type_via, "G");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 10:
			sprintf (listSession->session, "KR");
			sprintf (listSession->description, "TIPOVIAPPAL");
			listSession->orden_km = 26;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 1;
			sprintf (listSession->type_via, "G");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 11:
			sprintf (listSession->session, "PN");
			sprintf (listSession->description, "TIPOVIAPPAL");
			listSession->orden_km = 26;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 1;
			sprintf (listSession->type_via, "G");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 12:
			sprintf (listSession->session, "PS");
			sprintf (listSession->description, "TIPOVIAPPAL");
			listSession->orden_km = 26;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 1;
			sprintf (listSession->type_via, "G");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 13:
			sprintf (listSession->session, "PSJ");
			sprintf (listSession->description, "TIPOVIAPPAL");
			listSession->orden_km = 26;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 1;
			sprintf (listSession->type_via, "G");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 14:
			sprintf (listSession->session, "PT");
			sprintf (listSession->description, "TIPOVIAPPAL");
			listSession->orden_km = 26;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 1;
			sprintf (listSession->type_via, "G");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 15:
			sprintf (listSession->session, "TV");
			sprintf (listSession->description, "TIPOVIAPPAL");
			listSession->orden_km = 26;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 1;
			sprintf (listSession->type_via, "G");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
			
		case 16:
			sprintf (listSession->session, "VIA");
			sprintf (listSession->description, "TIPOVIAPPAL");
			listSession->orden_km = 26;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 1;
			sprintf (listSession->type_via, "G");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
			
		/*case 16:
			sprintf (listSession->session, "VIA");
			sprintf (listSession->description, "CARRETERA");
			listSession->orden_km = 2;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 23;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;*/
			
		case 17:
			sprintf (listSession->session, "CT");
			sprintf (listSession->description, "CARRETERA");
			listSession->orden_km = 2;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 23;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
			
		case 18:
			sprintf (listSession->session, "RP");
			sprintf (listSession->description, "CARRETERA");
			listSession->orden_km = 2;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 23;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 19:
			sprintf (listSession->session, "TC");
			sprintf (listSession->description, "CARRETERA");
			listSession->orden_km = 2;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 23;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
	
		case 20:
			sprintf (listSession->session, "VTE");
			sprintf (listSession->description, "CARRETERA");
			listSession->orden_km = 2;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 23;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 21:
			sprintf (listSession->session, "AVIAL");
			sprintf (listSession->description, "TIPOVIAPPAL");
			listSession->orden_km = 26;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 1;
			sprintf (listSession->type_via, "G");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 22:
			sprintf (listSession->session, "KM");
			sprintf (listSession->description, "KILOMETRO");
			listSession->orden_km = 1;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 0;
			sprintf (listSession->type_via, "N");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
			
		case 23:
			sprintf (listSession->session, "RP");
			sprintf (listSession->description, "CARRETERA");
			listSession->orden_km = 2;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 23;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 24:
			sprintf (listSession->session, "BTLL");
			sprintf (listSession->description, "CARRETERA");
			listSession->orden_km = 2;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 23;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 25:
			sprintf (listSession->session, "VEDA");
			sprintf (listSession->description, "VEREDA");
			listSession->orden_km = 3;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 24;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 26:
			sprintf (listSession->session, "FI");
			sprintf (listSession->description, "FINCA");
			listSession->orden_km = 4;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 26;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 27:
			sprintf (listSession->session, "HC");
			sprintf (listSession->description, "FINCA");
			listSession->orden_km = 4;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 26;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 28:
			sprintf (listSession->session, "QDA");
			sprintf (listSession->description, "FINCA");
			listSession->orden_km = 4;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 26;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 29:
			sprintf (listSession->session, "CM");
			sprintf (listSession->description, "MUNICIPIO");
			listSession->orden_km = 5;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 27;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 30:
			sprintf (listSession->session, "MUN");
			sprintf (listSession->description, "MUNICIPIO");
			listSession->orden_km = 5;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 27;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 31:
			sprintf (listSession->session, "CO");
			sprintf (listSession->description, "CORREGIMIENTO");
			listSession->orden_km = 6;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 28;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 32:
			sprintf (listSession->session, "PA");
			sprintf (listSession->description, "PARCELA");
			listSession->orden_km = 7;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 29;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 33:
			sprintf (listSession->session, "CAS");
			sprintf (listSession->description, "CASERIO");
			listSession->orden_km = 8;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 30;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 34:
			sprintf (listSession->session, "CNO");
			sprintf (listSession->description, "CAMINO");
			listSession->orden_km = 9;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 31;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 35:
			sprintf (listSession->session, "IP");
			sprintf (listSession->description, "INSPECCION");
			listSession->orden_km = 10;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 32;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 0;
			sprintf (listSession->type_mz, "N");
			break;
 	
		case 36:
			sprintf (listSession->session, "BR");
			sprintf (listSession->description, "BARRIO");
			listSession->orden_km = 15;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 8;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 1;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 37:
			sprintf (listSession->session, "CD");
			sprintf (listSession->description, "BARRIO");
			listSession->orden_km = 15;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 8;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 1;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case  38:
			sprintf (listSession->session, "CDM");
			sprintf (listSession->description, "BARRIO");
			listSession->orden_km = 15;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 8;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 1;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 39:
			sprintf (listSession->session, "CONJ");
			sprintf (listSession->description, "BARRIO");
			listSession->orden_km = 15;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 8;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 1;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 40:
			sprintf (listSession->session, "UN");
			sprintf (listSession->description, "BARRIO");
			listSession->orden_km = 15;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 8;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 1;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 41:
			sprintf (listSession->session, "URB");
			sprintf (listSession->description, "BARRIO");
			listSession->orden_km = 15;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 8;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 1;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 42:
			sprintf (listSession->session, "CC");
			sprintf (listSession->description, "BARRIO");
			listSession->orden_km = 15;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 8;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 1;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 43:
			sprintf (listSession->session, "SEC");
			sprintf (listSession->description, "SECTOR");
			listSession->orden_km = 11;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 9;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 2;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 44:
			sprintf (listSession->session, "ED");
			sprintf (listSession->description, "SECTOR");
			listSession->orden_km = 11;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 9;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 2;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 45:
			sprintf (listSession->session, "MLT");
			sprintf (listSession->description, "SECTOR");
			listSession->orden_km = 11;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 9;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 2;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 46:
			sprintf (listSession->session, "POR");
			sprintf (listSession->description, "SECTOR");
			listSession->orden_km = 11;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 9;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 2;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 47:
			sprintf (listSession->session, "PQ");
			sprintf (listSession->description, "SECTOR");
			listSession->orden_km = 11;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 9;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 2;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 48:
			sprintf (listSession->session, "SM");
			sprintf (listSession->description, "SECTOR");
			listSession->orden_km = 11;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 9;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 2;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 49:
			sprintf (listSession->session, "ZN");
			sprintf (listSession->description, "SECTOR");
			listSession->orden_km = 11;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 9;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 2;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 50:
			sprintf (listSession->session, "MZ");
			sprintf (listSession->description, "MANZANA");
			listSession->orden_km = 17;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 11;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 4;
			sprintf (listSession->type_mz, "G");
			break;
			
		case 51:
			sprintf (listSession->session, "SM");
			sprintf (listSession->description, "MANZANA");
			listSession->orden_km = 17;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 11;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 4;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 52:
			sprintf (listSession->session, "ET");
			sprintf (listSession->description, "ETAPA");
			listSession->orden_km = 16;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 10;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 3;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 53:
			sprintf (listSession->session, "AG");
			sprintf (listSession->description, "ETAPA");
			listSession->orden_km = 17;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 11;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 4;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 54:
			sprintf (listSession->session, "CU");
			sprintf (listSession->description, "ETAPA");
			listSession->orden_km = 17;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 11;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 4;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 55:
			sprintf (listSession->session, "BL");
			sprintf (listSession->description, "BLOQUE");
			listSession->orden_km = 18;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 12;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 5;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 56:
			sprintf (listSession->session, "MD");
			sprintf (listSession->description, "BLOQUE");
			listSession->orden_km = 18;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 12;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 5;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 57:
			sprintf (listSession->session, "NCO");
			sprintf (listSession->description, "BLOQUE");
			listSession->orden_km = 18;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 12;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 5;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 58:
			sprintf (listSession->session, "TO");
			sprintf (listSession->description, "BLOQUE");
			listSession->orden_km = 18;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 12;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 5;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 59:
			sprintf (listSession->session, "EX");
			sprintf (listSession->description, "BLOQUE");
			listSession->orden_km = 18;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 12;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 5;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 60:
			sprintf (listSession->session, "IN");
			sprintf (listSession->description, "BLOQUE");
			listSession->orden_km = 18;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 12;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 5;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 61:
			sprintf (listSession->session, "PI");
			sprintf (listSession->description, "PISO");
			listSession->orden_km = 19;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 13;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 6;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 62:
			sprintf (listSession->session, "NI");
			sprintf (listSession->description, "PISO");
			listSession->orden_km = 19;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 13;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 6;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 63:
			sprintf (listSession->session, "PL");
			sprintf (listSession->description, "PISO");
			listSession->orden_km = 19;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 13;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 6;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 64:
			sprintf (listSession->session, "AP");
			sprintf (listSession->description, "APARTAMENTO");
			listSession->orden_km = 12;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 14;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 7;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 65:
			sprintf (listSession->session, "AL");
			sprintf (listSession->description, "APARTAMENTO");
			listSession->orden_km = 12;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 14;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 7;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 66:
			sprintf (listSession->session, "CN");
			sprintf (listSession->description, "APARTAMENTO");
			listSession->orden_km = 12;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 14;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 7;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 67:
			sprintf (listSession->session, "DP");
			sprintf (listSession->description, "APARTAMENTO");
			listSession->orden_km = 12;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 14;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 7;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 68:
			sprintf (listSession->session, "GJ");
			sprintf (listSession->description, "APARTAMENTO");
			listSession->orden_km = 12;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 14;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 7;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 69:
			sprintf (listSession->session, "GS");
			sprintf (listSession->description, "APARTAMENTO");
			listSession->orden_km = 12;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 14;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 7;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 70:
			sprintf (listSession->session, "LC");
			sprintf (listSession->description, "APARTAMENTO");
			listSession->orden_km = 12;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 14;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 7;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 71:
			sprintf (listSession->session, "LM");
			sprintf (listSession->description, "APARTAMENTO");
			listSession->orden_km = 12;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 14;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 7;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 72:
			sprintf (listSession->session, "MN");
			sprintf (listSession->description, "APARTAMENTO");
			listSession->orden_km = 12;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 14;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 7;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 73:
			sprintf (listSession->session, "OF");
			sprintf (listSession->description, "APARTAMENTO");
			listSession->orden_km = 12;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 14;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 7;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 74:
			sprintf (listSession->session, "PH");
			sprintf (listSession->description, "APARTAMENTO");
			listSession->orden_km = 12;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 14;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 7;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 75:
			sprintf (listSession->session, "SA");
			sprintf (listSession->description, "APARTAMENTO");
			listSession->orden_km = 12;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 14;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 7;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 76:
			sprintf (listSession->session, "SS");
			sprintf (listSession->description, "APARTAMENTO");
			listSession->orden_km = 12;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 14;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 7;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 77:
			sprintf (listSession->session, "ST");
			sprintf (listSession->description, "APARTAMENTO");
			listSession->orden_km = 12;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 14;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 7;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 78:
			sprintf (listSession->session, "SU");
			sprintf (listSession->description, "APARTAMENTO");
			listSession->orden_km = 12;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 14;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 7;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 79:
			sprintf (listSession->session, "TZ");
			sprintf (listSession->description, "APARTAMENTO");
			listSession->orden_km = 12;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 14;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 7;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 80:
			sprintf (listSession->session, "CS");
			sprintf (listSession->description, "APARTAMENTO");
			listSession->orden_km = 12;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 14;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 7;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 81:
			sprintf (listSession->session, "BG");
			sprintf (listSession->description, "APARTAMENTO");
			listSession->orden_km = 12;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 14;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 7;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 82:
			sprintf (listSession->session, "LT");
			sprintf (listSession->description, "LOTE");
			listSession->orden_km = 20;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 15;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 8;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 83:
			sprintf (listSession->session, "PD");
			sprintf (listSession->description, "PREDIO");
			listSession->orden_km = 21;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 16;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 9;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 84:
			sprintf (listSession->session, "PU");
			sprintf (listSession->description, "PREDIO");
			listSession->orden_km = 21;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 16;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 9;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 85:
			sprintf (listSession->session, "AD");
			sprintf (listSession->description, "ENTRADA");
			listSession->orden_km = 22;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 17;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 10;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 86:
			sprintf (listSession->session, "EN");
			sprintf (listSession->description, "ENTRADA");
			listSession->orden_km = 22;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 17;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 10;
			sprintf (listSession->type_mz, "G");
			break;
			
		case 87:
			sprintf (listSession->session, "ESQ");
			sprintf (listSession->description, "ENTRADA");
			listSession->orden_km = 22;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 17;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 10;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 88:
			sprintf (listSession->session, "ALC");
			sprintf (listSession->description, "ALCALDIA");
			listSession->orden_km = 23;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 25;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 11;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 89:
			sprintf (listSession->session, "BA");
			sprintf (listSession->description, "ALCALDIA");
			listSession->orden_km = 23;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 25;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 11;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 90:
			sprintf (listSession->session, "CPO");
			sprintf (listSession->description, "ALCALDIA");
			listSession->orden_km = 23;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 25;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 11;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 91:
			sprintf (listSession->session, "GR");
			sprintf (listSession->description, "GRADA");
			listSession->orden_km = 24;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 19;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 12;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 92:
			sprintf (listSession->session, "IF");
			sprintf (listSession->description, "INFERIOR");
			listSession->orden_km = 25;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 20;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 13;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 93:
			sprintf (listSession->session, "AGP");
			sprintf (listSession->description, "COMMANZANA");
			listSession->orden_km = 13;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 22;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 15;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 94:
			sprintf (listSession->session, "AGR");
			sprintf (listSession->description, "COMMANZANA");
			listSession->orden_km = 13;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 22;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 15;
			sprintf (listSession->type_mz, "G");
			break;
 	
		case 95:
			sprintf (listSession->session, "PLAN");
			sprintf (listSession->description, "COMMANZANA");
			listSession->orden_km = 13;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 22;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 15;
			sprintf (listSession->type_mz, "G");
			break;
			
		case 96:
			sprintf (listSession->session, "CEN");
			sprintf (listSession->description, "CENTRO");
			listSession->orden_km = 33;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 33;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 16;
			sprintf (listSession->type_mz, "G");
			break;
			
		case 97:
			sprintf (listSession->session, "COMPVIA");
			sprintf (listSession->description, "COMPVIA");
			listSession->orden_km = 14;
			sprintf (listSession->type_km, "G");
			listSession->orden_via = 21;
			sprintf (listSession->type_via, "C");
			listSession->orden_mz = 14;
			sprintf (listSession->type_mz, "G");
			break;
 	
		default:
			sprintf (listSession->session, "FINISHED");
			break;
	}
}

