/*
 * ################################################################################
 * 
 * Objetivo:	  Funcion AddressNormalization1 para descomponer el string de entrada
 * 		  (direccion) en palabras e ir normalizandola y ordenandola de acuerdo
 *		  a las reglas enviadas por Experian
 * Fecha:	  2016/10/14
 * Realizado por: Luis E Ramirez (Capgemini)
 * Parametros:	  inStr, inCity, outStr
 * Proyecto:	  Experian - Reconocer
 * Script:	  AddressNormalization1.c
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha	Objetivo				Realizado por
 * 2016/12/15	Implementacion de manejo de tuplas con	Luis E. Ramirez
 *		el fin de detectar particulas y valores
 *		huerfanos
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */
 
#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include "operationsString.h"
#include "AddressNormalization.h"
#include <stdio.h>
#include <string.h>                   
#include <regex.h>
#include <ctype.h>
#include <stdlib.h>

// Funcion referenciada por Teradata
void AddressNormalization3 (
		VARCHAR_LATIN *inStr,
		VARCHAR_LATIN *inCity,
		INTEGER *inMaxRoad,
		VARCHAR_LATIN *outStr,
		SQL_TEXT extname[129],
		SQL_TEXT specific_name[129],
		SQL_TEXT error_message[257])
{
	// Valida cola Secciones
	if (Direction)
		freeSession();
	
	Session = AuxSession = DirectionStart = Direction = 0;
		
	// Detencion no valida, devuelve la cadena con un &	
	if (valExpRegStr(inStr, "[0-9]|FI|VEDA") == 1)
	{
		
		// Definicion de variables para manejo de cadenas
		
		int loop, space = 0;
		char word[MAX_SIZE_STRING];
		char preWord[2] = "";
		char a[MAX_SIZE_WORK], b[MAX_SIZE_WORK], c[MAX_SIZE_WORK];
		
		TYPEDIRECTION = 0;
		SESIONACTUAL = 0;
		NOMENCLATURA = 0;
		VALOR = 0;
		HUERFANOS = 0;
		HUERFANOV = 0;
		CUADRANTE = 0; 
		COMPVIA = 0;
		PASO = 0;
			
		strcpy(word, "");
		
		TYPEDIRECTION = (char*)malloc(2);
		SESIONACTUAL = (char*)malloc(MAX_SIZE_OF_VAR);
		NOMENCLATURA = (char*)malloc(MAX_SIZE_OF_VAR);
		VALOR = (char*)malloc(MAX_SIZE_OF_VAR);
		HUERFANOS = (char*)malloc(MAX_SIZE_OF_VAR);
		HUERFANOV = (char*)malloc(MAX_SIZE_OF_VAR);
		COMPVIA = (char*)malloc(MAX_SIZE_OF_VAR);
		CUADRANTE = (char*)malloc(6);
		
		PASO = (char*)malloc(MAX_SIZE_OF_VAR);
		strcpy(PASO, "");
		
		strcpy(TYPEDIRECTION, "");
		strcpy(TYPEDIRECTION, "");
		strcpy(NOMENCLATURA, "");
		strcpy(VALOR, "");
		strcpy(HUERFANOS, "");
		strcpy(HUERFANOV, "");
		strcpy(CUADRANTE, "");
		strcpy(COMPVIA, "");
		                    
			
		strcpy(TYPEDIRECTION, "NO");
		
		//Inicia la Lista de sessiones
		if (!listSessionStart)
			initSessions();
		
		// Estructura para la cola de palabras
		struct wordString *wordAct=0, *wordEnd=0, *wordStart=0;
		
		// Loop para recorrer el string de entrda e ir separandolo por palabras
		// almacenandolo en una cola
		for (loop = 0; loop<=strlen(inStr); loop++)
		{
		
			if ((inStr[loop] == ' ' || strlen(inStr) == loop) && space == 1) 
			{
				
				// Identifica el tipo de direccion, fundamental para el 
				// ordenamiento
				if (strcmp(TYPEDIRECTION, "NO") == 0)
					strcpy(TYPEDIRECTION, SessionID(word));
				
				wordAct = insertWord (word);
				if ( !wordEnd)
					wordEnd=wordStart=wordAct;
				else {
					wordEnd->next = wordAct;
					wordEnd=wordAct;
				}
				space = 0;
				strcpy(word, "");
			} else {
				if (inStr[loop] != ' ') {
					preWord[0] = inStr[loop];
					preWord[1] = '\0';
					strcat(word , preWord);
					space = 1;
				}
			}
			
		}
		
		// Apunta la cola al inicio de la misma, para recorrerla y realizar la clasificacion
		wordAct = wordStart;
		strcpy(a,"");
		// Recorre la cola palabra por palabra para la clasificacion, 
		// con a se maneja el valor actual, con b, el siguiente y con
		// con c el siguiente del siguiente.
		while (wordAct) 
		{
			strcpy(a , wordAct->word);
			strcpy(b,"");
			strcpy(c,"");
						
			if (wordAct->next)
				strcpy( b, wordAct->next->word);
			
			if (strcmp(b, "") != 0 && wordAct->next->next)
				strcpy(c, wordAct->next->next->word);
			
			classificationSessions(inCity, a, b, c); 
 
			wordAct = wordAct->next;
		}
		
		//Libera memoria
		freewordString(wordStart);
		
		//Arma la direccion
		//sprintf(outStr, "%s <> %s , %s",toDirectionCola(DirectionStart, CUADRANTE, COMPVIA), PASO, Direction );
		sprintf(outStr, "%s===%s - TIPED:.%s",toDirectionCola(DirectionStart, CUADRANTE, COMPVIA, TYPEDIRECTION, inMaxRoad), PASO, TYPEDIRECTION);
				
		// Limpieza de variables globales
		
		free(TYPEDIRECTION);
		free(SESIONACTUAL);
		free(NOMENCLATURA);
		free(VALOR);
		free(HUERFANOS);
		free(HUERFANOV);
		free(CUADRANTE);
		free(COMPVIA);
		free(PASO);
		
		
		word[0] = '\0';
		preWord[0] = '\0';
		a[0] = '\0';
		b[0] = '\0';
		c[0] = '\0';
		
		//PASO[0] = '\0';

		//free(Session);
		// Libera memoria
		//freeListSession(listSessionStart);
		//freeSession(Direction);
		

	} else {
		strcpy(outStr, inStr);
		strcat(outStr,"&&&&&&");
	}
	
}
