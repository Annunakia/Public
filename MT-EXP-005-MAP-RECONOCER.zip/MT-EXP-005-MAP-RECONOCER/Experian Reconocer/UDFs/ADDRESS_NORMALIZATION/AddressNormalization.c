#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <regex.h>
#include <ctype.h>
#include "operationsString.h"
#include "AddressNormalization.h"

// Agrega valor al valor de la ultima tupla organizada por el parametro  
void addValueSession (char *valor)
{
	
	Direction = DirectionStart;
	
 	if (Direction != NULL)
 	{   		
					
		while (Direction->next != NULL)
		{	
			Direction = Direction->next;
		}
		
		sprintf(Direction->value, "%s %s", Direction->value, valor);
	
	}
	
	return;
}

// Establece la bandera de VALIDA/NO VALIDA para una ubicaci�n
void CbValida (char *dane) 
{
	int countMZ=0, b, e;
	int countKM=0;
	char *cod_dane;
	
	// Inicializa variable
	sprintf (ValAddress, "&NO VALIDA");
	cod_dane = (char*)malloc(100*sizeof(char));
	
	regexp(dane,"[0-9]{3}$",&b,&e, cod_dane);
	
	Direction = DirectionStart;
	// Loop para recorrer la cola de componentes
	while (Direction != NULL) 
	{
		// Validacion tipo via 
		if (strcmp(Direction->sessionName, "TIPOVIAPPAL") == 0
			&& strcmp(Direction->NUMVIAPPAL, "") != 0
			&& strcmp(Direction->NUMVIAGEN, "") != 0
			&& strcmp(Direction->NUMPLACA, "") != 0
			)
		{
			sprintf (ValAddress, "&VALIDA");
			break;
		} else {
			
			// Validacion para tipo manzana
			// es NO VALIDA si countMZ es difernte de 2
			if (strcmp(Direction->session, "BR") == 0)
			{
				countMZ++;
			}
			
			if ((countMZ == 0 || countMZ == 1)
				&& countKM == 0
				&& (strcmp(Direction->sessionName, "MANZANA") == 0
					|| strcmp(Direction->sessionName, "LOTE") == 0
					|| strcmp(Direction->sessionName, "SECTOR") == 0
					|| strcmp(Direction->session, "CONJ") == 0
					|| strcmp(Direction->session, "URB") == 0)
				)
			{
				countMZ++;
			}
			
			// Validaciones para tipo rural
			if (countKM == 0
				&& countMZ == 0
				&& (strcmp(Direction->session, "KM") == 0 
					|| strcmp(Direction->session, "VEDA") == 0
					|| strcmp(Direction->session, "FI") == 0
					|| strcmp(Direction->session, "CS") == 0
					|| strcmp(Direction->session, "HC") == 0
					|| strcmp(Direction->session, "BG") == 0
					|| strcmp(Direction->session, "ZN") == 0)
				)
			{
				countKM++;
			}
		}
		
		Direction = Direction->next;
	}
	
	if (strcmp(ValAddress, "&VALIDA")!=0)
	{
		if (countMZ == 2)
				sprintf (ValAddress, "&VALIDA");
		
		if (countKM == 1)
				sprintf (ValAddress, "&VALIDA");
		
	}
	
	// Libera memoria
	free(cod_dane);
	
}


// arma una cola de palabras para determinar si alguna es una nomenclatura
// Devuelve 1 si lo es y 0 si no lo es
int validateWordNomenclature (char *str, struct s_session *listSessionStart)
{
	int loop, space = 0, validate= 0;
	char word[MAX_SIZE_STRING];
	char preWord[2] = "";
	
	// Estructura para la cola de palabras
	struct wordString *wordAct=NULL, *wordEnd=NULL, *wordStart=NULL;
	
	// Loop para recorrer el string de entrda e ir separandolo por palabras
	// almacenandolo en una cola
	for (loop = 0; loop<=strlen(str); loop++)
	{
	
		if ((str[loop] == ' ' || strlen(str) == loop) && space == 1) 
		{
			
			// En una cola va agregan palabra por palabra
			wordAct =FNC_malloc(sizeof(wordString));
			sprintf(wordAct->word,"%s", word);
			wordAct->next = NULL;
			
			if ( wordEnd == NULL)
				wordEnd=wordStart=wordAct;
			else {
				wordEnd->next = wordAct;
				wordEnd=wordAct;
			}
			space = 0;
			sprintf(word, "");
		} else {
			if (str[loop] != ' ') {
				preWord[0] = str[loop];
				preWord[1] = '\0';
				sprintf(word ,"%s%s", word, preWord);
				space = 1;
			}
		}
		
	}
	
	// Apunta la cola al inicio de la misma, para recorrerla y realizar la validacion
	wordAct = wordStart;
	
	// Recorre la cola palabra por palabra para la identificacion de tipo de ubicacion, 
	// con a se maneja el valor actual
	
	while (wordAct != NULL) 
	{
					
		if (validateSessionType(wordAct->word, "TIPOVIAPPAL", listSessionStart) == 0
				&& validateSession(wordAct->word, listSessionStart) == 1)
			validate = 1;

		wordAct = wordAct->next;
	}
	
		//Libera memoria
	while (wordStart != NULL)
	{
		wordAct = wordStart;
		wordStart = wordStart->next;
		
		FNC_free(wordAct);
	}
	
	return validate;	
}  

// Valida si la palabra es una session o un valor
// retorna 1 si es una session.
int validateSession (char *str, struct s_session *listSessionStart)
{
	struct s_session *listSession=NULL;
	int validate = 0;
	listSession = listSessionStart;
	
	while (listSession != NULL)
	{
		if (strcmp(listSession->session, str) == 0)
			validate = 1;
		
		listSession = listSession->next;
	}
	
	return validate;	
}                                      
                                                   
int validateSessionType (char *str, char *session, struct s_session *listSessionStart) 
{
	struct s_session *listSession=NULL;
	listSession = listSessionStart;
	
	while (listSession != NULL)        
	{               
		if (strcmp(listSession->session, str) == 0 && strcmp(listSession->description, session) == 0)
			return 1;

		listSession = listSession->next;
	}

	return 0;
}

// Devuelve                            
//	KM : Para direcciones tipo kilometro
//	GE : Para direcciones georeferenciales VIA PRINCIPAL
//	MZ : Para direcciones tipo manzana
void SessionID (char *str, char *TYPEDIRECTION, struct s_session *listSessionStart, char *dane, char *inStr, int type)
{
	struct s_session *listSession=NULL;
	
	char expression[500]="";
	char expression2[500]="";
	char *match, *match1;
	int b,e;
	
	match = (char*)malloc(100*sizeof(char));
	match1 = (char*)malloc(100*sizeof(char));
	
	regexp(dane,"[0-9]{3}$",&b,&e, match);
	
	sprintf(TYPEDIRECTION, "NO");
	
	listSession = listSessionStart;
	                                         
	sprintf (expression,"%s [0-9]{1,3} [A-Z� ]{0,7}[0-9]{1,3} [A-Z� ]{0,7}[0-9]{1,3}", str);
	sprintf (expression2,"%s [A-Z� ]{1,100}[0-9]{1,3}[ A-Z�]{0,7}[0-9]{1,3}" , str);
	
	regexp(inStr,expression2,&b,&e, match1);
	
	while (listSession != NULL)
	{
		
		// Primero Tipo Via
		if (strcmp(listSession->session, str) == 0 
			&& strcmp(listSession->description, "TIPOVIAPPAL") == 0
			&& strcmp(match, "000") == 0
			&& (valExpRegStr(inStr, expression) == 1
				|| (valExpRegStr(inStr, expression2) == 1
					/*&& validateWordNomenclature (match1, listSessionStart) == 0*/
					)
				)
			&& (type == 1) 
			)
		{
			sprintf(TYPEDIRECTION, "GE");
			break;
		}
		
		// Segundo Tipo Manzana
		if (strcmp(listSession->session, str) == 0 
			&& (strcmp(listSession->description, "MANZANA") == 0
				|| strcmp(listSession->description, "BARRIO") == 0
				|| strcmp(listSession->description, "SECTOR") == 0
				|| strcmp(listSession->description, "ETAPA") == 0
				|| strcmp(listSession->description, "BLOQUE") == 0
				|| strcmp(listSession->description, "PISO") == 0
				|| strcmp(listSession->description, "APARTAMENTO") == 0
				|| strcmp(listSession->description, "LOTE") == 0
				|| strcmp(listSession->description, "PREDIO") == 0
				|| strcmp(listSession->description, "ENTRADA") == 0
				|| strcmp(listSession->description, "ALCALDIA") == 0
				|| strcmp(listSession->description, "GRADA") == 0
				|| strcmp(listSession->description, "INFERIOR") == 0
				
				)
			&& strcmp(match, "000") == 0
			&& (type == 2)
			)
		{
			sprintf(TYPEDIRECTION, "MZ");
			break;
		}
		
		// Tercero Tipo Rural
		if ((strcmp(str, "KM") == 0 
			|| strcmp(str, "VEDA") == 0
			|| strcmp(str, "FI") == 0
			|| strcmp(str, "CS") == 0
			|| strcmp(str, "HC") == 0
			|| strcmp(str, "BG") == 0
			|| strcmp(str, "ZN") == 0
			)
			&& strcmp(match, "000") != 0
			&& (type == 3)
		)
		{
			sprintf(TYPEDIRECTION, "KM");
			break;
		}
		
		listSession = listSession->next;
	}
	
	free(match);
	free(match1);
}

// Devuelve la cola de sesiones y valores ordenada de acuerdo la orden configurado en 
// s_session
void createSession (char *str, char *TYPEDIRECTION, struct s_session *listSessionStart)
{                                                
	struct s_session *listSession=NULL;
	int exists = 0;
	
	listSession = listSessionStart;
		
	// Recupera los atributos de la session    
 	while (listSession != NULL)
	{
		if (strcmp(listSession->session, str) == 0)
		{
			exists = 1;
			break;
		}
		
		listSession = listSession->next;
	}
	
	if (exists == 0)
	{
		sprintf(Session->session, "");
		return;
	}
	                                 
 	sprintf(Session->session, "%s", str);
 	sprintf(Session->value, "");    
 	sprintf(Session->NUMVIAPPAL, "");
 	sprintf(Session->MODVIAPPAL, "");
 	sprintf(Session->NUMVIAGEN, "");
 	sprintf(Session->NUMPLACA, "");
 	sprintf(Session->MODVIAGEN, "");
 	
	sprintf(Session->sessionName, listSession->description);
	Session->next = NULL;
	
	if (strcmp(TYPEDIRECTION, "KM") == 0)
	{
		Session->weight = listSession->orden_km;
		sprintf(Session->type,"%s", listSession->type_km);
	}
	
	if (strcmp(TYPEDIRECTION, "GE") == 0)
	{
		sprintf(Session->type, "%s", listSession->type_via);
		Session->weight = listSession->orden_via;
	}
	
	if (strcmp(TYPEDIRECTION, "MZ") == 0)
	{
		sprintf(Session->type, "%s", listSession->type_mz);
		Session->weight = listSession->orden_mz;
	}
	
	if (strcmp(Session->type, "") == 0)
	{
		sprintf(Session->type, "N");
		Session->weight = 0;
	}
 	
}

// Agrega la session a la cola en el lugar correspondiente de acuerdo a  
// s_session
void insertSession ()
{
	
	Direction = DirectionStart;
	
 	if (Direction != NULL)
 	{
 		int loop = 0;   
 		
		if (Session->weight < Direction->weight)
		{
			Session->next = Direction;
			DirectionStart = Session;
		} else {
		
			struct s_sessionValue *DirectionPrev = NULL;
			
			while (Direction->next != NULL)
			{
				if (Session->weight >= Direction->weight
						&& Session->weight <= Direction->next->weight )
				{
					loop = 2;
					break;
				}
				
				Direction = Direction->next;
				loop = 1;
			}
			
			if (loop == 2) {
				DirectionPrev = Direction->next;
				Direction->next = Session;
				Session->next = DirectionPrev;	
			} else Direction->next = Session;
		}
		
	} else
		DirectionStart = Session;	
	
	return;
}

// Busca si la session ya existe, devuelve la extructura relacionado con ella
// ind = Name, para hacer la validacion por nombre
// ind = Session para hacer la validacion por seccion
void existsSession (char *str, char *ind)
{
	int valide = 0;
	
	Direction = DirectionStart;
	
	while (Direction != NULL)
	{
		if (strcmp(ind, "Name") == 0 && strcmp(Direction->sessionName, str) == 0)
			break;
		
		if (strcmp(ind, "Session") == 0 && strcmp(Direction->session, str) == 0)
			break;
		
		Direction = Direction->next;
		
	}
	
	Session = Direction;
}

// Devuelver un char[] con toda la direccion armada el string armado.
void toDirectionCola (char *String, int MaxRoad, char *dane)
{
	char StringCmpDir[MAX_SIZE_STRING]="";
	char *r;
	int complement = 0, numviappal, numviagen, assigned, mantipovia=0, indTV=0;
	
	Direction = DirectionStart;
	
	sprintf(String, "");
	sprintf(StringCmpDir, "");
	
	// En la variable StringCmpDir se agrega los campos TIPOVIAPPAL, NUMVIAPPAL, NUMVIAGEN, NUMPLACA
	// se agrega al final a la variable String
	if (strcmp(TYPEDIRECTION, "KM") == 0)
	{
		sprintf(StringCmpDir, "&RURAL&&&&");
	} else 
	{
		if (strcmp(TYPEDIRECTION, "GE") == 0)
		{
			sprintf(StringCmpDir, "&VIA");
		} else
		{
			if (strcmp(TYPEDIRECTION, "MZ") == 0)
			{
				sprintf(StringCmpDir, "&MANZANA");
			} else sprintf(StringCmpDir, "&&&&&");
		}
	}
	
	
	// Recorre las secciones para ir armando las direccion
	while (Direction != NULL) 
	{
		
		if (strcmp(Direction->type, "C") == 0 &&  complement == 0)
		{
			if (strlen(String) > 0)
			{                                                          
				if (String[strlen(String)] == ' ') 
					String[strlen(String)-1]='&';
				else String[strlen(String)]='&';
			} else sprintf (String, "&");
			
			complement = 1;
		} else sprintf (String, "%s ", String);
		
		
		if (strcmp(Direction->session, "COMPVIA") != 0)
			sprintf (String,"%s%s ",String, Direction->session);
		
		if (strcmp(Direction->sessionName, "TIPOVIAPPAL")==0
				&& (mantipovia == 0 || indTV == 0))
		{
			if (strcmp(Direction->value, "") == 0) 
			{
				sprintf (String, "%s%s%s %s%s %s %s",String
							,Direction->NUMVIAPPAL
							,Direction->MODVIAPPAL
							,Direction->NUMVIAGEN
							,Direction->MODVIAGEN
							,Direction->NUMPLACA
							,CUADRANTE);
				
			} else sprintf (String,"%s%s",String,Direction->value);
			
			if (strcmp(TYPEDIRECTION, "KM") != 0
				&& strcmp(Direction->value, "") == 0)
			{
				// Convierte a integer el NUMVIAPPAL y NUMVIAGEN
				r = Direction->NUMVIAPPAL;
				assigned = sscanf(r, "%d", &numviappal);
				
				r = Direction->NUMVIAGEN;
				assigned = sscanf(r, "%d", &numviagen);

				if (strlen(dane) > 2
					&& (
						(numviappal > MaxRoad && valExpRegStr(Direction->NUMVIAPPAL, "^[0-9]") == 1)
						|| (numviagen > MaxRoad && valExpRegStr(Direction->NUMVIAGEN, "^[0-9]") == 1)
					)
				    )
				{
					sprintf(ValAddress, "");
					sprintf(ValAddress, "&X VALIDAR VIAS");
					
					// Se valida Caso 1 y 2 del caso 3 numero incompletos  
					if ((numviappal > MaxRoad
						|| numviagen > MaxRoad)
						&& strlen(Direction->NUMVIAPPAL) > 0
						&& strlen(Direction->NUMVIAGEN) > 0
						&& strlen(Direction->NUMPLACA) > 0
						)
					{
						sprintf(ValAddress, "");
						sprintf(ValAddress, "&NO VALIDA 2");
					}
						
					
				}
			
				if (strcmp(Direction->session, "") != 0)
					sprintf(StringCmpDir, "%s&%s", StringCmpDir,Direction->session);
				else sprintf (StringCmpDir, "%s&", StringCmpDir);
				
				if (strcmp(Direction->NUMVIAPPAL, "") != 0)
					sprintf(StringCmpDir, "%s&%s", StringCmpDir,Direction->NUMVIAPPAL);
				else sprintf (StringCmpDir, "%s&",StringCmpDir);
				
				if (strcmp(Direction->NUMVIAGEN, "") != 0)
					sprintf(StringCmpDir, "%s&%s", StringCmpDir,Direction->NUMVIAGEN);
				else sprintf (StringCmpDir, "%s&", StringCmpDir);
				
				if (strcmp(Direction->NUMPLACA, "") != 0)
					sprintf(StringCmpDir, "%s&%s", StringCmpDir,Direction->NUMPLACA);
				else sprintf (StringCmpDir, "%s&", StringCmpDir);
				
				// Indicador si es tipo via en una ubicacion manaza
				if (strcmp(TYPEDIRECTION, "MZ") == 0)
					mantipovia=1;
				else indTV=1;
			}
					
		} else {
			sprintf (String,"%s%s",String,Direction->value);
		}
				
		Direction = Direction->next;
	}
	
	// Si no tiene complemente, se agrega el separador
	if (complement == 0)
		sprintf (String,"%s&", String);
	
	if ((mantipovia==0 && strcmp(TYPEDIRECTION, "MZ") == 0)
		|| (indTV==0 && strcmp(TYPEDIRECTION, "GE")==0 ))
		sprintf (String,"%s%s&&&&",String, StringCmpDir);
	else
		sprintf (String,"%s%s",String, StringCmpDir);

	
	if (strcmp(ValAddress, "") == 0)
		CbValida (dane); // Llamado a la funcion de validacion de ubicacion
	
	sprintf (String,"%s%s",String, ValAddress);
	
	// Rutina para dejar un solo espacio entre palabra y palabra
	int countNum=0, loop; // Acumula la cantidad de espacios
	char direc[strlen(String)];
	char preWord[2] = "";
	sprintf(direc, "");
		
	for (loop = 0; loop < strlen(String); loop++) 
	{	
		if (String[loop] != ' ' && String[loop] != '\0')
		{
			if (countNum > 0) 
			{
				if (strcmp(direc, "") != 0)
					sprintf(direc , "%s ", direc);
			}
			
			preWord[0] = String[loop];
			preWord[1] = '\0';
			sprintf(direc,"%s%s",direc , preWord);
			
			countNum=0;
		} else countNum++;
	}
	
	sprintf (String, "%s", direc);
		
}

// Para las direcciones cuyo numero principal o numero generadora es mayor al valor del parametro
// Las descompone, retornar las posibles direcciones separadas por &.
void decomAddressIntoMoreAddresses (char *StringDesc, int MaxRoad, char *dane)
{
	char StrTmp[1000]=""
		, StrString[1000]=""
		,StrTmp1[100]="",StrTmp2[100]="",StrTmp3[100]="",StrTmp4[100]=""
		, prevviappal[100]=""
		, prevnumviagen[100]=""
		, prevnumplaca[100]=""
		, *r
		;
		
	int numviappal=0, numviagen=0, NumWords=0, i, ind=0, start, end, conv, assigned;
	
	struct s_sessionValue *TipePP;
	
	sprintf (StringDesc, "");
	sprintf (StrTmp, "");
	sprintf (StrTmp1, "");
	sprintf (StrTmp2, "");
	sprintf (StrTmp3, "");
	sprintf (StrTmp4, "");
	
	sprintf (StrString, "");
	 
	
	//Identifica la seccion TIPOVIAPPAL
	Direction = DirectionStart;
	while (Direction != NULL)
	{
		if (strcmp(Direction->sessionName, "TIPOVIAPPAL")==0)
			break;
		
		Direction = Direction->next;
	}
	
	// si no existe la seccion retorna nulo
	if (Direction == NULL)
		return;
	
	TipePP = Direction;
	
	if (valExpRegStr(TipePP->NUMVIAPPAL, "^[0-9]*$") == 1)
	{
		// Convierte a integer el NUMVIAPPAL
		r = TipePP->NUMVIAPPAL;
		assigned = sscanf(r, "%d", &numviappal);
		
		if (numviappal > MaxRoad)
		{
			NumWords = strlen(TipePP->NUMVIAPPAL);
			ind = 1;
		}
	}
	
	if (valExpRegStr(TipePP->NUMVIAGEN, "^[0-9]*$") == 1)
	{
		// Convierte a integer el NUMVIAGEN
		r = TipePP->NUMVIAGEN;
		assigned = sscanf(r, "%d", &numviagen);
		
		if (numviagen > MaxRoad)
		{
			NumWords = strlen(TipePP->NUMVIAGEN);
			ind = 2;
		}	
	}
	
	sprintf(prevviappal, "%s", TipePP->NUMVIAPPAL);
	sprintf(prevnumviagen, "%s", TipePP->NUMVIAGEN);
	sprintf(prevnumplaca, "%s", TipePP->NUMVIAGEN);
	
	char tmp[100]="";
	
	for (i=1; i<NumWords; i++) 
	{ 
		
		if (ind == 1)
		{
			// Nuevo valor para numero via principal
			start=0;
			end=i;
			
			sprintf(tmp, "");
			strncpy (tmp, prevviappal+start,end);
			tmp[end] = '\0';
			
			sprintf (TipePP->NUMVIAPPAL, "%s", tmp);
			
			r = TipePP->NUMVIAPPAL;
			assigned = sscanf(r, "%d", &conv);
			sprintf (TipePP->NUMVIAPPAL, "%d", conv);

			// Nuevo valor para numero via Generadora
			start=i;
			end=NumWords-i;

			sprintf(tmp, "");
			strncpy (tmp, prevviappal+start,end);
			tmp[end] = '\0';

			sprintf (TipePP->NUMVIAGEN, "%s", tmp);
			
			r = TipePP->NUMVIAGEN;
			assigned = sscanf(r, "%d", &conv);
			
			sprintf (TipePP->NUMVIAGEN, "%d", conv);
			
			// Setea la numero de via generadora como numero de placa
			sprintf (TipePP->NUMPLACA, "%s", prevnumplaca);
			
		} else {
			// Nuevo valor para numero via Generadora
			start=0;
			end=i;
			
			sprintf(tmp, "");
			strncpy (tmp, prevnumviagen+start,end);
			tmp[end] = '\0';
			
			sprintf (TipePP->NUMVIAGEN, "%s", tmp);
			
			r = TipePP->NUMVIAGEN;
			assigned = sscanf(r, "%d", &conv);
			
			sprintf (TipePP->NUMVIAGEN, "%d", conv);
						
			// Nuevo valor para numero via Generadora
			start=i;
			end=NumWords-i;
			
			if (end < 0)
				end=0;
			
			sprintf(tmp, "");
			strncpy (tmp, prevnumviagen+start,end);
			tmp[end] = '\0';
			
			sprintf (TipePP->NUMPLACA, "%s", tmp);
			r = TipePP->NUMPLACA;
			assigned = sscanf(r, "%d", &conv);
			sprintf (TipePP->NUMPLACA, "%d", conv);
		}
		//Arma la salida, agregando una nueva direccion separado por /
		sprintf(StrTmp,"");
		sprintf (StrTmp1, "");
		sprintf (StrTmp3, "");
		sprintf (StrTmp4, "");
		
		toDirectionCola(StrTmp,MaxRoad, dane);
		ListGetValByIdx(StrTmp, "&", 1, StrTmp1);
		if (i == 1)
			ListGetValByIdx(StrTmp, "&", 2, StrTmp2);
		
		ListGetValByIdx(StrTmp, "&", 3, StrTmp3);
		ListGetValByIdx(StrTmp, "&", 4, StrTmp4);
		
		sprintf(StrTmp,"");
		sprintf (StrTmp,"%s&%s&%s&%s&%s&%s&%s%s", StrTmp1,  StrTmp2, StrTmp3,  StrTmp4, TipePP->NUMVIAPPAL, TipePP->NUMVIAGEN,  TipePP->NUMPLACA,  ValAddress);
		
		sprintf(StrString, "");
		sprintf(StrString, "%s", StringDesc);
		sprintf(StringDesc, "");
		
		if (strlen(StrString) == 0)
			sprintf(StringDesc, "%s",  StrTmp);
		else sprintf (StringDesc, "%s/%s",StrString, StrTmp);
		
		//sprintf(StringDesc, "%s",  StrTmp);
		
	}
	
}

// Busca si la session ya existe, devuelve la extructura relacionado con ella
int existsSessionIf (char *str)
{
	Direction = DirectionStart;
	
	while (Direction != NULL)
	{
		if (strcmp(Direction->session, str) == 0)
			return 1;
		
		Direction = Direction->next;
	}
	
	return 0;
}

// Realiza la clasificacion de las palabras y las va almacenando en la cola
int classificationMz ( char *wordSP
			, char *wordNext
			, struct s_session *listSessionStart)
{	
	struct s_session *listSession=NULL;
	char *wordS;
	
	s_sessionValue *AuxSession=NULL;
	
	wordS = wordSP;
	listSession = listSessionStart;
	
	// Valida si el valor es numero elimina los ceros a la izquierda
	if (valExpRegStr(wordS, "^[0-9]{1,9}$") == 1 )
	{
		int  uint = 0;
		// Convierte a integer wordS
		sscanf(wordS, "%d", &uint);
		
		if (uint == 0)
			return 1;
		
		sprintf (wordS, "%d", uint);	
	}
		
	// Manejo Tuplas
	if (validateSession(wordS, listSessionStart) == 1 
			&& strcmp(wordS, "") != 0
			&& strcmp(NOMENCLATURA, "") == 0)
		sprintf(NOMENCLATURA,"%s", wordS);
	else {
		if (validateSession(wordS, listSessionStart) == 0)
		{
			if (strcmp(VALOR, "") == 0)
				sprintf(VALOR, "%s", wordS);
			else sprintf(VALOR, "%s %s",VALOR ,wordS); // Concatena el valor
		}
	}
	//CL LOS ALMENDROS CS 5 20 LA BASE LT 3&&MANZANA&&&&&VALIDA
	// Valida si la siguiente palabra es VALOR
	if (validateSession(wordNext, listSessionStart) == 0
	    		&& ((strcmp(NOMENCLATURA, "BR") == 0
	    		    		&&  strcmp(NOMENCLATURA, "") == 0
	    		    		&& ((valExpRegStr(VALOR, "^[0-9]{1,9}$") == 0
						    && valExpRegStr(wordNext, "^[0-9]{1,9}$") == 1)
					    || (valExpRegStr(VALOR, "^[0-9]{1,9}$") == 1
						    && valExpRegStr(wordNext, "^[0-9]{1,9}$") == 0))
	    		    	|| (valExpRegStr(VALOR, "^[0-9]{1,9}$") == 0
	    		    	    	&& valExpRegStr(wordNext, "^[0-9]{1,9}$") == 0))
			    )
	    		&& strcmp(wordNext, "") != 0)
		return 1;
		
		
	// Si NOMENCLATURA es vacio, le asigna VACIO
	if (strcmp(NOMENCLATURA, "") == 0)
		sprintf(NOMENCLATURA, "BR");
	
	//sprintf(PASO, "%s .. P:%s /N:%s /V:%s .. ", PASO, wordS, NOMENCLATURA, VALOR);
	// Si la tupla esta completa arma la seccion
	if (strcmp(NOMENCLATURA, "") != 0
		&& strcmp(VALOR, "") != 0)
	{
		Session = NULL;
	
		existsSession(NOMENCLATURA, "Session");
		
		if ( Session == NULL)
		{
			// Si no esta creada, se crea
			Session = FNC_malloc(sizeof(s_sessionValue));
			createSession(NOMENCLATURA, TYPEDIRECTION, listSessionStart);
			
			sprintf (Session->value, "%s", VALOR);
			insertSession ();
			//FNC_free(Session);
			
		}
		
		sprintf (NOMENCLATURA, "");
		sprintf (VALOR, "");
			
	}
	
	return 1;
	
}

// Realiza la clasificacion de las palabras y las va almacenando en la cola
int classificationSessions (char *city
				, char *wordSP
				, char *wordNext
				, char *wordNextNext
				, char *wordNextNextNext
				, struct s_session *listSessionStart)
{	
	struct s_session *listSession=NULL;
	char *wordS;
	
	s_sessionValue *AuxSession=NULL;
	
	wordS = wordSP;
	listSession = listSessionStart;
	
	//sprintf(PASO, "%s .. P-%s S-%s .. ", PASO, wordS, SESIONACTUAL);
		
	// Evalua texto centro
	if (strcmp(wordS, "CENTRO") == 0)
		sprintf (wordS, "CEN");
	
	if (strcmp(wordS, "N") == 0  // Se agrega esta validacion para quitar la N cuando viene acompanada de numero principal
		&& *ORIGINTVP == 1) // Indica que la precedencia es TIPO VIA PRINCIPAL
		return 1;
	
	// Valida si el valor es numero elimina los ceros a la izquierda
	if (valExpRegStr(wordS, "^[0-9]{1,9}$") == 1 )
	{
		int  uint = 0;
		// Convierte a integer wordS
		sscanf(wordS, "%d", &uint);
		
		if (uint == 0)
			return 1;
		
		sprintf (wordS, "%d", uint);	
	}
	
	//sprintf(PASO, "%s - W:%s/N:%s/V:%s/HN:%s/HV:%s/SE:%s/SA:%s ^ ",PASO, wordS, NOMENCLATURA, VALOR, HUERFANOS, HUERFANOV, Session, SESIONACTUAL);
	//Evalua cuadrante
	if (valExpRegStr(wordS, "^NORTE$|^N$") == 0
		// Control de cambio Julio
		&& (strcmp(SESIONACTUAL, "VIAGENERADORA") == 0
			|| strcmp(SESIONACTUAL, "TIPOVIAPPAL") == 0)
		// End
		)
	{
		
		// Control de cambio Julio
		// Recupera la particula Tipo Via Principal
		Session = NULL;
		existsSession("TIPOVIAPPAL", "Name") ;
		
		if (Session != 	NULL)
		{
			
			if (strcmp(Session->NUMPLACA, "") != 0
					&& valExpRegStr(wordNext, "^SUR$|^OE$|^E$|^SE$|^O$|^S$|^SOE$") == 0)
				sprintf(SESIONACTUAL, "");
		// End
			//if (valExpRegStr(wordS, "^SUR$|^OE$|^E$|^NE$|^SE$|^O$|^S$|^NORTE$|^N$") == 1)
			// Se quita la validacion de NORTE en la direccion
			if (valExpRegStr(wordS, "^SUR$|^OE$|^E$|^SE$|^O$|^S$|^SOE$") == 1
				&& (strcmp(NOMENCLATURA, "") == 0
					|| valExpRegStr(wordNext, "^[0-9]{1,9}$") == 1)
				// Control de cambio Julio
				& strlen(Session->NUMVIAPPAL) > 0
				// End
				)
			{
				if (strcmp(wordS,"SUR") == 0) sprintf(wordS, "S");
				
				//if (strcmp(wordS,"NORTE") == 0) sprintf(wordS, "N");
				
				if (strstr(CUADRANTE, wordS) != NULL && strcmp(wordNext, "") != 0)
					return 1;
				
				if (strstr(CUADRANTE, wordS) == NULL) {
					char PreStr[50] = "";
					sprintf(PreStr, "%s", CUADRANTE);
					
					//if (strcmp(wordS,"S") == 0 || strcmp(wordS,"N") == 0 )
					if (strcmp(wordS,"S") == 0)
						sprintf(CUADRANTE,"%s%s",wordS, PreStr);
					else sprintf(CUADRANTE,"%s%s",PreStr ,wordS);
					
				}
				
				if (strcmp(wordNext, "") != 0
					/*&& strcmp(HUERFANOV, "") == 0*/)
				{
					//sprintf(PASO, "%s - W:%s/SS:%d/VSS:%s ^ ",PASO, wordS, strcmp(wordNext, ""), wordNext);
					return 1;
				}
				else sprintf(wordS,"");
			}
		}
	}
	//sprintf(PASO, "%s - W:%s/SS:%s ^ ",PASO, wordS, wordNext);
	//Evalua si session es TIPOVIAPPAL
	if (validateSessionType(wordS, "TIPOVIAPPAL", listSessionStart) == 1
		&& strcmp(TYPEDIRECTION, "GE") == 0)
	{
		//Session = NULL;
		//sprintf (PASO, "%s - %s:%s", PASO, wordS, TYPEDIRECTION);
		// Valida si la seccion esta creada
		
		Session = NULL;
		existsSession("TIPOVIAPPAL", "Name");
		
		if ( Session == NULL) 
		{
			// Si no esta creada, se crea
			Session = FNC_malloc(sizeof(s_sessionValue));
			 createSession(wordS, TYPEDIRECTION, listSessionStart);

			//Inicializa cola de direccion
			if (strcmp(Session->session, "") != 0)
			{
				insertSession ();
			}
			else FNC_free(Session);
			//sprintf (PASO, "%s - %s", PASO, Direction);

			sprintf(SESIONACTUAL, "TIPOVIAPPAL");
		}
		
		
		return 1;
	}
	
	//sprintf(PASO, "%s - W:%s/N:%s/V:%s/HN:%s/HV:%s/SE:%s/SA:%s ^ ",PASO, wordS, NOMENCLATURA, VALOR, HUERFANOS, HUERFANOV, Session, SESIONACTUAL);	
	//Evalua si la session actual es TIPOVIAPPAL
	if (strcmp(SESIONACTUAL, "TIPOVIAPPAL") == 0)
	{	
		// 1. Se debe priorizar el armado de la puerta para tipo v�a tomando los valores independiente de las nomenclaturas que acompa�en
		// 	estos valores. Ej call 57 casa 5 apto 36, tomo valores y defino call 57 5 36
		// 2. Despues de tomar los valores se toma las nomenclaturas y se env�an al complemento. En el complemento con elementos huerfanos
		//	se busca armar complemento logico.
		// 3. Se agrega validacion para obligar a que solo sean numeros.
		if (validateSession(wordS, listSessionStart) == 1
			&& validateSession(wordNext, listSessionStart) == 0
			&& (valExpRegStr(wordNext, "^[0-9]{1,9}$") == 1
				|| valExpRegStr(wordNext, "^[A-Z]{1,3}$") == 1
				)
			)
		{
			//sprintf(HUERFANOS,"%s", wordS);	
			
			if (strcmp(wordNext, "") != 0)
				return 0;
			
		}
		
		// Control de cambio Julio
		//Se agrega validacion si viene componentes que no son via principal y ya se ha asignado numero de via
		// la nomenclatura y su valor se env�an a huerfanos hasta que llegue un numero
		// Parte 1, validacion nomenclatura
		if (validateSession(wordS, listSessionStart) == 1
			&& validateSession(wordNext, listSessionStart) == 0
			&& valExpRegStr(wordNext, "^[A-Z]{2,50}$") == 1
			&& strcmp(wordNextNextNext, "") != 0
				)
		{
			sprintf(HUERFANOS,"%s", wordS);
			sprintf(IND_HUERFANO_TP,"SI");
			return 0;
		}
		// Parte 2, validacion valor
		if (validateSession(wordS, listSessionStart) == 0
			&& valExpRegStr(wordS, "^[A-Z]{1,50}$") == 1
			&& strcmp(HUERFANOS, "") != 0 
			&& strcmp(IND_HUERFANO_TP, "SI") == 0 
				)
		{
			if (strcmp(HUERFANOV, "") != 0)
				sprintf(HUERFANOV,"%s %s", HUERFANOV, wordS);
			else sprintf(HUERFANOV,"%s", wordS);
			
			if (strcmp(wordNext, "") == 0)
			{
				sprintf(VALOR,"%s", HUERFANOV);
				sprintf(NOMENCLATURA,"%s", HUERFANOS);
				sprintf(HUERFANOS,"");
				sprintf(HUERFANOV,"");
				sprintf(SESIONACTUAL,"");
				sprintf(wordS,"");
			} else return 0;
		}
		// End
		
		
		//Recupera la session
		Session = NULL;
		existsSession("TIPOVIAPPAL", "Name");
		
		//printf(PASO, "%s - W:%s/N:%s/V:%s/HN:%s/HV:%s/SE:%s/SA:%s/BREACHPAR:%d ^ ",PASO, wordS, NOMENCLATURA, VALOR, HUERFANOS, HUERFANOV, Session, SESIONACTUAL, *BREACHPAR);
		if ( Session != NULL 
			&& validateSession(wordS, listSessionStart) == 0
			&& strcmp(NOMENCLATURA, "") == 0
			&& ( strcmp(VALOR, "") == 0
				|| valExpRegStr(wordS, "^[0-9]{1,9}$") == 1	
				)
			)
		{
			//sprintf(PASO, "%s - W:%s/N:%s/V:%s/HN:%s/HV:%s/SE:%s/SA:%s/BREACHPAR:%d ^ ",PASO, wordS, NOMENCLATURA, VALOR, HUERFANOS, HUERFANOV, Session, SESIONACTUAL, *BREACHPAR);
						
			//Valida si la palabra tiene solo numeros   
			if (/*valExpRegStr(wordS, "^[0-9]{1,9}$") == 1 && */strlen(Session->NUMVIAPPAL) == 0)
			{
				// Si NUMVIAPPAL es vacio, le copia los numeros
				sprintf(Session->NUMVIAPPAL, "%s", wordS);

				if (strcmp(wordNext, "") != 0
						/*&& strcmp(TYPEDIRECTION, "MZ") != 0*/)
					return 1;
				
				sprintf(wordS, "");
			}

			//Valida si la palabra tiene solo letras
			if (valExpRegStr(wordS, "^[A-Z�a-z�]*$") == 1 
				&& valExpRegStr(Session->NUMVIAPPAL, "^[A-Z�a-z� ]*$") == 1
				&& valExpRegStr(wordS, "^[A-Z�a-z�]{0,2}BIS[A-Z�a-z�]{0,2}$") == 0)
			{
				// Si la palabra tiene letras las concatena  a NUMVIAPPAL
				sprintf(Session->NUMVIAPPAL,"%s %s", Session->NUMVIAPPAL, wordS);

				if (strcmp(wordNext, "") != 0
						/*&& strcmp(TYPEDIRECTION, "MZ") != 0*/)
					return 1;
				
				sprintf(wordS, "");
			}
			
			/*if (strlen(Session->NUMVIAPPAL) > 0
				&& strcmp(TYPEDIRECTION, "MZ") == 0
				)
			{
				if (validateSession(wordNext, listSessionStart) == 1)
					sprintf (SESIONACTUAL, "");
				
				return 0;
			}
		*/
			// Modificador numero via principal
			// Valida si la palabra son solo letras maximo de 2 letras y si contiene la palabra BIS
			if (((valExpRegStr(wordS, "^[A-Z�a-z�]{1,2}$") == 1 && valExpRegStr(wordS, "LA|LO|LOS|LAS|EL") == 0)
				||  valExpRegStr(wordS, "^[A-Z�a-z�]{0,2}BIS[A-Z�a-z�]{0,2}") == 1)
				&& strlen(Session->NUMVIAPPAL) > 0
				&& strlen(Session->NUMVIAGEN) == 0
				)
			{	
				sprintf (Session->MODVIAPPAL, "%s%s", Session->MODVIAPPAL, wordS);
				
				
				if (strcmp(wordNext, "") != 0)
					return 1;
				
				sprintf(wordS, "");
			}
			
			//Numero via Generadora
			//Valida si la palabra son maximo 3 numeros
			if (valExpRegStr(wordS, "^[0-9]{1,9}?$") == 1
				&& strlen(Session->NUMVIAPPAL) > 0
				&& strcmp(Session->NUMVIAGEN, "") == 0
				)
			{
				sprintf(Session->NUMVIAGEN, "%s", wordS);
				
				sprintf (SESIONACTUAL, "VIAGENERADORA");
				
				if (strcmp(wordNext, "") != 0)
					return 1;
				
				sprintf(wordS, "");
			
			}
			
		} /*else {
			if (strcmp(HUERFANOS, "") == 0)
				sprintf (SESIONACTUAL, "");
		}*/
	}
	
	//sprintf(PASO, "%s - W:%s/N:%s/V:%s/HN:%s/HV:%s/SE:%s/SA:%s ^ ",PASO, wordS, NOMENCLATURA, VALOR, HUERFANOS, HUERFANOV, Session, SESIONACTUAL);
		
	//Si la sesion es via generadora
	if (strcmp(SESIONACTUAL, "VIAGENERADORA") == 0)
	{
		
		// Valida si es una section
		// 1. Se debe priorizar el armado de la puerta para tipo v�a tomando los valores independiente de las nomenclaturas que acompa�en
		// 	estos valores. Ej call 57 casa 5 apto 36, tomo valores y defino call 57 5 36
		// 2. Despues de tomar los valores se toma las nomenclaturas y se env�an al complemento. En el complemento con elementos huerfanos
		// 3. Se agrega validacion para obligar a que solo sean numeros.
		if (validateSession(wordS, listSessionStart) == 1
			&& validateSession(wordNext, listSessionStart) == 0
			&& valExpRegStr(wordNext, "^[0-9]{1,9}$") == 1
			)
		{
			//sprintf(HUERFANOS,"%s", wordS);	
			
			if (strcmp(wordNext, "") != 0)
				return 0;
			
		}
		
		// Recupera la particula Tipo Via Principal
		Session = NULL;
		existsSession("TIPOVIAPPAL", "Name") ;
		
		if (Session != 	NULL
			&& validateSession(wordS, listSessionStart) == 0
			&& strcmp(NOMENCLATURA, "") == 0
			&& ( strcmp(VALOR, "") == 0
				|| valExpRegStr(wordS, "^[0-9]{1,9}$") == 1	
					)
			)
		{
			//sprintf(PASO, "%s - W:%s/N:%s/V:%s/HN:%s/HV:%s/SE:%s/SA:%s ^ ",PASO, wordS, NOMENCLATURA, VALOR, HUERFANOS, HUERFANOV, Session, SESIONACTUAL);	
			// Valida si la palabra son solo letras maximo de 2 letras y si contiene la palabra BIS
			// Modificadora de via generadora
			if (((valExpRegStr(wordS, "^[A-Z�a-z�]{1,2}$") == 1 && valExpRegStr(wordS, "LA|LO|LOS|LAS|EL") == 0)
					||  valExpRegStr(wordS, "^[A-Z�a-z�]{0,2}BIS[A-Z�a-z�]{0,2}") == 1)
				&& strcmp(Session->NUMVIAGEN, "") != 0
				&& strcmp(Session->NUMPLACA, "") == 0
				)
			{				
				sprintf (Session->MODVIAGEN, "%s%s", Session->MODVIAGEN, wordS);
				
				if (strcmp(wordNext, "") != 0)
					return 1;
				
				sprintf(wordS, "");
			}
		
			//Valida si la palabra son maximo 3 numeros
			//PUERTA
			if (valExpRegStr(wordS, "^[0-9]{1,9}$") == 1
					&& strcmp(Session->NUMVIAGEN, "") != 0
					&& strcmp(Session->NUMPLACA, "") == 0
					)
			{
				
				sprintf(Session->NUMPLACA, "%s", wordS);
				//sprintf(PASO, "%s %s",PASO, wordS );
				
				// Control de cambio Julio
				if (valExpRegStr(wordNext, "^SUR$|^OE$|^E$|^SE$|^O$|^S$|^SOE$") == 1)
					return 0;
				// End
				
				sprintf(SESIONACTUAL, "");
				
				if (strcmp(wordNext, "") != 0
					&& (strcmp(HUERFANOS, "") == 0
						|| strcmp(HUERFANOV, "") == 0)
					)
				{
					return 1;
				}
				
				sprintf(wordS, "");
			}
			
		}			
		
		// Control de cambio Julio
		if (valExpRegStr(wordNext, "^SUR$|^OE$|^E$|^SE$|^O$|^S$|^SOE$") == 1)
			return 0;
		// End
		
		if (strcmp(NOMENCLATURA, "") == 0)
			sprintf(SESIONACTUAL, "");
		
	}
	
	// Control de cambio Julio
	//Evalula si la session en TIPO VIA PRINCIPAL y la palabra es NORTE, la descarta, si huerfano valor es vacio salta a la siguiente palabra
	// Control del cambio Julio 2018
	if (strcmp(HUERFANOV, "") == 0
		&& valExpRegStr(wordS, "^NORTE$|^NORTE $|^NORTE [0-9 ]{1,50}$") == 1
		&& (strcmp(SESIONACTUAL, "TIPOVIAPPAL") == 0
			|| strcmp(SESIONACTUAL, "VIAGENERADORA") == 0)
			)
		return 1;
	// End
		
	//Inicio: Validacion de la seccion, incluye la seccion y el valor, tambien se emplea
	// la seccion pendiente para el manejo de valores huerfanos
	
	// Primera parte, Define valores para tupla o huerfanos
		// Primera parte, Define valores para tupla o huerfanos
	if (validateSession(wordS, listSessionStart) == 1 
		&& strcmp(wordS, "") != 0)
	{
		/*Escenario 1*/
		if (strcmp(NOMENCLATURA, "") == 0)
		{
			// Control de cambio Julio
			if (validateSession(wordNext, listSessionStart) == 1 // Caso CONJ AV 5 B E 9 B 27 VILLA ELENA
					&& validateSessionType(wordNext, "TIPOVIAPPAL", listSessionStart) == 1
					&& strcmp(TYPEDIRECTION, "GE") == 0
					&& strcmp(HUERFANOS, "") == 0)
				sprintf(HUERFANOS,"%s", wordS);
			else
				sprintf(NOMENCLATURA,"%s", wordS);
			
			//sprintf(NOMENCLATURA,"%s", wordS);
			// End
		}
		else {
			sprintf(HUERFANOS,"%s", NOMENCLATURA);     
			sprintf(NOMENCLATURA,"%s", wordS);
		}
	} else {
		if (strcmp(NOMENCLATURA, "") == 0)
		{				
			if (strcmp(HUERFANOV, "") == 0)
				sprintf(HUERFANOV, "%s", wordS);
			else {
				if ((valExpRegStr(HUERFANOV, "^[0-9]{1,9}$") == 0
							&& valExpRegStr(wordS, "^[0-9]{1,9}$") == 0
							&& validateSession(wordS, listSessionStart) == 0)
						|| (strlen(HUERFANOV) > 0
							&& validateSession(wordNext, listSessionStart) == 1
							&& validateSession(wordNextNext, listSessionStart) == 0
							&& strcmp(wordNextNext, "") != 0)
						|| (validateSession(wordNext, listSessionStart) == 0
							&& validateSession(wordNextNext, listSessionStart) == 1
							)
					)
					sprintf (HUERFANOV, "%s %s",HUERFANOV ,wordS);
				else
				{
					if (strcmp(VALOR, "") == 0
						&& validateSession(wordNext, listSessionStart) == 1)
						sprintf(VALOR, "%s", wordS);
					else {
						if (valExpRegStr(HUERFANOV, "^[0-9]{1,9}$") == 1
							&& valExpRegStr(wordS, "^[0-9]{1,9}$") == 1)
							sprintf(HUERFANOV, "%s", wordS);
						else { 
							sprintf (HUERFANOV, "%s %s",HUERFANOV ,wordS);
						}
					}
				}
			}
		} else {
			/*Escenario 1*/
			if (strcmp(VALOR, "") == 0)
				sprintf(VALOR, "%s", wordS);
			else {
				if ((valExpRegStr(VALOR, "^[0-9]{1,9}$") == 0
							&& valExpRegStr(wordS, "^[0-9]{1,9}$") == 0
							&& validateSession(wordS, listSessionStart) == 0)
						|| (validateSession(wordNext, listSessionStart) == 1
							&& validateSession(wordNextNext, listSessionStart) == 0)
						|| (validateSession(wordNext, listSessionStart) == 0
							&& validateSession(wordNextNext, listSessionStart) == 1
							)
						|| (validateSession(wordNext, listSessionStart) == 0
							&& validateSession(wordNextNext, listSessionStart) == 0
							)
						)
					sprintf (VALOR, "%s %s", VALOR,wordS);
				else {
					/*Escenario 1 con huerfano*/
					if ((valExpRegStr(VALOR, "^[0-9]{1,9}$") == 1
							&& valExpRegStr(wordS, "^[0-9]{1,9}$") == 0)
						|| (valExpRegStr(VALOR, "^[0-9]{1,9}$") == 0
							&& valExpRegStr(wordS, "^[0-9]{1,9}$") == 1))
					{
						sprintf(HUERFANOV, "%s", VALOR);
						sprintf(VALOR, "%s", wordS);
					}
				}
			}
		}
	}
	
	//sprintf(PASO, "%s - W:%s/N:%s/V:%s/HN:%s/HV:%s/SE:%s/SA:%s ^ ",PASO, wordS, NOMENCLATURA, VALOR, HUERFANOS, HUERFANOV, Session, SESIONACTUAL);
	
	// Segunda parte, valida si los huerfanos ya no son huerfanos, para asignarlos a las tuplas
	if ((strcmp(HUERFANOS, "") != 0 
			&& strcmp(HUERFANOV, "") != 0)
		)
	{
		if (strcmp(HUERFANOS, "") != 0)
		{
			sprintf(NOMENCLATURA,"%s", HUERFANOS);
			sprintf(HUERFANOS, "");
		}
		
		if (strcmp(HUERFANOV, "") != 0)
		{
			sprintf(VALOR, "%s", HUERFANOV);
			sprintf(HUERFANOV, "");
		}
	}
	
	//sprintf(PASO, "%s - W:%s/N:%s/V:%s/HN:%s/HV:%s/SE:%s ^ ",PASO, wordS, NOMENCLATURA, VALOR, HUERFANOS, HUERFANOV, Session);
	
	// Tercera parte, Valida si hay seccion sin valor y si el valor siguiente es seccion asignara huerfano valor	
	if (strcmp(NOMENCLATURA, "") != 0
		&& strcmp(VALOR, "") == 0
		&& ((strcmp(wordNext, "") != 0 && validateSession(wordNext, listSessionStart) == 1)
			|| strcmp(wordNext, "") == 0)
		)
	{
		
		if (strcmp(HUERFANOV, "") != 0)
		{
			sprintf(VALOR, "%s", HUERFANOV);
			sprintf(HUERFANOV, "");
		}
	}
	//sprintf(PASO, "%s - W:%s/N:%s/V:%s/HN:%s/HV:%s/SE:%s/SA:%s ^ ",PASO, wordS, NOMENCLATURA, VALOR, HUERFANOS, HUERFANOV, Session, SESIONACTUAL);
	// Cuarta parte, valida si la secci�n y su valor no tienen nada.
	//		o Si el valor es numerico y el valor siguiente no lo es y el tama�o del valor siguiente sea 1
	//		o Si el siguiente valor no es una seccion y el valor no es numerico y el valor siguiente es numero
	//	y Si seccion actual es diferente de TIPOVIAPPAL y VIAGENERADORA
	// Si cumple todo esto, retorna.
	
	if (/*Escenario 1*/
		(strcmp(VALOR, "") == 0
			|| (validateSession(wordNext, listSessionStart) == 0
				&& valExpRegStr(wordNext, "^[0-9]{1,9}$") == 0
				&& (!(strcmp(NOMENCLATURA, "") != 0
						&& valExpRegStr(VALOR, "^[0-9]{1,9}$") == 1)
					|| valExpRegStr(VALOR, "^[0-9]{1,9}$") == 0)
				)
			|| (validateSession(wordNext, listSessionStart) == 0
				&& validateSession(wordNextNext, listSessionStart) == 0
				&& (!(strcmp(NOMENCLATURA, "") != 0
						&& valExpRegStr(VALOR, "^[0-9]{1,9}$") == 1)
					|| valExpRegStr(VALOR, "^[0-9]{1,9}$") == 0)
				)
			|| strcmp(NOMENCLATURA, "") == 0
			)
		&& strcmp(wordNext, "") != 0
		)
		return 1;
	
	//sprintf(PASO, "%s - W:%s/N:%s/V:%s/HN:%s/HV:%s/SE:%s/SA:%s ^ ",PASO, wordS, NOMENCLATURA, VALOR, HUERFANOS, HUERFANOV, Session, SESIONACTUAL);
	// Evalua completitud de las tuplas
	if ((strcmp(NOMENCLATURA, "") != 0 
			&& strcmp(VALOR, "") == 0
			&& strcmp(HUERFANOV, "") != 0
			)
		|| (strcmp(NOMENCLATURA, "") == 0
			   && strcmp(VALOR, "") != 0
			   && strcmp(HUERFANOS, "") != 0
	   	   )
	   	|| (strcmp(NOMENCLATURA, "") == 0 
			&& strcmp(VALOR, "") == 0
			&& strcmp(HUERFANOV, "") != 0
			)
		)
	{
		
		if (strcmp(NOMENCLATURA, "") == 0
			&& strcmp(HUERFANOS, "") != 0)
		{
			sprintf(NOMENCLATURA, "%s", HUERFANOS);
			sprintf(HUERFANOS, "");
		} else {
			sprintf(VALOR, "%s", HUERFANOV);
			sprintf(HUERFANOV, "");
		}
	}
	
	//sprintf(PASO, "%s - W:%s/N:%s/V:%s/HN:%s/HV:%s/SE:%s ^ ",PASO, wordS, NOMENCLATURA, VALOR, HUERFANOS, HUERFANOV, Session);
	
	// Ultima parte de validacion de tuplas
	// Valida que la seccion y el valor tengan algo 
	// o que no venga seccion en el siguiente valor
		
	// Validacion para COMPLEMENTO DE VIA
	if ((strcmp(NOMENCLATURA, "AL") == 0 // Exclusion seccion Apto
			|| strcmp(NOMENCLATURA, "EN") == 0 // Exclusion seccion Entrada
			|| strcmp(NOMENCLATURA, "POR") == 0 // Exclusion seccion Sector
		)
			&& valExpRegStr(VALOR, "^[0-9]{1,9}$") == 0
			&& strcmp(VALOR, "") != 0)
	{
		Session = NULL;
		
		existsSession("COMPVIA", "Session");
		
		if (Session == NULL)
		{
			Session = FNC_malloc(sizeof(s_sessionValue));
			createSession("COMPVIA", TYPEDIRECTION, listSessionStart);
			
			//sprintf(PASO, "%s - W:%s/S:%s/V:%sTD:%s/SE:%s ^ ",PASO, wordS, NOMENCLATURA, VALOR,TYPEDIRECTION, Session);
			//FNC_free(Session);
			//return 1;
			
			insertSession ();
		}
		
		if (strcmp(HUERFANOV, "") != 0)
		{
			sprintf(Session->value, "%s %s %s",HUERFANOV ,NOMENCLATURA, VALOR);
			sprintf (HUERFANOV, "");
		}
		else
			sprintf(Session->value, "%s%s %s",Session->value, NOMENCLATURA, VALOR);		
		sprintf(NOMENCLATURA, "");
		sprintf(VALOR, "");
		return 1;
		
	}
	
	//sprintf(PASO, "%s - W:%s/N:%s/V:%s/HN:%s/HV:%s/SE:%s ^ ",PASO, wordS, NOMENCLATURA, VALOR, HUERFANOS, HUERFANOV, Session);
	//return 1;
	
	// Valida si la nomenclatura existe y si es la ultima palabra, setea BR a nada
	if (existsSessionIf(NOMENCLATURA) == 1
			&& strcmp(wordNext, "") == 0)
	{
		// Control de cambio Julio, incidencia caso 9 Et  Mz  W Cs 38 JORDAN ET 9
		sprintf(NOMENCLATURA, "");
		
		if (strcmp(HUERFANOV, "") != 0
			&& valExpRegStr(VALOR, "[0-9]{1,4}") == 1
			&& valExpRegStr(HUERFANOV, "[A-Za-z0-9 ]{4,100}") == 1) //VALIDACION valExpRegStr(HUERFANOV, "[A-Z�a-z�0-9 ]{4,100}") == 1
		{
			sprintf(VALOR, "%s", HUERFANOV);
			sprintf(HUERFANOV, "");
		}
		//End
		//sprintf(NOMENCLATURA, "");

	}
	
	
	// Cuando en nomenclatura esta vacio y el siguiente valor viene nulo, y en valor hay algo que contenga letras, entonces
	// a nomenclatura le asigna BR
	
	if (strcmp(NOMENCLATURA, "") == 0
		&& (strcmp(VALOR, "") != 0
			//|| strcmp(HUERFANOV, "") != 0
			)
		&& (valExpRegStr(VALOR, "[A-Z�a-z�0-9 ]{4,100}") == 1
			//|| valExpRegStr(HUERFANOV, "[A-Za-z0-9 ]{4,100}") == 1
			)
		)
	{
		if (strcmp(HUERFANOV, "") != 0)
		{
			sprintf(VALOR, "%s", HUERFANOV);
			sprintf(HUERFANOV, "");
		}
		
		if (strcmp(TYPEDIRECTION, "KM") == 0)
		{
			addValueSession(VALOR);
			sprintf(VALOR, "");
			return 1;
		} else 
			sprintf(NOMENCLATURA, "BR");
		
	}
	
	//sprintf(PASO, "%s - W:%s/N:%s/V:%s/HN:%s/HV:%s/SE:%s ^ ",PASO, wordS, NOMENCLATURA, VALOR, HUERFANOS, HUERFANOV, Session);
	
	// Valida si la particula esta agrupada en BARRIO y si su es un numero, para descartar
	// esta tupla strcmp
	if (strcmp(NOMENCLATURA, "BR") == 0
		&& (// Control de cambio Julio
			valExpRegStr(VALOR, "^NORTE$|^NORTE $|^NORTE [0-9 ]{1,50}$") == 1
		    // End
			|| valExpRegStr(VALOR, "[A-Z�a-z�]{4,100}") == 0
			|| valExpRegStr(VALOR, "^[0-9]{1,9}$") == 1
			|| strlen(VALOR) < 4
			)
		)
	{
		sprintf (NOMENCLATURA, "");
		sprintf (VALOR, "");
		return 1;
	}
	
	//sprintf(PASO, "%s - W:%s/N:%s/V:%s/HN:%s/HV:%s/SE:%s ^ ",PASO, wordS, NOMENCLATURA, VALOR, HUERFANOS, HUERFANOV, Session);
	
	// Se valida si es la ultima palabra y si en HUERFANOS esta la particula CEN
	// Entonces NOMENCLATURA = CEN
	if (strcmp(wordNext, "") == 0
			&& (strcmp(HUERFANOS, "CEN") == 0
				// Control de cambio Julio
				|| strcmp(HUERFANOS, "ESQ") == 0
				// End
				)
			&& strcmp(NOMENCLATURA, "") == 0)
	{
		sprintf (NOMENCLATURA, "%s", HUERFANOS);
		sprintf (HUERFANOS, "");
	}
	
	// Para aptos, casa y todas las nomenclaturas del mismo nivel se toman valores alfanumericos y numeros a partir de tres hasta cinco digitos.
	// Si es superior se quita el numero y la nomenclatura porque no seria v�lida.
	// 2. Para bloque, torre, interior y todas las nomencalturas del mismo nivel se toman valores alfanumericos se dejan 3 caracteres donde el maximo es una letra 2 n�meros.
	// ** en casos de torres (ej Satnta Clara) el tratamiento es diferente. 
	if ((validateSessionType(NOMENCLATURA, "APARTAMENTO", listSessionStart) == 1
			&& valExpRegStr(VALOR, "^[A-Z�0-9]{1,5}$") == 0
		) || (validateSessionType(NOMENCLATURA, "BLOQUE", listSessionStart) == 1 
			&& (valExpRegStr(VALOR, "^[A-Z�0-9]{1,3}$") == 0
				|| valExpRegStr(VALOR, "[A-Z�]{2}$") == 1
				)
			)
		)
	{
		if (!(strcmp (NOMENCLATURA, "TO") == 0 && valExpRegStr(VALOR, "^[A-Z�0-9 ]{1,50}$") == 1))
		{
			sprintf(NOMENCLATURA, "");
			sprintf(VALOR, "");
			return 1;
		}
		
	}
	
		
	//sprintf(PASO, "%s - W:%s/N:%s/V:%s/HN:%s/HV:%s/SE:%s ^ ",PASO, wordS, NOMENCLATURA, VALOR, HUERFANOS, HUERFANOV, Session);
	//return 0;
	
	// Crea la session de acuerdo a NOMENCLATURA
	// Valida primero si la seccion esta creada
	//sprintf(PASO, "%s - W:%s/N:%s/V:%s/HN:%s/HV:%s/SE:%s/SA:%s ^ ",PASO, wordS, NOMENCLATURA, VALOR, HUERFANOS, HUERFANOV, Session, SESIONACTUAL);
	//return 0;
	
	Session = NULL;
	
	if (strcmp(NOMENCLATURA,"") != 0)
		existsSession(NOMENCLATURA, "Session");
	
	if ( Session == NULL
		&&  ((strcmp(VALOR,"") != 0
			&& strcmp(NOMENCLATURA,"") != 0)
			|| strcmp(NOMENCLATURA,"CEN") == 0
			// Control de cambio Julio
			|| strcmp(NOMENCLATURA,"ESQ") == 0
			// End
			)
		)
	{

		// Si no esta creada, se crea
		Session = FNC_malloc(sizeof(s_sessionValue));
		createSession(NOMENCLATURA, TYPEDIRECTION, listSessionStart);

		//free(Session);
		//return 0; //PRUEBA
	} else {
		if (strcmp(wordNext, "") == 0
			&& (strcmp(VALOR,"") == 0/*
				||valExpRegStr(VALOR, "^[0-9]{1,9}$") == 1*/)
			 )
		{
		
			sprintf(NOMENCLATURA,"");
			sprintf(VALOR,"");
			sprintf (HUERFANOS, "");
			sprintf (HUERFANOV, "");      
			sprintf (SESIONACTUAL, "");
			sprintf (wordS, "");
			
			return 1;
		}
		
	}
	
	//sprintf(PASO, "%s - W:%s/N:%s/V:%s/HN:%s/HV:%s/VS:%s/SE:%s ^ ",PASO, wordS, NOMENCLATURA, VALOR, HUERFANOS, HUERFANOV, wordNext, Session);
	sprintf(NOMENCLATURA,"");                                                                

	//Esta seccion es para realizar algunas validaciones en adelante con los valores ya almacenados
	// Si la seccion se pudo crear
	if (Session != NULL)
	{
		
		// Validacion especial para seccion CORREGIMIENTO
		if (strcmp(Session->sessionName,"CORREGIMIENTO") == 0) 
		{
			s_sessionValue *SessionPrev;
			SessionPrev = Session;
			Session = NULL;
			existsSession("TIPOVIAPPAL", "Name");
			AuxSession = Session;
			Session = SessionPrev;
			
			SessionPrev = NULL;
			
			if ( AuxSession != NULL && strcmp(AuxSession->NUMVIAGEN,"") != 0)
			{
				SessionPrev = Session;
				Session = NULL;
				existsSession("BARRIO", "Name");
				
				if ( Session == NULL) 
				{                               
					// Si no esta creada, se crea
					//Session = 0;
					Session = FNC_malloc(sizeof(s_sessionValue));
					createSession("CONJ", TYPEDIRECTION, listSessionStart);
					sprintf(Session->value,"%s",VALOR);
				}  else sprintf (Session->value, "%s CONJ %s",Session->value ,VALOR);
				
				FNC_free(SessionPrev);
	
			} else {
				if (valExpRegStr(VALOR, "^[0-9]{1,9}$") == 0)
					sprintf(Session->value,VALOR);
				
			}
			
			sprintf(VALOR, "");
			
			//Agrega la seccion a la cola
			if (existsSessionIf(Session->session) == 0)
			{
				insertSession ();
				//free(Session);
			}
			return 1;
		}
		// Asignacion de NOMENCLATURA y VALOR para el resto de sessiones
		if (valExpRegStr(Session->value, "^[0-9]{1,9}$") == 1
				&& valExpRegStr(VALOR, "^[0-9]{1,9}$") == 1)
			sprintf (Session->value, "%s", VALOR) ;
		else sprintf (Session->value, "%s %s", Session->value, VALOR);
		
		sprintf(VALOR, "");
		//sprintf (PASO, "%s - P:%s^", PASO, Session);
		//Agrega la seccion a la cola
		if (existsSessionIf(Session->session) == 0)
		{
			//free(Session);
			insertSession ();
			//return 0;
		}
		
		
		if (((strcmp(HUERFANOV, "") != 0
			&& valExpRegStr(HUERFANOV, "^NORTE$|^NORTE $|^NORTE [0-9 ]{1,50}$") == 0
			&& ((valExpRegStr(HUERFANOV, "[A-Z�a-z�]{4,100}") == 1
						&& strlen(HUERFANOV) > 3)
					) || valExpRegStr(HUERFANOV, "^[0-9]{1,9}$") == 1
				) || strcmp (HUERFANOS, "CEN") == 0
				// Control de cambio Julio
				  || strcmp (HUERFANOS, "ESQ") == 0
				// End
			) && strcmp(wordNext, "") == 0
			)
		{
			if (strcmp (HUERFANOS, "") == 0)
			{
				if (strcmp(TYPEDIRECTION, "KM") == 0)
				{
					addValueSession(HUERFANOV);
					sprintf(HUERFANOV, "");
					return 1;
				} else 
					sprintf(HUERFANOS, "BR");
			}
			
			//sprintf(PASO, "%s - W:%s/N:%s/V:%s/HN:%s/HV:%s/SE:%s ^ ",PASO, wordS, NOMENCLATURA, VALOR, HUERFANOS, HUERFANOV, Session);
				
			Session = NULL;
			existsSession(HUERFANOS, "Session");
	
			if (Session == NULL
				&& valExpRegStr(HUERFANOV, "^[0-9]{1,9}$") == 0) 
			{
				Session = FNC_malloc(sizeof(s_sessionValue));
				createSession(HUERFANOS, TYPEDIRECTION, listSessionStart);
				
				insertSession ();
				//free(Session);
			}
			
			if (Session != NULL)
				sprintf (Session->value, "%s %s",Session->value, HUERFANOV);
			
			sprintf(HUERFANOV, "");
		}
		
		return 1;
	}
	
	return 1;	
}

// La funcion recibe una direccion, la ciudad, el valor maximo permitido por calle de la ciudad y
// el tipo de consulta type = 1, normalizacion <-> type = 2, descomposicion en mas direcciones
void Address_Normalization (
		char *inStr,
		char *inCity,
		char *outStr,
		int inMaxRoad,
		int type,
		char *dane,
		char *tipificacion
		)
{
	Direction=DirectionStart =NULL;
	ValAddress = NULL;
	
	ValAddress = (char*)malloc(20);
	
	sprintf (ValAddress, "");

	sprintf (outStr, "");
	
	if (strcmp(dane, "") == 0
		|| strcmp(dane, "0") == 0)
		sprintf (ValAddress,"&NO VALIDA"); // Marcacion como NO VALIDA porque no hay codigo dane
			
	// Detencion no valida, devuelve la cadena con un &	
	if (valExpRegStr(inStr, "[0-9]|FI|VEDA") == 1)
	{
		// Definicion de variables para manejo de cadenas
		
		int loop, space = 0, begin,end, siCSaCL=0;
		char word[MAX_SIZE_STRING];
		char preWord[2] = "";
		char a[MAX_SIZE_WORK], b[MAX_SIZE_WORK], c[MAX_SIZE_WORK], d[MAX_SIZE_WORK];
		char *match;
		char Complemento[500]="";
		char outTMP[500]="";
		
		TYPEDIRECTION = NULL;
		SESIONACTUAL = NULL;
		NOMENCLATURA = NULL;
		VALOR = NULL;
		HUERFANOS = NULL;
		HUERFANOV = NULL;
		CUADRANTE = NULL; 
		COMPVIA = NULL;
		BREACHPAR = NULL;
		ORIGINTVP = NULL;
		
		PASO = NULL;
		// Control de cambio Julio
		IND_HUERFANO_TP = NULL;
		// End
		
		sprintf(word, "");
		
		TYPEDIRECTION = (char*)malloc(20);
		SESIONACTUAL = (char*)malloc(MAX_SIZE_OF_VAR);
		NOMENCLATURA = (char*)malloc(MAX_SIZE_OF_VAR);
		VALOR = (char*)malloc(MAX_SIZE_OF_VAR);
		HUERFANOS = (char*)malloc(MAX_SIZE_OF_VAR);
		HUERFANOV = (char*)malloc(MAX_SIZE_OF_VAR);
		COMPVIA = (char*)malloc(MAX_SIZE_OF_VAR);
		CUADRANTE = (char*)malloc(20);
		BREACHPAR = FNC_malloc(sizeof(int));
		ORIGINTVP = FNC_malloc(sizeof(int));
		// Control de cambio Julio
		IND_HUERFANO_TP=(char*)malloc(2);
		// End
				
		match = (char*)malloc(100*sizeof(char));
		
		PASO = (char*)malloc(MAX_SIZE_OF_VAR);
		sprintf(PASO, "");
		
		sprintf(NOMENCLATURA, "");
		sprintf(VALOR, "");
		sprintf(HUERFANOS, "");
		sprintf(HUERFANOV, "");
		sprintf(CUADRANTE, "");
		sprintf(COMPVIA, "");
		// Control de cambio Julio
		sprintf(IND_HUERFANO_TP, "");
		// End
		                    
		*BREACHPAR = 0;
		*ORIGINTVP = 0;
			
		sprintf(TYPEDIRECTION, "NO");
		
		// Lista de particulas
		struct s_session *listSession=NULL
			, *listSessionStart=NULL
			, *listSessionEnd=NULL ;
		int id = 1; // Contador para la inicializacion de particulas		
		
		// Inicializa agrupamiento de particulas
		while (id <= 97)
		{
			listSession=FNC_malloc (sizeof(s_session));
			//listSession=(struct s_session*) malloc(sizeof *listSession);
			
			initSessions (id, listSession);
			listSession->next=NULL;
				
			if (id == 1)
				listSessionStart = listSession;
			else
				listSessionEnd->next=listSession;
				
			listSessionEnd = listSession;
			id++;		
		}
		
		
		// Estructura para la cola de palabras
		struct wordString *wordAct=NULL, *wordEnd=NULL, *wordStart=NULL;
		
		// Loop para recorrer el string de entrda e ir separandolo por palabras
		// almacenandolo en una cola
		for (loop = 0; loop<=strlen(inStr); loop++)
		{
		
			if ((inStr[loop] == ' ' || strlen(inStr) == loop) && space == 1) 
			{
				
				// En una cola va agregan palabra por palabra
				wordAct =FNC_malloc(sizeof(wordString));
				sprintf(wordAct->word,"%s", word);
				wordAct->next = NULL;
				
				if ( wordEnd == NULL)
					wordEnd=wordStart=wordAct;
				else {
					wordEnd->next = wordAct;
					wordEnd=wordAct;
				}
				space = 0;
				sprintf(word, "");
			} else {
				if (inStr[loop] != ' ') {
					preWord[0] = inStr[loop];
					preWord[1] = '\0';
					sprintf(word ,"%s%s", word, preWord);
					space = 1;
				}
			}
			
		}
		
		// Apunta la cola al inicio de la misma, para recorrerla y realizar la clasificacion
		wordAct = wordStart;
		sprintf(a,"");
		
		// Nueva regla de tipoficacion, el valor es definido por un parametro
		// con a se maneja el valor actual, type = 1, GE
		if (strcmp(tipificacion,"VIA") == 0)
			sprintf (TYPEDIRECTION, "GE");
		else {
			if (strcmp(tipificacion,"MANZANA") == 0)
				sprintf (TYPEDIRECTION, "MZ");
			else {
				if (strcmp(tipificacion,"RURAL") == 0)
					sprintf (TYPEDIRECTION, "KM");
			}
		}
				
		// Apunta la cola al inicio de la misma, para recorrerla y realizar la clasificacion
		wordAct = wordStart;
		sprintf(a,"");
		
		// Recorre la cola palabra por palabra para la clasificacion, 
		// con a se maneja el valor actual, con b, el siguiente y con
		// con c el siguiente del siguiente.
		
		if (strcmp(TYPEDIRECTION, "NO") != 0)
		{
		
			while (wordAct != NULL) 
			{
				
				// Validacion para cambiar CS por CL cuando la tipificacion indica que es MZ
				// y cumplie con la siguiente regla %s [0-9]{1,3}[A-Z� ]{0,7}[0-9]{1,3}[A-Z� ]{0,7}[0-9]{1,3}
				if (strcmp(TYPEDIRECTION, "MZ") == 0
						&& strcmp(wordAct->word, "CS") == 0
						&& valExpRegStr(inStr, "CS [0-9]{1,3} [A-Z� ]{0,7}[0-9]{1,3} [A-Z� ]{0,7}[0-9]{1,3}") == 1
						&& siCSaCL == 0)
				{
	
					regexp(inStr," [0-9]{1,3} [A-Z� ]{0,7}[0-9]{1,3} [A-Z� ]{0,7}[0-9]{1,3}",&begin,&end, match);
					
					if (validateWordNomenclature (match, listSessionStart) == 0)
					{
						sprintf(wordAct->word , "CL");
						siCSaCL=1;
					}
				}
					
				sprintf(a , "%s",  wordAct->word);
				sprintf(b,"");
				sprintf(c,"");
				sprintf(d,"");
							
				if (wordAct->next != NULL)
					sprintf( b, "%s", wordAct->next->word);
				
				if (strcmp(b, "") != 0 && wordAct->next->next != NULL)
					sprintf(c,"%s", wordAct->next->next->word);
				
				if (strcmp(c, "") != 0 && wordAct->next->next->next != NULL)
					sprintf(d,"%s", wordAct->next->next->next->word);
				
				/*if (strcmp(TYPEDIRECTION, "MZ") == 0) 
					classificationMz(a, b, listSessionStart);
				else */classificationSessions(inCity, a, b, c, d, listSessionStart); 
	 
				wordAct = wordAct->next;
			} 
			
			sprintf(IND_HUERFANO_TP, "");
			
			//Arma la direccion de acuerdo al parametro type
			switch (type)
			{
				case 1:
					sprintf (Complemento, "");
					sprintf (outStr, "");
					sprintf (outTMP, "");
					toDirectionCola(outTMP, inMaxRoad, dane);
					ListGetValByIdx(outTMP, "&", 1, Complemento);
					
					if (strcmp(Complemento, "") == 0)
						sprintf(outStr,"%s&&%s&&&&&NO VALIDA", inStr, tipificacion);
					else sprintf (outStr, "%s", outTMP);
					
					
					sprintf(Complemento, "");
					sprintf (outTMP, "");
					
					//sprintf (outStr, "PRUEBAS - %s : %s TYPEDIRECTION:%s", PASO, DirectionStart, TYPEDIRECTION);
					//sprintf (outStr, "PRUEBAS: %s", PASO);
					//sprintf (outStr, "PRUEBAS");
					break;
					
				case 2:
					sprintf(outStr,"");
					decomAddressIntoMoreAddresses(outStr, inMaxRoad, dane);
					break;
					
				case 3: // Valor empleado en Similitud de direcciones tipo VIA
					//Define variables	
					sprintf (Complemento, "");
					sprintf (outStr, "");
					sprintf (outTMP, "");
					
					toDirectionCola(outTMP, inMaxRoad, dane);
					ListGetValByIdx(outTMP, "&", 2, Complemento);
							
					Direction = DirectionStart;
					//sprintf(outStr, "");
					// Formatea Salida
					sprintf (outStr, "%s|%s|%s|%s|%s|%s|%s|%s"
								, Direction->session // 1
								, Direction->NUMVIAPPAL // 2
								, Direction->MODVIAPPAL // 3
								, Direction->NUMVIAGEN // 4
								, Direction->MODVIAGEN // 5
								, Direction->NUMPLACA // 6
								, CUADRANTE // 7
								, Complemento); //8
								
					//sprintf(outStr, "%s - ORI:.%s", Complemento, outTMP);
					sprintf(Complemento, "");
					sprintf (outTMP, "");
					break;
			}
		} else{
			if (strcmp(ValAddress, "") == 0)
				sprintf (ValAddress, "&NO VALIDA");
			sprintf(outStr,"%s&&%s&&&&%s", inStr, tipificacion,ValAddress); // Version 3, la ubicacion se marca como DESCRITIVA
		}
		
		free(match);
		
		//Libera memoria
		while (wordStart != NULL)
		{
			wordAct = wordStart;
			wordStart = wordStart->next;
			
			FNC_free(wordAct);
		}
		
		// Limpieza de variables globales
		free(TYPEDIRECTION);
		free(SESIONACTUAL);
		free(NOMENCLATURA);
		free(VALOR);
		free(HUERFANOS);
		free(HUERFANOV);
		free(CUADRANTE);
		free(COMPVIA);
		free(PASO);
		// Control de cambio Julio
		free(IND_HUERFANO_TP);
		// End
		
		FNC_free(BREACHPAR);
		FNC_free(ORIGINTVP);
		
		word[0] = '\0';
		preWord[0] = '\0';
		a[0] = '\0';
		b[0] = '\0';
		c[0] = '\0';
				
		while (DirectionStart != NULL)
		{
			Direction = DirectionStart;
			DirectionStart = DirectionStart->next;
			
			FNC_free(Direction);
	
		}
		
		while (listSessionStart)
		{
			listSession = listSessionStart;
			listSessionStart = listSessionStart->next;
			
			FNC_free(listSession);
		}
		

	} else {
		if (strcmp(ValAddress, "") == 0)
			sprintf (ValAddress, "&NO VALIDA");
		
		sprintf(outStr,"%s&&%s&&&&%s", inStr, tipificacion, ValAddress); // Version 3, la ubicacion se marca como DESCRITIVA
		
	}
	
	free(ValAddress);

}
