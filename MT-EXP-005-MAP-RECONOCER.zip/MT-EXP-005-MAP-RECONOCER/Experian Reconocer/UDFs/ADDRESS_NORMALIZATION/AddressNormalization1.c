/*
 * ################################################################################
 * 
 * Objetivo:	  Funcion AddressNormalization1 para descomponer el string de entrada
 * 		  (direccion) en palabras e ir normalizandola y ordenandola de acuerdo
 *		  a las reglas enviadas por Experian
 * Fecha:	  2016/10/14
 * Realizado por: Luis E Ramirez (Capgemini)
 * Parametros:	  inStr, inCity, outStr
 * Proyecto:	  Experian - Reconocer
 * Script:	  AddressNormalization1.c
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha	Objetivo				Realizado por
 * 2016/12/15	Implementacion de manejo de tuplas con	Luis E. Ramirez
 *		el fin de detectar particulas y valores
 *		huerfanos
 * 2018/02/28	Se quita la logica de tipificacion, el 
 *		nuevo valor viene por un parametro	Cagemini
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */
#include <stdio.h>
#include <string.h>                   
#include <ctype.h>
#include <stdlib.h>
#include "AddressNormalization.h"
#include "operationsString.h"


//Define variables

// Funcion referenciada por Teradata
void AddressNormalization1 (
		VARCHAR_LATIN *inStr,
		VARCHAR_LATIN *inCity,
		INTEGER *inMaxRoad,
		VARCHAR_LATIN *inDane,
		VARCHAR_LATIN *inTipificacion,
		VARCHAR_LATIN *outStr,
		SQL_TEXT extname[129],
		SQL_TEXT specific_name[129],
		SQL_TEXT error_message[257])
{		
	
	sprintf (outStr, "PRU");
	
	//type = 1, normalizacion
	Address_Normalization(inStr, inCity, outStr, *inMaxRoad, 1, inDane, inTipificacion);
	//sprintf (outStr, "INI: - FIN: %s", inStr);
		
}
