#define SQL_TEXT Latin_Text
#include "sqltypes_td.h"
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#include <regex.h>
#include <ctype.h>

void isNumeric(VARCHAR_LATIN  *texto,
               VARCHAR_LATIN  *outSalida,
			   SQL_TEXT extname[129],
			   SQL_TEXT specific_name[129],
			   SQL_TEXT error_message[257],
			   char sqlstate[6])
{ 
 char  cadena[200];
 int lenDato = strlen(texto);
 strcpy(cadena, texto );
 int i=0; 
 int res=1; 
 char aux1[200];
 strcpy (aux1,"1"); 
 while(i<lenDato){	 
	 if(isdigit(cadena[i]) == 0 ) {
	  res=0;
	  strcpy (aux1,"0"); 
	  break;
	  
	 }
	i++;
 }     
 sprintf(outSalida,aux1); 
}
