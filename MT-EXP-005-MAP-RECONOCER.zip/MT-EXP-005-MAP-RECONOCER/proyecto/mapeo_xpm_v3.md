# Mapeo XPM v3: JSON Real (xpm_john.json) → Campos Reconocer

> Mapeo basado en el análisis directo del JSON de XPM para persona natural (pin 7962867).
> Versión anterior (v2) se basaba en el sandbox de Redshift. Esta versión mapea contra la estructura JSON real que entrega la API de XPM.
> Fecha: 2026-05-XX | Autor: Equipo Macondotek
> **Actualización 2026-06-03**: Respuesta de Experian/EDF sobre los 8 gaps críticos incorporada (ver sección 3.3)
> **Actualización 2026-06-09**: Equipo de Estandarización confirma que entregará campos desagregados (Tipo_Via, Via_Principal, Via_Generadora, Numero_Puerta, Complemento). Solo queda pendiente Lat/Long.

---

## 1. Resumen del XPM (Estructura JSON)

El JSON de XPM (`xpm_john.json`) es la respuesta de la API de Experian para una persona natural. Contiene:

| Sección | Descripción | Registros (ejemplo) |
|---------|-------------|---------------------|
| **Raíz** | Identificadores de persona: `pin`, `pinScore`, `xpmVersion` | 1 |
| **bestName** | Mejor nombre consolidado | 1 |
| **bestPersonalInformation** | Mejor info personal (edad, género, estado civil, nacionalidad) | 1 |
| **bestAccounts[]** | Cuentas/obligaciones financieras con historial de comportamiento | 34 |
| **location[]** | Ubicaciones reportadas con datos de contacto (dirección, tel, email) | 30 |
| **counterparties[]** | Suscriptores/entidades que reportan datos | 18 |
| **identifications[]** | Documentos de identidad reportados | 51 |
| **personalInformation[]** | Información personal por suscriptor | 22 |
| **legal[]** | Información legal/jurídica | 34 |

### Campos raíz del JSON:
- `pin` (INTEGER): 7962867 — **Identificador PIN de la persona**
- `pinScore` (INTEGER): 205
- `xpmVersion` (DECIMAL): 4.11
- `generation` (TIMESTAMP): fecha de generación
- `countOfSubscriberCodes` (INTEGER): 65
- `countOfUniqueSSR` (INTEGER): 36

---

## 2. Mapeo Exitoso — Campos Encontrados en XPM JSON

### 2.1 Identificadores de Persona

| Campo Teradata | Sección XPM | Campo XPM | Tipo | Estado | Notas |
|---------------|-------------|-----------|------|--------|-------|
| `Cod_Pin_Persona` | Raíz | `pin` | INTEGER | ✅ Confirmado | Valor: 7962867. Identificador único de persona |
| `Num_Ident` | bestAccounts[] | `personIdNumber` | VARCHAR | ✅ Confirmado | Número de documento del titular |
| `Cod_Tipo_Ident_Fte` | bestAccounts[] | `personIdType` | VARCHAR | ✅ Confirmado | Tipo de documento (CC, CE, NI, etc.) |

### 2.2 Cuentas (bestAccounts[] → VU_CUENTA)

| Campo Teradata | Sección XPM | Campo XPM | Tipo | Estado | Notas |
|---------------|-------------|-----------|------|--------|-------|
| `Num_Cta` | bestAccounts[] | `accountNumber` | VARCHAR | ✅ Directo | Número de cuenta |
| `Cod_Tipo_Cta_Fte` | bestAccounts[] | `accountType` | VARCHAR | ✅ Directo | Tipo de cuenta |
| `Fecha_Apertura` | bestAccounts[] | `accountOpeningDate` | DATE | ✅ Directo | Fecha apertura |
| `Fecha_Nov` | bestAccounts[] | `cutoffDate` | DATE | ✅ Directo | Fecha de corte/novedad |
| `Fecha_Vencimiento` | bestAccounts[] | `expiryDate` | DATE | ✅ Directo | Fecha vencimiento |
| `Cod_Entrega_Dato_Fte` | bestAccounts[] | `businessLineCode` | VARCHAR | ✅ Directo | Código suscriptor/entrega dato |
| `Nit_Suscriptor` | bestAccounts[] | `counterpartyIdNumber` | VARCHAR | ✅ Directo | NIT del suscriptor |
| `Ind_Moneda_Legal` | bestAccounts[] | `currencyType` | VARCHAR | ✅ Directo | Indicador moneda |
| `Cod_DW_Franquicia` | bestAccounts[] | `franchise` | VARCHAR | ✅ Directo | Franquicia (VISA, MC, etc.) |
| `Cod_Clase_Garantia_Buro_Fte` | bestAccounts[] | `guaranteeType` | VARCHAR | ✅ Directo | Clase de garantía |
| `Cod_Tipo_Obligacion_Fte` | bestAccounts[] | `typeOfCredit` | VARCHAR | ✅ Directo | Tipo de obligación (fuente) |
| `Cod_Tipo_Rel_Con_Cta_Fte` | bestAccounts[] | `typeOfDebtor` | VARCHAR | ✅ Directo | Tipo relación con cuenta (P/C/D) |
| `Cod_Natu_Cta_Fte` | bestAccounts[] | `typeOfData` | INTEGER | ✅ Directo | 1=Activo, 2=Pasivo |
| `Cod_Est_Mod_Fte` | bestAccounts[] | `modificationIndicator` | VARCHAR | ✅ Directo | Estado modificación |
| `Num_Cuotas_Pactadas` | bestAccounts[] | `totalNumberOfInstallments` | INTEGER | ✅ Directo | Cuotas pactadas |
| `Cod_Tipo_Obligacion` (paymentType) | bestAccounts[] | `paymentType` | VARCHAR | ✅ Directo | Tipo pago |
| `Nombre_Ciudad_Radicacion` | bestAccounts[] | `filingCityName` | VARCHAR | ✅ Directo | Ciudad radicación |
| `Cod_Marca_Privada_Fte` | bestAccounts[] | `privateBrandName` | VARCHAR | ✅ Directo | Marca privada |
| `Cod_Clase_Tarjeta_Credito_Fte` | bestAccounts[] | `cardClass` | VARCHAR | ✅ Directo | Clase tarjeta |
| `Num_Plastico` | bestAccounts[] | `cardNumber` | VARCHAR | ✅ Directo | Número plástico |
| `Cod_Motivo_Bloqueo_Fte` | bestAccounts[] | `blockReason` | VARCHAR | ✅ Directo | Motivo bloqueo |
| `Cod_Tipo_Bloqueo_Fte` | bestAccounts[] | `blockSeverity` | VARCHAR | ✅ Directo | Severidad bloqueo |
| `Cod_Est_Suscriptor_Fte` | bestAccounts[] | `subscriberBlockStatus` | VARCHAR | ✅ Directo | Estado suscriptor |

### 2.3 Comportamiento Activo (bestAccounts[].frequentBehaviour[] donde typeOfData=1)

| Campo Teradata | Sección XPM | Campo XPM | Tipo | Estado | Notas |
|---------------|-------------|-----------|------|--------|-------|
| `Fecha_Nov` (comportamiento) | frequentBehaviour[] | `behaviourDate` | DATE | ✅ Directo | Fecha del comportamiento |
| `Valor_Disponible` | frequentBehaviour[] | `availableBalance` | DECIMAL | ✅ Directo | Cupo disponible |
| `Valor_Saldo` | frequentBehaviour[] | `debtBalance` | DECIMAL | ✅ Directo | Saldo actual |
| `Numero_Dias_Mora` | frequentBehaviour[] | `delinquencyMaturation` | INTEGER | ✅ Directo | Días en mora |
| `Valor_Inicial` | frequentBehaviour[] | `initialValue` | DECIMAL | ✅ Directo | Valor inicial crédito |
| `Num_Cuotas_Mora` | frequentBehaviour[] | `installmentsOverdue` | INTEGER | ✅ Directo | Cuotas en mora |
| `Num_Cuotas_Pagadas` | frequentBehaviour[] | `paidInstallments` | INTEGER | ✅ Directo | Cuotas pagadas |
| `Cod_Calif_Comp_Cta_Fte` | frequentBehaviour[] | `rating` | CHAR | ✅ Directo | Calificación (A-E) |
| `Valor_Saldo_Mora` | frequentBehaviour[] | `valueBalanceOverdue` | DECIMAL | ✅ Directo | Saldo en mora |
| `Valor_Cuota_Mensual` | frequentBehaviour[] | `valueMonthlyPayment` | DECIMAL | ✅ Directo | Cuota mensual |

### 2.4 Comportamiento Pasivo (bestAccounts[].frequentBehaviour[] donde typeOfData=2)

| Campo Teradata | Sección XPM | Campo XPM | Tipo | Estado | Notas |
|---------------|-------------|-----------|------|--------|-------|
| `Fecha_Nov` (comportamiento) | frequentBehaviour[] | `behaviourDate` | DATE | ✅ Directo | Fecha del comportamiento |
| `Valor_Creditos_Efec` | frequentBehaviour[] | `totalCashCredits` | DECIMAL | ✅ Directo | Créditos en efectivo |
| `Valor_Debitos_Efec` | frequentBehaviour[] | `totalCashDebits` | DECIMAL | ✅ Directo | Débitos en efectivo |
| `Valor_Creditos_Transf` | frequentBehaviour[] | `totalCreditTransfer` | DECIMAL | ✅ Directo | Créditos transferencia |
| `Valor_Debitos_Transf` | frequentBehaviour[] | `totalDebitTransfer` | DECIMAL | ✅ Directo | Débitos transferencia |

### 2.5 Ubicaciones (location[] → RELACION_PERSONA_UBICACION)

| Campo Teradata | Sección XPM | Campo XPM | Tipo | Estado | Notas |
|---------------|-------------|-----------|------|--------|-------|
| `Texto_Ubicacion` | location[].contactInformations[] | `contactAsReported` | VARCHAR | ✅ Directo | Dirección/teléfono/email como texto |
| `Cod_DW_Tipo_Ubicacion` | location[].contactInformations[] | `contactType` | VARCHAR | ✅ Directo | Tipo contacto (dirección, tel, cel, email) |
| `Fecha_Relacion_Persona_Ubicaci` | location[] | `locationFirstEventDate` | DATE | ✅ Directo | Primera fecha del evento |
| `Fecha_Ultima_Actualizacion` | location[].contactInformations[] | `contactEventLastUpdated` | DATE | ✅ Directo | Última actualización |
| `Nombre_Ciudad` | location[].contactInformations[] | `cityName` | VARCHAR | ✅ Directo | Ciudad |

### 2.6 Suscriptores (counterparties[] → REPORTE_RELACION_PERSONA_UBICA)

| Campo Teradata | Sección XPM | Campo XPM | Tipo | Estado | Notas |
|---------------|-------------|-----------|------|--------|-------|
| `Nit_Suscriptor` | counterparties[] | `counterpartyIdNumber` | VARCHAR | ✅ Directo | NIT suscriptor |
| `Cod_Entrega_Dato_Fte` | counterparties[].businessLines[] | `businessLineCode` | VARCHAR | ✅ Directo | Línea de negocio |

---

## 3. Gaps Críticos — Campos NO Encontrados en XPM JSON

### 3.1 Gaps Bloqueantes

| # | Campo Teradata | Proceso | Regla | Impacto | Alternativa Propuesta |
|---|---------------|---------|-------|---------|----------------------|
| 1 | **`Id_Buro_Persona`** | Ordenamiento + Unificación | R1,R2,R3 | ✅ RESUELTO. Se genera internamente en los SPs de Redshift. Experian confirma que EDF no lo calcula ni lo entrega. | Generar en Redshift mediante lógica en SPs. Usar `pin` como base o crear secuencia propia. Decisión técnica de Macondotek. |
| 2 | **`Latitud`** | Unificación R3, Ordenamiento F3 | R3 | 🔴 BLOQUEANTE. Confirmado por Experian: EDF NO genera este campo. Depende del proceso de Georreferenciación que está siendo evaluado por el equipo de Arquitectura de Experian. | Contactar a **Adriana Rondón** para estado actual de Georreferenciación. Sin este dato, Regla 3 y Fase 3 son inviables. |
| 3 | **`Longitud`** | Unificación R3, Ordenamiento F3 | R3 | 🔴 BLOQUEANTE. Mismo caso que Latitud. EDF no lo genera. Depende de Georreferenciación (Arquitectura Experian). | Mismo que Latitud. Contactar Adriana Rondón. |
| 4 | **`Complemento`** (separado) | Unificación R1, R2 | R1,R2 | ✅ RESUELTO (2026-06-09). Equipo de Estandarización confirma que entregará el complemento como campo separado en el XPM. | Mapeo directo desde campo desagregado que entrega Estandarización. |
| 5 | **`Tipo_Via_Principal`** | Unificación R3 | R3 | ✅ RESUELTO (2026-06-09). Estandarización lo entrega como campo separado. | Mapeo directo. |
| 6 | **`Via_Generadora`** | Unificación R3 | R3 | ✅ RESUELTO (2026-06-09). Estandarización lo entrega como campo separado. | Mapeo directo. |
| 7 | **`Numero_Puerta`** | Unificación R3 | R3 | ✅ RESUELTO (2026-06-09). Estandarización lo entrega como campo separado. | Mapeo directo. |
| 8 | **`Cod_Act_Econo_CIIU_Fte`** | Unificación R1 | R1 | ✅ RESUELTO. Confirmado por Experian: viene en `bestPersonalInformation.mainIsicCodeForProduct`. | Mapeo directo. El campo no estaba visible en el JSON de ejemplo pero Experian confirma que existe en la sección `bestPersonalInformation`. |

### 3.2 Gaps de Datos Derivados

| # | Campo Teradata | Proceso | Impacto | Alternativa Propuesta |
|---|---------------|---------|---------|----------------------|
| 9 | `Cod_DW_Municipio` | Unificación R2 | 🟡 Solo existe `cityName` en contactInformations. No hay código DANE. | Crear tabla de mapeo `cityName` → código DANE. O solicitar `cityCode` numérico a Experian. |
| 10 | `Urbanizacion_Barrio` | Ordenamiento F3 | 🟡 No existe como campo separado. Puede estar dentro de `contactAsReported`. | Extraer con parsing o solicitar a EDF. |
| 11 | `Dominio` (email) | Ordenamiento F4 | 🟡 No existe separado. El email viene completo en `contactAsReported`. | Derivar con `SPLIT_PART(contactAsReported, '@', 2)` en Redshift. Trivial. |
| 12 | `Direccion_Electronica` | Ordenamiento F4 | 🟡 Viene como `contactAsReported` cuando `contactType` = email. | Filtrar por `contactType`. Mapeo directo. |

### 3.3 Respuesta Oficial de Experian/EDF (2026-06-03)

Se recibió respuesta del equipo EDF de Experian a los 8 gaps reportados. Resumen:

| # | Campo | Veredicto Experian | Estado Resultante |
|---|-------|-------------------|-------------------|
| 1 | `id_buro_persona` | **No se calcula en EDF.** Debe generarse en los SPs de Reconocer (Redshift). Decisión técnica nuestra. | ✅ Resuelto — lo generamos nosotros |
| 2-3 | `Latitud` / `Longitud` | **EDF no los genera.** Depende del proceso de Georreferenciación, actualmente en evaluación por Arquitectura Experian. | 🔴 Pendiente — contactar **Adriana Rondón** |
| 4-7 | `Complemento`, `Tipo_Via`, `Via_Generadora`, `Numero_Puerta` | **Equipo de Estandarización confirma (2026-06-09) que entregará estos campos desagregados en el XPM.** | ✅ Resuelto — Estandarización los entrega |
| 8 | `CIIU` (`Cod_Act_Econo_CIIU_Fte`) | **SÍ existe.** Campo `bestPersonalInformation.mainIsicCodeForProduct` | ✅ Resuelto — mapeo directo |

#### Decisiones y Próximos Pasos

| Acción | Responsable | Prioridad | Fecha Límite |
|--------|-------------|-----------|--------------|
| ~~Definir estrategia para `id_buro_persona`~~ | Macondotek | ✅ Hecho | — |
| Contactar a Adriana Rondón sobre estado de Georreferenciación | Macondotek/Experian | 🔴 Alta | Inmediato |
| ~~Solicitar sesión sobre estandarización de direcciones~~ | ~~Macondotek/Experian~~ | ✅ Hecho (2026-06-09) | — |
| ~~Evaluar si replicar UDF ADDRESS_NORMALIZATION~~ | ~~Macondotek~~ | ✅ No necesario — Estandarización lo resuelve | — |
| Agregar `mainIsicCodeForProduct` al mapeo de campos de ingesta | Macondotek | ✅ Hecho | — |
| Confirmar formato exacto de campos desagregados con equipo Estandarización | Macondotek/Experian | 🟡 Media | Por definir |

---

## 4. Surrogate Keys (Cod_DW_*) — NO Existen en XPM

Todos los campos `Cod_DW_*` son **llaves subrogadas internas del Data Warehouse de Teradata**. No existen ni deben existir en el JSON de XPM. Se generan internamente en Redshift.

| Campo Teradata | Clasificación | Estrategia en Redshift |
|---------------|--------------|----------------------|
| `Cod_DW_Cta` | Surrogate key de cuenta | `ROW_NUMBER()` o `IDENTITY` sobre bestAccounts |
| `Cod_DW_Persona_Ubic` | Surrogate key relación persona-ubicación | `ROW_NUMBER()` sobre location[].contactInformations[] |
| `Cod_DW_Ubic` | Surrogate key de ubicación | `ROW_NUMBER()` sobre ubicaciones únicas |
| `Cod_DW_Direccion_Fisica` | Surrogate key dirección física | `ROW_NUMBER()` sobre direcciones únicas |
| `Cod_DW_Direccion_Electronica` | Surrogate key email | `ROW_NUMBER()` sobre emails |
| `Cod_DW_Telefono` | Surrogate key teléfono | `ROW_NUMBER()` sobre teléfonos |
| `Cod_DW_Doc_Ident` | FK a identidad | Mapear a `personIdNumber` + `personIdType` |
| `Cod_DW_Tipo_Ubicacion_Dir` | FK a catálogo tipo uso | Mapear a `contactType` del JSON |
| `Cod_DW_Tipo_Cta` | FK a catálogo tipo cuenta | Mapear a `accountType` del JSON |
| `Cod_DW_Tipo_Obligacion` | FK a catálogo tipo obligación | Mapear a `typeOfCredit` del JSON |
| `Cod_DW_Clase_Cta` | FK a catálogo clase cuenta | Mapear a `subAccountType` del JSON |
| `Cod_DW_Franquicia` | FK a catálogo franquicia | Mapear a `franchise` del JSON |
| `Cod_DW_Natu_Cta` | FK a naturaleza cuenta | Mapear a `typeOfData` (1=Activo, 2=Pasivo) |
| `Cod_DW_Tipo_Rel_Con_Cta` | FK a tipo relación | Mapear a `typeOfDebtor` del JSON |
| `Cod_DW_Razon_Bloqueo` | FK a razón bloqueo | Mapear a `blockReason` del JSON |
| `Cod_DW_Tipo_Bloqueo` | FK a tipo bloqueo | Mapear a `blockSeverity` del JSON |
| `Cod_DW_Est_Mod` | FK a estado modificación | Mapear a `modificationIndicator` del JSON |
| `Cod_DW_Est_Suscriptor` | FK a estado suscriptor | Mapear a `subscriberBlockStatus` del JSON |
| `Cod_DW_Entrega_Dato` | FK a entrega dato | Mapear a `businessLineCode` del JSON |
| `Cod_DW_Fte_Dato` | FK a fuente dato | Derivar de `businessLineCode` + catálogo Colibrí |
| `Cod_DW_Pais` | FK a país | Hardcode Colombia o derivar de `nationalityCode` |
| `Cod_DW_Motivo_Origen` | FK a motivo origen | Mapear a `originStatusOfAccount` del JSON |
| `Cod_DW_Ciudad` | FK a ciudad | Mapear a `cityName` + catálogo DANE |
| `Cod_DW_Fuente` | FK a fuente | Derivar de `businessLineCode` |
| `Cod_DW_Gestion_Registro` | FK a gestión registro | Derivar de lógica de validación |
| `Cod_DW_Reporte_Persona_Ubic` | Surrogate key reporte | `ROW_NUMBER()` en Redshift |
| `Cod_DW_Matricula` | FK a matrícula | Verificar con Experian |
| `Cod_DW_Hash` | Hash de cambios | Calcular con `MD5()` o `SHA2()` en Redshift |

### Patrón de generación:

```sql
-- Teradata (patrón original con MAX_ID):
SELECT (SELECT ID FROM REC_MTDAT.MAX_ID WHERE NOMBRE_TABLA='X') 
       + SUM(1) OVER (ROWS UNBOUNDED PRECEDING) AS Cod_DW_X

-- Redshift (equivalente):
ROW_NUMBER() OVER (ORDER BY <criterio>) + <offset_inicial> AS cod_dw_x
```

---

## 5. Recomendaciones para Experian / Sesión con IDF

### 5.1 Preguntas Bloqueantes (resolver antes de implementar)

| # | Pregunta | Contexto | Estado |
|---|----------|----------|--------|
| 1 | ~~¿El JSON de XPM incluye `id_buro_persona`?~~ | ✅ RESPONDIDO: No viene de EDF. Se genera en SPs de Redshift. Decisión técnica nuestra. | ✅ Cerrado |
| 2 | **¿Cuándo estará listo el proceso de Georreferenciación?** | Confirmado: EDF no genera Lat/Long. Depende de Arquitectura Experian. Contactar a **Adriana Rondón**. | 🔴 Pendiente |
| 3 | ~~¿EDF va a entregar los componentes de dirección separados?~~ | ✅ RESPONDIDO (2026-06-09): Equipo de Estandarización confirma que entregará Tipo_Via, Via_Principal, Via_Generadora, Numero_Puerta y Complemento como campos separados. | ✅ Cerrado |
| 4 | **¿`contactType` en el JSON usa qué valores?** | Necesitamos saber si distingue: dirección residencial, laboral, correspondencia, teléfono fijo, celular, email. | 🟡 Pendiente (no preguntado) |
| 5 | ~~¿El CIIU viene en el JSON para todas las personas?~~ | ✅ RESPONDIDO: Está en `bestPersonalInformation.mainIsicCodeForProduct`. | ✅ Cerrado |

### 5.2 Preguntas de Prioridad Media

| # | Pregunta | Contexto |
|---|----------|----------|
| 6 | ¿`cityName` en contactInformations corresponde al municipio DANE? ¿Hay código numérico? | Necesitamos código para JOINs con catálogo de geografía. |
| 7 | ¿`subscriberBlockStatus` y `blockReason` en location[] equivalen al concepto de BLOQUEO de Teradata? | Necesitamos saber si un dato bloqueado se excluye de Unificación/Ordenamiento. |
| 8 | ¿Los campos de fecha en el JSON son epoch (BIGINT) o strings ISO? | En el sandbox eran BIGINT epoch. En el JSON podrían ser diferentes. |
| 9 | ¿`pinScore` (205) es el score de Experian o es un campo interno? | No lo usamos en Reconocer pero conviene documentar. |
| 10 | ¿Hay campos adicionales en `frequentBehaviour[]` para cuentas pasivas? (cheques devueltos, sobregiro) | En Teradata existían `Cantidad_Cheques_Devs`, `Dias_Sobregiro_Aut`, etc. No los vemos en el JSON. |

### 5.3 Propuesta de Contrato de Datos con IDF

Basado en los gaps, el contrato de datos que Reconocer necesita de IDF/EDF debe incluir:

```
DATOS QUE DEBEN LLEGAR DE IDF/EDF (no están en XPM crudo):
─────────────────────────────────────────────────────────
1. Latitud / Longitud          → Proceso de Georreferenciación (en evaluación por Arquitectura Experian, contactar Adriana Rondón)
2. Código DANE municipio       → Catálogo de geografía
3. Flag de bloqueo por dato    → Reclamación 2.0

DATOS CONFIRMADOS EN XPM (resueltos):
─────────────────────────────────────
1. CIIU                        → bestPersonalInformation.mainIsicCodeForProduct ✅
2. Tipo_Via                    → Estandarización lo entrega desagregado ✅ (2026-06-09)
3. Via_Principal               → Estandarización lo entrega desagregado ✅ (2026-06-09)
4. Via_Generadora              → Estandarización lo entrega desagregado ✅ (2026-06-09)
5. Numero_Puerta               → Estandarización lo entrega desagregado ✅ (2026-06-09)
6. Complemento                 → Estandarización lo entrega desagregado ✅ (2026-06-09)

DATOS QUE SE GENERAN INTERNAMENTE EN REDSHIFT:
──────────────────────────────────────────────
1. id_buro_persona             → Generar en SPs de Redshift (confirmado por Experian que NO viene de EDF)
2. Todos los Cod_DW_* (surrogate keys)
3. Ind_Unificacion, Unifica_Atributos, Fecha_Unificacion
4. Lote, Lote_Actualizacion
5. Orden_Prioridad (resultado del scoring)
6. Hashes de cambio (V_CUENTA_ATRIBUTO_HASH, V_UBICACION_ATRIBUTO_HASH)
7. Dominio de email (derivado de contactAsReported)
```

---

## 6. Resumen Cuantitativo

| Categoría | Cantidad | % |
|-----------|----------|---|
| ✅ Campos con mapeo directo exitoso | 50 | 57% |
| 🟡 Campos derivables (cálculo simple en Redshift) | 8 | 9% |
| ✅ Gaps resueltos (CIIU + id_buro_persona + Estandarización) | 6 | 7% |
| 🔴 Gaps pendientes (Lat/Long — Georreferenciación) | 2 | 2% |
| 🔧 Surrogate keys (se generan en Redshift) | 18 | 21% |
| 📋 Catálogos (vienen de Collibra) | 5 | 6% |
| **Total campos analizados** | **87** | **100%** |

> **Nota**: De los 8 gaps originales, **6 fueron resueltos**: CIIU (Experian confirmó campo), id_buro_persona (se genera en SPs), y 4 campos de estandarización (equipo confirma entrega desagregada 2026-06-09).
> Los **2 restantes** (Latitud/Longitud) dependen exclusivamente del proceso de Georreferenciación (contactar Adriana Rondón).

### Viabilidad por proceso:

| Proceso | Fase | Viabilidad con XPM actual | Bloqueante | Estado post-respuesta Experian |
|---------|------|--------------------------|------------|-------------------------------|
| Ordenamiento | Fase 1 (Materialización) | ✅ Viable | — | ✅ Sin cambios |
| Ordenamiento | Fase 2 (Atributos cuenta) | ✅ Viable | — | ✅ Sin cambios |
| Ordenamiento | Fase 3 (Ubicaciones/Scoring) | ⚠️ Parcial | Latitud/Longitud | 🔴 Depende de Geo (Adriana Rondón) |
| Ordenamiento | Fase 4 (Scoring) | ✅ Viable (si F3 se resuelve) | — | ⚠️ Condicionado a F3 |
| Unificación | Regla 1 (Tipo uso) | ✅ Viable | — | ✅ CIIU + Estandarización resueltos |
| Unificación | Regla 2 (Complemento) | ✅ Viable | — | ✅ Estandarización entrega complemento separado |
| Unificación | Regla 3 (Vía generadora) | ⚠️ Parcial | Lat/Long | ⚠️ Estandarización resuelto, solo falta Geo |

---

*Documento generado a partir del análisis directo de `xpm_john.json` (persona natural, pin 7962867, 34 cuentas, 30 ubicaciones, 18 suscriptores).*
*Complementa y actualiza `ws-unificacion/docs/tecnico/mapeo_campos_xpm.md` (v2, basado en sandbox Redshift).*
