**Asunto:** Contrato de datos — Inputs requeridos para Reconocer (Unificación + Ordenamiento)

---

Hola equipo,

Con base en las sesiones que hemos tenido y las validaciones realizadas, consolidamos a continuación los campos que Reconocer necesita recibir como input para ejecutar los procesos de Unificación y Ordenamiento en el nuevo ambiente (Redshift).

Este documento busca formalizar el acuerdo sobre qué datos entrega EDF, qué datos entrega Georreferenciación y qué datos genera Reconocer internamente.

---

## 1. Campos que entrega EDF

Estos campos deben llegar disponibles para consumo de Reconocer.

### Datos de persona

| Campo | Tipo | Descripción | Sección XPM |
|-------|------|-------------|-------------|
| pin | INTEGER | Identificador único de persona | Raíz |
| mainIsicCodeForProduct | VARCHAR | Código CIIU (actividad económica) | bestPersonalInformation |

### Datos de cuenta (bestAccounts[])

| Campo | Tipo | Descripción |
|-------|------|-------------|
| accountNumber | VARCHAR | Número de cuenta |
| accountType | VARCHAR | Tipo de cuenta |
| typeOfCredit | VARCHAR | Tipo de obligación |
| typeOfDebtor | VARCHAR | Tipo relación con cuenta (P/C/D) |
| businessLineCode | VARCHAR | Código suscriptor |
| counterpartyIdNumber | VARCHAR | NIT suscriptor |
| accountOpeningDate | DATE | Fecha apertura |
| cutoffDate | DATE | Fecha de corte |
| behaviourDate | DATE | Fecha comportamiento |
| rating | CHAR | Calificación (A-E) |
| debtBalance | DECIMAL | Saldo actual |
| delinquencyMaturation | INTEGER | Días mora |

### Datos de ubicación (location[].contactInformations[])

| Campo | Tipo | Descripción |
|-------|------|-------------|
| contactAsReported | VARCHAR | Dirección/teléfono/email original |
| contactType | INTEGER | Tipo contacto (1=RES, 2=LAB, 3=CRR, 7=JUD, 8=CCL, 9=CEL, 10=EMAIL) |
| cityName | VARCHAR | Ciudad |
| contactEventLastUpdated | BIGINT | Fecha última actualización (epoch) |

### Campos de estandarización de dirección

| Campo | Tipo | Descripción | Ejemplo |
|-------|------|-------------|---------|
| tipo_via | VARCHAR(5) | Tipo de vía normalizado | CR, CL, TV, DG, AK |
| via_principal | VARCHAR(10) | Número de vía principal | 111A, 45, 72 |
| via_generadora | VARCHAR(10) | Número de vía cruzada | 148, 12, 13 |
| numero_puerta | VARCHAR(10) | Número de placa/puerta | 50, 33, 20 |
| complemento | VARCHAR(100) | Complemento separado (nomenclaturas) | AP 201 TO 3, OF 802, ED GALICIA |

---

## 2. Campos que entrega Georreferenciación

Estos campos dependen del proyecto de Georreferenciación (equipo de Arquitectura Experian).

| Campo | Tipo | Descripción |
|-------|------|-------------|
| latitud | DECIMAL(10,7) | Coordenada latitud de la dirección |
| longitud | DECIMAL(10,7) | Coordenada longitud de la dirección |

---

## 3. Campos que genera Reconocer internamente (en Redshift)

Estos campos NO se esperan del XPM. Los genera la lógica de los SPs de Reconocer.

| Campo | Descripción |
|-------|-------------|
| id_buro_persona | Identificador interno de persona (generado en SP) |
| Todos los Cod_DW_* | Surrogate keys (ROW_NUMBER en Redshift) |
| ind_unificacion | Flag resultado de Unificación |
| orden_prioridad | Score resultado de Ordenamiento |
| Hashes MD5 | Detección de cambios (cuenta_atributo_hash, ubicacion_atributo_hash) |
| Dominio email | Derivado con SPLIT_PART sobre contactAsReported |

---

## 4. Catálogos requeridos

Reconocer consume las siguientes tablas de referencia. Ya están identificadas y conocemos el proceso para cargarlas o consumirlas desde Collibra.

**Para Unificación:**
- `NOMENCLATURA` (nomenclatura, nivel_complemento)
- `V_Tipo_Ubicacion_Direccion` (cod_dw_tipo_ubicacion_dir, descripcion_tipo_ubicacion_dir)

**Para Ordenamiento:**
- `V_Razon_Bloqueo` (cod_dw_razon_bloqueo, cod_razon_bloqueo_fte)
- `V_Fuente_Dato` (cod_dw_fte_dato, cod_fte_dato_fte)
- `V_Cod_Entrega_Dato` (cod_dw_entrega_dato, fecha_ingreso_suscriptor)
- `V_Gestion_Registro` (cod_dw_gestion_registro, descripcion_gestion_registro)
- `V_Fuente` (cod_dw_fuente, descripcion_fuente)
- `V_Geografia` (cod_dw_ciudad, cod_dane_municipio, cod_dane_departamento)
- `V_Tipo_Persona` (cod_dw_tipo_persona, desc_tipo_persona)
- `V_Tipo_Cuenta` (cod_dw_tipo_cta, desc_tipo_cta)
- `V_Beta_Ordenamiento_Tel` (cod_caracteristica_fte, valor_beta)
- `V_Beta_Ordenamiento_Cel` (cod_caracteristica_fte, valor_beta)
- `V_Beta_Ordenamiento_Dir` (cod_caracteristica_fte, valor_beta)
- `V_Beta_Ordenamiento_Email` (cod_caracteristica_fte, valor_beta)
- `V_Operador_Ord_Cel` (cod_operador, valor)
- `V_Tipo_Cuenta_Ord` (cod_tipo_cta_fte, clasificación)

---

¿Algún ajuste o corrección sobre lo descrito? Con su confirmación cerramos este acuerdo como base para la integración.

Gracias,
Francisco Peña
