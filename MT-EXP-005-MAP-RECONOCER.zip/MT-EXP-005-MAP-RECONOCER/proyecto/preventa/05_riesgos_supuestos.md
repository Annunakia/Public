# Riesgos y Supuestos – EXPERIAN MAP RECONOCER

## Información General

| Campo | Valor |
|-------|-------|
| Cliente | Experian |
| Proyecto | Migración del Sistema Reconocer a AWS |
| Fecha | 2026-03-04 (actualizado 2026-03-19) |
| Versión | 1.2 |

---

## Resumen Ejecutivo

El proyecto presenta riesgos significativos debido a la complejidad técnica de la migración, la incertidumbre arquitectónica y los plazos ajustados. Se han identificado 43 riesgos principales, de los cuales 9 son CRÍTICOS y requieren atención inmediata. La dependencia de IFR y la estructura de tablas Redshift ≠ Teradata son los riesgos más críticos del proyecto.

**Actualización 26/03/2026**: El workshop técnico confirmó que la fuente de Contactabilidad OTP nunca se activó (R37 cerrado), que la geolocalización con Geolitics está desconectada (R41 nuevo, crítico), que los catálogos de estandarización son estáticos, y que el problema de suscriptores bloqueados en COBOL se resuelve con Data Fabric. Se identificaron 3 nuevos riesgos (R41-R43) y 4 nuevos supuestos (S34-S37).

**Actualización 25/03/2026**: La sesión de contexto funcional reveló que el producto tiene múltiples versiones (8 batch, 4 en línea, 2 microservicios) con estructuras de salida diferentes, que el canal batch usa Teradata directamente (no DB2 precalculado), y que existe una restricción legal crítica que impide mezclar datos del buró con datos de Nueva Data (ICS/Mi Data Crédito). Se identificaron 5 nuevos riesgos (R36-R40) y 5 nuevos supuestos (S29-S33).

**Actualización 19/03/2026**: La decisión sobre la etapa de estandarización en EDF fue resuelta (Curation, campo nuevo). PINNING no se toca. Esto reduce la exposición de R01 y elimina incertidumbre sobre la ubicación de la estandarización.

**Hallazgo importante**: El análisis técnico de alternativas de estandarización confirma que **Libpostal es la opción más viable** técnica y económicamente ($50-300 USD vs $1.6M+ de Google Maps API), pero requiere validación temprana de compatibilidad con el estándar colombiano DANE/DIVIPOLA.

---

## Matriz de Riesgos

### Riesgos Críticos (Probabilidad Alta + Impacto Alto)

| ID | Riesgo | Probabilidad | Impacto | Exposición | Mitigación | Contingencia | Responsable |
|----|--------|--------------|---------|------------|------------|--------------|-------------|
| R01 | **Rechazo de arquitectura por equipo de Experian** | Alta (70%) | Crítico | MUY ALTA | Workshop temprano (M1-M2), presentación de opciones con pros/contras, validación con XPMS | Replantear arquitectura, considerar OP2 (solo Redshift), extensión de plazo | Arquitecto + Gerente Proyecto |
| R02 | **Pérdida de calidad en estandarización vs sistema actual** | Alta (60%) | Crítico | MUY ALTA | Validación continua con Wilmar, pruebas comparativas, métricas de calidad, validación por muestreo | Ajuste de algoritmos, refinamiento de reglas, extensión de fase de estandarización | Líder Estandarización + QA |
| R03 | **Complejidad de migración de UDFs de C a Python/SQL** | Alta (70%) | Alto | MUY ALTA | Análisis detallado de UDFs, POCs tempranos, soporte de Wilmar, considerar experto externo en C | Contratar especialista en C, simplificar algoritmos, usar librerías existentes | Líder Estandarización |
| R04 | **Plazo de 6 meses insuficiente (vs 12-19 estimados)** | Muy Alta (90%) | Crítico | CRÍTICA | Priorización de MVP, paralelización de equipos, uso de IA (Cursor), evaluación de LIBPostal | Negociar extensión de plazo, reducir alcance, entrega por fases | Gerente Proyecto + Sponsor |
| R05 | **Incompatibilidad de LIBPostal con estándar colombiano** | Media (40%) | Alto | MEDIA | POC temprano de LIBPostal (M2), validación con casos reales colombianos, comparación con sistema actual, ajuste de post-procesamiento | Descartar LIBPostal, migrar UDFs completas, desarrollo desde cero, considerar Google Maps (con restricciones legales) | Arquitecto + Líder Estandarización |
| R06 | **Tiempos de procesamiento superiores a los actuales** | Media (50%) | Alto | ALTA | Optimización de queries, uso de índices, particionamiento, pruebas de performance tempranas | Escalamiento vertical/horizontal, optimización de algoritmos, revisión de arquitectura | Ing Datos + Arquitecto |
| R07 | **Disponibilidad limitada de Wilmar (40%)** | Media (50%) | Alto | ALTA | Sesiones intensivas de transferencia, documentación exhaustiva, grabación de sesiones | Contratar experto adicional en Reconocer, extender disponibilidad de Wilmar | Gerente Proyecto |
| R08 | **Dificultad para encontrar experto en migración Teradata→AWS** | Alta (70%) | Alto | MUY ALTA | Búsqueda inmediata, considerar consultores externos, ampliar búsqueda geográfica | Capacitación interna, soporte de AWS Professional Services, consultores externos | Gerente Proyecto |

---

### Riesgos Altos (Probabilidad Media + Impacto Alto)

| ID | Riesgo | Probabilidad | Impacto | Exposición | Mitigación | Contingencia | Responsable |
|----|--------|--------------|---------|------------|------------|--------------|-------------|
| R09 | **Cobertura de geolocalización inferior a la esperada** | Media (40%) | Alto | MEDIA | Validación temprana con ESRI, pruebas con muestra representativa, plan B sin geolocalización | Usar solo direcciones con lat/long, reducir dependencia de geolocalización | Dev Integración |
| R10 | **Complejidad de integración entre EDF y Redshift (OP1)** | Media (50%) | Alto | ALTA | Diseño detallado de integración, POC de transferencia de datos, monitoreo de performance | Simplificar integración, considerar OP2 (solo Redshift) | Arquitecto |
| R11 | **Rotación de personal durante proyecto largo** | Media (40%) | Alto | MEDIA | Documentación continua, pair programming, knowledge sharing, ambiente de trabajo positivo | Onboarding rápido, soporte de equipo, redistribución de tareas | Gerente Proyecto |
| R12 | **Falta de acceso a documentación técnica completa** | Media (40%) | Alto | MEDIA | Solicitud temprana de acceso a Confluence, DDLs de UDFs, tablas de parámetros | Ingeniería inversa, análisis de código, sesiones con Wilmar | Experto Reconocer |
| R13 | **Problemas de integración con ESRI/ArcGIS** | Media (40%) | Alto | MEDIA | POC temprano, validación de APIs, plan de contingencia sin geolocalización | Usar servicio alternativo, reducir dependencia, implementar en fase posterior | Dev Integración |
| R14 | **Limitaciones de escalabilidad en Redshift** | Baja (30%) | Alto | MEDIA | Diseño para escalabilidad, pruebas de carga tempranas, optimización de queries | Escalamiento de cluster, particionamiento, revisión de arquitectura | Ing Datos + Arquitecto |
| R15 | **Deuda técnica por desarrollo acelerado** | Alta (60%) | Medio | ALTA | Code reviews, estándares de código, refactoring continuo, documentación | Fase de refactoring post go-live, asignación de tiempo para mejoras | Líder Técnico |
| R29 | **Complejidad de integración JNI de Libpostal** | Media (40%) | Medio | MEDIA | POC temprano (M2), Dockerfile con dependencias C, validación en ambientes, documentación de setup | Usar Google Maps (con costos altos), migrar UDFs completas, desarrollo custom | Líder Estandarización + Infra AWS |

---

### Riesgos Medios

| ID | Riesgo | Probabilidad | Impacto | Exposición | Mitigación | Contingencia | Responsable |
|----|--------|--------------|---------|------------|------------|--------------|-------------|
| R16 | **Complejidad de integración con DB2** | Media (40%) | Medio | MEDIA | Diseño detallado de integración, pruebas tempranas, validación de formatos | Simplificar integración, usar formatos estándar | Dev Integración |
| R17 | **Problemas de performance en consultas** | Media (40%) | Medio | MEDIA | Optimización de queries, índices, pruebas de carga | Escalamiento, caching, revisión de modelo de datos | Ing Datos |
| R18 | **Costos AWS superiores a lo estimado** | Media (40%) | Medio | MEDIA | Estimación detallada, monitoreo de costos, optimización de recursos | Ajuste de recursos, optimización de queries, negociación con AWS | Infra AWS + Gerente Proyecto |
| R19 | **Cambios de alcance durante ejecución** | Media (40%) | Medio | MEDIA | Control de cambios estricto, validación con sponsor, documentación de impactos | Negociación de plazo/presupuesto, priorización | Gerente Proyecto |
| R20 | **Problemas de seguridad y compliance** | Baja (20%) | Alto | MEDIA | Revisión de seguridad, validación de compliance, auditorías | Ajustes de seguridad, validación con equipo de seguridad Experian | Infra AWS + Arquitecto |
| R21 | **Falta de ambientes AWS a tiempo** | Media (30%) | Medio | MEDIA | Solicitud temprana, seguimiento con infra, plan de ambientes | Uso de ambientes temporales, priorización de ambientes críticos | Infra AWS |
| R22 | **Problemas de integración con Control-M** | Baja (30%) | Medio | BAJA | Diseño detallado, pruebas tempranas, validación con equipo Control-M | Automatización alternativa, ajustes de integración | Dev AWS |
| R23 | **Falta de capacitación del equipo** | Media (40%) | Medio | MEDIA | Plan de capacitación, onboarding estructurado, documentación | Capacitación adicional, soporte externo, mentoring | Gerente Proyecto |
| R24 | **Problemas de calidad de datos de origen** | Media (30%) | Medio | MEDIA | Validación de calidad en ingesta, alertas de calidad, monitoreo | Limpieza adicional, validación con cliente, ajustes de reglas | Ing Datos + QA |

---

### Riesgos Bajos

| ID | Riesgo | Probabilidad | Impacto | Exposición | Mitigación | Contingencia | Responsable |
|----|--------|--------------|---------|------------|------------|--------------|-------------|
| R25 | **Problemas de comunicación con equipo Experian** | Baja (20%) | Medio | BAJA | Reuniones regulares, canales de comunicación claros, escalamiento definido | Ajuste de frecuencia de reuniones, escalamiento | Gerente Proyecto |
| R26 | **Falta de documentación post go-live** | Media (30%) | Bajo | BAJA | Documentación continua, templates, revisión de calidad | Documentación post go-live, asignación de tiempo | Todos |
| R27 | **Problemas de soporte post go-live** | Baja (20%) | Medio | BAJA | Plan de soporte, documentación de runbooks, capacitación | Soporte extendido, ajustes de equipo | Gerente Proyecto |
| R28 | **Incompatibilidad con estrategia XPMS** | Media (40%) | Bajo | MEDIA | Validación temprana con arquitectura, alineación con roadmap XPMS | Ajustes de arquitectura, plan de convergencia | Arquitecto |

---

### Riesgos Nuevos (Identificados en reuniones 16-17 marzo 2026)

| ID | Riesgo | Probabilidad | Impacto | Exposición | Mitigación | Contingencia | Responsable |
|----|--------|--------------|---------|------------|------------|--------------|-------------|
| R30 | **Dependencia crítica de IFR** – Si IFR no sale en agosto 2026, Reconocer se bloquea | Alta (60%) | Crítico | MUY ALTA | Priorizar data de Reconocer dentro de IFR, coordinación con equipo IFR | Evaluar ejecución sobre Alfa (doble esfuerzo posterior), negociar extensión de plazo | Francisco + Gerente Proyecto |
| R31 | **Estructura de tablas Redshift ≠ Teradata** – Los procedimientos almacenados de ordenamiento no se pueden copiar directamente. Requiere re-implementación con mapeo de fuentes, campos y tablas | Alta (70%) | Alto | MUY ALTA | Sesión técnica de Redshift con Johnny/Néstor, mapeo temprano de tablas, POC de migración de un procedimiento | Evaluar ordenamiento en EDF (Spark/Iceberg) en lugar de Redshift | Francisco + Data Engineer SQL |
| R32 | **Funciones nativas de Teradata sin equivalente en Redshift** | Media (50%) | Alto | ALTA | Inventario de funciones nativas usadas en procedimientos, identificar equivalentes en Redshift | Desarrollo custom de funciones equivalentes, evaluar EDF como alternativa | Data Engineer SQL |
| R33 | **Sección Locations del XPM insuficiente para Reconocer** – Si faltan campos, hay que crear nueva sección (proceso formal de gobierno de datos que puede tomar semanas) | Media (40%) | Alto | MEDIA | Diego Santucci validará con Johnny si Locations tiene todo. Hacer esta validación en la primera semana | Crear nueva sección en XPM (proceso de gobierno de datos), priorizar campos mínimos | Francisco + Diego |
| R34 | **Disponibilidad parcial de Francisco** – Compartido entre plataforma y Reconocer, con presión de ambos lados | Alta (60%) | Alto | ALTA | Reforzar equipo de plataforma con nuevas contrataciones (Diego Poveda pendiente), Laura asume más responsabilidad en plataforma | Asignar Francisco 100% a Reconocer si es crítico, buscar reemplazo temporal en plataforma | Gerente Proyecto |

### Riesgos Actualizados

| ID | Cambio | Detalle |
|----|--------|---------|
| R01 | **Probabilidad reducida (19/03)** | Reunión del 16/03 con arquitectura fue positiva. Viabilidad confirmada. Decisión de Curation tomada el 19/03. Pendiente workshops de detalle para ordenamiento. |
| R05 | **Probabilidad reducida** | Interoperabilidad Java/Scala confirmada. Libpostal funciona dentro de Curation. |
| R08 | **Mitigado parcialmente** | Francisco y Diego asignados. Se necesita 1 Scala + 1 SQL adicional. |
| R29 | **Probabilidad reducida** | Framework Oxygen ya tiene ~10% en Java. La integración JNI es viable. |

### Riesgos Nuevos (Identificados en llamada 19 marzo 2026)

| ID | Riesgo | Probabilidad | Impacto | Exposición | Mitigación | Contingencia | Responsable |
|----|--------|--------------|---------|------------|------------|--------------|-------------|
| R35 | **Colisión de nombre de campo nuevo** – El nombre del campo estandarizado nuevo podría coincidir con un campo existente de alguna fuente en EDF | Baja (20%) | Alto | MEDIA | Búsqueda previa en todos los archivos de configuración de EDF. Validar con equipo de ingesta antes de implementar | Renombrar campo, coordinar con equipo EDF para nombre alternativo | Francisco + Equipo EDF |

### Riesgos Nuevos (Identificados en sesión funcional 25 marzo 2026)

| ID | Riesgo | Probabilidad | Impacto | Exposición | Mitigación | Contingencia | Responsable |
|----|--------|--------------|---------|------------|------------|--------------|-------------|
| R36 | **Restricción legal de mezcla de datos buró + Nueva Data** – No se pueden mezclar datos del buró de crédito tradicional con datos de ICS/Mi Data Crédito que requieren consentimiento. Impacta integración de nuevas fuentes post-migración | Alta (80%) | Alto | MUY ALTA | Diseñar arquitectura con separación clara de fuentes (buró vs consentimiento). Validar con equipo legal de Experian | Mantener fuentes separadas con modelos de datos independientes. Integración solo a nivel de presentación | Arquitecto + Equipo Legal Experian |
| R37 | **Fuente Contactabilidad OTP (P0003) sin validar** – Proceso diario cuyo uso actual, valor y fuente de datos son desconocidos. Podría estar obsoleto o ser crítico | Media (50%) | Medio | MEDIA | Diego, Fernando y Natalia deben validar estado, uso y valor del proceso P0003 | Si está obsoleto, excluir del alcance. Si es crítico, incluir en migración | Diego + Fernando + Natalia |
| R38 | **Fuente ARGIS sin frecuencia de actualización validada** – Se desconoce la frecuencia actual de actualización de datos de georreferenciación (barrio y estrato) | Media (40%) | Medio | MEDIA | Validar con equipo técnico el estado actual y frecuencia de actualización de ARGIS | Definir frecuencia mínima aceptable para migración | Equipo Técnico |
| R39 | **Batch usa Teradata directamente (no DB2 precalculado)** – El canal batch genera datos desde Teradata, no desde las tablas precalculadas de DB2. Esto implica que la migración batch requiere acceso directo a datos procesados en Redshift, no solo a las tablas precalculadas | Media (50%) | Alto | ALTA | Diseñar flujo batch en Redshift que replique la explotación directa de Teradata. Mapear diferencias entre datos precalculados (DB2) y datos batch (Teradata) | Evaluar si batch puede usar datos precalculados en la nueva arquitectura para simplificar | Data Engineer SQL + Arquitecto |
| R40 | **Múltiples versiones del producto requieren migración** – 8 versiones batch, 4 en línea, 2 microservicios. Cada versión tiene estructura de salida diferente. Mayor alcance del esperado | Alta (60%) | Alto | ALTA | Obtener cuadro comparativo de versiones (Diego debe enviarlo). Priorizar versiones por uso/criticidad. Definir MVP con versiones mínimas | Migrar solo Reconocer Máster inicialmente, agregar versiones incrementalmente | Diego Reina + Equipo Técnico |

### Riesgos Actualizados (Workshop técnico 26 marzo 2026)

| ID | Cambio | Detalle |
|----|--------|---------|
| R37 | **CERRADO — Riesgo eliminado** | Contactabilidad OTP (P0003) nunca se activó. El contrato con proveedores nunca se concretó. Se excluye del alcance de migración. |
| R38 | **Reclasificado como CRÍTICO** | Geolocalización (Geolitics/ARGIS) está actualmente desconectada. La integración cambió y el proceso dejó de funcionar. Se necesita contactar a Julián Méndez para definir cómo funciona ahora. |
| R09 | **Probabilidad aumentada (60%)** | Geolocalización no solo tiene cobertura inferior, sino que la integración está rota. Requiere redefinición completa de la integración con Geolitics. |

### Riesgos Nuevos (Workshop técnico 26 marzo 2026)

| ID | Riesgo | Probabilidad | Impacto | Exposición | Mitigación | Contingencia | Responsable |
|----|--------|--------------|---------|------------|------------|--------------|-------------|
| R41 | **Geolocalización desconectada — integración con Geolitics rota** – El proceso de enriquecimiento con Geolitics dejó de funcionar. Se desconoce el estado actual de la API y cómo hacer el enriquecimiento en la nueva arquitectura | Alta (70%) | Alto | MUY ALTA | Contactar a Julián Méndez para definir cómo funciona Geolitics post-actualización. Evaluar alternativas de geolocalización | Implementar geolocalización como fase posterior al MVP. Usar datos históricos de geolocalización existentes | Equipo Técnico + Julián Méndez |
| R42 | **Suscriptores bloqueados en COBOL pierden datos** – Cuando un suscriptor se bloquea en COBOL, sus datos no se cargan. Si se desbloquea pero el delta no se reinyecta, los datos se pierden permanentemente | Media (40%) | Medio | MEDIA | Data Fabric (capa de curación) resuelve esto porque los datos no estarán filtrados. Documentar como beneficio de la migración | Proceso manual de reinyección de deltas para suscriptores desbloqueados | Equipo EDF |
| R43 | **Campo nuevo en XPM para validez de direcciones** – Se necesita un campo nuevo en XPM que indique si una dirección es válida para Reconocer. Puede requerir proceso formal de gobierno de datos | Media (40%) | Medio | MEDIA | Validar con equipo de gobierno de datos si se puede agregar al campo existente o requiere nueva sección. Coordinar con Diego Santucci | Usar campo existente con convención de valores para indicar validez | Francisco + Diego Santucci |

---

## Mapa de Calor de Riesgos

```
IMPACTO
  ↑
  │
C │  R01  R02  R04  R30
R │  R07  R08
Í │
T │
I │
C │
O │
  │
A │  R03  R05  R06  R09  R10  R11  R12  R13  R20  R31  R32  R34
L │  R14  R33
T │
O │
  │
M │  R15  R16  R17  R18  R19  R21  R23  R24  R25  R28  R29
E │
D │
I │
O │
  │
B │  R22  R26  R27
A │
J │
O │
  └─────────────────────────────────────────────→
    BAJA    MEDIA    ALTA    MUY ALTA
              PROBABILIDAD
```

---

## Supuestos del Proyecto

### Supuestos de Negocio

| ID | Supuesto | Validación | Impacto si es Falso | Responsable |
|----|----------|------------|---------------------|-------------|
| S01 | Presupuesto AWS aprobado y disponible | M1 | Proyecto no puede iniciar | Sponsor |
| S02 | Plazo de octubre 2026 para batch es firme | M1 | Replantear cronograma | Sponsor |
| S03 | Plazo de noviembre 2026 para servicio en línea es firme | M1 | Replantear cronograma | Sponsor |
| S04 | Cobertura de AWS del proyecto está confirmada | M1 | Costos adicionales | Sponsor |
| S05 | No hay cambios mayores de alcance durante ejecución | Continuo | Extensión de plazo/presupuesto | Gerente Proyecto |

### Supuestos Técnicos

| ID | Supuesto | Validación | Impacto si es Falso | Responsable |
|----|----------|------------|---------------------|-------------|
| S06 | Arquitectura será validada en M2 | M2 | Retraso de 2-4 semanas | Arquitecto |
| S07 | Acceso a ambientes AWS desde M1 | M1 | Retraso de inicio | Infra AWS |
| S08 | Acceso a documentación técnica completa | M1-M2 | Mayor esfuerzo de análisis | Experto Reconocer |
| S09 | Disponibilidad de Wilmar (40%) durante todo el proyecto | Continuo | Pérdida de conocimiento crítico | Gerente Proyecto |
| S10 | Integración con ESRI/ArcGIS sin problemas técnicos | M8-M9 | Retraso en geolocalización | Dev Integración |
| S11 | UDFs de C pueden migrarse a Python/SQL | M3-M4 | Mayor complejidad y tiempo | Líder Estandarización |
| S12 | Redshift puede manejar volumetría (65-70M registros) | M4-M5 | Revisión de arquitectura | Arquitecto |
| S13 | Calidad de datos de origen es aceptable | M2-M3 | Limpieza adicional | Ing Datos |
| S14 | DB2 está disponible para integración | M11-M12 | Retraso en servicio en línea | Dev Integración |
| S15 | Control-M puede integrarse sin problemas | M10-M11 | Automatización alternativa | Dev AWS |

### Supuestos de Equipo

| ID | Supuesto | Validación | Impacto si es Falso | Responsable |
|----|----------|------------|---------------------|-------------|
| S16 | Equipo completo disponible desde M2 | M2 | Retraso de inicio | Gerente Proyecto |
| S17 | Arquitecto con experiencia en Teradata→AWS disponible | M1 | Mayor curva de aprendizaje | Gerente Proyecto |
| S18 | Desarrolladores con experiencia en AWS disponibles | M2 | Mayor tiempo de capacitación | Gerente Proyecto |
| S19 | No hay rotación significativa de personal | Continuo | Pérdida de conocimiento | Gerente Proyecto |
| S20 | Equipo tiene capacidad para trabajar en paralelo | M3-M9 | Mayor duración | Gerente Proyecto |

### Supuestos Nuevos (actualización 19/03/2026)

| ID | Supuesto | Validación | Impacto si es Falso | Responsable |
|----|----------|------------|---------------------|-------------|
| S21 | IFR sale en agosto 2026 con data suficiente para Reconocer | Agosto 2026 | Reconocer se bloquea, hay que evaluar Alfa (doble esfuerzo) | Francisco + Gerente Proyecto |
| S22 | Sección Locations del XPM tiene todos los campos necesarios para Reconocer | Semana 1 (validación con Diego Santucci/Johnny) | Proceso de gobierno de datos para crear nueva sección (semanas de retraso) | Francisco + Diego |
| S23 | Francisco puede dedicar 50% a Reconocer sin impactar plataforma | Continuo | Retraso en liderazgo técnico, necesidad de asignar otro líder | Gerente Proyecto |
| S24 | Diego puede moverse de ingesta a Curation/Reconocer | Abril 2026 | Necesidad de contratar perfil adicional con conocimiento de Curation | Gerente Proyecto |
| S25 | Equipo de plataforma se refuerza para compensar salida parcial de Francisco y Diego | Abril-Mayo 2026 | Impacto en servicios de plataforma, conflicto con Experian | Gerente Proyecto |
| S26 | Modelo de servicios (no staffing) de Experian permite mover recursos internamente | Continuo | Conflicto administrativo con Experian | Edwin |
| S27 | El nombre del nuevo campo estandarizado es único en el ecosistema de fuentes EDF | Antes de implementación (M2-M3) | Colisión con campo existente, requiere renombrar y reconfigurar | Francisco + Equipo EDF |
| S28 | PINNING no requiere modificación para el alcance de este proyecto | Continuo | Si se requiere integración con PINNING, se necesitan pruebas de regresión adicionales y coordinación con equipo de ingesta | Francisco + Equipo EDF |

### Supuestos Nuevos (actualización 25/03/2026)

| ID | Supuesto | Validación | Impacto si es Falso | Responsable |
|----|----------|------------|---------------------|-------------|
| S29 | La estandarización de datos queda fuera del alcance de Reconocer y es responsabilidad del equipo de datos | Confirmado 25/03 | Si Reconocer debe estandarizar, se duplica esfuerzo y se extiende cronograma | Equipo de Producto |
| S30 | Los datos de ICS (Mi Data Crédito) NO se incluyen en el alcance inicial de migración | M1-M2 | Si se incluyen, hay restricción legal de mezcla con datos del buró que requiere arquitectura separada | Arquitecto + Legal |
| S31 | El proceso de Contactabilidad OTP (P0003) se valida y se define si entra o no en alcance | Semana 1-2 (Diego, Fernando, Natalia) | Si es crítico y no se incluye, se pierde funcionalidad del producto | Diego + Fernando + Natalia |
| S32 | Todas las versiones del producto se basan en el mismo modelo precalculado completo | Confirmado 25/03 | Si hay lógica diferente por versión, se multiplica el esfuerzo de migración | Diego Reina |
| S33 | El cuadro comparativo de versiones por canal de consumo estará disponible antes de cerrar alcance | Semana 1-2 (Diego) | Sin este insumo no se puede dimensionar correctamente el alcance de la migración | Diego Reina |

### Supuestos Nuevos (actualización 26/03/2026)

| ID | Supuesto | Validación | Impacto si es Falso | Responsable |
|----|----------|------------|---------------------|-------------|
| S34 | Contactabilidad OTP (P0003) se excluye del alcance de migración (nunca se activó) | Confirmado 26/03 | Si se decide incluir, requiere definir proveedores y contratos desde cero | Equipo de Producto |
| S35 | Los catálogos de estandarización (excepciones, topónimos) son estáticos y se pueden migrar tal cual | Confirmado 26/03 (no han cambiado desde configuración inicial) | Si requieren actualización, se necesita proceso de gestión de catálogos | Equipo Técnico |
| S36 | La integración con Geolitics se puede restablecer o reemplazar en la nueva arquitectura | Pendiente — contactar a Julián Méndez | Si Geolitics no está disponible, se pierde geolocalización y puntos de interés del producto | Julián Méndez + Equipo Técnico |
| S37 | El problema de suscriptores bloqueados en COBOL se resuelve con Data Fabric (capa de curación) | Confirmado conceptualmente 26/03 | Si Data Fabric no resuelve el filtrado, se necesita proceso de reinyección manual | Equipo EDF |

---

## Estrategia de Gestión de Riesgos

### Proceso de Gestión

1. **Identificación**: Revisión semanal de riesgos en reuniones de equipo
2. **Análisis**: Evaluación de probabilidad e impacto
3. **Priorización**: Clasificación según exposición (Probabilidad × Impacto)
4. **Planificación**: Definición de mitigación y contingencia
5. **Monitoreo**: Seguimiento continuo de riesgos activos
6. **Control**: Ejecución de planes de mitigación/contingencia

### Frecuencia de Revisión

- **Riesgos Críticos**: Revisión semanal
- **Riesgos Altos**: Revisión quincenal
- **Riesgos Medios/Bajos**: Revisión mensual
- **Nuevos Riesgos**: Identificación continua

### Escalamiento

| Nivel de Riesgo | Escalamiento | Tiempo de Respuesta |
|-----------------|--------------|---------------------|
| Crítico | Sponsor + Gerente Proyecto | Inmediato (24h) |
| Alto | Gerente Proyecto + Líder Técnico | 48 horas |
| Medio | Líder Técnico | 1 semana |
| Bajo | Responsable del Riesgo | 2 semanas |

---

## Plan de Acción para Riesgos Críticos

### R01: Rechazo de Arquitectura

**Acciones Inmediatas (Semana 1-2)**:
1. Agendar workshop con arquitectura Experian
2. Preparar presentación de opciones con análisis detallado
3. Validar alineación con estrategia XPMS
4. Preparar plan B (Opción 2 - Solo Redshift)

**Indicadores de Alerta**:
- Feedback negativo en reuniones preliminares
- Conflicto con estrategia XPMS
- Resistencia a partición de plataformas

---

### R02: Pérdida de Calidad en Estandarización

**Acciones Inmediatas (M3-M4)**:
1. Definir métricas de calidad (cobertura, precisión, recall)
2. Implementar pruebas comparativas vs sistema actual
3. Validación por muestreo con Wilmar
4. Dashboard de métricas de calidad

**Indicadores de Alerta**:
- Cobertura < 90% vs sistema actual
- Direcciones válidas < 85%
- Feedback negativo de Wilmar

---

### R30: Dependencia Crítica de IFR

**Acciones Inmediatas (Semana 1-2)**:
1. Confirmar con equipo IFR el roadmap y fecha estimada de agosto 2026
2. Identificar qué data de Reconocer necesita estar en IFR y priorizarla dentro del backlog de IFR
3. Evaluar viabilidad de ejecutar sobre Alfa como plan B (estimar esfuerzo de doble migración)
4. Establecer checkpoints mensuales con equipo IFR para monitorear avance

**Indicadores de Alerta**:
- Retraso > 2 semanas en hitos de IFR
- Cambio de prioridades en IFR que desplace data de Reconocer
- Falta de definición de esquema de datos en IFR para Reconocer

---

### R31: Estructura de Tablas Redshift ≠ Teradata

**Acciones Inmediatas (Semana 1-3)**:
1. Agendar sesión técnica de Redshift con Johnny y Néstor para entender estructura actual
2. Seleccionar un procedimiento almacenado representativo y hacer POC de migración
3. Mapear fuentes, campos y tablas entre Teradata y Redshift
4. Evaluar si el ordenamiento es más viable en EDF (Spark/Iceberg) que en Redshift
5. Inventariar funciones nativas de Teradata usadas en procedimientos (alimenta R32)

**Indicadores de Alerta**:
- POC de migración de procedimiento toma > 2 semanas
- Más del 30% de funciones nativas sin equivalente directo en Redshift
- Diferencias estructurales que requieran rediseño de modelo de datos

---

### R04: Plazo de 6 Meses Insuficiente

**Acciones Inmediatas (M1)**:
1. Negociar extensión de plazo con sponsor
2. Definir MVP con funcionalidades críticas
3. Evaluar entrega por fases (batch primero, servicio después)
4. Paralelización máxima de equipos

**Indicadores de Alerta**:
- Retraso > 2 semanas en hitos críticos
- Velocidad de desarrollo < esperada
- Complejidad técnica mayor a la estimada

---

## Exclusiones del Proyecto

### Fuera de Alcance

1. **Migración de otros sistemas de Experian** (solo Reconocer)
2. **Desarrollo de nuevas funcionalidades** no contempladas en sistema actual
3. **Soporte post go-live** (requiere contrato separado)
4. **Capacitación avanzada** a usuarios finales (solo capacitación básica)
5. **Optimizaciones no críticas** para MVP
6. **Migración de datos históricos** más allá de lo necesario para operación
7. **Integración con sistemas no mencionados** en alcance inicial
8. **Desarrollo de dashboards avanzados** (solo dashboards básicos de monitoreo)
9. **Integración de datos de ICS (Mi Data Crédito)** en el modelo inicial (restricción legal de mezcla con datos del buró)
10. **Estandarización de datos** (confirmado 25/03: responsabilidad del equipo de datos, no de Reconocer)
11. **Fuente de Contactabilidad OTP (P0003)** (confirmado 26/03: nunca se activó, contrato con proveedores nunca se concretó)

### Responsabilidades del Cliente

1. **Validación de arquitectura** en tiempo y forma (M2)
2. **Acceso a documentación técnica** completa
3. **Disponibilidad de Wilmar** (40%) durante todo el proyecto
4. **Acceso a ambientes** de Experian (Cobol, DB2, Control-M)
5. **Validación de resultados** y calidad de datos
6. **Aprobación de cambios** de alcance
7. **Provisión de datos de prueba** representativos
8. **Coordinación con equipos internos** (arquitectura, producto, operaciones)

---

## Criterios de Éxito y Aceptación

### Criterios Funcionales

| Criterio | Métrica | Objetivo | Crítico |
|----------|---------|----------|---------|
| Cobertura de estandarización | % vs sistema actual | ≥ 95% | Sí |
| Calidad de direcciones válidas | % direcciones válidas | ≥ 90% | Sí |
| Cobertura de geolocalización | % direcciones con lat/long | ≥ 70% | No |
| Tiempo de procesamiento delta | Horas | ≤ 6 horas | Sí |
| Capacidad de procesamiento full | Días | ≤ 7 días | Sí |

### Criterios No Funcionales

| Criterio | Métrica | Objetivo | Crítico |
|----------|---------|----------|---------|
| Disponibilidad del servicio | % uptime | ≥ 99.5% | Sí |
| Tiempo de respuesta consultas | Segundos | ≤ 2 seg | Sí |
| Escalabilidad | Millones de registros | 100M+ | No |
| Costos AWS | % vs presupuesto | ≤ 100% | Sí |

### Criterios de Negocio

| Criterio | Fecha Objetivo | Crítico |
|----------|----------------|---------|
| Solución batch operativa | Octubre 2026 | Sí |
| Servicio en línea operativo | Noviembre 2026 | Sí |
| Cumplimiento de normativas | Go-live | Sí |

---

## Recomendaciones

### Recomendaciones Críticas

1. **Priorizar validación de arquitectura**: Workshop con arquitectura Experian en las primeras 2 semanas
2. **Negociar extensión de plazo**: 6 meses es insuficiente, negociar 9-12 meses
3. **Contratar experto en Teradata→AWS**: Iniciar búsqueda inmediata
4. **Definir MVP**: Priorizar funcionalidades críticas para cumplir plazos
5. **POC de LIBPostal**: Validar viabilidad en primera semana de M3

### Recomendaciones Importantes

6. **Documentación exhaustiva**: Sesiones intensivas con Wilmar en M1-M3
7. **Pruebas tempranas**: Validación de calidad desde M3
8. **Monitoreo de costos AWS**: Desde M1, revisión mensual
9. **Plan de contingencia**: Preparar Opción 2 (solo Redshift) como plan B
10. **Paralelización de equipos**: Maximizar trabajo en paralelo en M3-M9

---

## Próximos Pasos

1. **Inmediato**: Agendar workshop con arquitectura Experian
2. **Semana 1**: Validar supuestos críticos (S01-S05)
3. **Semana 2**: Iniciar búsqueda de Arquitecto y Líder de Estandarización
4. **Semana 3**: Preparar presentación de opciones arquitectónicas
5. **Semana 4**: Ejecutar workshop y obtener decisión arquitectónica
6. **M2**: Iniciar implementación según arquitectura aprobada
