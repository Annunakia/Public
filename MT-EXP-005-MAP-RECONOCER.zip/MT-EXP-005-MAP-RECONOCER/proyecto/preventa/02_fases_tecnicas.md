# Fases Técnicas – EXPERIAN MAP RECONOCER

## Información General

| Campo | Valor |
|-------|-------|
| Cliente | Experian |
| Proyecto | Migración del Sistema Reconocer a AWS |
| Fecha | 2026-03-04 (actualizado 2026-03-19) |
| Versión | 1.2 |

---

## Resumen Ejecutivo

El proyecto contempla la migración del sistema Reconocer desde la arquitectura actual (Cobol → Teradata → DB2) hacia AWS utilizando una **arquitectura híbrida EDF + Redshift**.

**Duración**: 10 meses (cronograma optimizado con paralelización) | **Duración conservadora**: 12 meses

**Decisión arquitectónica**: Se ha seleccionado la arquitectura híbrida porque EDF (Experian Data Fabric) es por definición el punto de ingesta de todos los datos del bureau de Experian. 

**Estrategia de ejecución**: El proyecto aprovecha paralelización de equipos para reducir tiempos. Mientras el equipo EDF implementa estandarización, el equipo Redshift desarrolla algoritmos de ordenamiento con datos mock, permitiendo integración inmediata cuando los datos reales estén disponibles.

**Estructura**: 3 fases principales con actividades en paralelo:
1. Planeación y Diseño (M1-M2) - con POC Libpostal en paralelo
2. Ingesta y Estandarización en EDF (M2-M7) - con desarrollo de ordenamiento en Redshift en paralelo
3. Ordenamiento, Cálculo y Exposición (M5-M10) - con preparación de batch y servicio en línea en paralelo

---

## Fase 1: Planeación y Diseño (Meses 1-2)

### Objetivo
Validar viabilidad técnica, definir arquitectura objetivo y establecer bases para la implementación.

### Actividades Principales

#### 1.1 Validación Arquitectónica
- Workshop con equipo de arquitectura Experian (~15 días)
- Validación de compatibilidad con estrategia XPMS
- **Decisión crítica 1: ¿En qué etapa del pipeline de EDF se hace la estandarización?** → RESUELTA (19/03): Curation en IFR, campo nuevo, sin impacto en PINNING
- **Decisión crítica 2: ¿Dónde hacer el ordenamiento? (EDF vs Redshift)** → Abierta, Francisco sugiere evaluar EDF (Spark/Iceberg)
- Confirmación de arquitectura híbrida EDF+Redshift
- Coordinación con equipo de EDF para integración

**Workshops Definidos (actualización 16/03/2026)**:
1. **Alineación Técnica Interna**: Revisión de videos y análisis previos. Participantes: Adriana, Juan Carlos, Wilmar.
2. **Sesión con Producto y Datos**: Criterios de aceptación de estandarización. Participantes: Diego Reina, Caterina, equipo Macondotek.
3. **Revisión de Artefactos en Teradata**: Tablas, vistas, procedimientos almacenados.
4. **Revisión de Malla de Ordenamiento**: Proceso actual, dependencias, complejidad.
5. **Sesión Técnica de Redshift**: Compatibilidad de datos, configuración, aprovisionamiento. Participantes: Infraestructura + Johnny + Néstor.

##### Decisión Crítica 1: Etapa del Pipeline de EDF para Estandarización — RESUELTA

**Decisión (19/03/2026 — Llamada con equipo EDF/Ingesta):**

La estandarización de Reconocer se implementará en la etapa de **Curation** del pipeline EDF:

1. Se creará un **campo nuevo** (ej: "nueva dirección estandarizada") en la salida de Curation.
2. El campo existente de dirección estandarizada **no se modifica** (sigue con reglas básicas de Cobol).
3. El nuevo campo se mostrará en el **XPM** como campo adicional.
4. **Precondición**: El nombre del campo debe ser único en todo el ecosistema de fuentes de EDF.
5. **PINNING no se toca**: El nuevo campo no será consumido por PINNING inicialmente. Integración futura es opcional vía archivo de configuración `IdentifyingAttributesConfig`.

**Estandarización actual en EDF (reglas básicas de Cobol):**
- Reemplazar caracteres especiales y letras con espacios
- Segmentar por dígitos, rellenar con ceros
- Validar longitud (>5 → nulo)
- Concatenar segmentos, ordenar de mayor a menor

**Proceso de Curation:**
- Curation diaria: Procesa solo deltas entrantes
- Curation Stop (cada 1-2 semanas): Re-procesa todo el histórico (4 años) contra reglas actualizadas

---

##### Decisión Crítica 2: Ubicación del Ordenamiento

**Contexto:**

EDF (Experian Data Fabric) ya tiene una fase de "state calculation" donde calcula los "mejores" datos de una persona (bestName, bestAddress, bestPhone, etc.) usando reglas de negocio. Reconocer necesita ordenar direcciones, teléfonos y emails usando algoritmos de score similares.

**Pregunta:** ¿El ordenamiento de Reconocer debería hacerse en EDF (Spark/Scala) o en Redshift (SQL)?

**Opción A: Ordenamiento en EDF**

Ventajas:
- Reutiliza lógica existente de "state calculation"
- Alineado con estrategia XPMS (todo en EDF)
- Consistencia: Toda la priorización en un solo lugar
- Spark eficiente para procesamiento distribuido

Desventajas:
- Requiere desarrollo en Scala (curva de aprendizaje)
- Menor flexibilidad para cambios
- Dependencia de equipo EDF
- Posible impacto en performance de EDF

**Opción B: Ordenamiento en Redshift**

Ventajas:
- SQL más simple y flexible que Scala
- Mayor experiencia del equipo en SQL
- Independencia de EDF para cambios
- Redshift optimizado para queries analíticos

Desventajas:
- Duplica lógica de priorización
- Desalineado con estrategia XPMS
- Requiere transferir datos de EDF a Redshift
- Posible inconsistencia con "best" fields de EDF

**Criterios de Decisión:**
1. Alineación con estrategia XPMS de Experian
2. Flexibilidad de EDF para agregar lógica de Reconocer
3. Capacidad del equipo en Scala vs SQL
4. Impacto en performance
5. Visión a largo plazo de Reconocer en XPMS

**Impacto en Arquitectura:**
- Si ordenamiento en EDF → EDF hace: Ingesta + Estandarización + Ordenamiento, Redshift hace: Solo cálculo final
- Si ordenamiento en Redshift → EDF hace: Ingesta + Estandarización, Redshift hace: Ordenamiento + Cálculo

**Decisión:** Pendiente de workshop con arquitectura (M1-M2)

**Nota**: La arquitectura híbrida EDF + Redshift es la seleccionada porque EDF es el punto de ingesta obligatorio de todos los datos del bureau de Experian.

#### 1.2 Diseño de Solución
- Definición del modelo de datos en Redshift
- Diseño de pipelines de ingesta y transformación
- Arquitectura de integración con ESRI/ArcGIS para geolocalización
- **POC Interna Previa (NUEVO)**: Ejercicio interno Macondotek con Libpostal fuera de ambiente Experian. Tomar direcciones de ejemplo, pasarlas por Libpostal, evaluar si la salida se parece al sistema actual. Permite usar herramientas de IA (Claude Code, Kiro). Disipa incertidumbre rápidamente.
- **POC Formal de Libpostal (CRÍTICO)**: Validación con 10K direcciones colombianas sobre pipeline IFR, etapa de Curation (M2, semanas 1-2)
- **Triple Aprobación de POC (NUEVO)**: Requiere aprobación de: 1) Equipo de Datos (Caterina), 2) Equipo de Producto (Diego Reina/Julián Méndez), 3) Equipo de IFR/Pipeline (tiempo y performance)
- Evaluación de resultados POC y decisión de estrategia de estandarización
- Estrategia de migración de UDFs (si POC falla) o integración Libpostal (si POC exitoso)
- **Validación de sección Locations del XPM (NUEVO)**: Verificar si tiene todos los campos que necesita Reconocer. Si no, evaluar si se agregan o se crea nueva sección (proceso formal de gobierno de datos).

#### 1.3 Planeación Operativa
- Definición de ambientes (DEV, QA, PROD)
- Estrategia de cargue (full vs delta)
- Plan de pruebas y validación de calidad
- Definición de métricas de éxito
- Estimación de capacidad de cómputo AWS y costos

### Entregables
- Documento de arquitectura validado
- Modelo de datos Reconocer en Redshift
- Plan de proyecto detallado
- Estimación de costos AWS
- Matriz de decisiones arquitectónicas

### Riesgos Críticos
- **ALTO**: Rechazo de arquitectura por equipo de Experian
- **ALTO**: Incompatibilidad con estrategia XPMS
- **MEDIO**: Subestimación de complejidad de migración de UDFs
- **NUEVO - ALTO**: Dependencia de IFR (fecha tentativa agosto 2026, si no sale, Reconocer se bloquea)

---

## Hallazgos Técnicos Clave (Reuniones 16-17-19 marzo 2026)

### Confirmaciones Positivas
- **Interoperabilidad Java/Scala confirmada**: Libpostal (Java) funciona dentro de Scala/Spark en Curation. El framework Oxygen ya tiene componentes en Java (~10%). No se necesita perfil Java dedicado.
- **Solo se impacta Curation**: El resto del pipeline de EDF no se toca.
- **POC sobre IFR confirmado**: Se ejecutará sobre el pipeline IFR (no Alfa), en la etapa de Curation.
- **Estandarización en Curation como campo nuevo (19/03)**: Se creará un campo nuevo en la salida de Curation con el resultado del nuevo algoritmo. El campo existente no se modifica.
- **PINNING no se toca (19/03)**: El nuevo campo no será consumido por PINNING. No hay impacto. Integración futura es opcional vía `IdentifyingAttributesConfig`.
- **Independencia de proyectos (19/03)**: Reconocer avanza sin afectar ni depender de PINNING.

### Información Operativa de Curation (19/03)
- **Curation diaria**: Pipeline normal (preparación → validación → aceptación → curación) sobre deltas entrantes.
- **Curation Stop** (cada 1-2 semanas): Re-procesa todo el histórico (4 años de datos aceptados). Aplica cambios de reglas o catálogos. Crea archivos particionados que mejoran desempeño de PINNING.
- **Restricción**: Durante PINNING no se pueden transformar datos. Si es estandarización, debe pasar por Curation.

### Nuevos Riesgos Identificados
- **Estructura de tablas Redshift ≠ Teradata**: Los nombres de tablas cambian, lo que en Teradata es 1 tabla en Redshift puede ser 5. Los procedimientos almacenados de ordenamiento (ej: 420 pasos para teléfonos) no se pueden copiar directamente.
- **Funciones nativas de Teradata**: Algunos procedimientos usan funciones que no existen en Redshift.
- **Posible re-implementación del ordenamiento**: No solo migración, sino re-implementación con mapeo de fuentes, campos y tablas.

### Discusión Abierta: Ordenamiento en EDF vs Redshift
Francisco (líder técnico) sugirió evaluar si el ordenamiento tiene más sentido en EDF (Spark/Iceberg) que en Redshift, dado que:
- EDF tiene Spark, catálogo de datos, Iceberg, y más versatilidad que PL/SQL de Redshift.
- La estructura de tablas en Redshift no coincide con Teradata.
- Wilmar y Francisco acordaron estar abiertos a tener esa conversación con arquitectura.

### Deadline Real para EDF
- **Junio 2026**: Datos estandarizados deben estar en el XPM. Este es el deadline inamovible.
- La POC tiene margen de moverse, pero junio no.
- Estrategia: Definir un XPM base para desacoplar equipos.

---

## Análisis de Alternativas de Estandarización

### Contexto

El componente de estandarización de direcciones es el más crítico y complejo del proyecto. El sistema actual utiliza UDFs desarrolladas en C con lógica específica para el estándar colombiano (DANE/DIVIPOLA). Se han evaluado 3 alternativas para la migración.

---

### Alternativa 1: Migración Directa de UDFs (C → Python/SQL)

**Descripción**: Replicar la lógica actual de las UDFs de C en Python/SQL para Redshift.

**Ventajas**:
- Mantiene la lógica probada y validada del sistema actual
- Mayor control sobre el comportamiento de estandarización
- Compatibilidad 100% con estándar colombiano DANE/DIVIPOLA
- No depende de librerías externas

**Desventajas**:
- Alta complejidad técnica (migración de C a Python/SQL)
- Requiere experto en C para entender lógica actual
- Mayor tiempo de desarrollo (6-7 meses estimados)
- Riesgo de pérdida de calidad en la traducción
- Mantenimiento complejo a largo plazo

**Costos**:
- Desarrollo: ~2,380 horas (6-7 meses, 5-6 FTE)
- Infraestructura: $0 USD adicional
- Mantenimiento: Alto (código custom)

**Riesgos**:
- ALTO: Complejidad de migración de UDFs (R03)
- ALTO: Pérdida de calidad en estandarización (R02)
- MEDIO: Falta de experto en C disponible

**Viabilidad**: MEDIA | **Recomendación**: Plan B si Libpostal falla

---

### Alternativa 2: Google Maps Geocoding API

**Descripción**: Usar Google Maps Geocoding API para estandarización y normalización de direcciones.

**Ventajas**:
- Solución probada y de alta calidad
- Cobertura global incluyendo Colombia
- Mantenimiento por Google
- Integración relativamente simple

**Desventajas**:
- **CRÍTICO**: Restricción legal en ToS de Google - NO permite almacenar direcciones normalizadas permanentemente
- **CRÍTICO**: Costo prohibitivo para volumetría del proyecto
- Dependencia de servicio externo
- Requiere conectividad constante
- No optimizado para estándar colombiano DANE/DIVIPOLA

**Costos**:
- Cargue inicial: $1,600,000 USD (400M direcciones × $0.004/dirección)
- Mantenimiento anual: $80,000 USD (20M direcciones/año × $0.004)
- Infraestructura: $0 USD adicional
- **TOTAL 5 años**: $2,000,000 USD

**Restricciones Legales**:
- Google ToS prohíbe almacenar direcciones normalizadas permanentemente
- Solo permite uso en tiempo real para mostrar en mapas
- Violación de ToS puede resultar en suspensión de cuenta

**Riesgos**:
- CRÍTICO: Violación de términos de servicio de Google
- CRÍTICO: Costo prohibitivo ($2M+ en 5 años)
- ALTO: Dependencia de servicio externo
- MEDIO: Latencia en consultas masivas

**Viabilidad**: NO VIABLE | **Recomendación**: DESCARTADA

---

### Alternativa 3: Libpostal (RECOMENDADA)

**Descripción**: Usar Libpostal, librería open source de normalización de direcciones entrenada con OpenStreetMap, para estandarización base + post-procesamiento custom para DANE/DIVIPOLA.

**Ventajas**:
- **Costo mínimo**: $0 USD licencia (MIT) + $50-300 USD infraestructura
- **99.98% ahorro** vs Google Maps ($300 vs $2M en 5 años)
- Librería probada con 60M+ direcciones de entrenamiento
- Soporte para 249 países incluyendo Colombia
- Sin restricciones legales de almacenamiento
- Mantenimiento por comunidad open source
- Integración con Python/Java via JNI

**Desventajas**:
- Requiere post-procesamiento para DANE/DIVIPOLA
- Requiere POC para validar compatibilidad con estándar colombiano
- Integración JNI puede ser compleja
- Requiere 2-4 GB RAM por instancia

**Costos**:
- Licencia: $0 USD (MIT License)
- Infraestructura AWS: $50-300 USD/mes (instancias con 4GB RAM)
- Desarrollo POC: 40 horas (~$4,000 USD)
- Integración: 80 horas (~$8,000 USD)
- Post-procesamiento DANE: 120 horas (~$12,000 USD)
- **TOTAL**: ~$24,000 USD + $300/mes operación

**Requisitos Técnicos**:
- Instancias EC2/Lambda con 2-4 GB RAM
- Integración JNI (Java Native Interface)
- Post-procesamiento para:
  * Validación de códigos DANE
  * Homologación con DIVIPOLA
  * Aplicación de acepciones colombianas
  * Validación de nomenclaturas locales

**Estrategia de Implementación**:
1. **POC (M2, semanas 1-2)**: Validar con 10K direcciones colombianas reales
2. **Criterios de éxito POC**:
   - Compatibilidad ≥ 90% con estándar colombiano
   - Cobertura ≥ 85% de direcciones parseables
   - Performance ≤ 100ms por dirección
3. **Si POC exitoso**: Integración completa + post-procesamiento DANE
4. **Si POC falla**: Migrar a Alternativa 1 (migración directa UDFs)

**Riesgos**:
- MEDIO: Incompatibilidad con estándar colombiano (R05) - Mitigado con POC
- MEDIO: Complejidad de integración JNI (R29) - Mitigado con POC
- BAJO: Performance inferior a esperada

**Viabilidad**: ALTA | **Recomendación**: OPCIÓN PREFERIDA

---

### Comparación de Alternativas

| Criterio | Migración UDFs | Google Maps API | Libpostal |
|----------|----------------|-----------------|-----------|
| **Costo inicial** | $238,000 | $1,600,000 | $24,000 |
| **Costo anual** | $0 | $80,000 | $3,600 |
| **Costo 5 años** | $238,000 | $2,000,000 | $42,000 |
| **Ahorro vs Google** | 88% | 0% | 99.98% |
| **Compatibilidad DANE** | 100% | 60% | 85-90% (con post-proc) |
| **Tiempo desarrollo** | 6-7 meses | 1 mes | 2-3 meses |
| **Complejidad técnica** | Muy Alta | Baja | Media |
| **Restricciones legales** | Ninguna | CRÍTICAS | Ninguna |
| **Mantenimiento** | Alto | Bajo | Medio |
| **Riesgo técnico** | Alto | Bajo | Medio |
| **Riesgo legal** | Ninguno | CRÍTICO | Ninguno |
| **Viabilidad** | Media | NO VIABLE | Alta |

---

### Decisión y Criterios

**Decisión Recomendada**: Alternativa 3 (Libpostal) con POC obligatorio en M2

**Criterios de Decisión**:
1. **Costo**: Libpostal es 99.98% más económico que Google Maps
2. **Legal**: Google Maps tiene restricciones críticas de ToS
3. **Técnico**: POC validará viabilidad antes de comprometer desarrollo
4. **Riesgo**: POC en M2 permite pivotear a Alternativa 1 si falla
5. **Tiempo**: Libpostal permite cumplir plazos (2-3 meses vs 6-7)

**Métricas de Éxito del POC**:
- Compatibilidad ≥ 90% con estándar colombiano DANE/DIVIPOLA
- Cobertura ≥ 85% de direcciones parseables correctamente
- Performance ≤ 100ms por dirección (400M direcciones en ~11 horas)
- Calidad de normalización ≥ 80% vs sistema actual

**Plan de Contingencia**:
- Si POC falla: Migrar inmediatamente a Alternativa 1 (migración UDFs)
- Tiempo de pivote: 1 semana
- Impacto en cronograma: +4 meses (de 12 a 16 meses)

---

## Fase 2: Ingesta y Estandarización (Meses 2-7)

### Objetivo
Implementar procesos de cargue, estandarización y normalización de datos de contacto en EDF.

**NOTA IMPORTANTE**: Esta fase se ejecuta EN PARALELO con el desarrollo de algoritmos de ordenamiento en Redshift (ver Fase 3). El equipo Redshift puede iniciar desarrollo con datos mock mientras EDF completa la estandarización.

### Actividades Principales

#### 2.1 Implementación de Ingesta (M2)
**Plataforma**: EDF (Experian Data Fabric)

- Conexión con fuente Cobol (archivo ICBDIR)
- Cargue de datos maestros de direcciones
- Validación de integridad de datos
- Implementación de proceso delta semanal

#### 2.2 Estandarización de Direcciones (Componente Crítico)
**Duración**: M2-M7 | **Complejidad**: ALTA

**Etapa 1: Identificación de DANE** (M2-M3)
- Extracción de códigos DANE del texto
- Match con catálogo DIVIPOLA
- Implementación de tabla de acepciones de ciudades
- Algoritmos de proximidad para textos similares

**Etapa 2: Tipificación** (M3)
- Clasificación en 4 tipos: VÍA (54.7%), MANZANA (2%), RURAL (0.4%), DESCRIPTIVA (42.9%)
- Validación de estructura por tipo
- Aplicación de reglas de negocio parametrizadas

**Etapa 3: Limpieza** (M3)
- Eliminación de caracteres especiales
- Aplicación de ~200 expresiones regulares
- Separación de letras y números
- Normalización de espacios

**Etapa 4: Acepciones y Topónimos** (M3)
- Homologación de nomenclaturas (CARRERA→KR, BARRIO→BR)
- Aplicación de tabla de excepciones
- Procesamiento de lugares conocidos

**Etapa 5: Normalización** (M3-M4)
- Ordenamiento por pesos de nomenclaturas (89 nomenclaturas, 7 niveles)
- Separación de PUERTA y COMPLEMENTO
- Validación de direcciones según tipo

**Etapa 6: Unificación** (M5-M7)
- Regla 1: Unificación por tipo de uso y CIIU
- Regla 2: Unificación por complementos (genera nuevas direcciones)
- Regla 3: Unificación por geolocalización
- Construcción de diccionarios (Complementos y Vías)

#### 2.3 Estandarización de Teléfonos/Celulares (M3-M4)
- Aplicación de expresiones regulares
- Validación de prefijos con DANE
- Limpieza de caracteres especiales
- Marcación de validez

#### 2.4 Estandarización de Email (M3-M4)
- Aplicación de expresiones regulares
- Validación de formato
- Limpieza y normalización

### Entregables
- Pipeline de ingesta operativo
- Módulos de estandarización implementados (Etapas 1-6)
- Tablas de parámetros migradas (acepciones, nomenclaturas, topónimos)
- Diccionarios de complementos y vías
- Datos estandarizados listos para ordenamiento en Redshift
- Documentación técnica de algoritmos

### Paralelización con Fase 3
**CRÍTICO**: Mientras EDF ejecuta estandarización (M2-M7), el equipo Redshift puede:
- Diseñar algoritmos de ordenamiento (M3-M4)
- Desarrollar con datos mock (M3-M5)
- Preparar infraestructura y tests (M3-M5)
- **Ahorro estimado**: 1-2 meses vs enfoque secuencial

### Riesgos Críticos
- **ALTO**: Pérdida de calidad en estandarización vs sistema actual
- **ALTO**: Complejidad de migración de UDFs de C a Python/SQL
- **MEDIO**: Cobertura de geolocalización inferior a la esperada
- **MEDIO**: Incompatibilidad de LIBPostal con estándar colombiano
- **MEDIO**: Coordinación entre equipos EDF y Redshift para paralelización

---

## Fase 3: Ordenamiento y Cálculo (Meses 3-10)

### Objetivo
Implementar algoritmos de ordenamiento, cálculo de indicadores y exposición de datos en Redshift.

**NOTA IMPORTANTE**: Esta fase INICIA EN PARALELO con la Fase 2 (Estandarización en EDF). El desarrollo de algoritmos puede comenzar en M3 usando datos mock, mientras EDF completa la estandarización.

### Actividades Principales

#### 3.1 Preparación y Diseño (M3-M4 - EN PARALELO CON EDF)
**Plataforma**: Redshift

**Migración de Parámetros** (M3)
- Migración de tablas de parámetros desde Teradata
- Reestructuración de datos de configuración
- Migración de UDFs para explotación

**Diseño de Algoritmos** (M3-M4)
- Diseño de algoritmos de score para direcciones
- Diseño de algoritmos de score para teléfonos/celulares
- Diseño de algoritmos de score para emails
- Creación de datos mock para desarrollo
- Desarrollo de tests unitarios

**PARALELIZACIÓN CRÍTICA**: Mientras EDF ejecuta estandarización (M2-M7), Redshift puede desarrollar toda la lógica de ordenamiento con datos mock. Esto permite integración inmediata cuando los datos reales estén disponibles.

**Ahorro estimado**: 1-2 meses vs enfoque secuencial

#### 3.2 Ordenamiento con Datos Mock (M3-M5 - EN PARALELO CON EDF)
**Plataforma**: Redshift

**Ordenamiento de Direcciones** (M3-M5)
- Implementación de algoritmos de score con datos mock
- Priorización por reportes y lógicas de negocio
- Cálculo de orden 1 para direcciones
- Tests unitarios con datos sintéticos

**Ordenamiento de Teléfonos/Celulares** (M3-M4)
- Algoritmos de score para contactabilidad
- Priorización por número de reportes
- Validación de números activos

**Ordenamiento de Emails** (M3-M4)
- Algoritmos de score para emails
- Validación de dominios
- Priorización por uso

#### 3.3 Integración con Datos Reales (M5-M7)
**Plataforma**: Redshift

**Integración de Datos de EDF** (M5)
- Recepción de datos estandarizados desde EDF
- Validación de formato y calidad
- Integración con algoritmos de ordenamiento

**Validación y Ajustes** (M5-M7)
- Validación de resultados vs sistema actual
- Ajustes de algoritmos basados en datos reales
- Optimización de performance

**Indicadores de Movilidad** (M7)
- Cálculo de cambios de dirección
- Frecuencia de movilidad
- Patrones de desplazamiento

#### 3.4 Geolocalización (M8 - DESDE EDF)
**Plataforma**: EDF → Redshift

- Integración con servidor ESRI/ArcGIS (ejecutado en EDF)
- Cálculo de latitud y longitud
- Identificación de puntos de interés
- Transferencia de datos geolocalizados a Redshift

#### 3.5 Cálculo Reconocer General (M8-M9)
**Plataforma**: Redshift

- Precálculo para toda la población (65-70M ciudadanos)
- Generación de tablas finales por tipo y número de documento
- Consolidación de datos de contacto
- Validación de cobertura y calidad

**PARALELIZACIÓN**: Mientras se ejecuta el cálculo, el equipo puede preparar infraestructura batch (ver 3.6)

#### 3.6 Replicación Modelo Batch (M8-M9 - EN PARALELO CON CÁLCULO)
**Plataforma**: Redshift + Control-M

- Migración de esquema de tablas batch
- Integración con Control-M
- Automatización de procesos
- Conexión con proceso de cargue
- Preparación de scripts de carga

**PARALELIZACIÓN**: Preparación de infraestructura mientras se ejecuta cálculo Reconocer

**Ahorro estimado**: 1 mes vs enfoque secuencial

#### 3.7 Servicio en Línea (M9-M10 - EN PARALELO CON BATCH)
**Plataforma**: DB2 + APIs

- Exportación de datos a formato DB2
- Transferencia vía S3
- Cargue en DB2
- Ajustes en Control-M
- Implementación de APIs de consulta (Aurora/DynamoDB si aplica)

**PARALELIZACIÓN**: Preparación de servicio en línea mientras se completa modelo batch

**Ahorro estimado**: 1 mes vs enfoque secuencial

### Entregables
- Algoritmos de ordenamiento implementados y validados
- Tablas de Reconocer calculadas
- Modelo batch operativo
- Servicio en línea en DB2
- APIs de consulta (si aplica)
- Documentación de procesos y algoritmos

### Estrategia de Paralelización

**Paralelización 1: Desarrollo con Datos Mock (M3-M5)**
- Equipo Redshift desarrolla algoritmos mientras EDF estandariza
- Usa datos mock o históricos para desarrollo
- Permite integración inmediata cuando datos reales estén listos

**Paralelización 2: Infraestructura Batch (M8-M9)**
- Preparación de batch mientras se ejecuta cálculo Reconocer
- Infraestructura lista para recibir datos apenas cálculo termine

**Paralelización 3: Servicio en Línea (M9-M10)**
- Preparación de DB2 y APIs mientras se completa batch
- Permite despliegue inmediato de servicio en línea

### Riesgos Críticos
- **ALTO**: Tiempos de procesamiento superiores a los actuales
- **ALTO**: Calidad de datos mock insuficiente para desarrollo (mitiga paralelización)
- **MEDIO**: Limitaciones de escalabilidad en Redshift
- **MEDIO**: Complejidad de integración con DB2
- **MEDIO**: Coordinación entre equipos para paralelización efectiva
- **BAJO**: Problemas de performance en consultas

---

## Arquitectura Seleccionada: EDF + Redshift

### Resumen de la Arquitectura

| Fase | Duración | Plataforma | Complejidad | Paralelización |
|------|----------|------------|-------------|----------------|
| Planeación | M1-M2 | N/A | Media | POC Libpostal en paralelo con workshop |
| Ingesta y Estandarización | M2-M7 | EDF | Alta | Desarrollo de ordenamiento en paralelo |
| Ordenamiento y Cálculo | M3-M10 | Redshift | Media | Múltiples actividades en paralelo |
| **Total Optimizado** | **10 meses** | **Híbrida** | **Alta** | **Ahorro: 2 meses** |
| **Total Conservador** | **12 meses** | **Híbrida** | **Alta** | **Sin paralelización** |

### Justificación de la Decisión

**Razón principal**: EDF (Experian Data Fabric) es por definición el punto de ingesta de todos los datos del bureau de Experian. Toda la información que entra a la plataforma debe pasar por EDF para mantener la consistencia con la estrategia XPMS.

**Ventajas de la arquitectura seleccionada**:
- Alineado con arquitectura estándar de Experian
- Aprovecha fortalezas de cada plataforma (EDF para transformaciones complejas, Redshift para cálculos SQL)
- Duración optimizada: 10 meses (con paralelización) vs 12 meses (conservador)
- Consistencia con estrategia XPMS
- Reutiliza infraestructura existente de EDF
- Permite paralelización efectiva entre equipos

**Consideraciones**:
- Complejidad de integración entre EDF y Redshift
- Transferencia de datos entre plataformas vía archivos XPM
- Requiere coordinación con equipo de EDF
- Requiere coordinación entre equipos para paralelización exitosa

### Estrategia de Paralelización

**Oportunidad 1: POC Libpostal + Workshop Arquitectura (M1)**
- **Ahorro**: 2-3 semanas
- **Riesgo**: Bajo (POC puede descartarse si workshop decide otra estrategia)
- **Equipos**: Arquitectura + Técnico

**Oportunidad 2: Ordenamiento + Estandarización (M3-M5)**
- **Ahorro**: 1-2 meses (LA MÁS IMPORTANTE)
- **Riesgo**: Medio (requiere datos mock de calidad)
- **Equipos**: EDF + Redshift
- **Detalle**: Redshift desarrolla algoritmos con datos mock mientras EDF estandariza

**Oportunidad 3: Batch + Cálculo Reconocer (M8-M9)**
- **Ahorro**: 1 mes
- **Riesgo**: Bajo
- **Equipos**: Cálculo + Infraestructura
- **Detalle**: Preparación de infraestructura batch mientras se ejecuta cálculo

**Oportunidad 4: Servicio en Línea + Batch (M9-M10)**
- **Ahorro**: 1 mes
- **Riesgo**: Bajo
- **Equipos**: Batch + Servicio en Línea
- **Detalle**: Preparación de DB2 y APIs mientras se completa batch

**Total ahorro con paralelización**: 3-4 meses
- **Cronograma conservador**: 12 meses (sin paralelización)
- **Cronograma optimizado**: 10 meses (paralelización conservadora)
- **Cronograma agresivo**: 8 meses (paralelización máxima)

### Requisitos para Paralelización Exitosa

1. **Equipos independientes**: Mínimo 2 equipos trabajando en paralelo (EDF + Redshift)
2. **Comunicación constante**: Sincronización semanal entre equipos
3. **Datos mock de calidad**: Para desarrollo de ordenamiento antes de tener datos reales
4. **Gestión de riesgos**: Plan de contingencia si alguna paralelización falla
5. **Coordinación de dependencias**: Claridad sobre qué equipo entrega qué y cuándo

### Opción Descartada

Se evaluó inicialmente una arquitectura unificada donde todo el procesamiento se realizaría en Redshift (19 meses). Esta opción fue descartada porque no se alinea con la arquitectura estándar de Experian, donde EDF es el pipeline obligatorio de ingesta y transformación de datos del bureau.

---

## Estrategia de Aceleración y Paralelización

### Cronograma Optimizado

**Objetivo original**: 12 meses (conservador)
**Objetivo optimizado**: 10 meses (con paralelización)
**Objetivo agresivo**: 8 meses (paralelización máxima + riesgos controlados)

### Acciones de Aceleración Implementadas

#### 1. Paralelización de Equipos (IMPLEMENTADA)
**Ahorro: 2-4 meses**

- **POC Libpostal + Workshop Arquitectura** (M1): 2-3 semanas ahorradas
- **Ordenamiento + Estandarización** (M3-M5): 1-2 meses ahorrados (LA MÁS IMPORTANTE)
- **Batch + Cálculo Reconocer** (M8-M9): 1 mes ahorrado
- **Servicio en Línea + Batch** (M9-M10): 1 mes ahorrado

#### 2. Uso de Herramientas Modernas (PROPUESTA)
**Ahorro potencial: 1-2 meses**

- **Cursor con IA**: Para acelerar desarrollo de código
- **Libpostal**: Librería open source para estandarización (vs migración manual de UDFs)
- **Infraestructura como código**: Terraform/CloudFormation para provisión rápida

#### 3. Enfoque en Resultado vs Replicación Exacta (PROPUESTA)
**Ahorro potencial: 1-2 meses**

- No recrear proceso tal cual está en Teradata
- Crear algo que llegue al mismo resultado usando herramientas modernas
- Priorizar funcionalidades críticas (MVP primero)
- Simplificar procesos donde sea posible sin perder calidad

### Cronograma Comparativo

| Enfoque | Duración | Estrategia | Riesgo |
|---------|----------|------------|--------|
| **Conservador** | 12 meses | Sin paralelización, desarrollo secuencial | Bajo |
| **Optimizado** | 10 meses | Paralelización de equipos, Libpostal | Medio |
| **Agresivo** | 8 meses | Paralelización máxima + IA + simplificación | Alto |
| **Original Christian** | 6 meses | Todas las aceleraciones + riesgos altos | Muy Alto |

### Riesgos de Aceleración

#### Riesgos Controlados (Cronograma Optimizado - 10 meses)
- **MEDIO**: Coordinación entre equipos para paralelización
- **MEDIO**: Calidad de datos mock para desarrollo anticipado
- **MEDIO**: Incompatibilidad de Libpostal con estándar colombiano (mitigado con POC)

#### Riesgos Adicionales (Cronograma Agresivo - 8 meses)
- **ALTO**: Pérdida de calidad en estandarización por velocidad
- **ALTO**: Deuda técnica por desarrollo acelerado
- **MEDIO**: Falta de documentación por velocidad
- **MEDIO**: Mayor probabilidad de bugs en producción

#### Riesgos Críticos (Cronograma Original - 6 meses)
- **CRÍTICO**: Pérdida significativa de calidad vs sistema actual
- **CRÍTICO**: Deuda técnica insostenible
- **ALTO**: Falta de validación adecuada
- **ALTO**: Equipo sobrecargado y burnout

### Recomendación

**Cronograma recomendado**: 10 meses (optimizado con paralelización)

**Justificación**:
- Balance óptimo entre velocidad y calidad
- Riesgos controlables con buena gestión
- Permite cumplir objetivo de octubre 2026 (iniciando en marzo)
- Mantiene calidad de estandarización
- Equipos trabajan a ritmo sostenible

**Plan de contingencia**:
- Si POC Libpostal falla: Pivote a migración UDFs (+4 meses → 14 meses total)
- Si paralelización falla: Revertir a cronograma conservador (12 meses)
- Si se requiere 6 meses: Reducir alcance funcional (MVP mínimo)

---

## Hitos Críticos

| Hito | Fecha Objetivo | Dependencias | Riesgo | Paralelización |
|------|----------------|--------------|--------|----------------|
| H1: Validación arquitectura | M2 | Workshop con arquitectura | CRÍTICO | POC Libpostal en paralelo |
| H2: POC Libpostal validado | M2 (semanas 1-2) | Diseño de solución | CRÍTICO | Ejecuta en paralelo con H1 |
| H3: Algoritmos diseñados | M4 | Migración parámetros | ALTO | Desarrollo con datos mock |
| H4: Estandarización operativa | M7 | POC Libpostal, integración ESRI | ALTO | Ordenamiento en paralelo |
| H5: Ordenamiento completo | M7 | Estandarización, algoritmos | ALTO | Integración datos reales |
| H6: Cálculo Reconocer | M9 | Ordenamiento, geolocalización | MEDIO | Batch en paralelo |
| H7: Batch completo | M9 | Cálculo Reconocer | MEDIO | Servicio en línea en paralelo |
| H8: Servicio en línea | M10 | Batch, integración DB2 | MEDIO | Preparación anticipada |

### Ruta Crítica con Paralelización

```
RUTA CRÍTICA OPTIMIZADA (10 MESES)
═══════════════════════════════════════════════════════════════

M1-M2: Validación + POC (PARALELO)
  ├─ Workshop Arquitectura (CRÍTICO)
  └─ POC Libpostal (PARALELO - CRÍTICO)
       │
       ▼
M2-M7: Estandarización EDF (CRÍTICO)
  │    ├─ DANE + Tipificación
  │    ├─ Limpieza + Acepciones
  │    ├─ Normalización
  │    └─ Unificación
  │
  │    PARALELO CON ↓
  │
M3-M5: Desarrollo Ordenamiento Redshift (PARALELO)
       ├─ Diseño algoritmos
       ├─ Desarrollo con datos mock
       └─ Tests unitarios
       │
       ▼
M5-M7: Integración y Validación
       ├─ Integración datos reales
       └─ Validación vs sistema actual
       │
       ▼
M8-M9: Cálculo + Geolocalización (CRÍTICO)
  │    ├─ Geolocalización ESRI
  │    └─ Cálculo Reconocer
  │
  │    PARALELO CON ↓
  │
M8-M9: Preparación Batch (PARALELO)
       ├─ Esquema tablas
       └─ Integración Control-M
       │
       ▼
M9-M10: Servicio en Línea (PARALELO)
        ├─ Preparación DB2
        └─ Desarrollo APIs

AHORRO TOTAL: 2 meses (12 → 10 meses)
```

### Impacto de Retrasos en Ruta Crítica

| Hito Retrasado | Impacto en Timeline | Mitigación |
|----------------|---------------------|------------|
| H1: Validación arquitectura | +2 semanas en total | Acelerar POC Libpostal |
| H2: POC Libpostal | +4 meses (pivote a UDFs) | Decisión rápida, plan B listo |
| H4: Estandarización | +1 mes por cada mes de retraso | Imposible mitigar (ruta crítica) |
| H5: Ordenamiento | +1 mes por cada mes de retraso | Paralelización ya aplicada |
| H6: Cálculo Reconocer | +2 semanas en total | Batch ya preparado en paralelo |

---

## Dependencias Externas

### Críticas
- **Equipo de Arquitectura Experian**: Validación de solución (~15 días)
- **ESRI/ArcGIS**: Integración para geolocalización
- **Equipo de Producto**: Validación de alcance y funcionalidades
- **DB2**: Disponibilidad para integración

### Importantes
- **Control-M**: Integración con malla de procesos
- **Confluence**: Acceso a documentación técnica
- **Ambiente AWS**: Provisión de recursos

---

## Criterios de Éxito

### Funcionales
- Cobertura de estandarización ≥ 95% vs sistema actual
- Calidad de direcciones válidas ≥ 90%
- Cobertura de geolocalización ≥ 70%
- Tiempo de procesamiento delta ≤ 6 horas (actual)

### No Funcionales
- Disponibilidad del servicio ≥ 99.5%
- Tiempo de respuesta consultas ≤ 2 segundos
- Capacidad de procesamiento full en ≤ 1 semana (vs 1 mes actual)
- Escalabilidad para 100M+ registros

### Negocio
- Solución batch operativa: Octubre 2026
- Servicio en línea operativo: Noviembre 2026
- Costos AWS dentro de presupuesto aprobado
- Cumplimiento de normativas de protección de datos

---

## Próximos Pasos

### Inmediatos (Semana 1-2)

1. **Agendar workshop con arquitectura Experian** (CRÍTICO)
   - Decisión: Etapa de estandarización en pipeline EDF
   - Decisión: Ubicación del ordenamiento (EDF vs Redshift)
   - Validación de arquitectura híbrida EDF + Redshift

2. **Ejecutar POC de Libpostal EN PARALELO con workshop** (CRÍTICO)
   - Obtener 10K direcciones colombianas reales
   - Configurar entorno Libpostal
   - Ejecutar pruebas de compatibilidad con DANE/DIVIPOLA
   - Medir performance (objetivo: ≤100ms por dirección)
   - Medir cobertura (objetivo: ≥85% parseables)
   - Medir compatibilidad (objetivo: ≥90% con estándar colombiano)

3. **Formar equipos de trabajo**
   - Equipo EDF: Ingesta y estandarización
   - Equipo Redshift: Ordenamiento y cálculo
   - Equipo Infraestructura: Batch y servicio en línea
   - Coordinador de integración entre equipos

### Corto Plazo (Semana 3-4)

4. **Decisión de estrategia de estandarización**
   - Si POC Libpostal exitoso: Integración completa + post-procesamiento DANE
   - Si POC Libpostal falla: Pivote a migración directa de UDFs (+4 meses)

5. **Diseño detallado de solución seleccionada**
   - Modelo de datos en Redshift
   - Arquitectura de integración EDF-Redshift
   - Plan de datos mock para desarrollo anticipado

6. **Plan de proyecto detallado con paralelización**
   - Cronograma con actividades en paralelo
   - Matriz de dependencias entre equipos
   - Plan de comunicación y sincronización

### Mediano Plazo (Mes 2)

7. **Inicio de implementación de ingesta en EDF**
   - Conexión con fuente Cobol
   - Cargue de datos maestros
   - Validación de integridad

8. **Inicio de preparación en Redshift EN PARALELO**
   - Diseño de modelo de datos
   - Migración de parámetros
   - Generación de datos mock para desarrollo

### Seguimiento y Control

9. **Sincronización semanal entre equipos**
   - Estado de avance de cada equipo
   - Identificación de bloqueos
   - Ajuste de plan según necesidad

10. **Validación de hitos críticos**
    - H1: Validación arquitectura (M2)
    - H2: POC Libpostal validado (M2)
    - H3: Algoritmos diseñados (M4)
    - H4: Estandarización operativa (M7)
    - H5: Ordenamiento completo (M7)
    - H6: Cálculo Reconocer (M9)
    - H7: Batch completo (M9)
    - H8: Servicio en línea (M10)

### Información Pendiente de Recopilar

- [ ] Volumetría detallada de todas las tablas
- [ ] DDLs de las UDFs en C
- [ ] Acceso a Confluence con documentación técnica
- [ ] Tablas de acepciones, nomenclaturas y topónimos
- [ ] Presupuesto AWS disponible
- [ ] Requisitos de seguridad y compliance en AWS
