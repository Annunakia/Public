# Contexto del Proyecto – EXPERIAN MAP RECONOCER

## Información General

| Campo | Valor |
|-------|-------|
| Cliente | Experian |
| Proyecto | Migración del Sistema Reconocer a AWS |
| Fecha de análisis | 2026-03-04 (actualizado 2026-03-19) |
| Ingeniero Preventa | [Nombre] |

---

## Objetivo del Proyecto

Migrar el sistema Reconocer desde la arquitectura actual (Cobol → Teradata → DB2) hacia una arquitectura cloud en AWS (IDF), con el objetivo de:

- Modernizar la plataforma tecnológica del producto Reconocer
- Mejorar los tiempos de procesamiento y escalabilidad
- Habilitar capacidades de procesamiento full (actualmente limitado a deltas)
- Implementar servicios en línea en la nube para consultas de datos de contacto
- Habilitar integración con nuevas fuentes de datos (ICS/Mi Data Crédito, Meta/WhatsApp)

## Descripción del Producto Reconocer (actualización 25/03/2026)

Reconocer es un producto de Experian que analiza toda la información de contacto reportada por suscriptores al buró de crédito. Estandariza y consolida datos de contacto (direcciones, teléfonos, correos electrónicos) de múltiples entidades financieras, generando un ranking basado en cantidad de entidades, reportes y cuentas abiertas. Orientado principalmente a cobranza y contactabilidad de clientes.

**Reconocer Máster** es la versión actual en producción (más de 5 años en el mercado).

### Versiones del Producto

#### Versiones en Línea (Portal)

| Versión | Descripción |
|---------|-------------|
| Esencial | Versión básica con menor cantidad de campos de salida (ej: 2 celulares, 2 correos, 2 direcciones) |
| Entorno | Versión intermedia |
| Avanzada | Versión con más campos |
| Geo | Versión con georreferenciación para clientes específicos |

#### Versiones en Microservicios

| Versión | Descripción |
|---------|-------------|
| Validación | Validación de datos de contacto |
| Validación con enriquecimiento | Validación + datos adicionales |

#### Versiones en Batch

8 versiones totales: Esencial, Digital, Ampliado, Conocimiento del Cliente, Validación, Entorno, Avanzado, e Índice de Contactabilidad.

**Nota**: Todas las versiones se basan en el mismo modelo precalculado completo que contiene todos los datos de contacto históricos. La diferencia está en la cantidad de datos de contacto entregados y la estructura de datos de salida.

### Canales de Consumo

| Canal | Descripción | Fuente de Datos |
|-------|-------------|-----------------|
| Portal (Lotes) | Consulta individual o en lote (hasta 99 registros, máx 10MB). Genera PDFs individuales por cédula válida | DB2 (precalculado) |
| Web Service | Consultas individuales en línea | DB2 (precalculado) |
| Batch | Lotes masivos con costos diferenciados. Genera Excel consolidado con pestañas | Teradata (no precalculado) |

**Hallazgo importante**: El canal Batch usa información directamente de Teradata, NO la precalculada de DB2. Esto tiene implicaciones para la migración.

---

## Situación Actual

### Descripción del Sistema Reconocer

Reconocer es el producto que entrega datos de contacto (direcciones, teléfonos, emails) a toda la compañía Experian. Características principales:

- **Cobertura**: 65-70 millones de ciudadanos (personas naturales y jurídicas)
- **Tipos de datos**: 
  - Información básica (cédula, fecha expedición, nombre, edad)
  - Datos de contacto (direcciones, teléfonos fijos, celulares, emails)
  - Indicadores de movilidad
  - Actividad económica
  - Puntos de interés

### Arquitectura Actual del Sistema Reconocer

#### Diagrama de Flujo General

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        ARQUITECTURA ACTUAL                               │
└─────────────────────────────────────────────────────────────────────────┘

┌──────────────┐         ┌──────────────────────────┐         ┌──────────┐
│              │         │                          │         │          │
│    COBOL     │────────▶│       TERADATA           │────────▶│   DB2    │
│   (ICBDIR)   │         │   (Procesamiento +       │         │ (Consulta│
│              │         │    Estandarización)      │         │  Online) │
│  Archivo     │         │                          │         │          │
│  Maestro     │         │  • UDFs en C             │         │  Tablas  │
│  Direcciones │         │  • 8 Etapas              │         │  Finales │
│              │         │  • 65-70M registros      │         │          │
└──────────────┘         └──────────────────────────┘         └──────────┘
      │                              │                              │
      │                              │                              │
      ▼                              ▼                              ▼
  Cargue                    Estandarización +                  Exposición
  Semanal                   Ordenamiento +                     Servicio
  (Deltas)                  Cálculo                            en Línea
```

#### Componentes Detallados

**1. COBOL (Origen)**
- Archivo: ICBDIR (maestro de direcciones)
- Contiene: Datos de contacto de 65-70M ciudadanos
- Limitación: No permite cargue full (solo deltas semanales)
- Tiempo cargue full: ~1 mes máquina

**Flujo de Carga ICBIR (detalle 26/03/2026):**
1. **Aplanado**: Convierte delta de direcciones de formato COBOL a CSV
2. **Particionamiento**: El aplanador parte el delta en archivos de millones de registros para procesamiento en paralelo
3. **Archivos de control (CTL)**: Cada archivo tiene un CTL con la cantidad de registros
4. **Transferencia**: Archivos se transfieren al servidor de Teradata (LOAT)
5. **Carga a Stage**: Control-M ejecuta shells para subir a tabla Stage con timestamp automático (evita duplicidad)
6. **Validaciones**: Cruces con VU personas (tipo/código identificación) y VU cuentas contra BDM. Si no existen, se rechazan.

**Problema conocido**: Cuando un suscriptor está bloqueado en COBOL, el dato no se carga. Si se desbloquea pero el delta no se reinyecta, ese dato se pierde. Esto se resuelve con Data Fabric (capa de curación) donde los datos no estarán filtrados.

**2. TERADATA (Procesamiento)**
- Validación de datos atados a obligaciones
- Estandarización compleja (8 etapas - ver sección detallada)
- Ordenamiento por reportes y lógicas de negocio
- Cálculo de indicadores y tablas finales
- Tecnología: UDFs desarrolladas en C para performance
- Tiempo procesamiento delta: 6 horas (fines de semana)

**3. DB2 (Exposición)**
- Almacena tablas finales por tipo y número de documento
- Servicio de consulta en línea
- ~8-10 tablas principales

### Modelo de Datos

Aproximadamente 8-10 tablas con tipo y número de documento como llave:

- **MatInfoBásica**: Datos básicos de la persona
- **Actividad Económica**: Información laboral
- **Ubicaciones**: Particionadas en personas naturales (~500M registros) y jurídicas
- **Puntos de Interés**: Lugares relevantes
- **Indicadores de Movilidad**: Cambios de dirección
- **Contactabilidad**: Datos de contacto validados

### Proceso de Estandarización de Direcciones (Componente Crítico)

La estandarización de direcciones es el proceso más complejo del sistema. Basado en el análisis de la documentación técnica, el proceso se divide en las siguientes etapas:

#### Diagrama de Flujo de Estandarización

```
┌─────────────────────────────────────────────────────────────────────────┐
│              PROCESO DE ESTANDARIZACIÓN (8 ETAPAS)                       │
└─────────────────────────────────────────────────────────────────────────┘

Entrada: Dirección cruda desde COBOL
    │
    ▼
┌─────────────────────────────────────┐
│  ETAPA 1: Identificación DANE       │  ← Catálogo DIVIPOLA
│  • Extrae código ciudad (8 dígitos) │  ← Tabla acepciones ciudades
│  • Match con DIVIPOLA                │  ← Algoritmos proximidad
│  Output: Dirección + Código DANE    │
└─────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────┐
│  ETAPA 2: Tipificación              │
│  • Clasifica en 4 tipos:            │
│    - VÍA (54.7%)                    │  ← Reglas parametrizadas
│    - MANZANA (2.0%)                 │  ← ~200 reglas
│    - RURAL (0.4%)                   │
│    - DESCRIPTIVA (42.9%)            │
│  Output: Dirección + Tipo           │
└─────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────┐
│  ETAPA 3: Limpieza                  │
│  • Elimina caracteres especiales    │  ← ~200 expresiones regulares
│  • Separa letras/números            │
│  • Normaliza espacios               │
│  Output: Dirección limpia           │
└─────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────┐
│  ETAPA 4: Acepciones y Topónimos    │
│  • CARRERA → KR                     │  ← Tabla REC_DATOS.PARAMETRO
│  • APARTAMENTO → AP                 │  ← Acepciones
│  • BARRIO → BR                      │  ← Topónimos
│  Output: Nomenclaturas homologadas  │  ← Excepciones
└─────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────┐
│  ETAPA 5: Normalización             │
│  • Ordena por pesos (7 niveles)    │  ← Tabla REC_DATOS.NOMENCLATURA
│  • Separa PUERTA / COMPLEMENTO      │  ← 89 nomenclaturas con pesos
│  • Valida estructura por tipo       │
│  Output: Dirección normalizada      │
└─────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────┐
│  ETAPA 6: Validación                │
│  • Verifica requisitos mínimos      │
│  • Marca VÁLIDA / NO VÁLIDA         │
│  Output: Dirección validada         │
└─────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────┐
│  ETAPA 7: Unificación (3 Reglas)   │
│  • Regla 1: Por tipo uso + CIIU    │  ← Diccionario Complementos
│  • Regla 2: Por complementos        │  ← Diccionario Vías
│  • Regla 3: Por geolocalización     │  ← Genera nuevas direcciones
│  Output: Direcciones unificadas     │     (concepto Padre-Hijo)
└─────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────┐
│  ETAPA 8: Geolocalización           │
│  • Calcula lat/long                 │  ← Servidor ESRI/ArcGIS
│  • Identifica puntos de interés     │
│  • Calcula distancias               │
│  Output: Dirección geolocalizada    │
└─────────────────────────────────────┘
    │
    ▼
Salida: Dirección estandarizada, validada, unificada y geolocalizada
```

#### Detalle de Etapas

#### 1. Identificación del Código DANE

Proceso que identifica la ciudad a partir del texto de ubicación original:
- Extrae códigos DANE de 8 dígitos del texto (ej: 95001017 para CHARRAS)
- Compara nombres de ciudades contra catálogo DIVIPOLA
- Usa tabla de acepciones para homologar nombres de ciudades
- Aplica algoritmos de proximidad para textos similares (ej: "EGOVIA ANTIOQU" → "SEGOVIA ANTIOQUIA")
- Validación: Direcciones físicas y teléfonos fijos requieren DANE obligatoriamente

#### 2. Tipificación de Direcciones

Determina el tipo de dirección según su estructura:

**Tipo VÍA** (54.7% de direcciones):
- Estructura: Tipo vía principal + Número vía principal + Número vía generadora + Número puerta
- Ejemplos: CL 22 27 23, KR 20BIS 17 30, TV 70 114A 55
- Componentes:
  - **Puerta**: Parte identificable de la vivienda (ej: CL 22 27 23)
  - **Complemento**: Detalles adicionales (ej: BR LOS ALMENDROS ETAPA 2, BL 12 AP 504)
- Validación: Requiere vía principal y puerta para ser válida
- Aplica para 1112 municipios (código DANE termina en "000")

**Tipo MANZANA** (2.0% de direcciones):
- Estructura: Duplas de Nomenclatura + Valor
- Ejemplos: MZ 3 CASA 1 B BALKANES, JARDIN 2 ET MZ 5 CS 19
- No tienen complemento (todo es parte de la puerta)
- Validación: Requiere mínimo 1 nomenclatura de barrio/conjunto para ser válida
- Nomenclaturas obligatorias: BR, MZ, SuperManzana, Lote, Sector, Conjunto, Urbanización

**Tipo RURAL** (0.4% de direcciones):
- Direcciones descriptivas sin estructura estándar
- Ejemplos: VDA ALISAL FCA EL MIRADOR, FINCA LA MARIA RESTO VDA POTREROGRANDE
- Validación: Requiere mínimo 2 nomenclaturas de tipo rural para ser válida
- Nomenclaturas: Vereda, Kilómetro, Finca, Hacienda, Quebrada, Corregimiento, Caserío

**Tipo DESCRIPTIVA** (42.9% de direcciones):
- Direcciones incompletas o literales sin estructura estándar
- Ejemplos: HOSPITAL LA MANGA CONSULTORIO 5, RESTAURANTE HARRY SAZON
- Marcadas como NO VÁLIDAS (no son ubicables)
- Solo se validan si se pueden geocodificar

#### 3. Limpieza (Etapa 2)

Eliminación de caracteres especiales y aplicación de expresiones regulares:
- Elimina: comas, puntos, guiones, numerales, paréntesis
- Elimina dobles espacios
- Separa letras de números (ej: "B105" → "B 105")
- Elimina expresiones: "No.", "Nro", "NRO"
- Aplica ~200 reglas de expresiones regulares parametrizadas

#### 4. Aplicación de Acepciones, Excepciones y Topónimos

Homologación de palabras clave usando tabla REC_DATOS.PARAMETRO:
- **Acepciones**: Homologación de nomenclaturas
  - Ejemplos: "CARRERA" → "KR", "APARTAMENTO" → "AP", "BARRIO" → "BR"
  - "CALLE", "CALE", "CAL" → "CL"
- **Topónimos**: Lugares conocidos y sus variaciones
- **Excepciones**: Casos especiales que requieren tratamiento diferente
- Proceso: Separa texto en palabras y reemplaza según tabla de acepciones

#### 5. Normalización

Ordenamiento de componentes según pesos establecidos:
- Ordena nomenclaturas por niveles (tabla REC_DATOS.NOMENCLATURA)
- Nivel 1 (más alto): Barrio, Ciudadela, Conjunto, Urbanización
- Nivel 2: Edificio, Multifamiliar, Portería, Parque, Zona
- Nivel 3-7: Manzana, Etapa, Bloque, Torre, Piso, Apartamento, Casa, etc.
- Separa PUERTA y COMPLEMENTO según tipo de dirección
- Ejemplo:
  - Entrada: CL 22 27 45 AP 401 BQ 4 PI 3 ALAMEDA
  - Salida: CL 22 27 45 BR ALAMEDA BQ 4 PI 3 AP 401

#### 6. Validación de Direcciones

Verifica que las direcciones cumplan requisitos mínimos según tipo:
- **Tipo VÍA**: Requiere vía principal + número vía principal + vía generadora + puerta
- **Tipo MANZANA**: Requiere mínimo 1 nomenclatura de barrio/conjunto
- **Tipo RURAL**: Requiere mínimo 2 nomenclaturas de tipo rural
- **Tipo DESCRIPTIVA**: Marcadas como NO VÁLIDAS
- Marca direcciones como VÁLIDA o NO VÁLIDA

#### 7. Unificación de Direcciones (3 Reglas)

Proceso que consolida direcciones similares para una misma persona:

**Regla 1: Unificación por Tipo de Uso y CIIU**
- Aplica cuando direcciones tienen misma puerta pero diferente tipo de uso (RES, LAB, CRR)
- Escenarios:
  - CIIU = 10 (Asalariado) + tipo LAB/CRR: Escoge por mayor número de entidades que reportan
  - CIIU = 81, 82, 90 (Sin actividad) + tipo RES/CRR: Escoge por mayor número de entidades
  - Otros CIIU: Escoge por mayor número de entidades que reportan
- Resultado: Dirección "padre" unifica a dirección "hija"

**Regla 2: Unificación por Complementos (Genera Nuevas Direcciones)**
- Aplica cuando direcciones tienen misma puerta pero diferente complemento
- Usa Diccionario de Complementos (frecuencia de nomenclaturas reportadas)
- Escenarios:
  - Un complemento vacío: Toma la más completa
  - Un complemento incluido en otro: Toma la más completa
  - Misma nomenclatura, diferente valor: Escoge por número de entidades o frecuencia
  - Nomenclaturas diferentes mismo nivel: Usa diccionario de frecuencias
  - Nomenclaturas diferentes distinto nivel: Genera nueva dirección combinando ambas
- Resultado: Puede generar dirección "padre" nueva combinando complementos

**Regla 3: Unificación por Geolocalización**
- Aplica cuando direcciones difieren en vía generadora o número de puerta
- Requiere latitud y longitud (proceso de geocodificación ESRI)
- Usa Diccionario de Vía (frecuencia de vías generadoras y puertas reportadas)
- Escenarios:
  - Solo una tiene lat/long: Escoge la que tiene geolocalización
  - Ninguna tiene lat/long: Escoge por fecha actualización o número de entidades
  - Ambas tienen lat/long: Usa diccionario de frecuencias
  - Para puertas: Valida diferencia ±2 posiciones
- Resultado: Dirección "padre" unifica a dirección "hija"

**Reglas Generales de Unificación**:
- Unificación por pares de direcciones (proceso recursivo)
- Concepto Padre-Hijo: Padre unifica, Hijo no vuelve a procesarse
- Direcciones hijas marcadas con Ind_Unificacion=1
- Reglas se aplican en cascada: Regla 1 → Regla 2 → Regla 3
- Solo se unifican direcciones sin padre previo y sin bloqueos

#### 8. Geolocalización (Enriquecimiento)

Proceso de enriquecimiento con servidor ESRI (ArcGIS):
- Calcula latitud y longitud de direcciones físicas
- Identifica puntos de interés cercanos
- Calcula distancias entre direcciones
- Información usada en Regla 3 de unificación
- Cobertura parcial (no todas las direcciones se geocodifican)

**Implementación actual**:
- UDFs (User Defined Functions) desarrolladas en C
- Razón: Mayor velocidad y paralelismo en Teradata
- Tablas de acepciones: ~200 reglas de expresiones regulares
- Tabla de nomenclaturas: 89 nomenclaturas con niveles y pesos
- Diccionarios: Complementos y Vías (calculados durante unificación)

### Arquitectura Técnica Detallada (actualización 25/03/2026)

#### Componentes Principales del Sistema Actual

| Componente | Función |
|------------|---------|
| DB2 | Almacena tablas precalculadas, estados de procesos y consecutivos |
| Teradata | Fuente de datos para procesamiento batch |
| Control-M | Orquesta la ejecución de procesos batch |
| Bizagio (BPM) | Gestión de flujos de casos |
| S3 Data Loading | Almacenamiento de archivos cargados |

#### Flujo de Procesamiento Batch

1. **Inicio**: Validación de formato y estructura del archivo
2. **Sincronización**
3. **Explotación** de información en Teradata
4. **Transferencia** de archivos
5. **Alistamiento**: Generación de plantillas Excel
6. **Cierre**: Cierre de caso en Bizagio y actualización en DB2

#### Web Services

- **WebUtil**: Gestión de estados y fechas
- **Solicitud Batch**: Gestión de solicitudes masivas
- **WebService**: Orquestación del proceso batch

### Fuentes de Datos Actuales (actualización 26/03/2026)

| Fuente | Descripción | Estado |
|--------|-------------|--------|
| ICBD (Buró de Crédito) | Fuente principal. Datos de contacto reportados por suscriptores (entidades financieras) | Activa |
| ARGIS / Geolitics | Enriquecimiento de georreferenciación (longitud, latitud, puntos de interés). Se enviaban lotes de ~1M direcciones vía API | **DESCONECTADA** — la integración cambió y el proceso dejó de funcionar. Contactar a Julián Méndez para definir cómo funciona ahora |
| Contactabilidad OTP (Evidente) | Proceso P0003. Idea: recibir archivos de proveedores externos con franjas horarias de contacto | **NUNCA SE ACTIVÓ** — el contrato con proveedores nunca se concretó. Excluir del alcance de migración |

### Nuevas Fuentes Planificadas (post-migración)

| Fuente | Descripción | Restricciones |
|--------|-------------|---------------|
| ICS (Mi Data Crédito) | Datos de contacto con autorizaciones y consentimientos de ciudadanos. NO está incluida en el modelo actual de Reconocer | Requiere consentimiento. No se puede mezclar con datos del buró tradicional |
| Meta/WhatsApp | Validación de números con WhatsApp habilitado vía web service | Por definir |
| Otras fuentes externas | Para probabilidad de contacto efectivo | Por definir |

### Restricciones Técnicas Actuales

- **No se puede hacer cargue full**: Restricción técnica de Cobol
- **Tiempo de cargue full**: Aproximadamente 1 mes máquina (proceso manual/automático)
- **Operación actual**: Cargue semanal de deltas
- **Ordenamiento**: Fines de semana (6 horas para deltas de una semana)
- **Limitación de ordenamiento**: Máximo 30 millones de ciudadanos o muchos lotes de direcciones

---

## Tecnologías Involucradas

### Tecnologías Actuales
- **Cobol**: Sistema origen (archivo ICBDIR - maestro de direcciones)
- **Teradata**: Procesamiento y estandarización (fuente para batch)
- **DB2**: Base de datos de consulta (tablas precalculadas para servicio en línea y portal)
- **C**: Lenguaje de UDFs para estandarización
- **Control-M**: Orquestación de procesos batch
- **Bizagio (BPM)**: Gestión de flujos de casos

### Tecnologías Propuestas (AWS)
- **EDF (Experian Data Fabric)**: Para cargue y estandarización
- **Amazon Redshift**: Para ordenamiento y cálculo
- **Aurora/DynamoDB**: Para servicio en línea (por definir)
- **Python**: Lenguaje propuesto para migración de lógica
- **Cursor con IA**: Herramienta para acelerar desarrollo

### Alternativa Evaluada - LIBPostal (Recomendada)

**LIBPostal** es una librería open source de NLP para estandarización de direcciones:

**Características**:
- Licencia MIT (código abierto, $0 USD de costo)
- Entrenada con millones de direcciones de OpenStreetMap (incluye Colombia)
- Procesa texto libre y lo clasifica estructuralmente
- Integración vía jpostal (bindings Java/Scala)
- Tiempos de respuesta en microsegundos

**Requisitos Técnicos**:
- 2-4 GB RAM por instancia para modelo en memoria
- Integración JNI (Java Native Interface) con librería C
- Requiere post-procesamiento para adaptar a estándar DANE/DIVIPOLA

**Análisis de Costos**:
- **Carga inicial (400M direcciones)**: $50-300 USD en cómputo cloud efímero
- **Operación anual (20M direcciones)**: Pocos dólares/mes en batch nocturno
- **Comparación vs Google Maps API**: 
  - Google: $1.6M USD inicial + $80K/año
  - Libpostal: $50-300 USD inicial + costo marginal
  - **Ahorro**: ~99.98%

**Ventajas**:
- Sin restricciones legales de almacenamiento
- Propiedad total de datos normalizados
- Escalable a volúmenes ilimitados
- Sin dependencia de APIs externas

**Desventajas**:
- Requiere configuración de entorno C + JNI
- Modelo global requiere ajuste para Colombia
- Mayor esfuerzo de integración inicial

---

## Contexto de XPMS y EDF (Experian Data Fabric)

### ¿Qué es XPMS?

XPMS (Experian Platform Management System) es la plataforma estratégica de Experian que centraliza toda la información de una persona en un único lugar. Es la visión arquitectónica de tener un "single source of truth" para cada ciudadano.

### ¿Qué es EDF (Experian Data Fabric)?

EDF es el pipeline de ingesta y procesamiento de datos de Experian, construido sobre Apache Spark (Scala). Es la puerta de entrada de todos los datos que llegan a la plataforma.

**Características principales:**
- Tecnología: Apache Spark + Scala
- Función: Ingesta, transformación y enriquecimiento de datos
- Fuentes: Bancos, telcos, empresas pequeñas, entidades gubernamentales
- Output: Archivos XPM (JSON)

### ¿Qué es un XPM?

XPM (eXperian Person Model) es un archivo JSON que contiene toda la información de una persona:

**Estructura:**
- 1 XPM = 1 Persona (identificada por tipo y número de documento)
- Contiene: Todos los reportes de todas las fuentes
- Incluye: Datos básicos, obligaciones, direcciones, teléfonos, emails, actividad económica, etc.
- Formato: JSON estructurado

**Ejemplo conceptual:**
```json
{
  "personId": "CC-12345678",
  "basicInfo": { ... },
  "addresses": [
    { "source": "Banco A", "address": "CL 22 27 45", "reportDate": "2025-01" },
    { "source": "Telco B", "address": "CL 22 27 45 AP 401", "reportDate": "2025-02" }
  ],
  "phones": [ ... ],
  "emails": [ ... ],
  "obligations": [ ... ]
}
```

### State Calculation en EDF

EDF tiene una fase llamada "State Calculation" donde se calculan los "mejores" datos de una persona usando reglas de negocio:

**Campos calculados:**
- `bestName`: Mejor nombre reportado (más completo, más reciente, fuente más confiable)
- `bestAddress`: Mejor dirección reportada
- `bestPhone`: Mejor teléfono reportado
- `bestEmail`: Mejor email reportado
- `bestAccount`: Mejor cuenta bancaria reportada

**Lógica de cálculo:**
- Priorización por fuente (bancos > telcos > otras)
- Priorización por fecha de reporte (más reciente)
- Priorización por completitud (más campos llenos)
- Reglas de negocio específicas por tipo de dato

---

## Decisiones Arquitectónicas Pendientes

### Decisión 1 (RESUELTA): Etapa de estandarización en EDF → CURATION

**Contexto del problema:**
- EDF es un pipeline de Spark/Scala con múltiples etapas de procesamiento
- EDF tiene una fase de "state calculation" que calcula los "mejores" datos (bestName, bestAddress, etc.)
- EDF genera archivos XPM (JSON) con toda la información de una persona
- La estandarización de Reconocer (8 etapas) debe insertarse en algún punto del pipeline de EDF

**Decisión (19/03/2026 — Llamada con equipo EDF/Ingesta):**

La estandarización de Reconocer se implementará en la etapa de **Curation** del pipeline EDF, con las siguientes definiciones:

1. **Se creará un campo nuevo** en la salida de Curation (ej: "nueva dirección estandarizada") que contendrá el resultado del nuevo algoritmo de estandarización (Libpostal o el que se defina).
2. **No se modifica el campo existente** de dirección estandarizada. El campo actual sigue funcionando con las reglas básicas heredadas de Cobol.
3. **El nuevo campo se mostrará en el XPM** como un campo adicional junto a la dirección original y la dirección estandarizada actual.
4. **Precondición**: El nombre del nuevo campo debe ser **único** en todo el ecosistema de fuentes de EDF. Ninguna fuente puede usar ese nombre. Se requiere una búsqueda previa en todos los archivos de configuración.
5. **No hay impacto en PINNING** (ver Decisión 3 más abajo).

**Estandarización actual en EDF (reglas básicas de Cobol):**

EDF actualmente aplica reglas simples de estandarización de direcciones, heredadas de Cobol:
- Reemplazar todos los caracteres especiales y letras con espacios
- Segmentar la cadena por dígitos
- Rellenar con ceros (padding) hasta longitud correcta
- Si longitud > 5, estandarizar como nulo
- Concatenar todos los segmentos
- Ordenar de mayor a menor

Estas reglas son significativamente más simples que el proceso de 8 etapas de Reconocer en Teradata.

**Proceso de Curation — Detalle operativo:**

| Tipo | Frecuencia | Alcance | Descripción |
|------|-----------|---------|-------------|
| Curation diaria | Diaria | Solo deltas entrantes | Se ejecuta como parte del pipeline normal (preparación → validación → aceptación → curación) |
| Curation Stop | Cada 1-2 semanas | Todos los datos aceptados (4 años de histórico) | Re-procesa todo el histórico contra reglas actualizadas. Útil cuando cambia una regla de estandarización, un catálogo, o se borran datos |

**Beneficios de Curation Stop:**
- Aplica cambios de reglas o catálogos a todo el histórico
- Crea archivos particionados (en vez de carpetas individuales), lo que mejora el desempeño de lectura en PINNING
- Permite reprocesar datos cuando se borran registros

---

### Decisión 2 (CRÍTICA): ¿Dónde hacer el Ordenamiento?

**Contexto del problema:**
- EDF ya tiene lógica de "state calculation" que calcula los "mejores" datos (bestName, bestAddress, etc.)
- Reconocer necesita ordenar direcciones, teléfonos y emails usando algoritmos de score
- Ambos procesos son conceptualmente similares: priorizar datos de contacto

**Pregunta clave:** ¿El ordenamiento de Reconocer debería hacerse en EDF o en Redshift?

---

### Opción A: Ordenamiento en EDF (Spark/Scala)

**Descripción:**
- Aprovechar la fase de "state calculation" de EDF
- Extender la lógica existente para incluir algoritmos de Reconocer
- Output: XPM con direcciones/teléfonos/emails ya ordenados

**Ventajas:**
- Reutiliza infraestructura existente (EDF ya calcula "best" fields)
- Consistencia: Toda la lógica de priorización en un solo lugar
- Alineado con estrategia XPMS (todo en EDF)
- Evita duplicación de lógica de ordenamiento
- Spark es eficiente para procesamiento distribuido

**Desventajas:**
- Requiere desarrollo en Scala (curva de aprendizaje)
- Menor flexibilidad para cambios (Spark vs SQL)
- Mayor complejidad de integración con Redshift
- Dependencia de equipo de EDF para cambios
- Posible impacto en performance de EDF

**Impacto en arquitectura:**
- Favorece Opción 1 (EDF + Redshift)
- EDF hace: Ingesta + Estandarización + Ordenamiento
- Redshift hace: Solo cálculo final y exposición

---

### Opción B: Ordenamiento en Redshift (SQL)

**Descripción:**
- EDF solo hace ingesta y estandarización
- Redshift recibe datos estandarizados y aplica algoritmos de ordenamiento
- Output: Tablas en Redshift con direcciones/teléfonos/emails ordenados

**Ventajas:**
- SQL es más simple y flexible que Scala
- Equipo Macondotek tiene más experiencia en SQL
- Independencia de EDF para cambios
- Redshift optimizado para queries analíticos
- Más fácil de mantener y modificar

**Desventajas:**
- Duplica lógica de priorización (EDF ya tiene "state calculation")
- Desalineado con estrategia XPMS
- Requiere transferir datos de EDF a Redshift
- Posible inconsistencia entre "best" fields de EDF y orden de Reconocer

**Impacto en arquitectura:**
- Favorece Opción 1 (EDF + Redshift) o Opción 2 (Solo Redshift)
- EDF hace: Ingesta + Estandarización
- Redshift hace: Ordenamiento + Cálculo + Exposición

---

### Decisión 3 (RESUELTA): Impacto en PINNING → NO SE TOCA

**Decisión (19/03/2026 — Llamada con equipo EDF/Ingesta):**

PINNING **no se modifica** como parte de este proyecto. Definiciones clave:

1. **PINNING sigue usando los campos actuales** de dirección estandarizada (reglas básicas de Cobol).
2. **El nuevo campo estandarizado NO será consumido por PINNING** inicialmente. PINNING no lo toma porque no está configurado en su lista de campos.
3. **No hay impacto en PINNING**: Solo se toman los mismos datos que se reciben y se puebla un nuevo campo con la estandarización nueva. PINNING ignora este campo.
4. **Integración futura (opcional)**: Si en el futuro se decide que el nuevo campo es mejor para PINNING, solo se requiere modificar el archivo de configuración `IdentifyingAttributesConfig` para que apunte al nuevo campo en vez del actual. Esto requeriría:
   - Apagar la estandarización actual en PINNING para evitar conflictos
   - Pruebas de regresión
   - Análisis interno del equipo de ingesta
5. **Independencia de proyectos**: Esta decisión permite que el proyecto Reconocer avance sin afectar ni depender de PINNING.

**Campos actuales que PINNING consume de Curation:**
- Dirección residencial estandarizada
- Dirección laboral estandarizada
- Dirección de correspondencia estandarizada
- Nombre estandarizado
- Tipo de identificación estandarizado
- Número de identificación estandarizado

**Archivo de configuración clave:** `IdentifyingAttributesConfig` — contiene la lista de campos utilizados para PINNING. Para cambiar qué campo de dirección usa PINNING, solo se modifica este archivo.

---

### Criterios de Decisión

| Criterio | EDF (Spark/Scala) | Redshift (SQL) |
|----------|-------------------|----------------|
| Alineación con XPMS | ✅ Alta | ❌ Baja |
| Reutilización de lógica | ✅ Alta (state calculation) | ❌ Baja (duplica lógica) |
| Simplicidad técnica | ❌ Baja (Scala) | ✅ Alta (SQL) |
| Flexibilidad para cambios | ❌ Baja | ✅ Alta |
| Experiencia del equipo | ❌ Baja (Scala) | ✅ Alta (SQL) |
| Performance | ✅ Alta (Spark distribuido) | ⚠️ Media (depende volumetría) |
| Independencia de EDF | ❌ Baja | ✅ Alta |
| Consistencia de datos | ✅ Alta | ⚠️ Media (posible divergencia) |

---

### Recomendación Preliminar

**Pendiente de validación con arquitectura Experian.**

Factores a considerar en el workshop:
1. ¿Qué tan alineado está el proyecto con la estrategia XPMS?
2. ¿Qué tan flexible es EDF para agregar lógica de Reconocer?
3. ¿Cuál es la capacidad del equipo en Scala vs SQL?
4. ¿Cuál es el impacto en performance de cada opción?
5. ¿Cuál es la visión a largo plazo de Reconocer en XPMS?

**Próximo paso crítico:** Incluir ambas decisiones (etapa de estandarización en EDF + ubicación de ordenamiento) en el workshop de validación arquitectónica (M1-M2).

---

## Restricciones Conocidas

### Restricciones de Negocio
- **Plazo octubre 2026**: Solución batch completa
- **Plazo noviembre 2026**: Servicio en línea funcionando en la nube
- **Hito intermedio junio 2026**: Datos estandarizados disponibles en XPM (deadline real para equipo EDF)
- **Estimación inicial**: 12 meses reducidos a 6 meses
- **Deadline Teradata**: Abril-mayo 2027 (renovación de licenciamiento). Si no se completa la migración, hay que renovar Teradata.

### Restricciones Técnicas
- **Validación con arquitectura**: Reunión del 16/03/2026 confirmó viabilidad. Pendiente workshops de detalle.
- **Dependencia crítica de IFR**: El proyecto depende de que IFR salga (fecha tentativa agosto 2026, depende de certificación de datos). Si IFR no sale, Reconocer no sale.
- **POC sobre pipeline IFR**: Se confirmó que la POC de Libpostal se ejecutará sobre el pipeline de IFR (no Alfa), en la etapa de Curation.
- **Triple aprobación de POC**: La POC requiere aprobación de: 1) Equipo de Datos (Caterina), 2) Equipo de Producto (Diego Reina/Julián Méndez), 3) Equipo de IFR/Pipeline (tiempo y performance).
- **Estandarización en Curation (confirmado 19/03)**: La nueva estandarización se implementa como campo nuevo en Curation. No se modifica el campo existente.
- **Nombre de campo único (precondición 19/03)**: El nombre del nuevo campo estandarizado debe ser único en todo el ecosistema de fuentes de EDF. Requiere búsqueda previa en todos los archivos de configuración para evitar colisiones.
- **No impacto en PINNING (confirmado 19/03)**: PINNING no se modifica. El nuevo campo no será consumido por PINNING inicialmente. Integración futura es opcional y requiere cambio en `IdentifyingAttributesConfig`.
- **Sección Locations del XPM**: Se debe validar si tiene todos los campos que necesita Reconocer. Si no, hay que crear nueva sección (proceso formal de gobierno de datos).
- **Estructura de tablas Redshift ≠ Teradata**: Los nombres de tablas cambian, lo que en Teradata es 1 tabla en Redshift puede ser 5. Los procedimientos almacenados no se pueden migrar directamente.
- **Funciones nativas de Teradata**: Algunos procedimientos usan funciones que no existen en Redshift.
- **Interoperabilidad Java/Scala confirmada**: Libpostal (Java) funciona dentro de Scala/Spark en Curation (confirmado por Francisco, 17/03/2026).
- **Compatibilidad de estandarización**: Si se usa LIBPostal, debe estandarizar igual que el sistema actual
- **Transformaciones solo en Curation (confirmado 19/03)**: Durante PINNING no se pueden transformar datos. Cada etapa del pipeline tiene sus propias reglas. Si es estandarización, debe pasar por Curation.

### Restricciones de Seguridad y Compliance
- Datos sensibles de 65-70 millones de ciudadanos
- Cumplimiento de normativas de protección de datos (Ley 1581 de 2012 – Habeas Data Colombia)
- Accesos a producción de Experian (consultar con Oscar Fajardo)
- **Restricción legal crítica (confirmada 25/03/2026)**: No se pueden mezclar datos del buró de crédito tradicional con datos de Nueva Data (ICS/Mi Data Crédito) que requieren consentimiento del ciudadano. Esto impacta directamente la integración de nuevas fuentes post-migración.

### Definiciones de Alcance de Estandarización (confirmado 25/03/2026)
- La estandarización de datos se moverá al equipo de datos (fuera del alcance de Reconocer)
- Reconocer trabajará con datos ya estandarizados para aplicar algoritmos de ordenamiento y precálculos
- Esto confirma la decisión del 19/03 de implementar estandarización en Curation (EDF)

---

## Stakeholders Identificados

### Lado Cliente (Experian)
- **Christian Sparacino**: Sponsor del proyecto, define fechas y estrategia
- **Fernando Garrido**: Senior Lead, líder técnico del proyecto
- **Equipo de Arquitectura**: Validación de solución (pendiente)
- **Equipo de Producto**: Revisión de alcance y funcionalidades

### Lado Macondotek
- **Fer/Wilmar**: Coordinación del proyecto y líder de preventa
- **Lorena**: Planeación
- **Francisco**: Líder técnico de líneas EDF y Redshift (parcial, compartido con plataforma)
- **Diego**: Desarrollador/guía en Curation (conoce el proceso, ha trabajado con Jorman y arquitectura)
- **Laura**: Equipo de plataforma (empoderada, maneja dailies, habla con Oxygen)
- **Oscar Fajardo**: Referente para accesos a producción de Experian
- **Juan Pablo Rodriguez**: Referente técnico de QuickSight
- **Equipo adicional por contratar**: 1 desarrollador Scala (deseable Java) 100%, 1 Data Engineer SQL, 1 QA
- **Diego Poveda**: Entrevista pendiente para ingesta o plataforma

### Lado Cliente (Experian) – Contactos Adicionales (actualización 16/03)
- **Ricardo Martínez**: Conocimiento del proceso de ordenamiento y reglas de negocio
- **Caterina**: Equipo de Datos, validación de criterios de estandarización
- **Diego Reina**: P.O. de Reconocer (Producto)
- **Julián Méndez**: P.O. de datos
- **Alejandro Restrepo**: Métricas de Curation de IFR
- **Johnny/Néstor**: Tablas y vistas en Redshift

---

## Insumos Recibidos del Cliente

### Documentación Técnica

| # | Documento | Ubicación | Descripción | Estado |
|---|-----------|-----------|-------------|--------|
| 1 | reunionContexto.md | comunicaciones/ | Transcripción de reunión técnica del 04/03/2026 | ✅ Procesado |
| 2 | Documento Funcional Estandarizacion Final V1.0 2.docx | docs/ | Proceso de estandarización con reglas, acepciones, nomenclaturas y pesos | ✅ Procesado |
| 3 | Documento Funcional Unificacion Final V1.0 2.docx | docs/ | Proceso de unificación de direcciones | ✅ Procesado |
| 4 | PlanMigracionAWS 2.xlsx | docs/ | Plan de migración a AWS con 2 opciones (OP1: 12 meses, OP2: 19 meses) | ✅ Procesado |
| 5 | Reconocer_EDF_Reshift 1.drawio | diagramas/ | Diagrama de arquitectura propuesta | ✅ Procesado |

### Documentación Adicional Mencionada (No Recibida)
- Confluence: Diagrama de tablas y modelos de Reconocer con índice
- DDLs de funciones UDF en C
- Documento del proceso de estandarización (reglas, acepciones, nomenclaturas, pesos)
- Documento de unificación

### Comunicaciones Adicionales (actualización 19/03/2026)

| # | Documento | Ubicación | Descripción | Estado |
|---|-----------|-----------|-------------|--------|
| 6 | transcripcion_reunion_experian_arquitectura_20260316.md | comunicaciones/ | Reunión con Experian: arquitectura, workshops, dependencias IFR, validación POC | ✅ Procesado |
| 7 | transcripcion_reunion_interna_macondotek_20260317.md | comunicaciones/ | Reunión interna: presentación a Francisco, viabilidad técnica, equipos, estimación | ✅ Procesado |
| 8 | resumen_reunion_experian_arquitectura_20260316.md | comunicaciones/ | Resumen ejecutivo de reunión del 16/03 | ✅ Generado |
| 9 | resumen_reunion_interna_macondotek_20260317.md | comunicaciones/ | Resumen ejecutivo de reunión del 17/03 | ✅ Generado |
| 10 | transcripcion_llamada_edf_ingesta_20260319.md | comunicaciones/ | Llamada con equipo EDF/Ingesta: definición etapa Curation, campo nuevo, no impacto PINNING | ✅ Procesado |
| 11 | resumen_llamada_edf_ingesta_20260319.md | comunicaciones/ | Resumen ejecutivo de llamada del 19/03 | ✅ Generado |
| 12 | transcripcion_reunion_reconocer_sesion_funcional_20260325.md | comunicaciones/ | Sesión de contexto funcional del producto Reconocer: versiones, canales, fuentes de datos, arquitectura técnica, restricción legal Nueva Data | ✅ Procesado |
| 13 | resumen_workshop_tecnico_migracion_reconocer_20260326.md | comunicaciones/ | Workshop técnico migración: carga ICBIR, estandarización, validaciones, geolocalización desconectada, OTP nunca activada | ✅ Procesado |

---

## Arquitectura de Migración Seleccionada

### Decisión Arquitectónica

Se ha seleccionado la **Arquitectura Híbrida EDF + Redshift** como solución de migración. 

**Justificación**: EDF (Experian Data Fabric) es por definición el punto de ingesta de todos los datos del bureau de Experian. Toda la información que entra a la plataforma debe pasar por EDF para mantener la consistencia con la estrategia XPMS (Experian Platform Management System).

**Nota**: Se evaluó inicialmente una Opción 2 (migración completa a Redshift) que fue descartada por no alinearse con la arquitectura estándar de Experian, donde EDF es el pipeline obligatorio de ingesta y transformación de datos.

### Diagrama de Arquitectura Seleccionada

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    ARQUITECTURA HÍBRIDA EDF + REDSHIFT                   │
│                              (12 meses)                                  │
└─────────────────────────────────────────────────────────────────────────┘

┌──────────┐         ┌─────────────────┐         ┌──────────┐         ┌─────┐
│  COBOL   │────────▶│   EDF PIPELINE  │────────▶│ REDSHIFT │────────▶│ DB2 │
│ (ICBDIR) │         │                 │         │          │         │     │
└──────────┘         │  • Ingesta      │         │ • Precál │         └─────┘
                     │  • Estandariza  │         │ • Ordena │
   Cargue            │    (8 etapas)   │         │ • Calcula│         Consulta
   Semanal           │  • M2-M9        │         │ • M4-M12 │         Online
                     │                 │         │          │
                     └─────────────────┘         └──────────┘
                            │                          │
                            ▼                          ▼
                     Transformación              Cálculo SQL
                     Compleja (UDFs)             Ordenamiento
```

### Distribución Temporal de Fases

```
ARQUITECTURA EDF + REDSHIFT - 12 MESES
═══════════════════════════════════════════════════════════════════

M1-M2    M3-M9                    M4-M7      M8-M12
┌────┐   ┌──────────────────┐    ┌──────┐   ┌────────────┐
│Plan│   │  EDF: Ingesta +  │    │Redsh:│   │Redsh: Calc │
│    │   │  Estandarización │    │Orden │   │+ Batch + DB│
└────┘   └──────────────────┘    └──────┘   └────────────┘
         ▲                        ▲          ▲
         │                        │          │
      8 Etapas                Algoritmos  Exposición
      Estandarización         Score       Final
```

### Arquitectura Híbrida EDF + Redshift

**Diagrama**: Ver `diagramas/Reconocer_EDF_Reshift 1.drawio` - Página "OP1"

**Estimación**: 12 meses

**Distribución de componentes**:

**EDF Pipeline (Ingesta + Estandarización) - Meses 1-7**:
- **M1-M2**: Planeación y evaluación de arquitectura
- **M2-M3**: Cálculo del DANE (extracción de ciudad y match con DIVIPOLA)
- **M3**: Tipificación de direcciones (VÍA, Manzana, Rural)
- **M3**: Limpieza (acepciones, topónimos, excepciones)
- **M3-M4**: Normalización (ordenamiento por pesos de nomenclaturas)
- **M5-M6**: Unificación de direcciones (3 reglas)
- **M3**: Estandarización de teléfonos/celulares (expresiones regulares, validación DANE)
- **M3**: Estandarización de email (expresiones regulares, validación)
- **M8-M9**: Geolocalización (integración con ESRI/ArcGIS para lat/long y puntos de interés)

**Redshift (Precálculo + Ordenamiento + Cálculo) - Meses 2-12**:
- **M2**: Diseño del modelo de datos Reconocer
- **M3**: Migración de parámetros y reestructuración
- **M3**: Migración de UDFs para explotación
- **M4-M5**: Ordenamiento de direcciones (algoritmos de score, orden 1)
- **M4**: Ordenamiento de teléfonos/celulares (algoritmos de score)
- **M4**: Ordenamiento de emails (algoritmos de score)
- **M7**: Cálculo de indicadores de movilidad
- **M8-M9**: Cálculo Reconocer general (precálculo para toda la población)
- **M10-M11**: Replicación del modelo Batch (esquema, Control-M, conexión con cargue)
- **M11-M12**: Conexión Redshift con DB2 (exportación, transferencia S3, cargue DB2)

**DB2 (Exposición)**:
- Base de datos para servicio en línea

**Diagrama**: Ver `diagramas/Reconocer_EDF_Reshift 1.drawio` - Página "OP1"

**Estimación**: 12 meses

**Ventajas**:
- **Alineado con arquitectura Experian**: EDF es el punto de ingesta obligatorio de todos los datos del bureau
- Aprovecha fortalezas de cada plataforma (EDF para transformaciones complejas, Redshift para cálculos SQL)
- Consistencia con estrategia XPMS (todos los datos pasan por EDF)
- Menor tiempo de implementación (12 meses)
- Reutiliza infraestructura existente de EDF

**Consideraciones**:
- Complejidad de integración entre EDF y Redshift
- Transferencia de datos entre plataformas vía archivos XPM
- Requiere coordinación con equipo de EDF para cambios

**Distribución de Componentes**:

**EDF Pipeline (Ingesta + Estandarización) - Meses 2-9**:
- **M1-M2**: Planeación y evaluación de arquitectura
- **M2-M3**: Cálculo del DANE (extracción de ciudad y match con DIVIPOLA)
- **M3**: Tipificación de direcciones (VÍA, Manzana, Rural, Descriptiva)
- **M3**: Limpieza (acepciones, topónimos, excepciones)
- **M3-M4**: Normalización (ordenamiento por pesos de nomenclaturas)
- **M5-M6**: Unificación de direcciones (3 reglas)
- **M3**: Estandarización de teléfonos/celulares (expresiones regulares, validación DANE)
- **M3**: Estandarización de email (expresiones regulares, validación)
- **M8-M9**: Geolocalización (integración con ESRI/ArcGIS para lat/long y puntos de interés)

**Redshift (Precálculo + Ordenamiento + Cálculo) - Meses 2-12**:
- **M2**: Diseño del modelo de datos Reconocer
- **M3**: Migración de parámetros y reestructuración
- **M3**: Migración de UDFs para explotación
- **M4-M5**: Ordenamiento de direcciones (algoritmos de score, orden 1)
- **M4**: Ordenamiento de teléfonos/celulares (algoritmos de score)
- **M4**: Ordenamiento de emails (algoritmos de score)
- **M7**: Cálculo de indicadores de movilidad
- **M8-M9**: Cálculo Reconocer general (precálculo para toda la población)
- **M10-M11**: Replicación del modelo Batch (esquema, Control-M, conexión con cargue)
- **M11-M12**: Conexión Redshift con DB2 (exportación, transferencia S3, cargue DB2)

**DB2 (Exposición)**:
- Base de datos para servicio en línea
- Recibe datos procesados desde Redshift

**Fases del Plan**:
1. **Ingesta y Estandarización** (M1-M9): Cargue y transformación en EDF
2. **Ordenamiento** (M4-M7): Algoritmos de score en Redshift
3. **Cálculo y Exposición** (M8-M12): Cálculo Reconocer y servicio en línea

---

### Opción Descartada: Migración Completa a Redshift

Se evaluó inicialmente una arquitectura unificada donde todo el procesamiento (ingesta, estandarización, ordenamiento y cálculo) se realizaría en Redshift, con una estimación de 19 meses.

**Razón de descarte**: Esta opción fue descartada porque **EDF es por definición el punto de ingesta de todos los datos del bureau de Experian**. Toda la información que entra a la plataforma debe pasar por EDF para mantener la consistencia con la estrategia XPMS y la arquitectura estándar de Experian.

Implementar la ingesta directamente en Redshift hubiera creado una inconsistencia arquitectónica y un bypass del pipeline estándar de datos de la compañía.

---

### Estrategia de Aceleración

Para cumplir con el plazo de octubre 2026 (6 meses vs 12 estimados):

**Acciones Propuestas por Christian Sparacino**:
- No recrear el proceso tal cual está en Teradata
- Crear algo que llegue al mismo resultado usando herramientas modernas
- Uso de Cursor con IA para acelerar desarrollo
- Evaluar uso de Libpostal para estandarización de direcciones
- Priorizar velocidad de entrega:
  - Octubre 2026: Solución batch completa
  - Noviembre 2026: Servicio en línea funcionando en la nube
- Paralelización de equipos trabajando en diferentes componentes

**Riesgos de Aceleración**:
- Pérdida de calidad en estandarización
- Deuda técnica por desarrollo acelerado
- Falta de documentación por velocidad

---

## Información Faltante / Pendiente

### Información Técnica
- [ ] Volumetría detallada de todas las tablas
- [ ] DDLs de las UDFs en C
- [ ] Acceso a Confluence con documentación técnica
- [ ] Tablas de acepciones, nomenclaturas y topónimos
- [ ] Lógica de validación de direcciones (reglas de negocio completas)
- [ ] Tiempos de procesamiento actuales por fase

### Información de Arquitectura
- [ ] Validación de la solución con equipo de arquitectura
- [ ] Definición de plataforma (EDF vs Redshift vs híbrido)
- [ ] Alineación con estrategia XPMS
- [ ] Requisitos de seguridad y compliance en AWS

### Información de Negocio
- [ ] Presupuesto AWS disponible
- [ ] Cobertura de AWS del proyecto
- [ ] Funcionalidades a incluir/excluir en la migración
- [ ] Criterios de éxito del proyecto

---

## Cronograma del Proyecto (Gantt)

### Diagrama de Gantt - Versión Optimizada con Paralelización

```
PROYECTO: Migración Sistema Reconocer a AWS (Arquitectura EDF + Redshift)
DURACIÓN OPTIMIZADA: 10 meses | INICIO: Marzo 2026 | FIN: Diciembre 2026
═══════════════════════════════════════════════════════════════════════════════

                    M1  M2  M3  M4  M5  M6  M7  M8  M9  M10
                    ───────────────────────────────────────
FASE 1: PLANEACIÓN Y DISEÑO (PARALELO)
├─ Workshop Arquitectura    ██
├─ POC Libpostal (PARALELO) ██              ← INICIA EN PARALELO CON WORKSHOP
├─ Diseño Modelo Datos          ██
├─ Plan Proyecto                ██
└─ Estimación AWS               ██
                    ───────────────────────────────────────
FASE 2: INGESTA Y ESTANDARIZACIÓN (EDF)
├─ Conexión Cobol               ██
├─ DANE + Tipificación              ██
├─ Limpieza + Acepciones            ██
├─ Normalización                    ██  ██
├─ Unificación                          ██  ██
├─ Estandarización Tel/Email        ██  ██
└─ Geolocalización ESRI                         ██  ██
                    ───────────────────────────────────────
FASE 3: ORDENAMIENTO Y CÁLCULO (REDSHIFT - PARALELO CON EDF)
├─ Migración Parámetros             ██          ← PARALELO CON ESTANDARIZACIÓN
├─ Diseño Algoritmos                ██  ██      ← PARALELO CON ESTANDARIZACIÓN
├─ Ordenamiento (con datos mock)       ██  ██  ← USA DATOS MOCK PARA ADELANTAR
├─ Ordenamiento (datos reales)              ██  ← INTEGRA DATOS REALES DE EDF
├─ Indicadores Movilidad                    ██
├─ Cálculo Reconocer                            ██
├─ Modelo Batch                                 ██  ██
└─ Servicio en Línea DB2                            ██
                    ───────────────────────────────────────
HITOS CRÍTICOS
H1: Validación Arquitectura     ▼
H2: POC Libpostal Validado      ▼
H3: Estandarización Operativa                   ▼
H4: Ordenamiento Completo                       ▼
H5: Batch Completo                                  ▼
H6: Servicio en Línea                                   ▼
                    ───────────────────────────────────────
REDUCCIÓN: 12 meses → 10 meses (2 meses ahorrados con paralelización)
```

### Oportunidades de Paralelización Identificadas

#### 1. POC Libpostal en Paralelo con Workshop de Arquitectura (M1)
**Ahorro: 2-3 semanas**

**Justificación**: El POC de Libpostal es técnico y no requiere decisiones arquitectónicas. Puede ejecutarse mientras se discute con arquitectura.

**Actividades en paralelo**:
- **Equipo A (Arquitectura)**: Workshop con equipo de arquitectura Experian
  - Decisión: Etapa de estandarización en pipeline EDF
  - Decisión: Ubicación del ordenamiento (EDF vs Redshift)
- **Equipo B (Técnico)**: POC de Libpostal
  - Obtener 10K direcciones colombianas reales
  - Configurar entorno Libpostal
  - Ejecutar pruebas de compatibilidad
  - Medir performance y cobertura

**Riesgo**: Si el workshop decide NO usar Libpostal, el POC se descarta. Riesgo aceptable dado el bajo costo del POC (40 horas).

---

#### 2. Diseño de Algoritmos de Ordenamiento en Paralelo con Estandarización (M3-M4)
**Ahorro: 1-2 meses**

**Justificación**: Los algoritmos de ordenamiento pueden diseñarse y desarrollarse con datos mock mientras EDF completa la estandarización.

**Actividades en paralelo**:
- **Equipo EDF**: Implementa estandarización (DANE, tipificación, limpieza, normalización)
- **Equipo Redshift**: Diseña e implementa algoritmos de ordenamiento
  - Migra parámetros y UDFs
  - Diseña algoritmos de score para direcciones, teléfonos, emails
  - Desarrolla lógica con datos mock (generados o históricos)
  - Crea tests unitarios

**Integración**: Una vez EDF entrega datos estandarizados reales (M5), Redshift los integra y valida.

**Beneficio**: El ordenamiento está listo para recibir datos reales apenas EDF termina, sin esperar 2 meses adicionales.

---

#### 3. Desarrollo de Modelo Batch en Paralelo con Cálculo Reconocer (M8-M9)
**Ahorro: 1 mes**

**Justificación**: El esquema de tablas batch y la integración con Control-M pueden prepararse mientras se ejecuta el cálculo Reconocer.

**Actividades en paralelo**:
- **Equipo A**: Ejecuta cálculo Reconocer general (precálculo para 65-70M ciudadanos)
- **Equipo B**: Prepara infraestructura batch
  - Migra esquema de tablas batch
  - Configura Control-M
  - Prepara scripts de automatización
  - Configura conexión con proceso de cargue

**Integración**: Una vez el cálculo Reconocer termina, los datos se cargan directamente al modelo batch ya preparado.

---

#### 4. Preparación de Servicio en Línea en Paralelo con Batch (M9-M10)
**Ahorro: 1 mes**

**Justificación**: La infraestructura de DB2 y APIs puede prepararse mientras se completa el modelo batch.

**Actividades en paralelo**:
- **Equipo A**: Completa modelo batch y validaciones
- **Equipo B**: Prepara servicio en línea
  - Configura DB2 en AWS (si aplica) o valida DB2 existente
  - Diseña esquema de tablas de consulta
  - Prepara scripts de exportación/transferencia vía S3
  - Desarrolla APIs de consulta (si aplica)

**Integración**: Una vez batch está listo, los datos se exportan al servicio en línea ya preparado.

---

### Cronograma Optimizado con Paralelización

#### Mes 1: Inicio Acelerado (Paralelización Crítica)
**Semana 1-2**:
- **Paralelo A**: Workshop con arquitectura Experian
- **Paralelo B**: POC de Libpostal con 10K direcciones colombianas
- **Paralelo C**: Diseño preliminar de modelo de datos en Redshift

**Semana 3-4**:
- Decisiones arquitectónicas tomadas
- Resultado POC Libpostal validado
- Plan de proyecto detallado

**Ahorro**: 2-3 semanas vs enfoque secuencial

---

#### Mes 2-5: Estandarización + Ordenamiento en Paralelo
**Equipo EDF** (M2-M5):
- Conexión Cobol
- Implementación de 8 etapas de estandarización
- Estandarización de teléfonos/emails

**Equipo Redshift** (M2-M5 - EN PARALELO):
- Migración de parámetros
- Diseño de algoritmos de ordenamiento
- Desarrollo con datos mock
- Tests unitarios

**Ahorro**: 1-2 meses vs esperar a que EDF termine

---

#### Mes 5-7: Integración y Unificación
**Equipo EDF** (M5-M7):
- Unificación de direcciones (3 reglas)
- Construcción de diccionarios

**Equipo Redshift** (M5-M7):
- Integración de datos reales de EDF
- Validación de algoritmos de ordenamiento
- Ajustes basados en datos reales

---

#### Mes 8-10: Cálculo, Batch y Servicio en Paralelo
**Equipo A** (M8-M9):
- Geolocalización ESRI
- Cálculo Reconocer general

**Equipo B** (M8-M9 - EN PARALELO):
- Preparación de modelo batch
- Configuración Control-M

**Equipo C** (M9-M10 - EN PARALELO):
- Preparación de servicio en línea DB2
- Desarrollo de APIs

**Ahorro**: 2 meses vs enfoque secuencial

---

### Resumen de Ahorro de Tiempo

| Paralelización | Ahorro Estimado | Riesgo |
|----------------|-----------------|--------|
| POC Libpostal + Workshop Arquitectura | 2-3 semanas | Bajo |
| Ordenamiento + Estandarización | 1-2 meses | Medio (requiere datos mock) |
| Batch + Cálculo Reconocer | 1 mes | Bajo |
| Servicio en Línea + Batch | 1 mes | Bajo |
| **TOTAL** | **3-4 meses** | **Medio** |

**Cronograma original**: 12 meses
**Cronograma optimizado**: 10 meses (con paralelización conservadora)
**Cronograma agresivo**: 8 meses (con paralelización máxima y riesgos controlados)

---

### Requisitos para Paralelización Exitosa

1. **Equipos independientes**: Mínimo 2 equipos trabajando en paralelo (EDF + Redshift)
2. **Comunicación constante**: Sincronización semanal entre equipos
3. **Datos mock de calidad**: Para desarrollo de ordenamiento antes de tener datos reales
4. **Gestión de riesgos**: Plan de contingencia si alguna paralelización falla
5. **Coordinación de dependencias**: Claridad sobre qué equipo entrega qué y cuándo

---

### Detalle de Actividades por Mes

#### Mes 1-2: Planeación y Diseño
- **Semana 1-2**: Workshop con arquitectura Experian
  - Decisión: Etapa de estandarización en pipeline EDF
  - Decisión: Ubicación del ordenamiento (EDF vs Redshift)
- **Semana 1-2**: POC de Libpostal con 10K direcciones colombianas
  - Criterio éxito: ≥90% compatibilidad con DANE/DIVIPOLA
- **Semana 3-4**: Diseño de modelo de datos en Redshift
- **Semana 3-4**: Plan de proyecto detallado y estimación AWS

#### Mes 2-3: Inicio de Ingesta y Estandarización (EDF)
- Conexión con fuente Cobol (archivo ICBDIR)
- Implementación de cargue delta semanal
- Etapa 1: Identificación de código DANE
- Etapa 2: Tipificación de direcciones (VÍA, MANZANA, RURAL, DESCRIPTIVA)
- Etapa 3: Limpieza con expresiones regulares
- Etapa 4: Aplicación de acepciones y topónimos
- Estandarización de teléfonos/celulares y emails (inicio)

#### Mes 3-4: Normalización y Migración de Parámetros
- Etapa 5: Normalización por pesos de nomenclaturas
- Separación de PUERTA y COMPLEMENTO
- Validación de direcciones según tipo
- Migración de parámetros a Redshift
- Migración de UDFs para explotación

#### Mes 4-5: Ordenamiento en Redshift
- Algoritmos de score para direcciones (orden 1)
- Algoritmos de score para teléfonos/celulares
- Algoritmos de score para emails
- Validación de resultados vs sistema actual

#### Mes 5-7: Unificación de Direcciones
- Regla 1: Unificación por tipo de uso y CIIU
- Regla 2: Unificación por complementos (genera nuevas direcciones)
- Regla 3: Unificación por geolocalización
- Construcción de diccionarios (Complementos y Vías)

#### Mes 7: Indicadores de Movilidad
- Cálculo de cambios de dirección
- Frecuencia de movilidad
- Patrones de desplazamiento

#### Mes 8-9: Geolocalización y Cálculo Reconocer
- Integración con servidor ESRI/ArcGIS
- Cálculo de latitud y longitud
- Identificación de puntos de interés
- Precálculo para toda la población (65-70M ciudadanos)
- Generación de tablas finales por tipo y número de documento

#### Mes 10-11: Modelo Batch
- Migración de esquema de tablas batch
- Integración con Control-M
- Automatización de procesos
- Conexión con proceso de cargue

#### Mes 11-12: Servicio en Línea
- Exportación de datos a formato DB2
- Transferencia vía S3
- Cargue en DB2
- Ajustes en Control-M
- Implementación de APIs de consulta (si aplica)

### Paralelización de Actividades

El proyecto permite paralelización en varios puntos:

**Mes 2-4**: Mientras EDF desarrolla estandarización, Redshift puede preparar:
- Diseño de modelo de datos
- Migración de parámetros
- Migración de UDFs

**Mes 4-7**: Mientras EDF completa unificación, Redshift puede desarrollar:
- Algoritmos de ordenamiento
- Indicadores de movilidad

**Mes 8-9**: Mientras EDF completa geolocalización, Redshift puede iniciar:
- Cálculo Reconocer general
- Preparación de modelo batch

### Ruta Crítica

La ruta crítica del proyecto incluye:
1. **M1-M2**: Validación arquitectónica y POC Libpostal (CRÍTICO)
2. **M2-M9**: Estandarización en EDF (CRÍTICO - no se puede avanzar sin esto)
3. **M4-M7**: Ordenamiento en Redshift (CRÍTICO - depende de datos estandarizados)
4. **M8-M9**: Cálculo Reconocer (CRÍTICO - depende de ordenamiento)
5. **M10-M12**: Batch y servicio en línea (CRÍTICO - entrega final)

Cualquier retraso en la ruta crítica impacta directamente la fecha de entrega final (Octubre 2026 para batch, Noviembre 2026 para servicio en línea).

### Estrategia de Aceleración (6 meses vs 12 meses)

Para cumplir con el plazo agresivo de 6 meses propuesto por Christian Sparacino:

**Acciones de aceleración**:
- Paralelización máxima de equipos (EDF + Redshift + DB2 simultáneos)
- Uso de Cursor con IA para acelerar desarrollo
- Priorización de funcionalidades críticas (MVP primero)
- Simplificación de proceso (no replicar exacto, enfocarse en resultado)
- Decisión rápida en M1 sobre Libpostal (si falla POC, pivote inmediato a migración UDFs)

**Riesgos de aceleración**:
- Pérdida de calidad en estandarización
- Deuda técnica por desarrollo acelerado
- Falta de documentación
- Mayor probabilidad de bugs en producción

---

## Próximos Pasos Inmediatos

1. **Análisis de documentación técnica**: Revisar los 3 documentos Word y el Excel de plan de migración
2. **Análisis del diagrama de arquitectura**: Revisar el archivo .drawio
3. **Solicitar información faltante**: Volumetría, DDLs, acceso a Confluence
4. **Workshop con arquitectura**: Planificar sesión de validación (~15 días)
5. **Definir estrategia de estandarización**: LIBPostal vs migración de UDFs vs nuevo desarrollo
6. **Validar alcance con producto**: Confirmar funcionalidades a migrar

---

## Notas Adicionales

- El sistema actual tiene casi toda la lógica documentada funcionalmente
- La estandarización de teléfonos y celulares es más simple (expresiones regulares y validaciones)
- El proceso de ordenamiento es principalmente SQL
- Se requiere alineación urgente con arquitectura antes de ejecutar
- Christian espera un plan de proyecto de alto nivel para revisión
- Se necesita definir capacidad de cómputo y costos según plataforma elegida
