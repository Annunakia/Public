# Roles Identificados – EXPERIAN MAP RECONOCER

## Información General

| Campo | Valor |
|-------|-------|
| Cliente | Experian |
| Proyecto | Migración del Sistema Reconocer a AWS |
| Fecha | 2026-03-04 (actualizado 2026-03-17) |
| Versión | 1.1 |

---

## Estructura del Equipo

### Lado Macondotek

#### Roles de Liderazgo

**1. Gerente de Proyecto**
- **Responsable**: Fer
- **Dedicación**: 30% (12 horas/semana)
- **Responsabilidades**:
  - Coordinación general del proyecto
  - Gestión de relación con cliente
  - Seguimiento de hitos y entregables
  - Escalamiento de riesgos e impedimentos
  - Reporte ejecutivo a stakeholders
- **Perfil**: Experiencia en proyectos de migración cloud, conocimiento de AWS

**2. Arquitecto de Solución / Líder Técnico**
- **Responsable**: Francisco (confirmado 17/03/2026)
- **Dedicación**: 50% (compartido con equipo de plataforma)
- **Responsabilidades**:
  - Líder técnico de líneas EDF y Redshift
  - Conceptualización y revisión de soluciones en Curation
  - Validación técnica con arquitectura Experian
  - Definición de estrategia de migración
  - Diseño de modelo de datos en Redshift
  - Revisión técnica de implementaciones
- **Perfil**: Conocimiento de EDF/Curation, Scala, AWS, experiencia en plataforma Experian

#### Roles Técnicos Especializados

**3. Experto Técnico Reconocer**
- **Responsable**: Wilmar
- **Dedicación**: 40% (16 horas/semana)
- **Responsabilidades**:
  - Transferencia de conocimiento del sistema actual
  - Validación de lógica de estandarización migrada
  - Soporte en interpretación de UDFs de C
  - Validación de calidad de resultados
  - Documentación de reglas de negocio
- **Perfil**: Conocimiento profundo del sistema Reconocer actual, Teradata, UDFs en C

**4. Líder Técnico de Estandarización / Desarrollador Guía EDF**
- **Responsable**: Diego (confirmado 17/03/2026, conoce Curation, ha trabajado con Jorman y arquitectura)
- **Dedicación**: 100% (40 horas/semana)
- **Responsabilidades**:
  - Guía técnica en Curation para el desarrollador Scala
  - Implementación de algoritmos de estandarización en Curation
  - Integración de Libpostal en pipeline IFR
  - Coordinación con equipo de arquitectura y Oxygen
  - Optimización de performance en Curation
- **Perfil**: Conocimiento de Curation/EDF, Scala, experiencia en pipeline de Experian
- **Nota**: Diego tiene rol técnico puro con mínima comunicación (solo daily). Francisco lo guía como líder técnico.

**5. Desarrollador Scala/EDF (x1)**
- **Responsable**: Por contratar (perfil Scala con deseable Java)
- **Dedicación**: 100% (40 horas/semana)
- **Responsabilidades**:
  - Desarrollo de implementación de estandarización en Curation
  - Integración de librería Libpostal (Java) en pipeline Scala
  - Desarrollo de post-procesamiento para DANE/DIVIPOLA
  - Pruebas de performance y escalabilidad
- **Perfil**: Scala (obligatorio), Java (deseable), AWS, conocimiento de Spark. Perfil similar al de Diego y Laura.
- **Nota**: Curva de aprendizaje estimada similar a la de Diego (~2-4 semanas con accesos).

**5b. Data Engineer SQL / Redshift (x1)**
- **Responsable**: Por contratar (perfil PL/SQL fuerte)
- **Dedicación**: 100% (40 horas/semana)
- **Responsabilidades**:
  - Re-implementación de algoritmos de ordenamiento en Redshift
  - Mapeo de fuentes, campos y tablas entre Teradata y Redshift
  - Migración de procedimientos almacenados (adaptados, no copiados)
  - Optimización de queries en Redshift
- **Perfil**: SQL avanzado (PL/SQL), experiencia con Redshift, conocimiento de Teradata deseable.
- **Nota**: Perfil completamente distinto al de Scala. Los procedimientos almacenados de ordenamiento son muy grandes (ej: 420 pasos para teléfonos).

**6. Desarrollador de Integración**
- **Responsable**: Por asignar
- **Dedicación**: 75% (30 horas/semana)
- **Responsabilidades**:
  - Integración con ESRI/ArcGIS para geolocalización
  - Conexión con fuente Cobol (ICBDIR)
  - Integración Redshift → DB2
  - Implementación de APIs de consulta
  - Integración con Control-M
- **Perfil**: APIs REST, integración de sistemas, Python, experiencia con servicios de geolocalización

**7. Ingeniero de Datos**
- **Responsable**: Por asignar
- **Dedicación**: 100% (40 horas/semana)
- **Responsabilidades**:
  - Diseño e implementación de modelo de datos
  - Migración de tablas paramétricas
  - Optimización de queries en Redshift
  - Gestión de diccionarios (Complementos, Vías)
  - Monitoreo de volumetría y performance
- **Perfil**: Modelado de datos, SQL avanzado, Redshift, experiencia con grandes volúmenes

#### Roles de Soporte

**8. Especialista en QA/Testing**
- **Responsable**: Por asignar
- **Dedicación**: 75% (30 horas/semana)
- **Responsabilidades**:
  - Diseño de plan de pruebas
  - Validación de calidad de estandarización
  - Comparación de resultados vs sistema actual
  - Pruebas de performance y escalabilidad
  - Automatización de pruebas
- **Perfil**: Testing de sistemas de datos, Python, SQL, experiencia en validación de calidad de datos

**9. Especialista en Infraestructura AWS**
- **Responsable**: Oscar Fajardo (referente)
- **Dedicación**: 25% (10 horas/semana)
- **Responsabilidades**:
  - Provisión de ambientes AWS
  - Configuración de seguridad y accesos
  - Monitoreo de recursos y costos
  - Soporte en troubleshooting de infraestructura
  - Gestión de accesos a producción Experian
- **Perfil**: AWS (IAM, VPC, CloudWatch), seguridad cloud, compliance

**10. Especialista en Visualización (Opcional)**
- **Responsable**: Juan Pablo Rodriguez (referente)
- **Dedicación**: 10% (4 horas/semana)
- **Responsabilidades**:
  - Soporte en dashboards de monitoreo
  - Visualización de métricas de calidad
  - Reportes ejecutivos en QuickSight
- **Perfil**: QuickSight, visualización de datos

---

### Lado Cliente (Experian)

**11. Sponsor del Proyecto**
- **Responsable**: Christian Sparacino
- **Responsabilidades**:
  - Definición de estrategia y fechas
  - Aprobación de decisiones arquitectónicas
  - Gestión de presupuesto
  - Escalamiento ejecutivo

**12. Líder Técnico Cliente**
- **Responsable**: Fernando Garrido (Senior Lead)
- **Responsabilidades**:
  - Validación técnica de solución
  - Coordinación con equipos internos Experian
  - Aprobación de diseños técnicos
  - Soporte en accesos y permisos

**13. Equipo de Arquitectura Experian**
- **Responsabilidades**:
  - Validación de arquitectura propuesta
  - Aprobación de partición EDF/Redshift (si aplica)
  - Validación de alineación con XPMS
  - Revisión de seguridad y compliance

**14. Equipo de Producto Experian**
- **Responsable**: Diego Reina (P.O. de Reconocer), Julián Méndez (P.O. de datos)
- **Responsabilidades**:
  - Validación de alcance y funcionalidades
  - Definición de criterios de aceptación de estandarización
  - Priorización de features
  - Validación de calidad de resultados
  - Aprobación de POC (una de las tres aprobaciones requeridas)

**15. Equipo de Datos Experian**
- **Responsable**: Caterina
- **Responsabilidades**:
  - Validación de criterios de estandarización
  - Aprobación de POC (una de las tres aprobaciones requeridas)
  - Definición de estándares de calidad de datos

**16. Contactos Técnicos Experian (actualización 16/03)**
- **Ricardo Martínez**: Conocimiento del proceso de ordenamiento y reglas de negocio
- **Alejandro Restrepo**: Métricas de Curation de IFR
- **Johnny**: Tablas y vistas en Redshift
- **Néstor**: Vistas en Redshift
- **Diego Santucci**: Validación de sección Locations del XPM

---

## Matriz RACI

| Actividad | Gerente Proyecto | Arquitecto | Experto Reconocer | Líder Estandarización | Dev AWS | Dev Integración | Ing Datos | QA | Infra AWS | Sponsor | Líder Técnico Cliente | Arq Experian |
|-----------|------------------|------------|-------------------|----------------------|---------|-----------------|-----------|----|-----------|---------|-----------------------|--------------|
| Validación arquitectura | C | R | C | I | I | I | I | I | C | A | A | A |
| Diseño modelo datos | C | A | C | C | I | I | R | I | I | I | C | C |
| Migración UDFs | I | C | A | R | C | I | I | C | I | I | C | I |
| Implementación estandarización | C | C | A | R | R | C | C | C | I | I | C | I |
| Implementación ordenamiento | C | C | C | C | R | I | R | C | I | I | C | I |
| Integración ESRI | C | C | I | I | C | R | I | C | C | I | C | I |
| Integración DB2 | C | C | I | I | C | R | C | C | C | I | A | I |
| Pruebas y validación | C | C | A | C | C | C | C | R | I | I | A | I |
| Despliegue producción | A | C | C | I | C | C | C | C | R | A | A | C |

**Leyenda**: R=Responsable, A=Aprobador, C=Consultado, I=Informado

---

## Distribución por Fase

### Fase 1: Planeación y Diseño (M1-M2)

| Rol | Dedicación | Actividades Principales |
|-----|------------|------------------------|
| Arquitecto | 100% | Diseño de arquitectura, validación con Experian |
| Experto Reconocer | 60% | Transferencia de conocimiento, documentación |
| Gerente Proyecto | 50% | Coordinación de workshops, planificación |
| Ing Datos | 50% | Diseño de modelo de datos |
| Infra AWS | 50% | Diseño de infraestructura, estimación de costos |

**Total**: ~3.1 FTE

---

### Fase 2: Ingesta y Estandarización (M2-M9)

| Rol | Dedicación | Actividades Principales |
|-----|------------|------------------------|
| Líder Estandarización | 100% | Desarrollo de algoritmos de estandarización |
| Dev AWS (x2) | 100% | Desarrollo de pipelines, implementación |
| Experto Reconocer | 40% | Validación de lógica, soporte técnico |
| Dev Integración | 75% | Integración con Cobol, ESRI |
| Ing Datos | 100% | Migración de parámetros, diccionarios |
| QA | 75% | Validación de calidad, pruebas |
| Arquitecto | 30% | Revisión técnica, soporte |
| Gerente Proyecto | 30% | Seguimiento, coordinación |
| Infra AWS | 25% | Soporte de infraestructura |

**Total**: ~7.5 FTE

---

### Fase 3: Ordenamiento y Cálculo (M4-M12)

| Rol | Dedicación | Actividades Principales |
|-----|------------|------------------------|
| Dev AWS (x2) | 100% | Implementación de ordenamiento y cálculo |
| Ing Datos | 100% | Optimización de queries, modelo batch |
| Dev Integración | 75% | Integración DB2, APIs |
| QA | 75% | Pruebas de performance, validación |
| Experto Reconocer | 30% | Validación de resultados |
| Arquitecto | 25% | Revisión técnica |
| Gerente Proyecto | 30% | Seguimiento, coordinación |
| Infra AWS | 25% | Monitoreo, optimización |

**Total**: ~6.6 FTE

---

## Perfil de Carga del Equipo

```
FTE
10 |                    
 9 |                    
 8 |     ┌──────────┐   
 7 |     │          │   
 6 |     │          ├───┐
 5 |     │          │   │
 4 |     │          │   │
 3 |  ┌──┤          │   │
 2 |  │  │          │   │
 1 |  │  │          │   │
 0 └──┴──┴──────────┴───┴──
   M1 M2 M3-M9    M10-M12
```

**Pico de equipo**: Meses 3-9 (Fase de Estandarización) con ~7.5 FTE

---

## Necesidades de Contratación

### Inmediatas (Abril 2026 – Inicio del proyecto)
- Desarrollador Scala (deseable Java) – 100% dedicado a EDF/Curation (1)
- Data Engineer SQL – 100% dedicado a Redshift (1)
- Entrevista pendiente con Diego Poveda para ingesta o plataforma

### Corto Plazo (Mes 2)
- Especialista en QA/Cuba (1) – pruebas de estandarización y ordenamiento

### Roles Ya Asignados (actualización 17/03)
- Francisco: Líder técnico de líneas EDF y Redshift (parcial)
- Diego: Desarrollador/guía en Curation (100%)
- Laura: Se queda en plataforma (no se mueve a Reconocer)

---

## Riesgos de Equipo

| Riesgo | Probabilidad | Impacto | Mitigación |
|--------|--------------|---------|------------|
| Dificultad para encontrar experto en migración Teradata→AWS | Alta | Alto | Iniciar búsqueda inmediata, considerar consultores externos |
| Disponibilidad limitada de Wilmar (40%) | Media | Alto | Documentar conocimiento crítico, sesiones de transferencia intensivas |
| Rotación de personal durante proyecto largo | Media | Medio | Documentación continua, pair programming, knowledge sharing |
| Falta de experiencia en UDFs de C | Alta | Alto | Capacitación, soporte de Wilmar, considerar experto externo |
| Sobrecarga en fase de estandarización | Alta | Medio | Planificar refuerzos, priorizar funcionalidades |

---

## Capacitación Requerida

### Equipo Macondotek
- AWS Redshift avanzado (todos los desarrolladores)
- Experian Data Fabric - EDF (si se selecciona Opción 1)
- Sistema Reconocer actual (todos los técnicos)
- ESRI/ArcGIS APIs (desarrollador de integración)
- Estándares de direcciones colombianas (líder de estandarización)

### Equipo Experian
- Arquitectura AWS propuesta (equipo de arquitectura)
- Nuevos procesos y APIs (equipo de producto)

---

## Modelo de Trabajo

### Metodología
- Scrum con sprints de 2 semanas
- Daily standups (15 min)
- Sprint planning, review y retrospectiva
- Demos quincenales con cliente

### Herramientas
- Gestión: Jira / Azure DevOps
- Comunicación: Slack / Teams
- Código: Git / GitHub / GitLab
- Documentación: Confluence
- CI/CD: Jenkins / GitHub Actions

### Horarios
- Equipo Macondotek: Horario Colombia (GMT-5)
- Sincronización con Experian: Reuniones en horario compatible
- Disponibilidad para soporte: 8am-6pm COT

---

## Próximos Pasos

1. **Inmediato**: Confirmar disponibilidad de Wilmar (40%) y Fer (30%)
2. **Semana 1**: Iniciar búsqueda de Arquitecto de Solución
3. **Semana 2**: Definir perfiles detallados para contratación
4. **Semana 3-4**: Proceso de selección de roles críticos
5. **Mes 2**: Onboarding de equipo inicial

*Nota: Costos de servicios profesionales son responsabilidad del área comercial*
