# WBS Inicial – EXPERIAN MAP RECONOCER

## Información General

| Campo | Valor |
|-------|-------|
| Cliente | Experian |
| Proyecto | Migración del Sistema Reconocer a AWS |
| Fecha | 2026-03-04 (actualizado 2026-03-19) |
| Versión | 2.2 |
| Arquitectura Seleccionada | Híbrida EDF + Redshift |
| Cronograma Recomendado | 10 meses (optimizado con paralelización) |
| Cronograma Conservador | 12 meses (sin paralelización) |

---

## Estructura de Desglose del Trabajo (WBS)

### 1. PLANEACIÓN Y DISEÑO (M1-M2)

#### 1.1 Validación Arquitectónica
- 1.1.1 Preparación de workshop con arquitectura Experian
- 1.1.2 Presentación de opciones arquitectónicas (EDF+Redshift vs Solo Redshift)
- 1.1.3 Validación de compatibilidad con XPMS
- 1.1.4 Decisión de arquitectura objetivo
- 1.1.5 Documentación de decisiones arquitectónicas

**Duración**: 3 semanas | **Esfuerzo**: 120 horas | **Riesgo**: CRÍTICO

#### 1.2 Diseño de Solución
- 1.2.1 Diseño de modelo de datos en Redshift
- 1.2.2 Diseño de pipelines de ingesta
- 1.2.3 Arquitectura de integración con ESRI/ArcGIS
- 1.2.4 **POC Interna Previa (NUEVO)**: Ejercicio interno Macondotek con Libpostal fuera de ambiente Experian. Direcciones de ejemplo, evaluar salida vs sistema actual. Usar herramientas de IA (Claude Code, Kiro).
- 1.2.5 **POC Formal de Libpostal (CRÍTICO)**: Validación con 10K direcciones colombianas sobre pipeline IFR, etapa de Curation
- 1.2.6 **Triple Aprobación de POC**: Datos (Caterina) + Producto (Diego Reina/Julián Méndez) + Pipeline IFR (performance)
- 1.2.7 Evaluación de resultados POC y decisión de estrategia de estandarización
- 1.2.8 Estrategia de migración de UDFs (si POC falla) o integración Libpostal (si POC exitoso)
- 1.2.9 **Validación de sección Locations del XPM (NUEVO)**: Diego Santucci valida con Johnny si tiene todos los campos para Reconocer

**Duración**: 4 semanas | **Esfuerzo**: 240 horas | **Riesgo**: CRÍTICO

#### 1.3 Planeación Operativa
- 1.3.1 Definición de ambientes (DEV, QA, PROD)
- 1.3.2 Estrategia de cargue (full vs delta)
- 1.3.3 Plan de pruebas y validación
- 1.3.4 Estimación de capacidad AWS y costos
- 1.3.5 Plan de proyecto detallado

**Duración**: 3 semanas | **Esfuerzo**: 100 horas | **Riesgo**: MEDIO

**TOTAL FASE 1**: 8 semanas | 420 horas | ~2.6 FTE promedio

---

### 2. INGESTA Y ESTANDARIZACIÓN (M2-M9)

#### 2.1 Implementación de Ingesta
- 2.1.1 Conexión con fuente Cobol (ICBDIR)
- 2.1.2 Desarrollo de pipeline de cargue
- 2.1.3 Validación de integridad de datos
- 2.1.4 Implementación de proceso delta semanal
- 2.1.5 Pruebas de cargue

**Duración**: 4 semanas | **Esfuerzo**: 240 horas | **Riesgo**: MEDIO

#### 2.2 Estandarización de Direcciones

##### 2.2.0 Integración de Libpostal (M2-M3) - NUEVO
- 2.2.0.1 Setup de ambiente con dependencias C y JNI
- 2.2.0.2 Integración de librería Libpostal con Python/Java
- 2.2.0.3 Desarrollo de wrapper para invocación desde Redshift
- 2.2.0.4 Pruebas de performance y escalabilidad
- 2.2.0.5 Configuración de instancias EC2 con 4GB RAM

**Duración**: 4 semanas | **Esfuerzo**: 160 horas | **Riesgo**: MEDIO

##### 2.2.1 Identificación de DANE (M2-M3)
- 2.2.1.1 Extracción de códigos DANE del texto (usando output de Libpostal)
- 2.2.1.2 Implementación de match con DIVIPOLA
- 2.2.1.3 Migración de tabla de acepciones de ciudades
- 2.2.1.4 Implementación de algoritmos de proximidad
- 2.2.1.5 Validación de cobertura de DANE

**Duración**: 6 semanas | **Esfuerzo**: 320 horas | **Riesgo**: ALTO

##### 2.2.2 Tipificación (M3)
- 2.2.2.1 Implementación de clasificación en 4 tipos
- 2.2.2.2 Desarrollo de reglas de validación por tipo
- 2.2.2.3 Migración de reglas parametrizadas (~200)
- 2.2.2.4 Pruebas de tipificación
- 2.2.2.5 Validación de distribución (VÍA 54.7%, MANZANA 2%, RURAL 0.4%, DESCRIPTIVA 42.9%)

**Duración**: 4 semanas | **Esfuerzo**: 320 horas | **Riesgo**: ALTO

##### 2.2.3 Limpieza (M3)
- 2.2.3.1 Post-procesamiento de output de Libpostal
- 2.2.3.2 Desarrollo de expresiones regulares complementarias (~50 adicionales)
- 2.2.3.3 Implementación de separación letras/números
- 2.2.3.4 Normalización de espacios
- 2.2.3.5 Pruebas de limpieza

**Duración**: 3 semanas | **Esfuerzo**: 120 horas | **Riesgo**: BAJO

##### 2.2.4 Acepciones y Topónimos (M3)
- 2.2.4.1 Migración de tabla de acepciones (REC_DATOS.PARAMETRO)
- 2.2.4.2 Homologación de nomenclaturas de Libpostal a estándar colombiano
- 2.2.4.3 Procesamiento de topónimos
- 2.2.4.4 Aplicación de excepciones
- 2.2.4.5 Validación de cobertura

**Duración**: 3 semanas | **Esfuerzo**: 160 horas | **Riesgo**: MEDIO

##### 2.2.5 Normalización (M3-M4)
- 2.2.5.1 Validación de output de Libpostal vs tabla de nomenclaturas (89 nomenclaturas, 7 niveles)
- 2.2.5.2 Implementación de ordenamiento por pesos
- 2.2.5.3 Desarrollo de separación PUERTA/COMPLEMENTO
- 2.2.5.4 Validación de direcciones por tipo
- 2.2.5.5 Pruebas de normalización

**Duración**: 6 semanas | **Esfuerzo**: 320 horas | **Riesgo**: MEDIO

##### 2.2.6 Unificación (M5-M7)
- 2.2.6.1 Implementación de Regla 1 (tipo de uso y CIIU)
- 2.2.6.2 Implementación de Regla 2 (complementos, genera nuevas direcciones)
- 2.2.6.3 Implementación de Regla 3 (geolocalización)
- 2.2.6.4 Construcción de Diccionario de Complementos
- 2.2.6.5 Construcción de Diccionario de Vías
- 2.2.6.6 Pruebas de unificación

**Duración**: 10 semanas | **Esfuerzo**: 600 horas | **Riesgo**: ALTO

##### 2.2.7 Geolocalización (M8-M9)
- 2.2.7.1 Integración con servidor ESRI/ArcGIS
- 2.2.7.2 Implementación de cálculo de lat/long
- 2.2.7.3 Identificación de puntos de interés
- 2.2.7.4 Cálculo de distancias
- 2.2.7.5 Validación de cobertura

**Duración**: 6 semanas | **Esfuerzo**: 320 horas | **Riesgo**: MEDIO

**SUBTOTAL Estandarización Direcciones**: 38 semanas | 2,200 horas

#### 2.3 Estandarización de Teléfonos/Celulares (M3-M5)
- 2.3.1 Implementación de expresiones regulares
- 2.3.2 Validación de prefijos con DANE
- 2.3.3 Limpieza de caracteres especiales
- 2.3.4 Marcación de validez
- 2.3.5 Pruebas de estandarización

**Duración**: 8 semanas | **Esfuerzo**: 240 horas | **Riesgo**: BAJO

#### 2.4 Estandarización de Email (M3-M5)
- 2.4.1 Implementación de expresiones regulares
- 2.4.2 Validación de formato
- 2.4.3 Limpieza y normalización
- 2.4.4 Pruebas de estandarización

**Duración**: 6 semanas | **Esfuerzo**: 160 horas | **Riesgo**: BAJO

**TOTAL FASE 2**: 28 semanas | 2,840 horas | ~5.1 FTE promedio

---

### 3. ORDENAMIENTO Y CÁLCULO (M4-M12 OP1 / M10-M19 OP2)

#### 3.1 Ordenamiento de Direcciones (M4-M5 OP1 / M10-M11 OP2)
- 3.1.1 Migración de algoritmos de score
- 3.1.2 Implementación de priorización por reportes
- 3.1.3 Cálculo de orden 1
- 3.1.4 Validación vs sistema actual
- 3.1.5 Optimización de performance

**Duración**: 8 semanas | **Esfuerzo**: 480 horas | **Riesgo**: ALTO

#### 3.2 Ordenamiento de Teléfonos/Celulares (M4 OP1 / M12 OP2)
- 3.2.1 Implementación de algoritmos de score
- 3.2.2 Priorización por número de reportes
- 3.2.3 Validación de números activos
- 3.2.4 Pruebas de ordenamiento

**Duración**: 4 semanas | **Esfuerzo**: 200 horas | **Riesgo**: MEDIO

#### 3.3 Ordenamiento de Emails (M4 OP1 / M12 OP2)
- 3.3.1 Implementación de algoritmos de score
- 3.3.2 Validación de dominios
- 3.3.3 Priorización por uso
- 3.3.4 Pruebas de ordenamiento

**Duración**: 3 semanas | **Esfuerzo**: 150 horas | **Riesgo**: MEDIO

#### 3.4 Indicadores de Movilidad (M7 OP1 / M13 OP2)
- 3.4.1 Cálculo de cambios de dirección
- 3.4.2 Frecuencia de movilidad
- 3.4.3 Patrones de desplazamiento
- 3.4.4 Validación de indicadores

**Duración**: 4 semanas | **Esfuerzo**: 200 horas | **Riesgo**: MEDIO

#### 3.5 Cálculo Reconocer General (M8-M9 OP1 / M14-M15 OP2)
- 3.5.1 Precálculo para 65-70M ciudadanos
- 3.5.2 Generación de tablas finales
- 3.5.3 Consolidación de datos de contacto
- 3.5.4 Validación de cobertura y calidad
- 3.5.5 Optimización de performance

**Duración**: 8 semanas | **Esfuerzo**: 480 horas | **Riesgo**: ALTO

#### 3.6 Replicación Modelo Batch (M10-M11 OP1 / M16-M17 OP2)
- 3.6.1 Migración de esquema de tablas batch
- 3.6.2 Integración con Control-M
- 3.6.3 Automatización de procesos
- 3.6.4 Conexión con proceso de cargue
- 3.6.5 Pruebas de batch

**Duración**: 8 semanas | **Esfuerzo**: 400 horas | **Riesgo**: MEDIO

#### 3.7 Servicio en Línea (M11-M12 OP1 / M18-M19 OP2)
- 3.7.1 Exportación a formato DB2
- 3.7.2 Transferencia vía S3
- 3.7.3 Cargue en DB2
- 3.7.4 Ajustes en Control-M
- 3.7.5 Implementación de APIs (Aurora/DynamoDB)
- 3.7.6 Pruebas de servicio en línea

**Duración**: 8 semanas | **Esfuerzo**: 400 horas | **Riesgo**: MEDIO

**TOTAL FASE 3**: 43 semanas | 2,310 horas | ~2.7 FTE promedio

---

### 4. PRUEBAS Y VALIDACIÓN (Transversal M3-M12)

#### 4.1 Pruebas Unitarias
- 4.1.1 Pruebas de componentes de estandarización
- 4.1.2 Pruebas de algoritmos de ordenamiento
- 4.1.3 Pruebas de cálculos
- 4.1.4 Automatización de pruebas unitarias

**Duración**: Continuo | **Esfuerzo**: 400 horas | **Riesgo**: BAJO

#### 4.2 Pruebas de Integración
- 4.2.1 Pruebas de integración Cobol → Pipeline
- 4.2.2 Pruebas de integración ESRI/ArcGIS
- 4.2.3 Pruebas de integración Redshift → DB2
- 4.2.4 Pruebas end-to-end

**Duración**: 6 semanas | **Esfuerzo**: 300 horas | **Riesgo**: MEDIO

#### 4.3 Pruebas de Performance
- 4.3.1 Pruebas de carga (65-70M registros)
- 4.3.2 Pruebas de escalabilidad
- 4.3.3 Optimización de queries
- 4.3.4 Validación de tiempos de procesamiento

**Duración**: 4 semanas | **Esfuerzo**: 240 horas | **Riesgo**: ALTO

#### 4.4 Validación de Calidad
- 4.4.1 Comparación vs sistema actual
- 4.4.2 Validación de cobertura de estandarización
- 4.4.3 Validación de calidad de direcciones
- 4.4.4 Validación de geolocalización
- 4.4.5 Reporte de métricas de calidad

**Duración**: 6 semanas | **Esfuerzo**: 360 horas | **Riesgo**: ALTO

**TOTAL FASE 4**: 16 semanas | 1,300 horas | ~4.1 FTE promedio

---

### 5. DESPLIEGUE Y PUESTA EN PRODUCCIÓN (M12 OP1 / M19 OP2)

#### 5.1 Preparación de Producción
- 5.1.1 Configuración de ambiente productivo
- 5.1.2 Migración de datos históricos
- 5.1.3 Configuración de monitoreo
- 5.1.4 Configuración de alertas
- 5.1.5 Plan de rollback

**Duración**: 3 semanas | **Esfuerzo**: 180 horas | **Riesgo**: MEDIO

#### 5.2 Despliegue
- 5.2.1 Despliegue de pipelines
- 5.2.2 Despliegue de servicios
- 5.2.3 Configuración de Control-M
- 5.2.4 Pruebas de humo en producción
- 5.2.5 Go-live

**Duración**: 2 semanas | **Esfuerzo**: 120 horas | **Riesgo**: ALTO

#### 5.3 Estabilización
- 5.3.1 Monitoreo intensivo (primera semana)
- 5.3.2 Ajustes y correcciones
- 5.3.3 Optimización de performance
- 5.3.4 Validación de resultados

**Duración**: 2 semanas | **Esfuerzo**: 160 horas | **Riesgo**: MEDIO

**TOTAL FASE 5**: 7 semanas | 460 horas | ~3.3 FTE promedio

---

### 6. DOCUMENTACIÓN Y TRANSFERENCIA (Transversal)

#### 6.1 Documentación Técnica
- 6.1.1 Documentación de arquitectura
- 6.1.2 Documentación de algoritmos
- 6.1.3 Documentación de APIs
- 6.1.4 Guías de operación
- 6.1.5 Runbooks

**Duración**: Continuo | **Esfuerzo**: 300 horas | **Riesgo**: BAJO

#### 6.2 Capacitación
- 6.2.1 Capacitación a equipo de operaciones
- 6.2.2 Capacitación a equipo de soporte
- 6.2.3 Capacitación a usuarios finales
- 6.2.4 Materiales de capacitación

**Duración**: 4 semanas | **Esfuerzo**: 160 horas | **Riesgo**: BAJO

**TOTAL FASE 6**: Continuo | 460 horas | ~0.6 FTE promedio

---

## Resumen Ejecutivo

### Arquitectura Híbrida (EDF + Redshift) - Cronograma Optimizado con Paralelización

| Fase | Duración | Esfuerzo (horas) | FTE Promedio | Riesgo | Paralelización |
|------|----------|------------------|--------------|--------|----------------|
| 1. Planeación y Diseño | 8 semanas | 420 | 2.6 | ALTO | POC Libpostal en paralelo con workshop |
| 2. Ingesta y Estandarización | 24 semanas | 2,840 | 5.9 | ALTO | Ordenamiento en paralelo desde M3 |
| 3. Ordenamiento y Cálculo | 32 semanas | 2,310 | 3.6 | MEDIO | Inicia en M3 con datos mock |
| 4. Pruebas y Validación | 16 semanas | 1,300 | 4.1 | ALTO | Continuo desde M3 |
| 5. Despliegue | 7 semanas | 460 | 3.3 | MEDIO | Preparación anticipada |
| 6. Documentación | Continuo | 460 | 0.6 | BAJO | Continuo |
| **TOTAL OPTIMIZADO** | **40 semanas (10 meses)** | **7,790 horas** | **~4.9 FTE** | **ALTO** | **Ahorro: 2 meses** |
| **TOTAL CONSERVADOR** | **48 semanas (12 meses)** | **7,790 horas** | **~4.1 FTE** | **ALTO** | **Sin paralelización** |

### Ahorro por Paralelización

| Oportunidad | Ahorro | Riesgo | Equipos |
|-------------|--------|--------|---------|
| POC Libpostal + Workshop (M1) | 2-3 semanas | Bajo | Arquitectura + Técnico |
| Ordenamiento + Estandarización (M3-M5) | 1-2 meses | Medio | EDF + Redshift |
| Batch + Cálculo (M8-M9) | 1 mes | Bajo | Cálculo + Infraestructura |
| Servicio + Batch (M9-M10) | 1 mes | Bajo | Batch + Servicio |
| **TOTAL AHORRO** | **3-4 meses** | **Medio** | **Mínimo 2 equipos** |

---

### Opción 2: Arquitectura Unificada (Solo Redshift) - DESCARTADA

**Nota**: Esta opción fue descartada porque EDF es por definición el punto de ingesta obligatorio de todos los datos del bureau de Experian. Se mantiene aquí solo como referencia.

| Fase | Duración | Esfuerzo (horas) | FTE Promedio | Riesgo |
|------|----------|------------------|--------------|--------|
| 1. Planeación y Diseño | 8 semanas | 420 | 2.6 | ALTO |
| 2. Ingesta y Estandarización | 32 semanas | 3,620 | 5.7 | MUY ALTO |
| 3. Ordenamiento y Cálculo | 40 semanas | 2,710 | 3.4 | MEDIO |
| 4. Pruebas y Validación | 20 semanas | 1,500 | 3.8 | ALTO |
| 5. Despliegue | 7 semanas | 460 | 3.3 | MEDIO |
| 6. Documentación | Continuo | 460 | 0.6 | BAJO |
| **TOTAL** | **76 semanas (19 meses)** | **9,170 horas** | **~4.8 FTE** | **MUY ALTO** |

---

## Ruta Crítica

### Cronograma Optimizado con Paralelización (10 meses)

```
M1-M2: Validación + POC (PARALELO)
  ├─ Workshop Arquitectura (CRÍTICO)
  └─ POC Libpostal (PARALELO - CRÍTICO)
       │
       ▼
M2-M7: Estandarización EDF (CRÍTICO)
  │    ├─ Ingesta (M2)
  │    ├─ DANE + Tipificación (M2-M3)
  │    ├─ Limpieza + Acepciones (M3)
  │    ├─ Normalización (M3-M4)
  │    └─ Unificación (M5-M7)
  │
  │    PARALELO CON ↓
  │
M3-M5: Desarrollo Ordenamiento Redshift (PARALELO)
       ├─ Diseño algoritmos (M3-M4)
       ├─ Desarrollo con datos mock (M3-M5)
       └─ Tests unitarios (M3-M5)
       │
       ▼
M5-M7: Integración y Validación
       ├─ Integración datos reales (M5)
       └─ Validación vs sistema actual (M5-M7)
       │
       ▼
M8: Geolocalización (EDF → Redshift)
    └─ Integración ESRI/ArcGIS
       │
       ▼
M8-M9: Cálculo + Preparación Batch (PARALELO)
  │    ├─ Cálculo Reconocer (CRÍTICO)
  │    └─ Preparación infraestructura batch (PARALELO)
       │
       ▼
M9-M10: Servicio en Línea + Finalización Batch (PARALELO)
        ├─ Finalización batch
        └─ Preparación servicio en línea DB2 (PARALELO)

DURACIÓN TOTAL: 10 meses (40 semanas)
AHORRO vs CONSERVADOR: 2 meses
```

**Duración Ruta Crítica Optimizada**: 10 meses

---

### Cronograma Conservador sin Paralelización (12 meses)

```
Validación Arquitectura (M1-M2) →
  POC Libpostal (M2) →
    Diseño Modelo Datos (M2) →
      Implementación Ingesta (M2-M3) →
        Estandarización Direcciones (M3-M9) →
          Ordenamiento (M4-M7) →
            Cálculo Reconocer (M8-M9) →
              Modelo Batch (M10-M11) →
                Servicio en Línea (M11-M12)
```

**Duración Ruta Crítica Conservadora**: 12 meses

---

## Hitos Principales

| # | Hito | Fecha Optimizada | Fecha Conservadora | Criterio de Aceptación |
|---|------|------------------|-------------------|------------------------|
| H1 | Arquitectura validada | Fin M2 | Fin M2 | Aprobación de arquitectura Experian |
| H2 | **POC Libpostal validado** | **Fin M2 (semanas 1-2)** | **Fin M2 (semanas 1-2)** | **Compatibilidad ≥90% con estándar colombiano** |
| H3 | Ingesta operativa | Fin M2 | Fin M3 | Cargue exitoso de datos desde Cobol |
| H4 | Algoritmos diseñados | Fin M4 | Fin M5 | Algoritmos con datos mock validados |
| H5 | Estandarización completa | Fin M7 | Fin M9 | Cobertura ≥95% vs sistema actual |
| H6 | Ordenamiento completo | Fin M7 | Fin M7 | Algoritmos de score validados con datos reales |
| H7 | Geolocalización | Fin M8 | Fin M9 | Integración ESRI operativa |
| H8 | Cálculo Reconocer | Fin M9 | Fin M9 | Tablas generadas para 65-70M ciudadanos |
| H9 | Batch operativo | Fin M9 | Fin M11 | Proceso batch automatizado |
| H10 | Servicio en línea | Fin M10 | Fin M12 | APIs operativas en DB2 |
| H11 | Go-live producción | Fin M10 | Fin M12 | Sistema en producción estable |

### Comparación de Hitos

**Cronograma Optimizado (10 meses)**:
- Estandarización completa: M7 (vs M9 conservador)
- Batch operativo: M9 (vs M11 conservador)
- Go-live: M10 (vs M12 conservador)

**Ahorro total**: 2 meses en ruta crítica

---

## Supuestos del WBS

1. **Paralelización efectiva**: Equipos EDF y Redshift pueden trabajar en paralelo desde M3
2. **Datos mock de calidad**: Disponibles para desarrollo de ordenamiento antes de datos reales
3. **Equipo completo disponible**: Desde M2 con capacidad de trabajar en paralelo
4. **Acceso a ambientes AWS**: Desde M1
5. **Acceso a documentación técnica completa**: Incluyendo UDFs en C
6. **Disponibilidad de Wilmar**: 40% durante todo el proyecto
7. **Validación de arquitectura**: Completada en M2
8. **POC Libpostal exitoso**: Compatibilidad ≥90% con estándar colombiano
9. **Sin cambios mayores de alcance**: Durante ejecución
10. **Integración con ESRI/ArcGIS**: Sin problemas técnicos
11. **Acceso a producción Experian**: Gestionado por Oscar Fajardo
12. **Coordinación entre equipos**: Sincronización semanal efectiva
13. **IFR sale en agosto 2026** (NUEVO): Con data suficiente para Reconocer
14. **Sección Locations del XPM es suficiente** (NUEVO): Tiene todos los campos necesarios
15. **Francisco disponible al 50%** (NUEVO): Compartido con plataforma
16. **Diego se mueve a Curation/Reconocer** (NUEVO): Con curva de aprendizaje mínima

### Priorización de Frentes (definida 16/03/2026)

1. **Tratamiento y alistamiento de datos** (IDF + Redshift) – Prioridad inmediata, todo abril.
2. **Producto Batch** – Después de cerrar datos.
3. **Producto en Línea** – Último frente.

### Deadline Real para EDF (actualización 17/03/2026)

- **Junio 2026**: Datos estandarizados deben estar en el XPM. Este es el deadline inamovible.
- La POC tiene margen de moverse, pero junio no.
- Estrategia: Definir un XPM base para desacoplar equipos.

### Supuestos Específicos de Paralelización

- **M1**: POC Libpostal puede ejecutarse en paralelo con workshop de arquitectura
- **M3-M5**: Equipo Redshift puede desarrollar algoritmos con datos mock mientras EDF estandariza
- **M5**: Datos estandarizados de EDF están listos para integración con Redshift
- **M8-M9**: Infraestructura batch puede prepararse mientras se ejecuta cálculo Reconocer
- **M9-M10**: Servicio en línea puede prepararse mientras se finaliza batch

---

## Exclusiones

- Migración de otros sistemas de Experian
- Desarrollo de nuevas funcionalidades no contempladas en sistema actual
- Soporte post go-live (requiere contrato separado)
- Capacitación avanzada a usuarios finales
- Optimizaciones no críticas para MVP

---

## Próximos Pasos

1. **Validar WBS con stakeholders** (Christian Sparacino, Fernando Garrido)
2. **Confirmar viabilidad de paralelización** con equipos técnicos
3. **Validar disponibilidad de recursos** para equipos paralelos (EDF + Redshift)
4. **Refinar estimaciones** según feedback de arquitectura (post-workshop M2)
5. **Asignar recursos a actividades** por equipo (EDF, Redshift, Infraestructura)
6. **Crear cronograma detallado** en herramienta de gestión con dependencias
7. **Establecer puntos de control** semanales para sincronización entre equipos
8. **Definir estrategia de datos mock** para desarrollo anticipado de ordenamiento
9. **Preparar plan de contingencia** si paralelización no es viable (revertir a 12 meses)
10. **Documentar criterios de integración** entre equipos EDF y Redshift

### Acciones Inmediatas (actualización 17/03/2026)

1. **Francisco**: Evaluar complejidad de Curation con Diego, entender nivel de conocimiento.
2. **Francisco**: Revisar perfil de Diego Poveda para posible incorporación.
3. **Wilmar/Lorena**: Armar Excel con plan de equipos, roles y dedicación.
4. **Diego Santucci**: Validar sección Locations del XPM con Johnny.
5. **Equipo**: Ejecutar POC interna de Libpostal (fuera de ambiente Experian).
6. **Equipo**: Solicitar métricas actuales de Curation (con Alejandro Restrepo) y malla de estandarización (Control-M).
7. **Equipo**: Solicitar accesos a Teradata para ver procedimientos almacenados.
8. **Planear inicio en abril**: Setup de equipo, workshops, levantamiento de información.

### Decisiones Críticas Pendientes (M1-M2)

- **Decisión 1 (RESUELTA 19/03)**: Estandarización en etapa de Curation del pipeline EDF. Campo nuevo, sin impacto en PINNING.
- **Decisión 2**: ¿Dónde hacer el ordenamiento? (EDF vs Redshift) — Pendiente
- **Decisión 3**: Resultado POC Libpostal (continuar vs pivote a migración UDFs) — Pendiente
- **Decisión 4 (RESUELTA 19/03)**: PINNING no se toca. Integración futura opcional vía `IdentifyingAttributesConfig`.

### Precondiciones Nuevas (identificadas 19/03/2026)

- El nombre del nuevo campo estandarizado debe ser **único** en todo el ecosistema de fuentes de EDF. Requiere búsqueda previa en archivos de configuración.
