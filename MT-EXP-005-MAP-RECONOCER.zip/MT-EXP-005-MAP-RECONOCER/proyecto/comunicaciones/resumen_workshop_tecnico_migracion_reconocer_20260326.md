# Resumen – Workshop Técnico Migración Reconocer

**Fecha**: 26 de marzo de 2026
**Tipo**: Workshop técnico de migración
**Fuente**: [Notion Meeting Notes](https://www.notion.so/Workshop-T-cnico-Migraci-n-Reconocer-32ff666e815180808492c5c4e0851a8f)

---

## Objetivo de la Sesión

Revisar el funcionamiento técnico del proceso de carga de datos de Reconocer, desde la llegada de deltas hasta la generación de datos en tablas. El proceso se divide en:

1. Cargue de datos
2. Estandarización con unificación
3. Precálculo (generación del modelo de ordenamiento)
4. Cálculo de Reconocer

---

## Acciones Pendientes

- [ ] Compartir archivos comprimidos con los algoritmos de estandarización por el chat
- [ ] Contactar a Julián Méndez para definir cómo funciona Geolitics después de la actualización y cómo hacer el enriquecimiento de datos

---

## Hallazgos Clave

### Arquitectura y Tecnología

- **Control-M** es el orquestador que llama a los objetos de Teradata y ejecuta los pasos de la malla
- Control-M solo está disponible en producción, no en desarrollo
- Todos los objetos siguen un estándar: carpetas `fuentes script` y `fuentes macros`, ejecutados mediante una única Shell que identifica automáticamente dónde buscar los objetos
- Para ver la malla real en producción se debe coordinar con **David o Julián Méndez** (tienen acceso a Control-M)

### Proceso de Catálogos

- Se cargan catálogos desde archivos de diversas fuentes, principalmente para estandarización (excepciones y topónimos)
- Los catálogos están en una ruta del servidor de Reconocer y se cargan solo si hay archivos disponibles mediante un **FileWatcher**
- Si no hay archivos, la malla termina sin ejecutar procesos posteriores
- Los catálogos se reemplazan colocando un archivo nuevo en la ruta especificada
- **Los catálogos no se han cambiado desde la primera vez que se configuraron**

### Proceso ICBIR (Carga de Datos)

1. **Aplanado**: Convierte el delta de direcciones en formato COBOL a formato CSV
2. **Particionamiento**: El aplanador parte el delta en archivos con cierta cantidad de registros (millones) para procesamiento en paralelo
3. **Archivos de control**: Cada archivo generado tiene un CTL que indica la cantidad de registros
4. **Transferencia**: Los archivos se transfieren al servidor de Teradata (LOAT)
5. **Carga a Stage**: Control-M se conecta al LOAT y ejecuta shells para subir la información a una tabla en Stage
6. **Tablas con timestamp**: Las tablas en Stage se crean automáticamente con timestamp (año, mes, día, horas, minutos, segundos) para evitar duplicidad

### Validaciones y Rechazos en Ubicación Original

- Se realizan cruces con **VU personas** (validando tipo y código de identificación) y **VU cuentas**
- Llave de negocio válida: la cuenta debe existir y el tipo/código de identificación deben existir en BDM
- Si no existen, los registros se rechazan y no se cargan en ubicación original
- **Problema conocido**: Cuando un suscriptor está bloqueado en COBOL, el dato no se carga al modelo. Si se desbloquea posteriormente pero el delta no se reinyecta, ese dato nunca se cargará aunque aparezca en COBOL
- **Solución futura**: En Data Fabric (capa de curación), los datos no estarán filtrados, resolviendo esta sincronización

### Contactabilidad (Fuente OTP)

- **Nunca se activó** — la fuente de contactabilidad nunca entró en operación
- La idea era recibir archivos de proveedores externos indicando franjas horarias y días para contactar a una persona en un número específico
- Requería que tanto la persona como el dato de contacto ya existieran en el modelo para poder enriquecerlos
- **El contrato con los proveedores nunca se concretó**
- Esto responde al action item del 25/03 sobre validar el proceso P0003

### Proceso de Estandarización

- Toma todos los lotes pendientes desde ubicación original
- Aplica reglas predefinidas diferentes según el tipo de dato: dirección física, teléfono celular, teléfono fijo, o email

**Pasos del proceso:**

1. Cálculo del DANE
2. Tipificación de la dirección (rural, vía, manzana — hay 4-5 tipos)
3. Aplicación de reglas de estandarización específicas por tipo
4. Normalización mediante UDF que valida tipo de ubicación y código DANE
5. Marcado como válida o inválida
6. Actualización de lotes en ubicación original

**Reglas por tipo:**
- Cada tipo de dirección tiene reglas diferentes (ej: una vía debe tener apertura y puede tener complemento)
- Las direcciones no válidas no se muestran ni se ordenan, aunque se estandarizan
- Las reglas usan expresiones regulares y catálogos para validación

### Validación de Direcciones

- Se valida según tipo y código DANE (ej: Bogotá no puede tener vías más grandes de cierto tope)
- Una dirección marcada como inválida **no se puede mostrar** en el producto final
- **Para la implementación futura**: Las direcciones no estandarizadas deben marcarse, creando un campo nuevo en XPM que indique si es válida para Reconocer
- Es importante llevar seguimiento de direcciones que quedan inválidas, ya que pueden mantenerse así en el tiempo y perderse esos datos

### Geolocalización

- **Actualmente NO está funcionando**
- Anteriormente se conectaba con **Geolitics** mediante API para enriquecer direcciones estandarizadas con: longitud, latitud, y puntos de interés
- Se enviaban lotes de hasta ~1 millón de direcciones
- La integración cambió y el proceso se desconectó
- La respuesta de Geolitics se subía de nuevo al modelo en Teradata
- **Acción crítica**: Definir cómo funciona Geolitics ahora para poder hacer el enriquecimiento en la nueva arquitectura

---

## Impacto en el Proyecto

### Confirmaciones

- La fuente de Contactabilidad OTP (P0003) **nunca se activó** → se puede excluir del alcance de migración
- Los catálogos de estandarización son estáticos (no han cambiado) → simplifica la migración
- El problema de suscriptores bloqueados en COBOL se resuelve con Data Fabric → beneficio de la migración

### Nuevas Incertidumbres

- Geolocalización está desconectada → se necesita definir integración con Geolitics en la nueva arquitectura
- Se necesita un campo nuevo en XPM para marcar direcciones válidas/inválidas para Reconocer
- Falta cubrir: proceso de ordenamiento y algoritmos de cálculo completo

---

## Próximos Pasos

- **Lunes (sesión 11:00-12:00)**: Continuar con el tema de ordenamiento
- **Pendiente**: Proceso de ordenamiento y algoritmos de cálculo completo de Reconocer
- **Pendiente**: Contactar a Julián Méndez sobre Geolitics
