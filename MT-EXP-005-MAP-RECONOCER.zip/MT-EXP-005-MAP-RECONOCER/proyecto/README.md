# Proyecto Reconocer — Documentación Transversal

> Contexto general del proyecto de migración. Para documentación específica de cada proceso, ver los workspaces.

## Arquitectura y contexto técnico

| Documento | Descripción |
|-----------|-------------|
| [arquitectura.md](arquitectura.md) | Arquitectura AS-IS (Teradata) y TO-BE (EDF + Redshift) |
| [contrato_campos_edf_redshift.md](contrato_campos_edf_redshift.md) | Contrato de campos entre EDF y Redshift |
| [decisiones.md](decisiones.md) | Decisiones resueltas y abiertas |
| [inventario_codigo_fuente.md](inventario_codigo_fuente.md) | Mapeo completo de scripts Teradata |

## Subcarpetas

| Carpeta | Contenido |
|---------|-----------|
| [comunicaciones/](comunicaciones/) | Comunicaciones transversales (workshops generales) |
| [entregables/](entregables/) | Archivos binarios y multimedia |
| [gestion/](gestion/) | Reuniones, compromisos, plan de trabajo, avance |
| [metodologia/](metodologia/) | Lecciones aprendidas, comparativas de herramientas |
| [orquestacion/](orquestacion/) | Control-M, framework batch, orquestación de procesos |
| [preventa/](preventa/) | Documentos de preventa centralizados |

## Comunicaciones transversales

| Documento | Descripción |
|-----------|-------------|
| [comunicaciones/resumen_workshop_tecnico_migracion_reconocer_20260326.md](comunicaciones/resumen_workshop_tecnico_migracion_reconocer_20260326.md) | Resumen del workshop técnico general de migración |

## Entregables

| Documento | Descripción |
|-----------|-------------|
| [entregables/MT EXP F 031 Preliminary Work Plan.xlsx](entregables/MT%20EXP%20F%20031%20Preliminary%20Work%20Plan.xlsx) | Plan de trabajo preliminar |
| [entregables/Explicación funcionamiento framework procesos batch_v1.vtt](entregables/Explicaci%C3%B3n%20funcionamiento%20framework%20procesos%20batch_v1.vtt) | Transcripción explicación framework batch |

## Gestión del proyecto

| Documento | Descripción |
|-----------|-------------|
| [gestion/reu_sync.md](gestion/reu_sync.md) | Compromisos reunión con Wilmar y Molina |
| [gestion/plan_trabajo.md](gestion/plan_trabajo.md) | Plan de trabajo de Francisco |
| [gestion/checklist.md](gestion/checklist.md) | Tracking de progreso (✅/⏳/❌) |
| [gestion/avance_teams.md](gestion/avance_teams.md) | Resumen ejecutivo para sync en Teams |
| [gestion/propuesta_management_migracion_reconocer.md](gestion/propuesta_management_migracion_reconocer.md) | Propuesta de gestión de la migración |

## Metodología

| Documento | Descripción |
|-----------|-------------|
| [metodologia/specs_vs_prompt_directo.md](metodologia/specs_vs_prompt_directo.md) | Comparativa: specs vs prompt directo |
| [metodologia/lecciones_aprendidas_migracion_kiro.md](metodologia/lecciones_aprendidas_migracion_kiro.md) | Lecciones aprendidas usando Kiro en migración |

## Orquestación

| Documento | Descripción |
|-----------|-------------|
| [orquestacion/Control_M.xml](orquestacion/Control_M.xml) | Definición de jobs Control-M original |
| [orquestacion/orquestacion_control_m_unificacion_ordenamiento.md](orquestacion/orquestacion_control_m_unificacion_ordenamiento.md) | Análisis de orquestación Control-M |
| [orquestacion/framework_batch_procesos_dinamicos.md](orquestacion/framework_batch_procesos_dinamicos.md) | Framework de procesos batch dinámicos |

## Preventa

| Documento | Descripción |
|-----------|-------------|
| [preventa/01_contexto_proyecto.md](preventa/01_contexto_proyecto.md) | Contexto del proyecto |
| [preventa/02_fases_tecnicas.md](preventa/02_fases_tecnicas.md) | Fases técnicas |
| [preventa/03_roles_identificados.md](preventa/03_roles_identificados.md) | Roles identificados |
| [preventa/04_wbs_inicial.md](preventa/04_wbs_inicial.md) | WBS inicial |
| [preventa/05_riesgos_supuestos.md](preventa/05_riesgos_supuestos.md) | Riesgos y supuestos |
| [preventa/arquitectura_proyecto.md](preventa/arquitectura_proyecto.md) | Arquitectura del proyecto |
| [preventa/decisiones_abiertas.md](preventa/decisiones_abiertas.md) | Decisiones abiertas |
