# Análisis: Specs vs Prompt Directo en Migración Teradata → Redshift

> Documento interno Macondotek. NO sincronizar con Azure.
> Basado en experiencia real del proyecto Reconocer (Unificación + Ordenamiento).
> Fecha: 2026-04-22 | Autor: Francisco Peña

---

## Contexto

Durante la migración de Reconocer usamos dos aproximaciones:
- **Prompt directo**: Dar el código Teradata al agente IA y pedirle que lo migre a Redshift
- **Spec Driven Development**: Extraer lógica → requirements.md → design.md → tasks.md → implementar

Este análisis documenta cuándo cada una funcionó y cuándo no, con datos reales.

---

## Resumen de decisiones tomadas

| Componente | Aproximación | Líneas Teradata | Líneas Redshift | Bugs | Resultado |
|-----------|-------------|----------------:|----------------:|-----:|-----------|
| R1 (CIIU) | Prompt directo | ~200 | ~80 | 1 | ✅ Funcionó bien |
| R2 Esc 1-2 (vacío/incluido) | Prompt directo | ~400 | ~180 | 1 | ✅ Funcionó bien |
| R2 Esc 3 sin NIT | Prompt directo | ~200 | ~130 | 0 | ✅ Funcionó bien |
| R2 Esc 4 (diccionario) | Prompt directo | ~400 | ~200 | 0 | ✅ Funcionó bien |
| **R2 Motor (MOTOR_TMP)** | **Spec Driven** | **870** | **380** | **2** | ✅ Necesitó spec |
| R2 Esc 5-6 | Prompt directo (reutilizó motor) | ~1,600 | ~570 | 1 | ✅ Funcionó bien |
| R3 (Geolocalización) | Prompt directo | ~400 | ~290 | 0 | ✅ Funcionó bien |
| Ordenamiento (4 canales) | Prompt directo | ~253 sentencias | ~420 | 2 | ✅ Funcionó bien |
| Consolidación + persistencia | Prompt directo | ~100 | ~24 | 0 | ✅ Trivial |

---

## Cuándo usar Spec Driven Development

### Indicadores de que necesitas spec

1. **SQL dinámico** — El código genera SQL en runtime (XMLAGG, EXECUTE, DBC.COLUMNS). No puedes simplemente "traducir" porque la lógica no es visible en el código estático.

2. **Cursores con lógica variable** — El cursor itera y ejecuta operaciones diferentes según el estado. No es un loop simple.

3. **Número de columnas dinámico** — El código crea tablas con N columnas donde N depende de los datos (PIVOT dinámico). Requiere rediseñar la solución, no solo traducir.

4. **Más de 500 líneas de lógica interconectada** — Cuando un solo SP tiene múltiples fases que dependen entre sí y no se pueden migrar independientemente.

5. **Cambio de paradigma** — Cuando la solución en Teradata no tiene equivalente directo en Redshift (ej: SQL dinámico → SQL estático, cursor → set-based).

### Qué incluir en la spec

| Documento | Contenido | Cuándo es crítico |
|-----------|-----------|-------------------|
| requirements.md | Qué hace (funcional, no cómo) | Siempre |
| design.md | Cómo en Redshift (decisiones técnicas) | Cuando hay cambio de paradigma |
| tasks.md | Pasos de implementación | Cuando hay más de 5 pasos |
| revision_comite.md | Revisión de pares | Cuando hay riesgo de divergencia vs Teradata |

### Caso real: MOTOR_TMP

El motor de nuevas direcciones fue el único componente que necesitó spec. Razones:

- 870 líneas de SQL dinámico con XMLAGG generando CREATE TABLE con N columnas
- Cursor que ejecuta UPDATE dinámico por cada fila
- DBC.COLUMNS para leer metadata
- PIVOT implícito con CASE WHEN ORDEN=N
- La solución en Redshift es fundamentalmente diferente (LISTAGG + LEFT JOIN + string comparison)

Sin la spec, el agente habría intentado traducir línea por línea y habría fallado porque el concepto no tiene traducción directa.

**Resultado de la spec**: 4 documentos, 20 correcciones aplicadas en revisión, 12 test cases definidos, 7 ambigüedades resueltas antes de escribir código. El código final tuvo solo 2 bugs (vs los 5+ que habría tenido sin spec).

---

## Cuándo usar Prompt Directo

### Indicadores de que prompt directo es suficiente

1. **SQL estándar** — SELECT, JOIN, GROUP BY, window functions, CASE WHEN. Teradata y Redshift son casi idénticos.

2. **Patrón repetitivo** — La misma lógica se aplica N veces con diferentes parámetros (ej: scoring por canal).

3. **Menos de 500 líneas** — El contexto cabe en una sola conversación sin perder coherencia.

4. **Sin SQL dinámico** — Todo el SQL es estático y visible en el código fuente.

5. **Traducción mecánica** — Los cambios son sintácticos: `COLLECT STATISTICS` → `ANALYZE`, `PRIMARY INDEX` → `DISTKEY`, `CREATE MULTISET TABLE` → `CREATE TABLE`.

### Caso real: Ordenamiento

253 sentencias SQL en una tabla de configuración, todas siguiendo el mismo patrón:
```
métrica bruta → CASE WHEN (categorización) → (cat/max_cat) × Beta → Σ pesos → ROW_NUMBER
```

Prompt directo funcionó perfectamente porque:
- El patrón es repetitivo (una vez que DIR funcionó, TEL/CEL/EMA fueron mecánicos)
- No hay SQL dinámico (las sentencias son estáticas, solo parametrizadas)
- La traducción es casi 1:1 (solo cambiar COLLECT STATISTICS → ANALYZE)
- 70 sentencias Teradata → 1 query con CTEs de ~140 líneas

### Caso real: Regla 1 y escenarios simples de Regla 2

SQL estándar con JOINs, window functions y CASE WHEN. La traducción fue mecánica:
- `QUALIFY` → subconsulta con `ROW_NUMBER`
- `OREPLACE` → `REPLACE`
- `CAST(fecha AS INTEGER)` → `CAST(REPLACE(CAST(fecha AS VARCHAR),'-','') AS BIGINT)`

---

## Matriz de decisión

```
¿El código tiene SQL dinámico (EXECUTE, XMLAGG, DBC.COLUMNS)?
  → SÍ → SPEC DRIVEN
  → NO ↓

¿El código tiene cursores con lógica variable?
  → SÍ → SPEC DRIVEN
  → NO ↓

¿El código tiene más de 500 líneas de lógica interconectada?
  → SÍ → SPEC DRIVEN (al menos requirements + design)
  → NO ↓

¿El patrón es repetitivo?
  → SÍ → PROMPT DIRECTO (hacer POC con 1, replicar para N)
  → NO ↓

¿La traducción es mecánica (solo cambios sintácticos)?
  → SÍ → PROMPT DIRECTO
  → NO → SPEC DRIVEN (al menos requirements)
```

---

## Métricas de productividad

| Aproximación | Velocidad | Calidad | Cuándo |
|-------------|-----------|---------|--------|
| Prompt directo | ~200 líneas Redshift/hora | 1-2 bugs por componente | 80% de los casos |
| Spec driven | ~50 líneas Redshift/hora (incluye spec) | 0-1 bugs por componente | 20% de los casos (SQL dinámico, cambio de paradigma) |

La spec es 4x más lenta pero produce código más robusto. Solo vale la pena cuando el costo de los bugs es alto (lógica compleja, difícil de debuggear).

---

## Recomendación para futuros proyectos de migración

1. **Empezar siempre con prompt directo** — La mayoría del código Teradata es SQL estándar migrable mecánicamente.

2. **Escalar a spec cuando** el agente empiece a "divagar" o produzca código que no funciona después de 2 intentos. Eso indica que el problema necesita diseño, no más intentos.

3. **Hacer POC primero** — Migrar un caso representativo, validar en sandbox, y luego replicar el patrón. Esto aplica tanto para prompt directo como para spec.

4. **Validar siempre en sandbox** — No importa la aproximación, ejecutar en Redshift real es lo que encuentra los bugs. Los 7 bugs que encontramos fueron todos en sandbox, no en revisión de código.

5. **Documentar hallazgos** — Cada sesión de prueba genera un documento con resultados, bugs y correcciones. Esto es más valioso que la spec misma para el equipo.

---

## Aplicabilidad a otros procesos de Reconocer

| Proceso | Aproximación recomendada | Razón |
|---------|-------------------------|-------|
| Estandarización (EDF/Spark) | Fuera de alcance (no es SQL) | Va en Spark/Scala |
| Cálculo Reconocer | Prompt directo (probable) | SQL estándar de agregación |
| Batch (Control-M) | N/A | Orquestación, no SQL |
| Servicio en línea (DB2) | Prompt directo | Queries simples |
| UDFs en C (SetComplement) | Spec driven | Requiere rediseño en SQL/Python |

---

*Documento interno — no sincronizar con Azure DevOps*
