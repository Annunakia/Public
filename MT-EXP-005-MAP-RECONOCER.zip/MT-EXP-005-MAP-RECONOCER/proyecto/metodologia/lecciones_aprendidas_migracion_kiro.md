# Lecciones Aprendidas — Migración Reconocer con Kiro CLI

> Fecha: 2026-04-23 | Autor: Francisco Peña | Macondotek
> Proyecto: MT-EXP-005-MAP-RECONOCER | Cliente: Experian Colombia

---

## 1. Resumen Ejecutivo

Migración del sistema Reconocer (Teradata → AWS Redshift): ~65-70M registros de datos de contacto de ciudadanos colombianos. Se migraron dos procesos completos usando Kiro CLI como herramienta principal de asistencia IA.

| Proceso | Líneas Teradata | Líneas Redshift | Scripts | Bugs | Estado |
|---------|----------------:|----------------:|--------:|-----:|--------|
| **Unificación** (3 reglas, 12 escenarios) | ~18,220 | 2,540 | 10 + 9 rollback | 6 | ✅ Validado (20 personas + 5,000 sintéticas) |
| **Ordenamiento** (4 canales scoring) | ~2,310 (572 SPs + 1,479 TPT/BTQ + 261 SQL dinámico) | 540 | 6 | 2 | ✅ Validado (9 personas + 5,000 sintéticas) |
| **Total** | ~19,500 | 3,080 | 16 + 9 rollback | 8 | ✅ |

Tiempo efectivo de migración: ~1 semana (entendimiento previo de ~2 semanas).

---

## 2. Herramientas y Aproximaciones Usadas

### 2.1 Tres aproximaciones evaluadas

| # | Aproximación | Resultado | Uso real |
|---|-------------|-----------|----------|
| 1 | **Prompt directo** (Kiro CLI chat) | ✅ Funcionó para 80% del código | Regla 1, Esc 1-4, Esc 5-6, Regla 3, Ordenamiento completo |
| 2 | **AWS Q Transform Custom** | ⏳ Pendiente demo con Harold (AWS) | No evaluado aún |
| 3 | **Spec Driven Development** (Kiro specs) | ✅ Necesario para el 20% complejo | Motor MOTOR_TMP (SQL dinámico → SQL estático) |

### 2.2 Cuándo usar cada aproximación

```
¿SQL dinámico (EXECUTE, XMLAGG, DBC.COLUMNS)?  → SPEC DRIVEN
¿Cursores con lógica variable?                  → SPEC DRIVEN
¿Más de 500 líneas interconectadas?             → SPEC DRIVEN
¿Cambio de paradigma (sin equivalente directo)? → SPEC DRIVEN
¿SQL estándar (JOINs, window functions)?        → PROMPT DIRECTO
¿Patrón repetitivo?                             → PROMPT DIRECTO (POC + replicar)
¿Traducción mecánica (solo sintaxis)?           → PROMPT DIRECTO
```

### 2.3 Métricas de productividad

#### Volumen de código real (líneas contadas en repo)

**Código fuente Teradata analizado:**

| Fuente | Líneas | Nota |
|--------|-------:|------|
| Unificacion.sql (DDL + SPs) | 7,959 | Contiene todo: DDL, vistas, 3 SPs |
| PRO_UnificacionR2.sql (SP principal) | 6,220 | SP de Regla 2 completo |
| PRO_Unifi_MOTOR_TMP.sql | 870 | Motor de nuevas direcciones |
| Scripts TPT/BTQ Unificación (14 archivos) | 2,171 | Carga, transformación, exportación |
| Ordenamiento.sql (DDL + SPs) | 572 | DDL + SPs de scoring |
| Scripts TPT/BTQ Ordenamiento (9 archivos) | 1,479 | Carga, transformación, exportación |
| Caracteristicas.txt (SQL dinámico) | 261 | 253 sentencias SQL ejecutadas por cursor |
| **Total Teradata analizado** | **~19,500** | |

**Código Redshift generado:**

| Script | Líneas | Aproximación | Bugs |
|--------|-------:|:------------:|-----:|
| 01_schemas_roles.sql | 115 | Prompt directo | 0 |
| 02_regla1_unificacion.sql | 133 | Prompt directo | 1 |
| 03_regla2_esc1_2.sql | 248 | Prompt directo | 1 |
| 04_regla2_esc4.sql | 244 | Prompt directo | 0 |
| 05_regla2_esc3_sin_nit.sql | 168 | Prompt directo | 0 |
| **06_motor_nuevas_direcciones.sql** | **400** | **Spec driven** | **2** |
| 07_regla2_esc3_nit.sql | 147 | Prompt directo | 1 |
| 08_regla2_esc5.sql | 297 | Prompt directo | 1 |
| 09_regla2_esc6.sql | 274 | Prompt directo | 0 |
| 10_regla3_geo.sql | 291 | Prompt directo | 0 |
| Rollbacks (9 archivos) | 223 | Prompt directo | 0 |
| **Subtotal Unificación** | **2,540** | | **6** |
| 01_ordenamiento_schemas.sql | 110 | Prompt directo | 0 |
| 02_scoring_dir.sql | 143 | Prompt directo | 2 |
| 03_scoring_tel.sql | 91 | Prompt directo | 0 |
| 04_scoring_cel.sql | 81 | Prompt directo | 0 |
| 05_scoring_ema.sql | 91 | Prompt directo | 0 |
| 06_consolidacion_persistencia.sql | 24 | Prompt directo | 0 |
| **Subtotal Ordenamiento** | **540** | | **2** |
| **TOTAL REDSHIFT** | **3,080** | | **8** |

**Ratio de compresión**: ~19,500 líneas Teradata → 3,080 líneas Redshift = **6.3:1**

(La compresión es alta porque Teradata usa mucho boilerplate: TPT headers, LOCKING, COLLECT STATISTICS, tablas SET/MULTISET, y el SQL dinámico del cursor se reemplazó por CTEs compactos.)

#### Productividad por aproximación

| Aproximación | Componentes | Líneas RS generadas | Bugs | Bugs/100 líneas | Artefactos adicionales |
|-------------|:-----------:|--------------------:|-----:|:---------------:|:----------------------:|
| Prompt directo | 14 scripts | 2,680 | 6 | 0.22 | 0 |
| Spec driven | 1 script (motor) | 400 | 2 | 0.50 | 4 docs (821 líneas de spec) |

**Observación importante**: Los bugs/100 líneas del motor son más altos, pero eso es engañoso — el motor es el componente más complejo del sistema (SQL dinámico → SQL estático, cambio de paradigma). Sin la spec, la estimación es que habría tenido 5+ bugs y múltiples iteraciones fallidas antes de llegar a una solución funcional.

#### Velocidad estimada (tiempo efectivo de desarrollo)

| Componente | Líneas RS | Tiempo estimado | Líneas/hora | Aproximación |
|-----------|----------:|:---------------:|:-----------:|:------------:|
| R1 (CIIU) | 133 | ~40 min | ~200 | Prompt directo |
| R2 Esc 1-2 | 248 | ~1.5 h | ~165 | Prompt directo |
| R2 Esc 3 sin NIT | 168 | ~45 min | ~225 | Prompt directo |
| R2 Esc 4 | 244 | ~1 h | ~245 | Prompt directo |
| **R2 Motor** | **400** | **~8 h** (spec+código+revisión) | **~50** | **Spec driven** |
| R2 Esc 3 NIT | 147 | ~45 min | ~195 | Prompt directo (reutilizó motor) |
| R2 Esc 5-6 | 571 | ~2.5 h | ~230 | Prompt directo (reutilizó motor) |
| R3 Geo | 291 | ~1.5 h | ~195 | Prompt directo |
| Ordenamiento DIR (POC) | 143 | ~1.5 h | ~95 | Prompt directo (primer canal) |
| Ordenamiento TEL/CEL/EMA | 263 | ~1 h | ~265 | Prompt directo (replicar patrón) |
| Consolidación | 24 | ~10 min | ~145 | Prompt directo |
| Schemas + rollbacks | 338 | ~1 h | ~340 | Prompt directo (boilerplate) |

**Resumen de velocidad:**

| Aproximación | Velocidad promedio | Rango | Cuándo |
|-------------|:------------------:|:-----:|--------|
| Prompt directo (componente nuevo) | ~180 líneas RS/hora | 95-245 | Primera vez que se migra un patrón |
| Prompt directo (replicar patrón) | ~265 líneas RS/hora | 230-340 | Patrón ya validado, solo cambiar parámetros |
| Spec driven | ~50 líneas RS/hora | — | SQL dinámico, cambio de paradigma |

**La spec es ~3.5x más lenta** pero produce código más robusto en escenarios complejos. Solo vale la pena cuando el costo de los bugs es alto (lógica compleja, difícil de debuggear, múltiples dependencias).

#### Artefactos generados (no solo código)

| Tipo | Cantidad | Líneas |
|------|:--------:|-------:|
| Scripts SQL Redshift | 16 | 2,857 |
| Scripts rollback | 9 | 223 |
| Specs (requirements, design, tasks, revisión) | 4 | 821 |
| Steering files | 11 | 2,039 |
| Documentación técnica (unificación) | 10 docs | 1,851 |
| Documentación técnica (ordenamiento) | 3 docs | 525 |
| Datos mock (CSVs + README) | 9 archivos | 386 |
| Generadores de datos sintéticos | 2 scripts Python | 489 |
| Skill reutilizable | 1 | 68 |
| **Total artefactos generados** | **65 archivos** | **~9,260 líneas** |

#### Distribución del esfuerzo

```
Entendimiento + documentación:  ~40%  (análisis de scripts, modelo datos, mapeo escenarios)
Código SQL Redshift:            ~25%  (scripts + rollbacks)
Datos de prueba:                ~15%  (mock + sintéticos + validación)
Spec driven (motor):            ~10%  (requirements + design + revisión + tasks)
Steering + configuración:       ~10%  (steering files, skills, AGENTS.md)
```

La distribución muestra que **el código es solo el 25% del esfuerzo**. El 75% restante es entendimiento, documentación, datos de prueba y configuración del contexto IA — y es lo que hace que el código sea correcto a la primera (o segunda) iteración.

---

## 3. Capacidades de Kiro CLI Utilizadas

### 3.1 Steering files (contexto persistente)

Se crearon 10 steering files que le dan al agente contexto permanente del proyecto:

| Steering file | Propósito |
|--------------|-----------|
| `context.md` | Contexto general del proceso |
| `sql-redshift-xpm.md` | Reglas SQL específicas de Redshift en Experian |
| `modelo-datos-xpm.md` | Modelo de datos, encoding, DISTKEY/SORTKEY |
| `ambiente-redshift-cliente.md` | Configuración del sandbox (puerto, SSL, schemas) |
| `estandar-paquete-deploy-sql.md` | Convención de nombres, deploy_order.par, rollbacks |
| `desarrollo-ia-redshift.md` | Guía de desarrollo asistido por IA |
| `seguridad-rbac-redshift.md` | Roles y permisos |
| `operaciones-nocturnas-redshift.md` | Ventanas de mantenimiento |
| `proceso-rationalize.md` | Proceso de racionalización de código |
| `pruebas-redshift.md` | Estrategia de pruebas en sandbox |

**Lección**: Los steering files son el activo más valioso. Permiten que cada conversación nueva arranque con contexto completo sin repetir instrucciones.

### 3.2 Specs (Spec Driven Development)

Se usó para el componente más complejo: el Motor de Nuevas Direcciones (MOTOR_TMP).

| Documento | Contenido | Valor |
|-----------|-----------|-------|
| `requirements.md` | Qué hace el motor (funcional) | Resolvió 7 ambigüedades antes de escribir código |
| `design.md` | Cómo en Redshift (10 pasos, tablas staging) | Eliminó SQL dinámico → SQL estático |
| `tasks.md` | Pasos de implementación | Guía paso a paso para el agente |
| `revision_comite.md` | Revisión de pares (5 roles simulados) | 20 correcciones aplicadas, 14 técnicas |

**Resultado**: El motor final tuvo solo 2 bugs (vs estimados 5+ sin spec).

### 3.3 Skills (plantillas reutilizables)

Se creó un skill `migrar-sp-teradata-redshift.md` con el proceso estándar:
1. Entender lógica de negocio → 2. Leer código Teradata → 3. Traducir a Redshift → 4. Crear rollback → 5. Validar → 6. Actualizar deploy_order.par

Incluye tabla de equivalencias Teradata → Redshift (QUALIFY → ROW_NUMBER, OREPLACE → REPLACE, etc.).

### 3.4 AGENTS.md (contexto de repositorio)

Archivo raíz que le da al agente la visión global: estructura del repo, reglas estrictas (no modificar código fuente original), convenciones, tecnologías.

---

## 4. Conclusiones del Proceso de Unificación

### 4.1 Complejidad del algoritmo

El proceso de Unificación de Direcciones Físicas es el más complejo del sistema Reconocer:

- **3 reglas en cascada** (cada regla procesa solo lo no unificado por las anteriores)
- **12 escenarios** con subcasos
- **1 motor de generación** de nuevas direcciones (MOTOR_TMP: 870 líneas de SQL dinámico)
- **Concepto Padre-Hijo**: el padre sobrevive, los hijos se marcan con `ind_unificacion=1`

| Regla | Criterio | Complejidad | Aproximación |
|-------|----------|-------------|-------------|
| R1 (P0019) | Misma puerta, ≠ tipo uso → CIIU decide | Baja (~200 líneas) | Prompt directo |
| R2 (P0020) | Misma puerta, ≠ complemento → 6 escenarios | Alta (~3,470 líneas) | Mixta |
| R3 (P0021) | ≠ vía generadora → lat/long + diccionario | Media (~400 líneas) | Prompt directo |

### 4.2 Descomposición de Regla 2

La Regla 2 fue la más compleja. Se descompuso en 6 escenarios independientes:

| Escenario | Lógica | Genera nueva dir? | Líneas TD | Líneas RS |
|-----------|--------|:-----------------:|----------:|----------:|
| Esc 1 (vacío) | Complemento vacío vs no vacío | No | ~200 | ~90 |
| Esc 2 (incluido) | Un complemento contiene al otro | No | ~200 | ~90 |
| Esc 3 sin NIT | Misma nomenclatura, ≠ valor | No | ~200 | ~130 |
| Esc 3 NIT | Misma nomenclatura, ≠ valor, tipo NIT | **Sí** (motor) | ~200 + 870 | ~130 + 380 |
| Esc 4 | Nomenclaturas ≠ al mismo nivel | No | ~200 | ~100 |
| Esc 5 | Nomenclaturas ≠ en diferente nivel | **Sí** (motor) | ~800 | ~285 |
| Esc 6 | Ninguna contenida en la otra | **Sí** (motor) | ~800 | ~285 |

### 4.3 El desafío del MOTOR_TMP

El motor de nuevas direcciones fue el único componente que requirió Spec Driven Development:

- **870 líneas** de SQL dinámico en Teradata
- Usa `XMLAGG` para generar SQL, `DBC.COLUMNS` para leer metadata, cursor para ejecutar
- Genera tablas con N columnas dinámicas (PIVOT dinámico)
- **No tiene equivalente directo en Redshift**

La solución en Redshift reemplazó todo con:
- `LISTAGG()` para concatenar nomenclaturas
- `ROW_NUMBER()` + string de comparación para determinar MDIR (dirección con más nomenclaturas)
- `LEFT JOIN + IS NULL` para identificar nomenclaturas diferentes
- **380 líneas** de SQL estático (vs 870 de SQL dinámico)

### 4.4 Resultados de validación

| Nivel | Personas | Resultado |
|-------|----------|-----------|
| Mock (manual) | 20 personas, 12 escenarios | 100% correcto, 7 bugs encontrados y corregidos |
| Sintético (volumen) | 5,000 personas, 8,000 relaciones | 2,877 pares unificados, 100 nuevas dirs, 0 errores |

---

## 5. Conclusiones del Proceso de Ordenamiento

### 5.1 Complejidad del algoritmo

El Ordenamiento calcula un score de contactabilidad por dato de contacto usando regresión logística:

```
Score = Σ (categoría_i / max_categoría_i) × Beta_i
Lugar = ROW_NUMBER() OVER (PARTITION BY persona ORDER BY Score DESC)
```

- **4 canales**: Dirección (DIR), Teléfono fijo (TEL), Celular (CEL), Email (EMA)
- **47 características** distribuidas en los 4 canales
- **253 sentencias SQL** en tabla de configuración (ejecutadas dinámicamente por cursor en Teradata)

### 5.2 Arquitectura Data-Driven

El hallazgo principal del ordenamiento: **no tiene lógica hardcodeada**. Toda la lógica está en una tabla `CARACTERISTICA` con sentencias SQL como datos. Los SPs solo leen y ejecutan.

Esto simplificó enormemente la migración:
- En Teradata: cursor lee 253 sentencias → ejecuta dinámicamente → genera tablas intermedias
- En Redshift: **1 query con CTEs por canal** (~100-140 líneas cada uno)

| Canal | Sentencias TD | Líneas RS | Características |
|-------|-------------:|----------:|----------------:|
| DIR | 70 | ~140 | 12 |
| TEL | 82 | ~90 | 11 |
| CEL | 63 | ~80 | 11 |
| EMA | 38 | ~90 | 13 |
| Consolidación | ~50 | ~24 | — |

### 5.3 Patrón de 3 fases por característica

Cada característica sigue el mismo patrón:
1. **Métrica bruta** → ej: % reportes últimos 12 meses
2. **Categorización** → CASE WHEN <8.33 THEN 1 ... THEN 4
3. **Peso ponderado** → (categoría / max_categoría) × Beta

Este patrón repetitivo hizo que prompt directo fuera ideal: se migró DIR como POC, y TEL/CEL/EMA fueron mecánicos.

### 5.4 Resultados de validación

| Nivel | Personas | Scores | Resultado |
|-------|----------|--------|-----------|
| Mock (manual) | 9 personas | 15 scores | 100% coherente, 2 bugs corregidos |
| Sintético (volumen) | 5,000 personas | 25,108 scores | 0 errores, distribución coherente |

Distribución de scores (5,000 personas):

| Canal | Min | Avg | Max |
|-------|-----|-----|-----|
| DIR | 0.60 | 0.72 | 0.89 |
| TEL | 0.35 | 0.62 | 0.80 |
| CEL | 0.44 | 0.63 | 0.79 |
| EMA | 0.38 | 0.57 | 0.75 |

---

## 6. Conclusiones sobre Spec Driven Development

### 6.1 Cuándo agrega valor

| Situación | ¿Spec? | Razón |
|-----------|--------|-------|
| SQL dinámico (EXECUTE, XMLAGG) | **Sí** | No se puede traducir línea por línea |
| Cambio de paradigma (cursor → set-based) | **Sí** | Requiere rediseño, no traducción |
| >500 líneas interconectadas | **Sí** | El contexto no cabe en una conversación |
| SQL estándar (JOINs, CASE WHEN) | **No** | Traducción mecánica |
| Patrón repetitivo | **No** | POC + replicar es más rápido |

### 6.2 Valor concreto de la spec en MOTOR_TMP

- **7 ambigüedades** resueltas antes de escribir código (ej: ¿"LC 101 LC 205" o "LC 101 205"?)
- **20 correcciones** aplicadas en revisión de comité (14 técnicas, 3 funcionales, 3 operativas)
- **12 test cases** definidos en la spec
- **2 bugs** en código final (vs estimados 5+ sin spec)
- La revisión de comité simuló 5 roles: DBA, QA, Arquitecto, Analista funcional, DevOps

### 6.3 Cuándo NO agrega valor

- Para Regla 1 (~200 líneas, SQL estándar): spec habría tomado 2 horas, prompt directo tomó 30 min
- Para Ordenamiento (patrón repetitivo): spec habría sido overhead innecesario
- Para escenarios simples de R2 (Esc 1-2, Esc 4): traducción casi 1:1

### 6.4 Recomendación

**Empezar siempre con prompt directo.** Escalar a spec cuando el agente empiece a "divagar" o produzca código que no funciona después de 2 intentos. Eso indica que el problema necesita diseño, no más intentos.

---

## 7. Lecciones Aprendidas Clave

### 7.1 Sobre la herramienta (Kiro CLI)

1. **Los steering files son el activo más valioso.** Permiten que cada conversación nueva arranque con contexto completo. Invertir tiempo en crearlos bien al inicio se paga 10x después.

2. **AGENTS.md como guardia.** Evita que el agente modifique código fuente original o carpetas protegidas. Esencial en repos con código de cliente.

3. **Skills como plantillas.** El skill de migración Teradata→Redshift estandarizó el proceso y evitó que cada escenario se migrara de forma diferente.

4. **Specs para lo complejo, prompt para lo simple.** La matriz de decisión (§2.2) evita sobre-ingeniería en componentes simples y sub-ingeniería en componentes complejos.

### 7.2 Sobre la migración Teradata → Redshift

5. **El 80% del código Teradata es SQL estándar** migrable mecánicamente. Los cambios son sintácticos: `QUALIFY` → subconsulta, `OREPLACE` → `REPLACE`, `COLLECT STATISTICS` → `ANALYZE`.

6. **El 20% restante (SQL dinámico) requiere rediseño.** No se puede traducir línea por línea. Hay que entender qué hace y reimplementar con las primitivas de Redshift.

7. **Validar siempre en sandbox.** Los 9 bugs encontrados fueron todos en ejecución real, no en revisión de código. El sandbox es el test definitivo.

8. **Datos mock antes de código.** Diseñar los datos de prueba primero (con resultado esperado) y luego escribir el código. Esto invierte el flujo tradicional pero acelera la validación.

9. **Datos sintéticos para volumen.** Los 20 personas mock validan lógica; las 5,000 sintéticas validan que no hay edge cases ni problemas de rendimiento.

### 7.3 Sobre el proceso de migración

10. **Descomponer antes de migrar.** La Regla 2 (3,470 líneas) era inabordable como bloque. Descompuesta en 6 escenarios + 1 motor, cada pieza fue manejable.

11. **POC primero, replicar después.** En Ordenamiento, migrar DIR primero y luego replicar para TEL/CEL/EMA fue 3x más rápido que migrar los 4 en paralelo.

12. **Documentar hallazgos en tiempo real.** Cada sesión de prueba generó un documento con resultados, bugs y correcciones. Esto es más valioso que la spec misma para el equipo.

13. **La cascada de reglas funciona.** Las 3 reglas de unificación operan sin conflictos — cada regla procesa solo los registros no unificados por las anteriores. Validado con 5,000 personas.

---

## 8. Estado Actual y Próximos Pasos

### Completado ✅

| Entregable | Detalle |
|-----------|---------|
| Unificación R1 | 3 escenarios CIIU, validado |
| Unificación R2 | 6 escenarios + motor, validado |
| Unificación R3 | 3 escenarios geolocalización, validado |
| Ordenamiento 4 canales | DIR + TEL + CEL + EMA + consolidación, validado |
| Paquete deploy | 10 scripts SQL + 9 rollbacks + deploy_order.par |
| Datos mock | 20 personas, 12 escenarios cubiertos |
| Datos sintéticos | 5,000 personas unificación + 5,000 ordenamiento |
| Documentación técnica | Modelo datos, mapeo escenarios, criterios validación, resultados pruebas |

### Pendiente / Bloqueado

| Item | Bloqueante |
|------|-----------|
| Mapeo tablas Redshift del XPM | Molina → Confluence |
| Contrato de campos requeridos | Experian (deadline 15 mayo) |
| Malla Control-M | Experian (Melissa) |
| Demo AWS Q Transform Custom | Harold (AWS) |
| Repos en Azure DevOps | Molina |
| Indicadores de movilidad (P0029) | Análisis pendiente |
| 12 SPs de PRO_ORD_* | No localizados en archivos disponibles |

### Deadlines

- **Batch**: octubre 2026
- **Servicio en línea**: noviembre 2026
- **Dependencia crítica**: IFR (agosto 2026)

---

## 9. Números para la Reunión

| Métrica | Valor |
|---------|-------|
| Líneas Teradata analizadas | ~19,500 |
| Líneas Redshift generadas (SQL + rollbacks) | 3,080 |
| Ratio de compresión | 6.3:1 |
| Scripts SQL producidos | 16 (10 unificación + 6 ordenamiento) |
| Scripts rollback | 9 |
| Total artefactos generados | 65 archivos, ~9,260 líneas |
| Bugs encontrados y corregidos | 8 (6 unificación + 2 ordenamiento) |
| Tasa de bugs (prompt directo) | 0.22 por cada 100 líneas |
| Velocidad prompt directo (nuevo) | ~180 líneas RS/hora |
| Velocidad prompt directo (replicar) | ~265 líneas RS/hora |
| Velocidad spec driven | ~50 líneas RS/hora |
| Personas mock validadas | 20 (unificación) + 9 (ordenamiento) |
| Personas sintéticas validadas | 5,000 + 5,000 |
| Registros procesados en pruebas | 8,000 relaciones + 95,210 insumos scoring |
| Steering files creados | 11 (2,039 líneas de contexto) |
| Specs generados | 4 documentos (821 líneas) |
| Correcciones aplicadas en revisión de spec | 20 (14 técnicas, 3 funcionales, 3 operativas) |
| Documentos técnicos generados | 13 docs (2,376 líneas) |
| Distribución esfuerzo: código vs resto | 25% código / 75% entendimiento+docs+pruebas+contexto |

---

*Documento generado para reunión de avance 2026-04-23.*
