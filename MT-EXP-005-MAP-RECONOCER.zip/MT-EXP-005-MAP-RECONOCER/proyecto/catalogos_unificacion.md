# Catálogos para Unificación R1-R2-R3 — Inventario Completo

> Documento de referencia: identifica todos los catálogos necesarios para el proceso de Unificación de Direcciones, su metadata, estructura, valores conocidos y dependencias.
>
> Fecha: 2026-06-25 | Autor: Francisco Peña

---

## Resumen Ejecutivo

| # | Catálogo | Regla | Tipo | Registros | ¿Se modifica? | Fuente |
|---|----------|-------|------|-----------|---------------|--------|
| 1 | `tipo_ubicacion_dir` | R1, R2 | Estático | 5 | No | Colibrí |
| 2 | `ciiu_persona` | R1 | Datos ref. | ~65M | Sí (cada carga XPM) | XPM/EDF |
| 3 | `nomenclatura` | R2 | Estático | 89 | No | Colibrí |
| 4 | `diccionario_complementos` | R2 | Derivado | Variable | ⚠️ Pendiente definir quién lo genera | ¿EDF o Redshift? |
| 5 | `diccionario_via` | R3 | Dinámico | Variable | Sí (se recalcula cada ejecución) | Se construye en Redshift |
| 6 | `bloqueado` (flag) | R1, R2, R3 | Flag | N/A | Sí (IDF actualiza) | IDF / Reclamación 2.0 |

---

## 1. TIPO_UBICACION_DIR

| Atributo | Valor |
|----------|-------|
| **Tabla** | `bdm_datos.tipo_ubicacion_dir` |
| **Reglas que lo usan** | R1, R2 |
| **Tipo** | Catálogo estático |
| **Registros esperados** | Mínimo 5 |
| **Distribución Redshift** | `DISTSTYLE ALL` (tabla lookup pequeña, replicada en todos los nodos) |
| **Fuente de carga** | Colibrí → Redshift (proceso automático del cliente) |

### Metadata

| Columna | Tipo | Descripción | Ejemplo |
|---------|------|-------------|---------|
| `cod_dw_tipo_ubicacion_dir` | INTEGER | PK — Código numérico del tipo | 1, 2, 3, 4, 5 |
| `descripcion_tipo_ubicacion_dir` | VARCHAR(20) | Descripción textual | RES, LAB, CRR, JUD, CCL |

### Datos completos

| Código | Descripción | Significado |
|--------|-------------|-------------|
| 1 | RES | Residencial — donde vive la persona |
| 2 | LAB | Laboral — donde trabaja la persona |
| 3 | CRR | Correspondencia — donde recibe correo/notificaciones |
| 4 | JUD | Judicial — dirección para notificaciones legales |
| 5 | CCL | Comercial — dirección del negocio (personas jurídicas) |

### Uso en la lógica

- **R1:** Se usa en el `PARTITION BY` y en las condiciones `tipo_direccion IN ('LAB','CRR')` / `tipo_direccion IN ('RES','CRR')` para determinar quién gana según el CIIU.
- **R2:** Se usa como criterio de agrupación — solo se comparan direcciones con el mismo tipo de uso.

### DDL Redshift

```sql
CREATE TABLE IF NOT EXISTS bdm_datos.tipo_ubicacion_dir (
  cod_dw_tipo_ubicacion_dir        INTEGER     ENCODE AZ64,
  descripcion_tipo_ubicacion_dir   VARCHAR(20) ENCODE BYTEDICT
)
DISTSTYLE ALL;
```

---

## 2. CIIU_PERSONA

| Atributo | Valor |
|----------|-------|
| **Tabla** | `bdm_datos.ciiu_persona` |
| **Reglas que lo usan** | R1 |
| **Tipo** | Datos de referencia (una fila por persona) |
| **Registros esperados** | ~65M (uno por persona del universo) |
| **Distribución Redshift** | `DISTSTYLE KEY DISTKEY(id_buro_persona)` |
| **Fuente de carga** | XPM via EDF — campo `personalinformation.val.mainisiccode` |

### Metadata

| Columna | Tipo | Descripción | Ejemplo |
|---------|------|-------------|---------|
| `id_buro_persona` | INTEGER | FK — Identificador de la persona en el buró | 1001, 1002 |
| `cod_act_econo_ciiu_fte` | VARCHAR(10) | Código CIIU de actividad económica | '10', '81', '82', '90', '55' |

### Valores relevantes para R1

| CIIU | Significado | Escenario R1 | Comportamiento |
|------|-------------|--------------|----------------|
| 10 | Asalariado | Escenario 1 | Prefiere LAB o CRR |
| 81 | Sin actividad | Escenario 2 | Prefiere RES o CRR |
| 82 | Sin actividad | Escenario 2 | Prefiere RES o CRR |
| 90 | Sin actividad | Escenario 2 | Prefiere RES o CRR |
| Cualquier otro | Otro CIIU | Escenario 3 | Mayor número de entidades |

### Nota importante

No es un catálogo estático — es una tabla de datos que se actualiza con cada carga del XPM. Pero actúa como lookup para R1. El CIIU determina el escenario de desempate.

### DDL Redshift

```sql
CREATE TABLE IF NOT EXISTS bdm_datos.ciiu_persona (
  id_buro_persona        INTEGER     ENCODE AZ64,
  cod_act_econo_ciiu_fte VARCHAR(10) ENCODE BYTEDICT
)
DISTSTYLE KEY DISTKEY(id_buro_persona);
```

---

## 3. NOMENCLATURA

| Atributo | Valor |
|----------|-------|
| **Tabla** | `bdm_datos.nomenclatura` |
| **Reglas que lo usan** | R2 (escenarios 3, 4, 5, 6 + Motor de nuevas direcciones) |
| **Tipo** | Catálogo estático |
| **Registros esperados** | ~89 |
| **Distribución Redshift** | `DISTSTYLE ALL` |
| **Fuente de carga** | Colibrí → Redshift. Los 89 registros son estáticos. |

### Metadata

| Columna | Tipo | Descripción | Ejemplo |
|---------|------|-------------|---------|
| `nomenclatura` | VARCHAR(10) | PK — Código abreviado de la nomenclatura | 'BR', 'TO', 'AP', 'LC', 'OF' |
| `nivel_complemento` | INTEGER | Nivel jerárquico (1=macro → 7=micro) | 1, 2, 3, 4, 5, 6, 7 |

### Datos conocidos (parcial — 89 registros totales, 7 niveles)

| Nivel | Nomenclaturas conocidas | Significado |
|-------|------------------------|-------------|
| 1 | BR, UR, CJ, CD | Barrio, Urbanización, Conjunto, Ciudadela |
| 2 | ED, MF, PT, PQ, ZN | Edificio, Multifamiliar, Portería, Parque, Zona |
| 3 | MZ, ET, BQ | Manzana, Etapa, Bloque |
| 4 | TO | Torre |
| 5 | PI, CS | Piso, Casa |
| 6 | LC, OF | Local, Oficina |
| 7 | AP | Apartamento |

### Uso en la lógica

- **R2 Esc 4:** Compara si dos nomenclaturas están al **mismo nivel** → desempata con diccionario de frecuencias.
- **R2 Esc 5:** Nomenclaturas a **diferente nivel** → genera nueva dirección combinando ambas.
- **R2 Esc 6:** Determina si se combinan o se desempatan según niveles.
- **Motor de nuevas direcciones:** Ordena nomenclaturas por nivel (de mayor a menor) para construir el complemento combinado. Usa la fórmula `Nivel_Complemento * 100000 + valor_numérico` para el ordenamiento de componentes.

### DDL Redshift

```sql
CREATE TABLE IF NOT EXISTS bdm_datos.nomenclatura (
  nomenclatura       VARCHAR(10) ENCODE ZSTD,
  nivel_complemento  INTEGER     ENCODE AZ64
)
DISTSTYLE ALL;
```

---

## 4. DICCIONARIO_COMPLEMENTOS

| Atributo | Valor |
|----------|-------|
| **Tabla** | `bdm_datos.diccionario_complementos` |
| **Reglas que lo usan** | R2 (escenarios 3, 4, 5, 6 + Motor de nuevas direcciones) |
| **Tipo** | Catálogo derivado / calculado |
| **Registros esperados** | Variable (depende del universo de direcciones) |
| **Distribución Redshift** | `DISTSTYLE KEY DISTKEY(cod_dw_ubic) SORTKEY(cod_dw_ubic, id_buro_persona)` |
| **Fuente de carga** | ⚠️ **Pendiente definir** — se genera a partir de los datos de reportes históricos |

### Metadata

| Columna | Tipo | Descripción | Ejemplo |
|---------|------|-------------|---------|
| `cod_dw_ubic` | BIGINT | FK — Dirección geográfica (puerta) a la que pertenece | 5007 |
| `id_buro_persona` | INTEGER | FK — Persona dueña del complemento | 1007 |
| `nomenclatura` | VARCHAR(50) | Texto completo del complemento individual | 'LC 101', 'BR CEDRITOS', 'TO 3' |
| `nomen` | VARCHAR(10) | Nomenclatura abreviada (FK → `nomenclatura.nomenclatura`) | 'LC', 'BR', 'TO' |
| `valor` | VARCHAR(50) | Valor numérico o texto de la nomenclatura | '101', 'CEDRITOS', '3' |
| `frecuencia` | INTEGER | Veces que esta nomenclatura fue reportada para esa puerta+persona | 8, 15, 3 |

### Ejemplo de datos

Para la dirección `CL 10 20 30` (cod_dw_ubic=5007), persona 1007:

| cod_dw_ubic | id_buro_persona | nomenclatura | nomen | valor | frecuencia |
|-------------|-----------------|--------------|-------|-------|------------|
| 5007 | 1007 | LC 101 | LC | 101 | 8 |
| 5007 | 1007 | LC 205 | LC | 205 | 4 |

Para la dirección `CL 22 27 45` (cod_dw_ubic=5003), persona 2005:

| cod_dw_ubic | id_buro_persona | nomenclatura | nomen | valor | frecuencia |
|-------------|-----------------|--------------|-------|-------|------------|
| 5003 | 2005 | TO 3 | TO | 3 | 15 |
| 5003 | 2005 | BQ 5 | BQ | 5 | 3 |
| 5003 | 2005 | BR CASTILLA | BR | CASTILLA | 9 |

### Uso en la lógica

- **R2 Esc 4/6:** `SUM(frecuencia)` por complemento para desempatar por frecuencia total. El complemento con mayor frecuencia acumulada gana.
- **Motor de nuevas direcciones:** `JOIN ... ON complemento LIKE '%' || dc.nomenclatura || '%' AND cod_dw_ubic = dc.cod_dw_ubic AND id_buro_persona = dc.id_buro_persona` para descomponer un complemento en sus nomenclaturas individuales.
- Se usa junto con `NOMENCLATURA` para determinar niveles y ordenar la construcción de direcciones nuevas.

### Relación con NOMENCLATURA

```
diccionario_complementos.nomen → nomenclatura.nomenclatura
```

Cada fila del diccionario referencia una nomenclatura del catálogo. El nivel se obtiene via JOIN.

### DDL Redshift

```sql
CREATE TABLE IF NOT EXISTS bdm_datos.diccionario_complementos (
  cod_dw_ubic      BIGINT      ENCODE AZ64,
  id_buro_persona  INTEGER     ENCODE AZ64,
  nomenclatura     VARCHAR(50) ENCODE ZSTD,
  nomen            VARCHAR(10) ENCODE ZSTD,
  valor            VARCHAR(50) ENCODE ZSTD,
  frecuencia       INTEGER     ENCODE AZ64
)
DISTSTYLE KEY DISTKEY(cod_dw_ubic)
SORTKEY(cod_dw_ubic, id_buro_persona);
```

---

## 5. DICCIONARIO_VIA

| Atributo | Valor |
|----------|-------|
| **Tabla** | `bdm_datos.diccionario_via` |
| **Reglas que lo usan** | R3 |
| **Tipo** | Catálogo derivado / calculado dinámicamente en cada ejecución |
| **Registros esperados** | Variable (se construye en el paso 3 de R3) |
| **Distribución Redshift** | `DISTSTYLE ALL` |
| **Fuente de carga** | Se calcula dinámicamente en `10_regla3_geo.sql` a partir de `direccion_fisica` + `reporte_relacion_persona_ubica` |

### Metadata

| Columna | Tipo | Descripción | Ejemplo |
|---------|------|-------------|---------|
| `tipo` | VARCHAR(20) | Tipo de componente variable | 'Via_Generadora', 'Numero_Puerta' |
| `llave` | VARCHAR(100) | Parte fija de la dirección (excluye el componente variable) | 'KR 7 75', 'CL 80 15' |
| `via_generadora` | INTEGER | Valor del componente variable (vía generadora o número de puerta) | 78, 181, 20, 22 |
| `cod_dw_municipio` | INTEGER | Código de municipio (para filtrar por localidad) | 11001 |
| `conteo` | INTEGER | Frecuencia: cuántos reportes tienen esta vía/puerta | 15, 3, 22 |

### Ejemplo de datos — Escenario 1 (diferencia en vía generadora)

Para `KR 7 _ 75` (la vía generadora es el componente variable):

| tipo | llave | via_generadora | cod_dw_municipio | conteo |
|------|-------|----------------|------------------|--------|
| Via_Generadora | KR 7 75 | 181 | 11001 | 15 |
| Via_Generadora | KR 7 75 | 182 | 11001 | 3 |

→ Vía 181 tiene 15 reportes vs 182 tiene 3. Gana la dirección con vía generadora 181.

### Ejemplo de datos — Escenario 2 (diferencia en número de puerta)

Para `CL 80 15 _` (el número de puerta es el componente variable):

| tipo | llave | via_generadora | cod_dw_municipio | conteo |
|------|-------|----------------|------------------|--------|
| Numero_Puerta | CL 80 15 | 20 | 11001 | 22 |
| Numero_Puerta | CL 80 15 | 22 | 11001 | 5 |

→ Puerta 20 tiene 22 reportes vs 22 tiene 5. Gana la dirección con número de puerta 20.

### Cómo se construye (paso 3 de R3)

```sql
-- Via_Generadora: llave = tipo_via + via_principal + numero_puerta
SELECT
  'Via_Generadora' AS tipo,
  df.tipo_via_principal || ' ' || df.via_principal || ' ' || CAST(df.numero_puerta AS VARCHAR) AS llave,
  df.via_generadora,
  p.cod_dw_municipio,
  COUNT(rep.cod_dw_persona_ubic) AS conteo
FROM bdm_datos.direccion_fisica df
JOIN bdm_datos.ubicacion_estandarizada ue ON df.cod_dw_ubic = ue.cod_dw_ubic
JOIN bdm_datos.relacion_persona_ubicacion rpu ON ...
JOIN bdm_datos.reporte_relacion_persona_ubica rep ON ...
GROUP BY 1,2,3,4

UNION ALL

-- Numero_Puerta: llave = tipo_via + via_principal + via_generadora
SELECT
  'Numero_Puerta' AS tipo,
  df.tipo_via_principal || ' ' || df.via_principal || ' ' || CAST(df.via_generadora AS VARCHAR) AS llave,
  df.numero_puerta AS via_generadora,
  p.cod_dw_municipio,
  COUNT(rep.cod_dw_persona_ubic) AS conteo
FROM ...
GROUP BY 1,2,3,4;
```

### Uso en la lógica

- **R3 Subcaso 3** (ambos tienen lat/long): Se suma `100000000 + conteo` del diccionario al score. El que tiene mayor frecuencia en el diccionario gana.
- Se construye solo para las direcciones candidatas en R3 (no para todo el universo).
- Se persiste en `bdm_datos.diccionario_via` para referencia/auditoría.

### DDL Redshift

```sql
CREATE TABLE IF NOT EXISTS bdm_datos.diccionario_via (
  tipo             VARCHAR(20)  ENCODE ZSTD,
  llave            VARCHAR(100) ENCODE ZSTD,
  via_generadora   INTEGER      ENCODE AZ64,
  cod_dw_municipio INTEGER      ENCODE AZ64,
  conteo           INTEGER      ENCODE AZ64
)
DISTSTYLE ALL;
```

---

## 6. BLOQUEADO (Flag en relacion_persona_ubicacion)

| Atributo | Valor |
|----------|-------|
| **Ubicación** | Campo `bloqueado` en `bdm_datos.relacion_persona_ubicacion` |
| **Reglas que lo usan** | R1, R2, R3 (filtro de exclusión) |
| **Tipo** | Flag por registro (no es tabla separada) |
| **Fuente** | ⚠️ Debe venir de IDF como flag por dato de contacto. Funcionalidad "Reclamación 2.0" |

### Metadata

| Columna | Tipo | Descripción | Valores |
|---------|------|-------------|---------|
| `bloqueado` | SMALLINT | Flag: dato bloqueado por fraude/reclamación | 0 = activo, 1 = bloqueado |

### Uso en la lógica

Todas las reglas **excluyen** registros con `bloqueado = 1`:

```sql
WHERE rpu.ind_unificacion IS NULL
  AND rpu.bloqueado = 0  -- No procesar datos bloqueados
```

Un dato bloqueado es un dato de contacto (dirección, teléfono, email) que fue reportado como fraudulento o que tiene una reclamación activa. No debe participar en ningún producto de Reconocer.

### DDL (parte de relacion_persona_ubicacion)

```sql
-- Campo dentro de la tabla principal:
bloqueado SMALLINT ENCODE AZ64 DEFAULT 0  -- 0=activo, 1=bloqueado (fraude/reclamación)
```

---

## Diagrama de Relaciones entre Catálogos

```
                    ┌─────────────────────────┐
                    │  tipo_ubicacion_dir      │
                    │  (5 registros)           │
                    │  PK: cod_dw_tipo_ubic..  │
                    └────────────┬────────────┘
                                 │ FK
                                 ▼
┌──────────────┐    ┌─────────────────────────────────────────────┐
│ ciiu_persona │    │  relacion_persona_ubicacion                  │
│ (~65M reg)   │◄───│  (tabla central — ~70M registros)            │
│ PK: id_buro  │    │  cod_dw_tipo_ubicacion_dir → tipo_ubicacion  │
│              │    │  bloqueado (flag 0/1)                         │
└──────────────┘    └──────────┬──────────────────────────────────┘
                               │
                               │ cod_dw_ubic
                               ▼
                    ┌─────────────────────────────┐
                    │  ubicacion_estandarizada     │
                    │  PK: cod_dw_ubic             │
                    └──────────┬──────────────────┘
                               │
                               │ cod_dw_ubic
                               ▼
┌──────────────────────────────────────────────────────────┐
│  diccionario_complementos                                 │
│  FK: cod_dw_ubic + id_buro_persona                        │
│  nomen ──────────────────────────────────────┐            │
└──────────────────────────────────────────────┼────────────┘
                                               │ FK
                                               ▼
                    ┌─────────────────────────────┐
                    │  nomenclatura                │
                    │  (89 registros)              │
                    │  PK: nomenclatura            │
                    │  nivel_complemento (1-7)     │
                    └─────────────────────────────┘


┌─────────────────────────────────────────────────────────────────┐
│  diccionario_via  (se construye dinámicamente en R3)             │
│  tipo: 'Via_Generadora' | 'Numero_Puerta'                        │
│  Fuente: direccion_fisica + reporte_relacion_persona_ubica       │
└─────────────────────────────────────────────────────────────────┘
```

---

## Dependencias Pendientes de Definición

| # | Catálogo | Pregunta abierta | Impacto | Responsable |
|---|----------|------------------|---------|-------------|
| 1 | `diccionario_complementos` | ¿Lo genera la estandarización en EDF o se calcula en Redshift a partir de los reportes históricos? | 🔴 Bloqueante para R2 escenarios 3-6 | Equipo + Adriana (Ingesta) |
| 2 | `nomenclatura` | ¿Los 89 registros son 100% estáticos o se agregan nuevas nomenclaturas con el tiempo? | Medio — define si requiere actualización periódica | Experian (Wilmar) |
| 3 | `tipo_ubicacion_dir` | ¿`contacttype` (BIGINT) del XPM usa los mismos códigos 1-5? ¿Hay catálogo de decodificación? | 🔴 Bloqueante para mapeo XPM → Redshift | Experian |
| 4 | `bloqueado` | ¿IDF ya entrega este flag o hay que implementar la funcionalidad "Reclamación 2.0"? | 🔴 Bloqueante — sin esto entran datos de fraude al proceso | IDF / Fernando |
| 5 | `ciiu_persona` | ¿`mainisiccode` del XPM es el CIIU colombiano? ¿Misma codificación que Teradata? | Medio — posible tabla de conversión | Experian |

---

## Checklist de Validación Pre-Ejecución

El script `00_checklist_pre_ejecucion.sql` valida automáticamente:

| Check | Catálogo | Validación | Criterio |
|-------|----------|-----------|----------|
| 5.1 | `tipo_ubicacion_dir` | Tiene registros | ≥ 3 (RES, LAB, CRR) |
| 5.2 | `nomenclatura` | Tiene registros | ≥ 10 (de 89 esperados) |
| 5.3 | `diccionario_complementos` | Tiene registros | > 0 |
| 5.4 | `diccionario_via` | Tiene registros | > 0 (WARN si no — solo R3) |
| 7.4 | `diccionario_complementos` → `nomenclatura` | FK integridad | 0 registros sin catálogo |

---

*Documento generado: 2026-06-25 | Fuentes: `01_schemas_roles.sql`, `00_checklist_pre_ejecucion.sql`, `modelo_datos.md`, `mapeo_campos_xpm.md`, análisis de scripts Teradata*
