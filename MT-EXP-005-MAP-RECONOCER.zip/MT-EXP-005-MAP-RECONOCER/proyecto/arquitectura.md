# Arquitectura del Proyecto – Reconocer

> Resumen ejecutivo de la arquitectura de migración. Fuente: entregables de preventa EXP-005.

---

## Arquitectura Actual (AS-IS)

```
COBOL (ICBDIR)  →  TERADATA  →  DB2
  Archivo            Procesamiento     Consulta
  Maestro            + Estandarización Online
  Direcciones        + UDFs en C
                     65-70M registros
```

| Componente | Función | Tecnología |
|------------|---------|------------|
| COBOL (ICBDIR) | Archivo maestro de direcciones. Cargue semanal de deltas | Cobol |
| Teradata | Estandarización (8 etapas), Unificación, Ordenamiento, Cálculo | Teradata + UDFs en C |
| DB2 | Tablas precalculadas para servicio en línea y portal | DB2 |
| Control-M | Orquestación de procesos batch | Control-M |

**Limitaciones**: No permite cargue full (solo deltas). Full toma ~1 mes máquina. Ordenamiento: 6h fines de semana.

---

## Arquitectura Objetivo (TO-BE): Híbrida EDF + Redshift

```
COBOL (ICBDIR)  →  EDF Pipeline  →  REDSHIFT  →  DB2
                   (Spark/Scala)     (SQL)         (Online)
                   Ingesta +         Ordenamiento
                   Estandarización   + Cálculo
                   (Curation)        + Batch
```

**Justificación**: EDF es el punto de ingesta obligatorio de todos los datos del buró de Experian (estrategia XPMS).

### Distribución de responsabilidades

| Plataforma | Responsabilidad | Tecnología |
|------------|----------------|------------|
| **EDF** | Ingesta + Estandarización (8 etapas) en etapa Curation | Spark/Scala |
| **Redshift** | Ordenamiento + Cálculo + Modelo Batch | SQL |
| **DB2** | Servicio en línea (consulta) | DB2 |

### Decisiones resueltas

| Decisión | Resultado | Fecha |
|----------|-----------|-------|
| Estandarización en EDF | Etapa **Curation** del pipeline IFR. Campo nuevo en XPM | 19/03/2026 |
| Impacto en PINNING | **No se toca**. Campo nuevo no consumido por PINNING | 19/03/2026 |
| Arquitectura general | Híbrida EDF + Redshift (12 meses, optimizable a 10) | 16/03/2026 |

### Decisión abierta

| Decisión | Opciones | Estado |
|----------|----------|--------|
| ¿Dónde hacer Ordenamiento? | EDF (Spark) vs Redshift (SQL) | Pendiente workshop |

---

## Plataformas clave

### EDF (Experian Data Fabric)
- Pipeline de ingesta y procesamiento sobre Apache Spark + Scala
- Genera archivos **XPM** (JSON) = 1 persona con todos sus datos
- Etapa **Curation**: donde se implementará la nueva estandarización
- **Curation diaria**: solo deltas. **Curation Stop** (cada 1-2 semanas): reprocesa todo el histórico (4 años)

### XPMS (Experian Platform Management System)
- Plataforma estratégica: "single source of truth" por ciudadano
- Todo dato del buró debe pasar por EDF para mantener consistencia

### Redshift
- Destino para ordenamiento y cálculo SQL
- Estructura de tablas ≠ Teradata (1 tabla TD puede ser 5 en RS)
- Funciones nativas de TD no existen en RS → requiere re-implementación

---

## Cronograma de alto nivel

| Fase | Meses | Plataforma | Alcance Macondotek |
|------|-------|------------|-------------------|
| Planeación + POC | M1-M2 | — | ✅ Sí |
| Estandarización | M2-M7 | EDF | ✅ Sí (Fase 2) |
| Ordenamiento + Cálculo | M3-M10 | Redshift | ✅ Sí (Fase 3) |
| Batch + Servicio en línea | M8-M10 | Redshift + DB2 | ✅ Sí |

**Deadlines**: Batch octubre 2026 | Servicio en línea noviembre 2026 | Datos estandarizados en XPM junio 2026

---

## Dependencia crítica

**IFR**: El proyecto depende de que IFR salga (fecha tentativa agosto 2026). Si IFR no sale, Reconocer se bloquea.

---

*Fuente: 01_contexto_proyecto.md, 02_fases_tecnicas.md (preventa EXP-005)*
