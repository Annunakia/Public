# Contrato de Campos: EDF → Redshift (Unificación + Ordenamiento)

> **Fecha**: 28 de abril de 2026 | **Autor**: Francisco Peña | **Macondotek**
> **Proyecto**: MT-EXP-005-MAP-RECONOCER | **Cliente**: Experian Colombia
> **Objetivo**: Definir los campos mínimos que EDF (Curation) debe entregar para que los procesos de Unificación y Ordenamiento funcionen en Redshift.
> **Estado**: Borrador para validación con equipo de Ingesta (IDF)

---

## 1. Contexto

Redshift ejecuta dos procesos que consumen datos estandarizados producidos por EDF:

- **Unificación**: Consolida direcciones duplicadas por persona (3 reglas en cascada, 12 escenarios). Procesa ~65-70M ciudadanos.
- **Ordenamiento**: Calcula un score de contactabilidad por dato de contacto usando regresión logística con coeficientes Beta. 4 canales: dirección, teléfono fijo, celular, email.

Ambos procesos necesitan que EDF entregue los datos de contacto ya estandarizados, con ciertos campos desglosados que hoy no existen en el XPM.

### Fuentes de este documento

| Fuente | Ubicación |
|--------|-----------|
| Modelo de datos Unificación | `ws-unificacion/docs/tecnico/modelo_datos.md` |
| Mapeo campos XPM (validado contra sandbox) | `ws-unificacion/docs/tecnico/mapeo_campos_xpm.md` |
| Análisis scripts Ordenamiento | `ws-ordenamiento/docs/tecnico/analisis_scripts.md` |
| Hallazgos reunión técnica 24/04/2026 | `ws-unificacion/docs/tecnico/mapeo_campos_xpm.md` §7 |
| Código migrado Unificación | `ws-unificacion/src/redshift/sql/` (10 scripts) |
| Código migrado Ordenamiento | `ws-ordenamiento/src/redshift/sql/` (6 scripts) |

---

## 2. Campos Requeridos — UNIFICACIÓN

### 2.1 Identificación de la persona

| # | Campo | Tipo | Descripción | Reglas que lo usan | Estado en XPM sandbox |
|---|-------|------|-------------|-------------------|----------------------|
| U01 | `id_buro_persona` | BIGINT | Identificador de la persona en el buró | R1, R2, R3 | ✅ `xpm.id` |
| U02 | `cod_pin_persona` | BIGINT | Agrupador de persona (puede tener NIT + CC) | R2 | ✅ `xpm.pin` — ⚠️ pin Teradata ≠ pin XPM, verificar equivalencia |
| U03 | `cod_tipo_ident_fte` | VARCHAR | Tipo de identificación (CC, NIT, CE, TI) | R2 (Esc 3 NIT) | ⚠️ `bestidentifications.val.personidtype` (BIGINT, no VARCHAR) |
| U04 | `cod_dw_doc_ident` | VARCHAR | Número de documento de identidad | R2 (Esc 3 NIT) | ⚠️ `bestidentifications.val.personidnumber` |
| U05 | `cod_act_econo_ciiu_fte` | INTEGER | Código CIIU de actividad económica | R1 (decide por CIIU) | ⚠️ `personalinformation.val.mainisiccode` |

### 2.2 Dirección estandarizada — Componentes desglosados

Estos son los campos que la estandarización en EDF debe producir. Hoy la dirección llega como texto completo en `contactasreported`. Unificación necesita los componentes separados.

| # | Campo | Tipo | Descripción | Reglas que lo usan | Estado en XPM sandbox |
|---|-------|------|-------------|-------------------|----------------------|
| U06 | `texto_ubicacion` | VARCHAR(200) | Dirección estandarizada completa (la "puerta": ej. CL 22 27 45) | R1, R2, R3 | ✅ `contactasreported` — verificar si llega estandarizada o cruda |
| U07 | **`complemento`** | VARCHAR(100) | Complemento separado de la dirección (ej. BR ALAMEDA AP 401) | R1, R2 | ❌ **NO EXISTE**. Viene concatenado en `contactasreported` |
| U08 | **`tipo_via_principal`** | VARCHAR(20) | Tipo de vía: CL, KR, TV, DG, AC, AK | R3 | ❌ **NO EXISTE** |
| U09 | **`via_principal`** | VARCHAR(100) | Nombre o número de la vía principal | R3 | ❌ **NO EXISTE** |
| U10 | **`via_generadora`** | INTEGER | Número de la vía generadora (cruce) | R3 | ❌ **NO EXISTE** |
| U11 | **`numero_puerta`** | INTEGER | Número de puerta | R3 | ❌ **NO EXISTE** |

**¿Por qué son críticos?**
- Sin `complemento` (U07): Regla 2 no puede comparar complementos entre direcciones → 6 escenarios inoperantes.
- Sin `tipo_via_principal` + `via_generadora` + `numero_puerta` (U08-U11): Regla 3 no puede detectar diferencias en vía generadora ni validar ±2 posiciones de puerta.

**Referencia**: Estos campos son exactamente lo que la UDF en C `ADDRESS_NORMALIZATION` produce hoy en Teradata. El código fuente está en `Experian Reconocer/UDFs/ADDRESS_NORMALIZATION/`.

### 2.3 Ubicación geográfica

| # | Campo | Tipo | Descripción | Reglas que lo usan | Estado en XPM sandbox |
|---|-------|------|-------------|-------------------|----------------------|
| U12 | `cod_dw_ciudad` | INTEGER | Código DANE de la ciudad (8 dígitos) | R1, R2, R3 | ⚠️ `contactinformations.val.citycode` — verificar formato DANE |
| U13 | `cod_dw_municipio` | INTEGER | Código de municipio DANE | R2 | ❌ No existe. Solo hay `citycode` y `statecode` |
| U14 | `latitud` | DECIMAL(38,8) | Latitud de la dirección geocodificada | R3 | ❌ No existe. Geolocalización desconectada |
| U15 | `longitud` | DECIMAL(38,8) | Longitud de la dirección geocodificada | R3 | ❌ No existe. Geolocalización desconectada |

**Nota sobre U14-U15**: Regla 3 depende de lat/long para sus 3 subcasos. Si la geolocalización no se reactiva, Regla 3 opera en modo degradado (solo subcasos 1 y 2: por fecha y entidades).

### 2.4 Contexto de reporte

| # | Campo | Tipo | Descripción | Reglas que lo usan | Estado en XPM sandbox |
|---|-------|------|-------------|-------------------|----------------------|
| U16 | `contacttype` | INTEGER | Tipo de uso de la dirección (RES=1?, LAB=2?, CRR=3?) | R1, R2 | 🔵 `contactinformations.val.contacttype` (BIGINT) — falta catálogo de decodificación |
| U17 | `id_buro_suscriptor` | INTEGER | Identificador del suscriptor que reporta el dato | R1, R2, R3 | ⚠️ `counterparties.val.counterpartyidnumber` |
| U18 | `fecha_reporte` | DATE | Fecha de corte del reporte | R1, R2, R3 | ⚠️ `location.val.cutoffdate` (BIGINT epoch → convertir a DATE) |
| U19 | `fecha_relacion_persona_ubicacion` | DATE | Fecha del primer evento de la relación persona-ubicación | R2, R3 | ✅ `location.val.locationfirsteventdate` |
| U20 | `bloqueado` | INTEGER | Flag: 1=dato bloqueado (fraude/reclamación), 0=activo | R1, R2, R3 | ❌ No existe. Funcionalidad "Reclamación 2.0" |

### 2.5 Campos derivables (Redshift los calcula)

| # | Campo | Tipo | Cómo se calcula | Reglas |
|---|-------|------|----------------|--------|
| U21 | `numero_entidades_reportan` | INTEGER | `COUNT(DISTINCT id_buro_suscriptor)` por persona + ubicación | R1, R2, R3 |

### 2.6 Campos internos (Redshift los crea y gestiona)

| # | Campo | Tipo | Descripción | Tabla destino |
|---|-------|------|-------------|---------------|
| U22 | `ind_unificacion` | INTEGER | Flag: NULL=no procesada, 1=hija unificada | RELACION_PERSONA_UBICACION |
| U23 | `unifica_atributos` | INTEGER | Tipo de regla aplicada (1=R1/R3, 2=R2) | UNIFICACION_DIRECCION |
| U24 | `fecha_unificacion` | DATE | CURRENT_DATE al momento de unificar | UNIFICACION_DIRECCION |
| U25 | `generada_enriquecida` | INTEGER | Flag: 1=dirección generada por Regla 2 (motor) | DIRECCION_FISICA |
| U26 | `lote` | INTEGER | Número de lote batch | Varias tablas |

---

## 3. Campos Requeridos — ORDENAMIENTO

El ordenamiento calcula un score por dato de contacto usando la fórmula:

```
Score = Σ (categoría_i / max_categoría_i) × Beta_i
Lugar = ROW_NUMBER() OVER (PARTITION BY persona ORDER BY Score DESC)
```

### 3.1 Campos base (compartidos con Unificación)

| # | Campo | Tipo | Uso en scoring | Estado en XPM |
|---|-------|------|---------------|---------------|
| O01 | `id_buro_persona` | BIGINT | Agrupar scores por persona | ✅ = U01 |
| O02 | `cod_pin_persona` | BIGINT | Agrupar persona (NIT + natural) | ✅ = U02 |
| O03 | `texto_ubicacion` | VARCHAR | Dato de contacto a rankear | ✅ = U06 |
| O04 | `contacttype` | INTEGER | Distinguir DIR vs TEL vs CEL vs EMA | 🔵 = U16 |
| O05 | `id_buro_suscriptor` | INTEGER | Contar entidades que reportan | ⚠️ = U17 |
| O06 | `fecha_reporte` | DATE | Calcular ventanas temporales (3m, 6m, 12m) | ⚠️ = U18 |
| O07 | `fecha_relacion_persona_ubicacion` | DATE | Antigüedad de la relación | ✅ = U19 |
| O08 | `bloqueado` | INTEGER | Excluir datos bloqueados del ranking | ❌ = U20 |

### 3.2 Campos específicos para scoring de DIRECCIÓN (canal CO00DIR)

12 características de scoring. Campos adicionales requeridos:

| # | Campo | Tipo | Característica | Descripción |
|---|-------|------|---------------|-------------|
| O09 | `cod_dw_ciudad` | INTEGER | CO00DIR001 | Coincidencia geográfica con ciudad DANE |
| O10 | `contacttype` (RES/LAB/CRR) | INTEGER | CO00DIR005 | Tipo de uso de la dirección |
| O11 | `descripcion_gestion_registro` | VARCHAR | CO00DIR | Validez del registro: VALIDA / NO VALIDA |
| O12 | `descripcion_fuente` | VARCHAR | CO00DIR | Sector financiero de la fuente que reporta |
| O13 | `numero_entidades_reportan` | INTEGER | CO00DIR | Derivable: COUNT DISTINCT suscriptores |
| O14 | `ind_unificacion` | INTEGER | CO00DIR | Flag de unificación (resultado del proceso anterior) |

### 3.3 Campos específicos para scoring de TELÉFONO FIJO (canal CO01TEL)

11 características de scoring. Campos adicionales requeridos:

| # | Campo | Tipo | Característica | Descripción |
|---|-------|------|---------------|-------------|
| O15 | `numero_telefono` | VARCHAR | CO01TEL | Número de teléfono fijo (7-10 dígitos) |
| O16 | `cod_area` | VARCHAR | CO01TEL020 | Indicativo/código de área del teléfono |
| O17 | `cod_dw_geografia` | INTEGER | CO01TEL | Código geográfico asociado al teléfono |
| O18 | `descripcion_gestion_registro` | VARCHAR | CO01TEL | Validez: VALIDA / NO VALIDA |
| O19 | `descripcion_fuente` | VARCHAR | CO01TEL | Sector financiero de la fuente |

### 3.4 Campos específicos para scoring de CELULAR (canal CO01CEL)

11 características de scoring. Campos adicionales requeridos:

| # | Campo | Tipo | Característica | Descripción |
|---|-------|------|---------------|-------------|
| O20 | `numero_celular` | VARCHAR | CO01CEL | Número de celular (10 dígitos) |
| O21 | `prefijo_3_digitos` | VARCHAR(3) | CO01CEL023 | Primeros 3 dígitos del celular (identifica operador). Derivable de `numero_celular` |
| O22 | `tipo_cuenta` | VARCHAR | CO01CEL | Tipo de cuenta asociada al reporte |
| O23 | `es_tipo_lab` | VARCHAR(1) | CO01CEL | Flag: 'S' si el dato es de tipo laboral |
| O24 | `descripcion_gestion_registro` | VARCHAR | CO01CEL | Validez: VALIDA / NO VALIDA |

### 3.5 Campos específicos para scoring de EMAIL (canal CO01EMA)

13 características de scoring. Campos adicionales requeridos:

| # | Campo | Tipo | Característica | Descripción |
|---|-------|------|---------------|-------------|
| O25 | `email` | VARCHAR | CO01EMA | Dirección de email completa |
| O26 | `dominio` | VARCHAR | CO01EMA | Dominio del email (gmail.com, hotmail.com). Derivable de `email` |
| O27 | `buzon` | VARCHAR | CO01EMA | Buzón del email (parte antes del @). Derivable de `email` |
| O28 | `descripcion_gestion_registro` | VARCHAR | CO01EMA | Validez: VALIDA / NO VALIDA |
| O29 | `descripcion_fuente` | VARCHAR | CO01EMA | Sector financiero de la fuente |

### 3.6 Tablas de parámetros (coeficientes Beta)

Se cargan vía Colibrí → Redshift. No vienen de EDF.

| # | Tabla | Canal | Contenido |
|---|-------|-------|-----------|
| P01 | `V_Beta_Ordenamiento_Dir` | Dirección | 12 coeficientes Beta |
| P02 | `V_Beta_Ordenamiento_Tel` | Teléfono fijo | 11 coeficientes Beta |
| P03 | `V_Beta_Ordenamiento_Cel` | Celular | 11 coeficientes Beta |
| P04 | `V_Beta_Ordenamiento_Email` | Email | 13 coeficientes Beta |

### 3.7 Campos internos del Ordenamiento (Redshift los crea)

| # | Campo | Tipo | Descripción | Tabla destino |
|---|-------|------|-------------|---------------|
| O30 | `orden_prioridad` | INTEGER | Ranking calculado (1=mejor) | RELACION_PERSONA_UBICACION |
| O31 | `orden_prioridad_anterior` | INTEGER | Ranking del ciclo anterior | RELACION_PERSONA_UBICACION |
| O32 | `fecha_ult_ordenamiento` | DATE | Fecha del último ordenamiento | RELACION_PERSONA_UBICACION |
| O33 | `score` | DECIMAL(18,4) | Score calculado por regresión logística | Tabla intermedia |

---

## 4. Resumen Consolidado — Qué debe proveer EDF

### 4.1 Campos compartidos (Unificación + Ordenamiento)

Estos campos los necesitan ambos procesos. EDF los entrega una vez.

| # | Campo | Tipo | Unificación | Ordenamiento | Estado XPM | Acción requerida |
|---|-------|------|:-----------:|:------------:|:----------:|-----------------|
| C01 | `id_buro_persona` | BIGINT | ✅ R1,R2,R3 | ✅ 4 canales | ✅ `xpm.id` | Ninguna |
| C02 | `cod_pin_persona` | BIGINT | ✅ R2 | ✅ 4 canales | ✅ `xpm.pin` | Verificar equivalencia pin TD vs XPM |
| C03 | `texto_ubicacion` | VARCHAR(200) | ✅ R1,R2,R3 | ✅ 4 canales | ✅ `contactasreported` | Verificar si llega estandarizada |
| C04 | `contacttype` | INTEGER | ✅ R1,R2 | ✅ 4 canales | 🔵 Existe (BIGINT) | **Entregar catálogo de decodificación** |
| C05 | `id_buro_suscriptor` | INTEGER | ✅ R1,R2,R3 | ✅ 4 canales | ⚠️ Nombre diferente | Mapear a `counterpartyidnumber` |
| C06 | `fecha_reporte` | DATE | ✅ R1,R2,R3 | ✅ 4 canales | ⚠️ BIGINT epoch | **Convertir a DATE** |
| C07 | `fecha_relacion_persona_ubicacion` | DATE | ✅ R2,R3 | ✅ 4 canales | ✅ `locationfirsteventdate` | Ninguna |
| C08 | `cod_dw_ciudad` | INTEGER | ✅ R1,R2,R3 | ✅ DIR | ⚠️ En contactinformations | Verificar formato DANE |
| C09 | `bloqueado` | INTEGER | ✅ R1,R2,R3 | ✅ 4 canales | ❌ No existe | **EDF debe agregar flag** |
| C10 | `descripcion_gestion_registro` | VARCHAR | ❌ | ✅ 4 canales | ❌ No verificado | **Confirmar existencia** |
| C11 | `descripcion_fuente` | VARCHAR | ❌ | ✅ DIR,TEL,EMA | ❌ No verificado | **Confirmar existencia** |

### 4.2 Campos exclusivos de Unificación

| # | Campo | Tipo | Reglas | Estado XPM | Acción requerida |
|---|-------|------|--------|:----------:|-----------------|
| C12 | `cod_tipo_ident_fte` | VARCHAR | R2 | ⚠️ BIGINT | Mapear + convertir tipo |
| C13 | `cod_dw_doc_ident` | VARCHAR | R2 | ⚠️ Nombre diferente | Mapear a `personidnumber` |
| C14 | `cod_act_econo_ciiu_fte` | INTEGER | R1 | ⚠️ `mainisiccode` | Verificar equivalencia CIIU |
| C15 | `cod_dw_municipio` | INTEGER | R2 | ❌ No existe | Derivar de `citycode` o crear catálogo |
| C16 | **`complemento`** | VARCHAR(100) | R1,R2 | ❌ **NO EXISTE** | 🔴 **EDF debe separar en estandarización** |
| C17 | **`tipo_via_principal`** | VARCHAR(20) | R3 | ❌ **NO EXISTE** | 🔴 **EDF debe generar en estandarización** |
| C18 | **`via_principal`** | VARCHAR(100) | R3 | ❌ **NO EXISTE** | 🔴 **EDF debe generar en estandarización** |
| C19 | **`via_generadora`** | INTEGER | R3 | ❌ **NO EXISTE** | 🔴 **EDF debe generar en estandarización** |
| C20 | **`numero_puerta`** | INTEGER | R3 | ❌ **NO EXISTE** | 🔴 **EDF debe generar en estandarización** |
| C21 | `latitud` | DECIMAL(38,8) | R3 | ❌ No existe | Depende de reactivación Geolitics |
| C22 | `longitud` | DECIMAL(38,8) | R3 | ❌ No existe | Depende de reactivación Geolitics |

### 4.3 Campos exclusivos de Ordenamiento

| # | Campo | Tipo | Canal | Estado XPM | Acción requerida |
|---|-------|------|-------|:----------:|-----------------|
| C23 | `cod_area` | VARCHAR | TEL | ❌ No verificado | **Confirmar existencia** |
| C24 | `cod_dw_geografia` | INTEGER | TEL | ❌ No verificado | **Confirmar existencia** |
| C25 | `tipo_cuenta` | VARCHAR | CEL | ❌ No verificado | **Confirmar existencia** |
| C26 | `es_tipo_lab` | VARCHAR(1) | CEL | ❌ No verificado | **Confirmar existencia** |

**Nota**: Los campos de email (`dominio`, `buzon`) y celular (`prefijo_3_digitos`) son derivables en Redshift a partir de `texto_ubicacion`. No necesitan venir de EDF.

---

## 5. Campos Bloqueantes — Los 5 que EDF debe generar

Estos campos **no existen hoy en el XPM** y son indispensables para que Unificación funcione. Son el producto de la estandarización de direcciones que hoy hace la UDF en C en Teradata.

| # | Campo | Tipo | Sin este campo... | Impacto |
|---|-------|------|-------------------|---------|
| 🔴 1 | **`complemento`** | VARCHAR(100) | Regla 2 no puede comparar complementos entre direcciones | 6 escenarios de R2 inoperantes. Motor de nuevas direcciones no funciona |
| 🔴 2 | **`tipo_via_principal`** | VARCHAR(20) | Regla 3 no puede agrupar direcciones por tipo de vía | R3 completa inoperante |
| 🔴 3 | **`via_principal`** | VARCHAR(100) | Regla 3 no puede identificar la vía | R3 completa inoperante |
| 🔴 4 | **`via_generadora`** | INTEGER | Regla 3 no puede detectar diferencias en vía generadora | Escenario 1 de R3 inoperante |
| 🔴 5 | **`numero_puerta`** | INTEGER | Regla 3 no puede validar diferencia ±2 posiciones | Escenario 2 de R3 inoperante |

**Ejemplo de lo que EDF debe producir:**

```
Entrada (contactasreported):
  "CARRERA 111A NUMERO 148 CON 50 BOGOTA APARTAMENTO 703 TORRE 5"

Salida esperada de estandarización:
  texto_ubicacion:    "KR 111A 148 50"
  complemento:        "TO 5 AP 703"
  tipo_via_principal:  "KR"
  via_principal:       "111A"
  via_generadora:      148
  numero_puerta:       50
  cod_dw_ciudad:       11001000  (DANE Bogotá)
```

---

## 6. Catálogos y Tablas de Parámetros

Estos no vienen de EDF. Se cargan vía Colibrí → Redshift o se crean en `bdm_datos`.

| # | Tabla | Registros | Proceso | Fuente de carga |
|---|-------|:---------:|---------|----------------|
| T01 | `nomenclatura` | 89 | Unificación R2 | Colibrí o carga manual (estáticos) |
| T02 | `tipo_ubicacion_dir` | ~5 | Unificación R1 | Colibrí |
| T03 | `V_Beta_Ordenamiento_Dir` | 12 | Ordenamiento DIR | Colibrí |
| T04 | `V_Beta_Ordenamiento_Tel` | 11 | Ordenamiento TEL | Colibrí |
| T05 | `V_Beta_Ordenamiento_Cel` | 11 | Ordenamiento CEL | Colibrí |
| T06 | `V_Beta_Ordenamiento_Email` | 13 | Ordenamiento EMA | Colibrí |

---

## 7. Campos Internos (Redshift los crea y gestiona)

Estos campos NO vienen de EDF. Son resultado de los procesos en Redshift.

| # | Campo | Proceso | Tabla destino | Descripción |
|---|-------|---------|---------------|-------------|
| I01 | `ind_unificacion` | Unificación | RELACION_PERSONA_UBICACION | NULL=no procesada, 1=hija |
| I02 | `unifica_atributos` | Unificación | UNIFICACION_DIRECCION | 1=R1/R3, 2=R2 |
| I03 | `fecha_unificacion` | Unificación | UNIFICACION_DIRECCION | CURRENT_DATE |
| I04 | `generada_enriquecida` | Unificación | DIRECCION_FISICA | 1=dirección generada por motor R2 |
| I05 | `lote` | Ambos | Varias | Número de lote batch |
| I06 | `orden_prioridad` | Ordenamiento | RELACION_PERSONA_UBICACION | Ranking (1=mejor) |
| I07 | `orden_prioridad_anterior` | Ordenamiento | RELACION_PERSONA_UBICACION | Ranking ciclo anterior |
| I08 | `fecha_ult_ordenamiento` | Ordenamiento | RELACION_PERSONA_UBICACION | Fecha último ordenamiento |
| I09 | `score` | Ordenamiento | Tabla intermedia | Score regresión logística |

---

## 8. Preguntas Abiertas para Experian / Equipo de Ingesta

### Bloqueantes (sin respuesta no se puede avanzar)

| # | Pregunta | Impacto | Responsable |
|---|----------|---------|-------------|
| P01 | ¿La estandarización en EDF (Curation) va a separar `complemento` como campo independiente? | Sin esto, Regla 2 no funciona | Equipo EDF + Adriana |
| P02 | ¿EDF va a generar desglose de componentes de dirección (`tipo_via`, `via_principal`, `via_generadora`, `numero_puerta`)? | Sin esto, Regla 3 no funciona | Equipo EDF + Adriana |
| P03 | ¿Qué valores tiene `contacttype` (BIGINT) en el XPM? ¿Cuál es el catálogo de decodificación? (RES=?, LAB=?, CRR=?) | Regla 1 depende de distinguir tipo de uso | Molina / John Bueno |
| P04 | ¿`mainisiccode` en XPM equivale al código CIIU colombiano que usa Reconocer? | Regla 1 decide por CIIU | Molina / John Bueno |

### Prioridad media

| # | Pregunta | Impacto | Responsable |
|---|----------|---------|-------------|
| P05 | ¿`citycode` en XPM equivale al código de municipio DANE colombiano? ¿O solo es ciudad? | Define si `cod_dw_municipio` se puede derivar | Molina |
| P06 | ¿`subscriberblockstatus` en `xpm_location` equivale al concepto de BLOQUEO de Teradata? | Define si el flag `bloqueado` ya existe | Molina |
| P07 | ¿Existen `descripcion_gestion_registro` y `descripcion_fuente` en el XPM? ¿Con qué nombre? | Ordenamiento los necesita para scoring | Molina |
| P08 | ¿Existen `cod_area`, `cod_dw_geografia`, `tipo_cuenta`, `es_tipo_lab` en el XPM? | Scoring de TEL y CEL los necesita | Molina |
| P09 | ¿La numeración de surrogate keys debe ser continua con Teradata o puede reiniciar en Redshift? | Define seed de secuencias | Experian |

---

## 9. Diagrama de Flujo de Datos

```
┌─────────────────────────────────────────────────────────────────────┐
│                        EDF (Curation)                                │
│                                                                      │
│  COBOL (ICBDIR) ──► Ingesta ──► Estandarización ──► XPM (JSON)     │
│                                      │                               │
│                                      ▼                               │
│                              Campos que debe producir:               │
│                              • texto_ubicacion (estandarizada)       │
│                              • complemento (SEPARADO)                │
│                              • tipo_via_principal                    │
│                              • via_principal                         │
│                              • via_generadora                        │
│                              • numero_puerta                         │
│                              • cod_dw_ciudad (DANE)                  │
│                              • contacttype (RES/LAB/CRR)             │
│                              • bloqueado (flag)                      │
│                              + todos los campos base de persona      │
└──────────────────────────────────┬──────────────────────────────────┘
                                   │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│                        REDSHIFT                                      │
│                                                                      │
│  ┌─────────────────────┐    ┌──────────────────────────────────┐    │
│  │   UNIFICACIÓN       │    │   ORDENAMIENTO                   │    │
│  │                     │    │                                  │    │
│  │  Consume:           │    │  Consume:                        │    │
│  │  • C01-C22          │    │  • C01-C11, C23-C26              │    │
│  │  • T01-T02          │    │  • T03-T06                       │    │
│  │                     │    │                                  │    │
│  │  Produce:           │    │  Produce:                        │    │
│  │  • I01-I05          │    │  • I05-I09                       │    │
│  │  • ind_unificacion  │──►│  • orden_prioridad               │    │
│  │    (alimenta ORD)   │    │  • score                         │    │
│  └─────────────────────┘    └──────────────────────────────────┘    │
│                                                                      │
│  Catálogos vía Colibrí: nomenclatura, betas, tipo_ubicacion_dir     │
└─────────────────────────────────────────────────────────────────────┘
```

**Orden de ejecución**: Unificación PRIMERO → Ordenamiento DESPUÉS (porque Ordenamiento usa `ind_unificacion` como característica de scoring).

---

*Documento generado: 28 de abril de 2026*
*Fuentes: modelo_datos.md, mapeo_campos_xpm.md, analisis_scripts.md, código migrado en ws-unificacion/ y ws-ordenamiento/*
*Para validación con: Equipo de Ingesta (IDF), Juan Carlos Molina, Adriana, John Bueno*
