# Checklist Sprint 0: Validación de Arquitectura

**Proyecto:** MT-EXP-005-MAP-RECONOCER  
**Duración:** Semana 1-2  
**Objetivo:** Validar todos los supuestos críticos antes de iniciar desarrollo

---

## SECCIÓN 1: INFRAESTRUCTURA Y CONECTIVIDAD

### ☐ 1.1 Conectividad AWS

- [ ] **Verificar acceso a AWS Console**
  - Responsable: Infraestructura
  - Método: Acceder a https://console.aws.amazon.com
  - Criterio de éxito: Acceso exitoso con credenciales
  - Fecha límite: Día 1

- [ ] **Verificar acceso a Redshift Cluster**
  - Responsable: DBA Redshift
  - Método: Conectar con psql/SQL Workbench
  - Criterio de éxito: Conexión exitosa, query simple ejecutada
  - Fecha límite: Día 1

- [ ] **Validar VPN/Direct Connect**
  - Responsable: Network Team
  - Método: Verificar estado de conexión en AWS Console
  - Criterio de éxito: Conexión activa y estable
  - Fecha límite: Día 1

- [ ] **Medir latencia de conexión**
  - Responsable: Network Team
  - Método: Ejecutar ping/traceroute desde Framework Batch a Redshift
  - Criterio de éxito: Latencia < 100ms
  - Fecha límite: Día 2

- [ ] **Validar throughput de conexión**
  - Responsable: Network Team
  - Método: Ejecutar prueba de transferencia de datos
  - Criterio de éxito: Throughput > 10 Mbps
  - Fecha límite: Día 2

---

### ☐ 1.2 Configuración de Redshift

- [ ] **Verificar versión de Redshift**
  - Responsable: DBA Redshift
  - Método: Ejecutar `SELECT version();`
  - Criterio de éxito: Versión >= 1.0.30000
  - Fecha límite: Día 1

- [ ] **Verificar tamaño del cluster**
  - Responsable: DBA Redshift
  - Método: Revisar configuración en AWS Console
  - Criterio de éxito: Tamaño adecuado para volumen estimado
  - Fecha límite: Día 1

- [ ] **Validar espacio disponible**
  - Responsable: DBA Redshift
  - Método: Ejecutar `SELECT * FROM stv_partitions;`
  - Criterio de éxito: Espacio disponible > 50% de capacidad
  - Fecha límite: Día 1

- [ ] **Verificar backups configurados**
  - Responsable: DBA Redshift
  - Método: Revisar configuración de snapshots en AWS Console
  - Criterio de éxito: Backups automáticos habilitados
  - Fecha límite: Día 2

---

## SECCIÓN 2: PERMISOS Y SEGURIDAD

### ☐ 2.1 Permisos de Base de Datos

- [ ] **Crear usuario de desarrollo**
  - Responsable: DBA Redshift
  - Método: Ejecutar `CREATE USER dev_user WITH PASSWORD '...';`
  - Criterio de éxito: Usuario creado exitosamente
  - Fecha límite: Día 1

- [ ] **Asignar permisos CREATE TABLE**
  - Responsable: DBA Redshift
  - Método: Ejecutar `GRANT CREATE ON DATABASE redshift_db TO dev_user;`
  - Criterio de éxito: Permiso asignado
  - Fecha límite: Día 1

- [ ] **Asignar permisos CREATE PROCEDURE**
  - Responsable: DBA Redshift
  - Método: Ejecutar `GRANT CREATE ON SCHEMA public TO dev_user;`
  - Criterio de éxito: Permiso asignado
  - Fecha límite: Día 1

- [ ] **Asignar permisos EXECUTE**
  - Responsable: DBA Redshift
  - Método: Ejecutar `GRANT EXECUTE ON ALL PROCEDURES IN SCHEMA public TO dev_user;`
  - Criterio de éxito: Permiso asignado
  - Fecha límite: Día 1

- [ ] **Validar permisos en cada ambiente**
  - Responsable: DBA Redshift
  - Método: Crear matriz de permisos (Dev/QA/Demo/Prod)
  - Criterio de éxito: Matriz documentada y aprobada
  - Fecha límite: Día 3

---

### ☐ 2.2 Seguridad

- [ ] **Validar encriptación en tránsito**
  - Responsable: Security Team
  - Método: Verificar SSL/TLS en conexión Redshift
  - Criterio de éxito: SSL/TLS habilitado
  - Fecha límite: Día 2

- [ ] **Validar encriptación en reposo**
  - Responsable: Security Team
  - Método: Revisar configuración de KMS en AWS Console
  - Criterio de éxito: KMS habilitado (si requerido)
  - Fecha límite: Día 2

- [ ] **Configurar security groups**
  - Responsable: Network Team
  - Método: Whitelist de IPs de Framework Batch
  - Criterio de éxito: Security group configurado
  - Fecha límite: Día 2

- [ ] **Validar auditoría de accesos**
  - Responsable: Security Team
  - Método: Verificar query logging en Redshift
  - Criterio de éxito: Logging habilitado
  - Fecha límite: Día 3

---

## SECCIÓN 3: DATOS Y GOBIERNO

### ☐ 3.1 Volumen y Características

- [ ] **Estimar volumen de datos**
  - Responsable: Data Owner / XPM Team
  - Método: Analizar datos históricos en DB2
  - Criterio de éxito: Estimación documentada (GB/TB)
  - Fecha límite: Día 5

- [ ] **Validar distribución de datos**
  - Responsable: Data Owner
  - Método: Analizar distribución por tabla
  - Criterio de éxito: Distribución documentada
  - Fecha límite: Día 5

- [ ] **Identificar claves primarias**
  - Responsable: Data Owner
  - Método: Documentar PKs de cada tabla
  - Criterio de éxito: PKs identificadas
  - Fecha límite: Día 5

- [ ] **Identificar relaciones entre tablas**
  - Responsable: Data Owner
  - Método: Documentar FKs y relaciones
  - Criterio de éxito: Relaciones documentadas
  - Fecha límite: Día 5

---

### ☐ 3.2 Gobierno de Datos

- [ ] **Validar integración con Colibra**
  - Responsable: Colibra Team
  - Método: Verificar acceso a API/Export de Colibra
  - Criterio de éxito: Acceso confirmado
  - Fecha límite: Día 5

- [ ] **Documentar esquema de catálogos**
  - Responsable: Colibra Team
  - Método: Exportar esquema de 42 tablas catálogo
  - Criterio de éxito: Esquema documentado
  - Fecha límite: Día 5

- [ ] **Definir política de retención**
  - Responsable: Data Governance
  - Método: Documentar política de retención
  - Criterio de éxito: Política aprobada
  - Fecha límite: Día 5

- [ ] **Definir política de limpieza de temporales**
  - Responsable: Data Governance
  - Método: Documentar cuándo/cómo limpiar tablas temporales
  - Criterio de éxito: Política documentada
  - Fecha límite: Día 5

---

## SECCIÓN 4: RENDIMIENTO Y CAPACIDAD

### ☐ 4.1 Pruebas de Rendimiento

- [ ] **Ejecutar prueba de cargue simple**
  - Responsable: Performance Lead
  - Método: Cargar 1 tabla de prueba a Redshift
  - Criterio de éxito: Cargue exitoso, tiempo documentado
  - Fecha límite: Día 3

- [ ] **Medir tiempo de "relacionalize"**
  - Responsable: XPM Team / Performance Lead
  - Método: Ejecutar proceso con datos de prueba
  - Criterio de éxito: Tiempo documentado, < 60 min
  - Fecha límite: Día 7

- [ ] **Validar rendimiento de queries**
  - Responsable: Performance Lead
  - Método: Ejecutar queries de prueba en Redshift
  - Criterio de éxito: Queries ejecutadas en < 5 seg
  - Fecha límite: Día 7

- [ ] **Identificar cuellos de botella**
  - Responsable: Performance Lead
  - Método: Analizar planes de ejecución
  - Criterio de éxito: Cuellos de botella identificados
  - Fecha límite: Día 7

---

### ☐ 4.2 Capacidad

- [ ] **Validar capacidad de CPU**
  - Responsable: DBA Redshift
  - Método: Monitorear CPU durante pruebas
  - Criterio de éxito: CPU < 80% durante picos
  - Fecha límite: Día 7

- [ ] **Validar capacidad de memoria**
  - Responsable: DBA Redshift
  - Método: Monitorear memoria durante pruebas
  - Criterio de éxito: Memoria < 80% durante picos
  - Fecha límite: Día 7

- [ ] **Validar capacidad de I/O**
  - Responsable: DBA Redshift
  - Método: Monitorear I/O durante pruebas
  - Criterio de éxito: I/O < 80% durante picos
  - Fecha límite: Día 7

- [ ] **Definir tamaño final del cluster**
  - Responsable: DBA Redshift
  - Método: Basado en pruebas, estimar tamaño requerido
  - Criterio de éxito: Tamaño documentado y aprobado
  - Fecha límite: Día 10

---

## SECCIÓN 5: ALCANCE Y REQUISITOS

### ☐ 5.1 Definición de Alcance

- [ ] **Confirmar alcance de SOW**
  - Responsable: Sponsor / Project Manager
  - Método: Revisar SOW y confirmar entregables
  - Criterio de éxito: Alcance confirmado por escrito
  - Fecha límite: Día 1

- [ ] **Definir ambientes de deployment**
  - Responsable: Project Manager
  - Método: Documentar Dev/QA/Demo/Prod
  - Criterio de éxito: Ambientes definidos
  - Fecha límite: Día 2

- [ ] **Definir frecuencia de cargue**
  - Responsable: Product Owner
  - Método: Documentar si es diario, horario, etc.
  - Criterio de éxito: Frecuencia confirmada
  - Fecha límite: Día 2

- [ ] **Definir SLA del pipeline**
  - Responsable: Product Owner / Business
  - Método: Documentar SLA por componente
  - Criterio de éxito: SLA documentado y aprobado
  - Fecha límite: Día 3

---

### ☐ 5.2 Requisitos Funcionales

- [ ] **Documentar requisitos de Unificación**
  - Responsable: Business Analyst
  - Método: Entrevistar stakeholders
  - Criterio de éxito: Requisitos documentados
  - Fecha límite: Día 5

- [ ] **Documentar requisitos de Ordenamiento**
  - Responsable: Business Analyst
  - Método: Entrevistar stakeholders
  - Criterio de éxito: Requisitos documentados
  - Fecha límite: Día 5

- [ ] **Documentar requisitos de Geolocalización**
  - Responsable: Business Analyst
  - Método: Entrevistar stakeholders
  - Criterio de éxito: Requisitos documentados
  - Fecha límite: Día 5

- [ ] **Validar datos de prueba disponibles**
  - Responsable: Data Owner
  - Método: Verificar disponibilidad de datos de prueba
  - Criterio de éxito: Datos de prueba disponibles
  - Fecha límite: Día 7

---

## SECCIÓN 6: DOCUMENTACIÓN Y COMUNICACIÓN

### ☐ 6.1 Documentación

- [ ] **Crear documento de arquitectura**
  - Responsable: Arquitecto
  - Método: Documentar decisiones y diseño
  - Criterio de éxito: Documento completado
  - Fecha límite: Día 10

- [ ] **Crear matriz de decisiones**
  - Responsable: Arquitecto
  - Método: Documentar decisiones y dudas
  - Criterio de éxito: Matriz completada
  - Fecha límite: Día 10

- [ ] **Crear diagrama de arquitectura**
  - Responsable: Arquitecto
  - Método: Crear diagrama visual en DrawIO
  - Criterio de éxito: Diagrama completado
  - Fecha límite: Día 10

- [ ] **Crear especificación de Store Procedures**
  - Responsable: Arquitecto / Lead Developer
  - Método: Documentar cada SP (entrada, salida, lógica)
  - Criterio de éxito: Especificación completada
  - Fecha límite: Día 10

---

### ☐ 6.2 Comunicación

- [ ] **Kickoff meeting con equipo**
  - Responsable: Project Manager
  - Método: Reunión de inicio de proyecto
  - Criterio de éxito: Equipo alineado
  - Fecha límite: Día 1

- [ ] **Presentación de arquitectura a stakeholders**
  - Responsable: Arquitecto
  - Método: Presentación ejecutiva
  - Criterio de éxito: Arquitectura aprobada
  - Fecha límite: Día 10

- [ ] **Comunicar resultados de Sprint 0**
  - Responsable: Project Manager
  - Método: Reporte de validación
  - Criterio de éxito: Reporte completado
  - Fecha límite: Día 10

- [ ] **Obtener aprobación para Sprint 1**
  - Responsable: Sponsor
  - Método: Aprobación formal
  - Criterio de éxito: Aprobación obtenida
  - Fecha límite: Día 10

---

## SECCIÓN 7: RIESGOS Y MITIGACIÓN

### ☐ 7.1 Validación de Riesgos

- [ ] **Validar riesgo: Conectividad no disponible**
  - Responsable: Infraestructura
  - Método: Confirmar conectividad operativa
  - Criterio de éxito: Conectividad confirmada
  - Fecha límite: Día 1
  - Plan B: Implementar VPN (2-4 semanas)

- [ ] **Validar riesgo: Rendimiento insuficiente**
  - Responsable: Performance Lead
  - Método: Ejecutar pruebas de carga
  - Criterio de éxito: Rendimiento aceptable
  - Fecha límite: Día 7
  - Plan B: Aumentar tamaño del cluster

- [ ] **Validar riesgo: Permisos insuficientes**
  - Responsable: DBA Redshift
  - Método: Validar matriz de permisos
  - Criterio de éxito: Permisos confirmados
  - Fecha límite: Día 3
  - Plan B: Solicitar permisos adicionales

- [ ] **Validar riesgo: Volumen de datos no estimado**
  - Responsable: Data Owner
  - Método: Estimar volumen
  - Criterio de éxito: Volumen estimado
  - Fecha límite: Día 5
  - Plan B: Usar estimación conservadora

---

## SECCIÓN 8: DECISIONES PENDIENTES

### ☐ 8.1 Decisiones Críticas

- [ ] **Decidir: Tamaño final del cluster**
  - Responsable: DBA Redshift
  - Basado en: Pruebas de rendimiento
  - Fecha límite: Día 10

- [ ] **Decidir: Estrategia de cargue (Full vs Delta)**
  - Responsable: Arquitecto
  - Basado en: Requisitos de negocio
  - Fecha límite: Día 5

- [ ] **Decidir: Frecuencia de cargue**
  - Responsable: Product Owner
  - Basado en: Requisitos de negocio
  - Fecha límite: Día 2

- [ ] **Decidir: SLA del pipeline**
  - Responsable: Product Owner
  - Basado en: Requisitos de negocio
  - Fecha límite: Día 3

---

## SECCIÓN 9: ENTREGABLES DE SPRINT 0

### ☐ 9.1 Documentos

- [ ] Documento de Arquitectura (ARQUITECTURA_REDSHIFT.md)
- [ ] Resumen Ejecutivo (RESUMEN_EJECUTIVO.md)
- [ ] Matriz de Decisiones y Dudas (MATRIZ_DECISIONES_Y_DUDAS.md)
- [ ] Diagrama de Arquitectura (arquitectura_redshift_mejorada.drawio)
- [ ] Especificación de Store Procedures (por crear)
- [ ] Matriz de Permisos (por crear)
- [ ] Plan de Testing (por crear)

### ☐ 9.2 Validaciones

- [ ] Conectividad AWS confirmada
- [ ] Permisos Redshift asignados
- [ ] Rendimiento validado
- [ ] Volumen de datos estimado
- [ ] SLA definido
- [ ] Alcance confirmado

### ☐ 9.3 Aprobaciones

- [ ] Arquitectura aprobada por Sponsor
- [ ] Permisos aprobados por Security
- [ ] Rendimiento aprobado por Performance Lead
- [ ] Alcance aprobado por Product Owner

---

## SECCIÓN 10: CRITERIOS DE ÉXITO DE SPRINT 0

### ✅ Sprint 0 es EXITOSO si:

1. ✅ **Conectividad**: Conexión a Redshift operativa y latencia < 100ms
2. ✅ **Permisos**: Matriz de permisos definida y asignada
3. ✅ **Rendimiento**: Pruebas de cargue exitosas, tiempo de "relacionalize" < 60 min
4. ✅ **Volumen**: Volumen de datos estimado y cluster dimensionado
5. ✅ **Alcance**: SOW confirmado y SLA definido
6. ✅ **Documentación**: Todos los documentos completados
7. ✅ **Aprobaciones**: Arquitectura aprobada por stakeholders
8. ✅ **Equipo**: Equipo asignado y disponible 100%

### ❌ Sprint 0 FALLA si:

- ❌ No hay conectividad a Redshift
- ❌ Permisos insuficientes y no se pueden asignar
- ❌ Rendimiento < SLA requerido
- ❌ Volumen de datos no estimado
- ❌ Alcance no confirmado
- ❌ Arquitectura no aprobada
- ❌ Equipo no disponible

---

## SECCIÓN 11: PRÓXIMOS PASOS (POST SPRINT 0)

Si Sprint 0 es exitoso:

1. ✅ **Sprint 1-2**: Diseño detallado
   - Especificación completa de 32 SPs
   - Diseño de esquema de tablas
   - Plan de testing

2. ✅ **Sprint 3-4**: Desarrollo
   - Implementar tablas catálogo
   - Implementar tablas temporales
   - Desarrollar SPs de Unificación
   - Desarrollar SPs de Ordenamiento

3. ✅ **Sprint 5**: Testing
   - Pruebas unitarias
   - Pruebas de integración
   - Pruebas de carga
   - Pruebas de seguridad

4. ✅ **Sprint 6**: Go-Live
   - Migración a QA
   - Migración a Producción
   - Monitoreo post-go-live

---

## NOTAS Y OBSERVACIONES

```
[Espacio para notas durante Sprint 0]

Día 1:
- 

Día 2:
- 

Día 3:
- 

Día 4:
- 

Día 5:
- 

Día 6-7:
- 

Día 8-10:
- 
```

---

**Checklist preparado por:** Equipo de Arquitectura  
**Fecha:** Mayo 2026  
**Versión:** 1.0  
**Última actualización:** Mayo 2026

---

## FIRMA DE APROBACIÓN

| Rol | Nombre | Firma | Fecha |
|-----|--------|-------|-------|
| Sponsor | | | |
| Arquitecto | | | |
| Project Manager | | | |
| DBA Redshift | | | |

