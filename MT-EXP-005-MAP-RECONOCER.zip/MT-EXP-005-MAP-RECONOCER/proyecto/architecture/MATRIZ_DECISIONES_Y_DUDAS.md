# Matriz de Decisiones y Dudas Pendientes

**Proyecto:** MT-EXP-005-MAP-RECONOCER  
**Fecha:** Mayo 2026  
**Propósito:** Documentar todas las decisiones tomadas y dudas que requieren resolución

---

## PARTE 1: DECISIONES ARQUITECTÓNICAS TOMADAS

### D1: Plataforma de Data Warehouse

**Decisión:** Usar **Amazon Redshift** como plataforma central

| Aspecto | Detalle |
|--------|---------|
| **Opción Elegida** | Amazon Redshift |
| **Alternativas Evaluadas** | 1. Mantener DB2 on-premise<br>2. Usar S3 + Athena<br>3. Usar Snowflake<br>4. Usar BigQuery |
| **Criterios de Evaluación** | Escalabilidad, Rendimiento, Costo, Integración AWS, Gobierno de Datos |
| **Justificación** | ✅ Escalabilidad horizontal<br>✅ SQL avanzado nativo<br>✅ Integración con Colibra<br>✅ Costo-efectivo para cargas analíticas<br>✅ Soporte para procedimientos almacenados |
| **Riesgos Mitigados** | Limitaciones de escalabilidad on-premise |
| **Impacto** | CRÍTICO - Define toda la arquitectura |
| **Reversibilidad** | Media - Requeriría reescritura de SPs |
| **Aprobado por** | [Por definir] |
| **Fecha Decisión** | Mayo 2026 |

---

### D2: Arquitectura de Capas de Datos

**Decisión:** Separar datos en 4 capas: Catálogo, Temporal, Procesos, Resultado

| Aspecto | Detalle |
|--------|---------|
| **Opción Elegida** | Arquitectura de 4 capas |
| **Alternativas Evaluadas** | 1. Arquitectura monolítica<br>2. Arquitectura de 2 capas (Raw + Refined)<br>3. Data Lake + Data Warehouse |
| **Criterios de Evaluación** | Claridad, Auditoría, Mantenibilidad, Rendimiento |
| **Justificación** | ✅ Separación clara de responsabilidades<br>✅ Facilita auditoría y trazabilidad<br>✅ Permite limpiezas selectivas<br>✅ Gobierno de datos por capa<br>✅ Facilita debugging y troubleshooting |
| **Capas Definidas** | 1. **Catálogo** (42 tablas, datos de referencia)<br>2. **Temporal** (38 tablas, datos intermedios)<br>3. **Procesos** (32 SPs, transformaciones)<br>4. **Resultado** (29 tablas, datos finales) |
| **Impacto** | ALTO - Afecta diseño de esquema |
| **Reversibilidad** | Alta - Fácil de refactorizar |
| **Aprobado por** | [Por definir] |
| **Fecha Decisión** | Mayo 2026 |

---

### D3: Mecanismo de Orquestación

**Decisión:** Usar **Store Procedures** en Redshift para orquestación

| Aspecto | Detalle |
|--------|---------|
| **Opción Elegida** | Store Procedures (32 SPs) |
| **Alternativas Evaluadas** | 1. ETL externo (AWS Glue)<br>2. Lambda + Step Functions<br>3. Airflow/Orchestration Tool<br>4. Scripts SQL directos |
| **Criterios de Evaluación** | Transaccionalidad, Rendimiento, Mantenibilidad, Costo |
| **Justificación** | ✅ Transaccionalidad garantizada<br>✅ Mejor rendimiento para volúmenes grandes<br>✅ Lógica centralizada en BD<br>✅ Facilita versionado y control de cambios<br>✅ Menor latencia (sin network hops) |
| **Distribución** | 11 SPs Unificación + 21 SPs Ordenamiento |
| **Impacto** | ALTO - Afecta desarrollo y testing |
| **Reversibilidad** | Media - Requeriría reescritura en Glue/Lambda |
| **Aprobado por** | [Por definir] |
| **Fecha Decisión** | Mayo 2026 |

---

### D4: Estrategia de Cargue para XPM

**Decisión:** Cargues **Full (días 30 y 11) + Deltas (diarios)**

| Aspecto | Detalle |
|--------|---------|
| **Opción Elegida** | Híbrida: Full + Deltas |
| **Alternativas Evaluadas** | 1. Solo Full Load (mensual)<br>2. Solo Delta Load (diario)<br>3. Full + Deltas (elegida)<br>4. Streaming en tiempo real |
| **Criterios de Evaluación** | Consistencia, Eficiencia, Ventana de procesamiento |
| **Justificación** | ✅ Full (30,11): Garantiza consistencia<br>✅ Deltas (diarios): Eficiencia operativa<br>✅ Merge/Upsert automático<br>✅ Balance entre precisión y rendimiento |
| **Frecuencia** | Full: 2 veces/mes (días 30 y 11)<br>Delta: Diarios (excepto días 30 y 11) |
| **Impacto** | ALTO - Afecta SLA y ventana de procesamiento |
| **Reversibilidad** | Alta - Fácil cambiar a solo Full o solo Delta |
| **Aprobado por** | [Por definir] |
| **Fecha Decisión** | Mayo 2026 |

---

### D5: Integración con Colibra

**Decisión:** Colibra como fuente de **Tablas Catálogo (42 tablas)**

| Aspecto | Detalle |
|--------|---------|
| **Opción Elegida** | Colibra → Redshift (Catálogo) |
| **Alternativas Evaluadas** | 1. Mantener catálogos en DB2<br>2. Crear catálogos manuales en Redshift<br>3. Usar Colibra como fuente única (elegida) |
| **Criterios de Evaluación** | Gobierno de Datos, Centralización, Mantenibilidad |
| **Justificación** | ✅ Gobierno centralizado<br>✅ Única fuente de verdad<br>✅ Auditoría integrada<br>✅ Facilita cambios de clasificaciones |
| **Impacto** | MEDIO - Afecta gobierno de datos |
| **Reversibilidad** | Media - Requeriría cambiar fuente |
| **Aprobado por** | [Por definir] |
| **Fecha Decisión** | Mayo 2026 |

---

### D6: Exclusión de Tablas Temporales de Backups

**Decisión:** Excluir tablas temporales de backups/snapshots (OPCIONAL)

| Aspecto | Detalle |
|--------|---------|
| **Opción Elegida** | Excluir temporales (opcional) |
| **Alternativas Evaluadas** | 1. Incluir en backups<br>2. Excluir (elegida)<br>3. Backup selectivo |
| **Criterios de Evaluación** | Costo, RTO/RPO, Recuperabilidad |
| **Justificación** | ✅ Reduce costo de almacenamiento<br>✅ Datos intermedios, no críticos<br>✅ Pueden regenerarse<br>⚠️ Requiere validar RTO/RPO |
| **Impacto** | BAJO - Afecta costo y recuperación |
| **Reversibilidad** | Alta - Fácil cambiar política |
| **Aprobado por** | [Por definir] |
| **Fecha Decisión** | Mayo 2026 |

---

## PARTE 2: DUDAS CRÍTICAS (DEBEN RESPONDERSE)

### Categoría: INFRAESTRUCTURA Y CONECTIVIDAD

#### DU-001: ¿Existe conexión operativa a AWS/Redshift?

| Aspecto | Detalle |
|--------|---------|
| **Pregunta** | ¿Ya existe una conexión establecida a la cuenta AWS y al cluster Redshift? |
| **Por qué es crítica** | 🔴 **BLOQUEA** el inicio del proyecto |
| **Impacto si NO existe** | No se puede iniciar desarrollo, testing ni deployment |
| **Impacto si SÍ existe** | Acelera Sprint 0 |
| **Quién debe responder** | Infraestructura / AWS Account Owner |
| **Fecha límite** | Semana 1 (AHORA) |
| **Acción si NO** | Crear conexión (VPN/Direct Connect) - Puede tomar 2-4 semanas |
| **Acción si SÍ** | Validar latencia y throughput |
| **Dependencias** | Todas las demás tareas |

---

#### DU-002: ¿Cuál es la latencia de la conexión?

| Aspecto | Detalle |
|--------|---------|
| **Pregunta** | ¿Cuál es la latencia de red entre Framework Batch (on-premise) y Redshift (AWS)? |
| **Por qué es importante** | Afecta rendimiento de cargues y SLA |
| **Impacto esperado** | Latencia < 50ms: Óptimo<br>Latencia 50-100ms: Aceptable<br>Latencia > 100ms: Requiere optimización |
| **Quién debe responder** | Infraestructura / Network Team |
| **Fecha límite** | Semana 1 |
| **Acción** | Ejecutar pruebas de ping/traceroute |
| **Dependencias** | DU-001 |

---

#### DU-003: ¿Existe VPN o Direct Connect?

| Aspecto | Detalle |
|--------|---------|
| **Pregunta** | ¿Existe VPN o AWS Direct Connect configurado? |
| **Por qué es importante** | Afecta seguridad, latencia y confiabilidad |
| **Opciones** | 1. VPN (más rápido de implementar)<br>2. Direct Connect (mejor rendimiento)<br>3. Ambas (redundancia) |
| **Quién debe responder** | Infraestructura / Network Team |
| **Fecha límite** | Semana 1 |
| **Acción si NO existe** | Implementar VPN (1-2 semanas) o Direct Connect (4-6 semanas) |
| **Dependencias** | DU-001 |

---

### Categoría: PERMISOS Y SEGURIDAD

#### DU-004: ¿Cuáles son los permisos requeridos en Redshift?

| Aspecto | Detalle |
|--------|---------|
| **Pregunta** | ¿Cuáles son los permisos específicos requeridos para crear tablas, SPs y ejecutar cargues en cada ambiente (Dev/QA/Demo/Prod)? |
| **Por qué es importante** | 🔴 **BLOQUEA** desarrollo si no se tienen permisos |
| **Permisos Necesarios** | • CREATE TABLE<br>• CREATE PROCEDURE<br>• EXECUTE<br>• INSERT/UPDATE/DELETE<br>• DROP TABLE (para limpiezas)<br>• TRUNCATE |
| **Quién debe responder** | DBA Redshift / Security Team |
| **Fecha límite** | Semana 1 |
| **Acción** | Crear matriz de permisos por rol y ambiente |
| **Dependencias** | DU-001 |

---

#### DU-005: ¿Quién administra los permisos en Redshift?

| Aspecto | Detalle |
|--------|---------|
| **Pregunta** | ¿Quién es el propietario/administrador de permisos en Redshift? |
| **Por qué es importante** | Define modelo de acceso y governance |
| **Opciones** | 1. DBA Redshift<br>2. Security Team<br>3. Cloud Governance Team<br>4. Combinación |
| **Quién debe responder** | Governance / Security Lead |
| **Fecha límite** | Semana 1 |
| **Acción** | Definir RACI de permisos |
| **Dependencias** | DU-004 |

---

#### DU-006: ¿Se requiere encriptación en tránsito y en reposo?

| Aspecto | Detalle |
|--------|---------|
| **Pregunta** | ¿Existen requisitos de encriptación para datos en tránsito (SSL/TLS) y en reposo (KMS)? |
| **Por qué es importante** | Afecta configuración de Redshift y costo |
| **Impacto** | Encriptación en tránsito: Mínimo impacto<br>Encriptación en reposo: Requiere KMS (costo adicional) |
| **Quién debe responder** | Security / Compliance Team |
| **Fecha límite** | Semana 1 |
| **Acción** | Validar requisitos de compliance |
| **Dependencias** | Ninguna |

---

#### DU-007: ¿Existen restricciones de IP o firewall?

| Aspecto | Detalle |
|--------|---------|
| **Pregunta** | ¿Existen restricciones de IP o firewall que afecten la conectividad desde Framework Batch a Redshift? |
| **Por qué es importante** | Afecta conectividad y requiere configuración de security groups |
| **Quién debe responder** | Network / Security Team |
| **Fecha límite** | Semana 1 |
| **Acción** | Whitelist de IPs de Framework Batch |
| **Dependencias** | DU-001 |

---

### Categoría: DATOS Y GOBIERNO

#### DU-008: ¿Cuál es el volumen de datos esperado?

| Aspecto | Detalle |
|--------|---------|
| **Pregunta** | ¿Cuál es el volumen estimado de datos (GB/TB) para las 29 tablas resultado? |
| **Por qué es importante** | 🔴 **CRÍTICO** - Define tamaño del cluster Redshift |
| **Impacto** | Volumen < 100GB: dc2.large (2-4 nodos)<br>Volumen 100GB-1TB: dc2.xlarge (4-8 nodos)<br>Volumen > 1TB: dc2.8xlarge (8+ nodos) |
| **Quién debe responder** | Data Owner / XPM Team |
| **Fecha límite** | Semana 2 |
| **Acción** | Estimar basado en datos históricos |
| **Dependencias** | Ninguna |

---

#### DU-009: ¿Cuál es la frecuencia de cargue?

| Aspecto | Detalle |
|--------|---------|
| **Pregunta** | ¿Cuál es la frecuencia esperada de cargues (diaria, horaria, en tiempo real)? |
| **Por qué es importante** | Afecta ventana de procesamiento y SLA |
| **Opciones** | 1. Diaria (actual propuesta)<br>2. Horaria<br>3. Tiempo real (streaming)<br>4. Semanal |
| **Quién debe responder** | Product Owner / Business Analyst |
| **Fecha límite** | Semana 1 |
| **Acción** | Definir SLA de actualización |
| **Dependencias** | Ninguna |

---

#### DU-010: ¿El esquema de tablas catálogo es fijo?

| Aspecto | Detalle |
|--------|---------|
| **Pregunta** | ¿El esquema de las 42 tablas catálogo es fijo o evoluciona frecuentemente? |
| **Por qué es importante** | Afecta estrategia de versionado y cambios |
| **Impacto** | Fijo: Simplifica desarrollo<br>Evoluciona: Requiere versionado y migration scripts |
| **Quién debe responder** | Colibra Team / Governance |
| **Fecha límite** | Semana 2 |
| **Acción** | Documentar política de cambios |
| **Dependencias** | Ninguna |

---

#### DU-011: ¿Cómo se integra Colibra con Redshift?

| Aspecto | Detalle |
|--------|---------|
| **Pregunta** | ¿Cuál es el proceso de sincronización de Colibra a Redshift? ¿API, Export, Replicación? |
| **Por qué es importante** | Define arquitectura de ingesta de catálogos |
| **Opciones** | 1. API de Colibra<br>2. Export CSV/Parquet<br>3. Replicación nativa<br>4. Manual |
| **Quién debe responder** | Colibra Team / Integration Lead |
| **Fecha límite** | Semana 2 |
| **Acción** | Diseñar proceso de sincronización |
| **Dependencias** | DU-010 |

---

#### DU-012: ¿Existe política de retención de datos?

| Aspecto | Detalle |
|--------|---------|
| **Pregunta** | ¿Existe política de retención de datos? ¿Cuánto tiempo se mantienen los datos históricos? |
| **Por qué es importante** | Afecta limpieza de tablas temporales y costo |
| **Opciones** | 1. Retención indefinida<br>2. Retención de 12 meses<br>3. Retención de 3 meses<br>4. Retención de 30 días |
| **Quién debe responder** | Data Governance / Compliance |
| **Fecha límite** | Semana 2 |
| **Acción** | Definir política de retención |
| **Dependencias** | Ninguna |

---

#### DU-013: ¿Las tablas temporales se excluyen de backups?

| Aspecto | Detalle |
|--------|---------|
| **Pregunta** | ¿Se deben excluir las 38 tablas temporales de backups/snapshots? |
| **Por qué es importante** | Afecta costo de almacenamiento y RTO/RPO |
| **Impacto** | Excluir: Reduce costo ~30%<br>Incluir: Mejor recuperabilidad |
| **Quién debe responder** | DBA / Disaster Recovery Lead |
| **Fecha límite** | Semana 2 |
| **Acción** | Validar RTO/RPO requerido |
| **Dependencias** | Ninguna |

---

### Categoría: RENDIMIENTO Y CAPACIDAD

#### DU-014: ¿Cuánto tarda el "relacionalize" (XPM)?

| Aspecto | Detalle |
|--------|---------|
| **Pregunta** | 🔴 **CRÍTICO** - ¿Cuánto tiempo tarda el proceso de "relacionalize" de XPM? |
| **Por qué es importante** | **BLOQUEA** definición de SLA de todo el pipeline |
| **Impacto** | < 10 min: Óptimo<br>10-30 min: Aceptable<br>30-60 min: Requiere optimización<br>> 60 min: Requiere rediseño |
| **Quién debe responder** | XPM Team / Performance Lead |
| **Fecha límite** | Semana 2 |
| **Acción** | Ejecutar pruebas de carga con datos reales |
| **Dependencias** | DU-008 |

---

#### DU-015: ¿Se requiere procesamiento en paralelo?

| Aspecto | Detalle |
|--------|---------|
| **Pregunta** | ¿Se requiere ejecutar múltiples SPs en paralelo o secuencial? |
| **Por qué es importante** | Afecta arquitectura de orquestación |
| **Opciones** | 1. Secuencial (actual propuesta)<br>2. Paralelo (algunos SPs)<br>3. Paralelo (todos) |
| **Quién debe responder** | Arquitecto / Performance Lead |
| **Fecha límite** | Semana 3 |
| **Acción** | Analizar dependencias entre SPs |
| **Dependencias** | DU-014 |

---

#### DU-016: ¿Cuál es el SLA esperado?

| Aspecto | Detalle |
|--------|---------|
| **Pregunta** | ¿Cuál es el SLA esperado para el pipeline completo (Ingesta → Resultado)? |
| **Por qué es importante** | Define requisitos de rendimiento y disponibilidad |
| **Opciones** | 1. < 2 horas (diario)<br>2. < 4 horas (diario)<br>3. < 8 horas (diario)<br>4. < 24 horas (diario) |
| **Quién debe responder** | Product Owner / Business |
| **Fecha límite** | Semana 1 |
| **Acción** | Definir SLA por componente |
| **Dependencias** | DU-009, DU-014 |

---

### Categoría: ALCANCE Y FASES

#### DU-017: ¿Cuál es el alcance de la SOW?

| Aspecto | Detalle |
|--------|---------|
| **Pregunta** | ¿Cuál es el alcance exacto de la SOW respecto a cargue de datos en DEMO? |
| **Por qué es importante** | Define entregables y timeline |
| **Opciones** | 1. Solo desarrollo en Dev<br>2. Dev + QA<br>3. Dev + QA + Demo<br>4. Dev + QA + Demo + Prod |
| **Quién debe responder** | Sponsor / Project Manager |
| **Fecha límite** | Semana 1 |
| **Acción** | Revisar SOW y confirmar alcance |
| **Dependencias** | Ninguna |

---

#### DU-018: ¿Se incluye migración histórica?

| Aspecto | Detalle |
|--------|---------|
| **Pregunta** | ¿Se requiere migrar datos históricos de DB2 a Redshift? |
| **Por qué es importante** | Afecta timeline y esfuerzo |
| **Opciones** | 1. Solo datos nuevos (forward-looking)<br>2. Últimos 12 meses<br>3. Últimos 3 años<br>4. Todos los datos históricos |
| **Quién debe responder** | Product Owner / Business |
| **Fecha límite** | Semana 1 |
| **Acción** | Definir ventana histórica |
| **Dependencias** | DU-017 |

---

#### DU-019: ¿Cuál es el plan de cutover?

| Aspecto | Detalle |
|--------|---------|
| **Pregunta** | ¿Cuál es el plan de cutover: Big Bang o Gradual? |
| **Por qué es importante** | Afecta riesgo y validación |
| **Opciones** | 1. Big Bang (todo de una vez)<br>2. Gradual (por fases)<br>3. Paralelo (ambos sistemas) |
| **Quién debe responder** | Project Manager / Sponsor |
| **Fecha límite** | Semana 3 |
| **Acción** | Definir estrategia de cutover |
| **Dependencias** | DU-017, DU-018 |

---

## PARTE 3: MATRIZ DE IMPACTO

### Impacto de Dudas Críticas en Timeline

| Duda | Impacto | Delay si NO se resuelve | Prioridad |
|------|--------|------------------------|-----------|
| DU-001: Conectividad AWS | CRÍTICO | 2-4 semanas | 🔴 P0 |
| DU-014: Tiempo "Relacionalize" | CRÍTICO | 1-2 semanas | 🔴 P0 |
| DU-008: Volumen de datos | CRÍTICO | 1 semana | 🔴 P0 |
| DU-004: Permisos Redshift | CRÍTICO | 1 semana | 🔴 P0 |
| DU-009: Frecuencia de cargue | ALTO | 3-5 días | 🟠 P1 |
| DU-016: SLA esperado | ALTO | 3-5 días | 🟠 P1 |
| DU-017: Alcance SOW | ALTO | 3-5 días | 🟠 P1 |
| DU-010: Esquema catálogo fijo | MEDIO | 2-3 días | 🟡 P2 |
| DU-011: Integración Colibra | MEDIO | 2-3 días | 🟡 P2 |

---

## PARTE 4: PLAN DE RESOLUCIÓN

### Sprint 0: Validación (Semana 1-2)

**Objetivo:** Resolver todas las dudas críticas (P0)

| Duda | Acción | Responsable | Fecha |
|------|--------|-------------|-------|
| DU-001 | Validar conectividad AWS/Redshift | Infraestructura | Semana 1 |
| DU-002 | Medir latencia de conexión | Network Team | Semana 1 |
| DU-003 | Confirmar VPN/Direct Connect | Infraestructura | Semana 1 |
| DU-004 | Crear matriz de permisos | DBA Redshift | Semana 1 |
| DU-005 | Definir RACI de permisos | Governance | Semana 1 |
| DU-006 | Validar requisitos de encriptación | Security | Semana 1 |
| DU-007 | Configurar firewall/security groups | Network | Semana 1 |
| DU-008 | Estimar volumen de datos | Data Owner | Semana 2 |
| DU-009 | Definir frecuencia de cargue | Product Owner | Semana 1 |
| DU-014 | Ejecutar pruebas de rendimiento | Performance Lead | Semana 2 |
| DU-016 | Definir SLA | Product Owner | Semana 1 |
| DU-017 | Confirmar alcance SOW | Sponsor | Semana 1 |

---

## PARTE 5: TEMPLATE PARA NUEVAS DECISIONES

Cuando se tomen nuevas decisiones durante el proyecto, usar este template:

```markdown
### D[N]: [Título de la Decisión]

**Decisión:** [Opción elegida]

| Aspecto | Detalle |
|--------|---------|
| **Opción Elegida** | [Opción] |
| **Alternativas Evaluadas** | [Lista de alternativas] |
| **Criterios de Evaluación** | [Criterios usados] |
| **Justificación** | [Por qué se eligió] |
| **Impacto** | [Impacto en proyecto] |
| **Reversibilidad** | [Fácil/Media/Difícil de cambiar] |
| **Aprobado por** | [Quién aprobó] |
| **Fecha Decisión** | [Fecha] |
```

---

## PARTE 6: TEMPLATE PARA NUEVAS DUDAS

Cuando surjan nuevas dudas, usar este template:

```markdown
#### DU-[NNN]: [Pregunta?]

| Aspecto | Detalle |
|--------|---------|
| **Pregunta** | [Pregunta clara] |
| **Por qué es importante** | [Justificación] |
| **Impacto esperado** | [Qué pasa si no se resuelve] |
| **Quién debe responder** | [Rol/Equipo] |
| **Fecha límite** | [Cuándo se necesita] |
| **Acción** | [Qué hacer para resolver] |
| **Dependencias** | [Otras dudas/decisiones] |
```

---

## RESUMEN EJECUTIVO

### Decisiones Tomadas: 6
- ✅ Plataforma: Redshift
- ✅ Arquitectura: 4 capas
- ✅ Orquestación: Store Procedures
- ✅ Cargue XPM: Full + Deltas
- ✅ Catálogos: Colibra
- ✅ Backups: Excluir temporales (opcional)

### Dudas Críticas (P0): 4
- 🔴 DU-001: Conectividad AWS
- 🔴 DU-014: Rendimiento "Relacionalize"
- 🔴 DU-008: Volumen de datos
- 🔴 DU-004: Permisos Redshift

### Dudas Altas (P1): 3
- 🟠 DU-009: Frecuencia de cargue
- 🟠 DU-016: SLA esperado
- 🟠 DU-017: Alcance SOW

### Próximo Paso
**Ejecutar Sprint 0 (Semana 1-2) para resolver todas las dudas críticas**

---

**Documento preparado por:** Equipo de Arquitectura  
**Última actualización:** Mayo 2026  
**Próxima revisión:** Fin de Sprint 0
