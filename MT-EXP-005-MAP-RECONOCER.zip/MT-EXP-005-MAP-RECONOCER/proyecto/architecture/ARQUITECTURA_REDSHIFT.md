# Documento de Arquitectura - Solución Reconocer en Amazon Redshift

**Versión:** 1.0  
**Fecha:** Mayo 2026  
**Estado:** Propuesta en Revisión  
**Proyecto:** MT-EXP-005-MAP-RECONOCER

---

## 1. Visión General

La solución Reconocer propone migrar el procesamiento de datos de geolocalización y normalización de direcciones desde un ambiente on-premise (DB2) a **Amazon Redshift**, aprovechando la escalabilidad y capacidades analíticas de la nube.

### Objetivo Principal
Consolidar múltiples fuentes de datos (Framework Batch, Bizzagi, XPM) en un data warehouse centralizado que ejecute procesos de unificación, ordenamiento y enriquecimiento geográfico de manera eficiente y escalable.

---

## 2. Arquitectura Propuesta

### 2.1 Componentes Principales

```
┌─────────────────────────────────────────────────────────────────┐
│                    FUENTES DE DATOS                             │
├─────────────────────────────────────────────────────────────────┤
│  • Framework Batch (Orquestación)                               │
│  • Bizzagi (Procesos de Negocio)                                │
│  • XPM (Datos Relacionalizados - 29 tablas, 235 columnas)       │
│  • Colibra (Gobierno de Datos - 42 tablas catálogo)            │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│              AMAZON REDSHIFT (Data Warehouse)                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ TABLAS CATÁLOGO (Gobierno de Datos)                      │  │
│  │ • 42 tablas de referencia                                │  │
│  │ • Dimensiones y clasificaciones                          │  │
│  │ • Fuente: Colibra                                        │  │
│  └──────────────────────────────────────────────────────────┘  │
│                              ↓                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ TABLAS TEMPORALES (Staging)                              │  │
│  │ • 38 tablas internas                                     │  │
│  │ • Datos intermedios de procesamiento                     │  │
│  │ • Ciclo de vida: Cargue → Procesamiento → Limpieza      │  │
│  └──────────────────────────────────────────────────────────┘  │
│                              ↓                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ PROCESOS DE TRANSFORMACIÓN                               │  │
│  │                                                          │  │
│  │  1. UNIFICACIÓN (11 Store Procedures)                    │  │
│  │     └─ Consolidación de múltiples fuentes               │  │
│  │     └─ Aplicación de reglas de negocio                  │  │
│  │     └─ Validación de integridad                         │  │
│  │                                                          │  │
│  │  2. ORDENAMIENTO (21 Store Procedures)                   │  │
│  │     └─ Clasificación y jerarquización                   │  │
│  │     └─ Indicadores de movilidad                         │  │
│  │     └─ Nomenclatura normalizada                         │  │
│  │                                                          │  │
│  │  3. ENRIQUECIMIENTO GEOGRÁFICO                           │  │
│  │     └─ Geolocalización (coordenadas)                    │  │
│  │     └─ Distancias y proximidades                        │  │
│  │     └─ Puntos de interés                                │  │
│  └──────────────────────────────────────────────────────────┘  │
│                              ↓                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ RESULTADO FINAL (Relacionalizado - XPM)                  │  │
│  │ • 29 tablas                                              │  │
│  │ • 235 columnas                                           │  │
│  │ • Cargues: Full (días 30 y 11) + Deltas (diarios)       │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                    CONSUMIDORES                                 │
│  • Aplicaciones de Negocio                                      │
│  • Reportes y Análisis                                          │
│  • Inteligencia de Negocio                                      │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 Flujo de Datos

**Fase 1: Ingesta**
- Framework Batch invoca los procesos de cargue
- Datos se cargan desde DB2 a tablas temporales en Redshift
- Validación inicial de esquema y completitud

**Fase 2: Unificación**
- 11 Store Procedures consolidan datos de múltiples fuentes
- Aplicación de reglas de negocio y transformaciones
- Generación de tablas intermedias

**Fase 3: Ordenamiento**
- 21 Store Procedures clasifican y jerarquizan datos
- Cálculo de indicadores de movilidad
- Normalización de nomenclatura

**Fase 4: Enriquecimiento**
- Geolocalización de direcciones
- Cálculo de distancias y proximidades
- Asociación con puntos de interés

**Fase 5: Publicación**
- Resultado final en 29 tablas relacionalizadas
- Disponible para consumo por aplicaciones

---

## 3. Decisiones Arquitectónicas

### 3.1 Decisión: Usar Amazon Redshift como Data Warehouse Central

**Justificación:**
- Escalabilidad horizontal para volúmenes crecientes
- Capacidades analíticas nativas (SQL avanzado)
- Integración con ecosistema AWS
- Costo-efectividad para cargas analíticas

**Alternativas Consideradas:**
- ❌ Mantener en DB2 on-premise: Limitaciones de escalabilidad
- ❌ Usar S3 + Athena: Menos eficiente para procesamiento iterativo
- ✅ **Redshift**: Balance óptimo entre rendimiento y costo

### 3.2 Decisión: Separación de Tablas por Capas

**Justificación:**
- **Catálogo (Azul)**: Datos de referencia estables, gobierno centralizado
- **Temporales (Amarillo)**: Datos intermedios, ciclo de vida controlado
- **Resultado (Azul)**: Datos finales, optimizados para consumo

**Beneficios:**
- Claridad en responsabilidades
- Facilita auditoría y trazabilidad
- Permite limpiezas selectivas sin afectar datos finales

### 3.3 Decisión: Store Procedures para Orquestación

**Justificación:**
- Lógica de negocio centralizada en la base de datos
- Transaccionalidad garantizada
- Mejor rendimiento que ETL externo para volúmenes grandes
- Facilita mantenimiento y versionado

**Consideraciones:**
- 11 SPs para Unificación
- 21 SPs para Ordenamiento
- Total: 32 procedimientos almacenados

### 3.4 Decisión: Cargues Full + Deltas para XPM

**Justificación:**
- **Full (días 30 y 11)**: Recarga completa para garantizar consistencia
- **Deltas (diarios)**: Cambios incrementales para eficiencia

**Impacto:**
- Reduce tiempo de procesamiento en días normales
- Garantiza sincronización periódica
- Requiere lógica de merge/upsert

---

## 4. Dudas y Preguntas Críticas

### 4.1 Infraestructura y Conectividad

| Pregunta | Impacto | Prioridad |
|----------|--------|-----------|
| ¿Cuál es la volatilidad del ambiente (Dev/QA/Demo/Prod)? | Afecta estrategia de permisos y ciclo de vida | 🟠 P1 |
| ¿Existe VPN/Direct Connect configurado? | Impacta latencia y seguridad | 🟠 P1 |

### 4.2 Permisos y Seguridad

| Pregunta | Impacto | Prioridad |
|----------|--------|-----------|
| ¿Cuáles son los permisos requeridos para ejecutar pruebas en Redshift de forma óptima (cargue de datos, creación de tablas temporales, ejecución de SPs, generación de archivos para unificación y ordenamiento)? | **CRÍTICO** - Define capacidad de validación y testing del equipo | 🔴 P0 |
| ¿Cuáles son los permisos requeridos para crear tablas temporales en cada ambiente? | Afecta automatización y governance | 🟠 P1 |
| ¿Quién administra los permisos en Redshift? | Define modelo de acceso | 🟠 P1 |
| ¿Existen restricciones de IP o firewall? | Afecta conectividad desde Framework Batch | 🟠 P1 |

### 4.3 Datos y Gobierno

| Pregunta | Impacto | Prioridad |
|----------|--------|-----------|
| ¿El esquema de tablas catálogo es fijo o evoluciona? | Afecta estrategia de versionado | 🟠 P1 |
| ¿Cómo se integra Colibra con Redshift? | Define proceso de sincronización | 🟠 P1 |
| ¿Las tablas temporales se excluyen de backups/snapshots? | Impacta RTO/RPO | 🟡 P2 |
| ¿Existe política de retención de datos? | Afecta limpieza de tablas temporales | 🟡 P2 |

### 4.4 Rendimiento y Capacidad

| Pregunta | Impacto | Prioridad |
|----------|--------|-----------|
| ¿Cuánto tiempo tarda el "relacionalize" (XPM)? | **CRÍTICO** - Afecta SLA de todo el pipeline | 🔴 P0 |
| ¿Cuál es el volumen de datos esperado (GB/TB)? | Define tamaño del cluster Redshift | 🔴 P0 |
| ¿Cuál es la frecuencia de cargue (diaria/horaria)? | Afecta ventana de procesamiento | 🔴 P0 |
| ¿Se requiere procesamiento en paralelo? | Impacta arquitectura de SPs | 🟠 P1 |

### 4.5 Alcance y Fases

| Pregunta | Impacto | Prioridad |
|----------|--------|-----------|
| ¿Cuál es el alcance de la SOW respecto a cargue de datos en DEMO? | Define entregables | 🟠 P1 |
| ¿Se incluye migración histórica de datos? | Afecta timeline | 🟠 P1 |
| ¿Cuál es el plan de cutover (Big Bang vs. Gradual)? | Impacta riesgo y validación | 🟠 P1 |

---

## 5. Impactos Potenciales

### 5.1 Impacto en Rendimiento

**Riesgo: Tiempo de Procesamiento**
- El "relacionalize" puede ser cuello de botella
- Impacta directamente en SLA de Unificación y Ordenamiento
- Puede sobrecargar recursos del cluster

**Mitigación:**
- ✅ Ejecutar pruebas de carga y stress en QA
- ✅ Optimizar índices y distribución de datos
- ✅ Considerar paralelización de SPs
- ✅ Monitorear métricas de CPU/memoria

### 5.2 Impacto en Costos

**Riesgo: Escalada de Costos AWS**
- Cluster Redshift requiere tamaño adecuado
- Cargues frecuentes incrementan I/O
- Almacenamiento de 38 tablas temporales

**Mitigación:**
- ✅ Right-sizing del cluster basado en pruebas
- ✅ Política de limpieza agresiva de temporales
- ✅ Usar Redshift Spectrum para datos fríos
- ✅ Monitoreo de costos con AWS Cost Explorer

### 5.3 Impacto en Disponibilidad

**Riesgo: Ventana de Mantenimiento**
- Recarga full los días 30 y 11 puede afectar disponibilidad
- Procesos largos pueden bloquear consumidores

**Mitigación:**
- ✅ Ejecutar full loads en ventana de bajo uso
- ✅ Usar tablas de staging para no afectar consumo
- ✅ Implementar rollback automático en caso de error
- ✅ Comunicar ventanas de mantenimiento

### 5.4 Impacto en Seguridad

**Riesgo: Exposición de Datos**
- Datos sensibles en tablas temporales
- Acceso desde múltiples fuentes (Framework, Bizzagi, XPM)

**Mitigación:**
- ✅ Implementar row-level security (RLS)
- ✅ Encriptación de datos en reposo
- ✅ Auditoría de accesos
- ✅ Limpieza segura de temporales

### 5.5 Impacto en Mantenibilidad

**Riesgo: Complejidad de 32 Store Procedures**
- Difícil de mantener y debuggear
- Cambios en lógica requieren coordinación

**Mitigación:**
- ✅ Documentación exhaustiva de cada SP
- ✅ Versionado en Git
- ✅ Testing unitario de SPs
- ✅ Logs detallados de ejecución

---

## 6. Matriz de Riesgos

| Riesgo | Probabilidad | Impacto | Severidad | Mitigación |
|--------|-------------|--------|-----------|-----------|
| Conexión AWS no disponible | Media | Crítico | 🔴 CRÍTICO | Validar conectividad en Sprint 0 |
| Rendimiento insuficiente | Alta | Alto | 🔴 CRÍTICO | Pruebas de carga exhaustivas |
| Permisos insuficientes | Media | Alto | 🟠 ALTO | Definir matriz de permisos temprano |
| Crecimiento de datos no previsto | Media | Medio | 🟡 MEDIO | Monitoreo y escalado automático |
| Falta de documentación | Baja | Medio | 🟡 MEDIO | Documentar durante desarrollo |

---

## 7. Próximos Pasos

### Fase 0: Validación (Semana 1-2)
- [ ] Confirmar conectividad AWS/Redshift
- [ ] Validar permisos en todos los ambientes
- [ ] Definir matriz de seguridad
- [ ] Estimar volumen de datos

### Fase 1: Diseño Detallado (Semana 3-4)
- [ ] Diseñar esquema de tablas en Redshift
- [ ] Especificar 32 Store Procedures
- [ ] Definir estrategia de cargue (Full + Deltas)
- [ ] Crear plan de testing

### Fase 2: Desarrollo (Semana 5-8)
- [ ] Implementar tablas catálogo
- [ ] Implementar tablas temporales
- [ ] Desarrollar SPs de Unificación
- [ ] Desarrollar SPs de Ordenamiento

### Fase 3: Testing (Semana 9-10)
- [ ] Pruebas unitarias de SPs
- [ ] Pruebas de carga y stress
- [ ] Validación de datos
- [ ] Testing de seguridad

### Fase 4: Deployment (Semana 11-12)
- [ ] Migración a QA
- [ ] Validación en QA
- [ ] Migración a Producción
- [ ] Monitoreo post-go-live

---

## 8. Métricas de Éxito

| Métrica | Target | Umbral de Alerta |
|---------|--------|------------------|
| Tiempo de Unificación | < 30 min | > 45 min |
| Tiempo de Ordenamiento | < 20 min | > 30 min |
| Tiempo de Geolocalización | < 15 min | > 25 min |
| Disponibilidad del Pipeline | > 99% | < 95% |
| Costo mensual AWS | < $X | > $X * 1.2 |
| Tasa de error en cargues | < 0.1% | > 1% |

---

## 9. Referencias y Anexos

### Documentos Relacionados
- `reconocer arquitectura propuesta.drawio` - Diagrama visual
- `AGENTS.md` - Documentación de agentes
- Especificaciones de Store Procedures (por definir)

### Contactos Clave
- Arquitecto de Solución: [Por definir]
- DBA Redshift: [Por definir]
- Product Owner: [Por definir]

---

**Documento preparado por:** Equipo de Arquitectura  
**Última actualización:** Mayo 2026  
**Próxima revisión:** Después de Sprint 0 (Validación)
