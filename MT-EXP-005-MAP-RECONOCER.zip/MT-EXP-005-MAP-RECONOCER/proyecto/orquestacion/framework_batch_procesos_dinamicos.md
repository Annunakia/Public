# Framework Batch de Procesos Dinámicos — Documentación Técnica

> **Fecha**: 5 de mayo de 2026 | **Autor**: Francisco Peña | **Macondotek**
> **Fuente**: Videollamada con Oscar Fajardo (Explicación funcionamiento framework procesos batch_v1.vtt)
> **Objetivo**: Documentar el framework de orquestación batch que reemplaza a Control-M. Este es el destino al que debemos migrar los procesos de Unificación y Ordenamiento.

---

## 1. Resumen del Framework

### ¿Qué es?

Un **orquestador dinámico de stored procedures en Redshift**, construido por Oscar Fajardo (Macondotek) para Experian. Reemplaza a Control-M como motor de ejecución de procesos batch.

### Analogía de Oscar

> "Redshift es la caja de Legos. Los stored procedures son los legos. El archivo YAML de definición del proceso son las instrucciones para armar un carrito, un castillo, una casa, un avión. El framework es quien lee las instrucciones y arma las piezas."

### Características principales

- **Dinámico**: No hay Step Functions fijas por proceso. Se generan y destruyen por ejecución.
- **Declarativo**: Los procesos se definen en YAML, no en código.
- **Paralelo por nivel**: Dentro de cada nivel, los pasos se ejecutan en paralelo. Los niveles son secuenciales.
- **Genérico**: El mismo framework sirve para cualquier proceso batch (Reconocer, Cobol, etc.)
- **Infraestructura como código**: Todo desplegado con Terraform.

---

## 2. Diagrama de Arquitectura

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                    FRAMEWORK BATCH — PROCESOS DINÁMICOS                           │
│                    (Reemplazo de Control-M)                                       │
└─────────────────────────────────────────────────────────────────────────────────┘

                    ┌──────────────────────────────┐
                    │  S3: Dynamic Batch Source     │
                    │  Repository                   │
                    │  (archivos de entrada:        │
                    │   .val, .par, .inc, etc.)     │
                    └──────────────┬───────────────┘
                                   │ S3 Event (archivo .val cae)
                                   ▼
                    ┌──────────────────────────────┐
                    │         SQS Queue            │
                    │  (encola evento de archivo)   │
                    └──────────────┬───────────────┘
                                   │
                                   ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  Lambda: INITIATOR                                                               │
│  • Detecta que cayó un archivo .val                                              │
│  • Identifica el proceso asociado                                                │
│  • Dispara la Step Function Principal                                            │
└──────────────────────────────────┬──────────────────────────────────────────────┘
                                   │
                                   ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  STEP FUNCTION PRINCIPAL (fija, siempre la misma)                                │
│                                                                                   │
│  ┌─────────────────────────────────────────────────────────────────────────┐     │
│  │ 1. Notificación de inicio (email)                                        │     │
│  └──────────────────────────────────┬──────────────────────────────────────┘     │
│                                      │                                            │
│  ┌─────────────────────────────────────────────────────────────────────────┐     │
│  │ 2. Lambda: SOURCE VALIDATOR                                              │     │
│  │    • Lee el YAML de definición del proceso (S3: Definition Repository)   │     │
│  │    • Verifica archivos obligatorios en la ruta del proceso               │     │
│  │    • Valida extensiones requeridas (.val, .par, etc.)                    │     │
│  │    • Valida fecha de los archivos                                        │     │
│  │    • Registra resultado en DynamoDB                                      │     │
│  │    • Si falla → para el proceso                                          │     │
│  └──────────────────────────────────┬──────────────────────────────────────┘     │
│                                      │                                            │
│  ┌─────────────────────────────────────────────────────────────────────────┐     │
│  │ 3. Lambda: BUILDER (Step Function Definition Builder)                    │     │
│  │    • Lee el YAML de definición                                           │     │
│  │    • Transforma niveles y pasos en JSON ASL (Amazon States Language)     │     │
│  │    • Genera una Step Function DINÁMICA con:                              │     │
│  │      - Invocación de SPs vía integración nativa Redshift Data API        │     │
│  │      - Verificación de ejecución exitosa (describe statement)            │     │
│  │      - Logs por paso                                                     │     │
│  │    • Registra la Step Function dinámica en AWS                           │     │
│  └──────────────────────────────────┬──────────────────────────────────────┘     │
│                                      │                                            │
│  ┌─────────────────────────────────────────────────────────────────────────┐     │
│  │ 4. Lambda: LAUNCHER                                                      │     │
│  │    • Toma el nombre de la Step Function dinámica creada                  │     │
│  │    • La ejecuta                                                          │     │
│  └──────────────────────────────────┬──────────────────────────────────────┘     │
│                                      │                                            │
│                                      ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────────────┐     │
│  │ STEP FUNCTION DINÁMICA (efímera, generada por el Builder)                │     │
│  │                                                                           │     │
│  │  ┌─────────────────────────────────────────────────────────────┐         │     │
│  │  │ NIVEL 1 (pasos en PARALELO)                                  │         │     │
│  │  │  ┌────────┐  ┌────────┐  ┌────────┐                         │         │     │
│  │  │  │  SP 1  │  │  SP 2  │  │  SP 3  │  ← ejecutan en paralelo│         │     │
│  │  │  └───┬────┘  └───┬────┘  └───┬────┘                         │         │     │
│  │  │      └────────────┼──────────┘                               │         │     │
│  │  │                   │ (convergencia — espera que todos terminen)│         │     │
│  │  └───────────────────┼─────────────────────────────────────────┘         │     │
│  │                      │                                                    │     │
│  │  ┌───────────────────┼─────────────────────────────────────────┐         │     │
│  │  │ NIVEL 2 (secuencial respecto al nivel 1)                     │         │     │
│  │  │  ┌────────┐  ┌────────┐                                     │         │     │
│  │  │  │  SP 4  │  │  SP 5  │  ← paralelo dentro del nivel        │         │     │
│  │  │  └───┬────┘  └───┬────┘                                     │         │     │
│  │  │      └────────────┘                                          │         │     │
│  │  └──────────────────────────────────────────────────────────────┘         │     │
│  │                      │                                                    │     │
│  │  ┌───────────────────┼─────────────────────────────────────────┐         │     │
│  │  │ NIVEL N ...                                                  │         │     │
│  │  └──────────────────────────────────────────────────────────────┘         │     │
│  │                      │                                                    │     │
│  │  Paso final: notifica "terminé" al disparador                             │     │
│  └──────────────────────────────────┬──────────────────────────────────────┘     │
│                                      │                                            │
│  ┌─────────────────────────────────────────────────────────────────────────┐     │
│  │ 5. DESTRUCCIÓN de Step Function dinámica                                 │     │
│  │    • Si OK → destruye la SF dinámica (no persiste)                       │     │
│  │    • Si ERROR → la deja para debugging                                   │     │
│  └──────────────────────────────────┬──────────────────────────────────────┘     │
│                                      │                                            │
│  ┌─────────────────────────────────────────────────────────────────────────┐     │
│  │ 6. Glue Job de SALIDAS (si aplica=true en YAML)                          │     │
│  │    • Lee carpetas de output en S3 (merge_temp/<proceso>/)                │     │
│  │    • Unifica archivos en uno solo con formato definido (.dat, .csv, etc.)│     │
│  │    • Aplica expresiones regulares para identificar carpetas              │     │
│  └─────────────────────────────────────────────────────────────────────────┘     │
│                                                                                   │
└─────────────────────────────────────────────────────────────────────────────────┘

                    ┌──────────────────────────────┐
                    │  REDSHIFT                     │
                    │  • 1 cluster                  │
                    │  • 1 base de datos            │
                    │  • 1 usuario (user_sp)        │
                    │  • N stored procedures        │
                    │  • Integración nativa con     │
                    │    Step Functions (Data API)   │
                    └──────────────────────────────┘

                    ┌──────────────────────────────┐
                    │  DynamoDB                     │
                    │  • Tabla de logs (ejecuciones)│
                    │  • Tabla de nemotécnicos      │
                    │    (NIT → nombre empresa)     │
                    └──────────────────────────────┘

                    ┌──────────────────────────────┐
                    │  S3: Dynamic Batch Definition │
                    │  Repository                   │
                    │  • Archivos YAML por proceso  │
                    │  • Nemotécnicos               │
                    └──────────────────────────────┘
```

---

## 3. Estructura del YAML de Definición de Proceso

Cada proceso batch se define en un archivo YAML con esta estructura:

```yaml
# Ejemplo: PP_0989_CALCULO_DEUDAS.yaml
directorio: PP_0989_CALCULO_DEUDAS     # Ruta en S3 donde buscar fuentes

niveles:
  nivel_1:
    descripcion: "Crear tablas y cargar datos"
    procedimientos:
      - step_name: "carga_parametros"
        step_procedure: "schema.sp_carga_parametros"
        step_description: "Carga archivos .par en tablas"
      - step_name: "carga_validos"
        step_procedure: "schema.sp_carga_validos"
        step_description: "Carga archivos .val en tablas"
      - step_name: "carga_inconsistentes"
        step_procedure: "schema.sp_carga_inconsistentes"
        step_description: "Carga archivos .inc en tablas"

  nivel_2:
    descripcion: "Procesamiento principal"
    procedimientos:
      - step_name: "calculo_principal"
        step_procedure: "schema.sp_pp0989_calculo"
        step_description: "Ejecuta cálculo de deudas"

  nivel_3:
    descripcion: "Exportación de resultados"
    procedimientos:
      - step_name: "exportar_resultados"
        step_procedure: "schema.sp_exportar_resultados"
        step_description: "Genera archivos de salida en S3"

archivos:
  directorio: "/ruta/en/bucket/fuentes/"
  obligatorios:
    - ".val"       # Sin archivo .val, el proceso NO arranca
    - ".par"       # Sin archivo .par, el proceso NO arranca

salidas:
  aplica: true                    # true = ejecuta Glue Job de unificación de salidas
  chunks:                         # Expresiones regulares para identificar carpetas de output
    - "PP_0989"                   # Chunk 1: nombre del proceso
    - "out_1"                     # Chunk 2: subcarpeta de salida
  formato: ".dat"                 # Extensión del archivo unificado
  cabecera: true                  # Si el archivo tiene header
```

### Campos del YAML

| Campo | Tipo | Obligatorio | Descripción |
|-------|------|:-----------:|-------------|
| `directorio` | string | ✅ | Nombre de la carpeta en S3 donde están las fuentes. Debe coincidir con la carpeta real en el bucket |
| `niveles` | object | ✅ | Diccionario de niveles (nivel_1, nivel_2, ...). Se ejecutan secuencialmente |
| `niveles.nivel_N.descripcion` | string | ❌ | Descripción del nivel |
| `niveles.nivel_N.procedimientos` | array | ✅ | Lista de pasos. Se ejecutan en PARALELO dentro del nivel |
| `procedimientos[].step_name` | string | ✅ | Nombre del paso (identificador) |
| `procedimientos[].step_procedure` | string | ✅ | `schema.nombre_stored_procedure` a invocar en Redshift |
| `procedimientos[].step_description` | string | ❌ | Descripción de qué hace el paso |
| `archivos` | object | ❌ | Definición de archivos obligatorios |
| `archivos.directorio` | string | ✅ | Ruta en el bucket de fuentes |
| `archivos.obligatorios` | array | ✅ | Extensiones requeridas para que el proceso arranque |
| `salidas` | object | ❌ | Configuración de post-procesamiento de salidas |
| `salidas.aplica` | boolean | ✅ | Si es `true`, ejecuta Glue Job de unificación |
| `salidas.chunks` | array | ✅ | Expresiones regulares para identificar carpetas de output |
| `salidas.formato` | string | ✅ | Extensión del archivo unificado (.dat, .csv, .txt) |
| `salidas.cabecera` | boolean | ✅ | Si el archivo de salida tiene header |

---

## 4. Reglas de Ejecución

### Paralelismo y secuencialidad

```
NIVEL 1:  [SP_A, SP_B, SP_C]  → Los 3 arrancan AL MISMO TIEMPO
          ────────────────────── convergencia (espera que los 3 terminen)
NIVEL 2:  [SP_D]               → Arranca DESPUÉS de que Nivel 1 termine
          ────────────────────── convergencia
NIVEL 3:  [SP_E, SP_F]        → Los 2 arrancan al mismo tiempo
          ────────────────────── convergencia
```

### Firma de los Stored Procedures

Todos los SPs invocados por el framework **comparten la misma firma**. Oscar lo mencionó pero no detalló los parámetros exactos. Lo que sabemos:

- Se invocan vía integración nativa Step Functions ↔ Redshift Data API
- Cada paso invoca **un solo SP** en **un solo cluster**
- El SP debe existir en la base de datos y el usuario `user_sp` debe tener privilegios de ejecución

**⚠️ Pendiente confirmar**: ¿Cuál es la firma exacta? ¿Recibe parámetros (lote, fecha, proceso)? ¿O es sin parámetros?

### Ciclo de vida de la Step Function dinámica

1. **Creación**: Lambda Builder genera el JSON ASL y registra la SF en AWS
2. **Ejecución**: Lambda Launcher la ejecuta
3. **Destrucción**: Si termina OK → se destruye. Si termina con ERROR → persiste para debugging
4. **Persistencia**: Solo persisten la SF Principal y la información en DynamoDB (logs)

### Integración con Redshift

```json
// Patrón de invocación de SP dentro de la Step Function dinámica
{
  "Type": "Task",
  "Resource": "arn:aws:states:::redshift-data:executeStatement.sync",
  "Parameters": {
    "ClusterIdentifier": "<cluster>",
    "Database": "<database>",
    "DbUser": "user_sp",
    "Sql": "CALL schema.nombre_stored_procedure()"
  }
}
```

Después de cada invocación hay un paso invisible de **verificación** (describe statement) que confirma que el SP se ejecutó correctamente.

---

## 5. Infraestructura

### Componentes AWS

| Componente | Función | Provisión |
|-----------|---------|-----------|
| S3 (Definition Repository) | Almacena YAMLs de definición de procesos + nemotécnicos | Terraform |
| S3 (Source Repository) | Almacena archivos de entrada (.val, .par, .inc) | Terraform |
| S3 (Output / merge_temp) | Almacena salidas de los SPs antes de unificación | Terraform |
| SQS | Cola de eventos cuando cae un archivo en Source Repository | Terraform |
| Lambda (Initiator) | Detecta archivo, dispara SF Principal | Terraform + Python 3.12 |
| Lambda (Source Validator) | Valida archivos obligatorios | Terraform + Python 3.12 |
| Lambda (Builder) | Genera SF dinámica desde YAML | Terraform + Python 3.12 |
| Lambda (Launcher) | Ejecuta SF dinámica | Terraform + Python 3.12 |
| Step Function (Principal) | Orquesta el flujo fijo (validar → construir → lanzar → destruir) | Terraform (JSON inline) |
| Step Function (Dinámica) | Ejecuta los SPs del proceso específico | Generada en runtime por Builder |
| DynamoDB (Logs) | Registra resultado de cada ejecución | Terraform |
| DynamoDB (Nemotécnicos) | Mapeo nemotécnico → NIT + nombre empresa | Terraform |
| Glue Job | Unifica archivos de salida | Terraform |
| Redshift | Ejecuta los stored procedures | Existente (no lo crea el framework) |

### Estructura del repositorio (Terraform)

```
proyecto-batch/
├── ambientes/
│   ├── develop/        ← backend + tfvars para dev
│   ├── qa/             ← backend + tfvars para QA
│   ├── demo/           ← backend + tfvars para demo
│   └── produccion/     ← backend + tfvars para prod
├── modules/
│   └── step-functions-macondo/   ← Módulo Terraform del framework
├── scripts/
│   └── install_layer_dependencies.ps1  ← Empaqueta layers Lambda
├── src/
│   ├── lambdas/
│   │   ├── dynamic_batch_initiator/
│   │   ├── dynamic_batch_source_validator/
│   │   ├── dynamic_batch_builder/
│   │   └── dynamic_batch_launcher/
│   ├── layers/
│   │   └── requirements.txt    ← Dependencias Python (pydantic, etc.)
│   └── templates/              ← Templates de Step Functions (JSON)
├── procesos/
│   ├── nemotecnicos/           ← DynamoDB: mapeo nemotécnico → empresa
│   └── PP_XXXX_NOMBRE/         ← YAML de definición por proceso
├── docs/
│   ├── componentes/
│   ├── flujos/
│   ├── funciones_lambda/
│   ├── mensajes_sqs_eventbridge/
│   ├── glue_jobs/
│   ├── step_functions/
│   └── storages/
└── trunk/
    └── step-functions/         ← Terraform del módulo (SF Principal + recursos)
```

### Restricciones de infraestructura

| Restricción | Detalle | Impacto |
|-------------|---------|---------|
| 1 cluster Redshift | El framework está amarrado a un solo cluster | No se puede distribuir carga entre clusters |
| 1 base de datos | Todos los SPs deben estar en la misma BD | Naming conventions importantes |
| 1 usuario (`user_sp`) | Todas las invocaciones usan el mismo usuario | El usuario debe tener EXECUTE en todos los SPs |
| Python 3.12 | Lambdas usan Python 3.12, Jenkins tiene 3.9 | Layers se empaquetan localmente (workaround) |
| Políticas KMS/S3 | Riesgo de drift con Terraform si no se definen correctamente | Punto de fallo conocido |

---

## 6. Mapeo: Control-M Reconocer → Framework Batch

### Propuesta de YAML para Unificación + Ordenamiento

```yaml
# PP_RECONOCER_UNIFICACION_ORDENAMIENTO.yaml
directorio: PP_RECONOCER_UNIFICACION_ORDENAMIENTO

niveles:
  nivel_1:
    descripcion: "Unificación Regla 1 — Por tipo de uso + CIIU"
    procedimientos:
      - step_name: "regla1_unificacion"
        step_procedure: "bdm_datos.sp_regla1_unificacion"
        step_description: "Unifica direcciones con misma puerta y diferente tipo de uso"

  nivel_2:
    descripcion: "Unificación Regla 2 — Por complementos (6 escenarios + motor)"
    procedimientos:
      - step_name: "regla2_esc1_2"
        step_procedure: "bdm_datos.sp_regla2_esc1_2"
        step_description: "Escenarios 1 (vacío) y 2 (incluido)"
      - step_name: "regla2_esc4"
        step_procedure: "bdm_datos.sp_regla2_esc4"
        step_description: "Escenario 4: nomenclaturas diferentes, mismo nivel"

  nivel_3:
    descripcion: "Unificación Regla 2 — Escenarios con motor de nuevas direcciones"
    procedimientos:
      - step_name: "regla2_esc3_sin_nit"
        step_procedure: "bdm_datos.sp_regla2_esc3_sin_nit"
        step_description: "Escenario 3 sin NIT"
      - step_name: "regla2_esc3_nit"
        step_procedure: "bdm_datos.sp_regla2_esc3_nit"
        step_description: "Escenario 3 NIT — genera nuevas direcciones"
      - step_name: "regla2_esc5"
        step_procedure: "bdm_datos.sp_regla2_esc5"
        step_description: "Escenario 5: nomenclaturas diferente nivel"
      - step_name: "regla2_esc6"
        step_procedure: "bdm_datos.sp_regla2_esc6"
        step_description: "Escenario 6: ninguna contenida en otra"

  nivel_4:
    descripcion: "Unificación Regla 3 — Por geolocalización"
    procedimientos:
      - step_name: "regla3_geo"
        step_procedure: "bdm_datos.sp_regla3_geo"
        step_description: "Unifica por lat/long + diccionario de vía"

  nivel_5:
    descripcion: "Scoring de contactabilidad (4 canales en paralelo)"
    procedimientos:
      - step_name: "scoring_dir"
        step_procedure: "bdm_datos.sp_scoring_dir"
        step_description: "Score de direcciones (12 características)"
      - step_name: "scoring_tel"
        step_procedure: "bdm_datos.sp_scoring_tel"
        step_description: "Score de teléfonos fijos (11 características)"
      - step_name: "scoring_cel"
        step_procedure: "bdm_datos.sp_scoring_cel"
        step_description: "Score de celulares (11 características)"
      - step_name: "scoring_ema"
        step_procedure: "bdm_datos.sp_scoring_ema"
        step_description: "Score de emails (13 características)"

  nivel_6:
    descripcion: "Consolidación y persistencia del ordenamiento"
    procedimientos:
      - step_name: "consolidacion_persistencia"
        step_procedure: "bdm_datos.sp_consolidacion_persistencia"
        step_description: "Consolida scores y actualiza RELACION_PERSONA_UBICACION"

  nivel_7:
    descripcion: "Indicadores de movilidad"
    procedimientos:
      - step_name: "indicadores_movilidad"
        step_procedure: "bdm_datos.sp_indicadores_movilidad"
        step_description: "Calcula cambios de dirección, frecuencia, patrones"

archivos:
  directorio: "/reconocer/produccion/entradas/"
  obligatorios: []    # Reconocer no depende de archivos de entrada (datos vienen de EDF)

salidas:
  aplica: false       # Reconocer no genera archivos de salida en este punto

```

### Visualización de la ejecución propuesta

```
NIVEL 1:  [regla1_unificacion]                    ← 1 SP, secuencial
          ─────────────────────────────────────────
NIVEL 2:  [regla2_esc1_2] [regla2_esc4]           ← 2 SPs en PARALELO
          ─────────────────────────────────────────
NIVEL 3:  [esc3_sin_nit] [esc3_nit] [esc5] [esc6] ← 4 SPs en PARALELO
          ─────────────────────────────────────────
NIVEL 4:  [regla3_geo]                            ← 1 SP, secuencial
          ─────────────────────────────────────────
NIVEL 5:  [scoring_dir] [scoring_tel] [scoring_cel] [scoring_ema]  ← 4 PARALELO
          ─────────────────────────────────────────
NIVEL 6:  [consolidacion_persistencia]            ← 1 SP, secuencial
          ─────────────────────────────────────────
NIVEL 7:  [indicadores_movilidad]                 ← 1 SP, secuencial
```

### Comparación Control-M vs Framework Batch

| Aspecto | Control-M (actual) | Framework Batch (destino) |
|---------|:------------------:|:-------------------------:|
| Jobs totales | 14 (7 unif + 7 ord) | 7 niveles, 14 SPs |
| Ejecución scoring | Secuencial (1 cursor) | **Paralelo** (4 SPs simultáneos) |
| Ejecución Regla 2 | Secuencial (3 jobs) | **Parcialmente paralelo** (niveles 2 y 3) |
| Manejo de errores | Email manual | SF persiste + CloudWatch + DynamoDB |
| Trigger | Cíclico semanal (sábado 06:30) | Evento S3 o EventBridge schedule |
| Visibilidad | Solo consola Control-M (prod) | Consola AWS + logs + DynamoDB |
| Deploy | Manual (shells) | Terraform + Jenkins |
| Costo | Licencia Control-M | Pay-per-transition (~$0.025/1000) |

### Decisiones de diseño del YAML

| Decisión | Razón |
|----------|-------|
| Regla 1 sola en Nivel 1 | Es prerequisito de todo lo demás (marca hijos que no deben procesarse) |
| Regla 2 dividida en 2 niveles | Esc 1-2 y Esc 4 no generan nuevas direcciones (paralelo). Esc 3/5/6 sí generan (paralelo entre ellos, pero después de 1-2/4) |
| Regla 3 sola en Nivel 4 | Depende de que Regla 2 termine (cascada) |
| Scoring en paralelo (Nivel 5) | Los 4 canales son independientes entre sí — mejora vs Control-M que era secuencial |
| Consolidación después de scoring | Necesita que los 4 canales terminen |
| Movilidad al final | Es independiente del scoring pero se ejecuta después por convención |

---

## 7. Restricciones y Riesgos (advertidos por Oscar)

| # | Restricción / Riesgo | Detalle | Mitigación |
|---|---------------------|---------|-----------|
| 1 | **Usuario `user_sp` sin privilegios** | Si el usuario no tiene EXECUTE sobre un SP → falla silenciosa | Verificar permisos antes de deploy. Script de validación |
| 2 | **SP no existe en la BD** | Si el YAML referencia un SP que no fue creado → falla | Checklist de pre-deploy: validar existencia de todos los SPs |
| 3 | **Drift de Terraform con políticas KMS/S3** | Las políticas de bucket pueden sobreescribirse entre módulo Experian y definiciones custom | Definir políticas en el bucket_policy del módulo, no después |
| 4 | **Documentación desactualizada** | Oscar advirtió que los docs del repo pueden tener inconsistencias | Usar el código como fuente de verdad, no los docs |
| 5 | **Procesos no versionados** | Los YAMLs de procesos reales no están en el repo (solo los de prueba) | Versionar nuestro YAML en el repo desde el inicio |
| 6 | **Performance depende de Redshift** | El framework solo orquesta — la velocidad depende de los SPs | Optimizar SPs (DISTKEY, SORTKEY, ANALYZE) |
| 7 | **Un solo cluster** | No se puede distribuir carga entre clusters | Aceptar restricción. Escalar verticalmente si es necesario |
| 8 | **Layers de Lambda empaquetados manualmente** | Jenkins tiene Python 3.9, Lambdas usan 3.12 → incompatibilidad de pydantic | Usar script `install_layer_dependencies.ps1` para empaquetar |

---

## 8. Preguntas Pendientes para Oscar / Experian

| # | Pregunta | Impacto | Prioridad |
|---|----------|---------|:---------:|
| 1 | **¿Cuál es la firma exacta de los SPs?** ¿Reciben parámetros (lote, fecha)? ¿O son sin parámetros? | Define cómo escribir nuestros SPs | 🔴 Alta |
| 2 | **¿El framework ya está desplegado en el ambiente de Reconocer?** ¿O hay que desplegarlo? | Define si podemos probar ya o hay trabajo previo | 🔴 Alta |
| 3 | **¿Dónde está el bucket de Definition Repository para Reconocer?** ¿Ya existe o hay que crearlo? | Define dónde subir nuestro YAML | 🟡 Media |
| 4 | **¿El usuario `user_sp` ya tiene permisos sobre `bdm_datos`?** | Si no, hay que solicitarlos | 🟡 Media |
| 5 | **¿Cómo se dispara el proceso de Reconocer?** ¿Evento S3 (archivo .val) o schedule (EventBridge)? | Define el trigger | 🟡 Media |
| 6 | **¿Los SPs de Reconocer deben escribir salidas en S3 (merge_temp)?** ¿O solo actualizan tablas? | Define si necesitamos bloque `salidas` en el YAML | 🟢 Baja |
| 7 | **¿Hay un ambiente de pruebas del framework donde podamos validar nuestro YAML?** | Permite probar sin afectar producción | 🟡 Media |
| 8 | **¿El Glue Job de unificación de salidas aplica para Reconocer?** | Define si `salidas.aplica` es true o false | 🟢 Baja |

---

## 9. Lo que debemos hacer para migrar al Framework

### Checklist de preparación

```
□ STORED PROCEDURES
  □ Convertir scripts SQL actuales (ws-unificacion/src/redshift/sql/) en SPs de Redshift
  □ Definir firma estándar (confirmar con Oscar)
  □ Crear SPs en schema bdm_datos
  □ Otorgar EXECUTE a user_sp sobre cada SP
  □ Validar ejecución individual de cada SP en sandbox

□ YAML DE DEFINICIÓN
  □ Crear PP_RECONOCER_UNIFICACION_ORDENAMIENTO.yaml
  □ Definir niveles y pasos según propuesta (§6)
  □ Subir al bucket de Definition Repository

□ INFRAESTRUCTURA
  □ Confirmar que el framework está desplegado en el ambiente de Reconocer
  □ Confirmar bucket de Source Repository
  □ Confirmar permisos de user_sp
  □ Confirmar acceso a DynamoDB de logs

□ PRUEBAS
  □ Ejecutar proceso completo en ambiente de pruebas
  □ Verificar paralelismo de scoring (4 canales)
  □ Verificar manejo de errores (forzar fallo de un SP)
  □ Verificar logs en DynamoDB
  □ Verificar destrucción de SF dinámica post-ejecución

□ DEPLOY
  □ Versionar YAML en repo Azure DevOps
  □ Configurar trigger (EventBridge schedule semanal o evento S3)
  □ Validar en QA antes de producción
```

### Trabajo técnico requerido

| Tarea | Esfuerzo estimado | Dependencia |
|-------|:-----------------:|-------------|
| Convertir 10 scripts SQL de Unificación en SPs | 4-8 horas | Confirmar firma de SPs |
| Convertir 6 scripts SQL de Ordenamiento en SPs | 2-4 horas | Confirmar firma de SPs |
| Crear YAML de definición | 1-2 horas | Ninguna (propuesta ya lista) |
| Validar permisos y accesos | 1-2 horas | Oscar / Experian |
| Pruebas end-to-end en framework | 4-8 horas | Todo lo anterior |

---

*Documento generado: 5 de mayo de 2026*
*Fuente: Videollamada Oscar Fajardo + análisis de Control_M.xml + código migrado en ws-unificacion/ y ws-ordenamiento/*
