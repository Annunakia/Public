# Orquestación Control-M → Step Functions: Unificación + Ordenamiento

> **Fecha**: 5 de mayo de 2026 | **Autor**: Francisco Peña | **Macondotek**
> **Fuente**: `Control_M.xml` (exportado 21/04/2026 desde CTM_PROD)
> **Objetivo**: Documentar la malla de orquestación actual (Control-M) para los procesos de Unificación y Ordenamiento, y mapear su equivalente en AWS Step Functions.

---

## 1. Diagrama de Flujo — Control-M actual

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                         MALLA RECONOCER — CONTROL-M (PRODUCCIÓN)                     │
│                         Ejecución semanal | Inicio: DM-START_WEEK (sábado 06:30)     │
└─────────────────────────────────────────────────────────────────────────────────────┘

    ┌──────────────────────────────────────────────────────────────────────────────┐
    │  PRECONDICIONES (vienen de Estandarización — fuera de nuestro alcance)       │
    │                                                                               │
    │  EST_CU2.2_CARGA_FINAL_CONTACTIBILIDAD ──┐                                   │
    │  EST_CU23_FECHA_REPORTE ─────────────────┼──► disparan Unificación           │
    │  EST_CU4_CARGUE_MODELO ──────────────────┘                                   │
    │  GEO_CU5_GEOREFERENCIACION ──────────────────► también dispara Regla 1       │
    └──────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                              UNIFICACIÓN (7 jobs, secuencial)                         │
│                                                                                       │
│  ┌─────────────────────────────────────────────────────────────────────────────┐     │
│  │ PASO 1: REGLA 1                                                              │     │
│  │ Job: UNI_CU3.4.1_CARGUE_REGLA_1                                             │     │
│  │ Script: P0019_UNIFICACION                                                    │     │
│  │ Función: Unifica por tipo de uso + CIIU (misma puerta, ≠ tipo uso)           │     │
│  └──────────────────────────────────────┬──────────────────────────────────────┘     │
│                                          │                                            │
│                                          ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────────────────┐     │
│  │ PASO 2: REGLA 2 — Carga Insumos                                              │     │
│  │ Job: UNI_CU3.4.2_CARGUE_REGLA_2                                             │     │
│  │ Script: P0020_CARGA_INSUMO_UNI_REG2                                          │     │
│  │ Función: Prepara datos de entrada para Regla 2                                │     │
│  └──────────────────────────────────────┬──────────────────────────────────────┘     │
│                                          │                                            │
│                                          ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────────────────┐     │
│  │ PASO 3: REGLA 2 — Crear Diccionario Nomenclaturas                            │     │
│  │ Job: UNI_CU3.4.2_CARGUE_NOMENCLATURAS                                       │     │
│  │ Script: P0020_CreaDicNomenclaturaReg2                                         │     │
│  │ Función: Construye diccionario de frecuencias de complementos                 │     │
│  └──────────────────────────────────────┬──────────────────────────────────────┘     │
│                                          │                                            │
│                                          ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────────────────┐     │
│  │ PASO 4: REGLA 2 — Ejecutar Unificación de Direcciones                        │     │
│  │ Job: UNI_CU3.4.2_CARGUE_FINAL_MODELO                                        │     │
│  │ Script: P0020_UNIFICACION_DIRECCION                                           │     │
│  │ Función: Ejecuta 6 escenarios + motor de nuevas direcciones                   │     │
│  └──────────────────────────────────────┬──────────────────────────────────────┘     │
│                                          │                                            │
│                                          ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────────────────┐     │
│  │ PASO 5: REGLA 3                                                              │     │
│  │ Job: UNI_CU3.4.3_CARGUE_REGLA_3                                             │     │
│  │ Script: P0021_UNIFICACION                                                    │     │
│  │ Función: Unifica por geolocalización (lat/long + diccionario vía)             │     │
│  └──────────────────────────────────────┬──────────────────────────────────────┘     │
│                                          │                                            │
│                                          ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────────────────┐     │
│  │ PASO 6: FECHA REPORTE                                                        │     │
│  │ Job: UNI_CU23_FECHA_REPORTE                                                  │     │
│  │ Script: P0023_RECONOCER_FECHA_REPORTE                                         │     │
│  │ Función: Actualiza fechas de reporte post-unificación                         │     │
│  │ ✉ OK → Email "TERMINA MALLA RECONOCER MASTER"                                │     │
│  │ ✉ OK → Dispara ORDENAMIENTO                                                  │     │
│  └──────────────────────────────────────┬──────────────────────────────────────┘     │
│                                          │                                            │
└──────────────────────────────────────────┼──────────────────────────────────────────┘
                                           │
                    Condición: UNI_CU23_FECHA_REPORTE → ORD_CU24.2_CARGA_ATRIBUTOS
                                           │
                                           ▼
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                              ORDENAMIENTO (7 jobs, secuencial)                        │
│                                                                                       │
│  ┌─────────────────────────────────────────────────────────────────────────────┐     │
│  │ PASO 1: PRE-PROCESAMIENTO (12 SPs en paralelo/secuencial)                    │     │
│  │ Job: ORD_CU24.2_CARGA_ATRIBUTOS                                             │     │
│  │ Script: ORDENAMIENTO_242                                                      │     │
│  │ Función: Ejecuta 12 SPs PRO_ORD_* que materializan y preparan datos           │     │
│  │ ⚠️ SPs NO LOCALIZADOS en dump — bloqueante                                   │     │
│  └──────────────────────────────────────┬──────────────────────────────────────┘     │
│                                          │                                            │
│                                          ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────────────────┐     │
│  │ PASO 2: CARGA CARACTERÍSTICAS                                                │     │
│  │ Job: ORD_CU24.3_CARGA_CARACTERISTICAS                                       │     │
│  │ Script: BTEQ_Caracteristicas_estandar                                         │     │
│  │ Función: Carga tabla CARACTERISTICA con sentencias SQL de scoring             │     │
│  └──────────────────────────────────────┬──────────────────────────────────────┘     │
│                                          │                                            │
│                                          ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────────────────┐     │
│  │ PASO 3: EJECUCIÓN SCORING (cursor dinámico)                                   │     │
│  │ Job: ORD_CU24.3_EJECUCION_ORDENAMIENTO                                      │     │
│  │ Script: BTEQ_CURSOR                                                           │     │
│  │ Función: Lee sentencias SQL de CARACTERISTICA y las ejecuta dinámicamente     │     │
│  │          Genera tablas: Orden_Direcc, Orden_TelF, Orden_TM, Orden_Email       │     │
│  │ ✅ YA MIGRADO en PoC → 02_scoring_dir + 03_tel + 04_cel + 05_ema             │     │
│  └──────────────────────────────────────┬──────────────────────────────────────┘     │
│                                          │                                            │
│                                          ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────────────────┐     │
│  │ PASO 4: APLICAR ORDENAMIENTO (persistencia)                                   │     │
│  │ Job: ORD_CU27_APLICAR_ORDENAMIENTO                                           │     │
│  │ Script: P0027_UBI_ORDENAMIENTO                                                │     │
│  │ Función: Consolida scores y UPDATE RELACION_PERSONA_UBICACION                 │     │
│  │ ✅ YA MIGRADO en PoC → 06_consolidacion_persistencia.sql (incompleto)        │     │
│  └──────────────────────────────────────┬──────────────────────────────────────┘     │
│                                          │                                            │
│                                          ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────────────────┐     │
│  │ PASO 5: PREPARACIÓN DATOS MOVILIDAD                                           │     │
│  │ Job: ORD_CU29_PREPARACION_DATOS                                              │     │
│  │ Script: P0029_PRO_IndicadorMovilidad                                          │     │
│  │ Función: Prepara datos para cálculo de indicadores de movilidad               │     │
│  │ ❌ NO MIGRADO                                                                 │     │
│  └──────────────────────────────────────┬──────────────────────────────────────┘     │
│                                          │                                            │
│                                          ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────────────────┐     │
│  │ PASO 6: INDICADORES DE MOVILIDAD                                              │     │
│  │ Job: ORD_CU29_INDICADORES_MOVILIDAD                                          │     │
│  │ Script: P0029_INDICADORES_MOVILIDAD                                           │     │
│  │ Función: Calcula cambios de dirección, frecuencia, patrones                   │     │
│  │ ✉ OK → Email "La Malla de Ordenamiento ha finalizado Correctamente"          │     │
│  │ ❌ NO MIGRADO                                                                 │     │
│  └─────────────────────────────────────────────────────────────────────────────┘     │
│                                                                                       │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Inventario de Jobs — Detalle

### UNIFICACIÓN (7 jobs)

| # | Job Control-M | Script que ejecuta | Función | Estado migración | Equivalente Redshift |
|---|:---|:---|:---|:---:|:---|
| 1 | `UNI_CU3.4.1_CARGUE_REGLA_1` | P0019_UNIFICACION | Regla 1: unifica por tipo uso + CIIU | ✅ Migrado | `02_regla1_unificacion.sql` |
| 2 | `UNI_CU3.4.2_CARGUE_REGLA_2` | P0020_CARGA_INSUMO_UNI_REG2 | Carga insumos Regla 2 | ✅ Migrado | Incluido en `03_regla2_esc1_2.sql` |
| 3 | `UNI_CU3.4.2_CARGUE_NOMENCLATURAS` | P0020_CreaDicNomenclaturaReg2 | Crea diccionario de nomenclaturas | ✅ Migrado | Incluido en `03_regla2_esc1_2.sql` |
| 4 | `UNI_CU3.4.2_CARGUE_FINAL_MODELO` | P0020_UNIFICACION_DIRECCION | Ejecuta 6 escenarios + motor | ✅ Migrado | `03` a `09` (6 scripts) |
| 5 | `UNI_CU3.4.3_CARGUE_REGLA_3` | P0021_UNIFICACION | Regla 3: geolocalización | ✅ Migrado | `10_regla3_geo.sql` |
| 6 | `UNI_CU23_FECHA_REPORTE` | P0023_RECONOCER_FECHA_REPORTE | Actualiza fechas post-unificación | ❌ No migrado | Pendiente |
| 7 | `UNI_NOTIFICACION_ERROR_UNIFICACION` | CONTROLM_IMPRIMIR_LOG.sh | Notificación de errores por email | N/A | SNS / CloudWatch Alarms |

### ORDENAMIENTO (7 jobs)

| # | Job Control-M | Script que ejecuta | Función | Estado migración | Equivalente Redshift |
|---|:---|:---|:---|:---:|:---|
| 1 | `ORD_CU24.2_CARGA_ATRIBUTOS` | ORDENAMIENTO_242 | Pre-procesamiento: 12 SPs PRO_ORD_* | ❌ **Bloqueante** | SPs no localizados |
| 2 | `ORD_CU24.3_CARGA_CARACTERISTICAS` | BTEQ_Caracteristicas_estandar | Carga tabla CARACTERISTICA | ✅ Migrado | `01_ordenamiento_schemas.sql` (beta) |
| 3 | `ORD_CU24.3_EJECUCION_ORDENAMIENTO` | BTEQ_CURSOR | Scoring dinámico (4 canales) | ✅ Migrado | `02` a `05` (4 scripts) |
| 4 | `ORD_CU27_APLICAR_ORDENAMIENTO` | P0027_UBI_ORDENAMIENTO | Consolidación + persistencia | 🟡 Parcial | `06_consolidacion_persistencia.sql` (incompleto) |
| 5 | `ORD_CU29_PREPARACION_DATOS` | P0029_PRO_IndicadorMovilidad | Prepara datos movilidad | ❌ No migrado | Pendiente |
| 6 | `ORD_CU29_INDICADORES_MOVILIDAD` | P0029_INDICADORES_MOVILIDAD | Calcula indicadores movilidad | ❌ No migrado | Pendiente |
| 7 | `ORD_NOTIFICACION_ERROR_ORDENAMIENTO` | CONTROLM_IMPRIMIR_LOG.sh | Notificación de errores | N/A | SNS / CloudWatch Alarms |

---

## 3. Cadena de Dependencias

```
ESTANDARIZACIÓN (fuera de alcance)
    │
    ├── EST_CU2.2_CARGA_FINAL_CONTACTIBILIDAD ──┐
    ├── EST_CU23_FECHA_REPORTE ─────────────────┼──► UNI_CU3.4.1_CARGUE_REGLA_1
    ├── EST_CU4_CARGUE_MODELO ──────────────────┘
    └── GEO_CU5_GEOREFERENCIACION ──────────────────► UNI_CU3.4.1_CARGUE_REGLA_1
                                                              │
UNIFICACIÓN                                                   │
    UNI_CU3.4.1_CARGUE_REGLA_1 (P0019) ──────────────────────┘
        │
        ▼
    UNI_CU3.4.2_CARGUE_REGLA_2 (P0020 insumos)
        │
        ▼
    UNI_CU3.4.2_CARGUE_NOMENCLATURAS (P0020 diccionario)
        │
        ▼
    UNI_CU3.4.2_CARGUE_FINAL_MODELO (P0020 ejecución)
        │
        ▼
    UNI_CU3.4.3_CARGUE_REGLA_3 (P0021)
        │
        ▼
    UNI_CU23_FECHA_REPORTE (P0023)
        │
        ├──► Email "TERMINA MALLA RECONOCER MASTER"
        │
        ▼
ORDENAMIENTO
    ORD_CU24.2_CARGA_ATRIBUTOS (ORDENAMIENTO_242 → 12 SPs)
        │
        ▼
    ORD_CU24.3_CARGA_CARACTERISTICAS (BTEQ_Caracteristicas_estandar)
        │
        ▼
    ORD_CU24.3_EJECUCION_ORDENAMIENTO (BTEQ_CURSOR → scoring 4 canales)
        │
        ▼
    ORD_CU27_APLICAR_ORDENAMIENTO (P0027 → persistencia)
        │
        ▼
    ORD_CU29_PREPARACION_DATOS (P0029 preparación)
        │
        ▼
    ORD_CU29_INDICADORES_MOVILIDAD (P0029 cálculo)
        │
        ▼
    Email "La Malla de Ordenamiento ha finalizado Correctamente"
```

**Orden total**: 13 pasos secuenciales (6 unificación + 1 fecha reporte + 6 ordenamiento)

---

## 4. Mapeo Control-M → AWS Step Functions

### Diseño propuesto de la State Machine

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                    STEP FUNCTION: reconocer-unificacion-ordenamiento                  │
│                    Trigger: EventBridge (semanal) o manual                            │
└─────────────────────────────────────────────────────────────────────────────────────┘

    ┌───────────────────┐
    │ ValidarPrecondiciones │  ← Verifica que EDF entregó datos (S3 event o flag)
    └─────────┬─────────┘
              │
              ▼
    ┌───────────────────┐
    │ UnificacionRegla1  │  ← Ejecuta SQL en Redshift (Data API)
    │ (02_regla1)        │
    └─────────┬─────────┘
              │
              ▼
    ┌───────────────────┐
    │ UnificacionRegla2  │  ← Ejecuta 03 a 09 en secuencia
    │ (03→04→05→06→07→  │
    │  08→09)            │
    └─────────┬─────────┘
              │
              ▼
    ┌───────────────────┐
    │ UnificacionRegla3  │  ← Ejecuta 10_regla3_geo.sql
    │ (10_regla3)        │
    └─────────┬─────────┘
              │
              ▼
    ┌───────────────────┐
    │ ActualizarFechas   │  ← Equivalente a P0023_FECHA_REPORTE
    └─────────┬─────────┘
              │
              ▼
    ┌───────────────────┐
    │ OrdenamientoPreProc│  ← Equivalente a ORDENAMIENTO_242 (12 SPs)
    │ (pendiente migrar) │     ⚠️ BLOQUEANTE: SPs no localizados
    └─────────┬─────────┘
              │
              ▼
    ┌───────────────────┐
    │ ScoringDIR         │  ← 02_scoring_dir.sql
    ├───────────────────┤
    │ ScoringTEL         │  ← 03_scoring_tel.sql     ← PARALELO
    ├───────────────────┤
    │ ScoringCEL         │  ← 04_scoring_cel.sql     ← PARALELO
    ├───────────────────┤
    │ ScoringEMA         │  ← 05_scoring_ema.sql     ← PARALELO
    └─────────┬─────────┘
              │ (Wait for all)
              ▼
    ┌───────────────────┐
    │ Consolidacion      │  ← 06_consolidacion_persistencia.sql
    └─────────┬─────────┘
              │
              ▼
    ┌───────────────────┐
    │ IndicadoresMovilidad│ ← P0029 (pendiente migrar)
    └─────────┬─────────┘
              │
              ▼
    ┌───────────────────┐
    │ NotificarExito     │  ← SNS → reconocermaster@experian.com
    └───────────────────┘

    En caso de error en cualquier paso:
    ┌───────────────────┐
    │ ManejoError        │  ← CloudWatch Alarm + SNS + log detallado
    └───────────────────┘
```

### Mejoras vs Control-M

| Aspecto | Control-M (actual) | Step Functions (propuesto) |
|---------|-------------------|---------------------------|
| Scoring 4 canales | Secuencial (cursor) | **Paralelo** (4 estados simultáneos) |
| Manejo de errores | Email + log manual | CloudWatch Alarms + SNS + retry automático |
| Reintentos | Manual (operador) | Configurable por estado (maxAttempts, backoff) |
| Visibilidad | Solo en consola Control-M (producción) | Consola AWS + CloudWatch Logs |
| Trigger | Cíclico semanal (sábado 06:30) | EventBridge rule + manual |
| Costo | Licencia Control-M | Pay-per-transition (~$0.025/1000 transiciones) |

---

## 5. Patrón de Ejecución de cada Job

Todos los jobs de Unificación y Ordenamiento siguen el mismo patrón:

```bash
# Control-M ejecuta:
/reconocer/produccion/fuentes/macros/BDM-DWH_Exec_Process.sh <SCRIPT_NAME> [PARAMS]

# El shell genérico:
# 1. Lee parámetros del archivo .par correspondiente
# 2. Genera lote (timestamp)
# 3. Ejecuta el script TPT/BTQ/BTEQ contra Teradata
# 4. Valida resultado (exit code)
# 5. Retorna OK o NOTOK a Control-M
```

**Equivalente en Step Functions**:
```json
{
  "Type": "Task",
  "Resource": "arn:aws:states:::redshift-data:executeStatement",
  "Parameters": {
    "ClusterIdentifier": "reconocer-cluster",
    "Database": "ddm_xpm_db",
    "Sql": "-- contenido del script SQL migrado"
  },
  "Retry": [{"ErrorEquals": ["States.ALL"], "MaxAttempts": 2, "BackoffRate": 2}],
  "Catch": [{"ErrorEquals": ["States.ALL"], "Next": "ManejoError"}]
}
```

---

## 6. Manejo de Errores — Patrón actual

Todos los jobs tienen el mismo patrón de error:

1. Si `NOTOK` → setea variable `%%PROCESO_UNIFICACION` o `%%PROCESO_ORDENAMIENTO` con el nombre del script que falló
2. Dispara condición `REPORTAR_ERROR_UNIFICACION` o `REPORTAR_ERROR_ORDENAMIENTO`
3. Job de notificación envía email a `reconocermaster@experian.com` con log adjunto
4. La malla se detiene (no continúa al siguiente paso)

**Equivalente en Step Functions**: Catch → estado `ManejoError` → Lambda que envía SNS con detalle del error + CloudWatch Alarm.

---

## 7. Variables de Entorno

| Variable | Valor | Uso |
|----------|-------|-----|
| `%%AMBIENTE` | `/reconocer/produccion` | Ruta base de scripts y datos |
| `%%CTL` | `N` | Flag de archivo de control |
| `%%ENC` | `N` | Flag de encriptación |
| `%%U3REJ` | `Y` | Flag de rechazo de registros |
| `%%PREFIX` | Varía por job | Prefijo de archivos de entrada |
| `%%lote` | Generado automáticamente | Número de lote (timestamp) |

**En Step Functions**: Estas variables se pasan como input del state machine o se generan en un estado inicial `GenerarParametros`.

---

## 8. Resumen de lo que debemos migrar

| Componente | Control-M | Step Functions | Estado |
|:---|:---|:---|:---:|
| Regla 1 (P0019) | 1 job | 1 estado (Redshift Data API) | ✅ SQL listo |
| Regla 2 insumos (P0020) | 1 job | 1 estado | ✅ SQL listo |
| Regla 2 diccionario (P0020) | 1 job | 1 estado | ✅ SQL listo |
| Regla 2 ejecución (P0020) | 1 job | 1 estado (o sub-state machine) | ✅ SQL listo |
| Regla 3 (P0021) | 1 job | 1 estado | ✅ SQL listo |
| Fecha reporte (P0023) | 1 job | 1 estado | ❌ Pendiente migrar |
| Pre-procesamiento (ORDENAMIENTO_242) | 1 job (12 SPs internos) | 1 estado o sub-state machine | ❌ **Bloqueante** |
| Carga características | 1 job | 1 estado (carga parámetros) | ✅ Tabla beta lista |
| Scoring 4 canales (BTEQ_CURSOR) | 1 job (secuencial) | 4 estados **paralelos** | ✅ SQL listo |
| Persistencia (P0027) | 1 job | 1 estado | 🟡 SQL incompleto |
| Preparación movilidad (P0029) | 1 job | 1 estado | ❌ Pendiente |
| Indicadores movilidad (P0029) | 1 job | 1 estado | ❌ Pendiente |
| Notificación error | 2 jobs (email) | Catch + SNS | Diseño listo |
| **TOTAL** | **14 jobs** | **~12 estados** | **7 listos, 5 pendientes** |

---

## 9. Próximos pasos para completar la orquestación

| # | Acción | Prioridad | Dependencia |
|---|--------|:---------:|-------------|
| 1 | Obtener código de 12 SPs PRO_ORD_* | 🔴 Bloqueante | Experian (acceso Teradata) |
| 2 | Migrar P0023_RECONOCER_FECHA_REPORTE | 🟡 Media | Entender qué actualiza |
| 3 | Migrar P0029 (preparación + indicadores movilidad) | 🟡 Media | Análisis de scripts |
| 4 | Completar 06_consolidacion_persistencia.sql | 🟡 Media | Ninguna |
| 5 | Diseñar State Machine en ASL (Amazon States Language) | 🟢 Cuando SQL esté listo | Items 1-4 |
| 6 | Implementar Lambda de manejo de errores + SNS | 🟢 Paralelo | Ninguna |
| 7 | Definir trigger (EventBridge schedule vs manual) | 🟢 Con Experian | Decisión operativa |

---

*Documento generado: 5 de mayo de 2026 | Fuente: Control_M.xml + análisis de scripts migrados*
