**Asunto:** Alineación de criterios de aceptación — Unificación de Direcciones

---

Hola equipo,

Tras revisar el documento funcional V2 propuesto por Experian para la migración de Unificación de Direcciones, realizamos un cruce detallado contra los criterios de aceptación que definimos durante el desarrollo en Redshift. El resultado es una alineación funcional completa.

---

## Resultado del cruce

Consolidamos todos los criterios por regla e identificamos quién los propuso. **Estos criterios consolidados son los que usaremos para evaluar el resultado de la migración de Unificación en Redshift.** Cada tabla representa el acuerdo funcional contra el cual se validará la implementación.

### Regla 1 — Tipo de Uso + CIIU

| ID | Criterio | Origen |
|:--:|----------|:------:|
| R1-01 | CIIU=10 → padre es LAB o CRR con mayor entidades | Ambos |
| R1-02 | CIIU=81,82,90 → padre es RES o CRR con mayor entidades | Ambos |
| R1-03 | Otro CIIU → mayor entidades sin importar tipo | Ambos |
| R1-04 | Hijo queda con `ind_unificacion = 1` | Ambos |
| R1-05 | Se inserta par en `unificacion_direccion` | Ambos |
| R1-06 | Bloqueadas e hijas previas no se procesan | Ambos |
| R1-07 | Baseline CIIU obligatorio: 10=asalariado, 81/82/90=sin actividad (no usar 1-9 ni solo 81) | Ambos |
| R1-08 | Empate persistente = no decisión | Ambos |

### Regla 2 — Complementos

| ID | Criterio | Origen |
|:--:|----------|:------:|
| R2-01 | Esc 1: vacío vs informado → gana el informado | Ambos |
| R2-02 | Esc 2: incluido → gana el más completo | Ambos |
| R2-03 | Esc 3 sin NIT: misma nomenclatura, ≠ valor → mayor entidades | Ambos |
| R2-04 | Esc 3 NIT: genera nueva dirección combinando valores | Ambos |
| R2-05 | Esc 4: ≠ nomenclatura, mismo nivel → diccionario frecuencias | Ambos |
| R2-06 | Esc 5: ≠ nivel → genera nueva dirección | Ambos |
| R2-07 | Esc 6: ninguna contenida → combina o diccionario según nivel | Ambos |
| R2-08 | Nuevas direcciones marcadas como generadas | Kidar |
| R2-09 | Nuevas direcciones tienen relación persona-ubicación | Kidar |
| R2-10 | Padre NUNCA queda marcado como hijo | Ambos |
| R2-11 | Cada hija tiene exactamente 1 padre | Kidar |
| R2-12 | Corrección de complementos: sin duplicidad, con completitud y orden lógico | Ambos |
| R2-13 | Diccionario basado en frecuencia histórica | Ambos |
| R2-14 | Empate persistente = no decisión | Ambos |

### Regla 3 — Geolocalización

| ID | Criterio | Origen |
|:--:|----------|:------:|
| R3-01 | Solo tipo Vía (excluye Manzana y Rural) | Ambos |
| R3-02 | Solo una con lat/long → gana la geolocalizada | Ambos |
| R3-03 | Ninguna con lat/long → fecha más reciente, luego entidades | Ambos |
| R3-04 | Ambas con lat/long → diccionario de vía por frecuencia | Ambos |
| R3-05 | Diferencia puerta: valida umbral ±2 | Ambos |
| R3-06 | Diferencia > 2 → NO unifica | Ambos |
| R3-07 | Modificadores de vía (B, C, F, BIS) excluyen la dirección | Ambos |
| R3-08 | Cuadrantes (N, S, E, O) se omiten para comparación pero no excluyen | Ambos |
| R3-09 | Umbral ±2 aplica SOLO en subcaso "ambas con lat/long" | Ambos |
| R3-10 | Empate en diccionario = no decisión | Ambos |

### Reglas Generales

| ID | Criterio | Origen |
|:--:|----------|:------:|
| G-01 | Cascada R1 → R2 → R3 | Ambos |
| G-02 | Padre de R1 puede ser hijo en R2 | Ambos |
| G-03 | Hijas no se re-procesan | Ambos |
| G-04 | Bloqueadas no se procesan | Ambos |
| G-05 | Toda unificación genera trazabilidad | Ambos |
| G-06 | Idempotencia | Kidar |
| G-07 | Nunca se comparan personas diferentes | Ambos |
| G-08 | Unificación es lógica (no borra datos) | Ambos |
| G-09 | Hijas nunca pasan a ordenamiento | Ambos |
| G-10 | Padres vigentes siempre pasan a ordenamiento | Ambos |

---

## Conclusión

Existe **coincidencia funcional completa** en todos los criterios de reglas de negocio. No hay contradicciones. Los criterios técnicos de Kidar (marcas, relaciones, idempotencia) complementan los criterios funcionales de Experian sin conflicto.

---

## Gobernanza de migración (propuesto por Experian)

Adicionalmente, el documento de Experian propone criterios de gobernanza para el manejo de diferencias durante la migración:

| ID | Criterio |
|:--:|----------|
| GOB-01 | Toda diferencia debe clasificarse: error de migración, diferencia de datos, cambio funcional aprobado o no clasificada |
| GOB-02 | Diferencias no clasificadas no pueden aceptarse para producción |
| GOB-03 | Evolución funcional requiere aprobación formal de negocio |
| GOB-04 | Bitácora de diferencias con: ID, regla, caso, resultado Teradata, resultado Redshift, clasificación, impacto, responsable, decisión, aprobador |

Estos criterios de gobernanza los acogemos como marco de trazabilidad. En caso de identificarse diferencias durante la validación, se aplicará esta clasificación para documentarlas y resolverlas de forma ordenada.

---

## Punto a validar: Comparación de paridad Teradata vs Redshift

El documento de Experian también propone dos criterios que implican una validación cruzada entre ambientes:

- **G-E5**: Toda diferencia Teradata vs Redshift debe clasificarse, justificarse y aprobarse.
- **G-E6**: La certificación incluye matriz de pruebas con muestras comparativas padre-hijo entre Teradata y Redshift.

Estos criterios implican ejecutar el proceso en ambos ambientes con el mismo corte de datos y comparar resultados registro a registro.

Sobre esto, necesitamos definición de @Janneth y @Fernando:

**¿Es necesario realizar esta comparación de paridad contra Teradata?**

Planteamos tres consideraciones por las cuales este ejercicio requiere planificación especial:

1. **Diferencia en el modelo de datos origen.** El nuevo ambiente se alimenta del XPM (estructura JSON desde EDF), mientras que Teradata operaba sobre su propio modelo relacional con llaves subrogadas internas. No existe un corte de datos "espejo" entre ambos ambientes sin un proceso previo de conciliación de insumos.

2. **Cambio de plataforma y paradigma.** Redshift no soporta cursores, SQL dinámico ni UDFs en C. La implementación en destino será funcionalmente equivalente pero técnicamente diferente. Para que una comparación registro a registro sea válida, primero se debe garantizar que ambos ambientes operan con exactamente los mismos insumos de entrada — mismas personas, mismas direcciones, mismos complementos, mismos catálogos. Dado que el modelo de ingesta cambió (de carga directa a consumo de XPM), esta garantía de paridad de insumos requiere un diseño, transformación y validación dedicada antes de poder comparar resultados.

3. **Volumen y representatividad de la muestra.** El proceso actual de Teradata opera sobre ~65-70 millones de registros. Definir un subconjunto representativo que cubra los escenarios de las 3 reglas (incluyendo casos NIT, empates, nomenclaturas de diferente nivel, direcciones con y sin coordenadas) requiere un criterio de selección formal y acceso coordinado a datos productivos de ambos ambientes.

**En caso de que se considere necesario, proponemos construir en conjunto un plan de validación de paridad.** A alto nivel, este plan contemplaría:

**Fase 1 — Diseño de la comparación**
- Definir criterios de selección de muestra: personas con diversidad de escenarios (múltiples tipos de uso, complementos variados, direcciones con y sin coordenadas, casos NIT, empates).
- Acordar el tamaño del universo de prueba (propuesta inicial: 500-1,000 personas que cubran los 3 escenarios de R1, los 6 escenarios de R2 y los 2 escenarios de R3).
- Establecer las llaves de conciliación entre ambos ambientes (¿PIN? ¿id_buro_persona? ¿combinación?).

**Fase 2 — Preparación de insumos**
- Extraer de Teradata el estado actual de las personas seleccionadas: direcciones, complementos, tipo uso, CIIU, bloqueos, unificaciones previas.
- Transformar esos insumos al formato del modelo destino en Redshift (mapeo XPM → tablas de entrada).
- Validar que los insumos sean equivalentes antes de ejecutar.

**Fase 3 — Ejecución y comparación**
- Ejecutar el proceso de Unificación en Redshift con los insumos preparados.
- Obtener de Teradata el resultado final para esas mismas personas (pares padre-hijo, regla aplicada, escenario).
- Comparar resultado por resultado: padre coincide, hijo coincide, regla coincide, escenario coincide.

**Fase 4 — Clasificación de diferencias**
- Aplicar la bitácora propuesta por Experian: ID, regla, caso, resultado Teradata, resultado Redshift, clasificación (error de migración / diferencia de datos / cambio aprobado), responsable, decisión.
- Documentar causas raíz y plan de acción para cada diferencia.

**Fase 5 — Cierre**
- Aprobación funcional de diferencias aceptadas.
- Informe de certificación con evidencia.

Para avanzar, lo ideal sería acordar en una sesión corta el alcance de la muestra, quién facilita los datos de Teradata y los puntos de contacto por cada lado. Así lo incorporamos como parte del flujo de validación sin que se convierta en un esfuerzo separado.

---

Quedo atento a comentarios.

Francisco Peña
