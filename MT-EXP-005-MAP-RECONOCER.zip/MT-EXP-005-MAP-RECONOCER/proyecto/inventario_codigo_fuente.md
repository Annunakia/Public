# Inventario de Código Fuente – Reconocer (Teradata)

> Mapeo completo de scripts en `Experian Reconocer/`. Actualizado 2026-04-17.

---

## Convención de nombres

| Sufijo | Tipo | Paso | Descripción |
|--------|------|------|-------------|
| `_100` / `_110` / `_111` | BTQ/TPT | 1 | Setup: creación de tablas, vistas, preparación |
| `_120` | TPT | 2 | Carga de datos a tablas stage |
| `_130` / `_131` | TPT/BTQ | 3 | Transformación principal (lógica de negocio) |
| `_140` / `_141` | TPT/BTQ | 4 | Exportación / resultado final |

**Tipos de archivo**: `.TPT` = Teradata Parallel Transporter | `.BTQ` = BTEQ script | `.txt` = DDL de vistas/datos

---

## 1. Unificación (`Unificacion/`)

### Scripts de proceso

| Programa | Archivo | Tipo | Paso | Descripción |
|----------|---------|------|------|-------------|
| P0019 | P0019_UNIFICACION_111.TPT | TPT | 1 | Setup unificación base |
| P0019 | P0019_UNIFICACION_120.TPT | TPT | 2 | Carga datos |
| P0019 | P0019_UNIFICACION_130.TPT | TPT | 3 | Transformación principal (reglas) |
| P0019 | P0019_UNIFICACION_130_20240730.TPT | TPT | 3 | Variante con fecha (backup) |
| P0019 | P0019_UNIFICACION_140.TPT | TPT | 4 | Exportación resultado |
| P0020 | P0020_UNIFICACION_DIRECCION_111.BTQ | BTEQ | 1 | Setup unificación de direcciones |
| P0020 | P0020_UNIFICACION_DIRECCION_120.BTQ | BTEQ | 2 | Carga datos dirección |
| P0020 | P0020_UNIFICACION_DIRECCION_130.TPT | TPT | 3 | Transformación direcciones (11.8KB — el más pesado) |
| P0020 | P0020_UNIFICACION_DIRECCION_140.BTQ | BTEQ | 4 | Resultado direcciones |
| P0020 | P0020_CreaDicNomenclaturaReg2_131.BTQ | BTEQ | 3+ | Creación diccionario nomenclatura Regla 2 |
| P0020 | P0020_CARGA_INSUMO_UNI_REG2_131.BTQ | BTEQ | 3+ | Carga insumos Regla 2 |
| P0021 | P0021_UNIFICACION_120.TPT | TPT | 2 | Carga |
| P0021 | P0021_UNIFICACION_130.TPT | TPT | 3 | Transformación |
| P0021 | P0021_UNIFICACION_140.TPT | TPT | 4 | Resultado |
| P0021 | P0021_UNIFICACION_141.TPT | TPT | 4+ | Paso adicional de exportación |

### Vistas y datos

| Archivo | Tipo | Contenido |
|---------|------|-----------|
| V_Insumo_Unificacion_Regla1.txt | Vista SQL | Insumo Regla 1: JOINs entre RELACION_PERSONA_UBICACION, UBICACION_ESTANDARIZADA, DIRECCION_FISICA, CIIU. Filtra `Ind_Unificacion IS NULL` y sin bloqueos |
| V_Insumo_Unificacion_Regla2.txt | Vista SQL | Insumo Regla 2: SELECT desde `REC_STAGE.tmpINSUMO_UNI_REG2` |
| V_Insumo_Unificacion_Regla3.txt | Vista SQL | Insumo Regla 3: SELECT desde `REC_STAGE.Unificacion_3432` |
| VM_Reporte_Relacion_Pers_Ubi.txt | Vista SQL | Vista materializada con lógica compleja de fechas de reporte (CASE por estado vigencia, naturaleza cuenta, flags) |
| Tipo_Via.txt | Datos | Catálogo: tipos de vía, ubicación, zona + acepciones de estandarización |
| Documento Funcional Unificacion Final V1.0.docx | Doc | Documento funcional completo (convertido a MD en `Resumen/unificacion/`) |

### DDLs

| Archivo | Tamaño | Contenido |
|---------|--------|-----------|
| DB/Unificacion.sql | 311 KB | DDLs completos de tablas del proceso de unificación |

---

## 2. Ordenamiento (`Ordenamiento/`)

### Scripts de proceso

| Programa | Archivo | Tipo | Paso | Descripción |
|----------|---------|------|------|-------------|
| P0027 | P0027_UBI_ORDENAMIENTO_111.TPT | TPT | 1 | Setup ordenamiento ubicaciones |
| P0027 | P0027_UBI_ORDENAMIENTO_120.TPT | TPT | 2 | Carga datos |
| P0027 | P0027_UBI_ORDENAMIENTO_130.TPT | TPT | 3 | Transformación/score (6.3KB) |
| P0027 | P0027_UBI_ORDENAMIENTO_140.TPT | TPT | 4 | Resultado |
| P0029 | P0029_INDICADORES_MOVILIDAD_111.BTQ | BTEQ | 1 | Setup indicadores movilidad |
| P0029 | P0029_INDICADORES_MOVILIDAD_120.TPT | TPT | 2 | Carga datos movilidad |
| P0029 | P0029_INDICADORES_MOVILIDAD_130.TPT | TPT | 3 | Cálculo indicadores (8.5KB) |
| P0029 | P0029_INDICADORES_MOVILIDAD_140.TPT | TPT | 4 | Resultado |
| — | ORDENAMIENTO_242_131.BTQ | BTEQ | 3+ | Lógica de ordenamiento (6.9KB) |
| — | BTEQ_CURSOR_131.BTQ | BTEQ | 3+ | Cursor para procesamiento iterativo (6.2KB) |

### Datos

| Archivo | Tamaño | Contenido |
|---------|--------|-----------|
| Caracteristicas.txt | 133 KB | Catálogo de características (archivo grande, probablemente parametrización) |

### DDLs

| Archivo | Tamaño | Contenido |
|---------|--------|-----------|
| DB/Ordenamiento.sql | 17.7 KB | DDLs de tablas del proceso de ordenamiento |

---

## 3. Estandarización (`Estandarizacion/`)

| Programa | Archivo | Tipo | Paso | Tamaño |
|----------|---------|------|------|--------|
| P0001 | P0001_EstandarizacionUbicacion_131.BTQ | BTEQ | 3+ | 4.5 KB |
| P0001 | P0001_UBICACION_ESTANDARIZADA_111.BTQ | BTEQ | 1 | 14.9 KB |
| P0001 | P0001_UBICACION_ESTANDARIZADA_120.TPT | TPT | 2 | 3.6 KB |
| P0001 | P0001_UBICACION_ESTANDARIZADA_130.TPT | TPT | 3 | 17.9 KB |
| P0001 | P0001_UBICACION_ESTANDARIZADA_140.TPT | TPT | 4 | 4.6 KB |

**DDLs**: `DB/Estandarizacion.sql` (681 KB — el más grande, modelo de datos completo)

**Nota**: La estandarización se moverá a EDF (Curation). Este código es referencia para entender la lógica actual.

---

## 4. Novedades (`Novedades/`)

| Programa | Archivo | Tipo | Paso | Tamaño |
|----------|---------|------|------|--------|
| P0035 | P0035_Extractor_Novedades_111.BTQ | BTEQ | 1 | 20.3 KB |
| P0035 | P0035_Extractor_Novedades_120.TPT | TPT | 2 | 35.5 KB |
| P0035 | P0035_Extractor_Novedades_130.TPT | TPT | 3 | 41.0 KB |
| P0035 | P0035_Extractor_Novedades_140.BTQ | BTEQ | 4 | 28.2 KB |

**DDLs**: `DB/Novedad.sql` (406 KB)

**Nota**: Estado "Por confirmar en qué punto del flujo va" según reu_sync.md.

---

## 5. Geolocalización (`Geo/SO/`)

| Programa | Archivo | Tipo | Paso | Descripción |
|----------|---------|------|------|-------------|
| P0006 | P0006_STAGEGEOREFERENCIA_100.TPT | TPT | 0 | Stage de georeferenciación |
| P0007 | P0007_PUNTO_DE_INTERES_GEO_100-141 | TPT/BTQ | 0-4 | Puntos de interés GEO (6 archivos) |
| P0013 | P0013_STAGEDISTANCIASGEO_100.TPT | TPT | 0 | Stage distancias GEO |
| P0014 | P0014_NUEVANOMENCLATURA_100-140 | TPT | 0-4 | Nueva nomenclatura (5 archivos) |
| P0036 | P0036_STAGE_PUNTO_INTERES_GEO_131-141 | BTQ/TPT | 3-4 | Stage punto interés GEO |

**Nota**: Integración con ESRI/ArcGIS actualmente **DESCONECTADA**. Prioridad media en migración.

---

## 6. UDFs (`UDFs/`)

25 subcarpetas con funciones definidas por usuario en C:

| UDF | Descripción probable |
|-----|---------------------|
| ADDRESS_NORMALIZATION | Normalización de direcciones (11 archivos) |
| REPLEXPREG | Reemplazo por expresiones regulares (10 archivos) |
| REPL_CHRS | Reemplazo de caracteres (6 archivos) |
| DataMasking | Enmascaramiento de datos (8 archivos) |
| MD5 | Hash MD5 (8 archivos) |
| GENACCEPAUT | Generación de acepciones automáticas (7 archivos) |
| SUBSTREXPREG | Substring por expresión regular (5 archivos) |
| DIST_LEVEN | Distancia de Levenshtein (4 archivos) |
| Similitud_Palabras | Similitud entre palabras (4 archivos) |
| PorcSimilitud | Porcentaje de similitud (5 archivos) |
| Bach_Similitud_email | Similitud batch de emails (5 archivos) |
| Bach_Similitud_Dir_VIA | Similitud batch de direcciones tipo vía (4 archivos) |
| Bach_Similitud_Dir_MZ | Similitud batch de direcciones tipo manzana (4 archivos) |
| Bach_Similitud_Tel | Similitud batch de teléfonos (4 archivos) |
| ValidacionDirVia | Validación de dirección tipo vía (4 archivos) |
| ValidacionDirRural | Validación de dirección rural (4 archivos) |
| ValidacionDirMz | Validación de dirección manzana (4 archivos) |
| ValidateExpressionR | Validación de expresión regular (4 archivos) |
| IsNumeric | Validación numérica (4 archivos) |
| getNumCont | Obtener número de contacto (5 archivos) |
| eListGetValByIdx | Obtener valor de lista por índice (4 archivos) |
| SetComplement | Complemento de conjuntos (4 archivos) |
| IdentTuplaGeo | Identificación de tupla geográfica (5 archivos) |
| pru_leven | Prueba Levenshtein (4 archivos) |
| library | Librería compartida (8 archivos) |

**Nota**: Si se usa Libpostal, la mayoría de estas UDFs no se migran. Si Libpostal falla, hay que re-implementar las críticas.

---

## Resumen de volumen de código

| Proceso | Scripts | DDLs | Total estimado |
|---------|---------|------|----------------|
| Unificación | 15 archivos + 5 vistas/datos | 311 KB | ~370 KB |
| Ordenamiento | 10 archivos + 1 dato | 17.7 KB | ~70 KB |
| Estandarización | 5 archivos | 681 KB | ~725 KB |
| Novedades | 4 archivos | 406 KB | ~530 KB |
| Geo | 16 archivos | — | ~80 KB |
| UDFs | ~25 subcarpetas | — | Variable (C) |

---

*Generado: 2026-04-17 | Fuente: escaneo directo de `Experian Reconocer/`*
