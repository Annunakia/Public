# Decisiones Abiertas y Pendientes – Proyecto Reconocer

> Tracking de decisiones técnicas y de negocio. Actualizado 2026-04-17.

---

## Decisiones Resueltas ✅

| # | Decisión | Resultado | Fecha | Impacto |
|---|----------|-----------|-------|---------|
| 1 | Arquitectura general | Híbrida EDF + Redshift | 16/03 | Define toda la estrategia de migración |
| 2 | Etapa de estandarización en EDF | Curation en pipeline IFR | 19/03 | Campo nuevo en XPM, no modifica existente |
| 3 | Impacto en PINNING | No se toca | 19/03 | Independencia total del proyecto |
| 4 | Estandarización fuera de Reconocer | Se mueve al equipo de datos | 25/03 | Reconocer trabaja con datos ya estandarizados |
| 5 | Fuente OTP (Evidente) | Excluida del alcance | 26/03 | Nunca se activó, no se migra |
| 6 | Geolocalización ESRI | Desconectada actualmente | 26/03 | Contactar a Julián Méndez para nueva integración |

---

## Decisiones Abiertas ❓

### DA-1: ¿Ordenamiento en EDF (Spark) o Redshift (SQL)?

| Aspecto | EDF (Spark/Scala) | Redshift (SQL) |
|---------|-------------------|----------------|
| Alineación XPMS | ✅ Alta | ❌ Baja |
| Simplicidad técnica | ❌ Baja (Scala) | ✅ Alta (SQL) |
| Experiencia equipo | ❌ Baja | ✅ Alta |
| Independencia de EDF | ❌ Baja | ✅ Alta |

**Estado**: Pendiente workshop con arquitectura
**Responsable**: Francisco + Wilmar + Arquitectura Experian
**Impacto**: Define distribución de trabajo entre equipos EDF y Redshift

### DA-2: Estrategia de estandarización (Libpostal vs migración UDFs)

**Estado**: Pendiente POC de Libpostal
**Criterios de éxito POC**: ≥90% compatibilidad DANE, ≥85% cobertura, ≤100ms/dirección
**Plan B**: Si POC falla → migración directa de UDFs (+4 meses)

### DA-3: Aproximación de migración para Unificación y Ordenamiento

3 aproximaciones a probar (benchmark de Francisco):

| # | Aproximación | Estado |
|---|-------------|--------|
| 1 | Prompt directo (IDE) | Por probar |
| 2 | AWS Q Transform Custom | Pendiente demo con Harold |
| 3 | Spec Driven Development | Por probar |

**Responsable**: Francisco (benchmark)
**Dependencia**: Demo de AWS Q Transform Custom (Harold, por agendar)

---

## Insumos Pendientes 📋

| # | Insumo | Fuente | Responsable | Estado | Criticidad |
|---|--------|--------|-------------|--------|------------|
| 1 | Malla Control-M (orden ejecución) | Experian (Melissa) | Molina | Pendiente | Alta |
| 2 | Mapeo tablas Redshift del XPM | Confluence | Molina | Por compartir | Alta |
| 3 | Versión Redshift desplegada | Experian | Por confirmar | Pendiente | Media |
| 4 | Transcripciones reuniones unificación/ordenamiento | Experian (Janeth) | Molina | Pendiente | Media |
| 5 | Contrato de campos requeridos en tablas Redshift | Experian | Pendiente | Alta (deadline 15 mayo) |
| 6 | Demo AWS Q Transform Custom | Harold (AWS) | Molina coordina | Por agendar | Media |
| 7 | Framework orquestación Lambda | Oscar (Macondotek) | Molina coordina | Por agendar | Baja |
| 8 | Contexto Redshift/Experian desde Data Masking | Molina | Molina | Pendiente | Media |

---

## Restricciones clave

- **Deadline Teradata**: Abril-mayo 2027 (renovación licenciamiento). Si no se completa migración, hay que renovar.
- **Dependencia IFR**: Fecha tentativa agosto 2026. Si no sale, Reconocer se bloquea.
- **Restricción legal**: No mezclar datos buró tradicional con Nueva Data (ICS/Mi Data Crédito).
- **Horas en Clockify**: Se cargan como preventa hasta formalización.
- **No implementar mejoras**: Sin requerimiento escrito del cliente.

---

*Fuente: reu_sync.md, 01_contexto_proyecto.md, 02_fases_tecnicas.md*
