**Asunto:** Campos de salida — Procesos Unificación y Ordenamiento

---

Hola equipo,

Como parte del proceso de migración de Reconocer, necesitamos alinear las expectativas sobre qué produce cada proceso para que los equipos que consumen estos datos (batch de contacto, DB2 Online, reportería) tengan claridad sobre la estructura y contenido de las salidas.

A continuación detallo los campos de salida que generan Unificación y Ordenamiento en Redshift. Esto nos permite validar que el modelo de datos destino es compatible con lo que los consumidores esperan recibir, y confirmar que no hay campos faltantes o transformaciones adicionales necesarias antes de la integración.

---

## Salidas de Unificación

El proceso de Unificación toma todas las direcciones físicas de una persona y determina cuáles son redundantes. El resultado es una relación Padre-Hijo: la dirección "padre" es la que sobrevive como la mejor representación, las "hijas" quedan marcadas como absorbidas.

### Tabla: `unificacion_direccion` (INSERT — historial de decisiones)

| Campo | Tipo | Descripción |
|-------|------|-------------|
| cod_dw_persona_ubic | BIGINT | Dirección hija (la que fue absorbida) |
| cod_dw_direccion_unificada | BIGINT | Dirección padre (la ganadora) |
| unifica_atributos | INTEGER | Regla que la unificó (1=Regla 1, 2=Regla 2, 3=Regla 3) |
| fecha_unificacion | DATE | Fecha de ejecución |
| lote | INTEGER | Lote de procesamiento |
| severidad | INTEGER | Nivel de confianza |
| usuario_bd | VARCHAR | Usuario que ejecutó |

### Tabla: `relacion_persona_ubicacion` (UPDATE — marca de estado)

| Campo | Operación | Descripción |
|-------|-----------|-------------|
| ind_unificacion | SET = 1 | Marca la dirección como absorbida. Las que quedan NULL son las ganadoras que pasan a Ordenamiento. |

### Tabla: `direccion_fisica` (INSERT — solo Regla 2)

| Campo | Tipo | Descripción |
|-------|------|-------------|
| cod_dw_direccion_fisica | BIGINT | ID de la nueva dirección generada |
| complemento | VARCHAR | Complemento combinado (ej: "TO 3 AP 504") |
| cod_dw_ubic | BIGINT | Ubicación estandarizada asociada |
| generada_enriquecida | INTEGER | Flag = 1 (indica que fue creada por el motor de Regla 2) |

> **Nota:** Regla 2 puede generar nuevas direcciones combinando complementos de dos hijas. Estas direcciones nuevas se insertan como registros nuevos y se convierten en el padre.

---

## Salidas de Ordenamiento

El proceso de Ordenamiento toma las direcciones ganadoras de Unificación (y teléfonos, celulares, emails) y les calcula un score de contactabilidad usando regresión logística. El resultado es un ranking por persona: cuál dato de contacto intentar primero.

### Tabla: `score_ordenamiento` (INSERT — score por canal)

| Campo | Tipo | Descripción |
|-------|------|-------------|
| cod_dw_persona_ubic | BIGINT | ID del dato de contacto |
| cod_pin_persona | INTEGER | PIN de la persona |
| id_buro_persona | INTEGER | ID interno de persona |
| canal | VARCHAR(3) | Canal: DIR (dirección), TEL (fijo), CEL (celular), EMA (email) |
| score | DECIMAL(18,4) | Score de contactabilidad (suma ponderada de características × Beta) |
| lugar | INTEGER | Posición en el ranking (1 = más probable de contactar) |

### Tabla: `relacion_persona_ubicacion` (UPDATE — ranking final)

| Campo | Operación | Descripción |
|-------|-----------|-------------|
| orden_prioridad | SET = lugar | Ranking final. 1 = primera opción para contactar a la persona en ese canal. |

### Tabla: `ubicacion_atributo_hash` (INSERT/UPDATE — control de cambios)

| Campo | Tipo | Descripción |
|-------|------|-------------|
| cod_pin_persona | INTEGER | PIN persona |
| id_buro_persona | INTEGER | ID interno persona |
| cod_dw_persona_ubic | BIGINT | ID dato de contacto |
| concatena | VARCHAR | Concatenación de todas las características calculadas |
| cod_hash | VARCHAR(32) | Hash MD5 de concatena (detecta si algo cambió entre ejecuciones) |
| fecha_insercion | DATE | Fecha de cálculo |

---

## Flujo resumido

```
Direcciones de una persona (ej: 5)
        ↓
   UNIFICACIÓN
        ↓
Direcciones ganadoras (ej: 3) + historial padre-hijo
        ↓
   ORDENAMIENTO
        ↓
Ranking por canal: DIR #1, DIR #2, CEL #1, TEL #1, EMA #1
```

Quedo atento a dudas.

Francisco Peña
