# Análisis del Plan de Trabajo Preliminar (MT-EXP-F-031)

> **Fecha de análisis**: 6 de mayo de 2026 | **Analista**: Francisco Peña
> **Fuente**: `proyecto/entregables/MT EXP F 031 Preliminary Work Plan.xlsx`
> **Objetivo**: Revisar hitos, habilitadores, nomenclatura y secuencia de tareas. Proponer ajustes.

---

## 1. Resumen del Plan Original

- **Período**: Mayo – Noviembre 2026 (14 sprints de 2 semanas)
- **4 Workstreams**: WS2 (Arquitectura), WS3 (Motor Redshift + Batch), WS4 (Integración AWS), WS-GO (Producción)
- **6 Hitos**: Mayo, Junio, Julio, Agosto (crítico), Septiembre, Octubre/Noviembre
- **~70 tareas** distribuidas en los 4 workstreams

---

## 2. Análisis por Hito — Habilitadores y Observaciones

### HITO MAYO: "Acuerdo técnico de datos validado + Arquitectura en workshop"

**Habilitadores críticos:**
- Contrato de integración EDF ↔ Redshift firmado (campos, tipos, semántica)
- Arquitectura híbrida validada con equipo Experian
- Ambientes DEV/QA/PROD definidos

**Observaciones:**
- ✅ Nombre del hito es correcto y claro
- ⚠️ WS2.1.4 "Decisión sobre ubicación del ordenamiento (EDF vs Redshift)" — **ya está decidido** (Redshift). Esta tarea ya se completó. Eliminar o marcar como hecha.
- ⚠️ WS2.1.1-WS2.1.3 (workshop arquitectónico) — Los workshops ya se hicieron en marzo 2026. Estas tareas son retrospectivas. Considerar si se mantienen como "validación" o se eliminan.
- 💡 **Sugerencia de nombre**: "H-MAY: Contrato de Datos EDF↔Redshift Formalizado + Arquitectura Aprobada"

**Habilitadores que faltan en el plan:**
- Catálogo de decodificación de `contacttype` (RES/LAB/CRR)
- Confirmación de que `mainisiccode` = CIIU colombiano
- Mapeo de tablas XPM post-Relationalize (Confluence)

---

### HITO JUNIO: "Entorno Redshift operativo + Ordenamiento mock v1 funcional"

**Habilitadores críticos:**
- Entorno Redshift aprovisionado con permisos IAM
- Datos mock cargados y validados
- Algoritmos de scoring implementados (al menos DIR)

**Observaciones:**
- ⚠️ **Ordenamiento ya está migrado** (PoC completada). Los scripts 02-06 ya existen y están validados con 5,000 personas. Este hito debería reflejar "validación con datos mock del XPM real" en vez de "re-implementación".
- ⚠️ WS3.3.1-WS3.3.5 asumen que el ordenamiento no está hecho. Hay que ajustar para reflejar el avance de la PoC.
- ⚠️ **Falta Unificación** — El plan no tiene un bloque equivalente para Unificación (que es más compleja y también ya está migrada en PoC).
- 💡 **Sugerencia de nombre**: "H-JUN: Entorno Operativo + Validación de PoC con Datos Mock XPM"

**Habilitadores que faltan:**
- Catálogos cargados vía Colibrí (NOMENCLATURA, Beta)
- Firma de SPs confirmada con Oscar (para framework batch)

---

### HITO JULIO: "Ordenamiento mock completo y validado"

**Habilitadores críticos:**
- 4 canales de scoring validados (DIR, TEL, CEL, EMA)
- Consolidación y persistencia funcional
- Validación con experto Reconocer (Experian)

**Observaciones:**
- ⚠️ Si Ordenamiento ya está hecho (PoC), este hito debería ser **Unificación** validada con datos mock del XPM, no Ordenamiento.
- ⚠️ WS3.3.6-WS3.3.8 (TEL + EMA) ya están migrados. Redundante.
- 💡 **Sugerencia de nombre**: "H-JUL: Unificación + Ordenamiento Validados con Mock XPM + Aprobación Funcional"

**Habilitadores que faltan:**
- Los 12 SPs PRO_ORD_* localizados y analizados (bloqueante para ordenamiento completo)
- Indicadores de movilidad (P0029) al menos analizados

---

### HITO AGOSTO: "Integración EDF → Redshift funcional con datos reales (PUNTO CRÍTICO)"

**Habilitadores críticos:**
- IFR operativo con datos de Reconocer (dependencia externa — agosto 2026)
- Relationalize ejecutado y datos disponibles en Redshift
- Contrato de campos cumplido por EDF
- Ejecución exitosa de Unificación + Ordenamiento con datos reales

**Observaciones:**
- ✅ Correctamente marcado como PUNTO CRÍTICO
- ✅ Nombre claro y preciso
- ⚠️ WS3.4.1 depende de D3 (IFR). Si IFR se retrasa, todo desde aquí se corre. El plan no tiene contingencia.
- 💡 **Sugerencia de nombre**: "H-AGO: Integración EDF→Redshift con Datos Reales — Validación End-to-End" (mantener como está, es bueno)

**Habilitadores que faltan:**
- Plan de contingencia si IFR no está listo en agosto
- Datos anonimizados de Teradata para reconciliación
- Acceso a Teradata para comparar resultados

---

### HITO SEPTIEMBRE: "Cálculo de scores validado + Step Functions operativa"

**Habilitadores críticos:**
- Scores consolidados para 65-70M ciudadanos
- Indicadores de movilidad calculados
- Step Functions desplegada y funcional
- Pruebas de orquestación end-to-end pasadas

**Observaciones:**
- ✅ Combina bien el cálculo (WS3) con la orquestación (WS4)
- ⚠️ WS3.5.3 "Precálculo para población completa" es la primera vez que se ejecuta con 65-70M. Puede haber problemas de performance no detectados en mock. Necesita buffer.
- ⚠️ WS4.3 (Step Functions) asume diseño desde cero. Pero el framework batch de Oscar ya existe. Debería ser "integración con framework existente", no "implementación de Step Functions".
- 💡 **Sugerencia de nombre**: "H-SEP: Precálculo Completo (65-70M) + Orquestación Framework Batch Operativa"

**Habilitadores que faltan:**
- Framework batch desplegado en ambiente de Reconocer
- Permisos de `user_sp` sobre todos los SPs
- YAML de definición del proceso validado

---

### HITO OCTUBRE/NOVIEMBRE: "Modelo batch completo + Go-Live"

**Habilitadores críticos:**
- Pruebas integrales end-to-end aprobadas
- Certificación funcional por Experian
- Ambiente productivo configurado
- Proceso de estabilización definido

**Observaciones:**
- ✅ Secuencia correcta: pruebas → certificación → deploy → estabilización
- ⚠️ GO.1.3 "Certificación funcional por Experian" — ¿Quién en Experian certifica? ¿Con qué criterios? Esto debe definirse antes (en H-MAY idealmente).
- ⚠️ No hay mención de la conexión Redshift → DB2 (actividad #19 del WBS de preventa). Si está en alcance, falta.
- 💡 **Sugerencia de nombres**:
  - H-OCT: "Batch Completo + Certificación Funcional Experian"
  - H-NOV: "Go-Live Producción + Inicio Garantía"

**Habilitadores que faltan:**
- Criterios de aceptación definidos y acordados con Experian
- Runbook de operación documentado
- Plan de rollback en caso de fallo en producción

---

## 3. Problemas Estructurales del Plan

| # | Problema | Impacto | Sugerencia |
|---|----------|---------|-----------|
| 1 | **No refleja la PoC completada** | Tareas de Ordenamiento (WS3.3) son redundantes — ya están hechas | Reemplazar por "validación con datos XPM" |
| 2 | **Unificación no tiene bloque propio** | El proceso más complejo del proyecto no aparece como actividad explícita | Agregar bloque WS3.X para Unificación (R1, R2, R3) |
| 3 | **WS4.3 asume Step Functions desde cero** | El framework batch de Oscar ya existe. No hay que construirlo, hay que integrarse | Cambiar a "Integración con Framework Batch existente" |
| 4 | **No hay reconciliación contra Teradata** | Sin esto no se puede validar equivalencia funcional | Agregar tarea de reconciliación en H-AGO o H-SEP |
| 5 | **Geolocalización (WS4.1-WS4.2) asume ESRI disponible** | Geolitics está desconectada. Alto riesgo | Marcar como condicional o mover a fase posterior |
| 6 | **No hay tarea de conversión a SPs** | El framework batch requiere SPs, no scripts SQL planos | Agregar tarea de conversión scripts → SPs |

---

## 4. Cronograma Propuesto (Ajustado)

### Cronograma Visual de Workstreams:

```
                    MAY           JUN           JUL           AGO           SEP           OCT           NOV
                    ├─────────────┼─────────────┼─────────────┼─────────────┼─────────────┼─────────────┤

WS2: Arquitectura   ┌─────────┐ ┌─────┐
  + Contrato        │Workshop │ │Soporte│
                    │+ Contrato│ │      │
                    └─────────┘ └─────┘

WS3: Redshift       ┌─────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐ ┌─────┐
  (Datos + Lógica)  │Setup│ │  Validación │ │ Integración │ │  Precálculo │ │  Batch  │ │Go-  │
                    │+ Mock│ │  PoC + XPM  │ │ Datos Reales│ │  65-70M     │ │  E2E    │ │Live │
                    └─────┘ └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘ └─────┘

WS4: Orquestación            ┌─────────┐ ┌─────────────┐ ┌─────────┐ ┌─────────┐ ┌─────┐
  + Integración              │ Diseño  │ │ Integración │ │  Test   │ │  Test   │ │Soporte│
                             │Framework│ │ Framework   │ │  E2E    │ │  Carga  │ │     │
                             └─────────┘ └─────────────┘ └─────────┘ └─────────┘ └─────┘

─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─

Experian (WS1)      ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────┐
  EDF / Ingesta     │     EDF     │ │     EDF     │ │     EDF     │ │● IFR│
                    └─────────────┘ └─────────────┘ └─────────────┘ └─────┘

─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─

HITOS:              ◆ H-MAY       ◆ H-JUN       ◆ H-JUL       ◆ H-AGO       ◆ H-SEP       ◆ H-OCT  ◆ H-NOV
                    Contrato      Entorno       Unif+Ord      Datos         Precálculo    Batch     Go-Live
                    + Arq         + Mock        Validados     Reales        65-70M        Completo
                                                              (CRÍTICO)
```

### Hitos Propuestos (renombrados)

| Hito | Nombre propuesto | Sprint | Entregable clave |
|------|-----------------|:------:|-----------------|
| **H-MAY** | Contrato EDF↔Redshift Formalizado + Arquitectura Aprobada | S2 | Documento de contrato firmado + Arquitectura validada |
| **H-JUN** | Entorno Operativo + PoC Validada con Mock XPM | S4 | Redshift con datos mock del esquema XPM real |
| **H-JUL** | Unificación + Ordenamiento Completos y Validados (Mock) | S6 | 16 scripts + rollbacks ejecutados sin error con mock XPM |
| **H-AGO** | Integración EDF→Redshift con Datos Reales (PUNTO CRÍTICO) | S8 | Ejecución exitosa con subconjunto de datos reales |
| **H-SEP** | Precálculo 65-70M + Framework Batch Operativo | S10 | Scores calculados para toda la población + YAML en framework |
| **H-OCT** | Batch End-to-End + Certificación Funcional Experian | S12 | Proceso completo aprobado por Experian |
| **H-NOV** | Go-Live Producción + Inicio Garantía | S14 | Sistema en producción estable |

---

## 5. Tareas que Faltan en el Plan (Agregar)

| # | Tarea faltante | Workstream | Sprint sugerido | Justificación |
|---|---------------|:----------:|:---------------:|---------------|
| 1 | Validación de Unificación (R1, R2, R3) con datos mock XPM | WS3 | S3-S5 | Es el proceso más complejo y ya está migrado — falta validar con esquema XPM real |
| 2 | Conversión de scripts SQL a Stored Procedures | WS3 | S5-S6 | Framework batch solo invoca SPs, no scripts planos |
| 3 | Creación de YAML de definición para framework batch | WS4 | S6-S7 | Necesario para que el framework ejecute el proceso |
| 4 | Reconciliación Teradata vs Redshift | WS3 | S8-S9 | Validar equivalencia funcional con datos reales |
| 5 | Localización y análisis de 12 SPs PRO_ORD_* | WS3 | S1-S2 | Bloqueante para ordenamiento completo |
| 6 | Migración de Indicadores de Movilidad (P0029) | WS3 | S5-S7 | Proceso pendiente, parte del ordenamiento |
| 7 | Completar consolidación/persistencia (06_consolidacion) | WS3 | S3-S4 | Script incompleto (falta orden anterior, fecha, lote) |

---

## 6. Tareas que Deberían Reordenarse

| Tarea | Posición actual | Posición sugerida | Razón |
|-------|:---------------:|:-----------------:|-------|
| WS3.3.1-WS3.3.5 (Ordenamiento DIR) | S3-S6 | S3-S4 (solo validación) | Ya está migrado. Solo necesita validación con mock XPM |
| WS3.3.6-WS3.3.8 (Ordenamiento TEL/EMA) | S4-S6 | S3-S4 (solo validación) | Ya está migrado. Solo necesita validación |
| WS4.3.1-WS4.3.6 (Step Functions) | S7-S10 | S6-S8 | No es "implementar desde cero" sino "integrar con framework existente" — menos esfuerzo |
| WS4.1-WS4.2 (Geolocalización) | S5-S10 | Condicional / Fase 2 | Depende de que Experian reactive Geolitics — no bloquear ruta crítica |

---

## 7. Dependencias Externas (No controladas por Macondotek)

| ID | Dependencia | Responsable | Fecha límite | Impacto si falla |
|:--:|-------------|-------------|:------------:|-----------------|
| D1 | Código fuente Teradata completo (12 SPs PRO_ORD_*) | Experian (John Bueno) | S2 (mayo) | Ordenamiento incompleto |
| D2 | Contrato de campos EDF↔Redshift validado | Experian (Adriana + Ingesta) | S2 (mayo) | No se puede construir vistas sobre XPM |
| D3 | IFR operativo con datos de Reconocer | Experian (equipo IFR) | S7 (agosto) | Todo desde H-AGO se bloquea |
| D4 | Catálogos cargados vía Colibrí | Experian | S3 (junio) | Unificación y Ordenamiento no funcionan |
| D5 | Framework Batch desplegado en ambiente Reconocer | Oscar (Macondotek) | S6 (julio) | No se puede probar orquestación |
| D6 | Permisos user_sp sobre schemas bdm_datos | Experian (infra) | S6 (julio) | Framework no puede invocar SPs |
| D7 | API ESRI/ArcGIS reactivada | Experian (Julián Méndez) | S5 (julio) | Regla 3 opera degradada, Geo no funciona |
| D8 | Datos anonimizados para reconciliación | Experian | S7 (agosto) | No se puede comparar TD vs RS |

---

*Documento generado: 6 de mayo de 2026 | Fuente: MT-EXP-F-031 + análisis de PoC + documentación del proyecto*
