# Plan de Trabajo – Francisco Peña | Proyecto Reconocer

> **Fecha**: 2026-04-17 | **Fuente**: reu_sync.md | **Dedicación**: 100%

---

## 0. Estructura de Carpetas en Resumen/

```
Resumen/
├── reu_sync.md                          ← Compromisos reunión con Wilmar y Molina
├── plan_trabajo_francisco.md            ← Este documento
├── checklist_progreso.md                ← Tracking de tareas completadas/pendientes
├── resumen_avance_teams.md              ← Resumen ejecutivo para presentar en Teams
├── contexto_tecnico/
│   ├── arquitectura_proyecto.md         ← Resumen de arquitectura EDF+Redshift
│   ├── inventario_codigo_fuente.md      ← Mapeo de scripts Teradata
│   └── decisiones_abiertas.md           ← Decisiones pendientes
├── unificacion/
│   ├── documento_funcional_v1.md        ← Conversión del .docx a MD (Tarea #10)
│   ├── analisis_scripts.md              ← Análisis técnico de P0019/P0020/P0021
│   ├── modelo_datos.md                  ← Modelo de datos con explicaciones por tabla
│   ├── mapeo_escenarios_codigo.md       ← Mapeo regla/escenario ↔ líneas de código
│   ├── criterios_validacion.md          ← 20 criterios técnicos de validación
│   └── prueba_regla1_redshift.md        ← POC Regla 1 ejecutada en Redshift (resultados)
├── ordenamiento/
│   └── analisis_scripts.md              ← Análisis técnico de P0027/P0029 + modelo scoring
└── preventa_consolidada/
    └── README.md                        ← Índice de docs de preventa relevantes
```

---

## 1. Contexto del Proyecto

**Qué es Reconocer**: Producto de Experian que estandariza y consolida datos de contacto (direcciones, teléfonos, emails) de ~65-70M ciudadanos colombianos. Genera rankings de contactabilidad para cobranza.

**Migración**: Teradata → AWS (EDF + Redshift)
- **EDF (Experian Data Fabric)**: Ingesta + Estandarización (8 etapas, Spark/Scala)
- **Redshift**: Ordenamiento + Cálculo + Exposición (SQL)

**Procesos prioritarios para Macondotek**:
1. **Unificación** (primer proceso a abordar) — consolida direcciones similares por persona
2. **Ordenamiento** (segundo proceso) — rankea datos de contacto por score

**3 aproximaciones de migración a probar (benchmark)**:

| # | Aproximación | Qué hace |
|---|-------------|----------|
| 1 | Prompt directo (IDE) | Pasar código Teradata a Redshift con prompt de IA |
| 2 | AWS Q Transform Custom | Alimentar Transform con código Teradata, generar análisis |
| 3 | Spec Driven Development | Extraer lógica → spec → diseño → implementación |

---

## 2. Alcance de Macondotek (Fases 2 y 3)

```
Fase 2: Estandarización en EDF (Spark/Scala)
├── 8 etapas: DANE → Tipificación → Limpieza → Acepciones → Normalización → Validación → Unificación → Geo
├── Implementación en etapa Curation del pipeline EDF
├── Campo nuevo en XPM (no modifica campo existente)
└── PINNING no se toca

Fase 3: Ordenamiento + Cálculo en Redshift (SQL)
├── Algoritmos de score para direcciones, teléfonos, emails
├── Indicadores de movilidad
├── Cálculo Reconocer general (precálculo 65-70M ciudadanos)
├── Modelo Batch + Control-M
└── Servicio en línea (DB2)
```

**Decisión pendiente**: ¿Ordenamiento en EDF (Spark) o Redshift (SQL)?

---

## 3. Tareas Asignadas a Francisco (reu_sync.md)

### Tarea #2: Crear workspaces Kiro para Unificación y Ordenamiento

**Objetivo**: Tener 2 workspaces Kiro independientes, uno por proceso, que sirvan como base de trabajo para la migración técnica.

**Diseño propuesto**:

```
reconocer-unificacion/          ← Workspace Kiro #1
├── .kiro/
│   └── steering/
│       └── context.md          ← Contexto del proceso de unificación
├── src/
│   ├── teradata/               ← Código fuente original Teradata
│   │   ├── P0019_UNIFICACION_*.TPT
│   │   ├── P0020_UNIFICACION_DIRECCION_*.TPT/.BTQ
│   │   ├── P0021_UNIFICACION_*.TPT
│   │   └── vistas/             ← V_Insumo_Unificacion_Regla*.txt
│   └── redshift/               ← Código migrado (destino)
├── docs/
│   ├── funcional/              ← Doc funcional unificación (MD)
│   ├── tecnico/                ← Análisis técnico de scripts
│   └── benchmark/              ← Resultados de las 3 aproximaciones
├── data/
│   ├── parametros/             ← Tablas de acepciones, nomenclaturas
│   └── diccionarios/           ← Diccionarios de complementos y vías
└── README.md

reconocer-ordenamiento/         ← Workspace Kiro #2
├── .kiro/
│   └── steering/
│       └── context.md          ← Contexto del proceso de ordenamiento
├── src/
│   ├── teradata/               ← Código fuente original Teradata
│   │   ├── P0027_UBI_ORDENAMIENTO_*.TPT
│   │   ├── P0029_INDICADORES_MOVILIDAD_*.TPT
│   │   ├── ORDENAMIENTO_242_131.BTQ
│   │   └── BTEQ_CURSOR_131.BTQ
│   └── redshift/               ← Código migrado (destino)
├── docs/
│   ├── funcional/              ← Doc funcional ordenamiento
│   ├── tecnico/                ← Análisis técnico de scripts
│   └── benchmark/              ← Resultados de las 3 aproximaciones
├── data/
│   ├── parametros/             ← Tablas de parámetros
│   └── db/                     ← DDLs de tablas
└── README.md
```

**Archivos fuente disponibles**:

| Proceso | Archivos | Ubicación actual |
|---------|----------|-----------------|
| Unificación | P0019_*.TPT, P0020_*.TPT/.BTQ, P0021_*.TPT, vistas .txt, Tipo_Via.txt | `Experian Reconocer/Unificacion/` |
| Ordenamiento | P0027_*.TPT, P0029_*.TPT, ORDENAMIENTO_242_131.BTQ, BTEQ_CURSOR_131.BTQ, Caracteristicas.txt | `Experian Reconocer/Ordenamiento/` |

**Convención de nombres de scripts Teradata**:
- `_111` = BTEQ paso 1 (creación de tablas/vistas)
- `_120` = TPT paso 2 (carga de datos)
- `_130` = TPT paso 3 (transformación principal)
- `_140` = TPT paso 4 (exportación/resultado)
- `_141` = TPT paso adicional

**Pasos de ejecución**:
1. Crear directorios base para ambos workspaces
2. Inicializar `.kiro/steering/context.md` con contexto específico de cada proceso
3. Copiar código fuente Teradata a `src/teradata/`
4. Crear estructura de `docs/` y `data/`
5. Generar README.md con índice y guía de navegación

---

### Tarea #3: Consolidar documentación de preventa en los workspaces

**Objetivo**: Que cada workspace tenga toda la documentación relevante de preventa para que la IA y el equipo tengan contexto completo.

**Documentación disponible en preventa** (`[EXP-005] EXPERIAN - MAP RECONOCER/`):

| Tipo | Archivos clave | Destino |
|------|---------------|---------|
| Contexto general | `entregables/01_contexto_proyecto.md` | Ambos workspaces |
| Fases técnicas | `entregables/02_fases_tecnicas.md` | Ambos workspaces |
| Roles | `entregables/03_roles_identificados.md` | Ambos workspaces |
| WBS | `entregables/04_wbs_inicial.md` | Ambos workspaces |
| Riesgos | `entregables/05_riesgos_supuestos.md` | Ambos workspaces |
| Mapa mental | `entregables/mapa_mental_proyecto.md` | Ambos workspaces |
| Reuniones técnicas | `comunicaciones/*.md` (9 transcripciones/resúmenes) | Según relevancia |
| Doc funcional estandarización | `docs/Documento Funcional Estandarizacion Final V1.0 2.docx` | Workspace Unificación |
| Doc funcional unificación | `docs/Documento Funcional Unificacion Final V1.0 2.docx` | Workspace Unificación |
| Plan migración AWS | `docs/PlanMigracionAWS 2.xlsx` | Ambos workspaces |
| Diagrama arquitectura | `diagramas/Reconocer_EDF_Reshift 1.drawio` | Ambos workspaces |

**Comunicaciones relevantes por proceso**:

Para **Unificación**:
- `transcripcion_reunion_reconocer_sesion_funcional_20260325.md` — versiones, canales, fuentes
- `resumen_workshop_tecnico_migracion_reconocer_20260326.md` — carga ICBIR, estandarización
- `transcripcion_llamada_edf_ingesta_20260319.md` — definición Curation, campo nuevo

Para **Ordenamiento**:
- `resumen_reunion_experian_arquitectura_20260316.md` — arquitectura y planificación
- `resumen_reunion_interna_macondotek_20260317.md` — asignaciones y estrategia
- `resumen_workshop_tecnico_migracion_reconocer_20260326.md` — validaciones

**Pasos de ejecución**:
1. Copiar entregables comunes a `docs/preventa/` en ambos workspaces
2. Copiar comunicaciones relevantes a `docs/comunicaciones/` según proceso
3. Copiar documentos funcionales (docx) al workspace correspondiente
4. Crear `docs/preventa/README.md` con índice de documentación consolidada

---

### Tarea #10: Convertir documento funcional unificación V1 (docx) a MD

**Objetivo**: Tener el documento funcional en formato Markdown para que sea consumible por herramientas de IA y versionable en Git.

**Archivo fuente**: `Experian Reconocer/Unificacion/Documento Funcional Unificacion Final V1.0.docx` (1MB)

**Nota**: También existe una copia en preventa: `[EXP-005]/docs/Documento Funcional Unificacion Final V1.0 2.docx`

**Contenido esperado del documento** (basado en análisis de preventa):
- 3 reglas de unificación de direcciones
- Regla 1: Unificación por tipo de uso + CIIU
- Regla 2: Unificación por complementos (genera nuevas direcciones)
- Regla 3: Unificación por geolocalización
- Concepto Padre-Hijo
- Diccionarios de complementos y vías
- Escenarios y subcasos por regla

**Diseño del MD resultante**:

```
docs/funcional/documento_funcional_unificacion_v1.md
├── # Documento Funcional - Proceso de Unificación V1.0
├── ## 1. Objetivo del Proceso
├── ## 2. Alcance
├── ## 3. Regla 1: Unificación por Tipo de Uso y CIIU
│   ├── ### 3.1 Descripción
│   ├── ### 3.2 Escenarios
│   └── ### 3.3 Ejemplos
├── ## 4. Regla 2: Unificación por Complementos
│   ├── ### 4.1 Descripción
│   ├── ### 4.2 Diccionario de Complementos
│   ├── ### 4.3 Escenarios
│   └── ### 4.4 Generación de Nuevas Direcciones
├── ## 5. Regla 3: Unificación por Geolocalización
│   ├── ### 5.1 Descripción
│   ├── ### 5.2 Diccionario de Vías
│   └── ### 5.3 Escenarios
├── ## 6. Reglas Generales
│   ├── ### 6.1 Concepto Padre-Hijo
│   ├── ### 6.2 Cascada de Reglas
│   └── ### 6.3 Restricciones
└── ## 7. Tablas y Parámetros
```

**Pasos de ejecución**:
1. Extraer contenido del .docx (pandoc o python-docx)
2. Limpiar y estructurar en Markdown
3. Preservar tablas, diagramas y fórmulas
4. Validar que no se pierda información
5. Colocar en `docs/funcional/` del workspace de Unificación

---

## 4. Orden de Ejecución Recomendado

```
Semana 1 (actual):
  ① Tarea #10: Convertir doc funcional unificación a MD
     → Destino: Resumen/unificacion/documento_funcional_v1.md
     → Prerequisito para tener contexto en el workspace

  ② Generar contexto técnico del proyecto
     → Destino: Resumen/contexto_tecnico/
     → Arquitectura, inventario de código, decisiones abiertas

Semana 2:
  ③ Tarea #2: Diseñar workspaces Kiro (Unificación + Ordenamiento)
     → Destino: Resumen/unificacion/workspace_design.md
     → Destino: Resumen/ordenamiento/workspace_design.md
     → Análisis de scripts Teradata por proceso

  ④ Tarea #3: Consolidar documentación de preventa
     → Destino: Resumen/preventa_consolidada/
     → Índice con referencias a docs en [EXP-005]

  ⑤ Crear los workspaces Kiro en repositorios Azure
     → Depende de que Molina cree los repos (Tarea #1)
```

---

## 5. Dependencias e Insumos Pendientes

| Insumo | Fuente | Estado | Impacto |
|--------|--------|--------|---------|
| Malla Control-M (orden ejecución) | Experian (Melissa) | Pendiente | Crítico para entender flujo |
| Mapeo tablas Redshift del XPM | Molina (Confluence) | Por compartir | Necesario para diseño destino |
| Versión Redshift desplegada | Por confirmar | Pendiente | Afecta compatibilidad SQL |
| Transcripciones reuniones unificación/ordenamiento | Experian (Janeth) | Pendiente | Contexto funcional adicional |
| Demo AWS Q Transform Custom | Harold (AWS) | Por agendar | Benchmark aproximación #2 |
| Framework orquestación Lambda | Oscar (Macondotek) | Por agendar | Contexto de ejecución |

---

## 6. Contexto Técnico del Código Fuente

### Unificación (Experian Reconocer/Unificacion/)

| Archivo | Tipo | Paso | Descripción probable |
|---------|------|------|---------------------|
| P0019_UNIFICACION_111.TPT | TPT | 1 | Setup/creación tablas unificación regla base |
| P0019_UNIFICACION_120.TPT | TPT | 2 | Carga de datos para unificación |
| P0019_UNIFICACION_130.TPT | TPT | 3 | Transformación principal (reglas) |
| P0019_UNIFICACION_130_20240730.TPT | TPT | 3 | Versión con fecha (backup/variante) |
| P0019_UNIFICACION_140.TPT | TPT | 4 | Exportación/resultado |
| P0020_UNIFICACION_DIRECCION_111.BTQ | BTEQ | 1 | Setup unificación de direcciones |
| P0020_UNIFICACION_DIRECCION_120.BTQ | BTEQ | 2 | Carga datos dirección |
| P0020_UNIFICACION_DIRECCION_130.TPT | TPT | 3 | Transformación direcciones |
| P0020_UNIFICACION_DIRECCION_140.BTQ | BTEQ | 4 | Resultado direcciones |
| P0020_CreaDicNomenclaturaReg2_131.BTQ | BTEQ | 3+ | Creación diccionario nomenclatura Regla 2 |
| P0020_CARGA_INSUMO_UNI_REG2_131.BTQ | BTEQ | 3+ | Carga insumos Regla 2 |
| P0021_UNIFICACION_111.BTQ → no existe, es TPT | TPT | 1 | Setup unificación adicional |
| P0021_UNIFICACION_120.TPT | TPT | 2 | Carga |
| P0021_UNIFICACION_130.TPT | TPT | 3 | Transformación |
| P0021_UNIFICACION_140.TPT | TPT | 4 | Resultado |
| V_Insumo_Unificacion_Regla1.txt | Vista | — | DDL vista insumo Regla 1 |
| V_Insumo_Unificacion_Regla2.txt | Vista | — | DDL vista insumo Regla 2 |
| V_Insumo_Unificacion_Regla3.txt | Vista | — | DDL vista insumo Regla 3 |
| VM_Reporte_Relacion_Pers_Ubi.txt | Vista | — | Vista materializada relación persona-ubicación |
| Tipo_Via.txt | Datos | — | Catálogo de tipos de vía |

### Ordenamiento (Experian Reconocer/Ordenamiento/)

| Archivo | Tipo | Paso | Descripción probable |
|---------|------|------|---------------------|
| P0027_UBI_ORDENAMIENTO_111.TPT | TPT | 1 | Setup ordenamiento ubicaciones |
| P0027_UBI_ORDENAMIENTO_120.TPT | TPT | 2 | Carga datos |
| P0027_UBI_ORDENAMIENTO_130.TPT | TPT | 3 | Transformación/score |
| P0027_UBI_ORDENAMIENTO_140.TPT | TPT | 4 | Resultado |
| P0029_INDICADORES_MOVILIDAD_111.BTQ | BTEQ | 1 | Setup indicadores movilidad |
| P0029_INDICADORES_MOVILIDAD_120.TPT | TPT | 2 | Carga datos movilidad |
| P0029_INDICADORES_MOVILIDAD_130.TPT | TPT | 3 | Cálculo indicadores |
| P0029_INDICADORES_MOVILIDAD_140.TPT | TPT | 4 | Resultado |
| ORDENAMIENTO_242_131.BTQ | BTEQ | 3+ | Lógica de ordenamiento (242 = ¿proceso?) |
| BTEQ_CURSOR_131.BTQ | BTEQ | 3+ | Cursor para procesamiento iterativo |
| Caracteristicas.txt | Datos | — | Catálogo de características (133KB) |

### Subcarpetas DB/ (en ambos procesos)
Contienen DDLs de tablas de base de datos usadas por cada proceso.

---

## 7. Próximos Pasos Inmediatos

1. **Hoy**: Convertir `Documento Funcional Unificacion Final V1.0.docx` a `Resumen/unificacion/documento_funcional_v1.md`
2. **Hoy**: Generar `Resumen/contexto_tecnico/` con arquitectura, inventario y decisiones
3. **Semana próxima**: Diseñar workspaces Kiro → `Resumen/unificacion/workspace_design.md` y `Resumen/ordenamiento/workspace_design.md`
4. **Semana próxima**: Consolidar preventa → `Resumen/preventa_consolidada/`
5. **Continuo**: Profundizar análisis técnico de scripts Teradata → `Resumen/unificacion/analisis_scripts.md` y `Resumen/ordenamiento/analisis_scripts.md`

---

*Documento generado el 2026-04-17. Actualizar conforme avancen las tareas.*
