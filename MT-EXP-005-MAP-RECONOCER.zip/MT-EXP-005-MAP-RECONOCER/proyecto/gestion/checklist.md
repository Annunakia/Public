# Checklist de Progreso – Proyecto Reconocer

> Última actualización: 2026-04-17 | Responsable: Francisco Peña

---

## TAREAS DEL REU_SYNC.MD

- [x] Tarea #10: Convertir documento funcional unificación V1 (docx) a MD
- [x] Tarea #2: Crear workspace Kiro para unificación y ordenamiento
- [x] Tarea #3: Consolidar documentación de preventa en los workspaces

---

## UNIFICACIÓN

### Entendimiento y Diseño

- [x] Documento funcional convertido a MD (`documento_funcional_v1.md`)
- [x] Modelo de datos con explicaciones de cada tabla (`modelo_datos.md`)
- [x] Árbol de descomposición: reglas → escenarios → subcasos
- [x] Análisis técnico de scripts (`analisis_scripts.md`)
- [x] Separar SPs del DDL en archivos individuales (MOTOR_TMP, MOTOR_TMP_V2, UnificacionR2)
- [x] Mapeo escenario ↔ líneas de código (`mapeo_escenarios_codigo.md`)
- [x] Recomendación de aproximación de migración por escenario
- [x] Workspace Kiro armado con código + docs + preventa

### Migración (pendiente — no depende de nadie)

- [x] Crear datos mock que cubran todos los escenarios de las 3 reglas
- [x] Definir criterios de validación (resultado esperado por cada persona mock)
- [x] Migrar Regla 1 a Redshift SQL (POC — aproximación prompt directo)
- [x] Migrar Regla 2 Escenarios 1-2 a Redshift SQL (prompt directo)
- [x] Migrar Regla 2 Escenario 4 a Redshift SQL (prompt directo + ajustes)
- [x] Migrar Regla 2 Escenarios 3, 5, 6 a Redshift SQL (spec driven — reescritura del MOTOR_TMP)
- [ ] Migrar Regla 3 a Redshift SQL
- [ ] Validar resultados contra datos mock

### Benchmark de aproximaciones (pendiente)

- [ ] Probar aproximación 1: Prompt directo (IDE) con Regla 1
- [ ] Probar aproximación 2: AWS Q Transform Custom (depende de demo con Harold)
- [ ] Probar aproximación 3: Spec Driven Development con Regla 2
- [ ] Documentar resultados del benchmark

### Bloqueado por dependencias externas

- [ ] Mapeo de tablas Redshift del XPM (Molina → Confluence)
- [ ] Malla de Control-M — orden de ejecución real (Molina → Experian/Melissa)
- [ ] Contrato de campos requeridos en tablas Redshift (Experian, deadline 15 mayo)
- [ ] Demo AWS Q Transform Custom (Harold/AWS, Molina coordina)
- [ ] Repos en Azure DevOps (Molina — Tarea #1 del reu_sync.md)

---

## ORDENAMIENTO

### Entendimiento y Diseño

- [x] Análisis técnico de scripts (`analisis_scripts.md`)
- [x] Análisis de Caracteristicas.txt — modelo de scoring descifrado
- [x] Workspace Kiro armado con código + docs + preventa
- [ ] Modelo de datos presentable con explicaciones (como el de unificación)
- [ ] Mapeo de características por canal (TEL, CEL, EMA, DIR) con rangos y betas

### Migración (pendiente — no depende de nadie)

- [ ] Crear datos mock para scoring (4 canales)
- [ ] Migrar SQL de Caracteristicas.txt a Redshift (traducción directa)
- [ ] Migrar P0027_111 (consolidación de scores) a Redshift
- [ ] Migrar P0027_130 (persistencia) a Redshift
- [ ] Analizar P0029 (indicadores de movilidad) en detalle
- [ ] Localizar los 12 SPs de PRO_ORD_* (no están en archivos disponibles)

### Bloqueado por dependencias externas

- [ ] Mapeo de tablas Redshift (mismo que unificación)
- [ ] Tablas de coeficientes Beta (V_Beta_Ordenamiento_*) — necesitamos los valores reales
- [ ] Framework de orquestación Lambda (Oscar/Macondotek, por agendar)

---

## CONTEXTO GENERAL

### Documentación generada

- [x] Plan de trabajo Francisco (`plan_trabajo_francisco.md`)
- [x] Arquitectura del proyecto (`arquitectura_proyecto.md`)
- [x] Inventario de código fuente (`inventario_codigo_fuente.md`)
- [x] Decisiones abiertas (`decisiones_abiertas.md`)
- [x] Índice de preventa consolidada (`preventa_consolidada/README.md`)

### Pendiente general

- [ ] Convertir documento funcional estandarización (docx) a MD
- [ ] Resumen ejecutivo para sincronización semanal
- [ ] Documento de mapeo Teradata → Redshift (equivalencias de funciones, tipos de datos)
- [ ] Preparar preguntas para sesión con Harold (AWS Q Transform)

### Decisiones pendientes

- [ ] ¿Ordenamiento en EDF (Spark) o Redshift (SQL)? — workshop con arquitectura
- [ ] Estrategia de estandarización: Libpostal vs migración UDFs — pendiente POC
- [ ] Qué aproximación de migración usar para cada componente — pendiente benchmark

---

## RESUMEN DE ESTADO

| Área | Entendimiento | Migración | Bloqueantes |
|------|:------------:|:---------:|:-----------:|
| Unificación | ✅ Completo | ⏳ Por iniciar | Mapeo Redshift, repos Azure |
| Ordenamiento | 🟡 80% | ⏳ Por iniciar | Mapeo Redshift, Betas, 12 SPs |
| Estandarización | ℹ️ Fuera de alcance inmediato (va a EDF) | — | — |
| Geolocalización | ❌ No analizado (desconectada) | — | — |
| Novedades | ❌ No analizado | — | — |

---

*Actualizar este checklist conforme avancen las tareas.*
