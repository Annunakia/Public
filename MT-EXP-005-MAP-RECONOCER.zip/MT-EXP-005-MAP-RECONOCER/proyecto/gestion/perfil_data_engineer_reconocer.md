# Perfil: Data Engineer — Migración Reconocer

> Proyecto: MT-EXP-005-MAP-RECONOCER | Cliente: Experian Colombia
> Dedicación: 100% | Duración: 6 meses (mayo – noviembre 2026)

---

## Contexto

Migración del sistema Reconocer de Teradata a Amazon Redshift. Procesa ~65-70M registros de datos de contacto. El candidato trabajará bajo la dirección de un líder técnico senior que define arquitectura, revisa entregables y gestiona dependencias con el cliente. La generación de código se apoya en herramientas de IA (Kiro, Cursor) — el candidato debe saber usarlas y gobernar su output.

## Responsabilidades

- Migrar stored procedures y scripts SQL de Teradata a Redshift (Unificación: 3 reglas, 12 escenarios; Ordenamiento: 4 canales de scoring)
- Diseñar e implementar orquestación batch con AWS Step Functions + Lambda
- Crear y mantener datos de prueba (mock + sintéticos) para validación
- Ejecutar pruebas en sandbox Redshift, documentar bugs y correcciones
- Implementar rollbacks y scripts de deploy siguiendo estándar del cliente
- Reconciliar resultados Redshift vs Teradata cuando haya datos disponibles
- Generar código asistido por IA, revisarlo y asegurar que cumple specs

## Requisitos técnicos

| Área | Requerido | Deseable |
|------|-----------|----------|
| SQL analítico | Window functions, CTEs, JOINs complejos, CASE WHEN anidados | Experiencia con SQL dinámico |
| Amazon Redshift | DISTKEY/SORTKEY, encoding, ANALYZE, schemas, permisos | Redshift Serverless, Spectrum |
| Teradata SQL | Leer y entender código existente (QUALIFY, COLLECT STATS, SET tables) | Haber migrado desde Teradata |
| AWS Step Functions | Diseño de máquinas de estado, manejo de errores, reintentos | Integración con EventBridge |
| AWS Lambda | Python/Node para tareas auxiliares de orquestación | Layers, timeouts, concurrencia |
| Python | Generación de datos sintéticos, scripts de validación | pandas, boto3 |
| Git | Branching, PRs, commits descriptivos | Azure DevOps |
| IA como herramienta | Experiencia con Cursor, Copilot, Kiro o similar para generación de código | Spec Driven Development |

## Perfil

- 3-5 años de experiencia en ingeniería de datos
- Experiencia comprobada en migración de plataformas de datos (cualquier origen → cloud)
- SQL como lenguaje principal de trabajo (no solo consultas — transformaciones complejas, lógica de negocio en SQL)
- Capacidad de leer código legacy sin documentación y entender la lógica de negocio
- Autonomía para ejecutar tareas definidas, criterio para escalar cuando hay ambigüedad
- Español fluido (comunicación directa con cliente colombiano)

## Lo que NO es este rol

- No define arquitectura (eso lo hace el líder técnico)
- No toma decisiones de negocio (eso lo valida el experto funcional de Experian)
- No gestiona al cliente (eso lo hace el PM)
- No escribe código desde cero sin contexto — trabaja con specs, steering files y código fuente Teradata como referencia

## Stack del proyecto

```
Origen:    Teradata SQL + UDFs en C + Control-M
Destino:   Amazon Redshift (SQL) + Step Functions + Lambda
Repo:      Azure DevOps (Git)
IA:        Kiro CLI + Cursor
Datos:     ~65-70M registros, 4 canales (dirección, teléfono, celular, email)
```

---

## Oferta de Empleo — Para publicación en plataformas de reclutamiento

### Data Engineer — Migración de Datos a AWS (Remoto)

**Empresa**: Macondotek | **Ubicación**: Remoto (Colombia) | **Contrato**: 6 meses | **Dedicación**: Tiempo completo

---

**Sobre el proyecto**

Buscamos un Data Engineer para un proyecto de migración tecnológica de alto impacto en el sector financiero colombiano. Migraremos un sistema que procesa la base histórica de datos de contacto de más de 65 millones de personas, desde una plataforma legacy (Teradata) hacia Amazon Redshift en AWS.

No es un proyecto de desarrollo desde cero — es transformar lógica de negocio existente en SQL moderno, apoyándote en herramientas de inteligencia artificial para acelerar la generación de código. Trabajarás con un líder técnico senior que ya validó la viabilidad del enfoque en una prueba de concepto exitosa.

---

**¿Qué vas a hacer?**

- Migrar procedimientos almacenados y scripts SQL de Teradata a Amazon Redshift
- Implementar algoritmos de scoring y reglas de negocio en SQL analítico (window functions, CTEs, JOINs complejos)
- Diseñar e implementar orquestación de procesos batch con AWS Step Functions y Lambda
- Crear datos de prueba, ejecutar validaciones en sandbox y documentar resultados
- Usar herramientas de IA (Kiro, Cursor) para generar código — tu rol es revisar, ajustar y asegurar calidad

---

**¿Qué necesitas?**

Obligatorio:
- 3+ años de experiencia en ingeniería de datos
- SQL avanzado como herramienta principal de trabajo (no solo consultas — transformaciones, lógica de negocio, window functions, CTEs)
- Experiencia con Amazon Redshift
- Experiencia en al menos una migración de plataforma de datos (cualquier origen → cloud)
- Capacidad de leer código SQL legacy y entender qué hace sin documentación completa
- Python básico (scripts de validación, generación de datos)
- Git (commits, branches, PRs)
- Español nativo o fluido

Suma puntos:
- Experiencia con Teradata SQL (QUALIFY, COLLECT STATISTICS, tablas SET/MULTISET)
- AWS Step Functions y Lambda
- Herramientas de IA para desarrollo (Cursor, Copilot, Kiro o similar)
- Experiencia en sector financiero o buró de crédito
- Azure DevOps

---

**¿Qué ofrecemos?**

- Proyecto con impacto real: migrar un sistema que toca los datos de contacto de toda la población colombiana bancarizada
- Trabajo con IA como herramienta de productividad — no como reemplazo, sino como acelerador bajo tu criterio técnico
- Equipo pequeño y senior — sin burocracia, con autonomía
- Líder técnico que ya hizo la prueba de concepto y tiene el camino mapeado
- Remoto 100%
- Contrato por 6 meses con posibilidad de extensión

---

**Stack tecnológico**

`Amazon Redshift` · `AWS Step Functions` · `AWS Lambda` · `Teradata SQL (lectura)` · `Python` · `Git` · `Kiro / Cursor IA` · `Azure DevOps`

---

*Para aplicar, envía tu CV y un breve párrafo explicando tu experiencia más relevante en migración de datos.*
