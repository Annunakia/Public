# Insumos Pendientes de Experian — Proyecto Reconocer

> **Fecha**: 4 de mayo de 2026 | **Autor**: Francisco Peña | **Macondotek**
> **Proyecto**: MT-EXP-005-MAP-RECONOCER
> **Objetivo**: Documentar cada insumo que Macondotek necesita de Experian para continuar la migración de Unificación y Ordenamiento a Redshift. Cada ítem incluye qué es, por qué lo necesitamos y qué se bloquea sin él.

---

## Bloqueantes — Sin estos no podemos ejecutar en ambiente Experian

---

### 1. Mapeo de tablas Redshift del XPM (Confluence)

**¿Qué es?**
Un documento o diagrama que muestre cómo están organizadas las tablas del XPM (eXperian Person Model) dentro del Redshift de Experian. Específicamente: nombres de tablas, nombres de columnas, tipos de datos, y relaciones entre ellas. Esto es lo que resulta después de que EDF ejecuta el proceso de "Relationalize" (aplanar el JSON del XPM en tablas relacionales).

**¿Por qué lo necesitamos?**
En la PoC trabajamos con tablas propias (`bdm_datos.insumo_direccion`, etc.) que creamos nosotros con datos mock. Para ejecutar en el ambiente real de Experian, necesitamos saber exactamente de qué tablas y columnas leer los datos que ya están en el Redshift de producción. Sin este mapeo, no podemos escribir los queries que conectan nuestro código migrado con los datos reales.

**¿Qué se bloquea sin él?**
- Unificación: no podemos construir las vistas de insumo (V_Insumo_Regla1, Regla2, Regla3)
- Ordenamiento: no podemos poblar las tablas de insumo por canal (DIR, TEL, CEL, EMA)
- Ambos procesos quedan desconectados de los datos reales

**Proceso afectado**: Ambos (Unificación + Ordenamiento)

**Responsable sugerido**: Juan Carlos Molina

---

### 2. Contrato de campos validado y firmado

**¿Qué es?**
Un acuerdo formal entre el equipo de Ingesta (EDF) y el equipo de Redshift (Macondotek) que define exactamente qué campos entrega EDF después de la estandarización, con qué nombres, tipos de datos, y semántica de negocio. Es el "contrato de interfaz" entre las dos plataformas.

Ya tenemos un borrador en `proyecto/contrato_campos_edf_redshift.md` con 26 campos para Unificación y 33 para Ordenamiento. Necesitamos que Experian lo valide, ajuste si es necesario, y confirme que EDF va a producir esos campos.

**¿Por qué lo necesitamos?**
Sin un contrato validado, corremos el riesgo de que EDF entregue datos en un formato diferente al que esperamos, con nombres de campos distintos, o sin campos críticos. Esto generaría retrabajo cuando llegue la integración real (agosto 2026).

**¿Qué se bloquea sin él?**
- No podemos confirmar si los 5 campos bloqueantes de estandarización (complemento, tipo_via, via_principal, via_generadora, numero_puerta) van a existir
- No podemos diseñar las vistas de transformación XPM → tablas de insumo
- El equipo de EDF no sabe qué debe producir para Reconocer

**Proceso afectado**: Ambos

**Responsable sugerido**: Equipo de Ingesta (Adriana) + Juan Carlos Molina

**Deadline propuesto**: 15 de mayo de 2026

---

### 3. Catálogo de decodificación de `contacttype`

**¿Qué es?**
Una tabla o listado que diga qué valor numérico corresponde a cada tipo de uso de dirección. En el XPM de Redshift existe un campo llamado `contactinformations.val.contacttype` de tipo BIGINT. Necesitamos saber qué número significa "Residencial", cuál "Laboral", cuál "Correspondencia", etc.

En Teradata estos tipos se llaman RES, LAB, CRR, JUD, CCL y están en una tabla de catálogo `TIPO_UBICACION_DIR`. En el XPM de Redshift solo vemos un número entero sin decodificación.

**¿Por qué lo necesitamos?**
La Regla 1 de Unificación decide qué dirección queda como "padre" basándose en el tipo de uso combinado con la actividad económica (CIIU). Si una persona es asalariada (CIIU=10), se prefiere la dirección laboral. Si no podemos distinguir cuál es laboral y cuál es residencial, la regla no puede ejecutarse.

**¿Qué se bloquea sin él?**
- Regla 1 de Unificación completa (3 escenarios CIIU)
- Característica CO00DIR017 de Ordenamiento (tipo de uso como variable de scoring)

**Proceso afectado**: Unificación (R1) + Ordenamiento (DIR)

**Responsable sugerido**: Juan Carlos Molina / John Bueno

---

### 4. Código fuente de los 12 Stored Procedures PRO_ORD_*

**¿Qué es?**
Son 12 procedimientos almacenados de Teradata que ejecutan el pre-procesamiento de datos antes de que el scoring de ordenamiento pueda correr. Se llaman desde el script `ORDENAMIENTO_242_131.BTQ` y sus nombres son:

1. `PRO_ORD_MATERIALIZA_BTT`
2. `PRO_ORD_MATERIALIZA_REC`
3. `PRO_ORD_UNIF_BTT_REC`
4. `PRO_ORD_CTA_ATRIBUTOS`
5. `PRO_ORD_UBIC_DIRECCIONES`
6. `PRO_ORD_CTA_TOTALES_PERSONAS`
7. `PRO_ORD_CTA_TOTALES_PERSONAS_1`
8. `PRO_ORD_CALC_UBICACIONES`
9. `PRO_ORD_CALC_UBICACIONES_1`
10. `PRO_ORD_UNIF_BTT_REC_2`
11. `PRO_ORD_CTA_TOTALES_PERSONAS_2`
12. `PRO_ORD_CALC_UBICACIONES_2`

Más: `PRO_Cursor_Drop_TblaOrdenamiento` (limpieza de temporales).

Estos SPs no están en el dump de código fuente que nos entregaron (`Experian Reconocer/Ordenamiento/`). Probablemente están en el DDL de Estandarización (681KB) o directamente en Teradata sin haber sido exportados.

**¿Por qué lo necesitamos?**
Estos SPs preparan los datos antes del scoring: materializan vistas, unifican fuentes (BTT + REC), cuentan atributos por persona, y calculan ubicaciones. Sin entender qué hacen, no sabemos qué transformaciones aplicar a los datos reales antes de pasarlos por nuestros algoritmos de scoring. En la PoC esto no fue problema porque usamos datos mock ya preparados, pero con datos reales de producción necesitamos replicar ese pre-procesamiento.

**¿Qué se bloquea sin él?**
- Ordenamiento no puede funcionar con datos reales de producción
- No podemos diseñar el flujo completo de Step Functions (no sabemos qué pasos van antes del scoring)
- No podemos estimar el esfuerzo real de migración del ordenamiento completo

**Proceso afectado**: Ordenamiento

**Responsable sugerido**: Experian (acceso a Teradata para exportar DDLs) — John Bueno o David (tienen acceso a Control-M/Teradata)

---

### 5. Repositorios en Azure DevOps creados

**¿Qué es?**
Repositorios Git en la organización de Azure DevOps de Experian donde Macondotek pueda hacer push del código migrado, crear branches, hacer pull requests, y mantener versionamiento. Actualmente el código está en un repo interno de Macondotek (`MT-EXP-005-MAP-RECONOCER`) pero no en la infraestructura de Experian.

**¿Por qué lo necesitamos?**
Para que el código migrado sea accesible por el equipo de Experian (revisión, deploy, operación). También para seguir las prácticas de CI/CD del cliente y para que el código quede bajo la gobernanza de Experian una vez entregado.

**¿Qué se bloquea sin él?**
- No podemos hacer deploy formal en ambientes de Experian
- No hay trazabilidad del código para el equipo de operaciones de Experian
- No se puede hacer revisión de código por parte de Experian

**Proceso afectado**: Ambos

**Responsable sugerido**: Juan Carlos Molina

---

### 6. Definición: ¿El complemento de dirección se separa en EDF o en Redshift?

**¿Qué es?**
Una decisión técnica sobre dónde se ejecuta la lógica de separar una dirección completa en sus componentes (puerta vs complemento). Hoy en Teradata esto lo hace una UDF en C llamada `ADDRESS_NORMALIZATION`. En la nueva arquitectura, hay dos opciones:

- **Opción A**: EDF lo hace en la etapa de Curation (Spark/Scala) y entrega a Redshift los campos ya separados (`texto_ubicacion`, `complemento`, `tipo_via`, etc.)
- **Opción B**: EDF entrega la dirección completa en un solo campo y Redshift se encarga de separarla con lógica SQL

**¿Por qué lo necesitamos?**
La Regla 2 de Unificación compara complementos entre direcciones de una misma persona. Si el complemento no viene separado, Regla 2 no puede ejecutarse. La decisión define si Macondotek necesita implementar lógica de parsing de direcciones en Redshift (esfuerzo significativo) o si EDF la entrega lista.

En la reunión del 24/04 con John Bueno se confirmó que existe una UDF en C que hace esta separación. Quedó pendiente definir con Adriana y el equipo de proyecto si esa lógica se replica en EDF o en Redshift.

**¿Qué se bloquea sin él?**
- Regla 2 completa (6 escenarios + motor de nuevas direcciones)
- No podemos estimar esfuerzo de Redshift sin saber si nos toca parsear direcciones o no
- El contrato de campos no se puede cerrar sin esta decisión

**Proceso afectado**: Unificación (R2)

**Responsable sugerido**: Sesión conjunta Adriana + equipo de proyecto + Macondotek

---

## Necesarios — Se puede arrancar sin ellos pero se necesitan pronto

---

### 7. Datos reales anonimizados para pruebas

**¿Qué es?**
Un subconjunto de datos de producción (100,000 a 500,000 personas) con información personal anonimizada (nombres, cédulas reemplazados por valores ficticios) pero con la estructura y distribución real de los datos. Esto permite probar los algoritmos con la complejidad real del negocio (personas con 20+ direcciones, complementos exóticos, casos borde).

**¿Por qué lo necesitamos?**
Los datos mock (20 personas) validan lógica. Los sintéticos (5,000) validan volumen básico. Pero solo datos reales anonimizados permiten:
- Descubrir edge cases que no imaginamos
- Validar performance con distribuciones reales
- Reconciliar resultados Redshift vs Teradata (ejecutar ambos con el mismo dataset)

**Proceso afectado**: Ambos

**Responsable sugerido**: Experian (equipo de datos)

---

### 8. Coeficientes Beta reales (tablas V_Beta_Ordenamiento_*)

**¿Qué es?**
Los coeficientes de la regresión logística que pondera cada característica de scoring. Son 4 tablas (una por canal: DIR, TEL, CEL, EMA) con ~12 filas cada una. Cada fila tiene un código de característica y su peso (Beta). Estos valores fueron calibrados por el equipo de analítica de Experian y definen qué tan importante es cada variable para predecir contactabilidad.

**¿Por qué lo necesitamos?**
En la PoC usamos valores Beta inventados. Con valores reales, los scores tendrán la distribución correcta y podremos validar que el ranking coincide con lo que produce Teradata hoy.

**Proceso afectado**: Ordenamiento

**Responsable sugerido**: Experian / carga vía Colibrí

---

### 9. Catálogo NOMENCLATURA (89 registros reales)

**¿Qué es?**
Una tabla con 89 filas que define todas las nomenclaturas de direcciones colombianas (BR=Barrio, AP=Apartamento, TO=Torre, PI=Piso, MZ=Manzana, etc.) con su nivel jerárquico (1 a 7). El nivel determina la prioridad de cada nomenclatura en el complemento de una dirección.

**¿Por qué lo necesitamos?**
La Regla 2 de Unificación usa los niveles para decidir si dos complementos tienen nomenclaturas del mismo nivel (Escenario 4) o de diferente nivel (Escenarios 5 y 6). Sin los niveles correctos, la regla puede tomar decisiones equivocadas sobre qué dirección es "mejor".

**Proceso afectado**: Unificación (R2)

**Responsable sugerido**: Experian / carga vía Colibrí

---

### 10. Confirmación: ¿`mainisiccode` = CIIU colombiano?

**¿Qué es?**
Validar que el campo `personalinformation.val.mainisiccode` en el XPM contiene el mismo código CIIU (Clasificación Industrial Internacional Uniforme) que usaba Teradata. En Teradata el campo se llama `Cod_Act_Econo_CIIU_Fte` y tiene valores como 10 (Asalariado), 81/82/90 (Sin actividad), etc.

**¿Por qué lo necesitamos?**
La Regla 1 de Unificación tiene 3 escenarios que dependen del CIIU:
- CIIU=10 → prefiere dirección laboral
- CIIU=81,82,90 → prefiere dirección residencial
- Otro CIIU → mayor número de entidades

Si `mainisiccode` usa una codificación diferente (ej: ISIC internacional vs CIIU colombiano), los escenarios producirían resultados incorrectos.

**Proceso afectado**: Unificación (R1)

**Responsable sugerido**: Juan Carlos Molina / John Bueno

---

### 11. Confirmación: ¿`citycode` = código municipio DANE?

**¿Qué es?**
Validar que el campo `contactinformations.val.citycode` en el XPM contiene el código DANE colombiano de 8 dígitos (ej: 11001000 = Bogotá, 05001000 = Medellín). En Teradata se usa `Cod_DW_Ciudad` con formato DANE.

**¿Por qué lo necesitamos?**
Las 3 reglas de Unificación agrupan direcciones por ciudad. Si `citycode` usa un formato diferente (ej: código postal, código interno de Experian), las agrupaciones serían incorrectas y se compararían direcciones de ciudades diferentes.

El Ordenamiento también usa la ciudad para la característica de coincidencia geográfica (CO01TEL020, CO00DIR001).

**Proceso afectado**: Ambos

**Responsable sugerido**: Juan Carlos Molina

---

### 12. Confirmación: ¿pin XPM = pin Teradata?

**¿Qué es?**
Validar que el campo `xpm.pin` en Redshift tiene la misma semántica que `Cod_Pin_Persona` en Teradata. En Teradata, el PIN agrupa a una misma persona que puede aparecer con diferentes tipos de documento (ej: una empresa con NIT y su representante legal con CC). Es un "super-identificador" que une identidades.

**¿Por qué lo necesitamos?**
La Regla 2 de Unificación (Escenario 3 NIT) y el Ordenamiento usan el PIN para agrupar datos de una misma persona que tiene múltiples identificaciones. Si el PIN del XPM tiene una semántica diferente (ej: es un ID técnico sin relación con agrupación de persona), la lógica de agrupación fallaría.

En la reunión del 24/04 se mencionó que "el pin de Teradata no es el mismo que el de Redshift/XPM" — necesitamos confirmar cuál es la equivalencia correcta.

**Proceso afectado**: Ambos

**Responsable sugerido**: Juan Carlos Molina

---

### 13. Integración Geolitics (¿cómo funciona ahora?)

**¿Qué es?**
Definir cómo se va a hacer el enriquecimiento de geolocalización (latitud, longitud, puntos de interés) en la nueva arquitectura. Anteriormente se conectaba con un servicio de ESRI/ArcGIS llamado Geolitics vía API, enviando lotes de ~1 millón de direcciones. Esa integración está **desconectada** desde antes del proyecto.

**¿Por qué lo necesitamos?**
La Regla 3 de Unificación usa latitud y longitud para decidir cuál dirección es más confiable cuando dos direcciones difieren en vía generadora o número de puerta. Sin geolocalización, Regla 3 opera en modo degradado (solo por fecha y número de entidades, sin el subcaso 3 que es el más preciso).

**Proceso afectado**: Unificación (R3)

**Responsable sugerido**: Julián Méndez (Experian)

---

### 14. Framework de orquestación Lambda

**¿Qué es?**
Entender cómo Experian orquesta hoy los procesos batch en AWS (si ya tienen un framework de Step Functions + Lambda, convenciones de naming, manejo de errores, logging, etc.) para alinearnos con su estándar en vez de inventar uno propio.

**¿Por qué lo necesitamos?**
Si Experian ya tiene un patrón establecido para orquestación batch en AWS, debemos seguirlo para que el proceso de Reconocer sea operable por su equipo de infraestructura. Si no existe, debemos diseñarlo y validarlo con ellos.

**Proceso afectado**: Ambos (orquestación)

**Responsable sugerido**: Oscar (Macondotek) coordina con Experian

---

*Documento para compartir con Experian en reunión de sincronización.*
*Cada ítem resuelto nos acerca a la ejecución en ambiente real.*
