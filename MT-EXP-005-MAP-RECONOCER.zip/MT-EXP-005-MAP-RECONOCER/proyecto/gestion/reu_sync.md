
## Resumen de Decisiones y Tareas

### Procesos a migrar (Teradata → Redshift)

| Proceso | Estado | Prioridad |
|---------|--------|-----------|
| Estandarización | No aplica (va en IDF) | — |
| Unificación | Primer proceso a abordar | Alta |
| Ordenamiento | Segundo proceso a abordar | Alta |
| Geolocalización | Posterior, integración con Argus | Media |
| Novedades | Por confirmar en qué punto del flujo va | Pendiente |
| Precálculo y Cálculo | Posterior | Media |
| UDFs (programas C) | No aplica si se usa libPostal | — |

### Tres aproximaciones de migración a probar

| # | Aproximación | Descripción |
|---|-------------|-------------|
| 1 | Prompt directo (IDE) | Migración bruta: pasar programa Teradata a Redshift con prompt |
| 2 | AWS Q Transform Custom | Alimentar Transform con código Teradata, generar análisis/HTML |
| 3 | Spec Driven Development | Extraer lógica → especificación → diseño → implementación en Redshift |

### Roles definidos

| Persona | Rol | Dedicación |
|---------|-----|------------|
| Francisco | Construcción técnica, implementación, benchmark de aproximaciones | 100% |
| Molina | Habilitadores, contexto Redshift/XPM, gestión de insumos con Experian, skills de IA | 50% construcción |
| Wilmar | Estrategia del proyecto, acompañamiento | Parcial |

### Tareas inmediatas

| # | Tarea | Responsable |
|---|-------|-------------|
| 1 | Crear 2 repositorios en Azure (unificación, ordenamiento) | Molina |
| 2 | Crear workspace de Kiro para unificación y otro para ordenamiento | Francisco |
| 3 | Consolidar documentación de preventa en los workspaces | Francisco |
| 4 | Compartir Confluence con mapeo tablas Redshift del XPM | Molina |
| 5 | Gestionar insumo: malla de Control-M (orden de ejecución de programas) | Molina |
| 6 | Buscar transcripciones de reuniones de Experian sobre unificación/ordenamiento (preguntar a Janeth) | Molina |
| 7 | Sesión con Harold sobre AWS Q Transform Custom (demo 30-60 min) | Molina coordina |
| 8 | Sesión con Oscar sobre el framework de orquestación Lambda | Molina coordina |
| 9 | Consolidar contexto de Redshift/Experian desde proyecto Data Masking | Molina |
| 10 | Convertir documento funcional unificación V1 (docx) a MD | Francisco |
| 11 | Siguiente sincronización: viernes | Todos |

### Insumos pendientes

| Insumo | Fuente | Estado |
|--------|--------|--------|
| Malla de Control-M (orden de ejecución) | Experian (Melissa) | Pendiente |
| Transcripciones de reuniones sobre unificación/ordenamiento | Experian (Janeth) | Pendiente |
| Mapeo tablas Redshift del XPM (Confluence) | Molina | Por compartir |
| Versión de Redshift desplegada en Experian | Por confirmar | Pendiente |
| Contrato de campos requeridos en tablas Redshift (deadline 15 mayo) | Experian | Pendiente |
| Demo/guía de AWS Q Transform Custom | Harold (AWS) | Por agendar |
| Explicación del framework de orquestación Lambda | Oscar (Macondotek) | Por agendar |

### Decisiones clave

- Horas se cargan en Clockify como preventa hasta que se formalice el proyecto
- No formalizar con Lorena (PM) hasta que Experian confirme
- Wilmar habla con Lorena para informar que es trabajo exploratorio
- No implementar mejoras a reglas de negocio sin requerimiento escrito del cliente
