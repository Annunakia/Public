# Propuesta de Management — Migración Reconocer con IA

> **Fecha**: 27 de abril de 2026 | **Autor**: Francisco Peña | **Macondotek**
> **Proyecto**: MT-EXP-005-MAP-RECONOCER | **Cliente**: Experian Colombia
> **Versión**: 1.0 — De PoC a Ejecución Real

---

## Narrativa Ejecutiva

### Qué aprendimos con la PoC

En 3 semanas efectivas (2 de entendimiento + 1 de ejecución), migramos los dos procesos más complejos del sistema Reconocer — Unificación y Ordenamiento — de Teradata a Amazon Redshift. Los números hablan:

| Métrica | Resultado |
|---------|-----------|
| Líneas Teradata analizadas | ~19,500 |
| Líneas Redshift generadas | 3,080 |
| Ratio de compresión | 6.3:1 |
| Scripts SQL producidos | 16 + 9 rollbacks |
| Bugs encontrados y corregidos | 8 (tasa: 0.26/100 líneas) |
| Artefactos totales generados | 65 archivos (~9,260 líneas) |
| Personas validadas (mock + sintéticas) | 10,029 |

La PoC demostró tres cosas fundamentales:

1. **La IA genera código correcto a la primera iteración en el 80% de los casos**, siempre que tenga contexto suficiente (steering files, modelo de datos, reglas de negocio).

2. **El 20% complejo (SQL dinámico, cambio de paradigma) requiere diseño previo**, no más intentos de prompt. Spec Driven Development resolvió el componente más difícil del sistema (MOTOR_TMP: 870 líneas de SQL dinámico → 380 líneas de SQL estático) con solo 2 bugs.

3. **El código es solo el 25% del esfuerzo**. El 75% restante es entendimiento, documentación, datos de prueba y configuración del contexto IA — y es lo que hace que el código sea correcto.

### Por qué la migración debe manejarse con un enfoque industrializado

La PoC funcionó porque un líder técnico senior dedicó 100% de su tiempo a entender, decidir, revisar y validar. Eso no escala si queremos migrar los 6 procesos restantes del sistema (Estandarización, Geo, Novedades, Indicadores de Movilidad, Cálculo General, Batch/Servicio en Línea) con los mismos estándares de calidad.

Necesitamos pasar de "artesanía asistida por IA" a "línea de producción gobernada por humanos, ejecutada por IA". Eso significa:

- **Proceso repetible**: cada componente pasa por las mismas fases (inventario → spec → generación → revisión → pruebas → deploy).
- **Criterios de calidad estandarizados**: checklist de salida por componente, no criterio subjetivo.
- **Trazabilidad completa**: de código fuente Teradata → spec funcional → implementación Redshift → evidencia de pruebas.
- **Gobierno del uso de IA**: la IA genera, el humano aprueba. Nunca al revés.

### Por qué Spec Driven Development debe ser el centro del modelo

El prompt directo funciona para el 80% del código (SQL estándar, patrones repetitivos). Pero el 20% restante — que es donde están los bugs más costosos y las decisiones de arquitectura — necesita diseño previo.

La spec no es burocracia. Es el mecanismo que:
- Resuelve ambigüedades **antes** de escribir código (7 ambigüedades resueltas en MOTOR_TMP).
- Permite revisión de pares **antes** de ejecutar (20 correcciones aplicadas en comité simulado).
- Genera documentación **como subproducto** del desarrollo, no como tarea adicional.
- Crea trazabilidad automática: requirement → design → task → código → test.

### Rol del líder: gobernar, revisar, decidir, priorizar y asegurar calidad

Mi rol no es escribir código. Mi rol es:
- **Entender** la lógica funcional y técnica del código fuente.
- **Decidir** la aproximación correcta para cada componente (prompt directo vs spec driven).
- **Revisar** los entregables generados por IA antes de que lleguen a producción.
- **Priorizar** qué se migra primero según impacto y dependencias.
- **Gestionar** riesgos, bloqueantes, entornos y dependencias con Experian.
- **Asegurar** trazabilidad entre código fuente, especificaciones, implementación y pruebas.

### Propuesta concreta: de PoC a ejecución real

Pasar de la PoC a un modelo operativo con 7 fases, matriz de complejidad, gobierno de calidad y gestión de entornos. El detalle está en las secciones siguientes.

---

## 1. Lecciones Aprendidas de la PoC

### 1.1 Qué funcionó

| Práctica | Evidencia | Replicar |
|----------|-----------|----------|
| Steering files como contexto persistente | 11 archivos, 2,039 líneas. Cada conversación nueva arranca con contexto completo | ✅ Crear steering files por cada nuevo proceso |
| Prompt directo para SQL estándar | 14 scripts, ~180 líneas/hora, 0.22 bugs/100 líneas | ✅ Usar como aproximación por defecto |
| Spec driven para componentes complejos | MOTOR_TMP: 7 ambigüedades resueltas, 20 correcciones pre-código | ✅ Escalar cuando prompt falla 2+ veces |
| Datos mock antes de código | 20 personas diseñadas con resultado esperado → validación inmediata | ✅ Diseñar datos de prueba primero |
| Datos sintéticos para volumen | 5,000 personas → 0 errores en cascada completa | ✅ Generar para cada proceso |
| POC primero, replicar después | Ordenamiento DIR → TEL/CEL/EMA fue 3x más rápido | ✅ Identificar patrones repetitivos |
| Descomposición antes de migrar | Regla 2 (3,470 líneas) → 6 escenarios + 1 motor manejables | ✅ Descomponer todo componente >500 líneas |
| AGENTS.md como guardia | Evitó modificaciones al código fuente original | ✅ Mantener en todo el proyecto |

### 1.2 Qué riesgos aparecieron

| Riesgo | Cómo se manifestó | Mitigación aplicada |
|--------|-------------------|---------------------|
| SQL dinámico sin equivalente en Redshift | MOTOR_TMP: XMLAGG + DBC.COLUMNS + cursor | Spec driven: rediseño completo |
| Funciones nativas Teradata inexistentes | QUALIFY, OREPLACE, COLLECT STATISTICS | Tabla de equivalencias en skill reutilizable |
| Bugs solo visibles en ejecución | 8 bugs encontrados en sandbox, 0 en revisión de código | Validar siempre en sandbox con datos reales |
| Contexto insuficiente para la IA | Primeras iteraciones sin steering producían código genérico | Invertir en steering files al inicio |
| Ambigüedad en reglas de negocio | ¿Complemento concatenado con espacio o sin espacio? | Spec resuelve antes de codificar |

### 1.3 Qué se debe evitar

- **Prompt directo para componentes >500 líneas interconectadas**: la IA pierde contexto y genera código inconsistente.
- **Migrar sin datos de prueba diseñados**: el sandbox es el test definitivo, no la revisión visual del SQL.
- **Copiar SQL de Teradata y "adaptar"**: las diferencias de paradigma (SET vs MULTISET, QUALIFY, SQL dinámico) hacen que la adaptación sea más costosa que la reimplementación.
- **Asumir que la IA entiende el negocio**: la IA traduce sintaxis, no semántica. El entendimiento funcional es responsabilidad humana.

### 1.4 Por qué el prompt directo no escala

El prompt directo funciona cuando:
- El SQL es estándar (JOINs, CASE WHEN, window functions).
- El componente es autocontenido (<500 líneas).
- Existe un patrón ya validado que se puede replicar.

No funciona cuando:
- Hay SQL dinámico (EXECUTE IMMEDIATE, cursores que generan SQL).
- El componente tiene dependencias cruzadas con otros procesos.
- La lógica requiere cambio de paradigma (cursor → set-based).
- Hay ambigüedades funcionales que el código no resuelve.

En esos casos, más intentos de prompt producen más variantes incorrectas. La spec es el mecanismo para "parar, pensar, diseñar y luego generar".

---

## 2. Modelo Operativo del Proyecto

### 2.1 Workstreams

```
WS-1: ANÁLISIS Y ESPECIFICACIÓN
     → Entender lógica Teradata → Producir specs funcionales y técnicas
     → Responsable: Líder de migración + Experto funcional Experian

WS-2: GENERACIÓN ASISTIDA POR IA
     → Tomar specs → Generar código Redshift con Kiro/Cursor
     → Responsable: Ingeniero de datos + IA como ejecutor

WS-3: REVISIÓN Y VALIDACIÓN
     → Revisar código generado → Ejecutar en sandbox → Aprobar
     → Responsable: Líder de migración + QA de datos

WS-4: DATOS DE PRUEBA
     → Diseñar datos mock → Generar datos sintéticos → Reconciliar
     → Responsable: QA de datos + Ingeniero de datos

WS-5: GESTIÓN Y GOBIERNO
     → Riesgos, dependencias, entornos, comunicación con Experian
     → Responsable: Líder de migración
```

### 2.2 Responsabilidades: Humano vs IA

| Actividad | Responsable | IA como |
|-----------|-------------|---------|
| Entender lógica de negocio | Humano | Asistente de análisis (resumir, explicar código) |
| Decidir aproximación (prompt vs spec) | Humano | No participa |
| Escribir specs (requirements, design) | Humano + IA | IA genera borrador, humano revisa y aprueba |
| Generar código SQL Redshift | IA | Ejecutor principal |
| Revisar código generado | Humano | IA puede hacer revisión cruzada |
| Diseñar datos de prueba | Humano | IA genera datos sintéticos |
| Ejecutar pruebas en sandbox | Humano | IA puede generar scripts de validación |
| Aprobar entregable | Humano | No participa |
| Tomar decisiones de arquitectura | Humano | IA puede proponer opciones |
| Gestionar riesgos y dependencias | Humano | No participa |
| Documentar hallazgos | Humano + IA | IA genera borrador, humano valida |

### 2.3 Gobierno del uso de IA

| Regla | Descripción |
|-------|-------------|
| G1 | Todo código generado por IA debe ser revisado por un humano antes de merge |
| G2 | La IA no aprueba decisiones de arquitectura ni de negocio |
| G3 | Los steering files son propiedad del líder técnico — solo él los modifica |
| G4 | Las specs son el contrato entre el humano y la IA — el código debe cumplir la spec |
| G5 | Todo componente debe tener datos de prueba antes de generar código |
| G6 | Los bugs encontrados en sandbox se documentan y alimentan los steering files |
| G7 | No se usa IA para componentes con datos sensibles de producción sin anonimización |

### 2.4 Separación de fases por componente

```
ANÁLISIS          → Leer código Teradata, entender lógica, documentar hallazgos
ESPECIFICACIÓN    → Escribir spec (requirements + design) si complejidad ≥ Alta
GENERACIÓN        → IA produce código Redshift (prompt directo o desde spec)
REVISIÓN          → Humano revisa código, verifica contra spec y reglas de negocio
PRUEBAS           → Ejecutar en sandbox con datos mock + sintéticos
RECONCILIACIÓN    → Comparar resultados Redshift vs Teradata (cuando sea posible)
APROBACIÓN        → Checklist de salida firmado por líder técnico
```

---

## 3. Plan de Trabajo por Fases

### Fase 0: Preparación y Gobierno (Semana 1-2)

| Actividad | Entregable | Responsable |
|-----------|-----------|-------------|
| Definir modelo operativo y roles | Este documento aprobado | Líder migración |
| Crear steering files base para nuevos procesos | Steering files por proceso | Líder migración |
| Configurar sandbox Redshift con schemas por proceso | Ambientes listos | Ingeniero datos + Experian |
| Establecer checklist de salida por componente | Template de checklist | Líder migración + QA |
| Definir convención de nombres y estructura de repos | Estándar documentado | Líder migración |
| Resolver bloqueantes pendientes de PoC | Mapeo tablas XPM, malla Control-M | Líder migración + Experian |

### Fase 1: Inventario y Clasificación (Semana 2-3)

| Actividad | Entregable | Responsable |
|-----------|-----------|-------------|
| Inventariar todos los componentes Teradata pendientes | Inventario completo con líneas, tipo, dependencias | Ingeniero datos + IA |
| Clasificar por complejidad (Baja/Media/Alta/Crítica) | Matriz de complejidad poblada | Líder migración |
| Identificar dependencias entre procesos | Mapa de dependencias | Líder migración |
| Priorizar orden de migración | Backlog priorizado | Líder migración |
| Identificar componentes excluidos del alcance | Lista de exclusiones documentada | Líder migración |

### Fase 2: Construcción de Specs (Semana 3-6, iterativo)

| Actividad | Entregable | Responsable |
|-----------|-----------|-------------|
| Escribir specs para componentes Alta/Crítica | Requirements + Design por componente | Líder migración + IA |
| Documentar reglas de negocio por proceso | Documento funcional por proceso | Líder migración + Experian |
| Diseñar datos de prueba por componente | CSVs mock con resultado esperado | QA datos + IA |
| Validar specs con experto funcional Experian | Specs aprobadas | Líder migración + Experian |

### Fase 3: Diseño de Reglas de Migración (Semana 4-5)

| Actividad | Entregable | Responsable |
|-----------|-----------|-------------|
| Actualizar tabla de equivalencias Teradata → Redshift | Skill actualizado | Líder migración |
| Definir patrones de migración por tipo de componente | Catálogo de patrones | Líder migración |
| Crear templates de código Redshift | Templates reutilizables | Ingeniero datos + IA |
| Definir estrategia de rollback por componente | Estándar de rollback | Líder migración |

### Fase 4: Generación Asistida por IA (Semana 5-12, iterativo)

| Actividad | Entregable | Responsable |
|-----------|-----------|-------------|
| Generar código Redshift (prompt directo para Baja/Media) | Scripts SQL | IA + Ingeniero datos |
| Generar código Redshift (spec driven para Alta/Crítica) | Scripts SQL alineados a spec | IA + Líder migración |
| Generar scripts de rollback | Scripts rollback | IA |
| Generar scripts de validación | Scripts de prueba | IA + QA datos |
| Actualizar deploy_order.par | Orden de despliegue | Ingeniero datos |

### Fase 5: Revisión Técnica y Funcional (Semana 6-13, iterativo)

| Actividad | Entregable | Responsable |
|-----------|-----------|-------------|
| Revisión de código contra spec | Código aprobado o con observaciones | Líder migración |
| Revisión funcional con experto Experian | Validación de reglas de negocio | Experian |
| Corrección de observaciones | Código corregido | IA + Ingeniero datos |
| Documentar decisiones técnicas tomadas | Log de decisiones | Líder migración |

### Fase 6: Pruebas y Reconciliación (Semana 8-14, iterativo)

| Actividad | Entregable | Responsable |
|-----------|-----------|-------------|
| Ejecutar con datos mock en sandbox | Resultados vs esperado | QA datos |
| Ejecutar con datos sintéticos (volumen) | Resultados de volumen | QA datos |
| Reconciliar contra Teradata (cuando sea posible) | Reporte de reconciliación | QA datos + Experian |
| Pruebas de performance | Tiempos de ejecución documentados | Ingeniero datos |
| Documentar bugs y correcciones | Log de bugs | QA datos |

### Fase 7: Despliegue Controlado y Estabilización (Semana 14-16)

| Actividad | Entregable | Responsable |
|-----------|-----------|-------------|
| Deploy en ambiente de pruebas Experian | Scripts desplegados | Ingeniero datos + Experian |
| Pruebas de integración end-to-end | Reporte de integración | QA datos + Experian |
| Ajustes y correcciones finales | Código estabilizado | IA + Ingeniero datos |
| Documentación de operación | Runbook por proceso | Líder migración |
| Handoff a equipo de operaciones | Capacitación completada | Líder migración |

---

## 4. Matriz de Complejidad

### Clasificación de componentes

| Nivel | Criterio | Ejemplos en Reconocer |
|-------|----------|----------------------|
| **Baja** | DDL simples, consultas directas, scripts sin lógica compleja | Schemas, roles, tablas staging, rollbacks |
| **Media** | Transformaciones SQL, JOINs, reglas de negocio moderadas, window functions | Regla 1 unificación, scoring TEL/CEL/EMA (patrón replicado) |
| **Alta** | Stored procedures, lógica procedural, dependencias entre procesos, múltiples escenarios | Regla 2 escenarios 1-4, Regla 3, scoring DIR (primer canal) |
| **Crítica** | SQL dinámico, cambio de paradigma, generación de nuevas entidades, validación compleja | MOTOR_TMP, Indicadores de Movilidad (P0029), Novedades (P0035) |

### Detalle por nivel

#### Complejidad Baja

| Aspecto | Detalle |
|---------|---------|
| Esfuerzo | 30 min - 2 horas por componente |
| Riesgos | Mínimos. Errores de sintaxis Redshift |
| Rol de la IA | Generación completa con prompt directo |
| Rol del humano | Revisión rápida, validación de nombres y encoding |
| Criterios de aceptación | Script ejecuta sin error, objetos creados correctamente |
| Estrategia de pruebas | Ejecución directa en sandbox, verificación visual |
| Velocidad esperada | ~300 líneas RS/hora |

#### Complejidad Media

| Aspecto | Detalle |
|---------|---------|
| Esfuerzo | 2-4 horas por componente |
| Riesgos | Diferencias semánticas Teradata vs Redshift (QUALIFY, SET tables) |
| Rol de la IA | Generación con prompt directo + contexto de steering files |
| Rol del humano | Revisión de lógica de negocio, validación de resultados |
| Criterios de aceptación | Resultados coinciden con datos mock esperados |
| Estrategia de pruebas | Datos mock (10-20 registros) + ejecución en sandbox |
| Velocidad esperada | ~180 líneas RS/hora |

#### Complejidad Alta

| Aspecto | Detalle |
|---------|---------|
| Esfuerzo | 4-8 horas por componente |
| Riesgos | Ambigüedad en reglas de negocio, dependencias entre escenarios, edge cases |
| Rol de la IA | Generación con prompt directo, escalando a spec si falla 2+ veces |
| Rol del humano | Análisis funcional previo, diseño de datos de prueba, revisión exhaustiva |
| Criterios de aceptación | Datos mock + sintéticos (5,000+) pasan sin errores |
| Estrategia de pruebas | Mock + sintéticos + reconciliación contra Teradata si es posible |
| Velocidad esperada | ~120 líneas RS/hora |

#### Complejidad Crítica

| Aspecto | Detalle |
|---------|---------|
| Esfuerzo | 8-24 horas por componente (incluye spec completa) |
| Riesgos | Cambio de paradigma, SQL dinámico sin equivalente, alta dependencia funcional |
| Rol de la IA | Generación desde spec (requirements → design → tasks → código) |
| Rol del humano | Escribir spec, revisión de comité, validación exhaustiva, decisiones de arquitectura |
| Criterios de aceptación | Spec aprobada + código alineado + mock + sintéticos + reconciliación + performance |
| Estrategia de pruebas | Mock + sintéticos + reconciliación + pruebas de carga + revisión de comité |
| Velocidad esperada | ~50 líneas RS/hora |

### Aplicación al inventario pendiente

| Componente | Complejidad estimada | Líneas TD | Aproximación |
|-----------|:--------------------:|----------:|:------------:|
| Indicadores de Movilidad (P0029) | Alta | ~1,479 | Prompt directo + spec si necesario |
| 12 SPs PRO_ORD_* (no localizados) | Crítica | Desconocido | Spec driven obligatorio |
| Novedades (P0035) | Crítica | ~8,887 SP + ~125KB scripts | Spec driven obligatorio |
| Geo (P0006-P0036) | Alta | ~15 scripts | Prompt directo + dependencia ESRI |
| Cálculo Reconocer General | Alta | Por dimensionar | Spec driven |
| Modelo Batch + Control-M | Media | Por dimensionar | Prompt directo |
| Servicio en Línea (DB2) | Media | Por dimensionar | Prompt directo |

---

## 5. Gestión de Entornos

### Arquitectura de ambientes

```
┌─────────────────────────────────────────────────────────┐
│                    SANDBOX REDSHIFT                       │
│  (Ambiente actual de PoC — propiedad Experian)           │
│                                                           │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │ bdm_datos    │  │ bdm_tempo    │  │ bdm_stage    │   │
│  │ (tablas      │  │ (tablas      │  │ (staging     │   │
│  │  definitivas)│  │  temporales) │  │  intermedio) │   │
│  └──────────────┘  └──────────────┘  └──────────────┘   │
│                                                           │
│  Datos: Mock (20-50 personas) + Sintéticos (5,000+)      │
│  Acceso: VPN Experian + credenciales controladas         │
└─────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────┐
│              AMBIENTE DE PRUEBAS EXPERIAN                 │
│  (Post-sandbox — para integración y reconciliación)      │
│                                                           │
│  Datos: Subconjunto controlado de producción             │
│  Acceso: Gestionado por Oscar Fajardo / Experian         │
│  Uso: Reconciliación Teradata vs Redshift                │
└─────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────┐
│                    PRODUCCIÓN                             │
│  (Deploy final — Control-M + monitoreo)                  │
│                                                           │
│  Datos: 65-70M ciudadanos                                │
│  Acceso: Solo equipo de operaciones Experian             │
└─────────────────────────────────────────────────────────┘
```

### Estrategia de datos por ambiente

| Ambiente | Tipo de datos | Volumen | Propósito |
|----------|--------------|---------|-----------|
| Sandbox (desarrollo) | Mock diseñados manualmente | 20-50 personas | Validar lógica, cubrir escenarios |
| Sandbox (volumen) | Sintéticos generados por Python | 5,000-10,000 personas | Validar edge cases, performance básica |
| Pruebas Experian | Subconjunto anonimizado de producción | 100,000-500,000 personas | Reconciliación, performance real |
| Producción | Datos reales | 65-70M personas | Operación |

### Seguridad y accesos

| Recurso | Responsable | Estado |
|---------|-------------|--------|
| VPN Experian | Experian (Oscar Fajardo) | Activo |
| Credenciales sandbox Redshift | Experian | Activo (puerto 5439, SSL) |
| Repos Azure DevOps | Molina (Experian) | Pendiente creación |
| Acceso a Teradata (lectura) | Experian | Pendiente solicitud |
| Datos de producción anonimizados | Experian | Por gestionar |

### Dependencias con Experian

| Dependencia | Responsable Experian | Criticidad | Estado |
|-------------|---------------------|:----------:|--------|
| Mapeo tablas Redshift del XPM | Molina | Alta | Pendiente |
| Contrato de campos requeridos | Equipo de datos | Alta | Deadline 15 mayo |
| Malla Control-M | Melissa | Alta | Pendiente |
| Acceso a Teradata para reconciliación | Oscar Fajardo | Media | Pendiente |
| Datos anonimizados para pruebas | Experian | Media | Por gestionar |

---

## 6. Gobierno de Calidad

### Checklist de salida por componente

Todo componente migrado debe cumplir estos criterios antes de considerarse "listo":

```
□ ANÁLISIS
  □ Código fuente Teradata identificado y leído
  □ Lógica de negocio documentada (o referenciada en spec)
  □ Dependencias con otros procesos identificadas
  □ Complejidad clasificada (Baja/Media/Alta/Crítica)

□ ESPECIFICACIÓN (solo para Alta/Crítica)
  □ Requirements.md escrito y revisado
  □ Design.md escrito y revisado
  □ Datos de prueba diseñados con resultado esperado

□ CÓDIGO
  □ Script SQL Redshift generado
  □ Script de rollback generado
  □ Código revisado por líder técnico
  □ Código alineado con spec (si aplica)
  □ Convención de nombres respetada
  □ deploy_order.par actualizado

□ PRUEBAS
  □ Ejecutado en sandbox sin errores
  □ Datos mock: resultados coinciden con esperado
  □ Datos sintéticos: 0 errores en volumen
  □ Performance aceptable (documentar tiempos)
  □ Reconciliación contra Teradata (cuando sea posible)

□ DOCUMENTACIÓN
  □ Hallazgos documentados
  □ Bugs encontrados y corregidos documentados
  □ Decisiones técnicas registradas

□ APROBACIÓN
  □ Líder técnico firma checklist
  □ Componente marcado como "listo" en backlog
```

### Estrategia de pruebas por nivel

| Nivel | Mock | Sintéticos | Reconciliación | Performance | Revisión comité |
|-------|:----:|:----------:|:--------------:|:-----------:|:---------------:|
| Baja | ✅ | ❌ | ❌ | ❌ | ❌ |
| Media | ✅ | ✅ | ❌ | ❌ | ❌ |
| Alta | ✅ | ✅ | ✅ (si posible) | ✅ | ❌ |
| Crítica | ✅ | ✅ | ✅ (obligatorio) | ✅ | ✅ |

### Comparación Teradata vs Redshift (reconciliación)

Para componentes Alta/Crítica, cuando se tenga acceso a datos de Teradata:

1. Ejecutar proceso en Teradata con dataset de referencia.
2. Ejecutar proceso migrado en Redshift con mismo dataset.
3. Comparar resultados fila por fila (o agregados si el volumen es muy alto).
4. Documentar diferencias y justificar (ej: diferencias de precisión decimal, orden de empates).
5. Aprobar si diferencias están dentro de tolerancia definida.

---

## 7. Riesgos y Mitigaciones

| # | Riesgo | Probabilidad | Impacto | Mitigación |
|---|--------|:------------:|:-------:|-----------|
| R1 | Código fuente incompleto (12 SPs PRO_ORD_* no localizados) | Alta | Alto | Solicitar a Experian acceso a Teradata para extraer DDLs. Escalar si no se obtiene en 2 semanas |
| R2 | Falta de contexto funcional para procesos no documentados | Media | Alto | Sesiones de entendimiento con Wilmar/Experian. Documentar en specs antes de codificar |
| R3 | Ambigüedad en reglas de negocio | Alta | Medio | Spec driven para componentes Alta/Crítica. Validar con experto funcional antes de generar código |
| R4 | Diferencias semánticas Teradata vs Redshift | Media | Medio | Tabla de equivalencias en skill reutilizable. Actualizar con cada nuevo hallazgo |
| R5 | Problemas de performance en Redshift con 65-70M registros | Media | Alto | Pruebas de volumen progresivas (5K → 100K → 500K → full). Optimizar DISTKEY/SORTKEY |
| R6 | Sandbox no disponible o con restricciones | Baja | Alto | Tener ambiente local con datos mock como fallback. Escalar a Oscar Fajardo |
| R7 | Dependencia de expertos Experian (Wilmar, Molina) | Alta | Alto | Documentar todo hallazgo en tiempo real. Reducir dependencia con specs autocontenidas |
| R8 | Uso no gobernado de IA (código generado sin revisión) | Baja | Crítico | Reglas G1-G7 de gobierno. Ningún código llega a producción sin revisión humana |
| R9 | Validaciones insuficientes (bugs en producción) | Media | Crítico | Checklist de salida obligatorio. Datos mock + sintéticos + reconciliación |
| R10 | IFR no sale en agosto 2026 | Media | Crítico | Desacoplar trabajo de Redshift de EDF. Trabajar con datos mock hasta que IFR esté listo |
| R11 | Deadline Teradata (abril-mayo 2027) se acerca sin completar | Baja | Crítico | Priorizar procesos críticos primero. Tener plan de contingencia para renovación parcial |
| R12 | Cambio de alcance por parte de Experian | Media | Alto | Documentar alcance aprobado. Gestionar cambios con proceso formal |

---

## 8. Modelo de Roles

| Rol | Responsabilidad | Perfil | Dedicación |
|-----|----------------|--------|:----------:|
| **Líder de migración** | Gobernar, revisar, decidir, priorizar, asegurar calidad. Interlocutor con Experian | Senior con experiencia en migraciones de datos y gestión de proyectos | 100% |
| **Arquitecto de datos** | Decisiones de modelo de datos, DISTKEY/SORTKEY, performance, integración EDF↔Redshift | Senior con experiencia en Redshift y modelado dimensional | 50% (compartido) |
| **Ingeniero de datos** | Ejecutar generación de código con IA, implementar en sandbox, corregir bugs | Mid-Senior con SQL fuerte y experiencia en Redshift | 100% |
| **QA de datos** | Diseñar datos de prueba, ejecutar validaciones, reconciliar, documentar bugs | Mid con experiencia en testing de datos y SQL | 50-100% |
| **Experto funcional** | Resolver ambigüedades de negocio, validar specs, aprobar resultados funcionales | Experian (Wilmar o designado) | 20-30% |
| **Responsable de entornos** | Gestionar sandbox, accesos, VPN, repos, deploy | Experian (Oscar Fajardo / Molina) | 10-20% |
| **IA (Kiro/Cursor)** | Generar código, analizar código fuente, generar documentación, crear datos sintéticos | Herramienta gobernada por humanos | N/A |

**Principio fundamental**: La IA no reemplaza la responsabilidad técnica. Acelera la ejecución bajo gobierno humano. Todo entregable generado por IA es un borrador hasta que un humano lo aprueba.

---

## 9. Roadmap Ejecutivo

```
                    ABR         MAY         JUN         JUL         AGO         SEP         OCT
                    ├───────────┼───────────┼───────────┼───────────┼───────────┼───────────┤
                    │           │           │           │           │           │           │
FASE 0: Gobierno    ██████      │           │           │           │           │           │
                    │           │           │           │           │           │           │
FASE 1: Inventario  ░░████      │           │           │           │           │           │
                    │           │           │           │           │           │           │
FASE 2: Specs       │  ░████████████        │           │           │           │           │
                    │           │           │           │           │           │           │
FASE 3: Reglas      │  ░░████   │           │           │           │           │           │
                    │           │           │           │           │           │           │
FASE 4: Generación  │     ░░████████████████████████    │           │           │           │
                    │           │           │           │           │           │           │
FASE 5: Revisión    │        ░░░████████████████████████│           │           │           │
                    │           │           │           │           │           │           │
FASE 6: Pruebas     │           │  ░░░░████████████████████████████ │           │           │
                    │           │           │           │           │           │           │
FASE 7: Deploy      │           │           │           │           │     ░░████████████████│
                    │           │           │           │           │           │           │
                    ├───────────┼───────────┼───────────┼───────────┼───────────┼───────────┤
                    │           │           │           │           │           │           │
HITOS:              │           │           │           │           │           │           │
  H1: Gobierno OK   ▲           │           │           │           │           │           │
  H2: Inventario    │  ▲        │           │           │           │           │           │
  H3: Specs core    │           ▲           │           │           │           │           │
  H4: 50% código    │           │     ▲     │           │           │           │           │
  H5: IFR ready     │           │           │           ▲           │           │           │
  H6: 100% código   │           │           │           │     ▲     │           │           │
  H7: Reconciliado  │           │           │           │           │     ▲     │           │
  H8: BATCH GO-LIVE │           │           │           │           │           │     ▲     │
                    │           │           │           │           │           │           │
DEPENDENCIAS:       │           │           │           │           │           │           │
  Mapeo XPM         ▼ (mayo)   │           │           │           │           │           │
  Contrato campos   │  ▼ (15 may)          │           │           │           │           │
  Malla Control-M   ▼ (mayo)   │           │           │           │           │           │
  IFR disponible    │           │           │           ▼ (agosto)  │           │           │
  Datos producción  │           │           │     ▼     │           │           │           │
```

### Hitos y decisiones

| Hito | Fecha objetivo | Entregable | Decisión necesaria |
|------|:-------------:|-----------|-------------------|
| H1 | Fin abril | Modelo operativo aprobado, steering files creados | Aprobación de este documento |
| H2 | Mid mayo | Inventario completo, matriz de complejidad poblada | Priorización del backlog |
| H3 | Fin mayo | Specs de componentes críticos escritas y aprobadas | Validación funcional con Experian |
| H4 | Fin junio | 50% del código generado y validado en sandbox | Go/No-go para continuar |
| H5 | Agosto | IFR disponible con datos para Reconocer | Integración EDF ↔ Redshift |
| H6 | Fin agosto | 100% del código generado y validado | Inicio de reconciliación |
| H7 | Fin septiembre | Reconciliación completada, performance validada | Go/No-go para deploy |
| H8 | Octubre | Batch en producción | Go-live |

### Quick wins (primeras 4 semanas)

1. **Indicadores de Movilidad (P0029)**: proceso autocontenido, complejidad Alta pero acotada. Demuestra capacidad de migrar más allá de la PoC.
2. **Resolver bloqueantes pendientes**: mapeo XPM, malla Control-M, repos Azure DevOps.
3. **Crear steering files para procesos nuevos**: reutilizar los 11 existentes como base.
4. **Localizar los 12 SPs PRO_ORD_* faltantes**: crítico para dimensionar el ordenamiento completo.

---

## 10. Resumen de Números

### PoC completada

| Métrica | Valor |
|---------|-------|
| Procesos migrados | 2 (Unificación + Ordenamiento) |
| Líneas Teradata → Redshift | 19,500 → 3,080 (6.3:1) |
| Tiempo efectivo | ~3 semanas |
| Bugs | 8 (corregidos) |
| Tasa de bugs | 0.26/100 líneas |

### Proyecto completo (estimación)

| Métrica | Valor |
|---------|-------|
| Procesos pendientes de migrar a Redshift | 4-6 (Movilidad, Cálculo General, Batch, Servicio en Línea, + pendientes) |
| Líneas Teradata estimadas pendientes | ~30,000-40,000 |
| Líneas Redshift estimadas | ~5,000-7,000 (asumiendo ratio 6:1) |
| Tiempo estimado (con modelo industrializado) | 5-6 meses |
| Equipo mínimo | 3 personas (líder + ingeniero + QA) |
| Deadline | Octubre 2026 (batch) |

---

*Documento preparado para reunión de management — 27 de abril de 2026.*
*Autor: Francisco Peña | Macondotek | Proyecto MT-EXP-005-MAP-RECONOCER*
