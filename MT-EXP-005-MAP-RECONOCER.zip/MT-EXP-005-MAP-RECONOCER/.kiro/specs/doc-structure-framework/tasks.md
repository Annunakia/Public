# Tareas — Reestructuración de Carpetas del Repositorio

## Tareas

- [x] 1. Fase 1: Crear carpetas nuevas
  - [x] 1.1 Crear `proyecto/comunicaciones/`
  - [x] 1.2 Crear `proyecto/entregables/`
  - [x] 1.3 Crear `proyecto/metodologia/`
  - [x] 1.4 Crear `proyecto/orquestacion/`
  - [x] 1.5 Crear `proyecto/preventa/`
  - [x] 1.6 Commit: "refactor: crear estructura de carpetas nuevas para reorganización"

- [x] 2. Fase 2: Mover archivos a ubicación correcta
  - [x] 2.1 Mover archivos de preventa de `ws-unificacion/docs/preventa/` a `proyecto/preventa/` (7 archivos)
  - [x] 2.2 Mover `resumen_workshop_tecnico_migracion_reconocer_20260326.md` de ambos workspaces a `proyecto/comunicaciones/`
  - [x] 2.3 Mover `Control_M.xml` de raíz a `proyecto/orquestacion/`
  - [x] 2.4 Mover `proyecto/orquestacion_control_m_unificacion_ordenamiento.md` a `proyecto/orquestacion/`
  - [x] 2.5 Mover `proyecto/framework_batch_procesos_dinamicos.md` a `proyecto/orquestacion/`
  - [x] 2.6 Mover `analisis-interno/specs_vs_prompt_directo.md` a `proyecto/metodologia/`
  - [x] 2.7 Mover `proyecto/propuesta_management_migracion_reconocer.md` a `proyecto/gestion/`
  - [x] 2.8 Mover `proyecto/lecciones_aprendidas_migracion_kiro.md` a `proyecto/metodologia/`
  - [x] 2.9 Mover `proyecto/MT EXP F 031 Preliminary Work Plan.xlsx` a `proyecto/entregables/`
  - [x] 2.10 Mover `proyecto/Explicación funcionamiento framework procesos batch_v1.vtt` a `proyecto/entregables/`
  - [x] 2.11 Mover `ws-unificacion/src/redshift/Documentacion/PAQUETE_UNIFICACION_REGLA1.yml` a `ws-unificacion/docs/tecnico/`
  - [x] 2.12 Commit: "refactor: mover archivos a ubicación correcta según estructura objetivo"

- [x] 3. Fase 3: Eliminar duplicados y carpetas vacías
  - [x] 3.1 Eliminar `ws-ordenamiento/docs/preventa/` (archivos duplicados de preventa)
  - [x] 3.2 Eliminar `ws-unificacion/docs/preventa/` (ya movidos a proyecto/preventa/)
  - [x] 3.3 Eliminar `ws-unificacion/src/redshift/Documentacion/` (carpeta vacía post-movimiento)
  - [x] 3.4 Eliminar `analisis-interno/` (carpeta vacía post-movimiento)
  - [x] 3.5 Eliminar `proyecto/benchmark/` (carpeta vacía)
  - [x] 3.6 Eliminar comunicación transversal duplicada de `ws-ordenamiento/docs/comunicaciones/resumen_workshop_tecnico_migracion_reconocer_20260326.md`
  - [x] 3.7 Commit: "refactor: eliminar duplicados y carpetas vacías"

- [x] 4. Fase 4: Actualizar índices, READMEs y enlaces
  - [x] 4.1 Crear `ws-unificacion/docs/preventa/README.md` con enlace a `proyecto/preventa/`
  - [x] 4.2 Crear `ws-ordenamiento/docs/preventa/README.md` con enlace a `proyecto/preventa/`
  - [x] 4.3 Crear `ws-unificacion/src/redshift/_legacy/README.md` documentando propósito de archivos legacy
  - [x] 4.4 Crear `ws-ordenamiento/docs/funcional/README.md` placeholder indicando documentación pendiente
  - [x] 4.5 Actualizar `README.md` raíz con nueva estructura de carpetas
  - [x] 4.6 Actualizar `proyecto/README.md` con índice de subcarpetas y documentos
  - [x] 4.7 Actualizar `AGENTS.md` sección "Estructura del repo" con nueva estructura
  - [x] 4.8 Verificar que todos los enlaces relativos en archivos markdown apunten a ubicaciones válidas
  - [x] 4.9 Commit: "refactor: actualizar índices, READMEs y enlaces relativos"
  - [x] 4.10 Push a main
