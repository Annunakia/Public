# Documento de Requerimientos — Reestructuración de Carpetas del Repositorio

## Introducción

Este documento define los requerimientos para reorganizar la estructura de carpetas y archivos del repositorio MT-EXP-005-MAP-RECONOCER. El objetivo es eliminar duplicados, centralizar documentos transversales, y establecer una estructura clara y predecible que sirva como base para un framework reutilizable en futuros proyectos de Macondotek.

### Problemas concretos identificados

1. `docs/preventa/` (7 archivos idénticos) duplicado en `ws-unificacion/` y `ws-ordenamiento/`
2. `resumen_workshop_tecnico_migracion_reconocer_20260326.md` duplicado en ambos workspaces
3. `proyecto/benchmark/` vacío sin contenido
4. `analisis-interno/` carpeta huérfana con 1 solo archivo
5. `Control_M.xml` suelto en la raíz del repositorio
6. `Documentacion/` dentro de `ws-unificacion/src/redshift/` mezcla docs con código fuente
7. `_legacy/` dentro de `ws-unificacion/src/redshift/` sin documentar su propósito
8. Archivos binarios (`.vtt`, `.xlsx`) mezclados con markdown en `proyecto/`
9. `docs/funcional/` vacío en `ws-ordenamiento/`
10. `propuesta_management_migracion_reconocer.md` suelto en `proyecto/` en vez de en `proyecto/gestion/`
11. Comunicaciones transversales (workshop general) ubicadas en workspaces específicos

### Zonas protegidas (NO se modifican)

- `Experian Reconocer/` — Código fuente original del cliente
- `MT-Comercial - Preventa/` — Framework de preventa de la empresa

## Glosario

- **Repositorio**: El repositorio git MT-EXP-005-MAP-RECONOCER donde se trabaja la migración de Reconocer
- **Workspace**: Carpeta raíz de un proceso de migración específico (`ws-unificacion/`, `ws-ordenamiento/`)
- **Documento_Transversal**: Documento que aplica a todo el proyecto y no es específico de un solo workspace (preventa, comunicaciones generales, arquitectura)
- **Documento_Específico**: Documento que aplica solo a un workspace particular (funcional de unificación, técnico de ordenamiento)
- **Zona_Protegida**: Carpeta que no debe ser modificada (`Experian Reconocer/`, `MT-Comercial - Preventa/`)
- **Enlace_Referencia**: Archivo markdown mínimo que contiene un enlace relativo al documento canónico, reemplazando una copia duplicada

## Requerimientos

### Requerimiento 1: Centralizar documentos de preventa

**User Story:** Como miembro del equipo, quiero que los documentos de preventa existan en una sola ubicación, para no tener 7 archivos duplicados entre workspaces.

#### Criterios de Aceptación

1. WHEN se ejecuta la reestructuración, THE Repositorio SHALL contener los 7 archivos de preventa (`01_contexto_proyecto.md`, `02_fases_tecnicas.md`, `03_roles_identificados.md`, `04_wbs_inicial.md`, `05_riesgos_supuestos.md`, `arquitectura_proyecto.md`, `decisiones_abiertas.md`) únicamente en `proyecto/preventa/`
2. WHEN se mueven los archivos de preventa a `proyecto/preventa/`, THE Repositorio SHALL eliminar las carpetas `ws-unificacion/docs/preventa/` y `ws-ordenamiento/docs/preventa/`
3. WHEN se eliminan las carpetas de preventa de los workspaces, THE Repositorio SHALL crear un archivo `docs/preventa/README.md` en cada workspace con un enlace relativo a `proyecto/preventa/` indicando la ubicación canónica

### Requerimiento 2: Centralizar comunicaciones transversales

**User Story:** Como líder técnico, quiero que las comunicaciones que aplican a todo el proyecto estén en un solo lugar, para no buscar en múltiples carpetas.

#### Criterios de Aceptación

1. WHEN se ejecuta la reestructuración, THE Repositorio SHALL crear la carpeta `proyecto/comunicaciones/` para alojar comunicaciones transversales
2. WHEN una comunicación aplica a más de un workspace, THE Repositorio SHALL mover el archivo a `proyecto/comunicaciones/` y eliminarlo de los workspaces donde estaba duplicado
3. WHEN se centraliza `resumen_workshop_tecnico_migracion_reconocer_20260326.md`, THE Repositorio SHALL moverlo a `proyecto/comunicaciones/` y eliminarlo de `ws-unificacion/docs/comunicaciones/` y `ws-ordenamiento/docs/comunicaciones/`
4. THE Repositorio SHALL mantener en `ws-unificacion/docs/comunicaciones/` solo las comunicaciones específicas de unificación: `resumen_llamada_edf_ingesta_20260319.md` y `transcripcion_reunion_reconocer_sesion_funcional_20260325.md`
5. THE Repositorio SHALL mantener en `ws-ordenamiento/docs/comunicaciones/` solo las comunicaciones específicas de ordenamiento: `resumen_reunion_experian_arquitectura_20260316.md` y `resumen_reunion_interna_macondotek_20260317.md`

### Requerimiento 3: Reubicar archivos sueltos y huérfanos

**User Story:** Como desarrollador, quiero que cada archivo esté en la carpeta que corresponde según su naturaleza, para que la estructura sea predecible.

#### Criterios de Aceptación

1. WHEN se ejecuta la reestructuración, THE Repositorio SHALL mover `Control_M.xml` de la raíz a `proyecto/orquestacion/Control_M.xml`
2. WHEN se ejecuta la reestructuración, THE Repositorio SHALL mover `proyecto/orquestacion_control_m_unificacion_ordenamiento.md` a `proyecto/orquestacion/orquestacion_control_m_unificacion_ordenamiento.md`
3. WHEN se ejecuta la reestructuración, THE Repositorio SHALL mover `analisis-interno/specs_vs_prompt_directo.md` a `proyecto/metodologia/specs_vs_prompt_directo.md` y eliminar la carpeta `analisis-interno/`
4. WHEN se ejecuta la reestructuración, THE Repositorio SHALL mover `proyecto/propuesta_management_migracion_reconocer.md` a `proyecto/gestion/propuesta_management_migracion_reconocer.md`
5. WHEN se ejecuta la reestructuración, THE Repositorio SHALL mover `proyecto/lecciones_aprendidas_migracion_kiro.md` a `proyecto/metodologia/lecciones_aprendidas_migracion_kiro.md`

### Requerimiento 4: Separar documentación del código fuente

**User Story:** Como desarrollador, quiero que la carpeta `src/` contenga solo código ejecutable, para no confundir documentación con artefactos desplegables.

#### Criterios de Aceptación

1. WHEN se ejecuta la reestructuración, THE Repositorio SHALL mover `ws-unificacion/src/redshift/Documentacion/PAQUETE_UNIFICACION_REGLA1.yml` a `ws-unificacion/docs/tecnico/PAQUETE_UNIFICACION_REGLA1.yml`
2. WHEN se mueve el contenido de `Documentacion/`, THE Repositorio SHALL eliminar la carpeta `ws-unificacion/src/redshift/Documentacion/`
3. WHEN se ejecuta la reestructuración, THE Repositorio SHALL crear un archivo `ws-unificacion/src/redshift/_legacy/README.md` que documente el propósito de los archivos legacy (`00_setup_schema.sql`, `01_regla1_unificacion.sql`) indicando que son versiones anteriores reemplazadas por el código en `sql/`

### Requerimiento 5: Eliminar carpetas vacías y organizar archivos binarios

**User Story:** Como miembro del equipo, quiero que no existan carpetas vacías ni archivos binarios mezclados con documentación markdown, para que la estructura refleje contenido real.

#### Criterios de Aceptación

1. WHEN se ejecuta la reestructuración, THE Repositorio SHALL eliminar la carpeta `proyecto/benchmark/` que está vacía
2. WHEN se ejecuta la reestructuración, THE Repositorio SHALL crear la carpeta `proyecto/entregables/` para archivos binarios y multimedia
3. WHEN se ejecuta la reestructuración, THE Repositorio SHALL mover `proyecto/MT EXP F 031 Preliminary Work Plan.xlsx` a `proyecto/entregables/MT EXP F 031 Preliminary Work Plan.xlsx`
4. WHEN se ejecuta la reestructuración, THE Repositorio SHALL mover `proyecto/Explicación funcionamiento framework procesos batch_v1.vtt` a `proyecto/entregables/Explicación funcionamiento framework procesos batch_v1.vtt`
5. WHEN se ejecuta la reestructuración, THE Repositorio SHALL eliminar la carpeta vacía `ws-ordenamiento/docs/funcional/` o crear un archivo `README.md` placeholder indicando que la documentación funcional está pendiente

### Requerimiento 6: Actualizar índices de navegación

**User Story:** Como miembro del equipo, quiero que los README reflejen la estructura real después de la reorganización, para poder navegar el repositorio sin confusión.

#### Criterios de Aceptación

1. WHEN se completa la reestructuración, THE Repositorio SHALL actualizar `README.md` en la raíz para reflejar la nueva estructura de carpetas incluyendo `proyecto/orquestacion/`, `proyecto/comunicaciones/`, `proyecto/metodologia/` y `proyecto/entregables/`
2. WHEN se completa la reestructuración, THE Repositorio SHALL actualizar `proyecto/README.md` para incluir las nuevas subcarpetas y sus documentos con enlaces relativos correctos
3. WHEN se completa la reestructuración, THE Repositorio SHALL actualizar `AGENTS.md` para reflejar la estructura actualizada del repositorio en la sección "Estructura del repo"
4. WHEN se completa la reestructuración, THE Repositorio SHALL verificar que todos los enlaces relativos en los archivos markdown apunten a ubicaciones válidas

### Requerimiento 7: Estructura final objetivo

**User Story:** Como líder técnico, quiero una estructura de carpetas clara y documentada que sirva como referencia para validar que la reorganización se completó correctamente.

#### Criterios de Aceptación

1. THE Repositorio SHALL tener la siguiente estructura de primer nivel después de la reestructuración: `.kiro/`, `Experian Reconocer/` (sin cambios), `MT-Comercial - Preventa/` (sin cambios), `proyecto/`, `ws-unificacion/`, `ws-ordenamiento/`, `AGENTS.md`, `README.md`, `.gitignore`
2. THE carpeta `proyecto/` SHALL contener las subcarpetas: `arquitectura/` (futuro), `comunicaciones/`, `decisiones/` (futuro), `entregables/`, `gestion/`, `metodologia/`, `orquestacion/`, `preventa/`
3. THE carpeta `proyecto/` SHALL contener en su raíz solo: `arquitectura.md`, `contrato_campos_edf_redshift.md`, `decisiones.md`, `inventario_codigo_fuente.md` y `README.md`
4. WHEN se valida la reestructuración, THE Repositorio SHALL no contener archivos sueltos en la raíz excepto `AGENTS.md`, `README.md` y `.gitignore`
5. WHEN se valida la reestructuración, THE Repositorio SHALL no contener carpetas vacías sin al menos un archivo README.md placeholder

### Requerimiento 8: Ejecución segura con respaldo en git

**User Story:** Como líder técnico, quiero que la reorganización se ejecute de forma segura y reversible, para poder deshacer cambios si algo sale mal.

#### Criterios de Aceptación

1. WHEN se inicia la reestructuración, THE Repositorio SHALL tener un commit limpio (sin cambios pendientes) antes de ejecutar cualquier movimiento de archivos
2. THE reestructuración SHALL ejecutarse en fases con un commit por fase: Fase 1 (crear carpetas nuevas), Fase 2 (mover archivos), Fase 3 (eliminar duplicados y carpetas vacías), Fase 4 (actualizar índices y enlaces)
3. IF algún archivo se pierde durante la reestructuración, THEN THE Repositorio SHALL permitir recuperarlo usando `git checkout` del commit anterior a la fase donde se perdió
4. WHEN se completa cada fase, THE Repositorio SHALL incluir un mensaje de commit descriptivo que liste los archivos movidos o eliminados en esa fase
