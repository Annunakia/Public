# Diseño Técnico — Reestructuración de Carpetas del Repositorio

## Resumen

Reorganización del repositorio MT-EXP-005-MAP-RECONOCER en 4 fases atómicas (1 commit por fase), moviendo archivos con `git mv` para preservar historial, eliminando duplicados, y actualizando índices.

## Estructura Objetivo

```
MT-EXP-005-MAP-RECONOCER/
├── .kiro/                          ← Configuración Kiro (sin cambios)
├── Experian Reconocer/             ← ZONA PROTEGIDA (sin cambios)
├── MT-Comercial - Preventa/        ← ZONA PROTEGIDA (sin cambios)
├── proyecto/
│   ├── arquitectura.md
│   ├── contrato_campos_edf_redshift.md
│   ├── decisiones.md
│   ├── inventario_codigo_fuente.md
│   ├── README.md
│   ├── comunicaciones/
│   │   └── resumen_workshop_tecnico_migracion_reconocer_20260326.md
│   ├── entregables/
│   │   ├── MT EXP F 031 Preliminary Work Plan.xlsx
│   │   └── Explicación funcionamiento framework procesos batch_v1.vtt
│   ├── gestion/
│   │   ├── avance_teams.md
│   │   ├── checklist.md
│   │   ├── insumos_pendientes_experian.md
│   │   ├── MT-EXP-Insumos-Pendientes-Experian.xlsx
│   │   ├── perfil_data_engineer_reconocer.md
│   │   ├── plan_trabajo.md
│   │   ├── propuesta_management_migracion_reconocer.md
│   │   └── reu_sync.md
│   ├── metodologia/
│   │   ├── lecciones_aprendidas_migracion_kiro.md
│   │   └── specs_vs_prompt_directo.md
│   ├── orquestacion/
│   │   ├── Control_M.xml
│   │   ├── framework_batch_procesos_dinamicos.md
│   │   └── orquestacion_control_m_unificacion_ordenamiento.md
│   └── preventa/
│       ├── 01_contexto_proyecto.md
│       ├── 02_fases_tecnicas.md
│       ├── 03_roles_identificados.md
│       ├── 04_wbs_inicial.md
│       ├── 05_riesgos_supuestos.md
│       ├── arquitectura_proyecto.md
│       └── decisiones_abiertas.md
├── ws-unificacion/
│   ├── .kiro/
│   ├── data/
│   ├── docs/
│   │   ├── comunicaciones/         ← Solo comunicaciones específicas de unificación
│   │   ├── funcional/
│   │   ├── preventa/README.md      ← Enlace a proyecto/preventa/
│   │   └── tecnico/
│   ├── src/
│   │   ├── redshift/
│   │   │   ├── _legacy/
│   │   │   │   ├── README.md       ← Documenta propósito de archivos legacy
│   │   │   │   ├── 00_setup_schema.sql
│   │   │   │   └── 01_regla1_unificacion.sql
│   │   │   ├── rev-sql/
│   │   │   ├── sql/
│   │   │   └── deploy_order.par
│   │   └── teradata/
│   └── README.md
├── ws-ordenamiento/
│   ├── .kiro/
│   ├── data/
│   ├── docs/
│   │   ├── comunicaciones/         ← Solo comunicaciones específicas de ordenamiento
│   │   ├── funcional/README.md     ← Placeholder indicando pendiente
│   │   ├── preventa/README.md      ← Enlace a proyecto/preventa/
│   │   └── tecnico/
│   ├── src/
│   │   ├── redshift/
│   │   └── teradata/
│   └── README.md
├── AGENTS.md
├── README.md
└── .gitignore
```

## Fases de Ejecución

### Fase 1: Crear carpetas nuevas
- `proyecto/comunicaciones/`
- `proyecto/entregables/`
- `proyecto/metodologia/`
- `proyecto/orquestacion/`
- `proyecto/preventa/`

### Fase 2: Mover archivos
- Archivos de preventa duplicados → `proyecto/preventa/`
- Comunicaciones transversales → `proyecto/comunicaciones/`
- Archivos sueltos en raíz → carpeta correspondiente
- Archivos binarios → `proyecto/entregables/`
- Documentación dentro de src → `docs/tecnico/`
- Archivos de metodología → `proyecto/metodologia/`
- Archivos de orquestación → `proyecto/orquestacion/`
- Propuesta management → `proyecto/gestion/`

### Fase 3: Eliminar duplicados y carpetas vacías
- Eliminar `ws-unificacion/docs/preventa/` (7 archivos)
- Eliminar `ws-ordenamiento/docs/preventa/` (7 archivos)
- Eliminar `ws-unificacion/src/redshift/Documentacion/`
- Eliminar `analisis-interno/`
- Eliminar `proyecto/benchmark/`

### Fase 4: Actualizar índices y enlaces
- Actualizar `README.md` raíz
- Actualizar `proyecto/README.md`
- Actualizar `AGENTS.md`
- Crear READMEs placeholder donde corresponda
- Crear `_legacy/README.md`
- Verificar enlaces relativos

## Herramientas

- `git mv` para mover archivos (preserva historial)
- `git rm` para eliminar duplicados
- Verificación manual de enlaces post-reestructuración

## Riesgos

| Riesgo | Mitigación |
|--------|-----------|
| Romper enlaces relativos en markdown | Verificar con grep post-fase 4 |
| Perder archivos durante movimiento | 1 commit por fase, reversible |
| Conflictos con steering files que referencian rutas | Actualizar steering files en fase 4 |
