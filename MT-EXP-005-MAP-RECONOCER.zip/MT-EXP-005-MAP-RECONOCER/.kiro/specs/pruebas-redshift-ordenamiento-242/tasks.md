# Implementation Plan: Pruebas de Ejecución en Redshift para Ordenamiento 242

## Overview

Pipeline de pruebas end-to-end que ejecuta los 15 scripts SQL migrados del proceso Ordenamiento 242 contra Redshift Serverless con un dataset sintético de 10K personas. Se crean helper scripts, un orquestador, validaciones por fase, y se ejecuta el pipeline completo documentando resultados.

## Tasks

- [x] 1. Crear helper scripts de ejecución SQL
  - [x] 1.1 Crear `ws-ordenamiento/data/synthetic/run_sql.sh` — ejecutor de sentencia individual
    - Reutilizar patrón de `ws-unificacion/data/mock/run_sql.sh`
    - Configurar: profile=sandbox, region=us-east-1, workgroup=experian-sandbox-dev-redshift-workgroup, db=dev
    - Polling cada 2s con timeout de 120s
    - Imprimir resultados en formato tabla si hay filas
    - Exit code 0=éxito, 1=error
    - _Requirements: 1.1_

  - [x] 1.2 Crear `ws-ordenamiento/data/synthetic/run_sql_file.sh` — ejecutor de archivo SQL completo
    - Leer archivo SQL, dividir por `;` respetando strings y comentarios
    - Filtrar sentencias vacías y comentarios puros
    - Ejecutar cada sentencia secuencialmente via `run_sql.sh`
    - Si falla: reportar número de sentencia, SQL truncado, error, y salir con código 1
    - Implementar flag `--dry-run` que imprime sentencias numeradas sin ejecutar
    - _Requirements: 1.2, 1.3, 1.4, 1.5_

  - [x] 1.3 Crear `ws-ordenamiento/data/synthetic/split_dataset.sh` — divisor de dataset en batches
    - Leer `dataset_10k.sql` (~8.8MB)
    - Separar DDL (CREATE SCHEMA, CREATE TABLE, DROP TABLE) de INSERTs
    - Agrupar INSERTs en batches de máximo 80KB
    - Generar `batches/batch_001.sql`, `batch_002.sql`, etc.
    - Primer batch incluye sentencias DDL
    - Reportar número de batches y tamaño promedio
    - _Requirements: 2.6_

- [x] 2. Crear scripts de validación por fase
  - [x] 2.1 Crear `ws-ordenamiento/data/synthetic/validate_fase1.sh`
    - V1.1: COUNT unifica_btt_reconocer = 10,000
    - V1.2: COUNT DISTINCT (cod_pin_persona || id_buro_persona) = total (sin duplicados)
    - V1.3: 0 errores en log_ejecucion
    - V1.4: Log tiene >= 4 registros de Fase 1
    - Reportar cada validación como PASS/FAIL con valores actual vs esperado
    - Exit con count de errores
    - _Requirements: 5.1, 5.2, 5.3, 5.4_

  - [x] 2.2 Crear `ws-ordenamiento/data/synthetic/validate_fase2.sh`
    - V2.1: Ningún portafolio inválido (fuera de CO,RO,VE,HP,IN,OT,CC,AH,CT)
    - V2.2: 0 portafolios NULL
    - V2.3: 0 hashes con LENGTH != 32 en concatena_atributos
    - V2.4: 0 concatena vacíos o NULL
    - V2.5: 0 errores en log para scripts de Fase 2
    - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5_

  - [x] 2.3 Crear `ws-ordenamiento/data/synthetic/validate_fase3.sh`
    - V3.1: 0 tipo_persona NULL en datos_tipo_cuenta
    - V3.2: 0 hashes con LENGTH != 32 en hash_carac_direc
    - V3.3: Nuevos registros insertados hoy en ubicacion_atributo_hash (> 0)
    - V3.4: Registros actualizados hoy en ubicacion_atributo_hash (> 0)
    - V3.5: 0 errores en log para scripts de Fase 3
    - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5_

- [x] 3. Crear orquestador y script de limpieza
  - [x] 3.1 Crear `ws-ordenamiento/data/synthetic/run_tests.sh` — orquestador maestro
    - Soportar flags: `--skip-load`, `--skip-to-fase N`, `--cleanup-only`
    - Flujo: shared → split_dataset → cargar batches → Fase1 → validate_fase1 → Fase2 → validate_fase2 → Fase3 → validate_fase3 → resumen
    - Cada paso imprime `[PASO] OK` o `[PASO] FAILED: mensaje`
    - Stop-on-failure: si un paso falla, imprimir resumen parcial y salir
    - Registrar tiempos por paso y mostrar resumen al final
    - Referenciar scripts SQL desde `ws-ordenamiento/src/redshift/`
    - _Requirements: 3.1, 3.2, 3.3, 4.1, 4.2, 4.3, 4.4, 4.5, 6.1, 6.2, 6.3, 6.4, 6.5, 8.1, 8.2, 8.3, 8.4, 8.5, 8.6_

  - [x] 3.2 Crear `ws-ordenamiento/data/synthetic/cleanup_test.sql`
    - DROP IF EXISTS para todas las tablas intermedias de rec_stage (Fase 1, 2, 3)
    - TRUNCATE rec_stage.log_ejecucion
    - DROP rec_stage.personas_raw
    - Preservar tablas de rec_datos (control_ordenamiento, cuenta_atributo_hash, ubicacion_atributo_hash)
    - Idempotente: seguro ejecutar múltiples veces
    - _Requirements: 11.1, 11.2, 11.3, 11.4_

- [x] 4. Checkpoint — Verificar scripts creados
  - Ensure all scripts have correct permissions (chmod +x), ask the user if questions arise.
  - Verificar que `run_sql_file.sh --dry-run` funciona con un archivo SQL de prueba
  - Verificar que `split_dataset.sh` genera los batches correctamente

- [x] 5. Ejecutar pipeline completo contra Redshift
  - [x] 5.1 Ejecutar `split_dataset.sh` para generar batches del dataset
    - Confirmar que se generan ~110 batches de ≤80KB
    - _Requirements: 2.6_

  - [x] 5.2 Ejecutar scripts shared (infraestructura)
    - `run_sql_file.sh ws-ordenamiento/src/redshift/shared/00_schemas_tablas_control.sql`
    - `run_sql_file.sh ws-ordenamiento/src/redshift/shared/01_log_ejecucion.sql`
    - Confirmar schemas rec_stage y rec_datos creados
    - _Requirements: 3.1, 3.2, 3.3_

  - [x] 5.3 Cargar dataset sintético en Redshift
    - Ejecutar todos los batches secuencialmente via `run_sql_file.sh`
    - Validar conteos: personas_raw=10500, vu_cuenta≈40900, relacion_persona_ubicacion≈31700
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5_

  - [x] 5.4 Ejecutar Fase 1 (Materialización) y validar
    - Ejecutar 4 scripts de fase1_materializacion/ en orden
    - Ejecutar `validate_fase1.sh`
    - Documentar resultados y tiempos
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 5.1, 5.2, 5.3_

  - [x] 5.5 Ejecutar Fase 2 (Atributos Cuenta) y validar
    - Ejecutar 5 scripts de fase2_atributos_cuenta/ en orden
    - Ejecutar `validate_fase2.sh`
    - Documentar resultados y tiempos
    - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 7.1, 7.2, 7.3, 7.4, 7.5_

  - [x] 5.6 Ejecutar Fase 3 (Ubicaciones) y validar
    - Ejecutar 6 scripts de fase3_ubicaciones/ en orden
    - Ejecutar `validate_fase3.sh`
    - Documentar resultados y tiempos
    - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5, 8.6, 9.1, 9.2, 9.3, 9.4, 9.5_

- [x] 6. Checkpoint — Pipeline ejecutado
  - Ensure all tests pass, ask the user if questions arise.
  - Si algún script falló, documentar el error, aplicar fix en el SQL migrado, y re-ejecutar con `--skip-to-fase`

- [x] 7. Documentar resultados
  - [x] 7.1 Crear `ws-ordenamiento/docs/tecnico/pruebas_ejecucion_redshift_10k.md`
    - Incluir: fecha, ambiente, dataset, orden de ejecución
    - Tabla resumen con 15 scripts y estado (OK/FAILED)
    - Tiempos por script y por fase
    - Resultados de validaciones por checkpoint
    - Bugs encontrados con: script, statement, error, causa, fix, re-test
    - Conclusión y próximos pasos
    - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5_

- [x] 8. Final checkpoint — Limpieza y cierre
  - Ensure all tests pass, ask the user if questions arise.
  - Ejecutar `cleanup_test.sql` si el usuario lo solicita
  - Confirmar que el documento de resultados está completo

## Notes

- Todos los scripts se crean en `ws-ordenamiento/data/synthetic/`
- Los scripts SQL migrados están en `ws-ordenamiento/src/redshift/`
- El dataset ya existe: `ws-ordenamiento/data/synthetic/dataset_10k.sql`
- El patrón de `run_sql.sh` se reutiliza de `ws-unificacion/data/mock/run_sql.sh`
- No se usa Property-Based Testing: es un pipeline de integración contra servicio externo con dataset fijo
- Tiempos estimados del pipeline completo: 20-40 minutos
- Checkpoints permiten re-ejecutar parcialmente con `--skip-to-fase N`
