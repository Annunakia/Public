# Requirements Document — Pruebas de Ejecución en Redshift para Ordenamiento 242

## Introduction

Validación end-to-end de los 15 scripts SQL migrados del proceso Ordenamiento 242 (Teradata → Redshift) ejecutándolos contra un clúster real de Redshift Serverless con un dataset sintético de 10,000 personas. El objetivo es confirmar que los scripts ejecutan sin errores, producen resultados coherentes y las tablas intermedias/definitivas contienen los datos esperados.

## Glossary

- **Redshift_Cluster**: Workgroup `experian-sandbox-dev-redshift-workgroup`, database `dev`, region `us-east-1`, profile `sandbox`
- **Dataset_10K**: Dataset sintético de 10,000 personas generado por `ws-ordenamiento/data/synthetic/generate.py` con seed=42
- **Run_SQL_Helper**: Script bash que ejecuta sentencias SQL contra Redshift via AWS Data API (patrón de `ws-unificacion/data/mock/run_sql.sh`)
- **Run_SQL_File_Helper**: Script bash que ejecuta archivos SQL completos contra Redshift via AWS Data API, dividiendo por sentencias
- **Fase1**: Scripts de materialización + unificación (shared + fase1_materializacion/)
- **Fase2**: Scripts de atributos de cuenta (fase2_atributos_cuenta/)
- **Fase3**: Scripts de ubicaciones/direcciones (fase3_ubicaciones/)
- **Validation_Query**: Consulta SQL que verifica conteos, valores específicos o invariantes después de ejecutar un script
- **Checkpoint**: Punto de validación entre fases donde se verifican resultados intermedios

## Requirements

### Requirement 1: Preparación del Helper de Ejecución SQL

**User Story:** As a developer, I want a helper script that executes SQL files against Redshift via Data API, so that I can run the migrated scripts without needing psql or a direct connection.

#### Acceptance Criteria

1. THE Run_SQL_Helper SHALL execute a single SQL statement against the Redshift_Cluster and return the result or error message
2. THE Run_SQL_File_Helper SHALL execute a complete SQL file against the Redshift_Cluster, splitting by semicolons and executing each statement sequentially
3. WHEN a statement fails, THE Run_SQL_File_Helper SHALL report the failing statement number, the SQL text, and the error message
4. THE Run_SQL_File_Helper SHALL use the AWS profile `sandbox`, region `us-east-1`, workgroup `experian-sandbox-dev-redshift-workgroup`, and database `dev`
5. THE Run_SQL_File_Helper SHALL support a `--dry-run` flag that prints statements without executing them

### Requirement 2: Carga del Dataset Sintético en Redshift

**User Story:** As a developer, I want to load the 10K synthetic dataset into Redshift, so that the migrated scripts have input data to process.

#### Acceptance Criteria

1. WHEN the dataset is loaded, THE Redshift_Cluster SHALL contain schemas `rec_stage` and `rec_datos` with all required tables populated
2. THE Dataset_10K SHALL load the following tables: `rec_datos.control_ordenamiento`, `rec_datos.metadata_carga_log`, `rec_stage.personas_raw`, `rec_datos.vu_cuenta`, `rec_datos.relacion_persona_ubicacion`, `rec_datos.v_bloqueo`, `rec_datos.v_unificacion_direccion`, `rec_datos.cuenta_atributo_hash`, `rec_datos.ubicacion_atributo_hash`
3. WHEN the load completes, THE table `rec_stage.personas_raw` SHALL contain exactly 10,500 rows (10,000 unique + 500 duplicates)
4. WHEN the load completes, THE table `rec_datos.vu_cuenta` SHALL contain approximately 40,900 rows
5. WHEN the load completes, THE table `rec_datos.relacion_persona_ubicacion` SHALL contain approximately 31,700 rows
6. IF the dataset file exceeds the Data API statement size limit, THEN THE loading process SHALL split the file into batches and execute them sequentially

### Requirement 3: Ejecución de Scripts Shared (Infraestructura)

**User Story:** As a developer, I want to execute the shared infrastructure scripts first, so that schemas, control tables, and log tables exist before running the processing phases.

#### Acceptance Criteria

1. THE Run_SQL_File_Helper SHALL execute `shared/00_schemas_tablas_control.sql` successfully against the Redshift_Cluster
2. THE Run_SQL_File_Helper SHALL execute `shared/01_log_ejecucion.sql` successfully against the Redshift_Cluster
3. WHEN both scripts complete, THE Redshift_Cluster SHALL contain schemas `rec_stage` and `rec_datos`, tables `rec_datos.control_ordenamiento`, `rec_datos.cuenta_atributo_hash`, `rec_datos.ubicacion_atributo_hash`, and `rec_stage.log_ejecucion`

### Requirement 4: Ejecución de Fase 1 — Materialización + Unificación

**User Story:** As a developer, I want to execute the 4 Fase 1 scripts in order, so that I can validate the materialization and deduplication logic works correctly in Redshift.

#### Acceptance Criteria

1. THE Run_SQL_File_Helper SHALL execute `fase1_materializacion/01_materializa_btt.sql` successfully
2. THE Run_SQL_File_Helper SHALL execute `fase1_materializacion/02_materializa_rec.sql` successfully
3. THE Run_SQL_File_Helper SHALL execute `fase1_materializacion/03_unifica_btt_rec.sql` successfully
4. THE Run_SQL_File_Helper SHALL execute `fase1_materializacion/04_limpieza_validacion.sql` successfully
5. WHEN all Fase 1 scripts complete, THE table `rec_stage.unifica_btt_reconocer` SHALL contain exactly 10,000 unique pairs (cod_pin_persona, id_buro_persona) from the 10,500 raw records

### Requirement 5: Validación Checkpoint Fase 1

**User Story:** As a developer, I want to validate Fase 1 results before proceeding, so that I can detect errors early.

#### Acceptance Criteria

1. WHEN Fase 1 completes, THE Validation_Query SHALL confirm `rec_stage.unifica_btt_reconocer` has exactly 10,000 rows
2. WHEN Fase 1 completes, THE Validation_Query SHALL confirm no rows in `rec_stage.log_ejecucion` have `evento = 'ERROR'`
3. WHEN Fase 1 completes, THE Validation_Query SHALL confirm `SELECT COUNT(DISTINCT cod_pin_persona || '-' || id_buro_persona)` equals the total row count (no duplicates remain)
4. IF any validation fails, THEN THE process SHALL stop and report the failing validation with actual vs expected values

### Requirement 6: Ejecución de Fase 2 — Atributos de Cuenta

**User Story:** As a developer, I want to execute the 5 Fase 2 scripts in order, so that I can validate the account attribute calculation and portfolio classification logic.

#### Acceptance Criteria

1. THE Run_SQL_File_Helper SHALL execute `fase2_atributos_cuenta/01_cta_atributos.sql` successfully
2. THE Run_SQL_File_Helper SHALL execute `fase2_atributos_cuenta/02_cta_totales_personas.sql` successfully
3. THE Run_SQL_File_Helper SHALL execute `fase2_atributos_cuenta/03_cta_totales_personas_1.sql` successfully
4. THE Run_SQL_File_Helper SHALL execute `fase2_atributos_cuenta/04_cta_totales_personas_2.sql` successfully
5. THE Run_SQL_File_Helper SHALL execute `fase2_atributos_cuenta/05_concat_atributos.sql` successfully

### Requirement 7: Validación Checkpoint Fase 2

**User Story:** As a developer, I want to validate Fase 2 results, so that I can confirm portfolio classification and hash generation work correctly.

#### Acceptance Criteria

1. WHEN Fase 2 completes, THE Validation_Query SHALL confirm `rec_stage.cta_totales_personas_tmp3` has rows with non-null Portafolio values
2. WHEN Fase 2 completes, THE Validation_Query SHALL confirm all Portafolio values are within the valid set (CO, RO, VE, HP, IN, OT, CC, AH, CT)
3. WHEN Fase 2 completes, THE Validation_Query SHALL confirm `rec_stage.concatena_atributos` has rows with `cod_hash` of exactly 32 characters (MD5 format)
4. WHEN Fase 2 completes, THE Validation_Query SHALL confirm `rec_stage.concatena_atributos` has non-empty `concatena` values
5. WHEN Fase 2 completes, THE Validation_Query SHALL confirm no rows in `rec_stage.log_ejecucion` have `evento = 'ERROR'` for Fase 2 scripts

### Requirement 8: Ejecución de Fase 3 — Ubicaciones / Direcciones

**User Story:** As a developer, I want to execute the 6 Fase 3 scripts in order, so that I can validate the location processing, hash calculation, and persistence logic.

#### Acceptance Criteria

1. THE Run_SQL_File_Helper SHALL execute `fase3_ubicaciones/01_ubic_direcciones.sql` successfully
2. THE Run_SQL_File_Helper SHALL execute `fase3_ubicaciones/02_calc_ubicaciones.sql` successfully
3. THE Run_SQL_File_Helper SHALL execute `fase3_ubicaciones/03_calc_ubicaciones_1.sql` successfully
4. THE Run_SQL_File_Helper SHALL execute `fase3_ubicaciones/04_calc_ubicaciones_2.sql` successfully
5. THE Run_SQL_File_Helper SHALL execute `fase3_ubicaciones/05_concat_direcciones.sql` successfully
6. THE Run_SQL_File_Helper SHALL execute `fase3_ubicaciones/06_final_ubic_direcciones.sql` successfully

### Requirement 9: Validación Checkpoint Fase 3

**User Story:** As a developer, I want to validate Fase 3 results, so that I can confirm location enrichment, hash generation, and INSERT/UPDATE persistence work correctly.

#### Acceptance Criteria

1. WHEN Fase 3 completes, THE Validation_Query SHALL confirm `rec_stage.datos_tipo_cuenta` has rows with non-null enrichment columns (tipo_persona, tipo_cuenta)
2. WHEN Fase 3 completes, THE Validation_Query SHALL confirm `rec_stage.hash_carac_direc` has rows with `cod_hash` of exactly 32 characters
3. WHEN Fase 3 completes, THE Validation_Query SHALL confirm `rec_datos.ubicacion_atributo_hash` has new rows inserted (rows with `fecha_insercion = CURRENT_DATE`)
4. WHEN Fase 3 completes, THE Validation_Query SHALL confirm `rec_datos.ubicacion_atributo_hash` has rows updated (rows with `fecha_actualizacion = CURRENT_DATE` where `fecha_insercion < CURRENT_DATE`)
5. WHEN Fase 3 completes, THE Validation_Query SHALL confirm no rows in `rec_stage.log_ejecucion` have `evento = 'ERROR'` for Fase 3 scripts

### Requirement 10: Documentación de Resultados

**User Story:** As a developer, I want a consolidated results document, so that I can reference the test execution outcomes and share with the team.

#### Acceptance Criteria

1. THE documentation SHALL be created at `ws-ordenamiento/docs/tecnico/pruebas_ejecucion_redshift_10k.md`
2. THE documentation SHALL include: date, environment details, dataset description, execution order, per-script status (OK/FAILED), validation query results, and any bugs found
3. WHEN a script fails, THE documentation SHALL include the error message, the failing SQL statement, and the fix applied
4. THE documentation SHALL include a summary table with all 15 scripts and their execution status
5. THE documentation SHALL include timing information for each script execution

### Requirement 11: Limpieza Post-Prueba

**User Story:** As a developer, I want a cleanup script, so that I can reset the Redshift environment after testing without leaving orphan tables.

#### Acceptance Criteria

1. THE cleanup script SHALL drop all `rec_stage` intermediate tables created during the test
2. THE cleanup script SHALL preserve `rec_datos` tables (control_ordenamiento, cuenta_atributo_hash, ubicacion_atributo_hash) since they are persistent
3. THE cleanup script SHALL be idempotent (safe to run multiple times)
4. THE cleanup script SHALL be located at `ws-ordenamiento/data/synthetic/cleanup_test.sql`
