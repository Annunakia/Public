# Documento de Diseño — Pruebas de Ejecución en Redshift para Ordenamiento 242

## Resumen

Pipeline de pruebas end-to-end para validar los 15 scripts SQL migrados del proceso Ordenamiento 242 ejecutándolos contra Redshift Serverless con un dataset sintético de 10,000 personas. El pipeline carga datos, ejecuta scripts por fase, valida resultados en cada checkpoint y documenta los hallazgos.

---

## Arquitectura

### Visión General del Pipeline

```mermaid
graph TD
    subgraph Prep["Preparación"]
        H1[run_sql.sh<br/>Sentencia individual]
        H2[run_sql_file.sh<br/>Archivo completo]
        SPLIT[split_dataset.sh<br/>Divide dataset en batches]
    end

    subgraph Load["Carga de Datos"]
        SHARED[shared/00_schemas_tablas_control.sql<br/>shared/01_log_ejecucion.sql]
        DATASET[dataset_10k.sql<br/>~8.8MB en batches de 80KB]
    end

    subgraph Exec["Ejecución por Fases"]
        F1[Fase 1: Materialización<br/>4 scripts]
        V1[Checkpoint Fase 1<br/>Validación]
        F2[Fase 2: Atributos Cuenta<br/>5 scripts]
        V2[Checkpoint Fase 2<br/>Validación]
        F3[Fase 3: Ubicaciones<br/>6 scripts]
        V3[Checkpoint Fase 3<br/>Validación]
    end

    subgraph Doc["Documentación"]
        RESULTS[pruebas_ejecucion_redshift_10k.md]
    end

    subgraph Clean["Limpieza"]
        CLEANUP[cleanup_test.sql]
    end

    Prep --> Load
    Load --> SHARED
    SHARED --> DATASET
    DATASET --> F1
    F1 --> V1
    V1 -->|OK| F2
    V1 -->|FAIL| Doc
    F2 --> V2
    V2 -->|OK| F3
    V2 -->|FAIL| Doc
    F3 --> V3
    V3 --> Doc
    Doc --> Clean
```

### Decisiones Arquitectónicas

| Decisión | Elección | Justificación |
|----------|----------|---------------|
| Ejecución SQL | AWS Data API via CLI | No requiere psql ni conexión directa. Reutiliza patrón probado en ws-unificacion. |
| Splitting de dataset | Batches de ~80KB | Data API tiene límite de 100KB por statement. Margen de seguridad del 20%. |
| Validación | Queries SQL individuales via run_sql.sh | Cada validación es atómica y reporta resultado inmediato. |
| Orquestación | Script bash maestro (`run_tests.sh`) | Simple, secuencial, con stop-on-failure. No requiere infraestructura adicional. |
| Documentación | Markdown generado manualmente | Consistente con patrón existente en `ws-unificacion/docs/tecnico/`. |
| Cleanup | SQL idempotente | DROP IF EXISTS permite re-ejecutar sin efectos secundarios. |

### Flujo de Ejecución Detallado

```mermaid
sequenceDiagram
    participant DEV as Developer
    participant RUN as run_tests.sh
    participant RSQL as run_sql_file.sh
    participant RS as Redshift
    participant VAL as Validaciones

    DEV->>RUN: ./run_tests.sh
    
    Note over RUN,RS: Fase 0: Infraestructura
    RUN->>RSQL: shared/00_schemas_tablas_control.sql
    RSQL->>RS: CREATE SCHEMA, CREATE TABLE
    RUN->>RSQL: shared/01_log_ejecucion.sql
    RSQL->>RS: CREATE TABLE log_ejecucion
    
    Note over RUN,RS: Fase 0: Carga Dataset
    RUN->>RSQL: dataset_batch_001.sql ... batch_N.sql
    RSQL->>RS: INSERT INTO (batches secuenciales)
    
    Note over RUN,RS: Fase 1: Materialización
    RUN->>RSQL: fase1/01..04 (secuencial)
    RSQL->>RS: Ejecuta 4 scripts
    RUN->>VAL: Checkpoint Fase 1
    VAL->>RS: COUNT unifica_btt_reconocer = 10000?
    VAL-->>RUN: OK / FAIL
    
    Note over RUN,RS: Fase 2: Atributos Cuenta
    RUN->>RSQL: fase2/01..05 (secuencial)
    RSQL->>RS: Ejecuta 5 scripts
    RUN->>VAL: Checkpoint Fase 2
    VAL->>RS: Portafolio válido? Hash 32 chars?
    VAL-->>RUN: OK / FAIL
    
    Note over RUN,RS: Fase 3: Ubicaciones
    RUN->>RSQL: fase3/01..06 (secuencial)
    RSQL->>RS: Ejecuta 6 scripts
    RUN->>VAL: Checkpoint Fase 3
    VAL->>RS: INSERT/UPDATE en hash tables?
    VAL-->>RUN: OK / FAIL
    
    RUN->>DEV: Resumen de resultados
```

---

## Componentes e Interfaces

### Estructura de Archivos del Pipeline

```
ws-ordenamiento/data/synthetic/
├── generate.py                    # Generador del dataset (existente)
├── dataset_10k.sql                # Dataset completo ~8.8MB (existente)
├── README.md                      # Documentación del dataset (existente)
├── run_sql.sh                     # Helper: ejecuta 1 sentencia SQL
├── run_sql_file.sh                # Helper: ejecuta archivo SQL completo
├── split_dataset.sh               # Divide dataset_10k.sql en batches
├── run_tests.sh                   # Orquestador maestro del pipeline
├── validate_fase1.sh              # Validaciones checkpoint Fase 1
├── validate_fase2.sh              # Validaciones checkpoint Fase 2
├── validate_fase3.sh              # Validaciones checkpoint Fase 3
├── cleanup_test.sql               # SQL de limpieza post-prueba
└── batches/                       # Directorio generado por split_dataset.sh
    ├── batch_001.sql
    ├── batch_002.sql
    └── ...
```

### Componente 1: `run_sql.sh` — Ejecutor de Sentencia Individual

Reutiliza el patrón existente de `ws-unificacion/data/mock/run_sql.sh`.

**Interfaz:**
```bash
./run_sql.sh "SQL_STATEMENT" [label]
```

**Comportamiento:**
- Ejecuta una sentencia SQL via `aws redshift-data execute-statement`
- Polling cada 2 segundos hasta FINISHED/FAILED/ABORTED (timeout 120s)
- Si hay resultados, los imprime en formato tabla
- Exit code: 0 = éxito, 1 = error

**Configuración hardcoded:**
```bash
PROFILE="sandbox"
REGION="us-east-1"
WORKGROUP="experian-sandbox-dev-redshift-workgroup"
DB="dev"
```

### Componente 2: `run_sql_file.sh` — Ejecutor de Archivo SQL

**Interfaz:**
```bash
./run_sql_file.sh <archivo.sql> [--dry-run]
```

**Comportamiento:**
1. Lee el archivo SQL completo
2. Divide por `;` (respetando comentarios y strings)
3. Filtra sentencias vacías y comentarios puros
4. Ejecuta cada sentencia secuencialmente via `run_sql.sh`
5. Si una sentencia falla: reporta número, SQL truncado, error, y sale con código 1
6. Con `--dry-run`: imprime sentencias numeradas sin ejecutar

**Parsing de sentencias:**
- Ignora `;` dentro de strings (`'...'`)
- Ignora `;` dentro de comentarios (`--` hasta fin de línea, `/* ... */`)
- Trim de whitespace y líneas vacías entre sentencias
- Sentencias que son solo comentarios se saltan

### Componente 3: `split_dataset.sh` — Divisor de Dataset

**Interfaz:**
```bash
./split_dataset.sh
```

**Comportamiento:**
1. Lee `dataset_10k.sql` (~8.8MB)
2. Separa las sentencias DDL (CREATE SCHEMA, CREATE TABLE, DROP TABLE) de los INSERTs
3. Agrupa INSERTs en batches de máximo 80KB cada uno
4. Genera `batches/batch_001.sql`, `batch_002.sql`, etc.
5. El primer batch incluye las sentencias DDL
6. Reporta: número de batches generados, tamaño promedio

**Lógica de splitting:**
- Cada INSERT es una línea completa (el generador produce 1 INSERT por línea)
- Acumula líneas hasta que el buffer supere 80KB
- Cierra el batch actual y abre uno nuevo
- Garantiza que ningún batch exceda 95KB (margen para overhead del API)

### Componente 4: `run_tests.sh` — Orquestador Maestro

**Interfaz:**
```bash
./run_tests.sh [--skip-load] [--skip-to-fase N] [--cleanup-only]
```

**Comportamiento:**
1. `--skip-load`: Salta la carga del dataset (asume ya cargado)
2. `--skip-to-fase N`: Salta directamente a fase N (asume fases previas OK)
3. `--cleanup-only`: Solo ejecuta limpieza

**Flujo normal:**
```
1. Ejecutar shared/00_schemas_tablas_control.sql
2. Ejecutar shared/01_log_ejecucion.sql
3. Ejecutar split_dataset.sh (genera batches)
4. Cargar batches secuencialmente
5. Validar carga (conteos de tablas)
6. Ejecutar Fase 1 (4 scripts secuenciales)
7. Validar Fase 1 (checkpoint)
8. Ejecutar Fase 2 (5 scripts secuenciales)
9. Validar Fase 2 (checkpoint)
10. Ejecutar Fase 3 (6 scripts secuenciales)
11. Validar Fase 3 (checkpoint)
12. Imprimir resumen
```

**Output:** Cada paso imprime `[PASO] OK` o `[PASO] FAILED: mensaje`. Al final, resumen con tiempos.

### Componente 5: Scripts de Validación por Fase

Cada `validate_faseN.sh` ejecuta queries de validación y reporta resultados.

**Patrón común:**
```bash
#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
source "$SCRIPT_DIR/run_sql.sh" 2>/dev/null  # No, mejor llamar directamente

ERRORS=0

# Validación 1: Conteo
RESULT=$(./run_sql.sh "SELECT COUNT(*) FROM rec_stage.tabla" "conteo_tabla")
EXPECTED=10000
if [[ "$RESULT" != *"$EXPECTED"* ]]; then
    echo "FAIL: tabla esperaba $EXPECTED filas"
    ERRORS=$((ERRORS + 1))
fi

# ... más validaciones ...

exit $ERRORS
```

---

## Modelo de Datos

### Tablas de Entrada (cargadas por dataset_10k.sql)

| Schema | Tabla | Filas | Propósito |
|--------|-------|-------|-----------|
| `rec_datos` | `control_ordenamiento` | 1 | Fecha de control: 2024-06-15 |
| `rec_datos` | `metadata_carga_log` | 150 | Lotes de carga (60% post-control) |
| `rec_stage` | `personas_raw` | 10,500 | 10K únicos + 500 duplicados |
| `rec_datos` | `vu_cuenta` | ~40,900 | Cuentas con atributos |
| `rec_datos` | `relacion_persona_ubicacion` | ~31,700 | Ubicaciones con flags |
| `rec_datos` | `v_bloqueo` | 300 | Personas bloqueadas |
| `rec_datos` | `v_unificacion_direccion` | 200 | Personas unificadas |
| `rec_datos` | `cuenta_atributo_hash` | ~8,200 | Hashes existentes (cuentas) |
| `rec_datos` | `ubicacion_atributo_hash` | ~6,400 | Hashes existentes (ubicaciones) |

### Tablas Intermedias Generadas (por los scripts de Ordenamiento)

| Fase | Tabla | Generada por | Validación |
|------|-------|-------------|------------|
| 1 | `rec_stage.unifica_btt_reconocer` | 03_unifica_btt_rec.sql | COUNT = 10,000 |
| 2 | `rec_stage.cta_totales_personas_tmp3` | 04_cta_totales_personas_2.sql | Portafolio ∈ {CO,RO,...} |
| 2 | `rec_stage.concatena_atributos` | 05_concat_atributos.sql | LENGTH(cod_hash) = 32 |
| 3 | `rec_stage.datos_tipo_cuenta` | 04_calc_ubicaciones_2.sql | tipo_persona NOT NULL |
| 3 | `rec_stage.hash_carac_direc` | 05_concat_direcciones.sql | LENGTH(cod_hash) = 32 |

### Tablas Definitivas Modificadas

| Tabla | Operación | Validación |
|-------|-----------|------------|
| `rec_datos.ubicacion_atributo_hash` | INSERT nuevos + UPDATE modificados | fecha_insercion = CURRENT_DATE (nuevos) |

---

## Queries de Validación por Checkpoint

### Checkpoint Carga de Datos

```sql
-- V0.1: Personas raw cargadas
SELECT COUNT(*) AS total FROM rec_stage.personas_raw;
-- Esperado: 10500

-- V0.2: Cuentas cargadas
SELECT COUNT(*) AS total FROM rec_datos.vu_cuenta;
-- Esperado: ~40900

-- V0.3: Ubicaciones cargadas
SELECT COUNT(*) AS total FROM rec_datos.relacion_persona_ubicacion;
-- Esperado: ~31700

-- V0.4: Control ordenamiento
SELECT fecha_ult_ord FROM rec_datos.control_ordenamiento;
-- Esperado: 2024-06-15
```

### Checkpoint Fase 1

```sql
-- V1.1: Tabla unificada tiene exactamente 10,000 filas
SELECT COUNT(*) AS total FROM rec_stage.unifica_btt_reconocer;
-- Esperado: 10000

-- V1.2: No hay duplicados
SELECT COUNT(*) AS total,
       COUNT(DISTINCT cod_pin_persona || '-' || CAST(id_buro_persona AS VARCHAR))
         AS distintos
FROM rec_stage.unifica_btt_reconocer;
-- Esperado: total = distintos = 10000

-- V1.3: No hay errores en log
SELECT COUNT(*) AS errores
FROM rec_stage.log_ejecucion
WHERE evento = 'ERROR';
-- Esperado: 0

-- V1.4: Log tiene registros de ejecución
SELECT COUNT(*) AS registros_log
FROM rec_stage.log_ejecucion
WHERE fase = 'Fase 1';
-- Esperado: >= 4 (al menos 1 INICIO por script)
```

### Checkpoint Fase 2

```sql
-- V2.1: Portafolios válidos
SELECT DISTINCT portafolio
FROM rec_stage.cta_totales_personas_tmp3
WHERE portafolio NOT IN ('CO','RO','VE','HP','IN','OT','CC','AH','CT');
-- Esperado: 0 filas (ningún portafolio inválido)

-- V2.2: Portafolios no nulos
SELECT COUNT(*) AS sin_portafolio
FROM rec_stage.cta_totales_personas_tmp3
WHERE portafolio IS NULL;
-- Esperado: 0

-- V2.3: Hash MD5 formato correcto
SELECT COUNT(*) AS hash_invalido
FROM rec_stage.concatena_atributos
WHERE LENGTH(cod_hash) != 32;
-- Esperado: 0

-- V2.4: Concatena no vacío
SELECT COUNT(*) AS concat_vacio
FROM rec_stage.concatena_atributos
WHERE concatena IS NULL OR concatena = '';
-- Esperado: 0

-- V2.5: Sin errores Fase 2
SELECT COUNT(*) AS errores
FROM rec_stage.log_ejecucion
WHERE evento = 'ERROR'
  AND nombre_procedimiento IN (
    'cta_atributos', 'cta_totales_personas',
    'cta_totales_personas_1', 'cta_totales_personas_2',
    'concat_atributos'
  );
-- Esperado: 0
```

### Checkpoint Fase 3

```sql
-- V3.1: Enriquecimiento de datos
SELECT COUNT(*) AS sin_tipo_persona
FROM rec_stage.datos_tipo_cuenta
WHERE tipo_persona IS NULL;
-- Esperado: 0 (o un porcentaje bajo aceptable)

-- V3.2: Hash ubicaciones formato correcto
SELECT COUNT(*) AS hash_invalido
FROM rec_stage.hash_carac_direc
WHERE LENGTH(cod_hash) != 32;
-- Esperado: 0

-- V3.3: Nuevos registros insertados
SELECT COUNT(*) AS nuevos_hoy
FROM rec_datos.ubicacion_atributo_hash
WHERE fecha_insercion = CURRENT_DATE;
-- Esperado: > 0

-- V3.4: Registros actualizados
SELECT COUNT(*) AS actualizados_hoy
FROM rec_datos.ubicacion_atributo_hash
WHERE fecha_actualizacion = CURRENT_DATE
  AND fecha_insercion < CURRENT_DATE;
-- Esperado: > 0

-- V3.5: Sin errores Fase 3
SELECT COUNT(*) AS errores
FROM rec_stage.log_ejecucion
WHERE evento = 'ERROR'
  AND nombre_procedimiento IN (
    'ubic_direcciones', 'calc_ubicaciones',
    'calc_ubicaciones_1', 'calc_ubicaciones_2',
    'concat_direcciones', 'final_ubic_direcciones'
  );
-- Esperado: 0
```

---

## Manejo de Errores

### Estrategia por Componente

| Componente | Error | Acción |
|------------|-------|--------|
| `run_sql.sh` | Statement FAILED | Imprime error, exit 1 |
| `run_sql.sh` | Timeout (120s) | Imprime TIMEOUT, exit 1 |
| `run_sql_file.sh` | Statement N falla | Imprime N, SQL, error, exit 1 |
| `split_dataset.sh` | Archivo no encontrado | Imprime error, exit 1 |
| `run_tests.sh` | Cualquier paso falla | Imprime resumen parcial, exit 1 |
| `validate_faseN.sh` | Validación falla | Imprime FAIL con actual vs esperado, continúa con las demás, exit con count de errores |

### Patrón de Reporte de Error

```
[FASE 1 / Script 03] FAILED
  Statement: 5 de 12
  SQL: CREATE TABLE rec_stage.unifica_btt_reconocer AS SELECT DISTINCT...
  Error: relation "rec_stage.paso_v_cuenta" does not exist
  Tiempo transcurrido: 45s
```

### Reintentos

No se implementan reintentos automáticos. Si un script falla:
1. El pipeline se detiene
2. El developer diagnostica el error
3. Puede re-ejecutar con `--skip-to-fase N` después de corregir

---

## Estrategia de Testing

### Por qué NO se usa Property-Based Testing

Este feature es un **pipeline de integración** que ejecuta scripts SQL contra un servicio externo (Redshift). No es apropiado para PBT porque:

1. **Prueba servicios externos**: Valida que scripts SQL ejecutan correctamente en Redshift, no lógica pura local
2. **Dataset fijo y determinista**: El dataset_10k.sql es generado con seed=42, los resultados esperados son conocidos
3. **Comportamiento no varía con input**: Los scripts siempre procesan el mismo dataset
4. **Costo alto por iteración**: Cada ejecución consume recursos de Redshift Serverless
5. **Los scripts bajo prueba ya tienen PBT**: La lógica de negocio fue validada con propiedades en el spec de migración

### Enfoque de Testing Aplicado

| Tipo | Qué valida | Herramienta |
|------|-----------|-------------|
| **Integration tests** | Scripts ejecutan sin error en Redshift real | run_sql_file.sh + exit codes |
| **Smoke tests** | Infraestructura existe (schemas, tablas) | run_sql.sh + queries de existencia |
| **Validation queries** | Resultados correctos (conteos, formatos, invariantes) | run_sql.sh + comparación de valores |
| **Idempotency tests** | Re-ejecutar no rompe nada | Ejecutar pipeline 2 veces, mismos resultados |

### Criterios de Éxito

| Criterio | Métrica |
|----------|---------|
| Todos los scripts ejecutan | 15/15 con exit code 0 |
| Deduplicación correcta | unifica_btt_reconocer = 10,000 filas exactas |
| Portafolios válidos | 100% dentro del set {CO,RO,VE,HP,IN,OT,CC,AH,CT} |
| Hashes correctos | 100% con LENGTH = 32 |
| Persistencia funciona | INSERT nuevos > 0, UPDATE modificados > 0 |
| Sin errores en log | 0 registros con evento='ERROR' |

---

## Template de Documentación de Resultados

El archivo `ws-ordenamiento/docs/tecnico/pruebas_ejecucion_redshift_10k.md` seguirá esta estructura:

```markdown
# Pruebas de Ejecución — Ordenamiento 242 (10K personas)

> Fecha: YYYY-MM-DD | Ambiente: experian-sandbox-dev-redshift-workgroup | Dataset: 10K (seed=42)

## Resumen

| Fase | Scripts | OK | FAILED | Tiempo Total |
|------|---------|----|---------|----|
| Shared | 2 | ? | ? | ?s |
| Carga | N batches | ? | ? | ?s |
| Fase 1 | 4 | ? | ? | ?s |
| Fase 2 | 5 | ? | ? | ?s |
| Fase 3 | 6 | ? | ? | ?s |
| **Total** | **17+N** | | | |

## Detalle por Script

| # | Script | Estado | Tiempo | Notas |
|---|--------|--------|--------|-------|
| 1 | shared/00_schemas_tablas_control.sql | OK/FAIL | Xs | |
| 2 | shared/01_log_ejecucion.sql | OK/FAIL | Xs | |
| ... | ... | ... | ... | ... |

## Validaciones

### Checkpoint Carga
| Query | Esperado | Obtenido | Estado |
|-------|----------|----------|--------|
| COUNT personas_raw | 10500 | ? | ✅/❌ |
| ... | ... | ... | ... |

### Checkpoint Fase 1
...

### Checkpoint Fase 2
...

### Checkpoint Fase 3
...

## Bugs Encontrados

### Bug N: [Título]
- **Script**: fase?/0?_nombre.sql
- **Statement**: N de M
- **Error**: mensaje
- **Causa**: explicación
- **Fix**: qué se cambió
- **Re-test**: OK/FAIL

## Conclusión

[Resumen de resultados y próximos pasos]
```

---

## Script de Limpieza

El archivo `ws-ordenamiento/data/synthetic/cleanup_test.sql` elimina todas las tablas intermedias de `rec_stage` creadas durante la prueba, preservando las tablas definitivas de `rec_datos`.

```sql
-- ============================================================
-- cleanup_test.sql — Limpieza post-prueba Ordenamiento 242
-- Idempotente: seguro ejecutar múltiples veces
-- PRESERVA: rec_datos.control_ordenamiento,
--           rec_datos.cuenta_atributo_hash,
--           rec_datos.ubicacion_atributo_hash
-- ============================================================

-- Fase 1: Tablas de materialización
DROP TABLE IF EXISTS rec_stage.estructuras_mtdat_bdm;
DROP TABLE IF EXISTS rec_stage.calcula_lote_btt;
DROP TABLE IF EXISTS rec_stage.paso_v_cuenta;
DROP TABLE IF EXISTS rec_stage.paso_v_buro_persona;
DROP TABLE IF EXISTS rec_stage.paso_v_comportamiento_cuenta;
DROP TABLE IF EXISTS rec_stage.paso_v_comport_cta_activo;
DROP TABLE IF EXISTS rec_stage.paso_v_comport_cta_pasivo;
DROP TABLE IF EXISTS rec_stage.calcula_lote_rec;
DROP TABLE IF EXISTS rec_stage.paso_reporte_ubic_original;
DROP TABLE IF EXISTS rec_stage.paso_rpu;
DROP TABLE IF EXISTS rec_stage.paso_rrpu;
DROP TABLE IF EXISTS rec_stage.paso_v_bloqueo;
DROP TABLE IF EXISTS rec_stage.paso_v_rela_ubic_estandar_geo;
DROP TABLE IF EXISTS rec_stage.paso_v_ubicacion_original;
DROP TABLE IF EXISTS rec_stage.paso_v_ubicacion_estandarizada;
DROP TABLE IF EXISTS rec_stage.paso_v_log_ubic_estandarizada;
DROP TABLE IF EXISTS rec_stage.paso_v_unificacion_direccion;
DROP TABLE IF EXISTS rec_stage.unifica_btt_reconocer;

-- Fase 2: Tablas de atributos de cuenta
DROP TABLE IF EXISTS rec_stage.cta_totales_personas_tmp1;
DROP TABLE IF EXISTS rec_stage.tmp_cnta_fechas;
DROP TABLE IF EXISTS rec_stage.stg_comportamiento_cta_activo;
DROP TABLE IF EXISTS rec_stage.tmp_comportamiento_pasivo;
DROP TABLE IF EXISTS rec_stage.cta_totales_personas_tmp2;
DROP TABLE IF EXISTS rec_stage.cta_totales_personas_tmp3;
DROP TABLE IF EXISTS rec_stage.concatena_atributos;

-- Fase 3: Tablas de ubicaciones
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal_mat;
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal1;
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal11;
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal2;
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal3;
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal6;
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal61;
DROP TABLE IF EXISTS rec_stage.vmo_reporte_relacion_pers_ubi;
DROP TABLE IF EXISTS rec_stage.vector_ubi_insumo_base;
DROP TABLE IF EXISTS rec_stage.datos_ubic_estandarizadas;
DROP TABLE IF EXISTS rec_stage.datos_tipo_persona;
DROP TABLE IF EXISTS rec_stage.datos_tipo_cuenta;
DROP TABLE IF EXISTS rec_stage.hash_carac_direc;

-- Log de ejecución (limpiar contenido, mantener tabla)
TRUNCATE TABLE rec_stage.log_ejecucion;

-- Dataset de entrada (si se quiere limpiar completamente)
DROP TABLE IF EXISTS rec_stage.personas_raw;
```

---

## Consideraciones Operativas

### Prerequisitos

1. AWS CLI configurado con profile `sandbox` y acceso a Redshift Data API
2. Python 3 disponible (para parsing de resultados en run_sql.sh)
3. Dataset generado: `python3 ws-ordenamiento/data/synthetic/generate.py`
4. Permisos IAM: `redshift-data:ExecuteStatement`, `redshift-data:DescribeStatement`, `redshift-data:GetStatementResult`

### Tiempos Estimados

| Paso | Estimación |
|------|-----------|
| Split dataset | < 5s (local) |
| Carga batches (~110 batches × 2s polling) | ~5-10 min |
| Fase 1 (4 scripts) | ~2-5 min |
| Fase 2 (5 scripts) | ~3-8 min |
| Fase 3 (6 scripts) | ~5-12 min |
| Validaciones | ~1-2 min |
| **Total estimado** | **~20-40 min** |

### Límites del Data API

| Límite | Valor | Mitigación |
|--------|-------|-----------|
| Tamaño máximo por statement | 100 KB | Split en batches de 80KB |
| Requests por segundo | 5 | Ejecución secuencial con polling |
| Timeout por statement | 24 horas | Nuestro timeout: 120s |
| Resultado máximo | 100 MB | Queries de validación retornan pocas filas |
