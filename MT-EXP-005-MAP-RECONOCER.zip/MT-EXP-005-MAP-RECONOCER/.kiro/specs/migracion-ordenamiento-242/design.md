# Documento de Diseño — Migración Ordenamiento 242

## Resumen

Diseño técnico para la migración del proceso "Ordenamiento 242" (Scoring de Contactabilidad) desde Teradata hacia Amazon Redshift. El proceso consta de 17 Stored Procedures que se migran a scripts SQL estáticos organizados por fase, ejecutables secuencialmente por un orquestador externo.

---

## Arquitectura

### Visión General

```mermaid
graph TD
    subgraph Orquestador["Orquestador Externo (Lambda/Step Functions)"]
        direction TB
        ORC[Controlador de Ejecución]
    end

    subgraph Fase1["Fase 1: Materialización + Unificación"]
        direction TB
        MAT_BTT[materializa_btt.sql]
        MAT_REC[materializa_rec.sql]
        UNIF[unifica_btt_rec.sql]
        LIMPIEZA[limpieza_validacion.sql]
        MAT_BTT --> UNIF
        MAT_REC --> UNIF
        UNIF --> LIMPIEZA
    end

    subgraph Fase2["Fase 2: Atributos de Cuenta"]
        direction TB
        CTA_ATR[cta_atributos.sql]
        CTA_TOT[cta_totales_personas.sql]
        CTA_TOT1[cta_totales_personas_1.sql]
        CTA_TOT2[cta_totales_personas_2.sql]
        CONCAT_ATR[concat_atributos.sql]
        FINAL_CTA[final_cta_atributos.sql]
        CTA_ATR --> CTA_TOT
        CTA_TOT --> CTA_TOT1
        CTA_TOT1 --> CTA_TOT2
        CTA_TOT2 --> CONCAT_ATR
        CONCAT_ATR --> FINAL_CTA
    end

    subgraph Fase3["Fase 3: Ubicaciones / Direcciones"]
        direction TB
        UBIC_DIR[ubic_direcciones.sql]
        CALC_UBI[calc_ubicaciones.sql]
        CALC_UBI1[calc_ubicaciones_1.sql]
        CALC_UBI2[calc_ubicaciones_2.sql]
        CONCAT_DIR[concat_direcciones.sql]
        FINAL_UBI[final_ubic_direcciones.sql]
        UBIC_DIR --> CALC_UBI
        UBIC_DIR --> CALC_UBI1
        CALC_UBI --> CALC_UBI2
        CALC_UBI1 --> CALC_UBI2
        CALC_UBI2 --> CONCAT_DIR
        CONCAT_DIR --> FINAL_UBI
    end

    ORC --> Fase1
    Fase1 --> Fase2
    Fase1 --> Fase3

    subgraph Schemas["Esquemas Redshift"]
        REC_STAGE[(rec_stage<br/>Tablas intermedias)]
        REC_DATOS[(rec_datos<br/>Tablas definitivas)]
    end

    Fase1 --> REC_STAGE
    Fase2 --> REC_STAGE
    Fase2 --> REC_DATOS
    Fase3 --> REC_STAGE
    Fase3 --> REC_DATOS
```

### Decisiones Arquitectónicas

| Decisión | Elección | Justificación |
|----------|----------|---------------|
| Stored Procedures vs SQL estático | **SQL estático** | Redshift no requiere SQL dinámico (esquemas fijos). Scripts más simples, auditables y versionables. |
| Esquema intermedio | `rec_stage` | Separación clara entre datos temporales y definitivos. Permite limpieza selectiva. |
| Esquema definitivo | `rec_datos` | Tablas finales que persisten entre ejecuciones (hashes, control). |
| Tablas temporales vs regulares | **Tablas regulares con DROP IF EXISTS** | Las tablas intermedias son consumidas por múltiples scripts en paralelo; las temporales de sesión no son visibles entre conexiones. |
| Orquestación | **Externa** (no parte de este spec) | Lambda, Step Functions o Airflow controlan el orden. Los scripts SQL son unidades atómicas. |
| Hash MD5 | `MD5()` nativo de Redshift | Reemplaza la UDF `rec_vista.hash_md5()`. Produce el mismo resultado para strings idénticos. |
| Paralelismo | **Controlado por orquestador** | Scripts independientes pueden ejecutarse en paralelo; el orquestador gestiona las dependencias. |

---

## Componentes e Interfaces

### Estructura de Directorio

```
ws-ordenamiento/src/redshift/
├── fase1_materializacion/
│   ├── 01_materializa_btt.sql
│   ├── 02_materializa_rec.sql
│   ├── 03_unifica_btt_rec.sql
│   └── 04_limpieza_validacion.sql
├── fase2_atributos_cuenta/
│   ├── 01_cta_atributos.sql
│   ├── 02_cta_totales_personas.sql
│   ├── 03_cta_totales_personas_1.sql
│   ├── 04_cta_totales_personas_2.sql
│   ├── 05_concat_atributos.sql
│   └── 06_final_cta_atributos.sql
├── fase3_ubicaciones/
│   ├── 01_ubic_direcciones.sql
│   ├── 02_calc_ubicaciones.sql
│   ├── 03_calc_ubicaciones_1.sql
│   ├── 04_calc_ubicaciones_2.sql
│   ├── 05_concat_direcciones.sql
│   └── 06_final_ubic_direcciones.sql
├── shared/
│   ├── 00_schemas_tablas_control.sql
│   └── 01_log_ejecucion.sql
└── _disabled/
    ├── final_cta_atributos_disabled.sql
    └── final_ubic_direcciones_v0_disabled.sql
```

### Mapeo SP Teradata → Script Redshift

| # | SP Original (Teradata) | Script Redshift | Fase | Modo |
|---|------------------------|-----------------|------|------|
| 1 | PRO_ORD_MATERIALIZA_BTT | `fase1/01_materializa_btt.sql` | 1 | Paralelo |
| 2 | PRO_ORD_MATERIALIZA_REC | `fase1/02_materializa_rec.sql` | 1 | Paralelo |
| 3 | PRO_ORD_UNIF_BTT_REC | `fase1/03_unifica_btt_rec.sql` | 1 | Secuencial |
| 4 | PRO_ORD_UNIF_BTT_REC_2 | `fase1/04_limpieza_validacion.sql` | 1 | Secuencial |
| 5 | PRO_ORD_CTA_ATRIBUTOS | `fase2/01_cta_atributos.sql` | 2 | Paralelo |
| 6 | PRO_ORD_CTA_TOTALES_PERSONAS | `fase2/02_cta_totales_personas.sql` | 2 | Secuencial |
| 7 | PRO_ORD_CTA_TOTALES_PERSONAS_1 | `fase2/03_cta_totales_personas_1.sql` | 2 | Paralelo |
| 8 | PRO_ORD_CTA_TOTALES_PERSONAS_2 | `fase2/04_cta_totales_personas_2.sql` | 2 | Paralelo |
| 9 | PRO_ORD_CONCAT_ATRIBUTOS | `fase2/05_concat_atributos.sql` | 2 | Secuencial |
| 10 | PRO_ORD_FINAL_CTA_ATRIBUTOS | `_disabled/final_cta_atributos_disabled.sql` | 2 | Deshabilitado |
| 11 | PRO_ORD_UBIC_DIRECCIONES | `fase3/01_ubic_direcciones.sql` | 3 | Paralelo |
| 12 | PRO_ORD_CALC_UBICACIONES | `fase3/02_calc_ubicaciones.sql` | 3 | Paralelo |
| 13 | PRO_ORD_CALC_UBICACIONES_1 | `fase3/03_calc_ubicaciones_1.sql` | 3 | Paralelo |
| 14 | PRO_ORD_CALC_UBICACIONES_2 | `fase3/04_calc_ubicaciones_2.sql` | 3 | Paralelo |
| 15 | PRO_ORD_CONCAT_DIRECCIONES | `fase3/05_concat_direcciones.sql` | 3 | Secuencial |
| 16 | PRO_ORD_FINAL_UBIC_DIRECCIONES | `_disabled/final_ubic_direcciones_v0_disabled.sql` | 3 | Deshabilitado |
| 17 | PRO_ORD_FINAL_UBIC_DIRECCIONES1 | `fase3/06_final_ubic_direcciones.sql` | 3 | Secuencial |

### Encabezado Estándar de Cada Script

```sql
-- ============================================================
-- Archivo: fase1/01_materializa_btt.sql
-- SP Original: PRO_ORD_MATERIALIZA_BTT
-- Fase: 1 - Materialización
-- Modo: Paralelo (con 02_materializa_rec.sql)
-- Dependencias: shared/00_schemas_tablas_control.sql
-- Input: rec_datos.control_ordenamiento, rec_datos.metadata_carga_log,
--        rec_datos.v_cuenta, rec_datos.v_buro_persona, ...
-- Output: rec_stage.paso_v_cuenta, rec_stage.paso_v_buro_persona, ...
-- ============================================================
```

### Interfaz entre Scripts

Cada script:
1. **Lee** tablas de `rec_datos` (vistas/tablas definitivas) y/o `rec_stage` (intermedias de pasos previos)
2. **Escribe** tablas en `rec_stage` (intermedias) o `rec_datos` (definitivas)
3. **Registra** inicio/fin/error en `rec_stage.log_ejecucion`
4. **Retorna** código de salida 0 (éxito) o ≠0 (error) al orquestador

---

## Modelo de Datos

### Esquema `rec_stage` — Tablas Intermedias

#### Fase 1: Materialización

| Tabla | Creada por | Consumida por | Columnas clave |
|-------|-----------|---------------|----------------|
| `estructuras_mtdat_bdm` | materializa_btt | materializa_btt | tabla_nombre, lote_id |
| `calcula_lote_btt` | materializa_btt | materializa_btt | lote_id, fecha_carga |
| `paso_v_cuenta` | materializa_btt | unifica_btt_rec | cod_pin_persona, id_buro_persona |
| `paso_v_buro_persona` | materializa_btt | unifica_btt_rec | cod_pin_persona, id_buro_persona |
| `paso_v_comportamiento_cuenta` | materializa_btt | unifica_btt_rec | cod_pin_persona, id_buro_persona |
| `paso_v_comport_cta_activo` | materializa_btt | unifica_btt_rec | cod_pin_persona, id_buro_persona |
| `paso_v_comport_cta_pasivo` | materializa_btt | unifica_btt_rec | cod_pin_persona, id_buro_persona |
| `calcula_lote_rec` | materializa_rec | materializa_rec | lote_id, fecha_carga |
| `paso_reporte_ubic_original` | materializa_rec | unifica_btt_rec | cod_pin_persona, id_buro_persona |
| `paso_rpu` | materializa_rec | unifica_btt_rec | cod_pin_persona, id_buro_persona |
| `paso_rrpu` | materializa_rec | unifica_btt_rec | cod_pin_persona, id_buro_persona |
| `paso_v_bloqueo` | materializa_rec | unifica_btt_rec | cod_pin_persona, id_buro_persona |
| `paso_v_rela_ubic_estandar_geo` | materializa_rec | unifica_btt_rec | cod_pin_persona, id_buro_persona |
| `paso_v_ubicacion_original` | materializa_rec | unifica_btt_rec | cod_pin_persona, id_buro_persona |
| `paso_v_ubicacion_estandarizada` | materializa_rec | unifica_btt_rec | cod_pin_persona, id_buro_persona |
| `paso_v_log_ubic_estandarizada` | materializa_rec | unifica_btt_rec | cod_pin_persona, id_buro_persona |
| `paso_v_unificacion_direccion` | materializa_rec | unifica_btt_rec | cod_pin_persona, id_buro_persona |
| `unifica_btt_reconocer` | unifica_btt_rec | cta_atributos, ubic_direcciones | cod_pin_persona, id_buro_persona |

#### Fase 2: Atributos de Cuenta

| Tabla | Creada por | Consumida por | Descripción |
|-------|-----------|---------------|-------------|
| `cta_totales_personas_tmp1` | cta_atributos | cta_totales_personas | Cuentas con atributos base (~55 cols) |
| `tmp_cnta_fechas` | cta_totales_personas | cta_totales_personas_1, _2 | Ventana 12 meses por cuenta |
| `stg_comportamiento_cta_activo` | cta_totales_personas_1 | cta_totales_personas_2 | Comportamiento activo filtrado |
| `tmp_comportamiento_pasivo` | cta_totales_personas_2 | cta_totales_personas_2 | Comportamiento pasivo filtrado |
| `cta_totales_personas_tmp2` | cta_totales_personas_2 | cta_totales_personas_2 | Cruce activo + pasivo |
| `cta_totales_personas_tmp3` | cta_totales_personas_2 | concat_atributos | Con Portafolio, Portafolio_Nuevo, Sector |
| `concatena_atributos` | concat_atributos | final_cta_atributos | String concatenado + hash MD5 |

#### Fase 3: Ubicaciones

| Tabla | Creada por | Consumida por | Descripción |
|-------|-----------|---------------|-------------|
| `tmp_ord_cal_mat` | ubic_direcciones | calc_ubicaciones, calc_ubicaciones_1 | Reportes agrupados por persona-ubicación |
| `tmp_ord_cal1` | calc_ubicaciones | calc_ubicaciones | Ubicaciones con cuenta (flag_desde=0) |
| `tmp_ord_cal11` | calc_ubicaciones | calc_ubicaciones | Ubicaciones con cuenta (flag_desde=1) |
| `tmp_ord_cal2` | calc_ubicaciones | calc_ubicaciones | Con cod_entrega_dato |
| `tmp_ord_cal3` | calc_ubicaciones | calc_ubicaciones_2 | Resultado final con cuenta (top 3) |
| `tmp_ord_cal6` | calc_ubicaciones_1 | calc_ubicaciones_2 | Resultado sin cuenta |
| `tmp_ord_cal61` | calc_ubicaciones_1 | calc_ubicaciones_1 | Históricos sin cuenta |
| `vmo_reporte_relacion_pers_ubi` | calc_ubicaciones_2 | calc_ubicaciones_2 | Consolidación cal3 + cal6 |
| `vector_ubi_insumo_base` | calc_ubicaciones_2 | calc_ubicaciones_2 | Vector base de direcciones |
| `datos_ubic_estandarizadas` | calc_ubicaciones_2 | calc_ubicaciones_2 | Enriquecido con estandarización |
| `datos_tipo_persona` | calc_ubicaciones_2 | calc_ubicaciones_2 | Enriquecido con tipo persona |
| `datos_tipo_cuenta` | calc_ubicaciones_2 | concat_direcciones | Tabla final de direcciones enriquecida |
| `hash_carac_direc` | concat_direcciones | final_ubic_direcciones | Hash MD5 por dirección |

### Esquema `rec_datos` — Tablas Definitivas

```sql
-- Tabla de control de ejecución
CREATE TABLE IF NOT EXISTS rec_datos.control_ordenamiento (
    id_control              BIGINT IDENTITY(1,1) ENCODE AZ64,
    fecha_ult_ord           DATE                 ENCODE AZ64,
    fecha_ejecucion         TIMESTAMP            ENCODE AZ64,
    estado                  VARCHAR(20)          ENCODE ZSTD,
    registros_procesados    BIGINT               ENCODE AZ64
)
DISTSTYLE ALL;

-- Tabla de hash de atributos de cuenta
CREATE TABLE IF NOT EXISTS rec_datos.cuenta_atributo_hash (
    cod_pin_persona         INTEGER     ENCODE AZ64,
    id_buro_persona         INTEGER     ENCODE AZ64,
    cod_dw_cta              BIGINT      ENCODE AZ64,
    concatena               VARCHAR(4000) ENCODE ZSTD,
    cod_hash                VARCHAR(32)  ENCODE ZSTD,
    fecha_insercion         DATE         ENCODE AZ64
)
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, cod_pin_persona);

-- Tabla de hash de ubicaciones/direcciones
CREATE TABLE IF NOT EXISTS rec_datos.ubicacion_atributo_hash (
    cod_pin_persona         INTEGER      ENCODE AZ64,
    id_buro_persona         INTEGER      ENCODE AZ64,
    cod_dw_persona_ubic     BIGINT       ENCODE AZ64,
    concatena               VARCHAR(4000) ENCODE ZSTD,
    cod_hash                VARCHAR(32)   ENCODE ZSTD,
    fecha_insercion         DATE          ENCODE AZ64,
    fecha_actualizacion     DATE          ENCODE AZ64
)
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, cod_pin_persona);
```

### Tabla de Log de Ejecución

```sql
CREATE TABLE IF NOT EXISTS rec_stage.log_ejecucion (
    id_log              BIGINT IDENTITY(1,1) ENCODE AZ64,
    nombre_procedimiento VARCHAR(100)        ENCODE ZSTD,
    fase                VARCHAR(50)          ENCODE ZSTD,
    evento              VARCHAR(20)          ENCODE ZSTD,  -- INICIO, FIN, ERROR
    timestamp_evento    TIMESTAMP            ENCODE AZ64,
    registros_afectados BIGINT               ENCODE AZ64,
    mensaje_error       VARCHAR(2000)        ENCODE ZSTD,
    duracion_segundos   INTEGER              ENCODE AZ64
)
DISTSTYLE ALL;
```

---

## Patrones de Conversión Teradata → Redshift

### Tabla de Equivalencias

| Patrón Teradata | Equivalente Redshift | Ejemplo |
|-----------------|---------------------|---------|
| `CREATE SET TABLE` | `CREATE TABLE` + `SELECT DISTINCT` | Eliminar duplicados explícitamente |
| `CREATE MULTISET TABLE` | `CREATE TABLE` | Directo |
| `COLLECT STATISTICS` | `ANALYZE` | Automático en la mayoría de casos |
| `QUALIFY ROW_NUMBER() OVER(...) <= N` | Subquery + `WHERE rn <= N` | Ver ejemplo abajo |
| `ADD_MONTHS(fecha, -12)` | `DATEADD(month, -12, fecha)` | Directo |
| `rec_vista.hash_md5(str)` | `MD5(str)` | Función nativa |
| `SP_EXECSTRING_DES(sql)` | SQL estático inline | Eliminar indirección |
| `PRIMARY INDEX(col)` | `DISTKEY(col)` | Distribución |
| `DROP TABLE ... (error handling)` | `DROP TABLE IF EXISTS` | Idempotente |
| `OREPLACE(str, old, new)` | `REPLACE(str, old, new)` | Directo |
| `CAST(x AS FORMAT 'YYYY-MM-DD')` | `TO_CHAR(x, 'YYYY-MM-DD')` | Formato fecha |

### Patrón QUALIFY → Subquery

```sql
-- Teradata (original)
SELECT col1, col2, col3
FROM tabla
QUALIFY ROW_NUMBER() OVER (PARTITION BY col1 ORDER BY col2 DESC) <= 3;

-- Redshift (migrado)
SELECT col1, col2, col3
FROM (
    SELECT col1, col2, col3,
           ROW_NUMBER() OVER (PARTITION BY col1 ORDER BY col2 DESC) AS rn
    FROM tabla
) sub
WHERE rn <= 3;
```

### Patrón SET TABLE → SELECT DISTINCT

```sql
-- Teradata (original)
CREATE SET TABLE rec_stage.unifica_btt_reconocer AS (
    SELECT cod_pin_persona, id_buro_persona
    FROM rec_stage.paso_v_cuenta
    UNION ALL
    SELECT cod_pin_persona, id_buro_persona
    FROM rec_stage.paso_v_buro_persona
    -- ... 14 tablas
) WITH DATA;

-- Redshift (migrado)
DROP TABLE IF EXISTS rec_stage.unifica_btt_reconocer;
CREATE TABLE rec_stage.unifica_btt_reconocer AS
SELECT DISTINCT cod_pin_persona, id_buro_persona
FROM (
    SELECT cod_pin_persona, id_buro_persona FROM rec_stage.paso_v_cuenta
    UNION ALL
    SELECT cod_pin_persona, id_buro_persona FROM rec_stage.paso_v_buro_persona
    -- ... 14 tablas
);
```

### Patrón de Eliminación de SQL Dinámico

```sql
-- Teradata (original) — SQL dinámico
SET V_SQL = 'SELECT * FROM ' || P_BDSTAGE || '.paso_v_cuenta WHERE ...';
CALL SP_EXECSTRING_DES(V_SQL);

-- Redshift (migrado) — SQL estático
SELECT * FROM rec_stage.paso_v_cuenta WHERE ...;
```

### Patrón Hash MD5

```sql
-- Teradata (original)
SELECT rec_vista.hash_md5(
    COALESCE(CAST(col1 AS VARCHAR(100)), '') ||
    COALESCE(CAST(col2 AS VARCHAR(100)), '') ||
    COALESCE(CAST(col3 AS VARCHAR(100)), '')
) AS cod_hash
FROM tabla;

-- Redshift (migrado)
SELECT MD5(
    COALESCE(CAST(col1 AS VARCHAR(100)), '') ||
    COALESCE(CAST(col2 AS VARCHAR(100)), '') ||
    COALESCE(CAST(col3 AS VARCHAR(100)), '')
) AS cod_hash
FROM tabla;
```

### Patrón UPDATE con JOIN

```sql
-- Teradata (original)
UPDATE tabla_destino
FROM tabla_fuente src
SET col1 = src.col1
WHERE tabla_destino.id = src.id;

-- Redshift (migrado)
UPDATE rec_datos.ubicacion_atributo_hash dest
SET cod_hash = src.cod_hash,
    fecha_actualizacion = CURRENT_DATE
FROM rec_stage.hash_carac_direc src
WHERE dest.cod_dw_persona_ubic = src.cod_dw_persona_ubic;
```

---

## Flujo de Ejecución Detallado

```mermaid
sequenceDiagram
    participant ORC as Orquestador
    participant F1 as Fase 1
    participant F2 as Fase 2
    participant F3 as Fase 3
    participant LOG as Log Ejecución
    participant RS as rec_stage
    participant RD as rec_datos

    ORC->>F1: Ejecutar materializa_btt (paralelo)
    ORC->>F1: Ejecutar materializa_rec (paralelo)
    F1->>LOG: INICIO materializa_btt/rec
    F1->>RS: CREATE paso_v_* (BTT: 5 tablas, REC: 9 tablas)
    F1->>LOG: FIN materializa_btt/rec

    ORC->>F1: Ejecutar unifica_btt_rec
    F1->>RS: CREATE unifica_btt_reconocer (UNION ALL + DISTINCT)
    F1->>LOG: FIN unifica_btt_rec

    par Fase 2 y Fase 3 en paralelo
        ORC->>F2: Ejecutar cta_atributos
        F2->>RS: CREATE cta_totales_personas_tmp1
        ORC->>F2: Ejecutar cta_totales_personas
        F2->>RS: CREATE tmp_cnta_fechas
        ORC->>F2: Ejecutar cta_totales_personas_1
        F2->>RS: CREATE stg_comportamiento_cta_activo
        ORC->>F2: Ejecutar cta_totales_personas_2
        F2->>RS: CREATE cta_totales_personas_tmp3
        ORC->>F2: Ejecutar concat_atributos
        F2->>RS: CREATE concatena_atributos (con MD5)
    and
        ORC->>F3: Ejecutar ubic_direcciones
        F3->>RS: CREATE tmp_ord_cal_mat
        ORC->>F3: Ejecutar calc_ubicaciones (paralelo)
        ORC->>F3: Ejecutar calc_ubicaciones_1 (paralelo)
        F3->>RS: CREATE tmp_ord_cal3, tmp_ord_cal6
        ORC->>F3: Ejecutar calc_ubicaciones_2
        F3->>RS: CREATE datos_tipo_cuenta
        ORC->>F3: Ejecutar concat_direcciones
        F3->>RS: CREATE hash_carac_direc (con MD5)
    end

    ORC->>F3: Ejecutar final_ubic_direcciones
    F3->>RD: INSERT nuevos + UPDATE modificados en ubicacion_atributo_hash

    ORC->>F1: Ejecutar limpieza_validacion
    F1->>RS: DROP tablas paso_*
    F1->>LOG: FIN proceso completo
```

---

## Manejo de Errores

### Estrategia General

Cada script SQL implementa un patrón de try-catch usando bloques `BEGIN...EXCEPTION...END` de Redshift (dentro de procedimientos almacenados wrapper si se requiere) o bien el orquestador captura errores de ejecución SQL.

### Patrón de Logging

```sql
-- Al inicio de cada script
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento)
VALUES ('materializa_btt', 'Fase 1', 'INICIO', GETDATE());

-- Al final exitoso
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento, registros_afectados)
VALUES ('materializa_btt', 'Fase 1', 'FIN', GETDATE(),
    (SELECT COUNT(*) FROM rec_stage.paso_v_cuenta));

-- En caso de error (capturado por orquestador)
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento, mensaje_error)
VALUES ('materializa_btt', 'Fase 1', 'ERROR', GETDATE(), 'Mensaje del error');
```

### Validación Pre-Ejecución

El script `04_limpieza_validacion.sql` consulta el log para detectar errores previos:

```sql
-- Si hay errores en pasos anteriores, abortar
SELECT COUNT(*) AS errores
FROM rec_stage.log_ejecucion
WHERE evento = 'ERROR'
  AND timestamp_evento >= (SELECT MAX(timestamp_evento)
                           FROM rec_stage.log_ejecucion
                           WHERE evento = 'INICIO'
                             AND nombre_procedimiento = 'materializa_btt');
```

### Códigos de Error

| Código | Significado | Acción |
|--------|-------------|--------|
| 0 | Éxito | Continuar |
| 1 | Error en paso previo detectado | Detener ejecución |
| 2 | Tabla de entrada vacía | Advertencia, continuar |
| 3 | Error SQL (sintaxis, permisos) | Detener, registrar en log |
| 4 | Timeout de ejecución | Reintentar o escalar |

### Idempotencia

Todos los scripts son idempotentes gracias al patrón `DROP TABLE IF EXISTS` + `CREATE TABLE AS`:

```sql
DROP TABLE IF EXISTS rec_stage.paso_v_cuenta;
CREATE TABLE rec_stage.paso_v_cuenta AS
SELECT ...;
```

Esto permite re-ejecutar cualquier script sin efectos secundarios acumulativos.

---


## Propiedades de Correctitud

*Una propiedad es una característica o comportamiento que debe mantenerse verdadero en todas las ejecuciones válidas de un sistema — esencialmente, una declaración formal sobre lo que el sistema debe hacer. Las propiedades sirven como puente entre especificaciones legibles por humanos y garantías de correctitud verificables por máquina.*

### Propiedad 1: Filtrado por fecha identifica correctamente lotes nuevos

*Para cualquier* conjunto de registros de log con fechas variadas y una fecha de control dada, el proceso de materialización SHALL retornar exclusivamente los registros cuya fecha de carga es posterior a la fecha de control, sin omitir ninguno válido ni incluir ninguno anterior.

**Valida: Requerimientos 1.1, 2.1, 7.1, 8.1**

### Propiedad 2: Deduplicación produce conjunto único

*Para cualquier* conjunto de pares (cod_pin_persona, id_buro_persona) provenientes de múltiples tablas de paso con duplicados intencionales, la tabla UNIFICA_BTT_RECONOCER SHALL contener exactamente el conjunto de pares únicos (sin duplicados) y ningún par que no existiera en al menos una tabla de entrada.

**Valida: Requerimientos 3.1, 3.3**

### Propiedad 3: Detección de errores previos detiene ejecución

*Para cualquier* estado del log de ejecución que contenga al menos un registro con evento='ERROR' posterior al último INICIO del proceso actual, la validación SHALL detectar el error y señalar código de retorno distinto de cero.

**Valida: Requerimientos 4.2, 22.2**

### Propiedad 4: Ventana temporal de 12 meses es correcta

*Para cualquier* fecha de novedad válida, el cálculo de ventana temporal SHALL producir una fecha_inicio exactamente 12 meses antes de la fecha_novedad, y la fecha_fin igual a la fecha_novedad, sin desbordamiento ni truncamiento.

**Valida: Requerimiento 6.1**

### Propiedad 5: Clasificación de Portafolio es determinista y completa

*Para cualquier* combinación válida de atributos de cuenta (tipo_cuenta, tipo_obligacion, cuotas_pactadas, garantia, cod_suscriptor), la clasificación SHALL asignar exactamente uno de los valores de Portafolio (CO, RO, VE, HP, IN, OT, CC, AH, CT), un Portafolio_Nuevo y un Sector, de forma determinista (misma entrada → misma salida).

**Valida: Requerimiento 8.2**

### Propiedad 6: Filtrado de personas preserva solo el conjunto autorizado

*Para cualquier* tabla de reportes y tabla unificada, el resultado SHALL contener exclusivamente registros de personas presentes en UNIFICA_BTT_RECONOCER, y SHALL excluir todo registro marcado como bloqueado o unificado.

**Valida: Requerimientos 9.1, 11.1, 12.2**

### Propiedad 7: Agregación condicional por flag aplica función correcta

*Para cualquier* conjunto de registros de reporte con valores de Id_Flag_Desde (0 o 1), la agregación SHALL aplicar MAX para registros con flag=0 (más reciente) y MIN para registros con flag=1 (más antiguo), sin mezclar las funciones.

**Valida: Requerimiento 9.2**

### Propiedad 8: Reglas de fecha de ubicación seleccionan fecha correcta

*Para cualquier* ubicación con cuenta válida, dado su estado de vigencia y tipo (principal, pasivo, codeudor), la regla de fecha SHALL seleccionar: Fecha_Apertura si la cuenta es vigente y el tipo es principal/pasivo/codeudor y el registro es nuevo; Fecha_Reporte si es existente; MIN(Fecha_Nov, Fecha_Reporte) si la cuenta no es vigente.

**Valida: Requerimiento 10.1**

### Propiedad 9: Limitación por ROW_NUMBER respeta máximo por partición

*Para cualquier* conjunto de registros agrupados por combinación persona-ubicación, el resultado filtrado por ROW_NUMBER SHALL contener como máximo 3 registros por cada combinación, y los registros seleccionados SHALL ser los de mayor prioridad según el ORDER BY definido.

**Valida: Requerimiento 10.2**

### Propiedad 10: Hash MD5 es determinista y de formato fijo

*Para cualquier* string de entrada (concatenación de atributos), la función MD5() SHALL producir siempre un string hexadecimal de exactamente 32 caracteres, y la misma entrada SHALL producir siempre el mismo hash (determinismo).

**Valida: Requerimientos 13.1, 14.1**

### Propiedad 11: Detección de cambios identifica correctamente nuevos y modificados

*Para cualquier* par de conjuntos (hashes actuales, hashes existentes), la detección SHALL clasificar como "nuevo" todo registro cuya clave no existe en el conjunto existente, y como "modificado" todo registro cuya clave existe pero cuyo hash difiere. Ningún registro sin cambios SHALL ser marcado como nuevo o modificado.

**Valida: Requerimientos 15.1, 15.3**

---

## Estrategia de Testing

### Enfoque Dual

La estrategia de testing combina dos enfoques complementarios:

1. **Tests de equivalencia (integración)**: Verifican que el proceso migrado produce los mismos resultados que Teradata usando datasets de prueba con resultados pre-calculados.
2. **Tests basados en propiedades (PBT)**: Verifican que las propiedades universales se mantienen para cualquier entrada válida, usando generación aleatoria de datos.

### Tests Basados en Propiedades

**Librería**: [fast-check](https://github.com/dubzzz/fast-check) (JavaScript/TypeScript) para tests de lógica pura extraída a funciones auxiliares, o tests SQL con datos generados por scripts Python.

**Configuración**:
- Mínimo 100 iteraciones por propiedad
- Cada test referencia su propiedad del documento de diseño
- Tag format: **Feature: migracion-ordenamiento-242, Property {N}: {título}**

**Propiedades a implementar como PBT**:

| # | Propiedad | Generador | Verificación |
|---|-----------|-----------|--------------|
| 1 | Filtrado por fecha | Fechas aleatorias + registros con fechas variadas | Solo registros posteriores a fecha control |
| 2 | Deduplicación | Pares (int, int) con duplicados intencionales | COUNT = COUNT DISTINCT |
| 4 | Ventana 12 meses | Fechas aleatorias válidas | DATEADD(month, -12, fecha) = fecha_inicio |
| 5 | Clasificación Portafolio | Combinaciones aleatorias de atributos | Resultado ∈ {CO,RO,VE,HP,IN,OT,CC,AH,CT} y determinista |
| 7 | Agregación por flag | Registros con flag 0/1 y valores numéricos | MAX cuando flag=0, MIN cuando flag=1 |
| 9 | ROW_NUMBER ≤ 3 | Particiones de tamaño variable (1-20) | COUNT por partición ≤ 3 |
| 10 | Hash MD5 | Strings aleatorios | LENGTH = 32, mismo input → mismo output |
| 11 | Detección de cambios | Dos conjuntos de (clave, hash) | Nuevos = en actual pero no en existente |

### Tests de Integración (Equivalencia)

Usan datasets fijos pre-calculados con resultados conocidos de Teradata:

| Test | Dataset | Verificación |
|------|---------|--------------|
| Materialización BTT | 50 registros de log + 200 personas | Mismas personas identificadas |
| Materialización REC | 30 registros de log + 150 personas | Mismas personas identificadas |
| Unificación | 14 tablas con ~100 registros c/u | Misma tabla unificada |
| Clasificación Portafolio | 100 cuentas con clasificación conocida | Misma clasificación |
| Hash MD5 equivalencia | 50 strings con hash Teradata conocido | MD5() = hash_md5() |
| Persistencia ubicaciones | 30 registros (10 nuevos, 10 modificados, 10 sin cambio) | Mismos INSERT/UPDATE |

### Tests de Humo (Smoke)

Verifican requisitos estructurales y de código:

| Test | Verificación |
|------|--------------|
| Sin SQL dinámico | grep -r "EXECUTE\|SP_EXECSTRING" en src/redshift/ = 0 resultados |
| Sin parámetros de BD | grep -r "P_BDDATOS\|P_BDVISTA\|P_BDSTAGE" = 0 resultados |
| Estructura de directorio | Existen fase1/, fase2/, fase3/, shared/, _disabled/ |
| Encabezados presentes | Cada .sql tiene comentario con SP original, fase, modo |
| Idempotencia | Cada CREATE TABLE tiene DROP TABLE IF EXISTS previo |
| Rollback existe | Cada script en sql/ tiene correspondiente en rev-sql/ |

### Ejecución de Tests

```bash
# Tests de propiedades (fast-check)
npm test -- --run --grep "Property"

# Tests de integración (requieren conexión a Redshift dev)
npm test -- --run --grep "Integration"

# Tests de humo (solo verifican estructura de código)
npm test -- --run --grep "Smoke"
```

---

## Consideraciones de Rendimiento

### Volumen de Datos

- ~65-70M registros en tablas fuente
- ~5-10M personas afectadas por ejecución típica
- Tablas intermedias: 1-10M registros cada una

### Optimizaciones Redshift

| Técnica | Aplicación |
|---------|-----------|
| `DISTKEY(id_buro_persona)` | Tablas principales — colocaliza datos de la misma persona |
| `SORTKEY(id_buro_persona, cod_pin_persona)` | Optimiza JOINs frecuentes por persona |
| `DISTSTYLE ALL` | Tablas pequeñas de referencia (control, metadata) |
| `ANALYZE` post-carga | Después de CREATE TABLE AS con volumen significativo |
| Paralelismo por fase | Fase 2 y Fase 3 se ejecutan en paralelo |

### Patrón de Tabla Intermedia

```sql
-- Patrón estándar para tablas intermedias de alto volumen
DROP TABLE IF EXISTS rec_stage.tabla_intermedia;
CREATE TABLE rec_stage.tabla_intermedia
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, cod_pin_persona)
AS
SELECT ...
FROM ...;
ANALYZE rec_stage.tabla_intermedia;
```

---

## Apéndice: SPs Deshabilitados

### PRO_ORD_FINAL_CTA_ATRIBUTOS (Deshabilitado)

- **Razón**: Contiene `IF V_PASO > 0 THEN LEAVE L1` al inicio, lo que impide la ejecución de la lógica.
- **Funcionalidad**: Detecta cuentas nuevas por hash e inserta en `CUENTA_ATRIBUTO_HASH`.
- **Ubicación migrada**: `_disabled/final_cta_atributos_disabled.sql`
- **Activación futura**: Remover el bloque condicional de salida y habilitar en el orquestador.

### PRO_ORD_FINAL_UBIC_DIRECCIONES (Deshabilitado — versión 0)

- **Razón**: Reemplazado por `PRO_ORD_FINAL_UBIC_DIRECCIONES1` que además hace UPDATE de hashes modificados.
- **Funcionalidad**: Solo INSERT de registros nuevos (sin UPDATE de modificados).
- **Ubicación migrada**: `_disabled/final_ubic_direcciones_v0_disabled.sql`
- **Nota**: La versión activa (`PRO_ORD_FINAL_UBIC_DIRECCIONES1`) es la que se implementa en `fase3/06_final_ubic_direcciones.sql`.
