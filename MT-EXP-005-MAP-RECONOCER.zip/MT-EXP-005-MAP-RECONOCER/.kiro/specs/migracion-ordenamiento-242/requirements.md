# Documento de Requerimientos — Migración Ordenamiento 242

## Introducción

Migración del proceso "Ordenamiento 242" (Scoring de Contactabilidad) desde Teradata hacia Amazon Redshift. El proceso calcula un score de contactabilidad para cada dato de contacto (teléfono fijo, celular, email, dirección) usando regresión logística con coeficientes Beta. Consta de 17 Stored Procedures ejecutados desde una malla Control-M (`ORDENAMIENTO_242_131.BTQ`) que se deben migrar a procedimientos almacenados de Redshift o scripts SQL estáticos.

El proceso maneja ~65-70M registros y se organiza en 3 fases: Materialización + Unificación (identificar personas con cambios), Rama de Atributos de Cuenta (enriquecer y clasificar cuentas), y Rama de Ubicaciones/Direcciones (calcular vectores de dirección y detectar cambios por hash).

## Glosario

- **Sistema_Migracion**: Conjunto de procedimientos almacenados y scripts SQL en Amazon Redshift que replican la funcionalidad del proceso Ordenamiento 242 de Teradata.
- **SP_Teradata**: Stored Procedure original en Teradata que se migra a Redshift.
- **Redshift_SP**: Stored Procedure equivalente en Amazon Redshift.
- **Score_Contactabilidad**: Valor numérico calculado por regresión logística que indica la probabilidad de contactar exitosamente a una persona por un canal específico.
- **Coeficiente_Beta**: Peso asignado a cada característica en el modelo de regresión logística, almacenado en vistas de configuración (`V_Beta_Ordenamiento_*`).
- **Canal_Contacto**: Medio de comunicación con la persona: teléfono fijo, celular, email o dirección física.
- **Materialización**: Proceso de identificar personas afectadas por cambios recientes en los datos fuente (lotes nuevos desde la última ejecución).
- **BTT**: Modelo Bureau (datos de cuentas y comportamiento crediticio).
- **REC**: Modelo Reconocer (datos de ubicaciones, relaciones persona-ubicación, estandarización).
- **Portafolio**: Clasificación de una cuenta según tipo de obligación (CO, RO, VE, HP, IN, OT, CC, AH, CT).
- **Hash_MD5**: Valor hash calculado sobre atributos concatenados para detectar cambios entre ejecuciones.
- **UNIFICA_BTT_RECONOCER**: Tabla consolidada de personas que requieren re-ordenamiento.
- **rec_stage**: Esquema de Redshift para tablas intermedias del proceso.
- **rec_datos**: Esquema de Redshift para tablas definitivas del proceso.
- **SQL_Dinamico**: Patrón de Teradata donde se construyen sentencias SQL como strings y se ejecutan con `SP_EXECSTRING_DES`. En Redshift se elimina usando esquemas fijos.
- **SET_TABLE**: Tabla de Teradata que elimina duplicados automáticamente al insertar. En Redshift se reemplaza con `SELECT DISTINCT` o `GROUP BY`.
- **Malla_Control_M**: Orquestador batch que ejecuta los SPs en secuencia/paralelo según dependencias.
- **Ventana_Temporal**: Período de 12 meses hacia atrás usado para calcular comportamiento histórico de cuentas.
- **QUALIFY**: Cláusula de Teradata para filtrar resultados de window functions. En Redshift se reemplaza con subquery + WHERE.

## Requerimientos

### Requerimiento 1: Migración de Materialización BTT

**User Story:** Como equipo de operaciones, quiero que el proceso identifique personas con cambios en el modelo Bureau desde la última ejecución de ordenamiento, para que solo se recalculen los scores de personas afectadas.

#### Criterios de Aceptación

1. WHEN se ejecuta el procedimiento de materialización BTT, THE Sistema_Migracion SHALL consultar el log de metadata para identificar lotes con inserts o updates posteriores a la fecha del último ordenamiento registrada en la tabla de control.
2. WHEN se identifican lotes nuevos en el modelo BTT, THE Sistema_Migracion SHALL extraer los pares `Cod_Pin_Persona` + `Id_Buro_Persona` de las tablas modificadas (V_CUENTA, V_BURO_PERSONA, V_COMPORTAMIENTO_CUENTA, V_COMPORTAMIENTO_CUENTA_ACTIVO, V_COMPORTAMIENTO_CUENTA_PASIVO, VU_CUENTA).
3. THE Sistema_Migracion SHALL generar las tablas intermedias de paso en el esquema rec_stage sin utilizar SQL dinámico, reemplazando la concatenación de nombres de base de datos por referencias directas a esquemas fijos de Redshift.
4. WHEN el procedimiento de materialización BTT se ejecuta en Redshift, THE Sistema_Migracion SHALL producir el mismo conjunto de personas afectadas que el SP original `PRO_ORD_MATERIALIZA_BTT` de Teradata para un mismo estado de datos de entrada.

---

### Requerimiento 2: Migración de Materialización REC

**User Story:** Como equipo de operaciones, quiero que el proceso identifique personas con cambios en el modelo Reconocer desde la última ejecución, para incluirlas en el recálculo de scores.

#### Criterios de Aceptación

1. WHEN se ejecuta el procedimiento de materialización REC, THE Sistema_Migracion SHALL consultar el log de carga (`log_td`) para identificar lotes con cargas exitosas posteriores a la última ejecución de ordenamiento.
2. WHEN se identifican lotes nuevos en el modelo REC, THE Sistema_Migracion SHALL extraer personas de las 10 tablas fuente de ubicaciones, relaciones persona-ubicación, bloqueos, estandarización y unificación.
3. THE Sistema_Migracion SHALL generar las tablas intermedias de paso en el esquema rec_stage usando SQL estático con esquemas fijos.
4. WHEN el procedimiento de materialización REC se ejecuta en Redshift, THE Sistema_Migracion SHALL producir el mismo conjunto de personas afectadas que el SP original `PRO_ORD_MATERIALIZA_REC` de Teradata para un mismo estado de datos de entrada.

---

### Requerimiento 3: Unificación BTT + REC

**User Story:** Como equipo de operaciones, quiero consolidar las personas identificadas en ambos modelos (BTT y REC) en una sola tabla sin duplicados, para tener un conjunto único de personas a re-ordenar.

#### Criterios de Aceptación

1. WHEN las materializaciones BTT y REC han completado, THE Sistema_Migracion SHALL ejecutar un UNION ALL de todas las tablas de paso generadas (14 tablas) y eliminar duplicados para producir la tabla `UNIFICA_BTT_RECONOCER`.
2. THE Sistema_Migracion SHALL reemplazar el comportamiento de `CREATE SET TABLE` de Teradata con `SELECT DISTINCT` o `GROUP BY` en Redshift para garantizar la eliminación de duplicados.
3. WHEN se genera la tabla unificada, THE Sistema_Migracion SHALL contener exclusivamente las columnas `Cod_Pin_Persona` e `Id_Buro_Persona` sin registros duplicados.

---

### Requerimiento 4: Limpieza y Validación Post-Unificación

**User Story:** Como equipo de operaciones, quiero que las tablas temporales se limpien después de la unificación y se valide que no hubo errores en pasos anteriores, para mantener el espacio de almacenamiento y detectar fallos tempranamente.

#### Criterios de Aceptación

1. WHEN la unificación y los procesos dependientes han completado, THE Sistema_Migracion SHALL eliminar todas las tablas temporales de paso usando `DROP TABLE IF EXISTS`.
2. WHEN se detectan errores en pasos anteriores consultando el log de detalle, THE Sistema_Migracion SHALL retornar un código de error y detener la ejecución del proceso.
3. IF una tabla temporal no existe al momento de intentar eliminarla, THEN THE Sistema_Migracion SHALL continuar la ejecución sin generar error.

---

### Requerimiento 5: Extracción de Atributos de Cuenta

**User Story:** Como equipo de operaciones, quiero extraer y enriquecer los atributos de cuenta de las personas a ordenar, para disponer de la información base necesaria para el cálculo de scores.

#### Criterios de Aceptación

1. WHEN se ejecuta el procedimiento de atributos de cuenta, THE Sistema_Migracion SHALL extraer todas las cuentas de las personas en `UNIFICA_BTT_RECONOCER` desde la vista `VU_CUENTA` y enriquecerlas con datos de razón de bloqueo, fuente de dato y código de entrega.
2. THE Sistema_Migracion SHALL generar la tabla `CTA_TOTALES_PERSONAS_TMP1` con las columnas de atributos de cuenta requeridas por los pasos posteriores del proceso.
3. WHEN el procedimiento se ejecuta en Redshift, THE Sistema_Migracion SHALL producir resultados equivalentes al SP original `PRO_ORD_CTA_ATRIBUTOS` de Teradata, manteniendo los mismos LEFT JOINs y la misma estructura de columnas.

---

### Requerimiento 6: Cálculo de Ventana Temporal de Cuentas

**User Story:** Como equipo de operaciones, quiero calcular la ventana temporal de 12 meses para cada cuenta, para delimitar el período de búsqueda de comportamiento histórico.

#### Criterios de Aceptación

1. WHEN se ejecuta el cálculo de ventana temporal, THE Sistema_Migracion SHALL generar la tabla `TMP_CNTA_FECHAS` con el rango de fechas de 12 meses hacia atrás desde la fecha de novedad de cada cuenta.
2. THE Sistema_Migracion SHALL reemplazar la función `ADD_MONTHS(fecha, -12)` de Teradata por `DATEADD(month, -12, fecha)` de Redshift.
3. WHEN se calcula la ventana temporal, THE Sistema_Migracion SHALL producir las mismas fechas de inicio y fin que el SP original `PRO_ORD_CTA_TOTALES_PERSONAS` de Teradata.

---

### Requerimiento 7: Extracción de Comportamiento Activo

**User Story:** Como equipo de operaciones, quiero extraer el comportamiento de cuenta activo dentro de la ventana de 12 meses, para alimentar el modelo de scoring con datos de actividad reciente.

#### Criterios de Aceptación

1. WHEN se ejecuta la extracción de comportamiento activo, THE Sistema_Migracion SHALL cruzar `TMP_CNTA_FECHAS` con la vista de comportamiento de cuenta activo usando BETWEEN en fechas para filtrar solo registros dentro de la ventana de 12 meses.
2. THE Sistema_Migracion SHALL generar la tabla `STG_COMPORTAMIENTO_CTA_ACTIVO` con los datos precalculados de comportamiento activo.
3. WHEN se ejecuta en Redshift, THE Sistema_Migracion SHALL producir el mismo conjunto de registros que el SP original `PRO_ORD_CTA_TOTALES_PERSONAS_1` de Teradata.

---

### Requerimiento 8: Clasificación de Portafolio y Comportamiento Pasivo

**User Story:** Como equipo de operaciones, quiero clasificar cada cuenta en su tipo de Portafolio y extraer el comportamiento pasivo, para completar los atributos necesarios para el scoring.

#### Criterios de Aceptación

1. WHEN se ejecuta la clasificación de portafolio, THE Sistema_Migracion SHALL extraer el comportamiento pasivo dentro de la ventana de 12 meses y cruzarlo con el comportamiento activo previamente calculado.
2. THE Sistema_Migracion SHALL clasificar cada cuenta en Portafolio (CO, RO, VE, HP, IN, OT, CC, AH, CT), Portafolio_Nuevo y Sector usando la misma lógica CASE WHEN del SP original `PRO_ORD_CTA_TOTALES_PERSONAS_2`, incluyendo las condiciones basadas en tipo de cuenta, tipo de obligación, cuotas pactadas, garantía y código de suscriptor.
3. THE Sistema_Migracion SHALL generar la tabla `CTA_TOTALES_PERSONAS_TMP3` con las columnas de Portafolio, Portafolio_Nuevo y Sector correctamente calculadas.
4. WHEN se ejecuta en Redshift, THE Sistema_Migracion SHALL producir la misma clasificación de portafolio que el SP original para un mismo conjunto de datos de entrada.

---

### Requerimiento 9: Preparación de Reportes de Ubicación

**User Story:** Como equipo de operaciones, quiero preparar la tabla materializada de reportes de relación persona-ubicación, para disponer de los datos base del cálculo de ubicaciones.

#### Criterios de Aceptación

1. WHEN se ejecuta la preparación de reportes, THE Sistema_Migracion SHALL filtrar desde `MAT_REPORTE_REL_PERS_UBI` solo las personas presentes en `UNIFICA_BTT_RECONOCER`.
2. THE Sistema_Migracion SHALL agrupar por persona-ubicación y calcular MAX y MIN de `Cod_DW_Reporte_Persona_Ubic` y `Fecha_Reporte` según el valor de `Id_Flag_Desde` (0=más reciente, 1=más antiguo).
3. THE Sistema_Migracion SHALL generar la tabla `TMP_ORD_CAL_MAT` con los resultados agrupados.
4. WHEN se ejecuta en Redshift, THE Sistema_Migracion SHALL producir los mismos resultados que el SP original `PRO_ORD_UBIC_DIRECCIONES` de Teradata.

---

### Requerimiento 10: Cálculo de Ubicaciones con Cuenta Válida

**User Story:** Como equipo de operaciones, quiero calcular las fechas de reporte ajustadas para ubicaciones que tienen cuenta válida, para determinar correctamente la antigüedad de cada dato de contacto.

#### Criterios de Aceptación

1. WHEN se ejecuta el cálculo de ubicaciones con cuenta, THE Sistema_Migracion SHALL aplicar las reglas de negocio de fecha: si la cuenta es vigente y el tipo es principal, pasivo o codeudor, usar Fecha_Apertura para registros nuevos y Fecha_Reporte para existentes; si no es vigente, usar el mínimo entre Fecha_Nov y Fecha_Reporte.
2. THE Sistema_Migracion SHALL agregar `Cod_Entrega_Dato_Fte` y limitar a 3 registros por combinación persona-ubicación usando ROW_NUMBER con subquery WHERE en lugar de QUALIFY.
3. THE Sistema_Migracion SHALL generar las tablas intermedias `TMP_ORD_CAL1`, `TMP_ORD_CAL11`, `TMP_ORD_CAL2` y `TMP_ORD_CAL3`.
4. WHEN se ejecuta en Redshift, THE Sistema_Migracion SHALL producir los mismos resultados que el SP original `PRO_ORD_CALC_UBICACIONES` de Teradata.

---

### Requerimiento 11: Cálculo de Ubicaciones sin Cuenta Válida

**User Story:** Como equipo de operaciones, quiero calcular las fechas de reporte para ubicaciones sin cuenta válida, para no excluir datos de contacto que no están asociados a cuentas activas.

#### Criterios de Aceptación

1. WHEN se ejecuta el cálculo de ubicaciones sin cuenta, THE Sistema_Migracion SHALL aplicar las mismas reglas de fecha que el cálculo con cuenta, pero filtrando ubicaciones cuyo `COD_DW_CTA` no existe en `VU_CUENTA`.
2. THE Sistema_Migracion SHALL generar las tablas `TMP_ORD_CAL6` y `TMP_ORD_CAL61` con los resultados para registros sin cuenta.
3. WHEN se ejecuta en Redshift, THE Sistema_Migracion SHALL producir los mismos resultados que el SP original `PRO_ORD_CALC_UBICACIONES_1` de Teradata.

---

### Requerimiento 12: Consolidación y Enriquecimiento de Ubicaciones

**User Story:** Como equipo de operaciones, quiero consolidar los cálculos de ubicaciones (con y sin cuenta) y enriquecer con datos de estandarización, tipo de persona y tipo de cuenta, para construir el vector completo de insumo de direcciones.

#### Criterios de Aceptación

1. WHEN se ejecuta la consolidación, THE Sistema_Migracion SHALL unir `TMP_ORD_CAL3` y `TMP_ORD_CAL6` en la tabla `vmo_reporte_relacion_pers_ubi`.
2. THE Sistema_Migracion SHALL construir `VECTOR_UBI_INSUMO_BASE` cruzando personas con relación_persona_ubicación, excluyendo registros bloqueados y unificados.
3. THE Sistema_Migracion SHALL enriquecer el vector con datos de ubicación estandarizada (texto, fuente, geografía), tipo de persona y tipo de cuenta, generando las tablas `DATOS_UBIC_ESTANDARIZADAS`, `DATOS_TIPO_PERSONA` y `DATOS_TIPO_CUENTA`.
4. WHEN se ejecuta en Redshift, THE Sistema_Migracion SHALL producir los mismos resultados que el SP original `PRO_ORD_CALC_UBICACIONES_2` de Teradata.

---

### Requerimiento 13: Generación de Hash de Atributos de Cuenta

**User Story:** Como equipo de operaciones, quiero generar un hash MD5 sobre los atributos concatenados de cada cuenta, para detectar cambios entre ejecuciones sin comparar campo por campo.

#### Criterios de Aceptación

1. WHEN se ejecuta la concatenación de atributos, THE Sistema_Migracion SHALL concatenar los atributos numéricos de cuenta en un solo string y calcular el hash usando la función `MD5()` nativa de Redshift.
2. THE Sistema_Migracion SHALL generar la tabla `CONCATENA_ATRIBUTOS` con las columnas `Concatena` (string concatenado) y `cod_hash` (hash MD5).
3. WHEN se calcula el hash en Redshift con `MD5()`, THE Sistema_Migracion SHALL producir valores hash equivalentes a los generados por la UDF `rec_vista.hash_md5()` de Teradata para los mismos datos de entrada.

---

### Requerimiento 14: Generación de Hash de Direcciones

**User Story:** Como equipo de operaciones, quiero generar un hash MD5 sobre los atributos de dirección concatenados, para detectar cambios en las ubicaciones entre ejecuciones.

#### Criterios de Aceptación

1. WHEN se ejecuta la concatenación de direcciones, THE Sistema_Migracion SHALL concatenar los atributos de dirección (texto ubicación, tipo, gestión, DANE, tipo persona, tipo cuenta, dirección física, complemento, barrio, latitud, longitud) y calcular el hash usando `MD5()` de Redshift.
2. THE Sistema_Migracion SHALL generar la tabla `hash_Carac_direc` con el hash calculado por cada registro de dirección.
3. WHEN se calcula el hash en Redshift con `MD5()`, THE Sistema_Migracion SHALL producir valores hash equivalentes a los generados por la UDF `rec_vista.hash_md5()` de Teradata para los mismos datos de entrada.

---

### Requerimiento 15: Persistencia de Ubicaciones con Detección de Cambios

**User Story:** Como equipo de operaciones, quiero persistir solo las direcciones nuevas o modificadas en la tabla definitiva, para mantener un histórico eficiente de cambios detectados por hash.

#### Criterios de Aceptación

1. WHEN se ejecuta la persistencia de ubicaciones, THE Sistema_Migracion SHALL detectar registros nuevos comparando el hash actual contra `V_UBICACION_ATRIBUTO_HASH` mediante LEFT JOIN WHERE IS NULL.
2. WHEN se detectan registros nuevos (hash no existente), THE Sistema_Migracion SHALL insertar los registros en la tabla definitiva `UBICACION_ATRIBUTO_HASH`.
3. WHEN se detectan registros con hash modificado, THE Sistema_Migracion SHALL actualizar el hash en `UBICACION_ATRIBUTO_HASH` usando la sintaxis `UPDATE ... FROM ... WHERE` de Redshift.
4. THE Sistema_Migracion SHALL implementar la lógica del SP activo `PRO_ORD_FINAL_UBIC_DIRECCIONES1` (no la versión deshabilitada `PRO_ORD_FINAL_UBIC_DIRECCIONES`).

---

### Requerimiento 16: Eliminación de SQL Dinámico

**User Story:** Como equipo de desarrollo, quiero que todos los procedimientos migrados usen SQL estático con esquemas fijos, para simplificar el mantenimiento y aprovechar la arquitectura de Redshift.

#### Criterios de Aceptación

1. THE Sistema_Migracion SHALL reemplazar todas las invocaciones de `SP_EXECSTRING_DES` por sentencias SQL estáticas con referencias directas a los esquemas `rec_stage` y `rec_datos`.
2. THE Sistema_Migracion SHALL eliminar todos los parámetros de nombres de base de datos (`P_BDDATOS`, `P_BDVISTA`, `P_BDSTAGE`, etc.) de los procedimientos migrados.
3. THE Sistema_Migracion SHALL reemplazar la concatenación dinámica de nombres de esquema por referencias fijas en cada sentencia SQL.

---

### Requerimiento 17: Compatibilidad de Sintaxis Redshift

**User Story:** Como equipo de desarrollo, quiero que todos los procedimientos migrados usen sintaxis nativa de Redshift, para garantizar la ejecución correcta en el entorno destino.

#### Criterios de Aceptación

1. THE Sistema_Migracion SHALL reemplazar `COLLECT STATISTICS` por `ANALYZE` o eliminarlo donde Redshift lo ejecute automáticamente.
2. THE Sistema_Migracion SHALL reemplazar `CREATE SET TABLE` por `CREATE TABLE` con `SELECT DISTINCT` o `GROUP BY` para garantizar la eliminación de duplicados.
3. THE Sistema_Migracion SHALL reemplazar la cláusula `QUALIFY ROW_NUMBER() OVER(...)` por una subquery con alias y filtro `WHERE rn <= N`.
4. THE Sistema_Migracion SHALL reemplazar la UDF `rec_vista.hash_md5()` por la función nativa `MD5()` de Redshift.
5. THE Sistema_Migracion SHALL reemplazar `CREATE MULTISET TABLE` por `CREATE TABLE` estándar de Redshift.
6. THE Sistema_Migracion SHALL reemplazar `ADD_MONTHS(fecha, N)` por `DATEADD(month, N, fecha)` de Redshift.
7. THE Sistema_Migracion SHALL usar `DROP TABLE IF EXISTS` en lugar del patrón Teradata de DROP + manejo de error.

---

### Requerimiento 18: Equivalencia Funcional

**User Story:** Como equipo de calidad, quiero garantizar que el proceso migrado produce los mismos resultados que el proceso original en Teradata, para asegurar la continuidad del negocio.

#### Criterios de Aceptación

1. WHEN se ejecuta el proceso completo en Redshift con los mismos datos de entrada, THE Sistema_Migracion SHALL producir la misma tabla `UNIFICA_BTT_RECONOCER` (mismas personas identificadas) que el proceso Teradata.
2. WHEN se ejecuta el proceso completo en Redshift, THE Sistema_Migracion SHALL producir la misma clasificación de Portafolio, Portafolio_Nuevo y Sector para cada cuenta que el proceso Teradata.
3. WHEN se ejecuta el proceso completo en Redshift, THE Sistema_Migracion SHALL producir los mismos hashes MD5 para atributos de cuenta y direcciones que el proceso Teradata.
4. WHEN se ejecuta el proceso completo en Redshift, THE Sistema_Migracion SHALL insertar y actualizar los mismos registros en `UBICACION_ATRIBUTO_HASH` que el proceso Teradata.

---

### Requerimiento 19: Manejo de SPs Deshabilitados

**User Story:** Como equipo de desarrollo, quiero que los SPs actualmente deshabilitados en Teradata se migren como código inactivo documentado, para poder activarlos en el futuro si se requiere.

#### Criterios de Aceptación

1. THE Sistema_Migracion SHALL migrar `PRO_ORD_FINAL_CTA_ATRIBUTOS` como procedimiento comentado o con flag de activación, documentando que está deshabilitado en el sistema origen.
2. THE Sistema_Migracion SHALL migrar `PRO_ORD_FINAL_UBIC_DIRECCIONES` (versión deshabilitada) como código de referencia, documentando que la versión activa es `PRO_ORD_FINAL_UBIC_DIRECCIONES1`.
3. THE Sistema_Migracion SHALL incluir comentarios en el código migrado indicando el estado de habilitación de cada procedimiento y la razón conocida.

---

### Requerimiento 20: Organización del Código Migrado

**User Story:** Como equipo de desarrollo, quiero que el código migrado esté organizado por fases y con nomenclatura clara, para facilitar el mantenimiento y la trazabilidad con el código fuente original.

#### Criterios de Aceptación

1. THE Sistema_Migracion SHALL organizar los procedimientos migrados en el directorio `ws-ordenamiento/src/redshift/` con una estructura que refleje las 3 fases del proceso (materialización, atributos de cuenta, ubicaciones).
2. THE Sistema_Migracion SHALL mantener un mapeo documentado entre cada SP original de Teradata y su equivalente en Redshift.
3. THE Sistema_Migracion SHALL incluir en cada procedimiento migrado un encabezado con: nombre del SP original, fase a la que pertenece, dependencias, y modo de ejecución (paralelo o secuencial).

---

### Requerimiento 21: Gestión de Tablas Intermedias

**User Story:** Como equipo de desarrollo, quiero definir una estrategia clara para las tablas intermedias en Redshift, para optimizar el uso de recursos y mantener la coherencia del proceso.

#### Criterios de Aceptación

1. THE Sistema_Migracion SHALL crear las tablas intermedias del proceso en el esquema `rec_stage` usando `CREATE TABLE` con `DROP TABLE IF EXISTS` previo.
2. THE Sistema_Migracion SHALL usar tablas regulares (no temporales) para las tablas intermedias que son consumidas por procedimientos ejecutados en paralelo o en pasos posteriores.
3. WHEN el proceso completa exitosamente, THE Sistema_Migracion SHALL eliminar las tablas intermedias del esquema `rec_stage` que no sean necesarias para auditoría o reproceso.

---

### Requerimiento 22: Manejo de Errores y Logging

**User Story:** Como equipo de operaciones, quiero que el proceso migrado registre su ejecución y maneje errores de forma controlada, para facilitar el monitoreo y la resolución de incidentes.

#### Criterios de Aceptación

1. IF un procedimiento falla durante la ejecución, THEN THE Sistema_Migracion SHALL registrar el error con el nombre del procedimiento, timestamp y mensaje de error en una tabla de log.
2. IF se detecta un error crítico en un paso previo (consultando la tabla de log), THEN THE Sistema_Migracion SHALL detener la ejecución y retornar un código de error descriptivo.
3. WHEN cada procedimiento inicia y finaliza exitosamente, THE Sistema_Migracion SHALL registrar el evento con timestamp, nombre del procedimiento y cantidad de registros procesados.
