# Plan de Implementación: Migración Ordenamiento 242

## Resumen

Migración de 17 Stored Procedures de Teradata a scripts SQL estáticos de Amazon Redshift, organizados en 3 fases + infraestructura compartida + scripts deshabilitados. Cada tarea crea un archivo SQL individual siguiendo los patrones de conversión definidos en el diseño (QUALIFY→subquery, SET TABLE→DISTINCT, hash_md5→MD5, eliminación de SQL dinámico).

## Tareas

- [x] 1. Configurar estructura de directorios e infraestructura compartida
  - [x] 1.1 Crear estructura de directorios del proyecto
    - Crear los directorios: `ws-ordenamiento/src/redshift/fase1_materializacion/`, `fase2_atributos_cuenta/`, `fase3_ubicaciones/`, `shared/`, `_disabled/`
    - _Requerimientos: 20.1_

  - [x] 1.2 Crear script de schemas y tablas de control (`shared/00_schemas_tablas_control.sql`)
    - Crear schemas `rec_stage` y `rec_datos` con `CREATE SCHEMA IF NOT EXISTS`
    - Crear tabla `rec_datos.control_ordenamiento` (id_control, fecha_ult_ord, fecha_ejecucion, estado, registros_procesados) con DISTSTYLE ALL
    - Crear tabla `rec_datos.cuenta_atributo_hash` con DISTKEY(id_buro_persona) y SORTKEY(id_buro_persona, cod_pin_persona)
    - Crear tabla `rec_datos.ubicacion_atributo_hash` con DISTKEY(id_buro_persona) y SORTKEY(id_buro_persona, cod_pin_persona)
    - Incluir encabezado estándar con metadata del script
    - _Requerimientos: 20.1, 21.1_

  - [x] 1.3 Crear script de log de ejecución y helpers (`shared/01_log_ejecucion.sql`)
    - Crear tabla `rec_stage.log_ejecucion` (id_log, nombre_procedimiento, fase, evento, timestamp_evento, registros_afectados, mensaje_error, duracion_segundos) con DISTSTYLE ALL
    - Incluir sentencias INSERT de ejemplo para INICIO, FIN y ERROR como referencia para los demás scripts
    - Incluir encabezado estándar
    - _Requerimientos: 22.1, 22.3_

- [x] 2. Checkpoint — Verificar infraestructura compartida
  - Asegurar que todos los scripts de shared/ son válidos sintácticamente, preguntar al usuario si hay dudas.

- [x] 3. Implementar Fase 1: Materialización + Unificación
  - [x] 3.1 Crear script `fase1_materializacion/01_materializa_btt.sql`
    - Migrar SP `PRO_ORD_MATERIALIZA_BTT` a SQL estático de Redshift
    - Consultar `rec_datos.metadata_carga_log` para identificar lotes con inserts/updates posteriores a la fecha del último ordenamiento
    - Extraer pares (Cod_Pin_Persona, Id_Buro_Persona) de tablas BTT modificadas: V_CUENTA, V_BURO_PERSONA, V_COMPORTAMIENTO_CUENTA, V_COMPORTAMIENTO_CUENTA_ACTIVO, V_COMPORTAMIENTO_CUENTA_PASIVO
    - Crear tablas intermedias en rec_stage: estructuras_mtdat_bdm, calcula_lote_btt, paso_v_cuenta, paso_v_buro_persona, paso_v_comportamiento_cuenta, paso_v_comport_cta_activo, paso_v_comport_cta_pasivo
    - Usar patrón `DROP TABLE IF EXISTS` + `CREATE TABLE AS` para idempotencia
    - Eliminar SQL dinámico: reemplazar concatenación de nombres de BD por esquemas fijos (rec_stage, rec_datos)
    - Incluir INSERT en log_ejecucion al inicio y fin
    - Incluir encabezado estándar (SP original, fase, modo paralelo, dependencias, inputs, outputs)
    - _Requerimientos: 1.1, 1.2, 1.3, 1.4, 16.1, 16.2, 16.3, 17.7, 20.3, 22.3_

  - [x] 3.2 Crear script `fase1_materializacion/02_materializa_rec.sql`
    - Migrar SP `PRO_ORD_MATERIALIZA_REC` a SQL estático de Redshift
    - Consultar log_td para identificar lotes con cargas exitosas posteriores a la última ejecución
    - Extraer personas de 10 tablas fuente de ubicaciones, relaciones, bloqueos, estandarización y unificación
    - Crear tablas intermedias en rec_stage: calcula_lote_rec, paso_reporte_ubic_original, paso_rpu, paso_rrpu, paso_v_bloqueo, paso_v_rela_ubic_estandar_geo, paso_v_ubicacion_original, paso_v_ubicacion_estandarizada, paso_v_log_ubic_estandarizada, paso_v_unificacion_direccion
    - Usar patrón `DROP TABLE IF EXISTS` + `CREATE TABLE AS` para idempotencia
    - Eliminar SQL dinámico: esquemas fijos
    - Incluir INSERT en log_ejecucion al inicio y fin
    - Incluir encabezado estándar (modo paralelo con 01_materializa_btt.sql)
    - _Requerimientos: 2.1, 2.2, 2.3, 2.4, 16.1, 16.2, 16.3, 17.7, 20.3, 22.3_

  - [x] 3.3 Crear script `fase1_materializacion/03_unifica_btt_rec.sql`
    - Migrar SP `PRO_ORD_UNIF_BTT_REC` a SQL estático de Redshift
    - Ejecutar UNION ALL de las 14 tablas de paso generadas por materializa_btt y materializa_rec
    - Aplicar SELECT DISTINCT para reemplazar el comportamiento de CREATE SET TABLE de Teradata
    - Crear tabla `rec_stage.unifica_btt_reconocer` con columnas (cod_pin_persona, id_buro_persona)
    - Usar DISTKEY(id_buro_persona) y SORTKEY(id_buro_persona, cod_pin_persona)
    - Incluir INSERT en log_ejecucion al inicio y fin
    - Incluir encabezado estándar (modo secuencial, depende de 01 y 02)
    - _Requerimientos: 3.1, 3.2, 3.3, 17.2, 20.3, 22.3_

  - [x] 3.4 Crear script `fase1_materializacion/04_limpieza_validacion.sql`
    - Migrar SP `PRO_ORD_UNIF_BTT_REC_2` a SQL estático de Redshift
    - Consultar log_ejecucion para detectar errores en pasos anteriores; si hay errores, generar RAISE/señal de error
    - Ejecutar DROP TABLE IF EXISTS para todas las tablas temporales de paso (~15 tablas)
    - Usar DROP TABLE IF EXISTS para evitar errores si la tabla no existe
    - Incluir INSERT en log_ejecucion al inicio y fin
    - Incluir encabezado estándar (modo secuencial, depende de 03 + procesos dependientes)
    - _Requerimientos: 4.1, 4.2, 4.3, 17.7, 22.2_

- [x] 4. Checkpoint — Verificar Fase 1 completa
  - Asegurar que todos los scripts de fase1_materializacion/ son válidos sintácticamente y siguen los patrones de conversión del diseño. Preguntar al usuario si hay dudas.

- [x] 5. Implementar Fase 2: Atributos de Cuenta
  - [x] 5.1 Crear script `fase2_atributos_cuenta/01_cta_atributos.sql`
    - Migrar SP `PRO_ORD_CTA_ATRIBUTOS` a SQL estático de Redshift
    - Extraer cuentas de personas en unifica_btt_reconocer desde VU_CUENTA
    - Enriquecer con LEFT JOINs a V_Razon_Bloqueo, V_FUENTE_DATO, V_COD_ENTREGA_DATO
    - Crear tabla `rec_stage.cta_totales_personas_tmp1` con ~55 columnas de atributos
    - Usar patrón DROP TABLE IF EXISTS + CREATE TABLE AS con DISTKEY(id_buro_persona)
    - Incluir INSERT en log_ejecucion al inicio y fin
    - Incluir encabezado estándar (modo paralelo, depende de unifica_btt_reconocer)
    - _Requerimientos: 5.1, 5.2, 5.3, 16.1, 20.3, 22.3_

  - [x] 5.2 Crear script `fase2_atributos_cuenta/02_cta_totales_personas.sql`
    - Migrar SP `PRO_ORD_CTA_TOTALES_PERSONAS` a SQL estático de Redshift
    - Calcular ventana temporal de 12 meses usando DATEADD(month, -12, fecha_novedad) en lugar de ADD_MONTHS
    - Crear tabla `rec_stage.tmp_cnta_fechas` con rango de fechas por cuenta
    - Incluir INSERT en log_ejecucion al inicio y fin
    - Incluir encabezado estándar (modo secuencial, depende de 01_cta_atributos)
    - _Requerimientos: 6.1, 6.2, 6.3, 17.6, 20.3, 22.3_

  - [x] 5.3 Crear script `fase2_atributos_cuenta/03_cta_totales_personas_1.sql`
    - Migrar SP `PRO_ORD_CTA_TOTALES_PERSONAS_1` a SQL estático de Redshift
    - Cruzar tmp_cnta_fechas con vista de comportamiento de cuenta activo usando BETWEEN en fechas
    - Crear tabla `rec_stage.stg_comportamiento_cta_activo` con datos precalculados
    - Incluir INSERT en log_ejecucion al inicio y fin
    - Incluir encabezado estándar (modo paralelo, depende de 02_cta_totales_personas)
    - _Requerimientos: 7.1, 7.2, 7.3, 20.3, 22.3_

  - [x] 5.4 Crear script `fase2_atributos_cuenta/04_cta_totales_personas_2.sql`
    - Migrar SP `PRO_ORD_CTA_TOTALES_PERSONAS_2` a SQL estático de Redshift
    - Extraer comportamiento pasivo dentro de ventana de 12 meses
    - Cruzar con comportamiento activo previamente calculado
    - Implementar lógica CASE WHEN compleja para clasificación de Portafolio (CO, RO, VE, HP, IN, OT, CC, AH, CT), Portafolio_Nuevo y Sector
    - Crear tablas intermedias: tmp_comportamiento_pasivo, cta_totales_personas_tmp2
    - Crear tabla final `rec_stage.cta_totales_personas_tmp3` con columnas Portafolio, Portafolio_Nuevo, Sector
    - Incluir INSERT en log_ejecucion al inicio y fin
    - Incluir encabezado estándar (modo paralelo, depende de 02 y 03)
    - _Requerimientos: 8.1, 8.2, 8.3, 8.4, 20.3, 22.3_

  - [x] 5.5 Crear script `fase2_atributos_cuenta/05_concat_atributos.sql`
    - Migrar SP `PRO_ORD_CONCAT_ATRIBUTOS` a SQL estático de Redshift
    - Concatenar ~20 atributos numéricos de cuenta en un solo string
    - Calcular hash usando MD5() nativo de Redshift en lugar de rec_vista.hash_md5()
    - Crear tabla `rec_stage.concatena_atributos` con columnas Concatena y cod_hash
    - Incluir INSERT en log_ejecucion al inicio y fin
    - Incluir encabezado estándar (modo secuencial, depende de 04_cta_totales_personas_2)
    - _Requerimientos: 13.1, 13.2, 13.3, 17.4, 20.3, 22.3_

  - [x] 5.6 Crear script `_disabled/final_cta_atributos_disabled.sql`
    - Migrar SP `PRO_ORD_FINAL_CTA_ATRIBUTOS` (deshabilitado) como código de referencia
    - Implementar lógica de detección de registros nuevos por LEFT JOIN WHERE IS NULL contra V_CUENTA_ATRIBUTO_HASH
    - Documentar con comentarios que está deshabilitado en el sistema origen y la razón (IF V_PASO > 0 THEN LEAVE L1)
    - Incluir encabezado estándar indicando estado deshabilitado
    - _Requerimientos: 19.1, 19.3_

- [x] 6. Checkpoint — Verificar Fase 2 completa
  - Asegurar que todos los scripts de fase2_atributos_cuenta/ y el script disabled son válidos. Verificar que la lógica de clasificación de Portafolio cubre todos los casos. Preguntar al usuario si hay dudas.

- [x] 7. Implementar Fase 3: Ubicaciones / Direcciones
  - [x] 7.1 Crear script `fase3_ubicaciones/01_ubic_direcciones.sql`
    - Migrar SP `PRO_ORD_UBIC_DIRECCIONES` a SQL estático de Redshift
    - Filtrar desde MAT_REPORTE_REL_PERS_UBI solo personas en unifica_btt_reconocer
    - Agrupar por persona-ubicación calculando MAX/MIN de Cod_DW_Reporte_Persona_Ubic y Fecha_Reporte según Id_Flag_Desde (0=más reciente con MAX, 1=más antiguo con MIN)
    - Crear tabla `rec_stage.tmp_ord_cal_mat` con resultados agrupados
    - Incluir INSERT en log_ejecucion al inicio y fin
    - Incluir encabezado estándar (modo paralelo, depende de unifica_btt_reconocer)
    - _Requerimientos: 9.1, 9.2, 9.3, 9.4, 20.3, 22.3_

  - [x] 7.2 Crear script `fase3_ubicaciones/02_calc_ubicaciones.sql`
    - Migrar SP `PRO_ORD_CALC_UBICACIONES` a SQL estático de Redshift
    - Calcular fechas de reporte ajustadas para ubicaciones CON cuenta válida en VU_CUENTA
    - Implementar reglas de negocio de fecha: vigente+principal/pasivo/codeudor → Fecha_Apertura (nuevo) o Fecha_Reporte (existente); no vigente → MIN(Fecha_Nov, Fecha_Reporte)
    - Reemplazar QUALIFY ROW_NUMBER() OVER(...) <= 3 por subquery con WHERE rn <= 3
    - Crear tablas intermedias: tmp_ord_cal1, tmp_ord_cal11, tmp_ord_cal2
    - Crear tabla final `rec_stage.tmp_ord_cal3` (top 3 por combinación persona-ubicación)
    - Incluir INSERT en log_ejecucion al inicio y fin
    - Incluir encabezado estándar (modo paralelo, depende de 01_ubic_direcciones)
    - _Requerimientos: 10.1, 10.2, 10.3, 10.4, 17.3, 20.3, 22.3_

  - [x] 7.3 Crear script `fase3_ubicaciones/03_calc_ubicaciones_1.sql`
    - Migrar SP `PRO_ORD_CALC_UBICACIONES_1` a SQL estático de Redshift
    - Mismo cálculo que calc_ubicaciones pero para ubicaciones SIN cuenta válida (COD_DW_CTA NOT IN VU_CUENTA)
    - Aplicar mismas reglas de fecha y patrón QUALIFY→subquery
    - Crear tablas `rec_stage.tmp_ord_cal6` y `rec_stage.tmp_ord_cal61`
    - Incluir INSERT en log_ejecucion al inicio y fin
    - Incluir encabezado estándar (modo paralelo, depende de 01_ubic_direcciones)
    - _Requerimientos: 11.1, 11.2, 11.3, 17.3, 20.3, 22.3_

  - [x] 7.4 Crear script `fase3_ubicaciones/04_calc_ubicaciones_2.sql`
    - Migrar SP `PRO_ORD_CALC_UBICACIONES_2` a SQL estático de Redshift (SP más complejo, ~1300 líneas)
    - Consolidar tmp_ord_cal3 + tmp_ord_cal6 en vmo_reporte_relacion_pers_ubi
    - Construir vector_ubi_insumo_base cruzando personas con relacion_persona_ubicacion, excluyendo bloqueados y unificados
    - Enriquecer con datos de ubicación estandarizada (texto, fuente, geografía)
    - Agregar tipo de persona y tipo de cuenta
    - Crear tablas intermedias: vmo_reporte_relacion_pers_ubi, vector_ubi_insumo_base, datos_ubic_estandarizadas, datos_tipo_persona
    - Crear tabla final `rec_stage.datos_tipo_cuenta` (tabla final de direcciones enriquecida)
    - Usar patrón DROP TABLE IF EXISTS + CREATE TABLE AS con DISTKEY(id_buro_persona) para tablas de alto volumen
    - Incluir INSERT en log_ejecucion al inicio y fin
    - Incluir encabezado estándar (modo paralelo, depende de 02 y 03)
    - _Requerimientos: 12.1, 12.2, 12.3, 12.4, 17.2, 20.3, 22.3_

  - [x] 7.5 Crear script `fase3_ubicaciones/05_concat_direcciones.sql`
    - Migrar SP `PRO_ORD_CONCAT_DIRECCIONES` a SQL estático de Redshift
    - Concatenar atributos de dirección (texto ubicación, tipo, gestión, DANE, tipo persona, tipo cuenta, dirección física, complemento, barrio, latitud, longitud)
    - Calcular hash usando MD5() nativo de Redshift en lugar de rec_vista.hash_md5()
    - Crear tabla `rec_stage.hash_carac_direc` con hash calculado por registro de dirección
    - Incluir INSERT en log_ejecucion al inicio y fin
    - Incluir encabezado estándar (modo secuencial, depende de 04_calc_ubicaciones_2)
    - _Requerimientos: 14.1, 14.2, 14.3, 17.4, 20.3, 22.3_

  - [x] 7.6 Crear script `fase3_ubicaciones/06_final_ubic_direcciones.sql`
    - Migrar SP `PRO_ORD_FINAL_UBIC_DIRECCIONES1` (versión activa) a SQL estático de Redshift
    - Detectar registros nuevos: LEFT JOIN hash_carac_direc con V_UBICACION_ATRIBUTO_HASH WHERE IS NULL → INSERT en rec_datos.ubicacion_atributo_hash
    - Detectar registros modificados: JOIN donde clave existe pero hash difiere → UPDATE rec_datos.ubicacion_atributo_hash usando sintaxis UPDATE ... FROM ... WHERE de Redshift
    - Incluir INSERT en log_ejecucion al inicio y fin
    - Incluir encabezado estándar (modo secuencial, depende de 05_concat_direcciones)
    - _Requerimientos: 15.1, 15.2, 15.3, 15.4, 17.4, 20.3, 22.3_

  - [x] 7.7 Crear script `_disabled/final_ubic_direcciones_v0_disabled.sql`
    - Migrar SP `PRO_ORD_FINAL_UBIC_DIRECCIONES` (versión deshabilitada) como código de referencia
    - Implementar solo lógica de INSERT (sin UPDATE, a diferencia de la versión activa)
    - Documentar con comentarios que está deshabilitado y que la versión activa es PRO_ORD_FINAL_UBIC_DIRECCIONES1
    - Incluir encabezado estándar indicando estado deshabilitado
    - _Requerimientos: 19.2, 19.3_

- [x] 8. Checkpoint — Verificar Fase 3 completa
  - Asegurar que todos los scripts de fase3_ubicaciones/ y el script disabled son válidos. Verificar patrones QUALIFY→subquery y UPDATE...FROM...WHERE. Preguntar al usuario si hay dudas.

- [x] 9. Implementar tests basados en propiedades (PBT)
  - [x] 9.0 Generar dataset sintético de 10,000 personas para pruebas
    - Extender `ws-ordenamiento/data/synthetic/generate.py` para generar 10,000 personas con distribución realista
    - Incluir: 1-15 cuentas por persona, 1-8 ubicaciones, variedad de portafolios, lotes con fechas variadas, duplicados intencionales, registros bloqueados/unificados, hashes pre-calculados
    - Generar archivos SQL de INSERT o CSV cargables en Redshift para el dataset completo
    - Documentar en README la estructura y distribución del dataset
    - _Requerimientos: 18.1, 18.2, 18.3, 18.4_

  - [x] 9.1 Escribir test de propiedad: Filtrado por fecha identifica correctamente lotes nuevos
    - **Propiedad 1: Filtrado por fecha identifica correctamente lotes nuevos**
    - **Valida: Requerimientos 1.1, 2.1, 7.1, 8.1**
    - Generador: fechas aleatorias + registros con fechas variadas y una fecha de control
    - Verificación: solo registros posteriores a fecha control son retornados, sin omisiones ni inclusiones incorrectas

  - [x] 9.2 Escribir test de propiedad: Deduplicación produce conjunto único
    - **Propiedad 2: Deduplicación produce conjunto único**
    - **Valida: Requerimientos 3.1, 3.3**
    - Generador: pares (int, int) con duplicados intencionales provenientes de múltiples fuentes
    - Verificación: COUNT = COUNT DISTINCT, ningún par ausente ni inventado

  - [x] 9.3 Escribir test de propiedad: Detección de errores previos detiene ejecución
    - **Propiedad 3: Detección de errores previos detiene ejecución**
    - **Valida: Requerimientos 4.2, 22.2**
    - Generador: estados de log con/sin registros ERROR posteriores al último INICIO
    - Verificación: si hay ERROR posterior, retorna código distinto de cero

  - [x] 9.4 Escribir test de propiedad: Ventana temporal de 12 meses es correcta
    - **Propiedad 4: Ventana temporal de 12 meses es correcta**
    - **Valida: Requerimiento 6.1**
    - Generador: fechas aleatorias válidas
    - Verificación: fecha_inicio = DATEADD(month, -12, fecha_novedad), fecha_fin = fecha_novedad

  - [x] 9.5 Escribir test de propiedad: Clasificación de Portafolio es determinista y completa
    - **Propiedad 5: Clasificación de Portafolio es determinista y completa**
    - **Valida: Requerimiento 8.2**
    - Generador: combinaciones aleatorias de (tipo_cuenta, tipo_obligacion, cuotas_pactadas, garantia, cod_suscriptor)
    - Verificación: resultado ∈ {CO,RO,VE,HP,IN,OT,CC,AH,CT}, misma entrada → misma salida

  - [x] 9.6 Escribir test de propiedad: Filtrado de personas preserva solo el conjunto autorizado
    - **Propiedad 6: Filtrado de personas preserva solo el conjunto autorizado**
    - **Valida: Requerimientos 9.1, 11.1, 12.2**
    - Generador: tabla de reportes y tabla unificada con personas autorizadas y no autorizadas
    - Verificación: resultado contiene solo personas de unifica_btt_reconocer, excluye bloqueados/unificados

  - [x] 9.7 Escribir test de propiedad: Agregación condicional por flag aplica función correcta
    - **Propiedad 7: Agregación condicional por flag aplica función correcta**
    - **Valida: Requerimiento 9.2**
    - Generador: registros con Id_Flag_Desde (0 o 1) y valores numéricos variados
    - Verificación: MAX cuando flag=0, MIN cuando flag=1, sin mezcla

  - [x] 9.8 Escribir test de propiedad: Reglas de fecha de ubicación seleccionan fecha correcta
    - **Propiedad 8: Reglas de fecha de ubicación seleccionan fecha correcta**
    - **Valida: Requerimiento 10.1**
    - Generador: ubicaciones con diferentes estados de vigencia y tipos
    - Verificación: fecha seleccionada según reglas (Fecha_Apertura si vigente+nuevo, Fecha_Reporte si existente, MIN si no vigente)

  - [x] 9.9 Escribir test de propiedad: Limitación por ROW_NUMBER respeta máximo por partición
    - **Propiedad 9: Limitación por ROW_NUMBER respeta máximo por partición**
    - **Valida: Requerimiento 10.2**
    - Generador: particiones de tamaño variable (1-20 registros)
    - Verificación: COUNT por partición ≤ 3, registros seleccionados son los de mayor prioridad

  - [x] 9.10 Escribir test de propiedad: Hash MD5 es determinista y de formato fijo
    - **Propiedad 10: Hash MD5 es determinista y de formato fijo**
    - **Valida: Requerimientos 13.1, 14.1**
    - Generador: strings aleatorios (concatenación de atributos)
    - Verificación: LENGTH = 32, mismo input → mismo output (determinismo)

  - [x] 9.11 Escribir test de propiedad: Detección de cambios identifica correctamente nuevos y modificados
    - **Propiedad 11: Detección de cambios identifica correctamente nuevos y modificados**
    - **Valida: Requerimientos 15.1, 15.3**
    - Generador: dos conjuntos de (clave, hash) con solapamiento parcial
    - Verificación: nuevos = clave en actual pero no en existente; modificados = clave existe pero hash difiere; sin cambios no se marcan

- [x] 10. Implementar tests de integración y smoke
  - [x] 10.1 Escribir tests de integración (equivalencia con Teradata)
    - Tests con el dataset de 10,000 personas generado en tarea 9.0
    - Ejecutar el flujo completo (fase 1 → fase 2 → fase 3) contra el dataset de 10K registros
    - Verificar materialización BTT/REC, unificación, clasificación Portafolio, hash MD5 equivalencia, persistencia ubicaciones
    - Comparar resultados contra valores esperados pre-calculados para el dataset de 10K
    - Verificar que el proceso migrado produce los mismos resultados que Teradata
    - _Requerimientos: 18.1, 18.2, 18.3, 18.4_

  - [x] 10.2 Escribir tests de humo (smoke) para validación estructural
    - Verificar ausencia de SQL dinámico (grep EXECUTE|SP_EXECSTRING = 0)
    - Verificar ausencia de parámetros de BD (grep P_BDDATOS|P_BDVISTA|P_BDSTAGE = 0)
    - Verificar estructura de directorios (fase1/, fase2/, fase3/, shared/, _disabled/)
    - Verificar encabezados presentes en cada .sql
    - Verificar idempotencia (cada CREATE TABLE tiene DROP TABLE IF EXISTS previo)
    - _Requerimientos: 16.1, 16.2, 17.1, 17.2, 17.7, 20.1, 20.2, 20.3_

- [x] 11. Checkpoint final — Verificar implementación completa
  - Asegurar que todos los tests pasan, que la estructura de directorios es correcta, y que todos los scripts siguen los patrones de conversión del diseño. Preguntar al usuario si hay dudas.

## Notas

- Las tareas marcadas con `*` son opcionales y pueden omitirse para un MVP más rápido
- Cada tarea referencia requerimientos específicos para trazabilidad
- Los checkpoints aseguran validación incremental
- Los tests de propiedades validan propiedades universales de correctitud definidas en el diseño
- Los tests de integración verifican equivalencia funcional con Teradata
- Los tests de humo verifican requisitos estructurales del código migrado
- El lenguaje de implementación es SQL (Amazon Redshift) según el diseño

## Volumen de Datos Mock para Pruebas

**IMPORTANTE**: Los tests de integración y PBT deben usar un volumen significativo de datos mock para ser representativos del comportamiento real del proceso (~65-70M registros en producción).

- **Volumen mínimo para tests**: **10,000 registros** (personas) como dataset base de pruebas
- Los datos mock actuales (`ws-ordenamiento/data/mock/`) solo tienen 10 personas por canal — son insuficientes para validar comportamiento a escala
- Se debe generar un dataset sintético de 10,000 personas con:
  - Distribución realista de cuentas por persona (1-15 cuentas)
  - Múltiples ubicaciones por persona (1-8 direcciones)
  - Variedad de tipos de cuenta, portafolio, estados de vigencia
  - Lotes con fechas variadas (algunos antes y después de la fecha de control)
  - Duplicados intencionales para validar deduplicación
  - Registros bloqueados y unificados para validar exclusiones
  - Hashes pre-calculados para validar detección de cambios
- El generador de datos sintéticos puede extender `ws-ordenamiento/data/synthetic/generate.py` existente
- Los tests deben ejecutarse contra este dataset de 10K para garantizar que los scripts SQL manejan correctamente volúmenes representativos
