--<ScriptOptions statementTerminator=";"/>

REPLACE   PROCEDURE REC_DATOS.PRO_Unifi_MOTOR_TMP
	(
		IN	P_Lote			INTEGER
		,IN	P_StartTimeStampPadre	VARCHAR(20)
		,IN	P_Nombre_Proceso_Padre	VARCHAR(30)
		,IN	P_BDDATOS		VARCHAR(20)
		,IN	P_BDVISTA		VARCHAR(20)
		,IN	P_BDSTAGE		VARCHAR(20)
		,IN	P_BTTPRUVI		VARCHAR(20)
		,OUT	P_ERROR			VARCHAR(32000)
	)
/*
 * ################################################################################
 * 
 * Objetivo:	MOTOR UNIFICACION 
 *				
 *				
 * Fecha:		2017/10/16
 * Realizado por:	Carlos Castillo
 * Proyecto:		Nuevo reconocer
 * Script:		create_PRO_UnificacionR2.sql
 * 
 * 
 * 
 * BITACORA
 * ---------------------------------------------------------------------------
 * Fecha		  Objetivo										Realizado por
 * 
 * 
 * 
 * ---------------------------------------------------------------------------
 * 
 * Copyright 2016 Equipo Teradata - Capgemini
 * 
 *  Este componente fue realizado bajo la metodologia de desarrollo de Capgemini S.A.S y
 * 		se encuentra protegido por las leyes de derechos de autor
 * 
 * 
 * ################################################################################
 */


BEGIN
	

------------------------------------------------
-- Declaracion de variables-------------
------------------------------------------------
	DECLARE V_StartTimeStampPadre	TIMESTAMP(6);
	DECLARE	V_ERROR			VARCHAR(30);
	DECLARE V_CADENA		VARCHAR(32000);
	DECLARE V_CADENA1		VARCHAR(10000);
	DECLARE Temp CHAR(30);
	DECLARE V_SQL     					VARCHAR	(32000);
	DECLARE V_COD_DW_UBIC_H				VARCHAR	(30);
	DECLARE Cur_Nomenclatura NO SCROLL CURSOR 	FOR the_statement;

L1:	BEGIN

	SET P_ERROR = '';
	SET V_StartTimeStampPadre = CAST(P_StartTimeStampPadre AS TIMESTAMP(6) FORMAT 'yyyy-mm-ddhh:mi:ss');

------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------  Inicio creacion nuevas direcciones ------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------


--------------------------------------------------------------------------------
-- Busca y borra si existe la tabla Tmp_Unificacion_E051_D1 --------------------
--------------------------------------------------------------------------------
	SELECT TABLENAME 
	INTO :Temp
	FROM dbc.tables
	WHERE databasename =:P_BDSTAGE 
	AND TABLENAME = 'Tmp_Unificacion_E051_D1' ;

	IF ACTIVITY_COUNT > 0 THEN
		SET V_CADENA = 'DROP TABLE '||P_BDSTAGE || '.Tmp_Unificacion_E051_D1';
		CALL DBC.SysExecSQL(:V_CADENA);
	END IF;

	
	/*1. Descomposición de los complementos por nomenclatura  */
	
	SET V_CADENA = '';
	SET V_CADENA = 'CREATE TABLE '||P_BDSTAGE||'.Tmp_Unificacion_E051_D1  AS 
					(SELECT TU.Cod_DW_Persona_Ubic
					,TU.Cod_dw_ubic
					,DC.nomen
					,NOM.Nivel_Complemento 
					,SUM(1) OVER(PARTITION BY Cod_DW_Persona_Ubic ORDER BY NOM.Nivel_Complemento  DESC  ROWS UNBOUNDED PRECEDING) AS ID_COM
					,SUM(TO_NUMBER(VALOR))	AS valor
					,COUNT(Cod_DW_Persona_Ubic ) AS cantidad
					,SUM(1) OVER(PARTITION BY Cod_DW_Persona_Ubic ORDER BY NOM.Nivel_Complemento  ROWS UNBOUNDED PRECEDING) AS ID_COM1
					FROM '||P_BDSTAGE||'.Tmp_Unificacion_E051_D TU
					INNER  JOIN '||P_BDSTAGE||'.DICCIONARIO_COMPLEMENTOS DC
					ON TU.complemento LIKE ''%''||DC.nomenclatura||''%''
					AND tu.cod_dw_ubic=dc.cod_dw_ubic
					LEFT JOIN '||P_BDDATOS||'.NOMENCLATURA NOM
					ON NOM.NOMENCLATURA=DC.Nomen
					GROUP BY 1,2,3,4
					)WITH DATA 
					PRIMARY INDEX(Cod_DW_Persona_Ubic,nomen,Nivel_Complemento)
					;';
			
	
	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
			,V_StartTimeStampPadre
			,:P_Nombre_Proceso_Padre
			,:V_CADENA
			,'PRO_UnificacionR2 (5):Dirección_nueva'
			,V_ERROR);
			
	SET P_ERROR = V_ERROR;
        
        IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		LEAVE L1;
	END IF;
	

--------------------------------------------------------------------------------
-- Busca y borra si existe la tabla Tmp_Unificacion_E051_D2 --------------------
--------------------------------------------------------------------------------
	SELECT TABLENAME 
	INTO :Temp
	FROM dbc.tables
	WHERE databasename =:P_BDSTAGE 
	AND TABLENAME = 'Tmp_Unificacion_E051_D2' ;

	IF ACTIVITY_COUNT > 0 THEN
		SET V_CADENA = 'DROP TABLE '||P_BDSTAGE ||'.Tmp_Unificacion_E051_D2';
		CALL DBC.SysExecSQL(:V_CADENA);
	END IF;

	
	/*2. agrupación de nomenclaturas por cod_dw_persona_ubic  */
	
	SET V_CADENA = '';
	SET V_CADENA = 'CREATE TABLE '||P_BDSTAGE ||'.Tmp_Unificacion_E051_D2
					(COD_DW_PERSONA_UBIC INTEGER NULL
					,NOM_AGRUP  VARCHAR (100) NULL
					,cantidad	 INTEGER NULL
					) ;
					';
			
	
	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
			,V_StartTimeStampPadre
			,:P_Nombre_Proceso_Padre
			,:V_CADENA
			,'PRO_UnificacionR2 (5):Dirección_nueva'
			,V_ERROR);
			
	SET P_ERROR = V_ERROR;
        
        IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		LEAVE L1;
	END IF;	
	
	
	
	
	SET V_CADENA = '';
	SET V_CADENA = 'INSERT INTO '||P_BDSTAGE||'.Tmp_Unificacion_E051_D2
					SELECT COD_DW_PERSONA_UBIC
						,XMLAGG(NOMEN ORDER BY ID_COM) AS A_NOMEN
						,SUM(cantidad) AS cantidad
					FROM '||P_BDSTAGE||'.Tmp_Unificacion_E051_D1
					GROUP BY 1
					;
					';
			
	
	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
			,V_StartTimeStampPadre
			,:P_Nombre_Proceso_Padre
			,:V_CADENA
			,'PRO_UnificacionR2 (5):Dirección_nueva'
			,V_ERROR);
			
	SET P_ERROR = V_ERROR;
        
        IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		LEAVE L1;
	END IF;		
	

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------CALCULO DE MDIR --> ID para identificar la direción de mayor jerarquía ---------------------------------------------------------------

	SELECT TABLENAME 
	INTO :Temp
	FROM dbc.tables
	WHERE databasename =:P_BDSTAGE 
	AND TABLENAME = 'Tmp_Unificacion_E051_Dx' ;

	IF ACTIVITY_COUNT > 0 THEN
		SET V_CADENA = 'DROP TABLE '||P_BDSTAGE ||'.Tmp_Unificacion_E051_Dx';
		CALL DBC.SysExecSQL(:V_CADENA);
	END IF;


SET V_CADENA = '';

SELECT XMLAGG(CAMPO ORDER BY ORD)
INTO :V_CADENA
FROM 
(SELECT ORD
, ID_COM1 
,CAST(CASE WHEN ID_COM1 = idmin AND TP='ID_COM1'  THEN 'CREATE TABLE REC_STAGE.Tmp_Unificacion_E051_Dx AS ( Select  cod_dw_persona_ubic,cod_dw_ubic
,COALESCE(MAX(CASE WHEN ID_COM1 =  '||TRIM(ID_COM1)||' THEN nivel_complemento end) ,99) AS ID_COM1'||TRIM(ID_COM1)||'
'
WHEN ID_COM1 <> idmin AND TP='ID_COM1'  THEN ',COALESCE(MAX(CASE WHEN ID_COM1 =  '||TRIM(ID_COM1)||' THEN nivel_complemento end) ,99) AS ID_COM1'||TRIM(ID_COM1)||' '
WHEN ID_COM1 <> idMAX AND TP='val' THEN ',COALESCE(MAX(CASE WHEN ID_COM1 =  '||TRIM(ID_COM1)||' THEN valor end),99999) AS val'||TRIM(ID_COM1)||''
WHEN ID_COM1 = idMAX AND TP='val' THEN ',COALESCE(MAX(CASE WHEN ID_COM1 =  '||TRIM(ID_COM1)||' THEN valor end),99999) AS val'||TRIM(ID_COM1)||'
'
END  AS VARCHAR(16000)) AS campo  
FROM 
(SELECT ID_COM1,MAX(ID_COM1) OVER() idmax, MIN(ID_COM1) OVER() idmin , 'ID_COM1' AS TP,  SUM(1) OVER (ORDER BY ID_COM1 ROWS UNBOUNDED PRECEDING ) AS ORD 
FROM rec_stage.Tmp_Unificacion_E051_D1 GROUP BY 1
UNION ALL 
SELECT ID_COM1,MAX(ID_COM1) OVER() idmax, MIN(ID_COM1) OVER() idmin , 'val' AS TP, idMAX + SUM(1) OVER (ORDER BY ID_COM1 ROWS UNBOUNDED PRECEDING ) AS ORD
FROM rec_stage.Tmp_Unificacion_E051_D1 GROUP BY 1
) A
UNION ALL 
SELECT ORD
, ID_COM1 
,CASE WHEN ID_COM1 = idmin AND TP='ID_COM1'  THEN ' ,ROW_NUMBER() OVER (PARTITION BY cod_dw_ubic  ORDER BY  ID_COM1'||TRIM(ID_COM1)||'
'WHEN ID_COM1 <> idmin AND TP='ID_COM1'  THEN ',ID_COM1'||TRIM(ID_COM1)||' '
WHEN ID_COM1 <> idMAX AND TP='val' THEN ',val'||TRIM(ID_COM1)||''
WHEN ID_COM1 = idMAX AND TP='val' THEN ',val'||TRIM(ID_COM1)||') as MDIR
FROM rec_stage.Tmp_Unificacion_E051_D1
GROUP BY 1,2) WITH DATA
'
END AS campo  
FROM 
(SELECT ID_COM1,MAX(ID_COM1) OVER() idmax, MIN(ID_COM1) OVER() idmin , 'ID_COM1' AS TP, 10000+ SUM(1) OVER (ORDER BY ID_COM1 ROWS UNBOUNDED PRECEDING ) AS ORD 
FROM rec_stage.Tmp_Unificacion_E051_D1 GROUP BY 1
UNION ALL 
SELECT ID_COM1,MAX(ID_COM1) OVER() idmax, MIN(ID_COM1) OVER() idmin , 'val' AS TP, 10000+idMAX + SUM(1) OVER (ORDER BY ID_COM1 ROWS UNBOUNDED PRECEDING ) AS ORD
FROM rec_stage.Tmp_Unificacion_E051_D1 GROUP BY 1
) A
) A;


	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
			,V_StartTimeStampPadre
			,:P_Nombre_Proceso_Padre
			,:V_CADENA
			,'PRO_UnificacionR2 (5):MDIR'
			,V_ERROR);
			
	SET P_ERROR = V_ERROR;
        
        IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		LEAVE L1;
	END IF;		
	
	
	

--------------------------------------------------------------------------------
-- Busca y borra si existe la tabla Tmp_Unificacion_E051_D3 --------------------
--------------------------------------------------------------------------------
	SELECT TABLENAME 
	INTO :Temp
	FROM dbc.tables
	WHERE databasename =:P_BDSTAGE 
	AND TABLENAME = 'Tmp_Unificacion_E051_D3' ;

	IF ACTIVITY_COUNT > 0 THEN
		SET V_CADENA = 'DROP TABLE '||P_BDSTAGE ||'.Tmp_Unificacion_E051_D3';
		CALL DBC.SysExecSQL(:V_CADENA);
	END IF;

	
	/*3. agrupación Nomenclatura - valor cod_dw_persona_ubic e identificación de orden NOMENCLATURA - VALOR  */
	
	SET V_CADENA = '';
	SET V_CADENA = 'CREATE TABLE '||P_BDSTAGE||'.Tmp_Unificacion_E051_D3 AS (
				SELECT TU.cod_dw_ubic
				,TU.Cod_DW_Persona_Ubic
				,TU.complemento
				,DC.Nomenclatura
				,DC.nomen
				,DC.VALOR
				,NOM.Nivel_Complemento
				,TU.Id_Buro_Persona
				,TU.Cod_DW_Tipo_Ubicacion_Dir
				,MAX(NOM.Nivel_Complemento) OVER() MAX_NIVEL
				,MIN(NOM.Nivel_Complemento) OVER() MIN_NIVEL
				,TUN.ID_COM
				,MAX(TUN.ID_COM) OVER() MAX_ID_COM
				,MIN(TUN.ID_COM) OVER() MIN_ID_COM
				,MDIR
				,SUM(1) OVER(PARTITION BY TU.Cod_DW_Persona_Ubic ORDER BY MDIR,ID_COM DESC,TO_NUMBER(DC.VALOR)ROWS UNBOUNDED PRECEDING) AS ORDEN
				,NAGR.NOM_AGRUP 
				,NAGR.CANTIDAD
				FROM '||P_BDSTAGE||'.Tmp_Unificacion_E051_D TU
				INNER  JOIN '||P_BDSTAGE||'.DICCIONARIO_COMPLEMENTOS DC
				ON TU.complemento LIKE ''%''||DC.nomenclatura||''%''
				AND tu.cod_dw_ubic=dc.cod_dw_ubic
				LEFT JOIN REC_DATOS.NOMENCLATURA NOM
				ON NOM.NOMENCLATURA=DC.Nomen
				LEFT JOIN '||P_BDSTAGE||'.Tmp_Unificacion_E051_D1 TUN 
				ON TUN.Cod_DW_Persona_Ubic = TU.Cod_DW_Persona_Ubic
				AND TUN.nomen  = DC.nomen
				AND TUN.Nivel_Complemento  = NOM.Nivel_Complemento
				LEFT JOIN '||P_BDSTAGE||'.Tmp_Unificacion_E051_Dx AS MD
				ON TU.Cod_DW_Persona_Ubic=MD.COD_DW_PERSONA_UBIC
				LEFT JOIN '||P_BDSTAGE||'.Tmp_Unificacion_E051_D2 NAGR
				ON TU.COD_DW_PERSONA_UBIC=NAGR.COD_DW_PERSONA_UBIC
				
				)WITH DATA 
				PRIMARY INDEX(Id_Buro_Persona,Cod_DW_Persona_Ubic,cod_dw_ubic,Cod_DW_Tipo_Ubicacion_Dir)
				;
					';
			
	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
			,V_StartTimeStampPadre
			,:P_Nombre_Proceso_Padre
			,:V_CADENA
			,'PRO_UnificacionR2 (5):Dirección_nueva'
			,V_ERROR);
			
	SET P_ERROR = V_ERROR;
        
        IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		LEAVE L1;
	END IF;	
		
------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------	

--------------------------------------------------------------------------------
-- Busca y borra si existe la tabla Tmp_Unificacion_E051_D00 -------------------
--------------------------------------------------------------------------------
	SELECT TABLENAME 
	INTO :Temp
	FROM dbc.tables
	WHERE databasename =:P_BDSTAGE 
	AND TABLENAME = 'Tmp_Unificacion_E051_D00' ;

	IF ACTIVITY_COUNT > 0 THEN
		SET V_CADENA = 'DROP TABLE '||P_BDSTAGE ||'.Tmp_Unificacion_E051_D00';
		CALL DBC.SysExecSQL(:V_CADENA);
	END IF;


	
	SET V_CADENA = '';
	
	SELECT CAST(SQL_STRING AS VARCHAR(32000)) AS CONSULTA
	INTO :V_CADENA
	FROM (
	SELECT   XMLAGG(campo ORDER BY numero ) AS SQL_STRING
	FROM (SELECT numero,
	CASE WHEN NUMERO=1 THEN  'CREATE SET TABLE '||P_BDSTAGE ||'.Tmp_Unificacion_E051_D00
		( 
			Cod_DW_Persona_Ubic INTEGER
			,Cod_DW_Ubic INTEGER
			,Id_Buro_Persona INTEGER
			,Cod_DW_Tipo_Ubicacion_Dir INTEGER
			,Complemento VARCHAR(100) 
			,cantidad INTEGER
			,NOM_AGRUP VARCHAR(100) 
	' ELSE '' END
	|| CASE WHEN NUMERO <> (SELECT MAX(CANTIDAD) FROM REC_STAGE.Tmp_Unificacion_E051_D3) THEN 
	',C'||TRIM(NUMERO)|| '	VARCHAR(30) '
	ELSE ',C'||TRIM(NUMERO)|| '	VARCHAR(30) ' 
	||'
	);' END AS campo
	
	FROM 
	(SELECT SUM(1) OVER(ROWS UNBOUNDED PRECEDING) AS NUMERO
	FROM REC_STAGE.Tmp_Unificacion_E051_D3
	QUALIFY (NUMERO) <= (SELECT MAX(CANTIDAD) FROM REC_STAGE.Tmp_Unificacion_E051_D3)
	) T2
	) T3 
	) T4;	 

					
			
	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
			,V_StartTimeStampPadre
			,:P_Nombre_Proceso_Padre
			,:V_CADENA
			,'PRO_UnificacionR2 (5):Dirección_nueva c'
			,V_ERROR);
			
	SET P_ERROR = V_ERROR;
        
        IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		LEAVE L1;
	END IF;	


	SET V_CADENA='';
	
      SELECT XMLAGG(CAMPO ORDER BY NUMERO) AS CONSULTA
      INTO :V_CADENA
      FROM (
      
      SELECT NUMERO,
      CASE WHEN NUMERO=1 THEN  '
	INSERT INTO REC_STAGE.Tmp_Unificacion_E051_D00 
	SELECT COD_DW_PERSONA_UBIC
	,COD_DW_UBIC
	,ID_BURO_PERSONA
	,Cod_DW_Tipo_Ubicacion_Dir
	,COMPLEMENTO
	,CANTIDAD
	,NOM_AGRUP
	' ELSE '' END
	|| CASE WHEN NUMERO <> (SELECT MAX(CANTIDAD) FROM REC_STAGE.Tmp_Unificacion_E051_D3) THEN 
	',XMLAGG(CASE WHEN ORDEN='||TRIM(NUMERO)|| 'THEN NOMENCLATURA END ORDER BY ORDEN )  AS C'||TRIM(NUMERO)
	ELSE ',XMLAGG(CASE WHEN ORDEN='||TRIM(NUMERO)|| 'THEN NOMENCLATURA END ORDER BY ORDEN )  AS C'||TRIM(NUMERO) 
	||'
	FROM REC_STAGE.Tmp_Unificacion_E051_D3 
	GROUP BY 1,2,3,4,5,6,7
	;' END CAMPO
	FROM 
	(SELECT SUM(1) OVER(ROWS UNBOUNDED PRECEDING) AS NUMERO
	FROM REC_STAGE.Tmp_Unificacion_E051_D3
	QUALIFY (NUMERO) <= (SELECT MAX(CANTIDAD) FROM REC_STAGE.Tmp_Unificacion_E051_D3)
	) T2
	) T3
	;

	
			
	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
			,V_StartTimeStampPadre
			,:P_Nombre_Proceso_Padre
			,:V_CADENA
			,'PRO_UnificacionR2 (5):Dirección_nueva c'
			,V_ERROR);
			
	SET P_ERROR = V_ERROR;
        
        IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		LEAVE L1;
	END IF;	


------------------------------------------------------------------------------------------------------------------------------------------------
----------------ESTRUCTURA TIPO N --> Convinación de posibles nomenclaturas-valor  -------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------	
	SELECT TABLENAME 
	INTO :Temp
	FROM dbc.tables
	WHERE databasename =:P_BDSTAGE 
	AND TABLENAME = 'Tmp_Unificacion_E051_D01' ;

	IF ACTIVITY_COUNT > 0 THEN
		SET V_CADENA = 'DROP TABLE '||P_BDSTAGE ||'.Tmp_Unificacion_E051_D01';
		CALL DBC.SysExecSQL(:V_CADENA);
	END IF;
		
	
	SET V_CADENA='';
	
	SELECT XMLAGG(CAMPO ORDER BY NUMERO) AS CONSULTA
	INTO :V_CADENA
	FROM (
	SELECT NUMERO, CASE WHEN NUMERO=1 THEN  'CREATE SET  TABLE REC_STAGE.Tmp_Unificacion_E051_D01
    	 ( Cod_DW_Persona_Ubic INTEGER
	,Complemento VARCHAR(100) 
	' ELSE '' END
	|| CASE WHEN NUMERO <> (SELECT MAX(CANTIDAD) FROM REC_STAGE.Tmp_Unificacion_E051_D3) THEN 
	',N'||TRIM(NUMERO)|| '	VARCHAR(100)'
	ELSE ',N'||TRIM(NUMERO)|| '	VARCHAR(100)
	);
	' END AS CAMPO
	
	FROM 
	(SELECT SUM(1) OVER(ROWS UNBOUNDED PRECEDING) AS NUMERO
	FROM REC_STAGE.Tmp_Unificacion_E051_D3
	QUALIFY (NUMERO) <= (SELECT MAX(CANTIDAD) FROM REC_STAGE.Tmp_Unificacion_E051_D3)
	) T2
	) T3
	
	;
	
	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
			,V_StartTimeStampPadre
			,:P_Nombre_Proceso_Padre
			,:V_CADENA
			,'PRO_UnificacionR2 (5):Dirección_nueva N'
			,V_ERROR);
			
	SET P_ERROR = V_ERROR;
        
        IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		LEAVE L1;
	END IF;	
	
	
	
	SET V_CADENA='';
	
	SELECT XMLAGG(CAMPO ORDER BY NUMERO) AS CONSULTA
	INTO :V_CADENA
	FROM (
	
	SELECT NUMERO,
	CASE WHEN NUMERO=1 THEN  'INSERT INTO REC_STAGE.Tmp_Unificacion_E051_D01 
	SELECT COD_DW_PERSONA_UBIC
	,COMPLEMENTO
	,MAX(CASE WHEN ORDEN=1 THEN COMPLEMENTO END) 					 AS N1 
	' ELSE '' END
	|| CASE WHEN NUMERO <> (SELECT MAX(CANTIDAD) FROM REC_STAGE.Tmp_Unificacion_E051_D3) THEN 
	',XMLAGG(CASE WHEN ORDEN>'||TRIM(NUMERO)|| 'THEN NOMENCLATURA END ORDER BY ORDEN )  AS N'||TRIM(NUMERO+1)
	ELSE '
	FROM REC_STAGE.Tmp_Unificacion_E051_D3
	GROUP BY 1,2
	' END AS CAMPO
	FROM 
	(SELECT SUM(1) OVER(ROWS UNBOUNDED PRECEDING) AS NUMERO
	FROM REC_STAGE.Tmp_Unificacion_E051_D3
	QUALIFY (NUMERO) <= (SELECT MAX(CANTIDAD) FROM REC_STAGE.Tmp_Unificacion_E051_D3)
	) T2
	)T3
	;
	
	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
			,V_StartTimeStampPadre
			,:P_Nombre_Proceso_Padre
			,:V_CADENA
			,'PRO_UnificacionR2 (5):Dirección_nueva N'
			,V_ERROR);
			
	SET P_ERROR = V_ERROR;
        
        IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		LEAVE L1;
	END IF;

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------ Se crea la tabla con identificación de registro de mayor gerarquía ---------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	
	SELECT TABLENAME 
	INTO :Temp
	FROM dbc.tables
	WHERE databasename =:P_BDSTAGE 
	AND TABLENAME = 'Tmp_Unificacion_E051_P' ;

	IF ACTIVITY_COUNT > 0 THEN
		SET V_CADENA = 'DROP TABLE '||P_BDSTAGE ||'.Tmp_Unificacion_E051_P';
		CALL DBC.SysExecSQL(:V_CADENA);
	END IF;
	
	SET V_CADENA='';
	
	SELECT 'CREATE TABLE REC_STAGE.Tmp_Unificacion_E051_P AS(
	SELECT T2.COD_DW_PERSONA_UBIC
	,T2.COD_DW_UBIC
	,T2.ID_BURO_PERSONA 
	,T2.Cod_DW_Tipo_Ubicacion_Dir
	,T2.COMPLEMENTO
	,T3.CANTIDAD
	,T3.NOM_AGRUP
	'||
	OREPLACE(XMLAGG( ',T3.'||TRIM(COLUMNNAME) ORDER BY ColumnId) ,'@','')
	||'
	 FROM REC_STAGE.Tmp_Unificacion_E051_D3 AS T2
	LEFT JOIN REC_STAGE.Tmp_Unificacion_E051_D00 AS T3
		ON T2.COD_DW_PERSONA_UBIC=T3.COD_DW_PERSONA_UBIC
	QUALIFY (ROW_NUMBER()OVER(PARTITION BY T2.COD_DW_UBIC,T2.ID_BURO_PERSONA,T2.Cod_DW_Tipo_Ubicacion_Dir ORDER BY T2.MDIR ,T2.ORDEN ))=1
	) WITH DATA
	'
	INTO :V_CADENA
	FROM DBC.COLUMNS
	WHERE TRIM(DATABASENAME)= 'REC_STAGE'
	AND TRIM(TABLENAME)= 'Tmp_Unificacion_E051_D00'
	AND TRIM(COLUMNNAME) LIKE 'C%'
	AND ColumnFormat = 'X(30)'
	;

	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
			,V_StartTimeStampPadre
			,:P_Nombre_Proceso_Padre
			,:V_CADENA
			,'PRO_UnificacionR2 (5):Dirección_nueva P'
			,V_ERROR);
			
	SET P_ERROR = V_ERROR;
        
        IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		LEAVE L1;
	END IF;

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------ Se crea la tabla con identificación de registro de MENOR gerarquía ---------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	
	SELECT TABLENAME 
	INTO :Temp
	FROM dbc.tables
	WHERE databasename =:P_BDSTAGE 
	AND TABLENAME = 'Tmp_Unificacion_E051_H' ;

	IF ACTIVITY_COUNT > 0 THEN
		SET V_CADENA = 'DROP TABLE '||P_BDSTAGE ||'.Tmp_Unificacion_E051_H';
		CALL DBC.SysExecSQL(:V_CADENA);
	END IF;


SET V_CADENA='';

SELECT 'CREATE TABLE REC_STAGE.Tmp_Unificacion_E051_H 
	AS (
	SELECT T2.COD_DW_PERSONA_UBIC
	,T2.COD_DW_UBIC
	,T2.ID_BURO_PERSONA 
	,T2.Cod_DW_Tipo_Ubicacion_Dir
	,T2.COMPLEMENTO
	,T2.CANTIDAD
	,T2.NOM_AGRUP
	,T2.MDIR

	'||OREPLACE(XMLAGG( ',T5.'||TRIM(COLUMNNAME) ORDER BY ColumnId) ,'@','')
	 || (SELECT OREPLACE(XMLAGG( ',T3.'||TRIM(COLUMNNAME) ORDER BY ColumnId) ,'@','') AS CPN
	FROM DBC.COLUMNS
	WHERE TRIM(DATABASENAME)= 'REC_STAGE'
	AND TRIM(TABLENAME)= 'Tmp_Unificacion_E051_D01'
	AND TRIM(COLUMNNAME) LIKE 'N%'
	AND ColumnFormat = 'X(100)')
	
	||'
	 FROM REC_STAGE.Tmp_Unificacion_E051_D3 AS T2
	 LEFT JOIN REC_STAGE.Tmp_Unificacion_E051_D01 AS T3
	 	ON T2.COD_DW_PERSONA_UBIC=T3.COD_DW_PERSONA_UBIC
	 INNER JOIN REC_STAGE.Tmp_Unificacion_E051_D00 AS T5
	 	ON T2.COD_DW_PERSONA_UBIC=T5.COD_DW_PERSONA_UBIC
	 WHERE NOT EXISTS ( SELECT 1 FROM  REC_STAGE.Tmp_Unificacion_E051_P T4 WHERE T4.COD_DW_PERSONA_UBIC=T2.COD_DW_PERSONA_UBIC)
	 QUALIFY (ROW_NUMBER()OVER(PARTITION BY T2.COD_DW_PERSONA_UBIC ORDER BY T2.MDIR ,T2.ORDEN ))=1
	 ) WITH DATA
	 ;
	'
	INTO :V_CADENA
	FROM DBC.COLUMNS
	WHERE TRIM(DATABASENAME)= 'REC_STAGE'
	AND TRIM(TABLENAME)= 'Tmp_Unificacion_E051_D00'
	AND TRIM(COLUMNNAME) LIKE 'C%'
	AND ColumnFormat = 'X(30)'
;

	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
			,V_StartTimeStampPadre
			,:P_Nombre_Proceso_Padre
			,:V_CADENA
			,'PRO_UnificacionR2 (5):Dirección_nueva H'
			,V_ERROR);
			
	SET P_ERROR = V_ERROR;
        
        IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		LEAVE L1;
	END IF;	
	
	
	
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------ Se crea la tabla con los codigos generados para identificar los complementos que van a crear un nuevo complemento ---------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	
	SELECT TABLENAME 
	INTO :Temp
	FROM dbc.tables
	WHERE databasename =:P_BDSTAGE 
	AND TABLENAME = 'Tmp_Unificacion_E051_codigo' ;

	IF ACTIVITY_COUNT > 0 THEN
		SET V_CADENA = 'DROP TABLE '||P_BDSTAGE ||'.Tmp_Unificacion_E051_codigo';
		CALL DBC.SysExecSQL(:V_CADENA);
	END IF;
	
	SET V_CADENA='';
	
	SELECT XMLAGG(CAMPO ORDER BY ID_ORDEN) AS SQL_STRING
	INTO :V_CADENA
	FROM (
	SELECT SUM(1) OVER(ORDER BY NUMERO ROWS UNBOUNDED PRECEDING) AS ID_ORDEN,
	CAST(
	CASE WHEN NUMERO=1 THEN  'CREATE TABLE  REC_STAGE.Tmp_Unificacion_E051_codigo AS (
	SELECT T1.COD_DW_PERSONA_UBIC AS COD_DW_PERSONA_UBIC_PADRE
	,T2.COD_DW_PERSONA_UBIC AS COD_DW_PERSONA_UBIC_HIJO
	,T1.COMPLEMENTO AS COMPLEMENTO_PADRE
	,T1.COD_DW_UBIC 			
	,T1.ID_BURO_PERSONA 			
	,T1.Cod_DW_Tipo_Ubicacion_Dir	
	' ELSE '' END
	|| CASE WHEN NUMERO <> (SELECT MAX(CANTIDAD) FROM REC_STAGE.Tmp_Unificacion_E051_D3) THEN 
	',N'||TRIM(NUMERO)|| '	'
	ELSE ',N'||TRIM(NUMERO)|| '	' 
	||'
	
	' END
	
	AS VARCHAR(16000)) AS CAMPO
	
	FROM 
	(SELECT SUM(1) OVER(ROWS UNBOUNDED PRECEDING) AS NUMERO
	FROM REC_STAGE.Tmp_Unificacion_E051_D3
	QUALIFY (NUMERO) <= (SELECT MAX(CANTIDAD) FROM REC_STAGE.Tmp_Unificacion_E051_D3)
	) T2
	--ORDER BY NUMERO
	
	UNION ALL 
	
	SELECT 1000 + SUM(1)  OVER(ORDER BY NUMERO ROWS UNBOUNDED PRECEDING) AS ID_ORDEN,
	
	CASE WHEN NUMERO=1 THEN  ',CASE WHEN T1.NOM_AGRUP= T2.NOM_AGRUP THEN ''1'' ELSE ''0'' END	
	' ELSE '' END
	|| CASE WHEN NUMERO <> (SELECT MAX(CANTIDAD) FROM REC_STAGE.Tmp_Unificacion_E051_D3) THEN 
	'|| CASE WHEN T1.C'||TRIM(NUMERO)||' = T2.C'||TRIM(NUMERO)||' THEN ''1'' ELSE ''0'' END'
	
	ELSE '|| CASE WHEN T1.C'||TRIM(NUMERO)|| '= T2.C'||TRIM(NUMERO)||' THEN ''1'' ELSE ''0'' END AS CODIGO
	,''TRIM(N''||TRIM( CASE WHEN  (POSITION( ''0'' IN CODIGO) -1)<1 THEN 1 ELSE  (POSITION( ''0'' IN CODIGO) -1) END )||'')'' AS Campo_Complemento
	, CAST( NULL AS VARCHAR(300)) AS NUEVA_NOMENCLATURA
	,T2.MDIR  
	' 
	||'
	FROM REC_STAGE.Tmp_Unificacion_E051_P T1
	LEFT JOIN REC_STAGE.Tmp_Unificacion_E051_H T2
	ON 		T1.COD_DW_UBIC 			= 	T2.COD_DW_UBIC
	AND 	T1.ID_BURO_PERSONA 			= 	T2.ID_BURO_PERSONA 
	AND 	T1.Cod_DW_Tipo_Ubicacion_Dir	=	T2.Cod_DW_Tipo_Ubicacion_Dir
	) WITH DATA
	UNIQUE PRIMARY INDEX(COD_DW_PERSONA_UBIC_PADRE,COD_DW_PERSONA_UBIC_HIJO)
	;
	' END AS CAMPO
	
	FROM 
	(SELECT SUM(1) OVER(ROWS UNBOUNDED PRECEDING) AS NUMERO
	FROM REC_STAGE.Tmp_Unificacion_E051_D3
	QUALIFY (NUMERO) <= (SELECT MAX(CANTIDAD) FROM REC_STAGE.Tmp_Unificacion_E051_D3)
	) T2
	--ORDER BY NUMERO
	)T3;

	
	CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
			,V_StartTimeStampPadre
			,:P_Nombre_Proceso_Padre
			,:V_CADENA
			,'PRO_UnificacionR2 (5):Dirección_nueva codigos'
			,V_ERROR);
			
	SET P_ERROR = V_ERROR;
        
        IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
		LEAVE L1;
	END IF;	
	

---------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------- Cursor Actulización NUEVA_NOMENCLATURA -----------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------
	SET V_CADENA =  'SELECT  COD_DW_PERSONA_UBIC_HIJO,CAMPO_COMPLEMENTO
					 FROM '||P_BDSTAGE||'.Tmp_Unificacion_E051_codigo
					 ';

PREPARE the_statement FROM V_CADENA;

OPEN Cur_Nomenclatura ;

	CUR2:LOOP
		FETCH Cur_Nomenclatura  INTO  V_COD_DW_UBIC_H, V_SQL ;
		
		IF SQLCODE <> 0 THEN LEAVE CUR2;
		END IF;

-------------------------- UPDATE COMPLEMENTO -------------------------------------------------
-------------------------------------------------------------------------------------------------------------		
		SET V_CADENA='';
		SET V_CADENA='UPDATE A 
						FROM '||P_BDSTAGE||'.Tmp_Unificacion_E051_codigo  A 
						  SET NUEVA_NOMENCLATURA= '||V_SQL||'
						WHERE COD_DW_PERSONA_UBIC_HIJO ='''||V_COD_DW_UBIC_H|| '''
						';
		SET P_ERROR=V_CADENA;			
	
		CALL DBC.SysExecSQL(:V_CADENA);

	END LOOP CUR2;

CLOSE Cur_Nomenclatura ;

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------CREACION DE REGISTRO NUEVO PARA DIRECCION_FISICA Y RELACION PERSONA UBICACION -------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

		SELECT TABLENAME 
		INTO :Temp
		FROM dbc.tables
		WHERE databasename =:P_BDSTAGE 
		AND TABLENAME = 'Tmp_Unificacion_E051_E' ;
		
		IF ACTIVITY_COUNT > 0 THEN
			SET V_CADENA = 'DROP TABLE '||P_BDSTAGE ||'.Tmp_Unificacion_E051_E';
			CALL DBC.SysExecSQL(:V_CADENA);
		END IF;



		SET V_CADENA='';
		SET V_CADENA='CREATE TABLE rec_stage.Tmp_Unificacion_E051_E AS (
			SELECT COD_DW_PERSONA_UBIC_PADRE||COD_DW_PERSONA_UBIC_HIJO AS Cod_DW_Persona_Ubic 
			,NULL ID
			,T1.Texto_Ubicacion
			, CL.Id_Buro_Persona
			, CL.Cod_DW_Tipo_Ubicacion_Dir
			,COMPLEMENTO_PADRE|| CAST(NUEVA_NOMENCLATURA AS VARCHAR(300) )AS Complemento1
			,NULL Nomenclatura
			,CASE WHEN DF.COD_DW_DIRECCION_FISICA IS NULL 
					THEN ((SELECT ID FROM REC_MTDAT.MAX_ID AS M_ID1 WHERE M_ID1.NOMBRE_TABLA =''DIRECCION_FISICA'') +  SUM(1)    OVER (ROWS UNBOUNDED PRECEDING)) 
					ELSE DF.COD_DW_DIRECCION_FISICA   END AS COD_DW_DIRECCION_FISICA
			,CASE WHEN RPU.Cod_DW_Persona_Ubic IS NULL 
					THEN ((SELECT id FROM REC_MTDAT.MAX_ID AS M_ID WHERE M_ID.NOMBRE_TABLA =''RELACION_PERSONA_UBICACION'' ) +  SUM(1)    OVER (ROWS UNBOUNDED PRECEDING)) 
					ELSE RPU.Cod_DW_Persona_Ubic  END AS ID_PADRE
			,CL.COD_DW_UBIC
			FROM (
			SELECT COD_DW_PERSONA_UBIC_PADRE
			,COMPLEMENTO_PADRE
			,Cod_DW_Ubic
			,Id_Buro_Persona
			,Cod_DW_Tipo_Ubicacion_Dir
			,OREPLACE(XMLAGG( '' ''||TRIM(NUEVA_NOMENCLATURA) ORDER BY MDIR DESC) ,''@#X'','''')AS NUEVA_NOMENCLATURA
			,OREPLACE(XMLAGG( '' ,''||TRIM(COD_DW_PERSONA_UBIC_HIJO) ORDER BY MDIR DESC),''@'','''')  AS COD_DW_PERSONA_UBIC_HIJO
			FROM REC_STAGE.Tmp_Unificacion_E051_codigo 
			GROUP BY 1,2,3,4,5
			)CL
				LEFT JOIN REC_DATOS.DIRECCION_FISICA  DF
						ON 	 DF.Cod_DW_Ubic= CL.Cod_DW_Ubic
						AND  DF.Complemento = Complemento1
			
				LEFT JOIN REC_DATOS.RELACION_PERSONA_UBICACION RPU
				  ON     CL.Id_Buro_Persona  				= RPU.Id_Buro_Persona
				    AND DF.Cod_DW_Ubic  				= RPU.Cod_DW_Ubic
				    AND DF.Cod_DW_Direccion_Fisica  		= RPU.Cod_DW_Direccion_Fisica
				    AND CL.Cod_DW_Tipo_Ubicacion_Dir	= RPU.Cod_DW_Tipo_Ubicacion_Dir		
				 
				 LEFT JOIN REC_STAGE.Tmp_Unificacion_E051_D T1
				 ON T1.Cod_DW_Persona_Ubic=CL.COD_DW_PERSONA_UBIC_PADRE
				 
			)WITH DATA;
			';

			CALL REC_DATOS.SP_EXECSTRING_DES(:P_Lote
			,V_StartTimeStampPadre
			,:P_Nombre_Proceso_Padre
			,:V_CADENA
			,'PRO_UnificacionR2 (5):Dirección_nueva codigos'
			,V_ERROR);
			
			SET P_ERROR = V_ERROR;
        		
        		IF CHARACTER_LENGTH(V_ERROR) > 0 THEN
				LEAVE L1;
			END IF;	
	
	END L1;
    
END;

