-- ============================================================
-- 04_regla2_esc4.sql
-- Regla 2 Escenario 4: Nomenclaturas diferentes, mismo nivel
-- → Consulta DICCIONARIO_COMPLEMENTOS, mayor frecuencia = padre
-- Fuente Teradata: PRO_UnificacionR2.sql líneas 1838-2246
-- ============================================================
-- Prerequisito: 03_regla2_esc1_2.sql ejecutado (stg_regla2_e2 existe)
--
-- Flujo:
--   1. Filtrar no-unificados con complemento diferente
--   2. Identificar nomenclaturas de cada complemento (JOIN NOMENCLATURA)
--   3. Filtrar pares donde nomenclaturas están al mismo nivel
--   4. Sumar frecuencias del DICCIONARIO_COMPLEMENTOS
--   5. Calcular score = (frecuencia + 10000000) + fecha
--   6. Generar pares padre-hijo (mayor score = padre)
--   7. Actualizar tabla E2 acumulada
--
-- Dato mock P08: KR 20 55 18, CS 312 (freq=15) vs CS 108 (freq=3)
--   → padre = CS 312 (mayor frecuencia)
-- ============================================================

-- PASO 1: Filtrar no-unificados con complemento diferente
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04;
CREATE TABLE bdm_tempo.stg_regla2_e04
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT A.*
FROM (SELECT * FROM bdm_tempo.stg_regla2_e2 WHERE ind_unificacion = 'N') A
JOIN (SELECT * FROM bdm_tempo.stg_regla2_e2 WHERE ind_unificacion = 'N') B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.complemento              <> B.complemento;

ANALYZE bdm_tempo.stg_regla2_e04;

-- PASO 2: Identificar nomenclaturas de cada complemento
-- NMC1 = nomenclatura al inicio del complemento (ej: "CS" de "CS 312")
-- NMC2 = nomenclatura secundaria en medio del complemento (si existe)
-- COMPLEMENTO2 = complemento sin las nomenclaturas (solo valores numéricos)
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_a;
CREATE TABLE bdm_tempo.stg_regla2_e04_a
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT
  A.*,
  NMC1.nomenclatura AS nomenclatura_pri,
  NMC1.nivel_complemento AS nivel_pri,
  NMC2.nomenclatura AS nomenclatura_sec,
  NMC2.nivel_complemento AS nivel_sec,
  TRIM(REPLACE(REPLACE(A.complemento, COALESCE(NMC1.nomenclatura,''), ''), COALESCE(NMC2.nomenclatura,''), '')) AS complemento2
FROM bdm_tempo.stg_regla2_e04 A
LEFT JOIN bdm_datos.nomenclatura NMC1
  ON A.complemento LIKE TRIM(NMC1.nomenclatura) || ' %'
LEFT JOIN bdm_datos.nomenclatura NMC2
  ON A.complemento LIKE '% ' || TRIM(NMC2.nomenclatura) || ' %'
  AND NMC2.nomenclatura <> COALESCE(NMC1.nomenclatura, '');

ANALYZE bdm_tempo.stg_regla2_e04_a;

-- PASO 3: Filtrar pares donde nomenclaturas están al mismo nivel
-- Caso 1: misma nomenclatura primaria, diferente secundaria, mismo nivel secundario
-- Caso 2: diferente nomenclatura primaria, misma secundaria, mismo nivel primario
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_c;
CREATE TABLE bdm_tempo.stg_regla2_e04_c
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT * FROM (
  -- Caso 1: misma nomenclatura primaria, ≠ secundaria, mismo nivel secundario
  SELECT A.*
  FROM bdm_tempo.stg_regla2_e04_a A
  JOIN bdm_tempo.stg_regla2_e04_a B
    ON  A.id_buro_persona          = B.id_buro_persona
    AND A.texto_ubicacion           = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
    AND A.cod_dw_municipio          = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
    AND A.complemento              <> B.complemento
    AND (A.complemento2 LIKE '%' || B.complemento2 || '%'
         OR B.complemento2 LIKE '%' || A.complemento2 || '%')
    AND A.nomenclatura_pri = B.nomenclatura_pri
    AND COALESCE(A.nomenclatura_sec, 'X') <> COALESCE(B.nomenclatura_sec, 'X')
    AND COALESCE(A.nivel_sec, 0) = COALESCE(B.nivel_sec, 0)

  UNION ALL

  -- Caso 2: ≠ nomenclatura primaria, misma secundaria, mismo nivel primario
  SELECT A.*
  FROM bdm_tempo.stg_regla2_e04_a A
  JOIN bdm_tempo.stg_regla2_e04_a B
    ON  A.id_buro_persona          = B.id_buro_persona
    AND A.texto_ubicacion           = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
    AND A.cod_dw_municipio          = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
    AND A.complemento              <> B.complemento
    AND (A.complemento2 LIKE '%' || B.complemento2 || '%'
         OR B.complemento2 LIKE '%' || A.complemento2 || '%')
    AND A.nomenclatura_pri <> B.nomenclatura_pri
    AND COALESCE(A.nomenclatura_sec, 'X') = COALESCE(B.nomenclatura_sec, 'X')
    AND A.nivel_pri = B.nivel_pri
) sub;

ANALYZE bdm_tempo.stg_regla2_e04_c;

-- PASO 4: Sumar frecuencias del DICCIONARIO_COMPLEMENTOS por persona/ubicación
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_c1;
CREATE TABLE bdm_tempo.stg_regla2_e04_c1
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT
  t1.cod_dw_persona_ubic,
  COALESCE(t2.conteo, 0) AS conteo
FROM bdm_tempo.stg_regla2_e04_c t1
LEFT JOIN (
  SELECT t1.cod_dw_persona_ubic, SUM(dc.frecuencia) AS conteo
  FROM bdm_tempo.stg_regla2_e04_c t1
  LEFT JOIN bdm_datos.diccionario_complementos dc
    ON  t1.cod_dw_ubic = dc.cod_dw_ubic
    AND t1.complemento LIKE '%' || dc.nomenclatura || '%'
    AND t1.id_buro_persona = dc.id_buro_persona
  GROUP BY 1
) t2 ON t1.cod_dw_persona_ubic = t2.cod_dw_persona_ubic;

ANALYZE bdm_tempo.stg_regla2_e04_c1;

-- PASO 5: Calcular score y detectar empates
-- Score = (frecuencia_diccionario + 10000000) + fecha_como_entero
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_d;
CREATE TABLE bdm_tempo.stg_regla2_e04_d
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  u1.*,
  COUNT(*) OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id
  ) AS count_empate,
  MAX(id) OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio
  ) AS idmax,
  CASE
    WHEN COUNT(*) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id) > 1
         AND MAX(id) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio) > id
    THEN 1
    WHEN COUNT(*) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id) = 1
    THEN 1
    ELSE 0
  END AS empate
FROM (
  SELECT
    a.cod_dw_persona_ubic,
    (COALESCE(b.conteo, 0) + 10000000)
      + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0) AS id,
    a.texto_ubicacion,
    a.fecha_relacion_persona_ubicaci,
    a.numero_entidades_reportan,
    a.id_buro_persona,
    a.cod_dw_tipo_ubicacion_dir,
    a.cod_dw_municipio,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
      ORDER BY (COALESCE(b.conteo, 0) + 10000000)
        + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0)
    ) AS orden,
    a.cod_dw_ubic,
    a.complemento
  FROM bdm_tempo.stg_regla2_e04_c a
  LEFT JOIN bdm_tempo.stg_regla2_e04_c1 b
    ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
) u1;

ANALYZE bdm_tempo.stg_regla2_e04_d;

-- PASO 6: Generar pares padre-hijo (mayor score = padre)
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_e;
CREATE TABLE bdm_tempo.stg_regla2_e04_e
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT
  B.cod_dw_persona_ubic,
  A.cod_dw_persona_ubic AS id_padre
FROM bdm_tempo.stg_regla2_e04_d A
JOIN bdm_tempo.stg_regla2_e04_d B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.id > B.id
JOIN (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio,
         MAX(orden) AS max_orden
  FROM bdm_tempo.stg_regla2_e04_d
  GROUP BY 1,2,3,4
) mx
  ON  A.id_buro_persona          = mx.id_buro_persona
  AND A.texto_ubicacion           = mx.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = mx.cod_dw_municipio
  AND A.orden = mx.max_orden;

ANALYZE bdm_tempo.stg_regla2_e04_e;

-- PASO 7: Actualizar tabla E2 acumulada con pares del Escenario 4
UPDATE bdm_tempo.stg_regla2_e2
SET id_padre = e.id_padre,
    ind_unificacion = 'S',
    n_id = 'B5'
FROM bdm_tempo.stg_regla2_e04_e e
WHERE bdm_tempo.stg_regla2_e2.cod_dw_persona_ubic = e.cod_dw_persona_ubic
  AND bdm_tempo.stg_regla2_e2.id_padre IS NULL;

-- PASO 8: Persistir pares en tabla de unificación
INSERT INTO bdm_datos.unificacion_direccion
SELECT DISTINCT
  e.cod_dw_persona_ubic,
  e.id_padre AS cod_dw_direccion_unificada,
  2 AS unifica_atributos,
  CURRENT_DATE AS fecha_unificacion,
  1 AS lote,
  1 AS severidad,
  LEFT(CURRENT_USER, 30) AS usuario_bd
FROM bdm_tempo.stg_regla2_e04_e e;

-- PASO 9: Marcar hijos
UPDATE bdm_datos.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_tempo.stg_regla2_e04_e
);

-- PASO 10: Estadísticas
ANALYZE bdm_datos.unificacion_direccion;
ANALYZE bdm_datos.relacion_persona_ubicacion;

-- PASO 11: Limpiar staging del escenario 4
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_a;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_c;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_c1;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_d;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_e;
