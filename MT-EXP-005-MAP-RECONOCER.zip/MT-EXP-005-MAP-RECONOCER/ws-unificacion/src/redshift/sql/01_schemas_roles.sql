-- ============================================================
-- 01_schemas_roles.sql
-- Schemas y tablas permanentes para Unificación de Direcciones
-- Ambiente: bdm_datos (permanente), bdm_tempo (staging)
-- ============================================================

-- Schemas (ya existen en el ambiente del cliente, pero idempotente)
CREATE SCHEMA IF NOT EXISTS bdm_datos;
CREATE SCHEMA IF NOT EXISTS bdm_tempo;

-- ===========================================
-- TABLAS PERMANENTES (bdm_datos)
-- ===========================================

CREATE TABLE IF NOT EXISTS bdm_datos.ubicacion_estandarizada (
  cod_dw_ubic           BIGINT       ENCODE AZ64,
  texto_ubicacion       VARCHAR(200) ENCODE ZSTD,
  cod_dw_ciudad         INTEGER      ENCODE AZ64,
  cod_dw_tipo_ubicacion INTEGER      ENCODE AZ64,
  latitud               DECIMAL(10,6) ENCODE AZ64,
  longitud              DECIMAL(10,6) ENCODE AZ64
)
DISTSTYLE KEY DISTKEY(cod_dw_ubic)
SORTKEY(cod_dw_ubic);

CREATE TABLE IF NOT EXISTS bdm_datos.direccion_fisica (
  cod_dw_direccion_fisica BIGINT       ENCODE AZ64,
  complemento             VARCHAR(100) ENCODE ZSTD,
  tipo_via_principal      VARCHAR(20)  ENCODE ZSTD,
  via_principal           VARCHAR(100) ENCODE ZSTD,
  via_generadora          INTEGER      ENCODE AZ64,
  numero_puerta           INTEGER      ENCODE AZ64,
  cod_dw_ubic             BIGINT       ENCODE AZ64,
  generada_enriquecida    INTEGER      ENCODE AZ64 DEFAULT 0
)
DISTSTYLE KEY DISTKEY(cod_dw_ubic)
SORTKEY(cod_dw_direccion_fisica);

CREATE TABLE IF NOT EXISTS bdm_datos.relacion_persona_ubicacion (
  cod_dw_persona_ubic              BIGINT  ENCODE AZ64,
  id_buro_persona                  INTEGER ENCODE AZ64,
  cod_pin_persona                  INTEGER ENCODE AZ64,
  cod_dw_ubic                      BIGINT  ENCODE AZ64,
  cod_dw_direccion_fisica          BIGINT  ENCODE AZ64,
  cod_dw_tipo_ubicacion_dir        INTEGER ENCODE AZ64,
  ind_unificacion                  INTEGER ENCODE AZ64,
  orden_prioridad                  INTEGER ENCODE AZ64,
  fecha_relacion_persona_ubicaci   DATE    ENCODE AZ64,
  lote                             INTEGER ENCODE AZ64,
  cod_tipo_ident_fte               INTEGER ENCODE AZ64,
  bloqueado                        SMALLINT ENCODE AZ64 DEFAULT 0  -- 0=activo, 1=bloqueado (fraude/reclamación)
)
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, cod_dw_persona_ubic);

CREATE TABLE IF NOT EXISTS bdm_datos.tipo_ubicacion_dir (
  cod_dw_tipo_ubicacion_dir        INTEGER     ENCODE AZ64,
  descripcion_tipo_ubicacion_dir   VARCHAR(20) ENCODE BYTEDICT
)
DISTSTYLE ALL;

CREATE TABLE IF NOT EXISTS bdm_datos.ciiu_persona (
  id_buro_persona        INTEGER     ENCODE AZ64,
  cod_act_econo_ciiu_fte VARCHAR(10) ENCODE BYTEDICT
)
DISTSTYLE KEY DISTKEY(id_buro_persona);

CREATE TABLE IF NOT EXISTS bdm_datos.reporte_relacion_persona_ubica (
  cod_dw_persona_ubic  BIGINT  ENCODE AZ64,
  id_buro_suscriptor   INTEGER ENCODE AZ64,
  fecha_reporte        DATE    ENCODE AZ64
)
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
SORTKEY(cod_dw_persona_ubic);

CREATE TABLE IF NOT EXISTS bdm_datos.nomenclatura (
  nomenclatura       VARCHAR(10) ENCODE ZSTD,
  nivel_complemento  INTEGER     ENCODE AZ64
)
DISTSTYLE ALL;

CREATE TABLE IF NOT EXISTS bdm_datos.unificacion_direccion (
  cod_dw_persona_ubic        BIGINT      ENCODE AZ64,
  cod_dw_direccion_unificada BIGINT      ENCODE AZ64,
  unifica_atributos          INTEGER     ENCODE AZ64,
  fecha_unificacion          DATE        ENCODE AZ64,
  lote                       INTEGER     ENCODE AZ64,
  severidad                  SMALLINT    ENCODE AZ64,
  usuario_bd                 VARCHAR(100) ENCODE ZSTD
)
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
SORTKEY(cod_dw_persona_ubic);

CREATE TABLE IF NOT EXISTS bdm_datos.diccionario_complementos (
  cod_dw_ubic      BIGINT      ENCODE AZ64,
  id_buro_persona  INTEGER     ENCODE AZ64,
  nomenclatura     VARCHAR(50) ENCODE ZSTD,
  nomen            VARCHAR(10) ENCODE ZSTD,
  valor            VARCHAR(50) ENCODE ZSTD,
  frecuencia       INTEGER     ENCODE AZ64
)
DISTSTYLE KEY DISTKEY(cod_dw_ubic)
SORTKEY(cod_dw_ubic, id_buro_persona);

CREATE TABLE IF NOT EXISTS bdm_datos.diccionario_via (
  tipo             VARCHAR(20)  ENCODE ZSTD,
  llave            VARCHAR(100) ENCODE ZSTD,
  via_generadora   INTEGER      ENCODE AZ64,
  cod_dw_municipio INTEGER      ENCODE AZ64,
  conteo           INTEGER      ENCODE AZ64
)
DISTSTYLE ALL;

ANALYZE bdm_datos.tipo_ubicacion_dir;
ANALYZE bdm_datos.nomenclatura;
ANALYZE bdm_datos.diccionario_complementos;
