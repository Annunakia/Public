-- ============================================================
-- 06_motor_nuevas_direcciones.sql
-- Motor reutilizable de generación de nuevas direcciones
-- Reemplaza PRO_Unifi_MOTOR_TMP.sql (870 líneas SQL dinámico + cursor)
-- Fuente Teradata: PRO_Unifi_MOTOR_TMP.sql
-- ============================================================
-- Prerequisito: stg_motor_input debe existir en bdm_tempo con columnas:
--   cod_dw_persona_ubic, cod_dw_ubic, complemento,
--   id_buro_persona, cod_dw_tipo_ubicacion_dir,
--   cod_pin_persona, cod_dw_direccion_fisica, texto_ubicacion,
--   fecha_relacion_persona_ubicaci
--
-- Cada escenario que invoca este motor es responsable de:
--   1. Crear bdm_tempo.stg_motor_input con los pares candidatos
--   2. Ejecutar este script (los 12 pasos)
--   3. Leer bdm_tempo.stg_motor_resultado para post-procesamiento
--
-- Diseño: design.md del spec motor-tmp
-- ============================================================

-- ============================================================
-- PASO 1: Descomponer complementos en nomenclaturas individuales
-- Cada fila = 1 nomenclatura de 1 dirección
-- JOIN con DICCIONARIO_COMPLEMENTOS por LIKE con separadores
-- ============================================================
DROP TABLE IF EXISTS bdm_tempo.stg_motor_descomp;
CREATE TABLE bdm_tempo.stg_motor_descomp
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  sub.*,
  ROW_NUMBER() OVER (PARTITION BY sub.cod_dw_persona_ubic
    ORDER BY sub.nivel_complemento DESC) AS id_com,
  ROW_NUMBER() OVER (PARTITION BY sub.cod_dw_persona_ubic
    ORDER BY sub.nivel_complemento ASC) AS id_com1
FROM (
  SELECT
    tu.cod_dw_persona_ubic,
    tu.cod_dw_ubic,
    tu.id_buro_persona,
    tu.cod_dw_tipo_ubicacion_dir,
    dc.nomenclatura,
    dc.nomen,
    dc.valor AS valor_original,
    CASE WHEN dc.valor ~ '^[0-9]+$' THEN CAST(dc.valor AS BIGINT) ELSE 0 END AS valor_num,
    COALESCE(nom.nivel_complemento, 99) AS nivel_complemento,
    COUNT(*) AS cantidad
  FROM bdm_tempo.stg_motor_input tu
  JOIN bdm_datos.diccionario_complementos dc
    ON tu.complemento LIKE '%' || dc.nomenclatura || '%'
    AND tu.cod_dw_ubic = dc.cod_dw_ubic
    AND tu.id_buro_persona = dc.id_buro_persona
  LEFT JOIN bdm_datos.nomenclatura nom
    ON nom.nomenclatura = dc.nomen
  GROUP BY 1,2,3,4,5,6,7,8,9
) sub;

ANALYZE bdm_tempo.stg_motor_descomp;

-- ============================================================
-- PASO 2: Agrupar nomenclaturas por dirección
-- NOM_AGRUP = concatenación de abreviaturas (ej: "TO|AP")
-- ============================================================
DROP TABLE IF EXISTS bdm_tempo.stg_motor_agrup;
CREATE TABLE bdm_tempo.stg_motor_agrup
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT
  cod_dw_persona_ubic,
  LISTAGG(nomen, '|') WITHIN GROUP (ORDER BY id_com) AS nom_agrup,
  SUM(cantidad) AS cantidad
FROM bdm_tempo.stg_motor_descomp
GROUP BY 1;

ANALYZE bdm_tempo.stg_motor_agrup;

-- ============================================================
-- PASO 3: Calcular MDIR (jerarquía de dirección)
-- String ordenable: nivel(3 chars) + valor(6 chars) por nomenclatura
-- MDIR=1 = padre (mayor jerarquía), MDIR>1 = hijos
-- ============================================================
DROP TABLE IF EXISTS bdm_tempo.stg_motor_mdir;
CREATE TABLE bdm_tempo.stg_motor_mdir
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  sub.cod_dw_persona_ubic,
  sub.cod_dw_ubic,
  sub.id_buro_persona,
  sub.cod_dw_tipo_ubicacion_dir,
  sub.mdir_key,
  ROW_NUMBER() OVER (
    PARTITION BY sub.cod_dw_ubic, sub.id_buro_persona, sub.cod_dw_tipo_ubicacion_dir
    ORDER BY sub.mdir_key, sub.cod_dw_persona_ubic ASC
  ) AS mdir
FROM (
  SELECT
    cod_dw_persona_ubic,
    cod_dw_ubic,
    id_buro_persona,
    cod_dw_tipo_ubicacion_dir,
    RPAD(
      LISTAGG(
        LPAD(CAST(nivel_complemento AS VARCHAR), 3, '0')
        || LPAD(CAST(CASE WHEN valor_num > 999999 THEN 999999 ELSE valor_num END AS VARCHAR), 6, '0'),
        ''
      ) WITHIN GROUP (ORDER BY id_com1),
      54, '099999999'
    ) AS mdir_key
  FROM bdm_tempo.stg_motor_descomp
  GROUP BY 1,2,3,4
) sub;

ANALYZE bdm_tempo.stg_motor_mdir;

-- ============================================================
-- PASO 4: Identificar padre (MDIR=1) e hijo (MDIR>1)
-- ============================================================
DROP TABLE IF EXISTS bdm_tempo.stg_motor_padre;
CREATE TABLE bdm_tempo.stg_motor_padre
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  m.cod_dw_persona_ubic,
  m.cod_dw_ubic,
  m.id_buro_persona,
  m.cod_dw_tipo_ubicacion_dir,
  tu.complemento,
  tu.cod_pin_persona,
  tu.cod_dw_direccion_fisica,
  tu.texto_ubicacion,
  tu.fecha_relacion_persona_ubicaci,
  a.nom_agrup,
  a.cantidad
FROM bdm_tempo.stg_motor_mdir m
JOIN bdm_tempo.stg_motor_input tu
  ON m.cod_dw_persona_ubic = tu.cod_dw_persona_ubic
JOIN bdm_tempo.stg_motor_agrup a
  ON m.cod_dw_persona_ubic = a.cod_dw_persona_ubic
WHERE m.mdir = 1;

ANALYZE bdm_tempo.stg_motor_padre;

DROP TABLE IF EXISTS bdm_tempo.stg_motor_hijo;
CREATE TABLE bdm_tempo.stg_motor_hijo
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  m.cod_dw_persona_ubic,
  m.cod_dw_ubic,
  m.id_buro_persona,
  m.cod_dw_tipo_ubicacion_dir,
  tu.complemento,
  m.mdir,
  a.nom_agrup,
  a.cantidad
FROM bdm_tempo.stg_motor_mdir m
JOIN bdm_tempo.stg_motor_input tu
  ON m.cod_dw_persona_ubic = tu.cod_dw_persona_ubic
JOIN bdm_tempo.stg_motor_agrup a
  ON m.cod_dw_persona_ubic = a.cod_dw_persona_ubic
WHERE m.mdir > 1;

ANALYZE bdm_tempo.stg_motor_hijo;

-- ============================================================
-- PASO 5: Nomenclaturas del hijo que NO están en el padre
-- Reemplaza cursor + columnas dinámicas C1..CN + código binario
-- ============================================================
DROP TABLE IF EXISTS bdm_tempo.stg_motor_diff;
CREATE TABLE bdm_tempo.stg_motor_diff
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic_hijo)
AS
SELECT
  h_nom.cod_dw_persona_ubic AS cod_dw_persona_ubic_hijo,
  p.cod_dw_persona_ubic AS cod_dw_persona_ubic_padre,
  h_nom.nomenclatura,
  h_nom.nomen,
  h_nom.valor_original,
  h_nom.id_com
FROM bdm_tempo.stg_motor_descomp h_nom
JOIN bdm_tempo.stg_motor_hijo h
  ON h_nom.cod_dw_persona_ubic = h.cod_dw_persona_ubic
JOIN bdm_tempo.stg_motor_padre p
  ON h.cod_dw_ubic = p.cod_dw_ubic
  AND h.id_buro_persona = p.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = p.cod_dw_tipo_ubicacion_dir
LEFT JOIN bdm_tempo.stg_motor_descomp p_nom
  ON p.cod_dw_persona_ubic = p_nom.cod_dw_persona_ubic
  AND h_nom.nomen = p_nom.nomen
  AND TRIM(h_nom.valor_original) = TRIM(p_nom.valor_original)
WHERE p_nom.cod_dw_persona_ubic IS NULL
  AND h.complemento <> p.complemento;

ANALYZE bdm_tempo.stg_motor_diff;

-- ============================================================
-- PASO 6: Concatenar diferencias → nueva nomenclatura por par
-- ============================================================
DROP TABLE IF EXISTS bdm_tempo.stg_motor_codigo;
CREATE TABLE bdm_tempo.stg_motor_codigo
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic_padre)
AS
SELECT
  cod_dw_persona_ubic_padre,
  cod_dw_persona_ubic_hijo,
  LISTAGG(nomenclatura, ' ') WITHIN GROUP (ORDER BY id_com) AS nueva_nomenclatura
FROM bdm_tempo.stg_motor_diff
GROUP BY 1,2;

ANALYZE bdm_tempo.stg_motor_codigo;

-- ============================================================
-- PASO 7: Construir nueva dirección completa
-- complemento_padre + nuevas nomenclaturas de todos los hijos
-- ============================================================
DROP TABLE IF EXISTS bdm_tempo.stg_motor_resultado;
CREATE TABLE bdm_tempo.stg_motor_resultado
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  p.cod_dw_persona_ubic AS cod_dw_persona_ubic_padre,
  p.complemento AS complemento_padre,
  p.cod_dw_ubic,
  p.id_buro_persona,
  p.cod_dw_tipo_ubicacion_dir,
  p.cod_pin_persona,
  p.texto_ubicacion,
  p.fecha_relacion_persona_ubicaci,
  LEFT(
    TRIM(p.complemento) || ' ' || TRIM(LISTAGG(c.nueva_nomenclatura, ' ')
      WITHIN GROUP (ORDER BY h.mdir)),
    100
  ) AS nuevo_complemento,
  LISTAGG(CAST(c.cod_dw_persona_ubic_hijo AS VARCHAR), ',')
    WITHIN GROUP (ORDER BY h.mdir) AS hijos_ids
FROM bdm_tempo.stg_motor_padre p
JOIN bdm_tempo.stg_motor_codigo c
  ON p.cod_dw_persona_ubic = c.cod_dw_persona_ubic_padre
JOIN bdm_tempo.stg_motor_hijo h
  ON c.cod_dw_persona_ubic_hijo = h.cod_dw_persona_ubic
GROUP BY 1,2,3,4,5,6,7,8;

ANALYZE bdm_tempo.stg_motor_resultado;

-- ============================================================
-- PASO 8: Verificar existencia y generar IDs
-- Si la dirección combinada ya existe → reusar ID
-- Si no → MAX(id) + ROW_NUMBER() (sandbox; producción usa tabla de secuencias)
-- ============================================================
DROP TABLE IF EXISTS bdm_tempo.stg_motor_max_ids;
CREATE TABLE bdm_tempo.stg_motor_max_ids AS
SELECT
  COALESCE((SELECT MAX(cod_dw_direccion_fisica) FROM bdm_datos.direccion_fisica), 0) AS max_df,
  COALESCE((SELECT MAX(cod_dw_persona_ubic) FROM bdm_datos.relacion_persona_ubicacion), 0) AS max_rpu;

DROP TABLE IF EXISTS bdm_tempo.stg_motor_final;
CREATE TABLE bdm_tempo.stg_motor_final
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  r.*,
  CASE WHEN df.cod_dw_direccion_fisica IS NOT NULL
    THEN df.cod_dw_direccion_fisica
    ELSE mx.max_df + ROW_NUMBER() OVER (
      PARTITION BY CASE WHEN df.cod_dw_direccion_fisica IS NULL THEN 1 ELSE 0 END
      ORDER BY r.cod_dw_persona_ubic_padre
    )
  END AS new_cod_dw_direccion_fisica,
  CASE WHEN df.cod_dw_direccion_fisica IS NULL THEN 1 ELSE 0 END AS es_nueva_df,
  mx.max_rpu + ROW_NUMBER() OVER (ORDER BY r.cod_dw_persona_ubic_padre) AS new_cod_dw_persona_ubic
FROM bdm_tempo.stg_motor_resultado r
CROSS JOIN bdm_tempo.stg_motor_max_ids mx
LEFT JOIN bdm_datos.direccion_fisica df
  ON df.cod_dw_ubic = r.cod_dw_ubic
  AND TRIM(df.complemento) = TRIM(r.nuevo_complemento);

ANALYZE bdm_tempo.stg_motor_final;

-- ============================================================
-- PASO 9: INSERT en DIRECCION_FISICA (solo nuevas)
-- Generada_Enriquecida=1 marca que fue generada por el motor
-- ============================================================
INSERT INTO bdm_datos.direccion_fisica (
  cod_dw_direccion_fisica, complemento, cod_dw_ubic, generada_enriquecida
)
SELECT DISTINCT
  new_cod_dw_direccion_fisica,
  nuevo_complemento,
  cod_dw_ubic,
  1
FROM bdm_tempo.stg_motor_final
WHERE es_nueva_df = 1;

-- ============================================================
-- PASO 10: INSERT en RELACION_PERSONA_UBICACION (nueva relación padre)
-- ============================================================
INSERT INTO bdm_datos.relacion_persona_ubicacion (
  cod_dw_persona_ubic,
  id_buro_persona,
  cod_pin_persona,
  cod_dw_ubic,
  cod_dw_direccion_fisica,
  cod_dw_tipo_ubicacion_dir,
  ind_unificacion,
  fecha_relacion_persona_ubicaci,
  lote
)
SELECT
  new_cod_dw_persona_ubic,
  id_buro_persona,
  cod_pin_persona,
  cod_dw_ubic,
  new_cod_dw_direccion_fisica,
  cod_dw_tipo_ubicacion_dir,
  NULL,
  CURRENT_DATE,
  1
FROM bdm_tempo.stg_motor_final;

-- ============================================================
-- PASO 11: INSERT en UNIFICACION_DIRECCION (pares padre-hijo)
-- Cada hijo original apunta al nuevo cod_dw_persona_ubic del padre generado
-- En escenarios con motor, el padre MDIR original TAMBIÉN es hijo del nuevo padre
-- ============================================================
INSERT INTO bdm_datos.unificacion_direccion (
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  unifica_atributos,
  fecha_unificacion,
  lote,
  severidad,
  usuario_bd
)
SELECT
  h.cod_dw_persona_ubic,
  f.new_cod_dw_persona_ubic,
  2,
  CURRENT_DATE,
  1,
  1,
  LEFT(CURRENT_USER, 30)
FROM bdm_tempo.stg_motor_final f
JOIN bdm_tempo.stg_motor_hijo h
  ON h.cod_dw_ubic = f.cod_dw_ubic
  AND h.id_buro_persona = f.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = f.cod_dw_tipo_ubicacion_dir;

-- Padre MDIR original también es hijo del nuevo padre generado
INSERT INTO bdm_datos.unificacion_direccion (
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  unifica_atributos,
  fecha_unificacion,
  lote,
  severidad,
  usuario_bd
)
SELECT
  f.cod_dw_persona_ubic_padre,
  f.new_cod_dw_persona_ubic,
  2,
  CURRENT_DATE,
  1,
  1,
  LEFT(CURRENT_USER, 30)
FROM bdm_tempo.stg_motor_final f;

-- ============================================================
-- PASO 12: UPDATE Ind_Unificacion=1 en TODAS las originales (hijos + padre MDIR)
-- ============================================================
UPDATE bdm_datos.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_tempo.stg_motor_hijo
  UNION ALL
  SELECT cod_dw_persona_ubic FROM bdm_tempo.stg_motor_padre
);

-- ============================================================
-- PASO 13: ANALYZE en todas las tablas modificadas
-- ============================================================
ANALYZE bdm_datos.direccion_fisica;
ANALYZE bdm_datos.relacion_persona_ubicacion;
ANALYZE bdm_datos.unificacion_direccion;

-- ============================================================
-- Limpieza de tablas staging del motor
-- ============================================================
DROP TABLE IF EXISTS bdm_tempo.stg_motor_max_ids;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_descomp;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_agrup;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_mdir;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_padre;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_hijo;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_diff;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_codigo;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_resultado;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_final;
-- Nota: stg_motor_input NO se borra aquí — lo borra el script que invoca al motor
