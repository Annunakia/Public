-- ============================================================
-- 07_regla2_esc3_nit.sql
-- Regla 2 Escenario 3 Caso NIT: Misma nomenclatura, diferente valor
-- → Invoca motor de nuevas direcciones (06_motor)
-- Fuente Teradata: PRO_UnificacionR2.sql líneas 630-1834
-- ============================================================
-- Prerequisito: 05_regla2_esc3_sin_nit.sql ejecutado
--
-- Lógica:
--   1. Filtrar no-unificados que SÍ son NIT (cod_tipo_ident_fte = 3)
--   2. Encontrar pares con misma nomenclatura pero diferente valor
--   3. Preparar stg_motor_input con esos pares
--   4. Ejecutar motor (06_motor_nuevas_direcciones.sql)
--   5. Actualizar stg_regla2_e2 con nuevos pares + nueva dirección
--
-- Dato mock: P07 (NIT, CL 10 20 30, "LC 101" y "LC 205")
--   → Motor genera nueva dirección "LC 101 LC 205"
-- ============================================================

-- PASO 1: Filtrar no-unificados que SÍ son NIT
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e031;
CREATE TABLE bdm_tempo.stg_regla2_e031
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT a.*
FROM bdm_tempo.stg_regla2_e2 a
JOIN bdm_datos.relacion_persona_ubicacion rpu
  ON a.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE a.ind_unificacion = 'N'
  AND rpu.cod_tipo_ident_fte = 3;

ANALYZE bdm_tempo.stg_regla2_e031;

-- PASO 2: Encontrar pares con misma nomenclatura, diferente valor
-- Estos son los candidatos que el motor va a combinar
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03_nit_pares;
CREATE TABLE bdm_tempo.stg_regla2_e03_nit_pares
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT a.cod_dw_persona_ubic
FROM bdm_tempo.stg_regla2_e031 a
JOIN bdm_tempo.stg_regla2_e031 b
  ON  a.id_buro_persona          = b.id_buro_persona
  AND a.texto_ubicacion           = b.texto_ubicacion
  AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
  AND a.cod_dw_municipio          = b.cod_dw_municipio
  AND a.cod_dw_persona_ubic      <> b.cod_dw_persona_ubic
  AND a.complemento              <> b.complemento
JOIN bdm_datos.nomenclatura nmc1
  ON a.complemento LIKE nmc1.nomenclatura || '%'
JOIN bdm_datos.nomenclatura nmc2
  ON b.complemento LIKE nmc2.nomenclatura || '%'
WHERE nmc1.nomenclatura = nmc2.nomenclatura;

ANALYZE bdm_tempo.stg_regla2_e03_nit_pares;

-- PASO 3: Preparar stg_motor_input (contrato del motor)
DROP TABLE IF EXISTS bdm_tempo.stg_motor_input;
CREATE TABLE bdm_tempo.stg_motor_input
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  e.cod_dw_persona_ubic,
  e.cod_dw_ubic,
  e.complemento,
  e.id_buro_persona,
  e.cod_dw_tipo_ubicacion_dir,
  rpu.cod_pin_persona,
  rpu.cod_dw_direccion_fisica,
  e.texto_ubicacion,
  e.fecha_relacion_persona_ubicaci
FROM bdm_tempo.stg_regla2_e031 e
JOIN bdm_tempo.stg_regla2_e03_nit_pares p
  ON e.cod_dw_persona_ubic = p.cod_dw_persona_ubic
JOIN bdm_datos.relacion_persona_ubicacion rpu
  ON e.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

ANALYZE bdm_tempo.stg_motor_input;

-- ============================================================
-- PASO 4: EJECUTAR MOTOR (06_motor_nuevas_direcciones.sql)
-- El motor lee stg_motor_input y:
--   - Genera nueva dirección en DIRECCION_FISICA
--   - Crea relación en RELACION_PERSONA_UBICACION
--   - Inserta pares en UNIFICACION_DIRECCION
--   - Marca hijos con ind_unificacion=1
-- Después del motor, stg_motor_final tiene los resultados
-- ============================================================

-- >>> INCLUIR AQUÍ EL CONTENIDO DE 06_motor_nuevas_direcciones.sql <<<
-- En producción se ejecuta como script separado via orquestador.
-- En sandbox, copiar/pegar el contenido del 06.

-- ============================================================
-- PASO 5: Actualizar stg_regla2_e2 con los hijos NIT
-- N_ID = 'X4' para hijos NIT procesados por el motor
-- Nota: en escenarios con motor, AMBOS originales (padre MDIR + hijo MDIR)
-- son hijos del nuevo padre generado
-- ============================================================
UPDATE bdm_tempo.stg_regla2_e2
SET ind_unificacion = 'S',
    n_id = 'X4',
    id_padre = f.new_cod_dw_persona_ubic
FROM bdm_tempo.stg_motor_final f
JOIN bdm_tempo.stg_motor_hijo h
  ON h.cod_dw_ubic = f.cod_dw_ubic
  AND h.id_buro_persona = f.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = f.cod_dw_tipo_ubicacion_dir
WHERE bdm_tempo.stg_regla2_e2.cod_dw_persona_ubic = h.cod_dw_persona_ubic
  AND bdm_tempo.stg_regla2_e2.ind_unificacion = 'N';

-- Padre MDIR original también es hijo del nuevo padre generado
UPDATE bdm_tempo.stg_regla2_e2
SET ind_unificacion = 'S',
    n_id = 'X4',
    id_padre = f.new_cod_dw_persona_ubic
FROM bdm_tempo.stg_motor_final f
WHERE bdm_tempo.stg_regla2_e2.cod_dw_persona_ubic = f.cod_dw_persona_ubic_padre
  AND bdm_tempo.stg_regla2_e2.ind_unificacion = 'N';

-- PASO 6: Insertar nueva dirección generada en E2 (para que escenarios posteriores la vean)
INSERT INTO bdm_tempo.stg_regla2_e2 (
  cod_dw_persona_ubic, id_padre, id_buro_persona,
  cod_dw_tipo_ubicacion_dir, cod_dw_ubic, texto_ubicacion,
  cod_dw_direccion_fisica, complemento,
  ind_unificacion, n_id
)
SELECT
  f.new_cod_dw_persona_ubic,
  NULL,
  f.id_buro_persona,
  f.cod_dw_tipo_ubicacion_dir,
  f.cod_dw_ubic,
  f.texto_ubicacion,
  f.new_cod_dw_direccion_fisica,
  f.nuevo_complemento,
  'N',
  NULL
FROM bdm_tempo.stg_motor_final f;

-- PASO 7: Estadísticas
ANALYZE bdm_tempo.stg_regla2_e2;

-- PASO 8: Limpiar staging del escenario
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e031;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03_nit_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_input;
