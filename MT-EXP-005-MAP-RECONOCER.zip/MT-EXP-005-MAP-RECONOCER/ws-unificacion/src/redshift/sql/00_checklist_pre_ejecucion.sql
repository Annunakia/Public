-- ============================================================
-- 00_checklist_pre_ejecucion.sql
-- CHECKLIST DE INSUMOS — Unificación de Direcciones Físicas
-- ============================================================
--
-- OBJETIVO:
-- Garantizar que sobre Redshift Experian se encuentren TODOS los
-- insumos necesarios (tablas, catálogos, datos, integridad) para
-- ejecutar la lógica migrada de Unificación.
--
-- DISEÑO:
-- Tolerante a tablas faltantes — nunca se revienta.
-- Primero valida existencia via information_schema, luego datos.
--
-- USO:
-- Ejecutar este script completo en Redshift Experian.
--   PASS = OK
--   FAIL = Bloqueante — NO ejecutar Unificación
--   WARN = No bloqueante
--
-- Fecha: 2026-04-24
-- ============================================================

-- =====================
-- 1. SCHEMAS
-- =====================
SELECT '1.1' AS check_id, 'SCHEMA' AS categoria,
  'bdm_datos existe' AS validacion,
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END AS estado,
  NULL AS detalle
FROM information_schema.schemata WHERE schema_name = 'bdm_datos'

UNION ALL
SELECT '1.2', 'SCHEMA', 'bdm_tempo existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.schemata WHERE schema_name = 'bdm_tempo'

-- =====================
-- 2. EXISTENCIA DE TABLAS
-- =====================

UNION ALL
SELECT '2.01', 'TABLA', 'ubicacion_estandarizada existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='ubicacion_estandarizada'

UNION ALL
SELECT '2.02', 'TABLA', 'direccion_fisica existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='direccion_fisica'

UNION ALL
SELECT '2.03', 'TABLA', 'relacion_persona_ubicacion existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='relacion_persona_ubicacion'

UNION ALL
SELECT '2.04', 'TABLA', 'reporte_relacion_persona_ubica existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='reporte_relacion_persona_ubica'

UNION ALL
SELECT '2.05', 'TABLA', 'ciiu_persona existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='ciiu_persona'

UNION ALL
SELECT '2.06', 'TABLA', 'tipo_ubicacion_dir existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='tipo_ubicacion_dir'

UNION ALL
SELECT '2.07', 'TABLA', 'nomenclatura existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='nomenclatura'

UNION ALL
SELECT '2.08', 'TABLA', 'diccionario_complementos existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='diccionario_complementos'

UNION ALL
SELECT '2.09', 'TABLA', 'diccionario_via existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS'
       ELSE 'WARN — solo requerida para Regla 3' END, NULL
FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='diccionario_via'

UNION ALL
SELECT '2.10', 'TABLA', 'unificacion_direccion existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='unificacion_direccion'

-- =====================
-- 3. COLUMNAS CRÍTICAS (¿la tabla tiene las columnas que esperamos?)
-- =====================

UNION ALL
SELECT '3.1', 'COLUMNA', 'relacion_persona_ubicacion.bloqueado existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.columns
WHERE table_schema='bdm_datos' AND table_name='relacion_persona_ubicacion' AND column_name='bloqueado'

UNION ALL
SELECT '3.2', 'COLUMNA', 'relacion_persona_ubicacion.cod_dw_persona_ubic existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.columns
WHERE table_schema='bdm_datos' AND table_name='relacion_persona_ubicacion' AND column_name='cod_dw_persona_ubic'

UNION ALL
SELECT '3.3', 'COLUMNA', 'relacion_persona_ubicacion.cod_dw_tipo_ubicacion_dir existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.columns
WHERE table_schema='bdm_datos' AND table_name='relacion_persona_ubicacion' AND column_name='cod_dw_tipo_ubicacion_dir'

UNION ALL
SELECT '3.4', 'COLUMNA', 'direccion_fisica.complemento existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.columns
WHERE table_schema='bdm_datos' AND table_name='direccion_fisica' AND column_name='complemento'

UNION ALL
SELECT '3.5', 'COLUMNA', 'ubicacion_estandarizada.latitud existe (Regla 3)',
  CASE WHEN COUNT(*) > 0 THEN 'PASS'
       ELSE 'WARN — solo requerida para Regla 3' END, NULL
FROM information_schema.columns
WHERE table_schema='bdm_datos' AND table_name='ubicacion_estandarizada' AND column_name='latitud'

ORDER BY check_id;

-- ============================================================
-- BLOQUE 2: VALIDACIÓN DE DATOS
-- Ejecutar DESPUÉS del bloque 1.
-- Solo valida tablas que existan. Si una tabla no existe,
-- el check se salta (no aparece en el resultado).
-- ============================================================

-- Tabla temporal para acumular resultados
CREATE TEMP TABLE IF NOT EXISTS _checklist_datos (
  check_id VARCHAR(10), categoria VARCHAR(20),
  validacion VARCHAR(200), estado VARCHAR(10), detalle VARCHAR(200)
);
TRUNCATE _checklist_datos;

-- Macro: cada bloque DO verifica existencia antes de consultar
-- =====================
-- 4. DATOS — Tablas de entrada tienen registros
-- =====================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='ubicacion_estandarizada') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''4.01'', ''DATOS'', ''ubicacion_estandarizada tiene registros'',
      CASE WHEN COUNT(*)>0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' registros''
      FROM bdm_datos.ubicacion_estandarizada';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='direccion_fisica') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''4.02'', ''DATOS'', ''direccion_fisica tiene registros'',
      CASE WHEN COUNT(*)>0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' registros''
      FROM bdm_datos.direccion_fisica';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='relacion_persona_ubicacion') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''4.03'', ''DATOS'', ''relacion_persona_ubicacion tiene registros'',
      CASE WHEN COUNT(*)>0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' registros''
      FROM bdm_datos.relacion_persona_ubicacion';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='reporte_relacion_persona_ubica') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''4.04'', ''DATOS'', ''reporte_relacion_persona_ubica tiene registros'',
      CASE WHEN COUNT(*)>0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' registros''
      FROM bdm_datos.reporte_relacion_persona_ubica';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='ciiu_persona') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''4.05'', ''DATOS'', ''ciiu_persona tiene registros'',
      CASE WHEN COUNT(*)>0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' registros''
      FROM bdm_datos.ciiu_persona';
  END IF;
END $$;

-- =====================
-- 5. DATOS — Catálogos tienen registros esperados
-- =====================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='tipo_ubicacion_dir') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''5.1'', ''CATALOGO'', ''tipo_ubicacion_dir (mín 3: RES,LAB,CRR)'',
      CASE WHEN COUNT(*)>=3 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' registros''
      FROM bdm_datos.tipo_ubicacion_dir';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='nomenclatura') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''5.2'', ''CATALOGO'', ''nomenclatura (esperado ~89)'',
      CASE WHEN COUNT(*)>=10 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' registros''
      FROM bdm_datos.nomenclatura';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='diccionario_complementos') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''5.3'', ''CATALOGO'', ''diccionario_complementos tiene registros'',
      CASE WHEN COUNT(*)>0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' registros''
      FROM bdm_datos.diccionario_complementos';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='diccionario_via') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''5.4'', ''CATALOGO'', ''diccionario_via (solo Regla 3)'',
      CASE WHEN COUNT(*)>0 THEN ''PASS'' ELSE ''WARN'' END, COUNT(*)::VARCHAR||'' registros''
      FROM bdm_datos.diccionario_via';
  END IF;
END $$;

-- =====================
-- 6. CALIDAD — NULLs en columnas críticas
-- =====================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='bdm_datos' AND table_name='ubicacion_estandarizada' AND column_name='cod_dw_ubic') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''6.1'', ''CALIDAD'', ''ubicacion_estandarizada.cod_dw_ubic NOT NULL'',
      CASE WHEN COUNT(*)=0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' NULLs''
      FROM bdm_datos.ubicacion_estandarizada WHERE cod_dw_ubic IS NULL';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='bdm_datos' AND table_name='relacion_persona_ubicacion' AND column_name='cod_dw_persona_ubic') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''6.2'', ''CALIDAD'', ''relacion_persona_ubicacion.cod_dw_persona_ubic NOT NULL'',
      CASE WHEN COUNT(*)=0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' NULLs''
      FROM bdm_datos.relacion_persona_ubicacion WHERE cod_dw_persona_ubic IS NULL';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='bdm_datos' AND table_name='relacion_persona_ubicacion' AND column_name='id_buro_persona') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''6.3'', ''CALIDAD'', ''relacion_persona_ubicacion.id_buro_persona NOT NULL'',
      CASE WHEN COUNT(*)=0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' NULLs''
      FROM bdm_datos.relacion_persona_ubicacion WHERE id_buro_persona IS NULL';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='bdm_datos' AND table_name='relacion_persona_ubicacion' AND column_name='bloqueado') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''6.4'', ''CALIDAD'', ''relacion_persona_ubicacion.bloqueado valores válidos (0 o 1)'',
      CASE WHEN COUNT(*)=0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' inválidos''
      FROM bdm_datos.relacion_persona_ubicacion WHERE bloqueado NOT IN (0,1) OR bloqueado IS NULL';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='bdm_datos' AND table_name='direccion_fisica' AND column_name='cod_dw_direccion_fisica') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''6.5'', ''CALIDAD'', ''direccion_fisica.cod_dw_direccion_fisica NOT NULL'',
      CASE WHEN COUNT(*)=0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' NULLs''
      FROM bdm_datos.direccion_fisica WHERE cod_dw_direccion_fisica IS NULL';
  END IF;
END $$;

-- =====================
-- 7. INTEGRIDAD REFERENCIAL
-- =====================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='relacion_persona_ubicacion')
     AND EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='ubicacion_estandarizada') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''7.1'', ''FK'', ''relacion_persona_ubicacion.cod_dw_ubic → ubicacion_estandarizada'',
      CASE WHEN COUNT(*)=0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' huérfanos''
      FROM bdm_datos.relacion_persona_ubicacion rpu
      LEFT JOIN bdm_datos.ubicacion_estandarizada ue ON rpu.cod_dw_ubic=ue.cod_dw_ubic
      WHERE ue.cod_dw_ubic IS NULL AND rpu.cod_dw_ubic IS NOT NULL';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='relacion_persona_ubicacion')
     AND EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='direccion_fisica') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''7.2'', ''FK'', ''relacion_persona_ubicacion.cod_dw_direccion_fisica → direccion_fisica'',
      CASE WHEN COUNT(*)=0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' huérfanos''
      FROM bdm_datos.relacion_persona_ubicacion rpu
      LEFT JOIN bdm_datos.direccion_fisica df ON rpu.cod_dw_direccion_fisica=df.cod_dw_direccion_fisica
      WHERE df.cod_dw_direccion_fisica IS NULL AND rpu.cod_dw_direccion_fisica IS NOT NULL';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='relacion_persona_ubicacion')
     AND EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='tipo_ubicacion_dir') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''7.3'', ''FK'', ''relacion_persona_ubicacion.cod_dw_tipo_ubicacion_dir → tipo_ubicacion_dir'',
      CASE WHEN COUNT(*)=0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' con tipo no catalogado''
      FROM bdm_datos.relacion_persona_ubicacion rpu
      LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir=tud.cod_dw_tipo_ubicacion_dir
      WHERE tud.cod_dw_tipo_ubicacion_dir IS NULL AND rpu.cod_dw_tipo_ubicacion_dir IS NOT NULL';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='diccionario_complementos')
     AND EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='nomenclatura') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''7.4'', ''FK'', ''diccionario_complementos.nomen → nomenclatura'',
      CASE WHEN COUNT(*)=0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' sin catálogo''
      FROM bdm_datos.diccionario_complementos dc
      LEFT JOIN bdm_datos.nomenclatura n ON dc.nomen=n.nomenclatura
      WHERE n.nomenclatura IS NULL AND dc.nomen IS NOT NULL';
  END IF;
END $$;

-- =====================
-- RESULTADO BLOQUE 2
-- =====================
SELECT * FROM _checklist_datos ORDER BY check_id;

DROP TABLE IF EXISTS _checklist_datos;
