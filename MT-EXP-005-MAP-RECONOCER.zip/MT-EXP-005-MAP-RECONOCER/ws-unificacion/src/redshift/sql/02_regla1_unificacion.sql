-- ============================================================
-- 02_regla1_unificacion.sql
-- Regla 1 de Unificación: Misma puerta + misma ciudad,
-- diferente tipo de uso. Escoge padre según CIIU.
-- Fuente Teradata: P0019_UNIFICACION_130.TPT
-- ============================================================
-- Escenarios:
--   Esc 1 (CIIU=10): Prefiere LAB/CRR, desempate por entidades
--   Esc 2 (CIIU=81/82/90): Prefiere RES/CRR, desempate por entidades
--   Esc 3 (otro CIIU): Mayor entidades, desempate por fecha
-- ============================================================

-- PASO 1: Materializar insumo en bdm_tempo (staging volátil)
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_insumo;
CREATE TABLE bdm_tempo.stg_regla1_insumo
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, texto_ubicacion)
AS
SELECT
  rpu.cod_dw_persona_ubic,
  rpu.id_buro_persona,
  ubi.texto_ubicacion,
  df.complemento,
  ubi.cod_dw_ciudad,
  rpu.cod_dw_tipo_ubicacion_dir,
  COALESCE(ciiu.cod_act_econo_ciiu_fte, '') AS cod_act_econo_ciiu_fte,
  COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor), 0) AS numero_entidades_reportan,
  tud.descripcion_tipo_ubicacion_dir AS tipo_direccion
FROM bdm_datos.relacion_persona_ubicacion rpu
JOIN bdm_datos.ubicacion_estandarizada ubi
  ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_datos.direccion_fisica df
  ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
JOIN bdm_datos.reporte_relacion_persona_ubica rep
  ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
LEFT JOIN bdm_datos.ciiu_persona ciiu
  ON rpu.id_buro_persona = ciiu.id_buro_persona
LEFT JOIN bdm_datos.tipo_ubicacion_dir tud
  ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
WHERE rpu.ind_unificacion IS NULL
GROUP BY 1,2,3,4,5,6,7,9;

ANALYZE bdm_tempo.stg_regla1_insumo;

-- PASO 2: Calcular score y ranking por escenario
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_scored;
CREATE TABLE bdm_tempo.stg_regla1_scored
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, texto_ubicacion)
AS
SELECT *,
  CASE
    WHEN cod_act_econo_ciiu_fte = '10' THEN 'ESC1'
    WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN 'ESC2'
    ELSE 'ESC3'
  END AS escenario,

  CASE
    WHEN cod_act_econo_ciiu_fte = '10' THEN
      CASE WHEN tipo_direccion IN ('LAB','CRR') THEN 100000 ELSE 0 END
      + numero_entidades_reportan
    WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN
      CASE WHEN tipo_direccion IN ('RES','CRR') THEN 100000 ELSE 0 END
      + numero_entidades_reportan
    ELSE
      numero_entidades_reportan
  END AS score,

  ROW_NUMBER() OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_ciudad,
      CASE
        WHEN cod_act_econo_ciiu_fte = '10' THEN 'ESC1'
        WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN 'ESC2'
        ELSE 'ESC3'
      END
    ORDER BY
      CASE
        WHEN cod_act_econo_ciiu_fte = '10' THEN
          CASE WHEN tipo_direccion IN ('LAB','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan
        WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN
          CASE WHEN tipo_direccion IN ('RES','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan
        ELSE numero_entidades_reportan
      END DESC
  ) AS orden
FROM bdm_tempo.stg_regla1_insumo;

ANALYZE bdm_tempo.stg_regla1_scored;

-- PASO 3: Generar pares padre-hijo
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_pares;
CREATE TABLE bdm_tempo.stg_regla1_pares
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT
  hijo.cod_dw_persona_ubic        AS cod_dw_persona_ubic,
  padre.cod_dw_persona_ubic       AS cod_dw_direccion_unificada
FROM bdm_tempo.stg_regla1_scored padre
JOIN bdm_tempo.stg_regla1_scored hijo
  ON padre.id_buro_persona = hijo.id_buro_persona
 AND padre.texto_ubicacion = hijo.texto_ubicacion
 AND padre.cod_dw_ciudad = hijo.cod_dw_ciudad
 AND padre.escenario = hijo.escenario
 AND padre.score > hijo.score
 AND padre.cod_dw_tipo_ubicacion_dir <> hijo.cod_dw_tipo_ubicacion_dir
WHERE padre.orden = 1;

-- PASO 4: Persistir resultado
INSERT INTO bdm_datos.unificacion_direccion
SELECT
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  1 AS unifica_atributos,
  CURRENT_DATE AS fecha_unificacion,
  1 AS lote,
  1 AS severidad,
  CURRENT_USER AS usuario_bd
FROM bdm_tempo.stg_regla1_pares;

-- PASO 5: Marcar hijos como unificados
UPDATE bdm_datos.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_tempo.stg_regla1_pares
);

-- PASO 6: Actualizar estadísticas de tablas modificadas
ANALYZE bdm_datos.unificacion_direccion;
ANALYZE bdm_datos.relacion_persona_ubicacion;

-- PASO 7: Limpiar staging (bdm_tempo es volátil)
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_insumo;
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_scored;
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_pares;
