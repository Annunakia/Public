# _legacy — Archivos SQL Legacy

Esta carpeta contiene versiones anteriores de scripts SQL que han sido reemplazados por el código actual en `../sql/`.

## Archivos

| Archivo | Descripción |
|---------|-------------|
| `00_setup_schema.sql` | Setup inicial del schema en Redshift (versión anterior) |
| `01_regla1_unificacion.sql` | Primera versión de la migración de Regla 1 (reemplazada por scripts en `../sql/`) |

## Propósito

Estos archivos se conservan como referencia histórica. **No deben ejecutarse en producción.** El código vigente se encuentra en la carpeta `../sql/`.
