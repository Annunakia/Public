-- ============================================================
-- 01_regla1_unificacion.sql
-- Migración de Regla 1 de Unificación: Teradata → Redshift
-- Fuente: P0019_UNIFICACION_111.TPT
-- ============================================================
-- Regla 1: Misma puerta + misma ciudad, diferente tipo de uso.
-- Escoge padre según CIIU:
--   Esc 1 (CIIU=10): Prefiere LAB/CRR, desempate por entidades
--   Esc 2 (CIIU=81/82/90): Prefiere RES/CRR, desempate por entidades
--   Esc 3 (otro CIIU): Mayor entidades, desempate por fecha
-- ============================================================

-- PASO 1: Materializar insumo (equivale a V_Insumo_Unificacion_Regla1)
DROP TABLE IF EXISTS rec_mock.stg_regla1_insumo;
CREATE TABLE rec_mock.stg_regla1_insumo AS
SELECT
  rpu.cod_dw_persona_ubic,
  rpu.id_buro_persona,
  ubi.texto_ubicacion,
  df.complemento,
  ubi.cod_dw_ciudad,
  rpu.cod_dw_tipo_ubicacion_dir,
  COALESCE(ciiu.cod_act_econo_ciiu_fte, '') AS cod_act_econo_ciiu_fte,
  COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor), 0) AS numero_entidades_reportan,
  tud.descripcion_tipo_ubicacion_dir AS tipo_direccion
FROM rec_mock.relacion_persona_ubicacion rpu
INNER JOIN rec_mock.ubicacion_estandarizada ubi
  ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN rec_mock.direccion_fisica df
  ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
INNER JOIN rec_mock.reporte_relacion_persona_ubica rep
  ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
LEFT JOIN rec_mock.ciiu_persona ciiu
  ON rpu.id_buro_persona = ciiu.id_buro_persona
LEFT JOIN rec_mock.tipo_ubicacion_dir tud
  ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
WHERE rpu.ind_unificacion IS NULL
GROUP BY 1,2,3,4,5,6,7,9;


-- PASO 2: Calcular score por escenario (equivale a stage2 en P0019_111)
DROP TABLE IF EXISTS rec_mock.stg_regla1_scored;
CREATE TABLE rec_mock.stg_regla1_scored AS
SELECT *,
  -- Asignar escenario
  CASE
    WHEN cod_act_econo_ciiu_fte = '10' THEN 'ESCENARIO1'
    WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN 'ESCENARIO2'
    ELSE 'ESCENARIO3'
  END AS escenario,

  -- Calcular score según escenario
  CASE
    WHEN cod_act_econo_ciiu_fte = '10' THEN
      CASE WHEN tipo_direccion IN ('LAB','CRR') THEN 100000 ELSE 0 END
      + numero_entidades_reportan

    WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN
      CASE WHEN tipo_direccion IN ('RES','CRR') THEN 100000 ELSE 0 END
      + numero_entidades_reportan

    ELSE
      numero_entidades_reportan
  END AS score,

  -- Rankear dentro de cada grupo (persona + puerta + ciudad + escenario)
  ROW_NUMBER() OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_ciudad,
      CASE
        WHEN cod_act_econo_ciiu_fte = '10' THEN 'ESCENARIO1'
        WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN 'ESCENARIO2'
        ELSE 'ESCENARIO3'
      END
    ORDER BY
      CASE
        WHEN cod_act_econo_ciiu_fte = '10' THEN
          CASE WHEN tipo_direccion IN ('LAB','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan
        WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN
          CASE WHEN tipo_direccion IN ('RES','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan
        ELSE numero_entidades_reportan
      END DESC
  ) AS orden

FROM rec_mock.stg_regla1_insumo;


-- PASO 3: Generar pares padre-hijo (equivale a stage3 en P0019_111)
DROP TABLE IF EXISTS rec_mock.stg_regla1_pares;
CREATE TABLE rec_mock.stg_regla1_pares AS
SELECT
  hijo.cod_dw_persona_ubic AS cod_dw_persona_ubic,       -- HIJO
  padre.cod_dw_persona_ubic AS cod_dw_direccion_unificada -- PADRE
FROM rec_mock.stg_regla1_scored padre
INNER JOIN rec_mock.stg_regla1_scored hijo
  ON padre.texto_ubicacion = hijo.texto_ubicacion
  AND padre.escenario = hijo.escenario
  AND padre.id_buro_persona = hijo.id_buro_persona
  AND padre.cod_dw_ciudad = hijo.cod_dw_ciudad
  AND padre.score > hijo.score
  AND padre.cod_dw_tipo_ubicacion_dir <> hijo.cod_dw_tipo_ubicacion_dir  -- Solo pares con DIFERENTE tipo de uso
WHERE padre.orden = 1;


-- PASO 4: Persistir resultado en tabla de unificación
INSERT INTO rec_mock.unificacion_direccion
SELECT
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  1 AS unifica_atributos,  -- 1 = Regla 1
  CURRENT_DATE AS fecha_unificacion,
  1 AS lote,
  1 AS severidad,
  CURRENT_USER AS usuario_bd
FROM rec_mock.stg_regla1_pares;


-- PASO 5: Marcar hijos en relacion_persona_ubicacion
UPDATE rec_mock.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM rec_mock.stg_regla1_pares
);

-- PASO 6: Limpiar tablas stage (intermedias)
DROP TABLE IF EXISTS rec_mock.stg_regla1_insumo;
DROP TABLE IF EXISTS rec_mock.stg_regla1_scored;
DROP TABLE IF EXISTS rec_mock.stg_regla1_pares;
