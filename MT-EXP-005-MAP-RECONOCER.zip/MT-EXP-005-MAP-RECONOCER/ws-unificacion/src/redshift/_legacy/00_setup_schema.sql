-- ============================================================
-- 00_setup_schema.sql
-- Setup del schema rec_mock para pruebas de unificación
-- Ejecutado: 2026-04-17 en experian-sandbox-dev-redshift-workgroup
-- ============================================================

CREATE SCHEMA IF NOT EXISTS rec_mock;

CREATE TABLE IF NOT EXISTS rec_mock.ubicacion_estandarizada (
  cod_dw_ubic BIGINT PRIMARY KEY,
  texto_ubicacion VARCHAR(200),
  cod_dw_ciudad INTEGER,
  cod_dw_tipo_ubicacion INTEGER,
  latitud DECIMAL(10,6),
  longitud DECIMAL(10,6)
);

CREATE TABLE IF NOT EXISTS rec_mock.direccion_fisica (
  cod_dw_direccion_fisica BIGINT PRIMARY KEY,
  complemento VARCHAR(100),
  tipo_via_principal VARCHAR(20),
  via_principal VARCHAR(100),
  via_generadora INTEGER,
  numero_puerta INTEGER,
  cod_dw_ubic BIGINT,
  generada_enriquecida INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS rec_mock.relacion_persona_ubicacion (
  cod_dw_persona_ubic BIGINT PRIMARY KEY,
  id_buro_persona INTEGER,
  cod_pin_persona INTEGER,
  cod_dw_ubic BIGINT,
  cod_dw_direccion_fisica BIGINT,
  cod_dw_tipo_ubicacion_dir INTEGER,
  ind_unificacion INTEGER,
  orden_prioridad INTEGER,
  fecha_relacion_persona_ubicaci DATE,
  lote INTEGER,
  cod_tipo_ident_fte INTEGER
);

CREATE TABLE IF NOT EXISTS rec_mock.tipo_ubicacion_dir (
  cod_dw_tipo_ubicacion_dir INTEGER PRIMARY KEY,
  descripcion_tipo_ubicacion_dir VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS rec_mock.ciiu_persona (
  id_buro_persona INTEGER PRIMARY KEY,
  cod_act_econo_ciiu_fte VARCHAR(10)
);

CREATE TABLE IF NOT EXISTS rec_mock.reporte_relacion_persona_ubica (
  cod_dw_persona_ubic BIGINT,
  id_buro_suscriptor INTEGER,
  fecha_reporte DATE
);

CREATE TABLE IF NOT EXISTS rec_mock.nomenclatura (
  nomenclatura VARCHAR(10) PRIMARY KEY,
  nivel_complemento INTEGER
);

CREATE TABLE IF NOT EXISTS rec_mock.unificacion_direccion (
  cod_dw_persona_ubic BIGINT,
  cod_dw_direccion_unificada BIGINT,
  unifica_atributos INTEGER,
  fecha_unificacion DATE,
  lote INTEGER,
  severidad SMALLINT,
  usuario_bd VARCHAR(30)
);
