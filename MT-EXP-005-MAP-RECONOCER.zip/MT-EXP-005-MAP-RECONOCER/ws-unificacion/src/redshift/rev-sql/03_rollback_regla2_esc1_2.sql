-- ============================================================
-- 03_rollback_regla2_esc1_2.sql
-- Rollback: revierte Regla 2 Escenarios 1-2
-- ============================================================

-- Desmarcar hijos unificados por Regla 2
UPDATE bdm_datos.relacion_persona_ubicacion
SET ind_unificacion = NULL
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic
  FROM bdm_datos.unificacion_direccion
  WHERE unifica_atributos = 2
);

-- Eliminar registros de Regla 2
DELETE FROM bdm_datos.unificacion_direccion
WHERE unifica_atributos = 2;

-- Limpiar staging
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_insumo;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_esc1_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e1;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_esc2_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e2;

ANALYZE bdm_datos.unificacion_direccion;
ANALYZE bdm_datos.relacion_persona_ubicacion;
