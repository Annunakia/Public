-- 08_rollback_regla2_esc5.sql
UPDATE bdm_tempo.stg_regla2_e2 SET id_padre=NULL, ind_unificacion='N', n_id=NULL WHERE n_id IN ('M5','D5');
DELETE FROM bdm_tempo.stg_regla2_e2 WHERE n_id IS NULL AND cod_dw_persona_ubic > 100039;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_a;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_c;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_sub1;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_sub2;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_sub2_freq;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_sub2_d;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e05_sub2_e;
ANALYZE bdm_tempo.stg_regla2_e2;
