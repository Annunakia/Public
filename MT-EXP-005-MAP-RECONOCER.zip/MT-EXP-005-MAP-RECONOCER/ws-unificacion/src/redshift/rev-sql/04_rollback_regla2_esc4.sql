-- ============================================================
-- 04_rollback_regla2_esc4.sql
-- Rollback: revierte Regla 2 Escenario 4
-- ============================================================

-- Revertir UPDATE en E2
UPDATE bdm_tempo.stg_regla2_e2
SET id_padre = NULL, ind_unificacion = 'N', n_id = NULL
WHERE n_id = 'B5';

-- Desmarcar hijos en relacion_persona_ubicacion
-- (solo los que fueron marcados por esc4, no por esc1-2)
-- Nota: esto es aproximado — en producción usar log de auditoría
UPDATE bdm_datos.relacion_persona_ubicacion
SET ind_unificacion = NULL
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_datos.unificacion_direccion
  WHERE unifica_atributos = 2
    AND fecha_unificacion = CURRENT_DATE
    AND cod_dw_persona_ubic NOT IN (
      SELECT cod_dw_persona_ubic FROM bdm_tempo.stg_regla2_e2 WHERE n_id IN ('H1','K2')
    )
);

-- Limpiar staging
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_a;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_c;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_c1;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_d;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e04_e;

ANALYZE bdm_datos.unificacion_direccion;
ANALYZE bdm_datos.relacion_persona_ubicacion;
