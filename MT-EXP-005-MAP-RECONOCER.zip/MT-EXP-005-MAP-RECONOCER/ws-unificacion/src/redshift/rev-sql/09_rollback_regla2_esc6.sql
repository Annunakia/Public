-- 09_rollback_regla2_esc6.sql
UPDATE bdm_tempo.stg_regla2_e2 SET id_padre=NULL, ind_unificacion='N', n_id=NULL WHERE n_id IN ('M6','D6');
DELETE FROM bdm_tempo.stg_regla2_e2 WHERE n_id IS NULL AND cod_dw_persona_ubic > 100039;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_a;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_c;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_sub1;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_sub3;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_sub3_freq;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_sub3_d;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e06_sub3_e;
ANALYZE bdm_tempo.stg_regla2_e2;
