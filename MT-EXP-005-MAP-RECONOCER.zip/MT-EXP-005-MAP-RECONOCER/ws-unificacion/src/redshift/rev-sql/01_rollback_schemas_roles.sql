-- ============================================================
-- 01_rollback_schemas_roles.sql
-- Rollback: elimina tablas permanentes de unificación
-- NOTA: No elimina schemas bdm_datos/bdm_tempo porque son compartidos
-- ============================================================

DROP TABLE IF EXISTS bdm_datos.unificacion_direccion;
DROP TABLE IF EXISTS bdm_datos.reporte_relacion_persona_ubica;
DROP TABLE IF EXISTS bdm_datos.nomenclatura;
DROP TABLE IF EXISTS bdm_datos.ciiu_persona;
DROP TABLE IF EXISTS bdm_datos.tipo_ubicacion_dir;
DROP TABLE IF EXISTS bdm_datos.relacion_persona_ubicacion;
DROP TABLE IF EXISTS bdm_datos.direccion_fisica;
DROP TABLE IF EXISTS bdm_datos.ubicacion_estandarizada;
