-- ============================================================
-- 02_rollback_regla1_unificacion.sql
-- Rollback: revierte los resultados de Regla 1
-- ============================================================

-- Desmarcar hijos que fueron unificados por Regla 1
UPDATE bdm_datos.relacion_persona_ubicacion
SET ind_unificacion = NULL
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic
  FROM bdm_datos.unificacion_direccion
  WHERE unifica_atributos = 1
);

-- Eliminar registros de Regla 1 de la tabla de unificación
DELETE FROM bdm_datos.unificacion_direccion
WHERE unifica_atributos = 1;

-- Limpiar staging por si quedó
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_insumo;
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_scored;
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_pares;

ANALYZE bdm_datos.unificacion_direccion;
ANALYZE bdm_datos.relacion_persona_ubicacion;
