-- 10_rollback_regla3_geo.sql
UPDATE bdm_datos.relacion_persona_ubicacion SET ind_unificacion = NULL
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_datos.unificacion_direccion WHERE unifica_atributos = 1 AND fecha_unificacion = CURRENT_DATE
);
DELETE FROM bdm_datos.unificacion_direccion WHERE unifica_atributos = 1 AND fecha_unificacion = CURRENT_DATE;
DELETE FROM bdm_datos.diccionario_via;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_insumo;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_diccionario_via;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_scored;
DROP TABLE IF EXISTS bdm_tempo.stg_regla3_resultado;
ANALYZE bdm_datos.unificacion_direccion;
ANALYZE bdm_datos.relacion_persona_ubicacion;
