-- ============================================================
-- 06_rollback_motor_nuevas_direcciones.sql
-- Rollback: revierte las direcciones generadas por el motor
-- ============================================================

-- Desmarcar hijos en relacion_persona_ubicacion
UPDATE bdm_datos.relacion_persona_ubicacion
SET ind_unificacion = NULL
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_datos.unificacion_direccion
  WHERE unifica_atributos = 2
    AND fecha_unificacion = CURRENT_DATE
    AND cod_dw_direccion_unificada IN (
      SELECT cod_dw_persona_ubic FROM bdm_datos.relacion_persona_ubicacion
      WHERE lote = 1 AND fecha_relacion_persona_ubicaci = CURRENT_DATE
    )
);

-- Eliminar pares padre-hijo generados por el motor hoy
DELETE FROM bdm_datos.unificacion_direccion
WHERE unifica_atributos = 2
  AND fecha_unificacion = CURRENT_DATE
  AND cod_dw_direccion_unificada IN (
    SELECT cod_dw_persona_ubic FROM bdm_datos.relacion_persona_ubicacion
    WHERE lote = 1 AND fecha_relacion_persona_ubicaci = CURRENT_DATE
  );

-- Eliminar relaciones persona-ubicación generadas hoy
DELETE FROM bdm_datos.relacion_persona_ubicacion
WHERE lote = 1
  AND fecha_relacion_persona_ubicaci = CURRENT_DATE
  AND cod_dw_direccion_fisica IN (
    SELECT cod_dw_direccion_fisica FROM bdm_datos.direccion_fisica
    WHERE generada_enriquecida = 1
  );

-- Eliminar direcciones físicas generadas por el motor
DELETE FROM bdm_datos.direccion_fisica
WHERE generada_enriquecida = 1;

-- Limpiar staging del motor
DROP TABLE IF EXISTS bdm_tempo.stg_motor_input;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_descomp;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_agrup;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_mdir;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_padre;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_hijo;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_diff;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_codigo;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_resultado;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_final;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_max_ids;

ANALYZE bdm_datos.direccion_fisica;
ANALYZE bdm_datos.relacion_persona_ubicacion;
ANALYZE bdm_datos.unificacion_direccion;
