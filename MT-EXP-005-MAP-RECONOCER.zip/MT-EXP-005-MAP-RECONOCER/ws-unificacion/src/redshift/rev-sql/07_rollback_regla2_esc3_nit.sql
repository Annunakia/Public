-- ============================================================
-- 07_rollback_regla2_esc3_nit.sql
-- Rollback: revierte Regla 2 Escenario 3 caso NIT
-- ============================================================

-- Revertir UPDATE en E2 (hijos NIT)
UPDATE bdm_tempo.stg_regla2_e2
SET id_padre = NULL, ind_unificacion = 'N', n_id = NULL
WHERE n_id = 'X4';

-- Eliminar nuevas direcciones insertadas en E2 por el motor
-- (las que no tienen n_id y fueron generadas hoy)
DELETE FROM bdm_tempo.stg_regla2_e2
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_datos.relacion_persona_ubicacion
  WHERE lote = 1 AND fecha_relacion_persona_ubicaci = CURRENT_DATE
    AND cod_dw_direccion_fisica IN (
      SELECT cod_dw_direccion_fisica FROM bdm_datos.direccion_fisica
      WHERE generada_enriquecida = 1
    )
);

-- Limpiar staging
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e031;
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03_nit_pares;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_input;

-- Nota: el rollback del motor (06_rollback) se ejecuta por separado
ANALYZE bdm_tempo.stg_regla2_e2;
