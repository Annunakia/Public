# Design: Motor de Generación de Nuevas Direcciones en Redshift

> Diseño técnico para reemplazar PRO_Unifi_MOTOR_TMP.sql (870 líneas de SQL dinámico + cursor)
> con SQL estático de Redshift. Referencia: requirements.md (corregido)

---

## 1. Decisión clave: eliminar SQL dinámico

En Teradata, el MOTOR_TMP genera tablas con N columnas dinámicas (C1..CN, N1..NM) porque no sabe de antemano cuántas nomenclaturas tiene cada complemento. Usa:
- XMLAGG para concatenar y para generar SQL
- Cursor para ejecutar UPDATE dinámico por cada hijo
- DBC.COLUMNS para leer metadata de tablas generadas
- PIVOT implícito con CASE WHEN ORDEN=N

En Redshift, reemplazamos todo con:
- `LISTAGG()` para concatenar nomenclaturas
- `ROW_NUMBER()` + string de comparación para MDIR
- Un solo query con JOINs para el código de comparación (sin cursor)
- `POSITION()` + `SUBSTRING()` para extraer la parte diferente

---

## 2. Tablas temporales del motor (Teradata → Redshift)

| Teradata | Qué contiene | Redshift |
|----------|-------------|----------|
| E051_D | Input: pares candidatos a combinar | `stg_motor_input` |
| E051_D1 | Descomposición: 1 fila por nomenclatura por dirección | `stg_motor_descomp` |
| E051_D2 | Agrupación: NOM_AGRUP concatenado + cantidad | `stg_motor_agrup` |
| E051_Dx | MDIR: vector de niveles+valores pivoteado → ROW_NUMBER | `stg_motor_mdir` |
| E051_D3 | Consolidación: todo junto con MDIR, ORDEN, NOM_AGRUP | `stg_motor_consolidado` |
| E051_D00 | Pivot C1..CN: nomenclatura en cada posición (dinámico) | No necesario — usar LISTAGG |
| E051_D01 | Pivot N1..NM: sufijos acumulados (dinámico) | No necesario — usar SUBSTRING sobre LISTAGG |
| E051_P | Padre: dirección con MDIR=1 | `stg_motor_padre` |
| E051_H | Hijo: direcciones con MDIR>1 | `stg_motor_hijo` |
| E051_codigo | Código binario + Campo_Complemento + NUEVA_NOMENCLATURA | `stg_motor_codigo` |
| E051_E | Resultado: nuevas direcciones con IDs | `stg_motor_resultado` |

---

## 3. Diseño por pasos

### Paso 1: Descomponer complementos → `stg_motor_descomp`

Igual que en Teradata. Una fila por nomenclatura por dirección.

```sql
-- Paso 1a: JOIN sin window functions
CREATE TABLE bdm_tempo.stg_motor_descomp_raw AS
SELECT
  tu.cod_dw_persona_ubic,
  tu.cod_dw_ubic,
  tu.id_buro_persona,
  tu.cod_dw_tipo_ubicacion_dir,
  dc.nomenclatura,  -- completa: "AP 101"
  dc.nomen,         -- abreviatura: "AP"
  dc.valor AS valor_original,  -- preservar original: "101" o "CASTILLA"
  CASE WHEN dc.valor ~ '^[0-9]+$' THEN CAST(dc.valor AS BIGINT) ELSE 0 END AS valor_num,
  COALESCE(nom.nivel_complemento, 99) AS nivel_complemento,  -- 99 si no está en catálogo
  COUNT(*) AS cantidad
FROM bdm_tempo.stg_motor_input tu
JOIN bdm_datos.diccionario_complementos dc
  ON ' ' || tu.complemento || ' ' LIKE '% ' || dc.nomenclatura || ' %'  -- separadores para evitar match parcial
  AND tu.cod_dw_ubic = dc.cod_dw_ubic
  AND tu.id_buro_persona = dc.id_buro_persona  -- JOIN por persona
LEFT JOIN bdm_datos.nomenclatura nom
  ON nom.nomenclatura = dc.nomen
GROUP BY 1,2,3,4,5,6,7,8,9;

ANALYZE bdm_tempo.stg_motor_descomp_raw;

-- Paso 1b: Agregar ROW_NUMBER sobre resultado
CREATE TABLE bdm_tempo.stg_motor_descomp AS
SELECT *,
  ROW_NUMBER() OVER (PARTITION BY cod_dw_persona_ubic
    ORDER BY nivel_complemento DESC) AS id_com,
  ROW_NUMBER() OVER (PARTITION BY cod_dw_persona_ubic
    ORDER BY nivel_complemento ASC) AS id_com1
FROM bdm_tempo.stg_motor_descomp_raw;

ANALYZE bdm_tempo.stg_motor_descomp;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_descomp_raw;
```

### Paso 2: Agrupar nomenclaturas → `stg_motor_agrup`

```sql
SELECT
  cod_dw_persona_ubic,
  LISTAGG(nomen, '|') WITHIN GROUP (ORDER BY id_com) AS nom_agrup,
  SUM(cantidad) AS cantidad
FROM bdm_tempo.stg_motor_descomp
GROUP BY 1
```

Nota: usar `|` como separador para evitar colisiones (ej: "TO|AP" nunca colisiona con "T|OAP"). En Teradata usa `XMLAGG(NOMEN ORDER BY ID_COM)` sin separador — replicamos con separador por seguridad.

### Paso 3: Calcular MDIR → `stg_motor_mdir`

En Teradata, MDIR se calcula con un PIVOT dinámico que genera columnas ID_COM1_1, ID_COM1_2, val_1, val_2... y luego ROW_NUMBER sobre todas ellas.

En Redshift, generamos un string de comparación ordenable con padding fijo:

```sql
SELECT
  cod_dw_persona_ubic,
  cod_dw_ubic,
  id_buro_persona,
  cod_dw_tipo_ubicacion_dir,
  -- String ordenable: nivel (padded 3) + valor (padded 6) por cada nomenclatura
  -- Pad a largo fijo (54 chars = 6 nomenclaturas × 9 chars) con "099999999" para posiciones faltantes
  RPAD(
    LISTAGG(
      LPAD(CAST(nivel_complemento AS VARCHAR), 3, '0')
      || LPAD(CAST(CASE WHEN valor_num > 999999 THEN 999999 ELSE valor_num END AS VARCHAR), 6, '0'),
      ''
    ) WITHIN GROUP (ORDER BY id_com1),
    54, '099999999'  -- posiciones faltantes = nivel 99 + valor 999999
  ) AS mdir_key
FROM bdm_tempo.stg_motor_descomp
GROUP BY 1,2,3,4
```

Luego:
```sql
ROW_NUMBER() OVER (
  PARTITION BY cod_dw_ubic, id_buro_persona, cod_dw_tipo_ubicacion_dir
  ORDER BY mdir_key, cod_dw_persona_ubic ASC  -- desempate por ID más bajo = padre
) AS mdir
```

Esto produce el mismo ranking que el PIVOT dinámico de Teradata, porque el string concatenado respeta el orden lexicográfico de nivel + valor.

### Paso 4: Consolidar → `stg_motor_consolidado`

Unir todo: input + descomposición + MDIR + agrupación + ORDEN.

```sql
SELECT
  tu.cod_dw_ubic,
  tu.cod_dw_persona_ubic,
  tu.complemento,
  dc.nomenclatura,
  dc.nomen,
  dc.valor,
  nom.nivel_complemento,
  tu.id_buro_persona,
  tu.cod_dw_tipo_ubicacion_dir,
  md.mdir,
  agr.nom_agrup,
  agr.cantidad,
  -- ORDEN: dentro de cada dirección, ordenar nomenclaturas por MDIR + nivel DESC + valor
  ROW_NUMBER() OVER (PARTITION BY tu.cod_dw_persona_ubic
    ORDER BY md.mdir, descomp.id_com DESC, CAST(dc.valor AS BIGINT)) AS orden
FROM bdm_tempo.stg_motor_input tu
JOIN bdm_datos.diccionario_complementos dc ...
LEFT JOIN bdm_datos.nomenclatura nom ...
LEFT JOIN bdm_tempo.stg_motor_descomp descomp ...
LEFT JOIN bdm_tempo.stg_motor_mdir md ...
LEFT JOIN bdm_tempo.stg_motor_agrup agr ...
```

### Paso 5: Identificar padre e hijo

```sql
-- Padre: MDIR=1 por grupo
CREATE TABLE bdm_tempo.stg_motor_padre AS
SELECT cod_dw_persona_ubic, cod_dw_ubic, id_buro_persona,
  cod_dw_tipo_ubicacion_dir, complemento, nom_agrup, cantidad,
  LISTAGG(nomenclatura, '|') WITHIN GROUP (ORDER BY orden) AS nomenclaturas_ord
FROM bdm_tempo.stg_motor_consolidado
WHERE mdir = 1
GROUP BY 1,2,3,4,5,6,7;

ANALYZE bdm_tempo.stg_motor_padre;

-- Hijo: MDIR > 1
CREATE TABLE bdm_tempo.stg_motor_hijo AS
SELECT cod_dw_persona_ubic, cod_dw_ubic, id_buro_persona,
  cod_dw_tipo_ubicacion_dir, complemento, nom_agrup, cantidad, mdir,
  LISTAGG(nomenclatura, '|') WITHIN GROUP (ORDER BY orden) AS nomenclaturas_ord
FROM bdm_tempo.stg_motor_consolidado
WHERE mdir > 1
GROUP BY 1,2,3,4,5,6,7,8;

ANALYZE bdm_tempo.stg_motor_hijo;
```

### Paso 6: Generar nueva nomenclatura → `stg_motor_codigo`

Identificar las nomenclaturas del hijo que NO están en el padre, y concatenarlas.
Esto reemplaza el cursor + columnas dinámicas C1..CN + código binario de Teradata.

```sql
-- Paso 6a: Nomenclaturas del hijo que NO están en el padre
CREATE TABLE bdm_tempo.stg_motor_diff AS
SELECT
  h_nom.cod_dw_persona_ubic AS cod_dw_persona_ubic_hijo,
  p.cod_dw_persona_ubic AS cod_dw_persona_ubic_padre,
  h_nom.nomenclatura,  -- completa: "AP 504"
  h_nom.nomen,
  h_nom.valor_original,
  h_nom.orden
FROM bdm_tempo.stg_motor_consolidado h_nom
JOIN bdm_tempo.stg_motor_hijo h
  ON h_nom.cod_dw_persona_ubic = h.cod_dw_persona_ubic
JOIN bdm_tempo.stg_motor_padre p
  ON h.cod_dw_ubic = p.cod_dw_ubic
  AND h.id_buro_persona = p.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = p.cod_dw_tipo_ubicacion_dir
LEFT JOIN bdm_tempo.stg_motor_consolidado p_nom
  ON p.cod_dw_persona_ubic = p_nom.cod_dw_persona_ubic
  AND h_nom.nomen = p_nom.nomen
  AND TRIM(h_nom.valor_original) = TRIM(p_nom.valor_original)  -- TRIM para evitar padding
WHERE p_nom.cod_dw_persona_ubic IS NULL  -- nomenclaturas que NO están en el padre
  AND h.complemento <> p.complemento;   -- defensa: excluir pares idénticos

ANALYZE bdm_tempo.stg_motor_diff;

-- Paso 6b: Concatenar las diferencias por par padre-hijo
CREATE TABLE bdm_tempo.stg_motor_codigo AS
SELECT
  cod_dw_persona_ubic_padre,
  cod_dw_persona_ubic_hijo,
  LISTAGG(nomenclatura, ' ') WITHIN GROUP (ORDER BY orden) AS nueva_nomenclatura
FROM bdm_tempo.stg_motor_diff
GROUP BY 1,2;

ANALYZE bdm_tempo.stg_motor_codigo;
```

**NO USAR subquery correlacionada en CASE** — Redshift no la soporta.

### Paso 7: Construir nueva dirección → `stg_motor_resultado`

```sql
SELECT
  p.cod_dw_persona_ubic AS cod_dw_persona_ubic_padre,
  p.complemento AS complemento_padre,
  p.cod_dw_ubic,
  p.id_buro_persona,
  p.cod_dw_tipo_ubicacion_dir,
  -- Concatenar complemento del padre + nuevas nomenclaturas de TODOS los hijos
  LEFT(
    TRIM(p.complemento) || ' ' || TRIM(LISTAGG(c.nueva_nomenclatura, ' ')
      WITHIN GROUP (ORDER BY h.mdir DESC)),
    100  -- truncar a VARCHAR(100) de DIRECCION_FISICA
  ) AS nuevo_complemento,
  -- Concatenar IDs de hijos (para trazabilidad)
  LISTAGG(CAST(c.cod_dw_persona_ubic_hijo AS VARCHAR), ',')
    WITHIN GROUP (ORDER BY h.mdir DESC) AS hijos_ids
FROM bdm_tempo.stg_motor_padre p
JOIN bdm_tempo.stg_motor_codigo c
  ON p.cod_dw_persona_ubic = c.cod_dw_persona_ubic_padre
JOIN bdm_tempo.stg_motor_hijo h
  ON c.cod_dw_persona_ubic_hijo = h.cod_dw_persona_ubic
GROUP BY 1,2,3,4,5
```

### Paso 8: Verificar existencia y generar IDs

```sql
-- Precalcular MAX IDs una sola vez (no por cada fila)
DROP TABLE IF EXISTS bdm_tempo.stg_motor_max_ids;
CREATE TABLE bdm_tempo.stg_motor_max_ids AS
SELECT
  COALESCE((SELECT MAX(cod_dw_direccion_fisica) FROM bdm_datos.direccion_fisica), 0) AS max_df,
  COALESCE((SELECT MAX(cod_dw_persona_ubic) FROM bdm_datos.relacion_persona_ubicacion), 0) AS max_rpu;

-- Generar resultado con IDs
SELECT
  r.*,
  CASE WHEN df.cod_dw_direccion_fisica IS NULL
    THEN mx.max_df + ROW_NUMBER() OVER (ORDER BY r.cod_dw_persona_ubic_padre)
    ELSE df.cod_dw_direccion_fisica
  END AS new_cod_dw_direccion_fisica,
  CASE WHEN rpu.cod_dw_persona_ubic IS NULL
    THEN mx.max_rpu + ROW_NUMBER() OVER (ORDER BY r.cod_dw_persona_ubic_padre)
    ELSE rpu.cod_dw_persona_ubic
  END AS new_cod_dw_persona_ubic
FROM bdm_tempo.stg_motor_resultado r
CROSS JOIN bdm_tempo.stg_motor_max_ids mx
LEFT JOIN bdm_datos.direccion_fisica df
  ON df.cod_dw_ubic = r.cod_dw_ubic
  AND TRIM(df.complemento) = TRIM(r.nuevo_complemento)  -- match exacto con TRIM
LEFT JOIN bdm_datos.relacion_persona_ubicacion rpu
  ON rpu.id_buro_persona = r.id_buro_persona
  AND rpu.cod_dw_ubic = r.cod_dw_ubic
  AND rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
  AND rpu.cod_dw_tipo_ubicacion_dir = r.cod_dw_tipo_ubicacion_dir
```

---

## 4. Diferencias clave vs Teradata (actualizado)

| Aspecto | Teradata (870 líneas) | Redshift (estimado ~200 líneas) |
|---------|----------------------|-------------------------------|
| Columnas dinámicas C1..CN | XMLAGG genera CREATE TABLE con N columnas | No necesario — LISTAGG con separador |
| Columnas dinámicas N1..NM (sufijos) | XMLAGG genera tabla de sufijos acumulados | No necesario — LEFT JOIN + LISTAGG de diferencias |
| PIVOT para MDIR | SQL dinámico genera ID_COM1_1..N, val_1..N | String concatenado con LPAD (ordenable lexicográficamente) |
| Cursor para NUEVA_NOMENCLATURA | Itera por cada hijo, ejecuta UPDATE dinámico | LEFT JOIN + IS NULL + LISTAGG (un solo query) |
| DBC.COLUMNS | Lee metadata para generar SQL | No necesario |
| MAX_ID | Tabla de secuencias manual | MAX() + ROW_NUMBER() |
| XMLAGG | Concatena strings | LISTAGG() WITHIN GROUP |
| OREPLACE | Reemplaza strings | REPLACE() |
| SQL dinámico total | ~500 líneas de generación de SQL | 0 líneas — todo estático |

---

## 5. Riesgo identificado y análisis

### Comparación posicional (Teradata) vs semántica (Redshift)

El código original compara posición por posición (C1=C1, C2=C2). Mi diseño compara por nomen+valor (semántico). Analicé cuándo podrían diferir:

**Caso 1: Complementos con nomenclaturas completamente diferentes**
- Padre: "TO 3", Hijo: "AP 504"
- Posicional: NOM_AGRUP diferentes → CODIGO empieza con '0' → toma complemento completo del hijo → "AP 504"
- Semántico: ninguna nomenclatura coincide → toma todo del hijo → "AP 504"
- **Resultado: IGUALES** ✅

**Caso 2: Misma nomenclatura, diferente valor**
- Padre: "LC 101", Hijo: "LC 205"
- Posicional: NOM_AGRUP iguales → '1', C1 diferentes ("LC 101"≠"LC 205") → '0' → CODIGO="10" → toma N1 = "LC 205"
- Semántico: nomen "LC" coincide pero valor difiere → toma "LC 205"
- **Resultado: IGUALES** ✅

**Caso 3: Nomenclaturas parcialmente compartidas, mismo orden**
- Padre: "TO 3 AP 504", Hijo: "TO 3 AP 702"
- Posicional: NOM_AGRUP iguales → '1', C1 iguales → '1', C2 diferentes → '0' → CODIGO="110" → toma N2 = "AP 702"
- Semántico: "TO 3" coincide, "AP 504"≠"AP 702" (mismo nomen, ≠ valor) → toma "AP 702"
- **Resultado: IGUALES** ✅

**Caso 4: Nomenclaturas parcialmente compartidas, NOM_AGRUP diferente**
- Padre: "TO 3 AP 504", Hijo: "TO 3 BR SUBA"
- Posicional: NOM_AGRUP diferentes ("TOAP"≠"TOBR") → '0' → toma complemento COMPLETO del hijo → "TO 3 BR SUBA"
- Semántico: "TO 3" coincide, "BR SUBA" no → toma solo "BR SUBA"
- **Resultado: DIFERENTES** ⚠️
  - Teradata: "TO 3 AP 504 TO 3 BR SUBA" (repite "TO 3")
  - Redshift: "TO 3 AP 504 BR SUBA" (no repite)

**Evaluación del riesgo:**
- El caso 4 solo ocurre cuando padre e hijo comparten nomenclaturas pero tienen NOM_AGRUP diferente (es decir, tienen nomenclaturas diferentes además de las compartidas)
- En la práctica, los escenarios que llaman al motor ya filtran por condiciones específicas (mismo nivel, diferente nivel, etc.) que hacen improbable este caso
- El resultado de Redshift (no repetir) es arguably más correcto que el de Teradata (repetir)
- **Decisión: mantener diseño semántico. Validar con datos reales cuando estén disponibles. Si hay discrepancias, ajustar.**

### Otro riesgo: LISTAGG tiene límite de 65535 caracteres

Si un complemento tiene muchas nomenclaturas, LISTAGG podría truncar. En la práctica, los complementos de direcciones colombianas rara vez tienen más de 3-4 nomenclaturas, así que esto no debería ser problema.

---

## 6. Reutilización

Mismo patrón que antes — cada escenario prepara `stg_motor_input` y el motor es idéntico:

```sql
-- Al INICIO de cada invocación, limpiar tablas de invocación anterior
DROP TABLE IF EXISTS bdm_tempo.stg_motor_input;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_descomp;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_agrup;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_mdir;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_consolidado;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_padre;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_hijo;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_diff;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_codigo;
DROP TABLE IF EXISTS bdm_tempo.stg_motor_resultado;

-- Escenario X prepara input
CREATE TABLE bdm_tempo.stg_motor_input AS SELECT ... FROM ... WHERE ...;

-- Ejecutar motor (mismo SQL siempre)
-- Lee stg_motor_input → escribe stg_motor_resultado
```

---

## 7. ANALYZE entre pasos

Agregar `ANALYZE` después de cada `CREATE TABLE AS` para que el optimizador tenga estadísticas actualizadas. Crítico para 70M registros:

```sql
CREATE TABLE bdm_tempo.stg_motor_descomp AS ...;
ANALYZE bdm_tempo.stg_motor_descomp;
-- repetir para cada tabla staging
```

---

## 8. Manejo de errores

Como Redshift Data API ejecuta todo el script como una transacción, un error en cualquier paso revierte todo automáticamente. Adicionalmente:

1. Después del paso 1, verificar que `stg_motor_descomp` no está vacío. Si está vacío, el DICCIONARIO_COMPLEMENTOS no tiene datos para las ubicaciones del input → log warning y saltar el resto del motor.
2. Después del paso 8, verificar que los IDs generados no colisionan con IDs existentes.
3. Para producción: usar tabla de secuencias (`bdm_datos.max_id`) en vez de MAX() + ROW_NUMBER() para generación de IDs concurrency-safe.

---

## 9. Generación de IDs (sandbox vs producción)

| Ambiente | Método | Concurrency-safe |
|----------|--------|-------------------|
| Sandbox/dev | `MAX(id) + ROW_NUMBER()` | No — suficiente para pruebas |
| Producción | Tabla `bdm_datos.max_id` con UPDATE atómico | Sí |

---

## 10. Validación

| Caso | Padre complemento | Hijo complemento | Resultado esperado |
|------|-------------------|------------------|-------------------|
| P07 (NIT, Esc 3) | "LC 101" | "LC 205" | "LC 101 LC 205" |
| P09 (Esc 5 sub1) | "TO 3" | "AP 504" | "TO 3 AP 504" |
| P11 (Esc 6 sub1) | "ED PROMOTOR" | "OF 2007" | "ED PROMOTOR OF 2007" |

Nota: en P07 ambos tienen la misma nomenclatura (LC) pero diferente valor. El padre será el de mayor jerarquía (MDIR=1). La nueva nomenclatura del hijo será "LC 205" (el valor que difiere).

---

*Diseño corregido: 2026-04-21 | Errores corregidos: MDIR simplificado, código binario, sufijos acumulados, subquery correlacionada*
