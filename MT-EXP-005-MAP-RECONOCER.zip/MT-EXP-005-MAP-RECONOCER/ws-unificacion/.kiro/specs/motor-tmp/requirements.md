# Requirements: Motor de Generación de Nuevas Direcciones (MOTOR_TMP)

> Especificación funcional extraída de PRO_Unifi_MOTOR_TMP.sql (870 líneas).
> Este motor se invoca desde PRO_UnificacionR2.sql en los escenarios 3 (NIT), 5 y 6.

---

## 1. Objetivo

Cuando las direcciones de una misma persona necesitan combinarse (por tener nomenclaturas diferentes, valores diferentes, o por ser tipo NIT), el motor **genera una nueva dirección** que combina las nomenclaturas relevantes de todas las direcciones del grupo.

La nueva dirección se convierte en el **Padre** y las originales se convierten en **Hijas**. Puede haber 2 o más hijas en un grupo.

---

## 2. Input

Tabla `Tmp_Unificacion_E051_D` con pares de direcciones candidatas a combinar:

| Campo | Descripción |
|-------|-------------|
| Cod_DW_Persona_Ubic | PK de la relación persona-ubicación |
| Cod_DW_Ubic | FK a ubicación estandarizada (la "puerta") |
| Complemento | Complemento actual de la dirección |
| Id_Buro_Persona | Persona |
| Cod_DW_Tipo_Ubicacion_Dir | Tipo de uso |

Tablas de soporte:
- `DICCIONARIO_COMPLEMENTOS` — frecuencia de cada nomenclatura por ubicación. `nomenclatura` es el texto completo con valor (ej: "AP 101"), `nomen` es solo la abreviatura (ej: "AP"), `valor` es el componente numérico o textual (ej: "101" o "CASTILLA")
- `NOMENCLATURA` — catálogo con niveles jerárquicos (1=Barrio...7=Apartamento)

**Precondiciones:**
- Todas las direcciones en el input deben tener complemento NOT NULL y NOT EMPTY
- El DICCIONARIO_COMPLEMENTOS debe tener datos para las ubicaciones del input
- Los escenarios que invocan al motor son responsables de filtrar complementos vacíos

---

## 3. Lógica funcional (qué hace, paso a paso)

> **Nota:** Los pasos 3-6 describen la lógica TAL COMO ESTÁ en Teradata (para referencia y trazabilidad). La implementación en Redshift usa un enfoque diferente descrito en design.md. Para implementar, seguir design.md.

### Paso 1: Descomponer complementos en nomenclaturas

Para cada dirección, descomponer el complemento en sus nomenclaturas individuales usando el DICCIONARIO_COMPLEMENTOS. Nota: `dc.nomenclatura` es el texto completo con valor (ej: "AP 101"), `dc.nomen` es solo la abreviatura (ej: "AP"), `dc.valor` puede ser numérico ("101") o textual ("CASTILLA").

Ejemplo: complemento "TO 3 AP 504"
→ nomenclatura "TO 3", nomen "TO" (nivel 4), valor "3"
→ nomenclatura "AP 504", nomen "AP" (nivel 7), valor "504"

Cada nomenclatura recibe:
- `valor_num`: valor convertido a número (0 si no es numérico, para ordenamiento)
- `valor_original`: valor tal cual (para concatenación)
- `ID_COM`: orden por nivel descendente
- `ID_COM1`: orden por nivel ascendente

Nota: NO agrupar por nomen — si un complemento tiene "AP 101 AP 202", deben mantenerse como 2 filas separadas (la clave es `dc.nomenclatura`, no `dc.nomen`).

### Paso 2: Agrupar nomenclaturas por dirección

Concatenar todas las nomenclaturas de una dirección en un string `NOM_AGRUP` (ej: "TO AP") y contar cuántas tiene (`CANTIDAD`).

### Paso 3: Calcular MDIR (jerarquía de dirección)

Para cada dirección, generar un vector de comparación con una columna por cada posición de nomenclatura:
- `ID_COM1_N` = nivel_complemento de la nomenclatura en posición N (99 si no existe)
- `val_N` = valor numérico de la nomenclatura en posición N (99999 si no existe)

Luego, ROW_NUMBER ordenando por TODAS las columnas del vector (ID_COM1_1, ID_COM1_2, ..., val_1, val_2, ...). Esto produce un ranking multi-criterio que respeta la jerarquía de nomenclaturas.

En Teradata esto se hace con SQL dinámico (genera N columnas según cuántas nomenclaturas hay). En Redshift se puede resolver con LISTAGG para crear un string de comparación ordenable.

La dirección con MDIR=1 es la de mayor jerarquía (nivel más bajo = más específico).

### Paso 4: Identificar Padre e Hijo

- **Padre** (E051_P): la dirección con MDIR=1 dentro de cada grupo (persona + ubicación + tipo). Incluye las columnas C1..CN (nomenclatura en cada posición).
- **Hijo** (E051_H): las demás direcciones del grupo que NO son padre. Incluye las columnas C1..CN y N1..NM (sufijos acumulados de nomenclaturas).

### Paso 5: Generar código de comparación

Para cada par padre-hijo, generar un CODIGO binario comparando posición por posición:
- Primer carácter: '1' si NOM_AGRUP del padre = NOM_AGRUP del hijo, '0' si no
- Siguientes caracteres: '1' si C_N del padre = C_N del hijo, '0' si no

Ejemplo con padre "TO AP" y hijo "TO BR":
- NOM_AGRUP: "TO AP" vs "TO BR" → '0' (diferentes)
- C1: "TO 3" vs "TO 3" → '1'
- C2: "AP 504" vs "BR SUBA" → '0'
- CODIGO = "010"

El `Campo_Complemento` se calcula como: `TRIM(N{posición_del_primer_0 - 1})`. Esto apunta a la columna N que contiene las nomenclaturas del hijo desde la primera diferencia.

### Paso 6: Construir nueva nomenclatura (cursor en Teradata)

Para cada hijo, el cursor ejecuta dinámicamente:
```
UPDATE Tmp_Unificacion_E051_codigo
SET NUEVA_NOMENCLATURA = TRIM(N{X})
WHERE COD_DW_PERSONA_UBIC_HIJO = {id}
```
Donde X viene de Campo_Complemento. Esto extrae del hijo las nomenclaturas que difieren del padre.

### Paso 7: Crear nueva dirección

Concatenar: `COMPLEMENTO_PADRE` + todas las `NUEVA_NOMENCLATURA` de los hijos del grupo (ordenadas por MDIR DESC).

Se usa XMLAGG en Teradata: `OREPLACE(XMLAGG(' '||TRIM(NUEVA_NOMENCLATURA) ORDER BY MDIR DESC), '@#X', '')`

Ejemplo:
- Padre complemento: "TO 3"
- Hijo nueva_nomenclatura: "AP 504"
- Resultado: "TO 3 AP 504"

### Paso 8: Verificar si ya existe

Buscar en `DIRECCION_FISICA` si ya existe una dirección con ese complemento para esa ubicación:
- Si existe → reusar el `Cod_DW_Direccion_Fisica` existente
- Si no existe → generar nuevo ID desde `REC_MTDAT.MAX_ID`

Buscar en `RELACION_PERSONA_UBICACION` si ya existe la relación:
- Si existe → reusar el `Cod_DW_Persona_Ubic` existente
- Si no existe → generar nuevo ID desde `REC_MTDAT.MAX_ID`

---

## 4. Output

Tabla `Tmp_Unificacion_E051_E` con las nuevas direcciones generadas:

| Campo | Descripción | Valor |
|-------|-------------|-------|
| Cod_DW_Persona_Ubic | ID concatenado padre+hijo (temporal) | — |
| ID_PADRE | Nuevo Cod_DW_Persona_Ubic (generado o existente) | — |
| Texto_Ubicacion | La "puerta" (heredada del padre) | — |
| Id_Buro_Persona | Persona | Heredado del padre |
| Cod_DW_Tipo_Ubicacion_Dir | Tipo de uso | Heredado del padre |
| Complemento1 | Nuevo complemento combinado | — |
| COD_DW_DIRECCION_FISICA | Nuevo o existente | — |
| Cod_Pin_Persona | PIN de la persona | Heredado del padre |
| Fecha_Relacion_Persona_Ubicaci | Fecha de la relación | CURRENT_DATE |
| Orden_Prioridad | Ranking | NULL (se calcula en Ordenamiento) |
| Lote | Lote del proceso | P_Lote (parámetro) |
| Severidad | Severidad | 1 |
| Usuario_BD | Usuario | LEFT(CURRENT_USER, 30) |
| Ind_Unificacion | Flag | NULL (es padre, no está unificada) |
| Generada_Enriquecida | Flag dirección generada | 1 |

Este output se usa para:
1. INSERT en `DIRECCION_FISICA` (nueva dirección con `Generada_Enriquecida=1`)
2. INSERT en `RELACION_PERSONA_UBICACION` (nueva relación persona-ubicación con todos los campos)
3. INSERT en `UNIFICACION_DIRECCION` (pares padre-hijo)
4. UPDATE `Ind_Unificacion=1` en las hijas originales

Nota sobre DIRECCION_FISICA vs RELACION_PERSONA_UBICACION:
- DIRECCION_FISICA es independiente del tipo de uso (una dirección física es la misma para RES y LAB)
- RELACION_PERSONA_UBICACION sí depende del tipo de uso (relaciones diferentes por tipo)

---

## 5. Invocaciones

El MOTOR_TMP se invoca 4 veces desde PRO_UnificacionR2.sql:

| Escenario | Caso | Líneas | Cuándo se invoca |
|-----------|------|--------|-----------------|
| 3 | NIT | ~797-1834 | Misma nomenclatura, ≠ valor, tipo NIT → combina |
| 5 | Subcaso 1 | ~2600-3607 | ≠ nomenclatura, ≠ nivel, valores diferentes → combina |
| 6 | Subcaso 1 | ~4339-4655 | Ninguna contenida, ≠ nivel → combina |
| 6 | Subcaso 2 | ~4715-5395 | Variante de combinación → combina |

---

## 6. Criterios de aceptación

1. Dado P07 (NIT, CL 10 20 30, "LC 101" y "LC 205"), debe generar nueva dirección "LC 101 LC 205" (la nomenclatura LC se REPITE porque los valores son diferentes)
2. Dado P09 (CL 45 22 10, "TO 3" y "AP 504"), debe generar nueva dirección "TO 3 AP 504"
3. Dado P11 (KR 10 27 45, "ED PROMOTOR" y "OF 2007"), debe generar nueva dirección "ED PROMOTOR OF 2007"
4. Las direcciones originales deben quedar como hijas (Ind_Unificacion=1)
5. La nueva dirección debe insertarse en DIRECCION_FISICA con Generada_Enriquecida=1
6. Si la dirección combinada ya existe en DIRECCION_FISICA, reusar el ID existente
7. El motor debe ser reutilizable — se invoca desde 4 puntos diferentes del SP
8. Si DICCIONARIO_COMPLEMENTOS no tiene datos para una ubicación, el motor no genera nada (no es error)
9. Complementos con valores no numéricos (ej: "BR CASTILLA") deben funcionar correctamente
10. Si hay 3+ direcciones en un grupo, todas las no-padre se combinan al padre

---

## 7. Complejidad del código Teradata original

| Técnica Teradata | Qué hace | Por qué es complejo |
|-----------------|----------|---------------------|
| SQL dinámico (XMLAGG + EXECUTE) | Genera CREATE TABLE con N columnas dinámicas | El número de columnas depende de cuántas nomenclaturas tiene el complemento |
| Cursor | Itera por cada hijo para calcular NUEVA_NOMENCLATURA | Ejecuta un UPDATE dinámico por cada fila |
| XMLAGG para concatenar | Concatena nomenclaturas en orden | Equivale a STRING_AGG/LISTAGG en Redshift |
| Consulta a DBC.COLUMNS | Lee metadata de tablas para generar SQL | No existe en Redshift |
| MAX_ID (tabla de secuencias) | Genera IDs nuevos | Redshift usa IDENTITY o secuencias |

---

*Extraído de: PRO_Unifi_MOTOR_TMP.sql (870 líneas) | Fecha: 2026-04-21*
