# Revisión de Spec — MOTOR_TMP

> Documento consolidado: 20 correcciones iniciales + revisión de comité de diseño (5 roles).
> Fecha: 2026-04-21

---

## 1. Correcciones aplicadas a la spec

Las siguientes correcciones ya fueron aplicadas a requirements.md y design.md.

### Funcionales (aplicadas)

| # | Problema | Corrección | Archivo |
|---|---------|-----------|---------|
| F1 | Valores no numéricos ("CASTILLA") rompen CAST | `valor_num` con regex + `valor_original` preservado | design.md paso 1 |
| F2 | Nomenclatura repetida ("AP 101 AP 202") se colapsa en GROUP BY | GROUP BY por nomenclatura completa, no por nomen | design.md paso 1 |
| F3 | Spec dice "dos direcciones" pero puede haber 3+ | Objetivo corregido: "todas las direcciones del grupo" | requirements.md §1 |
| F4 | Padre e hijo con complementos idénticos | Filtro `h.complemento <> p.complemento` en paso 6a | design.md paso 6 |
| F5 | Complemento vacío en input | Precondición: NOT NULL y NOT EMPTY | requirements.md §2 |
| F6 | Orden de concatenación no documentado | Documentado: MDIR DESC (menor jerarquía primero) | requirements.md paso 7 |
| F7 | P07 ¿"LC 101 LC 205" o "LC 101 205"? | Verificado: "LC 101 LC 205" (nomenclatura se repite) | requirements.md §6 |

### Técnicos (aplicados)

| # | Problema | Corrección | Archivo |
|---|---------|-----------|---------|
| T1 | GROUP BY + ROW_NUMBER incompatibles | Separado en paso 1a (GROUP BY) + paso 1b (ROW_NUMBER) | design.md paso 1 |
| T2 | LISTAGG sin separador → colisiones | Separador `\|` en NOM_AGRUP | design.md paso 2 |
| T3 | LPAD no maneja valores > 999999 | Cap a 999999 | design.md paso 3 |
| T4 | MAX() + ROW_NUMBER() no es concurrency-safe | Documentado: sandbox usa MAX, producción usa tabla secuencias | design.md §9 |
| T5 | Subquery correlacionada en CASE | Eliminada. Solo versión con LEFT JOIN + IS NULL | design.md paso 6 |
| T6 | Comparación valor con padding ("03" ≠ "3") | TRIM en comparación | design.md paso 6a |
| T7 | PARTITION BY de MDIR incompleto | Agregado id_buro_persona + cod_dw_tipo_ubicacion_dir | design.md paso 3 |
| T8 | NOT EXISTS para identificar hijos | Cambiado a `WHERE mdir > 1` | design.md paso 5 |
| T9 | DISTINCT redundante con GROUP BY | Eliminado DISTINCT | design.md paso 5 |
| T10 | Subquery escalar en CASE (rendimiento) | Precalcular MAX en tabla stg_motor_max_ids | design.md paso 8 |
| T11 | MDIR_KEY sin padding para diferente cantidad de nomenclaturas | RPAD a 54 chars con "099999999" | design.md paso 3 |
| T12 | Empate de MDIR sin desempate definido | Desempate por cod_dw_persona_ubic ASC | design.md paso 3 |
| T13 | LIKE match parcial ("AP 10" matchea "AP 101") | Separadores: `' ' \|\| complemento \|\| ' ' LIKE '% ' \|\| nomenclatura \|\| ' %'` | design.md paso 1 |
| T14 | Falta id_buro_persona en JOIN con diccionario | Agregado `AND tu.id_buro_persona = dc.id_buro_persona` | design.md paso 1 |

### Operativos (aplicados)

| # | Problema | Corrección | Archivo |
|---|---------|-----------|---------|
| O1 | Sin manejo de errores | Transacción automática de Data API + verificación post-paso 1 | design.md §8 |
| O2 | Sin ANALYZE entre pasos | ANALYZE después de cada CREATE TABLE AS | design.md §7 |
| O3 | Tablas staging no se limpian entre invocaciones | DROP IF EXISTS al inicio de cada invocación | design.md §6 |
| O4 | Sin validación de diccionario vacío | Verificar COUNT después de paso 1 | design.md §8 |

### De negocio (aplicados)

| # | Problema | Corrección | Archivo |
|---|---------|-----------|---------|
| N1 | Objetivo dice "diferente nivel" pero Esc 3 NIT es mismo nivel | Objetivo corregido: "necesitan combinarse" (genérico) | requirements.md §1 |
| N2 | Campos heredados no definidos | Tabla completa con 15 campos y valores | requirements.md §4 |
| N3 | DIRECCION_FISICA vs tipo de uso | Documentado: DF independiente de tipo, RPU depende de tipo | requirements.md §4 |
| N4 | Pasos 3-6 mezclan Teradata con Redshift | Nota: pasos son referencia Teradata, implementar desde design.md | requirements.md §3 |

---

## 2. Hallazgos del comité de diseño (pendientes de resolver)

Estos hallazgos requieren decisión o validación antes de implementar.

### Funcionales pendientes

| # | Hallazgo | Impacto | Acción requerida |
|---|---------|---------|-----------------|
| FP1 | Espacios dobles en concatenación | Bajo — TRIM aplicado | ✅ Resuelto en design.md paso 7 |
| FP2 | Complemento > 100 chars | Bajo — LEFT(100) aplicado | ✅ Resuelto en design.md paso 7 |
| FP3 | Sin caso de prueba con 3+ direcciones | Medio | Crear dato mock P20 con 3 dirs antes de validar |
| FP4 | Pasos 3-6 de requirements confunden al implementador | Medio | ✅ Resuelto con nota en requirements.md §3 |

### Técnicos pendientes

| # | Hallazgo | Impacto | Acción requerida |
|---|---------|---------|-----------------|
| TP1 | Nomenclatura no en catálogo NOMENCLATURA | Bajo — COALESCE(99) aplicado | ✅ Resuelto |
| TP2 | Comparación semántica vs posicional (caso 4) | Medio | Validar con datos reales. Documentado como riesgo aceptado |

### Operativos pendientes

| # | Hallazgo | Impacto | Acción requerida |
|---|---------|---------|-----------------|
| OP1 | Sin timeout definido | Bajo | Documentado: esperado < 30 min, max 4h del cluster |
| OP2 | Sin métricas de observabilidad | Medio | Agregar INSERT a bdm_mtdat.log_rs después de cada invocación |
| OP3 | Sin estrategia de retry | Bajo | Motor es idempotente por diseño (DROP IF EXISTS) |
| OP4 | Ejecuciones paralelas pisan staging | Alto | Documentado: DEBEN ser secuenciales. deploy_order.par lo garantiza |

### Seguridad pendientes

| # | Hallazgo | Impacto | Acción requerida |
|---|---------|---------|-----------------|
| SP1 | IDs predecibles | Bajo | Aceptable para batch interno. No hay exposición externa |
| SP2 | Input podría contener direcciones bloqueadas | Alto | Agregar a precondiciones: escenario invocante debe excluir bloqueos |

---

## 3. Invariantes del sistema

| # | Invariante | Verificación |
|---|-----------|-------------|
| I1 | Dirección padre NUNCA tiene Ind_Unificacion=1 | Query post-ejecución |
| I2 | Dirección hija tiene exactamente 1 padre en UNIFICACION_DIRECCION | COUNT GROUP BY = 1 |
| I3 | Dirección generada (Generada_Enriquecida=1) SIEMPRE es padre | JOIN DF + UNIF_DIR |
| I4 | Complemento generado = concatenación de complementos de hijas | Comparación string |
| I5 | IDs generados NUNCA colisionan con existentes | MAX(id) post > MAX(id) pre |
| I6 | Motor es idempotente — re-ejecutar produce mismo resultado | Ejecutar 2 veces, comparar |
| I7 | Tablas staging NO persisten después de ejecución | pg_tables check |
| I8 | DICCIONARIO_COMPLEMENTOS no se modifica por el motor | COUNT pre = COUNT post |

---

## 4. Matriz de cobertura

| Req | Scenario | Precondition | Trigger | Expected | Failure Mode | Observability | Test |
|-----|----------|-------------|---------|----------|-------------|---------------|------|
| Combinar 2 compl diferentes | P09: "TO 3"+"AP 504" | Diccionario tiene datos | Motor | "TO 3 AP 504" | Diccionario vacío→0 | COUNT resultado | TC-01 |
| Misma nom ≠ valor | P07: "LC 101"+"LC 205" | NIT, diccionario ok | Motor | "LC 101 LC 205" | Semántica omite LC 205 | Verificar compl exacto | TC-02 |
| Valor no numérico | "BR CASTILLA"+"AP 504" | Diccionario ok | Motor | "BR CASTILLA AP 504" | CAST falla | valor_num=0 | TC-03 |
| 3+ direcciones | "TO 3"+"AP 504"+"BR SUBA" | 3 dirs en input | Motor | Combinación de 3 | Solo 2 se combinan | COUNT hijos | TC-04 |
| Dir ya existe | "TO 3 AP 504" pre-existe | En DIRECCION_FISICA | Motor | Reusar ID | ID duplicado | No INSERT en DF | TC-05 |
| Diccionario vacío | Input ok, diccionario no | Sin filas | Motor | 0 resultados, log | Falla silenciosa | COUNT descomp=0 | TC-06 |
| Compl > 100 chars | Padre 60 + hijo 50 | Ambos en input | Motor | Truncado a 100 | INSERT falla | LEN(compl) | TC-07 |
| Nom no en catálogo | "XX" no en NOMENCLATURA | LEFT JOIN NULL | Motor | nivel=99 | MDIR NULL | No NULLs en mdir | TC-08 |
| LIKE match parcial | "AP 101", dict tiene "AP 10" | Ambos matchean | Motor | Solo "AP 101" | Fila espuria | COUNT descomp | TC-09 |
| Idempotencia | Motor ya ejecutado | Staging existe | Re-ejecutar | Mismo resultado | Duplicados | COUNT pre=post | TC-10 |
| Paralelo | 2 escenarios simultáneos | Ambos escriben stg | Paralelo | Fallo | Staging pisado | Error en log | TC-11 |
| Rollback parcial | Falla en paso 5 | Pasos 1-4 ok | Rollback | Staging limpio | Staging huérfano | No stg_motor_* | TC-12 |

---

## 5. Puntos de interpretación ambigua (resueltos)

| # | Punto | Resolución |
|---|-------|-----------|
| A1 | "Mayor jerarquía" en MDIR | MDIR=1 = nivel_complemento más BAJO (más específico). Desempate por cod_dw_persona_ubic ASC |
| A2 | Comparación semántica vs posicional | Semántica (LEFT JOIN + IS NULL). Riesgo caso 4 documentado y aceptado |
| A3 | "Concatenar nomenclaturas de TODOS los hijos" | nueva_nomenclatura (solo lo que difiere), no complemento completo |
| A4 | ORDER BY MDIR DESC | Replica Teradata. Hijo de menor jerarquía va primero en concatenación |
| A5 | Match en DIRECCION_FISICA | Match exacto con TRIM, sin UPPER (datos ya estandarizados) |
| A6 | GROUP BY + ROW_NUMBER | Separado en 2 subqueries (paso 1a + 1b) |
| A7 | ¿Motor modifica tablas permanentes? | NO. Motor escribe en stg_motor_resultado. El escenario invocante hace INSERTs/UPDATEs a tablas permanentes |

---

*Revisión consolidada: 2026-04-21 | 20 correcciones aplicadas + 12 hallazgos pendientes + 8 invariantes + 12 test cases + 7 ambigüedades resueltas*
