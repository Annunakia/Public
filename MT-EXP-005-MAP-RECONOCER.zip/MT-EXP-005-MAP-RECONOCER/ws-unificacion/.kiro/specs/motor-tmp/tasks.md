# Tasks: Implementación del Motor de Nuevas Direcciones en Redshift

> Checklist de implementación. Referencia: requirements.md + design.md

---

## Tareas

- [x] 1. Crear `06_motor_nuevas_direcciones.sql` con el motor reutilizable
  - [x] 1.1 Paso 1: Descomponer complementos (stg_motor_nomenclaturas)
  - [x] 1.2 Paso 2: Agrupar nomenclaturas (stg_motor_agrupado) con LISTAGG
  - [x] 1.3 Paso 3: Calcular MDIR jerarquía (stg_motor_jerarquia)
  - [x] 1.4 Paso 4: Identificar padre (MDIR=1) e hijo (MDIR>1)
  - [x] 1.5 Paso 5: Generar código comparación + nueva nomenclatura con LISTAGG
  - [x] 1.6 Paso 6: Construir nueva dirección (complemento_padre + nueva_nomenclatura)
  - [x] 1.7 Paso 7: Verificar existencia en DIRECCION_FISICA, generar IDs
  - [x] 1.8 Paso 8: INSERT en DIRECCION_FISICA (Generada_Enriquecida=1)
  - [x] 1.9 Paso 9: INSERT en RELACION_PERSONA_UBICACION (nueva relación)
  - [x] 1.10 Paso 10: INSERT en UNIFICACION_DIRECCION (pares padre-hijo)
  - [x] 1.11 Paso 11: UPDATE Ind_Unificacion=1 en hijas originales
  - [x] 1.12 Paso 12: UPDATE stg_regla2_e2 con nuevos pares
  - [x] 1.13 ANALYZE en todas las tablas modificadas

- [x] 2. Crear `07_regla2_esc3_nit.sql` que prepara input y llama al motor
  - [x] 2.1 Filtrar registros NIT no-unificados de stg_regla2_e2
  - [x] 2.2 Preparar stg_motor_input con pares de misma nomenclatura ≠ valor
  - [x] 2.3 Ejecutar motor (incluir SQL de 06_motor)
  - [x] 2.4 Actualizar stg_regla2_e2

- [x] 3. Crear rollback scripts
  - [x] 3.1 06_rollback_motor_nuevas_direcciones.sql
  - [x] 3.2 07_rollback_regla2_esc3_nit.sql

- [x] 4. Actualizar deploy_order.par

- [ ] 5. Validar en sandbox
  - [ ] 5.1 Cargar datos mock P07 (NIT, LC 101 + LC 205)
  - [ ] 5.2 Ejecutar scripts 06 + 07
  - [ ] 5.3 Verificar: nueva dirección "LC 101 LC 205" creada en DIRECCION_FISICA
  - [ ] 5.4 Verificar: P07-A y P07-B marcados como hijos
  - [ ] 5.5 Verificar: nueva relación persona-ubicación creada
  - [ ] 5.6 Verificar: 0 falsos positivos en reglas anteriores (R1 + R2 Esc1-3)

---

*Tasks: 2026-04-21 | Referencia: design.md*
