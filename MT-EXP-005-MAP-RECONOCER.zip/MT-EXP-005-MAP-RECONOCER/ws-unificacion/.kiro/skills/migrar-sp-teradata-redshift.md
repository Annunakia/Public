# Skill: Migrar Stored Procedure Teradata → Redshift SQL

## Cuándo usar
Cuando se necesite migrar una regla o escenario del proceso de Unificación de Teradata a Amazon Redshift.

## Inputs requeridos
1. Código fuente Teradata (SP o script) con las líneas específicas del escenario
2. Documento funcional con la lógica de negocio del escenario
3. Datos mock relevantes para validar

## Pasos

### 1. Entender la lógica de negocio
- Leer `docs/funcional/documento_funcional_v1.md` para el escenario específico
- Leer `docs/tecnico/mapeo_escenarios_codigo.md` para ubicar las líneas exactas en el SP
- Identificar: criterio de agrupación, criterio de selección del padre, si genera direcciones nuevas

### 2. Leer el código Teradata
- Abrir el SP indicado en `src/teradata/`
- Extraer solo las líneas del escenario (según mapeo)
- Identificar: tablas de entrada, tablas de salida, JOINs, funciones Teradata usadas

### 3. Traducir a Redshift SQL
Aplicar las reglas de los steering files:

**De `sql-redshift-xpm.md`:**
- Sin CTEs recursivos → usar tablas de staging en `bdm_tempo`
- Sin ON CONFLICT → usar DELETE + INSERT o MERGE
- Sin LATERAL JOIN → usar subqueries
- Columnas con puntos entre comillas dobles
- Scripts idempotentes: `CREATE OR REPLACE`, `IF NOT EXISTS`, `DROP IF EXISTS`

**De `ambiente-redshift-cliente.md`:**
- Tablas permanentes → schema `bdm_datos`
- Tablas de staging → schema `bdm_tempo` (volátil, se limpia al final)
- Puerto 5440, SSL obligatorio

**De `modelo-datos-xpm.md`:**
- Encoding: AZ64 (BIGINT/INT), ZSTD (VARCHAR corto), BYTEDICT (baja cardinalidad)
- DISTKEY: `id_buro_persona` para tablas de persona, `cod_dw_ubic` para ubicación
- DISTSTYLE ALL para tablas lookup pequeñas
- ANALYZE después de cada CREATE TABLE AS y cada INSERT/UPDATE

**De `estandar-paquete-deploy-sql.md`:**
- Prefijo numérico: `NN_nombre.sql`
- Rollback en `rev-sql/NN_rollback_nombre.sql`
- Actualizar `deploy_order.par`

### 4. Crear rollback
- Revertir INSERTs con DELETE WHERE condición específica de la regla/escenario
- Revertir UPDATEs con SET al valor anterior
- DROP IF EXISTS para tablas de staging
- ANALYZE al final

### 5. Validar contra datos mock
- Cargar datos mock en `bdm_datos` (si no están)
- Ejecutar el script
- Comparar resultado con `data/mock/README_datos_mock.md` (resultado esperado)
- Verificar: pares padre-hijo correctos, 0 falsos positivos, hijos marcados

### 6. Actualizar deploy_order.par
- Agregar nuevo script en sección [SQL]
- Agregar rollback en sección [REV-SQL] (orden inverso)

## Equivalencias Teradata → Redshift

| Teradata | Redshift |
|----------|----------|
| `QUALIFY ROW_NUMBER()` | `ROW_NUMBER() OVER()` en subquery o CTE |
| `SAMPLE` | `ORDER BY RANDOM() LIMIT N` |
| `LOCKING ROW FOR ACCESS` | No necesario (MVCC) |
| `VOLATILE TABLE` | `CREATE TABLE bdm_tempo.stg_*` + DROP al final |
| `COLLECT STATISTICS` | `ANALYZE` |
| `TRIM(BOTH FROM x)` | `TRIM(x)` |
| `INDEX(str, substr)` | `POSITION(substr IN str)` o `STRPOS(str, substr)` |
| `OREPLACE(str, old, new)` | `REPLACE(str, old, new)` |
| `CHARACTERS(str)` | `LEN(str)` |
| `ZEROIFNULL(x)` | `COALESCE(x, 0)` |
| `NULLIFZERO(x)` | `NULLIF(x, 0)` |
