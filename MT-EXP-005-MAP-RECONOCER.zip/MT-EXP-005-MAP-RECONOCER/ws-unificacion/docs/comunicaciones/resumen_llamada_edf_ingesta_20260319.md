# Resumen – Llamada con Equipo EDF/Ingesta (Estandarización y PINNING)
**Fecha**: 19 de marzo de 2026  
**Tipo**: Llamada técnica con equipo EDF/Ingesta  
**Participantes**: Equipo Macondotek (Adriana, Juan Carlos, Wilmar) + Equipo EDF/Ingesta Experian

---

## Contexto

Sesión para definir en qué etapa del pipeline EDF se implementará la nueva estandarización de direcciones de Reconocer, y aclarar el impacto (o no) en PINNING.

---

## Decisiones y Acuerdos Clave

### 1. Estandarización se hace en CURATION
- La nueva estandarización de direcciones se implementará en la etapa de **Curation** del pipeline EDF.
- Se creará un **campo nuevo** (ej: "nueva dirección estandarizada") en la salida de Curation.
- El campo existente de dirección estandarizada **no se modifica**. Sigue funcionando con las reglas básicas heredadas de Cobol.
- El nuevo campo se mostrará en el **XPM** como campo adicional.

### 2. PINNING no se toca
- PINNING **no se modifica** como parte de este proyecto.
- El nuevo campo estandarizado **no será consumido por PINNING** inicialmente.
- PINNING sigue usando los campos actuales (dirección estandarizada con reglas básicas).
- **No hay impacto en PINNING**: solo se puebla un campo nuevo que PINNING ignora.

### 3. Integración futura con PINNING (opcional)
- Si en el futuro se decide usar el nuevo campo para PINNING, solo se requiere modificar el archivo de configuración `IdentifyingAttributesConfig`.
- Se tendría que apagar la estandarización actual en PINNING para evitar conflictos.
- Requiere pruebas de regresión y análisis interno del equipo de ingesta.
- Esta decisión **no es parte del alcance actual** del proyecto.

### 4. Nombre del campo debe ser único
- El nombre que se escoja para el nuevo campo **no puede coincidir** con ningún campo existente de ninguna fuente en EDF.
- Se requiere una búsqueda previa en todos los archivos de configuración.
- **Precondición** para la implementación.

### 5. Independencia de proyectos
- Con esta definición, el proyecto Reconocer avanza **sin afectar ni depender de PINNING**.
- El equipo de ingesta analizará internamente los resultados del nuevo campo y decidirá si lo adopta para PINNING en una fase posterior.

---

## Información Técnica Relevante

### Proceso de Curation en EDF

| Tipo | Frecuencia | Alcance |
|------|-----------|---------|
| Curation diaria | Diaria | Solo deltas entrantes (datos nuevos del día) |
| Curation Stop | Cada 1-2 semanas | Todos los datos aceptados (4 años de histórico) |

- **Curation diaria**: Se ejecuta como parte del pipeline normal (preparación → validación → aceptación → curación). Procesa solo los datos entrantes del día.
- **Curation Stop**: Re-procesa todos los datos aceptados presentes (4 años). Útil cuando cambia una regla de estandarización, un catálogo, o se borran datos. También mejora el desempeño de PINNING porque crea archivos particionados.

### Estandarización actual en EDF (reglas básicas de Cobol)

Lo que EDF hace hoy para estandarizar direcciones:
1. Reemplazar caracteres especiales y letras con espacios
2. Segmentar por dígitos
3. Rellenar con ceros (padding)
4. Validar longitud (>5 → nulo)
5. Concatenar segmentos
6. Ordenar de mayor a menor

Estas reglas son significativamente más simples que el proceso de 8 etapas de Reconocer en Teradata.

### Campos que PINNING consume de Curation
- Dirección residencial, laboral y de correspondencia estandarizadas
- Nombre estandarizado
- Tipo y número de identificación estandarizados

### Restricción de transformación en PINNING
- Durante PINNING **no se pueden transformar datos**. Cada etapa del pipeline tiene sus propias reglas.
- PINNING solo adjunta un número de TIN a cada registro y agrupa registros con base en ese número.
- Si se requiere estandarización, **debe pasar por Curation**.

---

## Campos configurables para PINNING

Los campos que PINNING utiliza se definen en el archivo de configuración `IdentifyingAttributesConfig`. Para cambiar qué campo de dirección usa PINNING, solo se modifica este archivo (sin cambiar código).

---

## Conclusión

Se logró el objetivo de la llamada: definir que la estandarización va en Curation como campo nuevo, sin impacto en PINNING, y con independencia total entre los proyectos. El equipo de ingesta evaluará internamente si adopta el nuevo campo para PINNING en el futuro.
