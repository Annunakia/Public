# Transcripción – Reunión Producto Reconocer - Sesión de Contexto Funcional

**Fecha**: 25 de marzo de 2026
**Tipo**: Sesión de contexto funcional del producto Reconocer
**Fuente**: [Notion Meeting Notes](https://www.notion.so/32ef666e815180049b82c2729eccf40c)

---

## Elementos de Acción

- [ ] Diego, Fernando y Natalia: Revisar y validar el proceso de contactabilidad OTP (P0003) para determinar si está en uso, qué valor genera al producto y de dónde provienen los datos
- [ ] Equipo técnico: Validar el estado actual y frecuencia de actualización de la fuente ARGIS para enriquecimiento de georreferenciación
- [ ] Todos: Preparar para la siguiente sesión el recorrido detallado por todas las etapas de construcción del producto Reconocer (enriquecimiento, algoritmos de ordenamiento, etc.)
- [ ] Diego: Enviar cuadro comparativo de versiones de Reconocer por canal de consumo

---

## Descripción del Producto Reconocer

- Reconocer es un producto de Experian que analiza toda la información de contacto reportada por suscriptores al buró de crédito
- Estandariza y consolida datos de contacto (direcciones, teléfonos, correos electrónicos) de múltiples entidades financieras
- Genera un ranking de datos de contacto basado en cantidad de entidades, reportes y cuentas abiertas
- Orientado principalmente a cobranza y contactabilidad de clientes

---

## Versiones del Producto

- **Reconocer Máster** es la versión actual en producción (más de 5 años en el mercado)

### Versiones en Línea (Portal)

- **Esencial**: versión básica con menor cantidad de campos de salida
- **Entorno**: versión intermedia
- **Avanzada**: versión con más campos
- **Geo**: versión con georreferenciación para clientes específicos

### Versiones en Microservicios

- Validación
- Validación con enriquecimiento

### Versiones en Batch

- 8 versiones totales incluyendo: Esencial, Digital, Ampliado, Conocimiento del Cliente, Validación, Entorno, Avanzado, e Índice de Contactabilidad

---

## Canales de Consumo

### Portal (Lotes)

- Consulta individual de usuarios
- Consulta en lote (hasta 99 registros, máximo 10MB)
- Genera PDFs individuales por cada cédula válida

### Web Service

- Consultas individuales en línea
- Utiliza información precalculada almacenada en DB2

### Batch

- Lotes masivos más grandes con costos diferenciados
- Genera archivo Excel consolidado con pestañas
- Utiliza información de Teradata (no la precalculada de DB2)

---

## Arquitectura Técnica

### Componentes principales

- **DB2**: almacena tablas precalculadas, estados de procesos y consecutivos
- **Teradata**: fuente de datos para procesamiento batch
- **Control-M**: orquesta la ejecución de procesos batch
- **Bizagio (BPM)**: gestión de flujos de casos
- **S3 Data Loading**: almacenamiento de archivos cargados

### Flujo de procesamiento batch

1. **Inicio**: validación de formato y estructura del archivo
2. **Sincronización**
3. **Explotación** de información en Teradata
4. **Transferencia** de archivos
5. **Alistamiento**: generación de plantillas Excel
6. **Cierre**: cierre de caso en Bizagio y actualización en DB2

### Web Services

- **WebUtil**: gestión de estados y fechas
- **Solicitud Batch**
- **WebService**: orquestación del proceso batch

---

## Fuentes de Datos Actuales

### ICBD (Buró de Crédito)

- Fuente principal de información de contacto
- Contiene datos reportados por suscriptores (entidades financieras)

### ARGIS

- Enriquecimiento de georreferenciación (barrio y estrato)
- Requiere validación sobre frecuencia de actualización

### Contactabilidad OTP (Evidente)

- Proceso P0003 que se ejecuta diariamente
- Requiere investigación sobre uso actual y fuente de datos

---

## Proyecto de Modernización

**Objetivo**: Migración/modernización del producto a la nube en IDF

### Consideraciones clave

- **Restricción legal**: no se pueden mezclar datos del buró de crédito tradicional con datos de Nueva Data que requieren consentimiento
- La estandarización de datos se moverá al equipo de datos (fuera del alcance de Reconocer)
- Reconocer trabajará con datos ya estandarizados para aplicar algoritmos de ordenamiento y precálculos

### Nuevas fuentes planificadas

- **ICS (Mi Data Crédito)**: datos de contacto con autorizaciones y consentimientos de ciudadanos
- **Meta/WhatsApp**: validación de números con WhatsApp habilitado vía web service
- Otras fuentes externas para probabilidad de contacto efectivo

### Estado de integración ICS

- En el modelo actual de Reconocer, la data de ICS **NO** está incluida
- Una vez migrado a IDF, se podría complementar priorizando datos de Mi Data Crédito
- Depende del alcance final del proyecto

---

## Diferencias entre Versiones

- Las versiones difieren en la cantidad de datos de contacto entregados
- Ejemplo Esencial: entrega 2 celulares, 2 correos, 2 direcciones
- Todas las versiones se basan en el mismo modelo precalculado completo que contiene todos los datos de contacto históricos
- La estructura de datos de salida cambia entre versiones

---

## Temas Pendientes para Próximas Sesiones

- Recorrido detallado por etapas de construcción del producto
- Algoritmos de ordenamiento para celulares, direcciones y teléfonos (cada uno con formato diferente)
- Reglas de priorización de fuentes (ej: si Bancolombia tiene más peso que Davivienda)
- Integración con ARGIS: formato de intercambio, tiempos de respuesta, frecuencia
- Proceso de enriquecimiento en detalle
- Trazabilidad de datos en el cálculo del producto
