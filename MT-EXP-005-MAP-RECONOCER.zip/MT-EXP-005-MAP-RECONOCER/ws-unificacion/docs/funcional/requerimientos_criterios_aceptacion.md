# Requerimientos y Criterios de Aceptación — Unificación de Direcciones

> **Proceso**: Unificación de Direcciones Físicas
> **Origen**: Teradata (P0019, P0020, P0021) | **Destino**: Amazon Redshift
> **Versión**: 1.0 | **Fecha**: 12 de mayo de 2026

---

## Objetivo del Proceso

Consolidar direcciones duplicadas de una misma persona, eliminando redundancias y generando un ranking limpio de direcciones listo para el proceso de Ordenamiento. Se aplican 3 reglas en cascada.

---

## Regla 1 — Unificación por Tipo de Uso + CIIU

### Requerimiento

Cuando una persona tiene la misma dirección (misma puerta + misma ciudad) reportada con diferentes tipos de uso (RES, LAB, CRR), el sistema debe escoger una como "padre" y marcar las demás como "hijas" según la actividad económica (CIIU) de la persona.

### Criterios de Aceptación

| ID | Criterio | Verificación |
|:--:|----------|:-------------|
| R1-01 | Si CIIU=10 (asalariado), el padre es la dirección LAB o CRR con mayor número de entidades | `WHERE ciiu=10 AND tipo_padre IN ('LAB','CRR')` |
| R1-02 | Si CIIU=81,82,90 (sin actividad), el padre es la dirección RES o CRR con mayor número de entidades | `WHERE ciiu IN (81,82,90) AND tipo_padre IN ('RES','CRR')` |
| R1-03 | Para cualquier otro CIIU, el padre es la dirección con mayor número de entidades sin importar tipo | `COUNT(DISTINCT suscriptor) padre >= COUNT hijo` |
| R1-04 | El hijo queda marcado con `ind_unificacion = 1` | `SELECT COUNT(*) FROM rpu WHERE ind_unificacion=1` |
| R1-05 | Se inserta un registro en `unificacion_direccion` con `unifica_atributos = 1` | Par padre-hijo registrado |
| R1-06 | Direcciones ya unificadas (`ind_unificacion=1`) o bloqueadas NO se procesan | Filtro en insumo |

---

## Regla 2 — Unificación por Complementos

### Requerimiento

Cuando una persona tiene la misma dirección (misma puerta + misma ciudad + mismo barrio) con diferentes complementos, el sistema debe decidir cuál queda como padre según 6 escenarios. En algunos casos genera una nueva dirección combinando complementos.

### Criterios de Aceptación

| ID | Criterio | Verificación |
|:--:|----------|:-------------|
| R2-01 | Esc 1 (vacío): Si un complemento es vacío y otro no, queda el que tiene complemento | Padre tiene `complemento IS NOT NULL AND complemento <> ''` |
| R2-02 | Esc 2 (incluido): Si un complemento contiene al otro, queda el más completo | `LENGTH(complemento_padre) >= LENGTH(complemento_hijo)` |
| R2-03 | Esc 3 sin NIT: Misma nomenclatura, diferente valor → mayor entidades gana | `entidades_padre >= entidades_hijo` |
| R2-04 | Esc 3 NIT: Misma nomenclatura, diferente valor, tipo NIT → genera nueva dirección combinando ambos | Nueva dirección con `generada_enriquecida = 1` |
| R2-05 | Esc 4: Nomenclaturas diferentes, mismo nivel → diccionario de frecuencias decide | Padre tiene nomenclatura con mayor frecuencia en diccionario |
| R2-06 | Esc 5: Nomenclaturas diferentes, diferente nivel → genera nueva dirección combinando | Nueva dirección contiene nomenclaturas de ambas hijas |
| R2-07 | Esc 6: Ninguna contenida en otra → combina si niveles diferentes, diccionario si mismo nivel | Según subcaso |
| R2-08 | Nuevas direcciones tienen `generada_enriquecida = 1` en DIRECCION_FISICA | `COUNT(*) WHERE generada_enriquecida=1 > 0` (cuando aplica) |
| R2-09 | Nuevas direcciones tienen relación en RELACION_PERSONA_UBICACION | JOIN entre nueva dir y RPU existe |
| R2-10 | El padre NUNCA tiene `ind_unificacion = 1` | Invariante: `WHERE es_padre AND ind_unificacion=1` debe ser 0 |
| R2-11 | Cada hija tiene exactamente 1 padre | `GROUP BY hijo HAVING COUNT(padre) > 1` debe ser 0 |

---

## Regla 3 — Unificación por Geolocalización

### Requerimiento

Cuando una persona tiene direcciones que difieren en vía generadora o número de puerta (mismo departamento + ciudad + zona, solo tipo Vía), el sistema debe decidir cuál queda como padre usando latitud/longitud y diccionario de frecuencias de vía.

### Criterios de Aceptación

| ID | Criterio | Verificación |
|:--:|----------|:-------------|
| R3-01 | Solo procesa direcciones tipo Vía (excluye Manzana y Rural) | Filtro en insumo |
| R3-02 | Esc 1 (vía generadora): Si solo una tiene lat/long, queda la geolocalizada | Padre tiene `latitud IS NOT NULL` |
| R3-03 | Esc 1: Si ninguna tiene lat/long, queda la de mayor fecha actualización | `fecha_padre >= fecha_hijo` |
| R3-04 | Esc 1: Si ambas tienen lat/long, diccionario de vía decide (mayor frecuencia) | Padre tiene vía con mayor frecuencia |
| R3-05 | Esc 2 (puerta): Valida diferencia ±2 posiciones antes de unificar | `ABS(puerta_a - puerta_b) <= 2` |
| R3-06 | Esc 2: Si diferencia > 2, NO unifica | No se genera par padre-hijo |
| R3-07 | Se inserta registro en `unificacion_direccion` con `unifica_atributos = 1` | Par registrado |

---

## Reglas Generales (aplican a las 3 reglas)

| ID | Criterio | Verificación |
|:--:|----------|:-------------|
| G-01 | Las reglas se ejecutan en cascada: R1 → R2 → R3 | Un hijo de R1 no entra a R2 ni R3 |
| G-02 | Un padre de R1 puede ser hijo en R2 | Cascada permite re-procesamiento |
| G-03 | Direcciones con `ind_unificacion = 1` no se re-procesan | Filtro `WHERE ind_unificacion IS NULL` en insumo |
| G-04 | Direcciones bloqueadas no se procesan | LEFT JOIN con BLOQUEO, excluir matches |
| G-05 | Toda unificación genera un registro en `unificacion_direccion` (trazabilidad) | `COUNT(unificacion_direccion) = COUNT(hijos marcados)` |
| G-06 | El proceso es idempotente: ejecutar 2 veces no duplica resultados | Segunda ejecución no genera nuevos pares |

---

## Métricas de Validación (datos mock 20 personas)

| Métrica | Valor esperado | Verificado en sandbox |
|---------|:--------------:|:---------------------:|
| Pares R1 | 4 | ✅ |
| Pares R2 | 4 | ✅ |
| Pares R3 | 0 (sin lat/long en mock) | ✅ |
| Total hijos marcados | 8 | ✅ |
| Nuevas direcciones generadas | 0 (mock no tiene candidatos para motor) | ✅ |
| Relaciones sin unificar | 33 | ✅ |


---

## Consolidación de Criterios de Aceptación — Unificación

### Comparativo: Kidar vs Experian

La siguiente tabla consolida los criterios de aceptación propuestos por cada parte e identifica coincidencias. Los criterios de Kidar (antes Macondotek) se definieron durante la migración (mayo 2026). Los criterios de Experian provienen del "Documento Funcional V2 — Migración Unificación de Direcciones" (junio 2026).

#### Unificación — Regla 1

| ID | Criterio | Propuesto por | Coincide |
|:--:|----------|:-------------:|:--------:|
| R1-01 | CIIU=10 → padre es LAB o CRR con mayor entidades | Kidar | Ambos |
| R1-02 | CIIU=81,82,90 → padre es RES o CRR con mayor entidades | Kidar | Ambos |
| R1-03 | Otro CIIU → mayor entidades sin importar tipo | Kidar | Ambos |
| R1-04 | Hijo queda con `ind_unificacion = 1` | Kidar | Ambos |
| R1-05 | Se inserta par en `unificacion_direccion` | Kidar | Ambos |
| R1-06 | Bloqueadas e hijas previas no se procesan | Kidar | Ambos |
| R1-E1 | Baseline CIIU obligatorio: asalariado=10, sin actividad=81/82/90 (no usar asalariado 1-9 ni solo 81) | Experian | Ambos |
| R1-E2 | Empate persistente = no decisión, no se fuerza unificación | Experian | Ambos |

#### Unificación — Regla 2

| ID | Criterio | Propuesto por | Coincide |
|:--:|----------|:-------------:|:--------:|
| R2-01 | Esc 1: vacío vs informado → gana el informado | Kidar | Ambos |
| R2-02 | Esc 2: incluido → gana el más completo | Kidar | Ambos |
| R2-03 | Esc 3 sin NIT: misma nomenclatura, ≠ valor → mayor entidades | Kidar | Ambos |
| R2-04 | Esc 3 NIT: genera nueva dirección combinando valores | Kidar | Ambos |
| R2-05 | Esc 4: ≠ nomenclatura, mismo nivel → diccionario frecuencias | Kidar | Ambos |
| R2-06 | Esc 5: ≠ nivel → genera nueva dirección combinando | Kidar | Ambos |
| R2-07 | Esc 6: ninguna contenida → combina o diccionario según nivel | Kidar | Ambos |
| R2-08 | Nuevas direcciones marcadas con `generada_enriquecida = 1` | Kidar | Kidar |
| R2-09 | Nuevas direcciones tienen relación en RPU | Kidar | Kidar |
| R2-10 | Padre NUNCA tiene `ind_unificacion = 1` | Kidar | Ambos |
| R2-11 | Cada hija tiene exactamente 1 padre | Kidar | Kidar |
| R2-E1 | Corrección de complementos generados: no duplicidad, completitud, legibilidad, orden lógico | Experian | Ambos |
| R2-E2 | Diccionario conserva decisión funcional basada en frecuencia (independiente de implementación) | Experian | Ambos |
| R2-E3 | Empate persistente = no decisión | Experian | Ambos |

#### Unificación — Regla 3

| ID | Criterio | Propuesto por | Coincide |
|:--:|----------|:-------------:|:--------:|
| R3-01 | Solo tipo Vía (excluye Manzana y Rural) | Kidar | Ambos |
| R3-02 | Solo una con lat/long → gana la geolocalizada | Kidar | Ambos |
| R3-03 | Ninguna con lat/long → fecha más reciente, luego entidades | Kidar | Ambos |
| R3-04 | Ambas con lat/long → diccionario de vía por frecuencia | Kidar | Ambos |
| R3-05 | Diferencia puerta: valida umbral ±2 | Kidar | Ambos |
| R3-06 | Diferencia > 2 → NO unifica | Kidar | Ambos |
| R3-E1 | Modificadores de vía (B, C, F, BIS) excluyen la dirección | Experian | Ambos |
| R3-E2 | Cuadrantes (N, S, E, O) se omiten para comparación pero no excluyen | Experian | Ambos |
| R3-E3 | Umbral ±2 aplica SOLO en subcaso "ambas con lat/long" (no globalmente) | Experian | Ambos |
| R3-E4 | Empate en diccionario = no decisión | Experian | Ambos |

#### Unificación — Reglas Generales

| ID | Criterio | Propuesto por | Coincide |
|:--:|----------|:-------------:|:--------:|
| G-01 | Cascada R1 → R2 → R3 | Kidar | Ambos |
| G-02 | Padre de R1 puede ser hijo en R2 | Kidar | Ambos |
| G-03 | `ind_unificacion = 1` no se re-procesa | Kidar | Ambos |
| G-04 | Bloqueadas no se procesan | Kidar | Ambos |
| G-05 | Toda unificación genera registro de trazabilidad | Kidar | Ambos |
| G-06 | Idempotencia | Kidar | Kidar |
| G-E1 | Nunca se comparan direcciones de personas diferentes | Experian | Ambos |
| G-E2 | No eliminación: unificación es lógica, no borra datos | Experian | Ambos |
| G-E3 | Hijas nunca pasan a ordenamiento | Experian | Ambos |
| G-E4 | Padres vigentes (existentes + generados) siempre pasan a ordenamiento | Experian | Ambos |
| G-E5 | Toda diferencia Teradata vs Redshift debe clasificarse, justificarse y aprobarse | Experian | Experian |
| G-E6 | Certificación incluye matriz de pruebas + muestras comparativas padre-hijo | Experian | Experian |

#### Unificación — Gobernanza de Migración (propuesto solo por Experian)

| ID | Criterio | Descripción |
|:--:|----------|-------------|
| GOB-01 | Toda diferencia debe clasificarse: error de migración, diferencia de datos, cambio funcional aprobado o no clasificada |
| GOB-02 | Diferencias no clasificadas no pueden aceptarse para producción |
| GOB-03 | Evolución funcional requiere aprobación formal de negocio |
| GOB-04 | Bitácora de diferencias con: ID, regla, caso, resultado Teradata, resultado Redshift, clasificación, impacto, responsable, decisión, aprobador |

---

## Criterios de Aceptación — Ordenamiento

> **Nota**: El documento de Experian (V2) cubre únicamente Unificación. Los siguientes criterios de aceptación para Ordenamiento fueron definidos por Kidar durante la migración.

| ID | Criterio | Propuesto por |
|:--:|----------|:-------------:|
| O-01 | Fase 1 materializa correctamente la unión BTT + REC sin duplicados | Kidar |
| O-02 | Fase 2 calcula atributos de cuenta (portafolio, saldos, comportamiento) sin NULL inesperados | Kidar |
| O-03 | Fase 2 genera hash MD5 de concatenación de atributos para detección de cambios | Kidar |
| O-04 | Fase 3 calcula características de ubicación (meses reportados, entidades, tipo persona) | Kidar |
| O-05 | Fase 3 genera hash MD5 de concatenación de ubicación | Kidar |
| O-06 | Fase 4 calcula score por canal (DIR, TEL, CEL, EMA) usando regresión logística (Betas × características) | Kidar |
| O-07 | Fase 4 genera ranking (`lugar`) por canal por persona: 1 = más probable de contactar | Kidar |
| O-08 | El campo `orden_prioridad` se actualiza en `relacion_persona_ubicacion` con el ranking final | Kidar |
| O-09 | Solo direcciones vigentes (no hijas) reciben score de Ordenamiento | Kidar |
| O-10 | Proceso idempotente: ejecutar dos veces produce el mismo resultado | Kidar |
| O-11 | Los coeficientes Beta deben coincidir con los vigentes de Teradata (`V_Beta_Ordenamiento_*`) | Kidar |
| O-12 | Cuentas bloqueadas se excluyen del cálculo de atributos | Kidar |

---

## Resumen de Consolidación

| | Kidar | Experian | Coincidencia |
|--|:-----:|:--------:|:------------:|
| Criterios Unificación R1 | 6 | 2 adicionales | 8 total — todos coinciden |
| Criterios Unificación R2 | 11 | 3 adicionales | 14 total — todos coinciden |
| Criterios Unificación R3 | 6 | 4 adicionales | 10 total — todos coinciden |
| Criterios Generales | 6 | 6 adicionales | 12 total — 10 coinciden, 2 solo Experian (gobernanza) |
| Gobernanza migración | — | 4 | Solo Experian |
| Criterios Ordenamiento | 12 | — | Solo Kidar |
| **Total** | **41** | **19** | **Alta coincidencia funcional** |

> **Conclusión**: Existe alineación funcional completa entre lo propuesto por Kidar y lo requerido por Experian para Unificación. Los criterios de Experian agregan formalizaciones de gobernanza (bitácora de diferencias, clasificación de errores, aprobación formal) que complementan los criterios técnicos de Kidar sin contradecirlos. Para Ordenamiento, los criterios son exclusivamente de Kidar ya que Experian aún no ha emitido documento funcional equivalente.
