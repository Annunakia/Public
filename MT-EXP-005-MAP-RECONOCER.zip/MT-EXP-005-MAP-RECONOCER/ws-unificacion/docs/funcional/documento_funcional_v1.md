# Documento Funcional – Algoritmo de Unificación de Direcciones Físicas

> **Versión**: 1.0 | **Autor**: Andy García – Arquitecto Teradata | **Fecha**: Enero 2019
> **Convertido a MD**: 2026-04-17 desde .docx original

---

## Objetivo

Explicar los detalles de la solución desarrollada para Experian del algoritmo de Unificación de Direcciones Físicas con ejemplos prácticos y funcionales.

---

## Contenido

1. Descripción General del Proceso
2. Reglas Generales de Unificación
3. Regla 1: Unificación por Tipo de Uso y CIIU
4. Regla 2: Direcciones Nuevas Generadas a partir de Direcciones Hijas
5. Regla 3: Direcciones Unificadas con Insumo GEO
6. Correcciones Complementos Resultado Unificación Regla 2
7. Apéndice: Lógica de Negocio (diagramas)

---

## 1. Descripción General del Proceso

Dentro de la solución **Reconocer Máster**, Experian estableció los lineamientos para generar valor de negocio a partir de la información de ubicaciones reportadas por los suscriptores y distintas fuentes hacia el buró.

Con la información de ubicación de personas, se desea conocer cuál es la ubicación más probable a la que se pueda contactar una persona (Ver Documentación Algoritmo Ordenamiento).

Para lograr esto, se toman todas las direcciones físicas ya estandarizadas y normalizadas (Ver Documento Algoritmo Estandarización) para realizar la **unificación**: un "borrado lógico" de aquellas direcciones que son iguales y que cambian por su Tipo de Uso (RES, LAB, CRR) o que se puedan generar nuevas y mejores direcciones físicas usando sus COMPLEMENTOS.

**Unificar**: Tomar las direcciones normalizadas de tipo vía y, a partir de su puerta y/o complemento, más el uso de variables como Latitud, Longitud, Número de meses de reporte, Número de entidades que reportan, Diccionario de Vía, entre otros elementos estadísticos y reglas de negocio, establecer cuál es la dirección que sería la mejor para su explotación en cuanto a uso y/o calidad por completitud, para luego ser tratadas por un proceso de ordenamiento.

---

## 2. Reglas Generales de Unificación

### 2.1 Unificación por pares (proceso recursivo)

La unificación se realiza por pares de direcciones para una misma persona. Si una persona cuenta con 3+ direcciones unificables, primero se unifican 2 y a partir del resultado se unifican con la tercera. Es un proceso recursivo.

### 2.2 Concepto Padre-Hijo

- **Padre Tipo 1**: Direcciones "Unificadoras" escogidas entre dos candidatas por determinada variable (resultado de Regla 1 y Regla 3).
- **Padre Tipo 2**: Direcciones "Unificadoras" que son el resultado de una **nueva dirección** generada a partir de los componentes de las dos direcciones hijas (resultado de Regla 2).

### 2.3 Hija no vuelve a entrar

Toda dirección que se torna en "Hija" no volverá a entrar al algoritmo de unificación. La marcación Padre-Hijo queda persistida en `REC_DATOS.UNIFICACION_DIRECCION`.

### 2.4 Cascada de reglas

Las reglas se aplican secuencialmente: **Regla 1 → Regla 2 → Regla 3**. El resultado de una es insumo de la siguiente. Direcciones "Padres" de una regla pueden ser "Hijas" en la siguiente. También entran direcciones que cumplan condiciones mínimas para ser candidatas.

### 2.5 Solo direcciones sin padres y sin bloqueos

Solo se toman direcciones hijas sin padres previos y sin bloqueos:
- **Unificadas**: `Ind_unificacion=1` en `REC_DATOS.RELACION_PERSONA_UBICACION`
- **Bloqueadas**: JOIN contra `REC_DATOS.BLOQUEO` por `Cod_DW_Persona_Ubic`

---

## 3. Regla 1: Unificación por Tipo de Uso y CIIU

Valida direcciones de una persona con la misma **Puerta** pero diferente **Tipo de Uso** (RES, LAB, CRR).

### Variables clave

| Variable | Descripción |
|----------|-------------|
| **CIIU** | Actividad Económica de la persona (Asalariado=10, Sin actividad=81/82/90, etc.) |
| **Tipo de Uso** | Descripción Tipo Ubicación Dir: RES, LAB, CRR, JUD, CCL |
| **Número de entidades** | Conteo distinto de suscriptores que reportan una misma ubicación |

### Insumo

Vista `REC_STAGE.V_Insumo_Unificacion_Regla1` — agrupa direcciones candidatas por:
- Address_Geo, Complement, Departamento, Código Localidad, Ciudad, Zona, Estrato

### Escenario 1: CIIU = 10 (Asalariado) + tipo LAB o CRR

a. Si una dirección no tiene LAB o CRR → se toma la que sí tenga.
b. Si ambas tienen LAB o CRR → se toma la de mayor "Número de entidades que reportan".

### Escenario 2: CIIU = 81, 82 o 90 (Sin Actividad) + tipo RES o CRR

a. Si una dirección no tiene RES o CRR → se toma la que sí tenga.
b. Si ambas tienen RES o CRR → se toma la de mayor "Número de entidades que reportan".

### Escenario 3: CIIU diferente a los anteriores

No se tiene en cuenta el tipo de dirección. Se escoge la de mayor "Número de entidades que reportan". Desempate por fecha de última actualización más reciente.

### Persistencia

- Relaciones padre-hijo en `REC_DATOS.UNIFICACION_DIRECCION` y `REC_DATOS.REPORTE_UNIFICACION_DIRECCION`
- En `REC_DATOS.RELACION_PERSONA_UBICACION`:
  - Se marca `Ind_Unificacion=1` para ubicaciones ya unificadas
  - Se actualiza fecha de modificación, Lote y Lote Actualización

---

## 4. Regla 2: Direcciones Nuevas Generadas a partir de Direcciones Hijas

### 4.1 Diccionario de Nomenclaturas (Complementos)

Herramienta que calcula el número de veces que se ha reportado cada nomenclatura para una dirección GEO.

**Ejemplo**: Para dirección GEO con complemento `TO 3 AP 404`:
- `TO 3` → 15 veces reportado
- `AP 404` → 5 veces reportado
- `BR CASTILLA` → 9 veces reportado

**Construcción**:
- Se construye durante el proceso de Unificación solo para direcciones fuente de Regla 2
- Conteo basado en tabla `VM_REPORTE_RELACION_PERS_UBI` (histórico de reportes)
- Se almacena en área STAGE, solo durante el proceso de unificación

### 4.2 Insumo

Vista `REC_STAGE.V_Insumo_Unificacion_Regla2` — direcciones con igualdad en:
- Address_Geo, Departamento, Código Localidad, Ciudad, Zona, Estrato, Barrio, Tipo de Dirección

Y que **difieren en la variable complemento**.

### 4.3 Escenarios

#### Escenario 1: Un complemento vacío

Se toma la dirección más completa (la que tiene complemento).

> Ejemplo: Puerta `CL 22 27 45` — una sin complemento, otra con `AP 802` → se toma la de `AP 802`.

#### Escenario 2: Un complemento incluido en el otro

Se toma la dirección más completa (la que contiene al otro).

> Ejemplo: Complemento `OF 702` vs `ED GALICIA OF 702` → se toma `ED GALICIA OF 702`.

#### Escenario 3: Misma nomenclatura, diferente valor

Se valida "Número de entidades que reportan". Se escoge la de mayor valor.

> Ejemplo: `AP 105` vs `AP 404` → se toma la de mayor entidades.

**Caso especial NIT**: Si tipo documento = NIT, se unen los textos de ambos complementos creando una **nueva dirección** en `DIRECCION_FISICA`.

**Desempate**: Si entidades iguales → fecha de última actualización más reciente.

#### Escenario 4: Varias nomenclaturas, una diferente, mismo nivel

Nomenclaturas contenidas en el otro pero una difiere. Si están al **mismo nivel** (tabla `NOMENCLATURA`):
- Se consulta el **Diccionario de Complementos**
- Se toma la de mayor frecuencia
- Desempate: fecha de actualización más reciente

#### Escenario 5: Varias nomenclaturas, una diferente, diferente nivel

**Subcaso 1** — Valores diferentes: Se arma un nuevo registro más completo que contenga ambas nomenclaturas y sus valores → **genera nueva dirección** en `DIRECCION_FISICA` + relación en `RELACION_PERSONA_UBICACION`.

**Subcaso 2** — Valores iguales: Se consulta el Diccionario, se toma la de mayor frecuencia. Desempate: fecha más reciente.

#### Escenario 6: Ninguna nomenclatura contenida en otra

- Si una está incluida en la otra (ej: `OF 20` incluida en `OF 2007`) → se toma la más completa, armando nuevo complemento.
- Si nomenclaturas no coinciden y están en **niveles diferentes** → se arma nuevo complemento uniendo ambas nomenclaturas → **genera nueva dirección**.
- Si están en **igual nivel** → se revisa Diccionario, se escoge la de mayor frecuencia.

---

## 5. Regla 3: Direcciones Unificadas con Insumo GEO

### 5.1 Precondiciones

- Requiere que se haya ejecutado el proceso de **Geocodificación** (servidor ESRI) y cargado latitud/longitud al modelo de datos.
- Solo aplica para direcciones **Tipo Vía** (excluye Manzana y Rurales).
- Direcciones con **modificadores de vía** (B, C, F, BIS, BBISS, etc.) quedan excluidas.
- **Indicadores de cuadrante** (norte, sur, este, oeste) no se tienen en cuenta para comparación (la dirección sí se procesa, pero se omiten estos indicadores).

### 5.2 Diccionario de Vía

Calcula el número de veces que se ha reportado las direcciones tipo vía, clasificados por diferencia en **vía generadora** o **número de puerta**.

**Ejemplo**: Para dirección GEO `CL 34 78 52`:
- Llave `CL 34 _ 52` → Vía generadora 78, reportada 15 veces
- Llave `CL 34 78 _` → Número puerta 52, reportada 11 veces

**Construcción**:
- Se construye durante Unificación solo para direcciones fuente de Regla 3
- Conteo basado en `VM_REPORTE_RELACION_PERS_UBI`
- Se almacena en área STAGE, se borra al finalizar

### 5.3 Insumo

Vista `REC_STAGE.V_Insumo_Unificacion_Regla3` — direcciones con igualdad en:
- Departamento, Código Localidad, Ciudad, Zona

Y que **difieren en la Puerta**, solo en valores de **Número de Vía Generadora (NUMVIAGEN)** o **Número de Puerta (NUMPLACA)** de tabla `DIRECCION_FISICA`.

Incluye: Latitud, Longitud, Fecha Reporte, Número de entidades (`ID_BURO_SUSCRIPTOR`).

### 5.4 Escenarios

#### Escenario 1: Diferencia en número de vía generadora

**Subcaso 1** — Solo uno tiene lat/long: Se toma el que tenga geolocalización.

**Subcaso 2** — Ninguno tiene lat/long: Se toma el de máxima fecha de última actualización. Desempate: mayor número de entidades. Si persiste empate: sin modificaciones.

**Subcaso 3** — Ambos tienen lat/long: Se busca en **Diccionario Vía** la frecuencia de las vías generadoras para la llave. Se toma la de mayor frecuencia. Si frecuencias iguales: sin alteraciones.

#### Escenario 2: Diferencia en número de puerta

**Subcaso 1** — Solo uno tiene lat/long: Se toma el que tenga geolocalización.

**Subcaso 2** — Ninguno tiene lat/long: Se toma el de máxima fecha de última actualización. Desempate: mayor número de entidades. Si persiste empate: sin modificaciones.

**Subcaso 3** — Ambos tienen lat/long: Primero se verifica que la diferencia entre números de puerta sea **± 2 posiciones**. Si es mayor → se mantienen sin cambios. Si cumple → se busca en **Diccionario Vía** (registros identificados por número de puerta) la frecuencia. Se toma la de mayor frecuencia. Si frecuencias iguales: sin alteraciones.

---

## 6. Correcciones Complementos Resultado Unificación Regla 2

Una vez realizada la unificación por Regla 2, se ejecuta una **función desarrollada en lenguaje C** que ajusta los resultados debido a que las salidas no son tan legibles y de buena calidad como se esperaban.

Escenarios que se corrigen:
- Duplicidad de nomenclaturas dentro de un complemento unificado
- Duplicidad de valores dentro de un complemento unificado

---

## 7. Tablas y Vistas del Modelo de Datos

### Tablas principales

| Tabla | Uso en Unificación |
|-------|-------------------|
| `REC_DATOS.RELACION_PERSONA_UBICACION` | Relación persona-ubicación. Flag `Ind_Unificacion=1` marca unificadas |
| `REC_DATOS.UNIFICACION_DIRECCION` | Persistencia de relaciones Padre-Hijo |
| `REC_DATOS.REPORTE_UNIFICACION_DIRECCION` | Reportes de unificación |
| `REC_DATOS.BLOQUEO` | Direcciones bloqueadas (excluidas de unificación) |
| `REC_DATOS.DIRECCION_FISICA` | Direcciones físicas. Regla 2 crea nuevos registros aquí |
| `REC_DATOS.NOMENCLATURA` | Niveles de nomenclaturas para comparación en Regla 2 |
| `VM_REPORTE_RELACION_PERS_UBI` | Histórico de reportes (fuente para diccionarios) |

### Vistas de insumo (esquema REC_STAGE)

| Vista | Regla | Campos de agrupación | Campo que difiere |
|-------|-------|---------------------|-------------------|
| `V_Insumo_Unificacion_Regla1` | 1 | Address_Geo, Complement, Depto, Cod Localidad, Ciudad, Zona, Estrato | Tipo de Uso |
| `V_Insumo_Unificacion_Regla2` | 2 | Address_Geo, Depto, Cod Localidad, Ciudad, Zona, Estrato, Barrio, Tipo Dir | Complemento |
| `V_Insumo_Unificacion_Regla3` | 3 | Depto, Cod Localidad, Ciudad, Zona | Puerta (NUMVIAGEN o NUMPLACA) |

### Diccionarios (temporales en STAGE)

| Diccionario | Regla | Contenido | Fuente |
|-------------|-------|-----------|--------|
| Diccionario de Nomenclaturas (Complementos) | 2 | Frecuencia de cada nomenclatura por dirección GEO | `VM_REPORTE_RELACION_PERS_UBI` |
| Diccionario de Vía | 3 | Frecuencia de vía generadora y número de puerta por llave | `VM_REPORTE_RELACION_PERS_UBI` |

---

## 8. Apéndice: Diagramas de Lógica de Negocio

> **Nota**: Los diagramas originales del .docx son imágenes EMF/PNG embebidas. Se listan como referencia. Consultar el documento original para visualización.

1. **Lógica de Negocio: Unificación Regla 1** — Diagrama de flujo de decisión
2. **Insumo Unificación Regla 2** — Diagrama de flujo de preparación de datos
3. **Insumo Diccionario de Complementos Regla 2** — Diagrama de construcción del diccionario
4. **Unificación de Direcciones: Regla 2** — Diagrama de flujo completo con escenarios
5. **Unificación Regla 3** — Diagrama de flujo completo con escenarios y subcasos

---

*Documento convertido desde: `Documento Funcional Unificacion Final V1.0.docx` (Andy García, Enero 2019)*
*Conversión: 2026-04-17 | Herramienta: pandoc + limpieza manual*
