# Análisis Técnico de Scripts – Proceso de Unificación

> Análisis del código fuente Teradata para migración. Actualizado 2026-04-17.

---

## Flujo de Ejecución

```
P0019 (Regla 1)                    P0020 (Regla 2)                    P0021 (Regla 3)
┌──────────────┐                   ┌──────────────┐                   ┌──────────────┐
│ _111 Setup   │                   │ _111 Setup   │                   │ _111 (no hay)│
│  Crea tablas │                   │  Crea tablas │                   │              │
│  stage 1,2,3 │                   │  + SPs       │                   │              │
│  + lógica    │                   │              │                   │              │
│  escenarios  │                   │              │                   │              │
├──────────────┤                   ├──────────────┤                   ├──────────────┤
│ _120 Carga   │                   │ _120 Carga   │                   │ _120 Carga   │
├──────────────┤                   ├──────────────┤                   ├──────────────┤
│ _130 Persist │──────────────────▶│ _131 DicNom  │                   │ _130 Persist │
│  UPSERT a    │                   │  (SP)        │                   │  UPSERT a    │
│  tablas      │                   │ _131 Insumo  │                   │  tablas      │
│  finales     │                   │  (SP)        │                   │  finales     │
│              │                   │ _130 Persist │                   │              │
│              │                   │  UPSERT 4    │                   │              │
│              │                   │  tablas      │                   │              │
├──────────────┤                   ├──────────────┤                   ├──────────────┤
│ _140 Export  │                   │ _140 Export  │                   │ _140 Export  │
└──────────────┘                   └──────────────┘                   └──────────────┘
```

**Orden de ejecución**: P0019 → P0020 → P0021 (cascada: resultado de una es insumo de la siguiente)

---

## P0019 – Unificación Regla 1 (Tipo de Uso + CIIU)

### P0019_111 (Setup) — ⭐ CONTIENE LA LÓGICA DE NEGOCIO

Este es el script más importante de Regla 1. No solo hace setup, sino que **implementa toda la lógica de escenarios**.

**Step 1: `Crea_Insumo_CU_3_4_1`** — Crea 3 tablas stage secuenciales:

**Tabla stage 1** — Materializa la vista de insumo:
```sql
SELECT FROM V_Insumo_Unificacion_Regla1
  LEFT JOIN V_Tipo_Ubicacion_Direccion  -- Agrega descripción tipo (RES, LAB, CRR)
```
- PI: `COD_DW_PERSONA_UBIC`

**Tabla stage 2** — Aplica lógica de escenarios con CASE anidados:
```sql
CASE 
  WHEN CIIU = '10'                    → ESCENARIO1 (Asalariado)
    Score = 100000 si LAB o CRR + Numero_Entidades
  WHEN CIIU IN ('81','82','90')       → ESCENARIO2 (Sin actividad)
    Score = 100000 si RES o CRR + Numero_Entidades
  ELSE                                → ESCENARIO3 (Otros)
    Score = Numero_Entidades
END AS ID
```
- Usa `ROW_NUMBER() OVER (PARTITION BY ESCENARIO, TEXTO_UBICACION, Id_Buro_Persona, Cod_DW_Ciudad ORDER BY ID DESC)` para rankear
- Usa `COUNT(*) OVER(...)` para detectar empates
- `QUALIFY EMPATE=1` filtra solo los que no empatan (o el ganador del empate)

**Tabla stage 3** — Genera pares padre-hijo:
```sql
SELECT T2.COD_DW_PERSONA_UBIC,          -- Hijo
       T1.COD_DW_PERSONA_UBIC AS Padre  -- Padre (mayor score)
FROM stage2 T1
LEFT JOIN stage2 T2
  ON T1.TEXTO_UBICACION = T2.TEXTO_UBICACION
  AND T1.ESCENARIO = T2.ESCENARIO
  AND T1.Id_Buro_Persona = T2.Id_Buro_Persona
  AND T1.Cod_DW_Ciudad = T2.Cod_DW_Ciudad
  AND T1.ID > T2.ID                     -- Padre tiene mayor score
QUALIFY MIN(T1.ORDEN) OVER(...) = T1.ORDEN
```

**Step 2: `Crea_VSTG`** — Crea vista `Vstg_Unificacion_uno` que alimenta el paso 130.

### P0019_130 (Persistencia) — Carga a tablas finales

Lee desde `Vstg_Unificacion_uno` y hace UPSERT a 3 tablas:

| Tabla destino | Operación |
|---------------|-----------|
| `UNIFICACION_DIRECCION` | INSERT/UPDATE relación padre-hijo |
| `REPORTE_UNIFICACION_DIRECCION` | INSERT/UPDATE reporte de unificación |
| `RELACION_PERSONA_UBICACION` | UPDATE `IND_UNIFICACION = 1` para hijos |

También inserta bloqueos por novedad en tabla `BLOQUEO`.

**Patrón**: `CASE WHEN Severidad < 3 THEN UPDATE... INSERT FOR MISSING UPDATE ROWS`

---

## P0020 – Unificación Regla 2 (Complementos)

### Flujo específico de Regla 2

```
_131 CARGA_INSUMO_UNI_REG2  →  _131 CreaDicNomenclaturaReg2  →  _130 Persistencia
     (SP: prepara insumo)        (SP: crea diccionario)             (UPSERT 4 tablas)
```

### P0020_CARGA_INSUMO_UNI_REG2_131 (Shell + BTEQ)

- Script shell que ejecuta SP `PRO_CARGA_INSUMO_UNI_REG2`
- Parámetros: lote, fecha, proceso, esquemas (BDVISTA, BDSTAGE, BTTVISTA)
- El SP prepara la tabla `tmpINSUMO_UNI_REG2` que alimenta la vista `V_Insumo_Unificacion_Regla2`

### P0020_CreaDicNomenclaturaReg2_131 (Shell + BTEQ)

- Script shell que ejecuta SP `PRO_CreaDicNomenclaturaReg2`
- Construye el **Diccionario de Nomenclaturas** (frecuencia de cada nomenclatura por dirección GEO)
- Parámetros: lote, fecha, proceso, esquemas (BDDATOS, BDVISTA, BDSTAGE)

**⚠️ Nota crítica**: La lógica real de Regla 2 está en los **Stored Procedures** (`PRO_CARGA_INSUMO_UNI_REG2` y `PRO_CreaDicNomenclaturaReg2`), que están dentro del DDL `DB/Unificacion.sql` (311 KB). Los scripts .BTQ solo los invocan.

### P0020_130 (Persistencia) — Carga a 4 tablas

Lee desde `VstgCargaUnificacionDir` y hace UPSERT a **4 tablas** (una más que Regla 1):

| Tabla destino | Operación | Condición |
|---------------|-----------|-----------|
| `UNIFICACION_DIRECCION` | INSERT/UPDATE relación padre-hijo | `Severidad < 3` |
| `REPORTE_UNIFICACION_DIRECCION` | INSERT/UPDATE reporte | `Severidad < 3` |
| `DIRECCION_FISICA` | **INSERT nueva dirección** | `Complemento IS NOT NULL AND Severidad = 3 AND ID_ACTUALIZACION = 1` |
| `RELACION_PERSONA_UBICACION` | INSERT nueva relación + UPDATE `IND_UNIFICACION = 1` | Según condición |

**Diferencia clave vs Regla 1**: Regla 2 **crea nuevas direcciones físicas** (Padre Tipo 2) en `DIRECCION_FISICA` con campos:
- Complemento (nuevo, combinado)
- Tipo_Via_Principal, Via_Principal, Via_Generadora, Numero_Puerta
- `Generada_Enriquecida = 1` (flag que marca dirección generada por unificación)

También actualiza `MAX_ID` para `DIRECCION_FISICA` y `RELACION_PERSONA_UBICACION`.

---

## P0021 – Unificación Regla 3 (Geolocalización)

### P0021_130 (Persistencia) — Idéntico patrón a P0019

Lee desde `Vstg_Unificacion_tres` y hace UPSERT a 3 tablas (mismo patrón que Regla 1):

| Tabla destino | Operación |
|---------------|-----------|
| `UNIFICACION_DIRECCION` | INSERT/UPDATE relación padre-hijo |
| `REPORTE_UNIFICACION_DIRECCION` | INSERT/UPDATE reporte |
| `RELACION_PERSONA_UBICACION` | UPDATE `IND_UNIFICACION = 1` |

**⚠️ Nota**: La lógica de escenarios de Regla 3 (subcasos de vía generadora y número de puerta, diccionario de vía, validación ±2 posiciones) probablemente está en el script `_111` de P0021 o en SPs dentro de `Unificacion.sql`. No se encontró archivo `P0021_111` en el directorio — puede estar embebido en el DDL.

---

## Modelo de Datos Involucrado

### Tablas que se escriben

| Tabla | Regla 1 | Regla 2 | Regla 3 | Operación |
|-------|---------|---------|---------|-----------|
| `REC_DATOS.UNIFICACION_DIRECCION` | ✅ | ✅ | ✅ | UPSERT padre-hijo |
| `REC_DATOS.REPORTE_UNIFICACION_DIRECCION` | ✅ | ✅ | ✅ | UPSERT reporte |
| `REC_DATOS.RELACION_PERSONA_UBICACION` | ✅ | ✅ | ✅ | UPDATE Ind_Unificacion=1 |
| `REC_DATOS.DIRECCION_FISICA` | ❌ | ✅ | ❌ | INSERT nuevas direcciones |
| `REC_DATOS.BLOQUEO` | ✅ | ❌ | ❌ | INSERT bloqueos por novedad |

### Tablas que se leen

| Tabla/Vista | Uso |
|-------------|-----|
| `V_Insumo_Unificacion_Regla1` | Insumo Regla 1 (JOIN complejo: 6 tablas) |
| `V_Insumo_Unificacion_Regla2` | Insumo Regla 2 (desde tabla temporal) |
| `V_Insumo_Unificacion_Regla3` | Insumo Regla 3 (desde tabla temporal) |
| `VM_Reporte_Relacion_Pers_Ubi` | Histórico de reportes (para diccionarios) |
| `V_Tipo_Ubicacion_Direccion` | Catálogo tipos de uso |
| `V_TIPO_UBICACION` | Filtro tipo ubicación = 'Geografica' |
| `V_BLOQUEO` | Exclusión de bloqueados |
| `bdm_vista.v_persona_act_economica_ciiu` | CIIU de la persona |
| `bdm_vista.V_ACTIVIDAD_ECONOMICA_CIIU` | Catálogo CIIU |

### Esquemas

| Esquema | Uso |
|---------|-----|
| `REC_DATOS` | Tablas finales (persistencia) |
| `REC_STAGE` | Tablas temporales y vistas stage |
| `REC_VISTA` | Vistas de consulta |
| `bdm_vista` | Vistas del BDM (fuente externa: CIIU, personas) |

---

## Hallazgos para Migración

### Complejidad por regla

| Regla | Complejidad | Razón |
|-------|-------------|-------|
| **Regla 1** | 🟡 Media | Lógica de escenarios clara en SQL (CASE + ROW_NUMBER). Migrable a Redshift con ajustes menores |
| **Regla 2** | 🔴 Alta | Lógica en SPs (311 KB de DDL). Crea nuevas direcciones. Diccionario de nomenclaturas. Requiere análisis profundo del DDL |
| **Regla 3** | 🟡 Media | Patrón similar a Regla 1 pero con lat/long y diccionario de vía. Lógica de escenarios probablemente en SPs |

### Patrones reutilizables

1. **Patrón UPSERT TPT**: Los 3 programas usan el mismo patrón `UPDATE... INSERT FOR MISSING UPDATE ROWS`. En Redshift se puede reemplazar con `MERGE` o `INSERT ON CONFLICT`.
2. **Patrón de scoring**: Regla 1 usa `CASE + ROW_NUMBER + QUALIFY` para rankear. Redshift soporta window functions pero no `QUALIFY` (usar subquery).
3. **Patrón padre-hijo**: LEFT JOIN de tabla consigo misma con `T1.ID > T2.ID` para generar pares.

### Funciones Teradata sin equivalente directo en Redshift

| Función Teradata | Uso | Alternativa Redshift |
|-----------------|-----|---------------------|
| `QUALIFY` | Filtro post-window function | Subquery con WHERE |
| `SEL` (abreviatura) | SELECT | `SELECT` |
| `LOCKING ROW FOR ACCESS` | Lock hint | No necesario (MVCC) |
| `PRIMARY INDEX` | Distribución | `DISTKEY` / `SORTKEY` |
| `WITH DATA` | CTAS | `CREATE TABLE AS` (implícito) |

### Siguiente paso: Análisis del DDL

El archivo `DB/Unificacion.sql` (311 KB) contiene:
- Stored Procedures de Regla 2 y Regla 3 (la lógica real de escenarios)
- DDLs de todas las tablas
- Posiblemente la lógica de corrección de complementos (función C)

---

## Análisis de Stored Procedures (Unificacion.sql — 311 KB)

El DDL contiene 3 Stored Procedures que implementan la lógica real de Regla 2:

### Inventario de SPs

| SP | Línea | Tamaño aprox | Función |
|----|-------|-------------|---------|
| `PRO_Unifi_MOTOR_TMP` | L3-L870 | ~870 líneas | Motor de generación de nuevas direcciones (Padre Tipo 2) |
| `PRO_Unifi_MOTOR_TMP_V2` | L871-L1739 | ~870 líneas | V2 del motor (misma lógica, ajustes) |
| `PRO_UnificacionR2` | L1740-final | ~2000+ líneas | **SP principal**: orquesta los 6 escenarios de Regla 2 |

### PRO_UnificacionR2 — Orquestador de Regla 2

**Patrón general**: SQL dinámico construido como strings (`V_CADENA`) y ejecutado vía `SP_EXECSTRING_DES`. Crea tablas temporales en cascada (`Tmp_Unificacion_E1`, `_E2`, `_0E1`, `_0E2`, etc.).

**Flujo de escenarios**:

```
Insumo: V_Insumo_Unificacion_Regla2
    │
    ▼
Escenario 1: Complemento vacío vs no vacío
    Tmp_Unificacion_0E1 → Tmp_Unificacion_E1
    JOIN A con B donde A.COMPLEMENTO IS NOT NULL AND B.COMPLEMENTO IS NULL
    Padre = el que tiene complemento
    Marca: N_ID = 'H1'
    │
    ▼
Escenario 2: Un complemento incluido en otro
    Tmp_Unificacion_0E2 → Tmp_Unificacion_E2
    JOIN donde A.COMPLEMENTO LIKE '%' || B.COMPLEMENTO || '%'
    Padre = el más completo (que contiene al otro)
    Marca: N_ID = 'K2'
    │
    ▼
Escenarios 3-6: Nomenclaturas diferentes (usa MOTOR_TMP)
    Descompone complementos en nomenclaturas
    Compara niveles, frecuencias del diccionario
    Genera nuevas direcciones combinando nomenclaturas
    │
    ▼
Salida: VstgCargaUnificacionDir → P0020_130 (persistencia)
```

**Lógica de Escenario 1** (complemento vacío):
```sql
-- Hijo: el que NO tiene complemento. Padre: el que SÍ tiene.
SELECT B.COD_DW_PERSONA_UBIC,        -- Hijo
       A.COD_DW_PERSONA_UBIC AS ID_PADRE  -- Padre
FROM V_Insumo_Unificacion_Regla2 A
JOIN V_Insumo_Unificacion_Regla2 B
  ON A.Id_Buro_Persona = B.Id_Buro_Persona
  AND A.Texto_Ubicacion = B.Texto_Ubicacion
  AND A.Cod_DW_Tipo_Ubicacion_Dir = B.Cod_DW_Tipo_Ubicacion_Dir
  AND A.Cod_DW_Municipio = B.Cod_DW_Municipio
  AND A.Cod_DW_Persona_Ubic <> B.Cod_DW_Persona_Ubic
WHERE A.COMPLEMENTO IS NOT NULL AND B.COMPLEMENTO IS NULL
```

**Lógica de Escenario 2** (complemento incluido):
```sql
-- Hijo: el contenido. Padre: el que contiene.
WHERE A.COMPLEMENTO LIKE '%' || B.COMPLEMENTO || '%'  -- B contenido en A
  AND A.Ind_Unificacion = 'N'  -- Solo no-unificados del escenario anterior
```

**Patrón cascada**: Cada escenario marca `Ind_Unificacion = 'S'` en los hijos. El siguiente escenario solo procesa los que tienen `Ind_Unificacion = 'N'`.

### PRO_Unifi_MOTOR_TMP — Motor de Nuevas Direcciones

Este SP implementa la lógica más compleja: **generar nuevas direcciones combinando nomenclaturas** (Escenarios 3-6).

**Flujo interno**:

```
1. Descomposición de complementos por nomenclatura
   Tmp_Unificacion_E051_D1
   JOIN con DICCIONARIO_COMPLEMENTOS (complemento LIKE '%nomenclatura%')
   JOIN con NOMENCLATURA (obtiene Nivel_Complemento)
   Calcula: ID_COM (orden por nivel), valor, cantidad

2. Agrupación de nomenclaturas por persona
   Tmp_Unificacion_E051_D2
   Usa XMLAGG para concatenar nomenclaturas (NOM_AGRUP)

3. Cálculo de MDIR (jerarquía de dirección)
   Tmp_Unificacion_E051_Dx
   SQL dinámico generado con XMLAGG: crea columnas dinámicas
   por cada nivel de nomenclatura (ID_COM1_1, ID_COM1_2, etc.)
   ROW_NUMBER para rankear por jerarquía de niveles

4. Consolidación con orden y metadata
   Tmp_Unificacion_E051_D3
   JOIN de todo: complementos + diccionario + nomenclatura + MDIR + agrupación
   Calcula ORDEN global por persona

5. Generación de tabla dinámica de nuevas direcciones
   Tmp_Unificacion_E051_D00 y D01
   SQL dinámico: crea columnas C1..Cn y N1..Nn según cantidad de nomenclaturas
   Cada columna = una nomenclatura del complemento combinado
```

**⚠️ Complejidad crítica**: Este SP genera SQL dinámico basado en la cantidad de nomenclaturas encontradas. Crea tablas con columnas variables (C1, C2, ..., Cn). Usa `XMLAGG` extensivamente para concatenar y generar SQL. Esto es lo más difícil de migrar a Redshift.

### Funciones Teradata específicas usadas en SPs

| Función | Uso | Alternativa Redshift |
|---------|-----|---------------------|
| `XMLAGG(col ORDER BY ...)` | Concatenar strings ordenados | `LISTAGG(col, '' ORDER BY ...)` |
| `DBC.SysExecSQL(cadena)` | Ejecutar SQL dinámico | No hay equivalente directo. Usar procedimiento con `EXECUTE` o mover lógica a aplicación |
| `SP_EXECSTRING_DES(...)` | Wrapper de ejecución con logging | Reimplementar como SP helper |
| `ACTIVITY_COUNT` | Contar filas afectadas | `GET DIAGNOSTICS row_count = ROW_COUNT` |
| `QUALIFY` | Filtro post-window | Subquery con WHERE |
| `dbc.tables` | Metadata de tablas | `SVV_TABLE_INFO` o `information_schema.tables` |
| `COLLECT STAT INDEX` | Actualizar estadísticas | `ANALYZE table` |
| `CREATE SET TABLE` | Tabla sin duplicados | `CREATE TABLE` + constraint o `SELECT DISTINCT` |
| `PRIMARY INDEX` | Distribución | `DISTKEY` |

---

## Resumen de Complejidad para Migración

| Componente | Complejidad | Líneas aprox | Estrategia sugerida |
|------------|-------------|-------------|---------------------|
| **P0019_111** (Regla 1 lógica) | 🟡 Media | ~180 | SQL directo → Redshift con ajustes menores |
| **P0019_130** (Regla 1 persist) | 🟢 Baja | ~100 | Reemplazar UPSERT TPT por MERGE |
| **PRO_UnificacionR2** (Regla 2 escenarios) | 🔴 Alta | ~2000+ | SQL dinámico + cascada de tablas temp. Requiere rediseño |
| **PRO_Unifi_MOTOR_TMP** (Regla 2 motor) | 🔴 Muy Alta | ~870 | XMLAGG dinámico + columnas variables. Candidato a reescribir en Python/Spark |
| **P0020_130** (Regla 2 persist) | 🟡 Media | ~200 | UPSERT a 4 tablas, incluye INSERT de nuevas direcciones |
| **P0021** (Regla 3) | 🟡 Media | ~similar a P0019 | Lógica de escenarios probablemente en SPs adicionales dentro del DDL |

### Recomendación para las 3 aproximaciones de migración

| Aproximación | Mejor para | Peor para |
|-------------|-----------|-----------|
| **1. Prompt directo** | P0019 (Regla 1) — SQL claro y autocontenido | PRO_Unifi_MOTOR_TMP — SQL dinámico demasiado complejo |
| **2. AWS Q Transform** | P0019, P0020_130 — patrones TPT estándar | SPs con SQL dinámico y XMLAGG |
| **3. Spec Driven** | PRO_UnificacionR2 y MOTOR_TMP — extraer spec funcional y reimplementar | Overkill para scripts simples como P0019 |

**Recomendación**: Usar aproximación mixta. Regla 1 con prompt directo. Regla 2 con Spec Driven (la lógica es demasiado compleja para traducción directa). Regla 3 evaluar después de analizar sus SPs.

---

*Generado: 2026-04-17 | Fuente: `Experian Reconocer/Unificacion/` + `DB/Unificacion.sql`*
