# Criterios de Validación – Proceso de Unificación

> Documento de referencia para validar la migración de Unificación de Teradata a Redshift.
> Última actualización: 2026-04-17

---

## ⚠️ BANDERA: Criterios de Aceptación Pendientes de Definición con Experian

Los criterios de aceptación específicos de Reconocer Máster **no están formalizados en ningún documento existente**. La preventa define métricas generales del proyecto ("cobertura ≥95%", "calidad ≥90%", "sin perder calidad") pero no especifica:

- ¿Qué porcentaje de coincidencia entre Teradata y Redshift se considera aceptable?
- ¿Se acepta tolerancia en el resultado o debe ser 100% idéntico?
- ¿Quién del lado de Experian aprueba que el resultado es correcto?
- ¿Existe un dataset de referencia (golden dataset) contra el cual comparar?

**Acción requerida**: Definir con Experian (Fernando Garrido / Ricardo Martínez / Caterina) los criterios de aceptación formales antes de iniciar validación con datos reales.

**Contactos sugeridos para definición**:
- Fernando Garrido — Senior Lead, líder técnico del proyecto
- Ricardo Martínez — Conocimiento del proceso de ordenamiento y reglas de negocio
- Caterina — Equipo de Datos, validación de criterios de estandarización

---

## 1. Criterios del Proyecto (fuente: preventa)

Estos criterios aplican al proyecto completo, no solo a unificación. Extraídos de `02_fases_tecnicas.md` y `05_riesgos_supuestos.md`:

### Funcionales

| Criterio | Métrica | Objetivo | Crítico | Aplica a Unificación |
|----------|---------|----------|---------|---------------------|
| Cobertura de estandarización | % vs sistema actual | ≥ 95% | Sí | Indirectamente (insumo) |
| Calidad de direcciones válidas | % direcciones válidas | ≥ 90% | Sí | ✅ Sí |
| Cobertura de geolocalización | % direcciones con lat/long | ≥ 70% | No | Solo Regla 3 |
| Tiempo de procesamiento delta | Horas | ≤ 6 horas | Sí | ✅ Sí |
| Capacidad de procesamiento full | Días | ≤ 7 días | Sí | ✅ Sí |

### No Funcionales

| Criterio | Métrica | Objetivo | Crítico |
|----------|---------|----------|---------|
| Disponibilidad del servicio | % uptime | ≥ 99.5% | Sí |
| Tiempo de respuesta consultas | Segundos | ≤ 2 seg | Sí |
| Escalabilidad | Registros | 100M+ | No |

### Negocio

| Criterio | Fecha | Crítico |
|----------|-------|---------|
| Solución batch operativa | Octubre 2026 | Sí |
| Servicio en línea operativo | Noviembre 2026 | Sí |

### User Story (fuente: USERSTORYFORMAT-MT.md)

> "El sistema debe aplicar las mismas reglas de validación y limpieza que existen hoy en Reconocer Master, sin perder calidad."

> "El tiempo total de este procesamiento cruzado (ahora en Redshift) debe ser igual o más rápido que el tiempo actual."

---

## 2. Criterios Específicos de Unificación (derivados por Macondotek)

Estos criterios los derivamos del documento funcional y del análisis técnico. **⚠️ Requieren validación de Experian.**

### 2.1 Integridad de Reglas

| # | Criterio | Cómo se valida |
|---|----------|----------------|
| U01 | Las 3 reglas se ejecutan en cascada: R1 → R2 → R3 | Verificar que hijos de R1 no entran a R2, hijos de R2 no entran a R3 |
| U02 | Toda dirección hija tiene exactamente un padre | COUNT de hijos sin padre = 0 |
| U03 | Ningún padre es hijo de sí mismo | WHERE Cod_DW_Persona_Ubic = Cod_DW_Direccion_Unificada → 0 registros |
| U04 | Hijas marcadas con Ind_Unificacion=1 | COUNT de hijos en UNIFICACION_DIRECCION sin marca en RELACION_PERSONA_UBICACION = 0 |
| U05 | Direcciones bloqueadas no entran al proceso | JOIN con BLOQUEO → 0 registros procesados |
| U06 | Solo direcciones tipo 'Geografica' entran al proceso | Verificar filtro de tipo ubicación |

### 2.2 Regla 1: Tipo de Uso + CIIU

| # | Criterio | Cómo se valida |
|---|----------|----------------|
| R1-01 | CIIU=10: Padre tiene tipo LAB o CRR | Verificar tipo de uso del padre cuando CIIU=10 |
| R1-02 | CIIU=81/82/90: Padre tiene tipo RES o CRR | Verificar tipo de uso del padre cuando CIIU en (81,82,90) |
| R1-03 | Otro CIIU: Padre tiene mayor número de entidades | Verificar que entidades del padre ≥ entidades de cada hijo |
| R1-04 | Desempate por fecha más reciente | Cuando entidades iguales, padre tiene fecha ≥ hijo |

### 2.3 Regla 2: Complementos

| # | Criterio | Cómo se valida |
|---|----------|----------------|
| R2-01 | Esc 1: Padre tiene complemento, hijo no | Verificar que hijo tiene complemento vacío |
| R2-02 | Esc 2: Complemento del padre contiene al del hijo | Padre.Complemento LIKE '%' + Hijo.Complemento + '%' |
| R2-03 | Esc 3 sin NIT: Padre tiene mayor entidades | Verificar entidades padre ≥ hijo |
| R2-04 | Esc 3 con NIT: Se genera nueva dirección combinando | Verificar que existe registro con Generada_Enriquecida=1 |
| R2-05 | Esc 5 sub 1: Se genera nueva dirección combinando nomenclaturas de ≠ nivel | Nueva dirección contiene nomenclaturas de ambas hijas |
| R2-06 | Esc 6: Combinación o diccionario según nivel | Verificar según subcaso |
| R2-07 | Nuevas direcciones tienen Generada_Enriquecida=1 en DIRECCION_FISICA | COUNT de nuevas sin flag = 0 |
| R2-08 | Nuevas direcciones tienen relación en RELACION_PERSONA_UBICACION | JOIN verificando existencia |

### 2.4 Regla 3: Geolocalización

| # | Criterio | Cómo se valida |
|---|----------|----------------|
| R3-01 | Solo direcciones tipo Vía entran (excluye Manzana y Rural) | Verificar tipo de dirección |
| R3-02 | Direcciones con modificadores de vía (BIS, B, C, F) excluidas | Verificar exclusión |
| R3-03 | Esc 1/2 sub 1: Padre tiene lat/long cuando solo uno tiene | Verificar lat/long no nulos en padre |
| R3-04 | Esc 1/2 sub 2: Padre tiene fecha más reciente cuando ninguno tiene geo | Verificar fecha padre ≥ hijo |
| R3-05 | Esc 2 sub 3: No unifica si diferencia de puerta > ±2 | Verificar que pares con diferencia >2 no se unificaron |
| R3-06 | Esc 1/2 sub 3: Padre tiene mayor frecuencia en diccionario de vía | Verificar contra diccionario |

---

## 3. Resultado Esperado por Persona Mock

Validación concreta contra el dataset mock (`data/mock/`):

### Regla 1

| Persona | Direcciones | Resultado esperado | Criterio que valida |
|---------|------------|-------------------|-------------------|
| P01 (CIIU=10) | A=LAB 5ent, B=RES 3ent | A=PADRE, B=HIJO | R1-01 |
| P02 (CIIU=81) | A=RES 4ent, B=LAB 2ent | A=PADRE, B=HIJO | R1-02 |
| P03 (CIIU=55) | A=CRR 7ent, B=RES 3ent, C=LAB 1ent | A=PADRE, B=HIJO, C=HIJO | R1-03 |

### Regla 2

| Persona | Complementos | Resultado esperado | Criterio que valida |
|---------|-------------|-------------------|-------------------|
| P04 | A="AP 802", B=vacío | A=PADRE, B=HIJO | R2-01 |
| P05 | A="ED GALICIA AP 702", B="AP 702" | A=PADRE, B=HIJO | R2-02 |
| P06 | A="AP 105" 6ent, B="AP 404" 2ent | A=PADRE, B=HIJO | R2-03 |
| P07 (NIT) | A="LC 101", B="LC 205" | NUEVO="LC 101 LC 205"=PADRE, A=HIJO, B=HIJO | R2-04 |
| P08 | A="CS 312", B="CS 108" | A=PADRE (dic: CS 312 más frecuente), B=HIJO | R2-06 |
| P09 | A="TO 3", B="AP 504" | NUEVO="TO 3 AP 504"=PADRE, A=HIJO, B=HIJO | R2-05 |
| P10 | A="TO 3" 5ent, B="AP 3" 2ent | A=PADRE (dic: TO más frecuente), B=HIJO | R2-06 |
| P11 | A="ED PROMOTOR", B="OF 2007" | NUEVO="ED PROMOTOR OF 2007"=PADRE, A=HIJO, B=HIJO | R2-05 |
| P12 | A="BR CASTILLA", B="BR VENECIA" | A=PADRE (dic: más frecuente), B=HIJO | R2-06 |

### Regla 3

| Persona | Direcciones | Geo | Resultado esperado | Criterio que valida |
|---------|------------|-----|-------------------|-------------------|
| P13 | A=CL 8 6 52, B=CL 8 7 52 | A=sí, B=no | A=PADRE, B=HIJO | R3-03 |
| P14 | A=KR 55 14 30, B=KR 55 15 30 | Ninguno | A=PADRE (fecha reciente), B=HIJO | R3-04 |
| P15 | A=KR 7 181 75, B=KR 7 182 75 | Ambos | A=PADRE (dic: 181 más frec), B=HIJO | R3-06 |
| P16 | A=AV BOYACA 77A 41, B=AV BOYACA 77A 43 | A=no, B=sí | B=PADRE, A=HIJO | R3-03 |
| P17 | A=CL 13 18 21, B=CL 13 18 23 | Ninguno | A=PADRE (fecha reciente), B=HIJO | R3-04 |
| P18 | A=KR 55 14 55, B=KR 55 14 57 | Ambos | A=PADRE (dic: 55 más frec), B=HIJO | R3-05, R3-06 |
| P19 | A=CL 20 10 50, B=CL 20 10 60 | Ambos | SIN CAMBIO (dif >±2) | R3-05 |

---

## 4. ⚠️ Criterios Pendientes de Definición con Experian

| # | Criterio pendiente | Por qué es necesario | Quién lo define |
|---|-------------------|---------------------|----------------|
| CP-01 | Tolerancia de coincidencia Teradata vs Redshift | ¿100% match o se acepta margen? | Fernando Garrido / Ricardo Martínez |
| CP-02 | Golden dataset de referencia | Dataset real con resultado conocido para comparar | Experian (equipo de datos) |
| CP-03 | Responsable de aceptación formal | ¿Quién firma que el resultado es correcto? | Christian Sparacino / Fernando Garrido |
| CP-04 | Criterios de aceptación para nuevas direcciones (Regla 2) | ¿Cómo se valida que una dirección generada es correcta? | Ricardo Martínez (reglas de negocio) |
| CP-05 | Prioridad de reglas en caso de conflicto | ¿Qué pasa si el resultado difiere entre aproximaciones de migración? | Fernando Garrido |
| CP-06 | Métricas de calidad específicas de unificación | ¿% de unificación esperado? ¿Ratio padre/hijo esperado? | Experian (datos históricos) |

---

*Generado: 2026-04-17 | Fuentes: 02_fases_tecnicas.md, 05_riesgos_supuestos.md, USERSTORYFORMAT-MT.md, documento funcional unificación, análisis técnico de scripts*
