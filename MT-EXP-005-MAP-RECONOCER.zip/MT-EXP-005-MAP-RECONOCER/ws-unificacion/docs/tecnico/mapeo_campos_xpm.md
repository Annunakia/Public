# Mapeo de Campos: Unificación → XPM en Redshift

> Identifica qué campos necesita el proceso de Unificación, qué esperábamos encontrar en XPM (análisis de steering), y qué encontramos realmente en el sandbox.
> Fecha: 2026-04-21 | Autor: Francisco Peña

---

## 1. Resumen

### Análisis inicial (basado en steering files)

| Categoría | Cantidad |
|-----------|----------|
| Campos requeridos por Unificación | 32 |
| Disponibles en XPM (mapeo directo o derivable) | 12 |
| No encontrados en XPM (requieren confirmación) | 10 |
| Catálogos / derivables (requieren confirmación) | 5 |
| Campos internos del proceso (no vienen de XPM) | 5 |

### Validación contra sandbox real (2026-04-21)

Sandbox: cuenta `193272798722` | workgroup `experian-sandbox-trunk-ddm-xpm-workgroup` | database `ddm_xpm_db` | schema `edf_views`

| Categoría | Cantidad |
|-----------|----------|
| Campos requeridos por Unificación | 32 |
| ✅ Confirmados (mapeo directo o derivable) | 4 |
| ⚠️ Existen pero con nombre o tabla diferente al esperado | 8 |
| 🔵 Hallazgos nuevos (no estaban en análisis inicial) | 3 |
| ❌ No existen en XPM actual | 12 |
| 🔧 Campos internos del proceso (se crean en Redshift) | 5 |

---

## 2. Análisis inicial (steering files)

Mapeo esperado basado en la documentación de `modelo-datos-xpm.md` y `sql-redshift-xpm.md`:

| # | Campo | Tabla Teradata | Regla | Estado steering | Tabla XPM esperada | Columna XPM esperada |
|---|-------|---------------|-------|-----------------|-------------------|---------------------|
| 1 | Id_Buro_Persona | RELACION_PERSONA_UBICACION | R1,R2,R3 | ✅ Disponible | edf_views.xpm | id |
| 2 | Cod_Pin_Persona | RELACION_PERSONA_UBICACION | R2 | ✅ Disponible | edf_views.xpm | pin |
| 3 | Texto_Ubicacion | UBICACION_ESTANDARIZADA | R1,R2,R3 | ✅ Disponible | xpm_location_val_contactinformations | contactasreported |
| 4 | Cod_DW_Ciudad | UBICACION_ESTANDARIZADA | R1,R2,R3 | ✅ Disponible | xpm_location | citycode |
| 5 | Cod_Act_Econo_CIIU_Fte | bdm_vista (CIIU) | R1 | ✅ Disponible | xpm_personalinformation | economicactivitycode |
| 6 | Latitud | UBICACION_ESTANDARIZADA | R3 | ✅ Disponible | xpm_location_val_contactinformations | latitude |
| 7 | Longitud | UBICACION_ESTANDARIZADA | R3 | ✅ Disponible | xpm_location_val_contactinformations | longitude |
| 8 | Id_Buro_Suscriptor | REPORTE_RELACION_PERSONA_UBICA | R1,R2,R3 | ✅ Disponible | xpm_counterparties | subscribercode |
| 9 | Fecha_Reporte | REPORTE_RELACION_PERSONA_UBICA | R1,R2,R3 | ✅ Disponible | xpm_counterparties | cutoffdate |
| 10 | Cod_DW_Doc_Ident | RELACION_PERSONA_UBICACION | R2 | ✅ Disponible | xpm_identifications | identificationnumber |
| 11 | Cod_Tipo_Ident_Fte | RELACION_PERSONA_UBICACION | R2 | ✅ Disponible | xpm_identifications | identificationtype |
| 12 | Cod_DW_Municipio | RELACION_PERSONA_UBICACION | R2 | ✅ Disponible | xpm_location | municipalitycode |
| 13 | Cod_DW_Persona_Ubic | RELACION_PERSONA_UBICACION | R1,R2,R3 | ❌ No encontrado | — | — |
| 14 | Cod_DW_Tipo_Ubicacion_Dir | RELACION_PERSONA_UBICACION | R1,R2 | ❌ No encontrado | — | — |
| 15 | Cod_DW_Ubic | UBICACION_ESTANDARIZADA | R1,R2,R3 | ❌ No encontrado | — | — |
| 16 | Cod_DW_Direccion_Fisica | DIRECCION_FISICA | R2 | ❌ No encontrado | — | — |
| 17 | Complemento | DIRECCION_FISICA | R1,R2 | ❌ No encontrado | — | — |
| 18 | Tipo_Via_Principal | DIRECCION_FISICA | R3 | ❌ No encontrado | — | — |
| 19 | Via_Generadora | DIRECCION_FISICA | R3 | ❌ No encontrado | — | — |
| 20 | Numero_Puerta | DIRECCION_FISICA | R3 | ❌ No encontrado | — | — |
| 21 | Cod_DW_Tipo_Ubicacion | UBICACION_ESTANDARIZADA | R1,R2,R3 | ❌ No encontrado | — | — |
| 22 | Fecha_Relacion_Persona_Ubicaci | RELACION_PERSONA_UBICACION | R2,R3 | ❌ No encontrado | — | — |
| 23 | Numero_Entidades_Reportan | Calculado | R1,R2,R3 | ⚠️ Derivable | xpm_counterparties | COUNT DISTINCT |
| 24 | NOMENCLATURA (catálogo) | REC_DATOS | R2 | ⚠️ Catálogo | — | — |
| 25 | TIPO_UBICACION_DIR (catálogo) | REC_DATOS | R1 | ⚠️ Catálogo | — | — |
| 26 | BLOQUEO (tabla) | REC_DATOS | R1,R2,R3 | ⚠️ Catálogo | — | — |
| 27 | MAT_REPORTE_REL_PERS_UBI | REC_DATOS | R1,R2,R3 | ⚠️ Derivable | — | — |
| 28 | Ind_Unificacion | RELACION_PERSONA_UBICACION | R1,R2,R3 | 🔧 Interno | bdm_datos | — |
| 29 | Unifica_Atributos | UNIFICACION_DIRECCION | R1,R2,R3 | 🔧 Interno | bdm_datos | — |
| 30 | Fecha_Unificacion | UNIFICACION_DIRECCION | R1,R2,R3 | 🔧 Interno | bdm_datos | — |
| 31 | Generada_Enriquecida | DIRECCION_FISICA | R2 | 🔧 Interno | bdm_datos | — |
| 32 | Lote | Varias | R1,R2,R3 | 🔧 Interno | bdm_datos | — |

---

## 3. Validación contra sandbox real

Consulta ejecutada el 2026-04-21 via AWS Redshift Data API contra `ddm_xpm_db.edf_views`.

| # | Campo | Regla | Estado sandbox | Columna real en XPM | Diferencia vs steering |
|---|-------|-------|---------------|---------------------|----------------------|
| 1 | Id_Buro_Persona | R1,R2,R3 | ✅ Confirmado | `xpm.id` (BIGINT) | Sin diferencia |
| 2 | Cod_Pin_Persona | R2 | ✅ Confirmado | `xpm.pin` (BIGINT) | Sin diferencia |
| 3 | Texto_Ubicacion | R1,R2,R3 | ✅ Confirmado | `"location.val.contactinformations.val.contactasreported"` (VARCHAR) | Sin diferencia. Verificar si llega estandarizada |
| 4 | Cod_DW_Ciudad | R1,R2,R3 | ⚠️ Diferente | `"location.val.contactinformations.val.citycode"` | Está en contactinformations, no en xpm_location |
| 5 | Cod_Act_Econo_CIIU_Fte | R1 | ⚠️ Diferente | `"personalinformation.val.mainisiccode"` | Se llama mainisiccode, no economicactivitycode |
| 6 | Latitud | R3 | ❌ No existe | — | No hay columna de latitud en el sandbox |
| 7 | Longitud | R3 | ❌ No existe | — | No hay columna de longitud en el sandbox |
| 8 | Id_Buro_Suscriptor | R1,R2,R3 | ⚠️ Diferente | `"counterparties.val.counterpartyidnumber"` | Se llama counterpartyidnumber, no subscribercode |
| 9 | Fecha_Reporte | R1,R2,R3 | ⚠️ Diferente | `"location.val.cutoffdate"` (BIGINT epoch) | Está en xpm_location, no en counterparties |
| 10 | Cod_DW_Doc_Ident | R2 | ⚠️ Diferente | `"bestidentifications.val.personidnumber"` (VARCHAR) | Tabla es bestidentifications, no identifications |
| 11 | Cod_Tipo_Ident_Fte | R2 | ⚠️ Diferente | `"bestidentifications.val.personidtype"` (BIGINT) | Tabla es bestidentifications. Tipo BIGINT no VARCHAR |
| 12 | Cod_DW_Municipio | R2 | ❌ No existe | — | No hay municipalitycode. Solo citycode y statecode |
| 13 | Cod_DW_Persona_Ubic | R1,R2,R3 | ❌ No existe | — | Derivar como id + index de xpm_location |
| 14 | Cod_DW_Tipo_Ubicacion_Dir | R1,R2 | 🔵 Hallazgo | `"location.val.contactinformations.val.contacttype"` (BIGINT) | ¡Existe como código numérico! Falta catálogo de decodificación |
| 15 | Cod_DW_Ubic | R1,R2,R3 | ❌ No existe | — | Generar en Redshift o usar id+index |
| 16 | Cod_DW_Direccion_Fisica | R2 | ❌ No existe | — | No hay tabla DIRECCION_FISICA en XPM |
| 17 | Complemento | R1,R2 | ❌ No existe | — | CRÍTICO. Viene dentro de contactasreported |
| 18 | Tipo_Via_Principal | R3 | ❌ No existe | — | CRÍTICO. EDF debe generarlo en estandarización |
| 19 | Via_Generadora | R3 | ❌ No existe | — | CRÍTICO. EDF debe generarlo |
| 20 | Numero_Puerta | R3 | ❌ No existe | — | CRÍTICO. EDF debe generarlo |
| 21 | Cod_DW_Tipo_Ubicacion | R1,R2,R3 | ⚠️ Diferente | `"location.val.contactinformations.val.contacttype"` (BIGINT) | Verificar si distingue Geografica vs Tel vs Email |
| 22 | Fecha_Relacion_Persona_Ubicaci | R2,R3 | 🔵 Hallazgo | `"location.val.locationfirsteventdate"` (BIGINT) | Posible equivalencia. También existe locationeventlastupdated |
| 23 | Numero_Entidades_Reportan | R1,R2,R3 | ✅ Derivable | COUNT DISTINCT `counterparties.val.counterpartyidnumber` | Se calcula sin problema |
| 24 | NOMENCLATURA (catálogo) | R2 | ❌ No existe | — | Crear en bdm_datos (89 registros) |
| 25 | TIPO_UBICACION_DIR (catálogo) | R1 | ❌ No existe | — | Crear en bdm_datos |
| 26 | BLOQUEO (tabla) | R1,R2,R3 | 🔵 Hallazgo | `"location.val.subscriberblockstatus"` (VARCHAR) | Posible equivalencia. Verificar con Experian |
| 27 | MAT_REPORTE_REL_PERS_UBI | R1,R2,R3 | ❌ No existe | — | No existe como vista ni tabla. Reconstruir lógica |
| 28 | Ind_Unificacion | R1,R2,R3 | 🔧 Interno | bdm_datos (crear) | Se crea en Redshift |
| 29 | Unifica_Atributos | R1,R2,R3 | 🔧 Interno | bdm_datos (crear) | Se crea en Redshift |
| 30 | Fecha_Unificacion | R1,R2,R3 | 🔧 Interno | bdm_datos (crear) | CURRENT_DATE |
| 31 | Generada_Enriquecida | R2 | 🔧 Interno | bdm_datos (crear) | Flag dirección generada por Regla 2 |
| 32 | Lote | R1,R2,R3 | 🔧 Interno | bdm_datos (crear) | Número de lote batch |

---

## 4. Diagrama de mapeo (actualizado con sandbox)

```
TERADATA (Origen)                          XPM en REDSHIFT (Sandbox real)
─────────────────                          ──────────────────────────────

RELACION_PERSONA_UBICACION                 edf_views.xpm (raíz)
  Id_Buro_Persona ─────────────────────►     id ✅
  Cod_Pin_Persona ─────────────────────►     pin ✅
  Cod_DW_Persona_Ubic ─────────────────►     id + index (derivar) ❌
  Cod_DW_Tipo_Ubicacion_Dir ───────────►     contactinformations.val.contacttype 🔵 (BIGINT)

UBICACION_ESTANDARIZADA                    edf_views.xpm_location_val_contactinformations
  Texto_Ubicacion ─────────────────────►     contactasreported ✅
  Cod_DW_Ciudad ───────────────────────►     citycode ⚠️ (en contactinformations, no location)
  Latitud ─────────────────────────────►     ❌ NO EXISTE
  Longitud ────────────────────────────►     ❌ NO EXISTE

DIRECCION_FISICA                           ❌ NO HAY TABLA EQUIVALENTE
  Complemento ─────────────────────────►     ❌ (dentro de contactasreported)
  Tipo_Via_Principal ──────────────────►     ❌ (EDF debe generar)
  Via_Generadora ──────────────────────►     ❌ (EDF debe generar)
  Numero_Puerta ───────────────────────►     ❌ (EDF debe generar)

bdm_vista.CIIU                             edf_views.xpm_personalinformation
  Cod_Act_Econo_CIIU_Fte ──────────────►     mainisiccode ⚠️ (nombre diferente)

REPORTE_RELACION_PERSONA_UBICA             edf_views.xpm_location + xpm_counterparties
  Id_Buro_Suscriptor ──────────────────►     counterpartyidnumber ⚠️ (nombre diferente)
  Fecha_Reporte ───────────────────────►     location.val.cutoffdate ⚠️ (tabla diferente)

IDENTIDAD                                  edf_views.xpm_bestidentifications
  Cod_DW_Doc_Ident ────────────────────►     personidnumber ⚠️ (tabla bestidentifications)
  Cod_Tipo_Ident_Fte ──────────────────►     personidtype ⚠️ (BIGINT)
```

---

## 5. Preguntas para Experian (actualizadas post-sandbox)

### Bloqueantes

1. **¿Cómo se identifica la relación persona-ubicación en XPM?** En Teradata es `Cod_DW_Persona_Ubic`. En XPM parece ser `id` + `index` de `xpm_location`. ¿Es correcto?

2. **¿El complemento de la dirección llega separado o concatenado?** En el sandbox, `contactasreported` contiene la dirección completa. Regla 2 necesita el complemento como campo independiente. ¿La estandarización en EDF lo va a separar?

3. **¿EDF va a generar desglose de componentes de dirección?** (tipo_via, via_principal, via_generadora, numero_puerta). No existen en el XPM actual. Regla 3 los necesita por separado.

4. **¿`contacttype` (BIGINT) equivale al tipo de uso RES/LAB/CRR?** Encontramos este campo en el sandbox. ¿Qué valores tiene? ¿Hay catálogo de decodificación?

### Prioridad media

5. **¿`mainisiccode` equivale al CIIU colombiano?** El steering decía `economicactivitycode` pero en el sandbox se llama `mainisiccode`. ¿Es el mismo dato?

6. **¿`subscriberblockstatus` equivale al concepto de BLOQUEO de Teradata?** Lo encontramos en `xpm_location`. ¿Qué valores tiene?

7. **¿La lógica de `MAT_REPORTE_REL_PERS_UBI` se debe reconstruir en Redshift?** No existe como vista ni tabla en el sandbox. Tiene lógica compleja de fechas de vigencia.

---

*Documento actualizado: 2026-04-21 | Fuentes: steering files XPM/Redshift + validación sandbox ddm_xpm_db via Redshift Data API*


## 6. Inventario de Catálogos y Surrogate Keys (Cod_DW_*)

> Análisis solicitado por Juan Carlos Molina (2026-04-24): identificar todas las tablas de catálogos/lookup y campos subrogados del código Teradata, clasificarlos, y validar qué existe en el sandbox XPM de Redshift.

### 6.1 Tablas de Catálogos / Lookup

| # | Tabla Teradata | Schema | Uso en Unificación | ¿Existe en XPM? | Decisión migración |
|---|---------------|--------|-------------------|-----------------|-------------------|
| 1 | `NOMENCLATURA` | REC_DATOS / P_BDDATOS | Catálogo de nomenclaturas de complementos (89 registros). Se usa en R1 y R2 para descomponer complementos por nivel. JOIN con `DICCIONARIO_COMPLEMENTOS` vía campo `Nomen`. Tiene `Nivel_Complemento` para ordenar. | ❌ No existe | Crear en `bdm_datos.nomenclatura`. Cargar datos estáticos (89 registros). Fuente: dump original del cliente. |
| 2 | `DICCIONARIO_COMPLEMENTOS` | P_BDSTAGE | Diccionario que mapea texto de complemento → nomenclatura + valor. Se usa con `LIKE '%'||DC.nomenclatura||'%'` para parsear complementos. Tiene campos: `nomenclatura`, `nomen`, `valor`, `cod_dw_ubic`. | ❌ No existe | Crear en `bdm_datos`. **Depende de EDF**: si la estandarización separa complementos, esta tabla podría simplificarse o eliminarse. Confirmar con Experian. |
| 3 | `REC_MTDAT.MAX_ID` | REC_MTDAT | Tabla de metadatos para generar surrogate keys. Patrón: `SELECT ID FROM MAX_ID WHERE NOMBRE_TABLA='X'` + `SUM(1) OVER()`. No es secuencia automática — es lookup manual. | ❌ No existe | **Reemplazar con `IDENTITY` o secuencias en Redshift.** Patrón Teradata: `MAX_ID + SUM(1) OVER(ROWS UNBOUNDED PRECEDING)`. Equivalente Redshift: columna `GENERATED BY DEFAULT AS IDENTITY` o `CREATE SEQUENCE`. |
| 4 | `TMP_Unificacion_VIA_DIR` | P_BDSTAGE / REC_STAGE | Diccionario de vías para Regla 3. Se crea dinámicamente en el SP. Contiene mapeo de vías generadoras para comparación por lat/long. | ❌ No existe | **Depende de EDF (Regla 3).** Si EDF genera desglose de componentes de dirección, esta tabla se reconstruye en Redshift. Si no, Regla 3 no es viable. |
| 5 | `V_Insumo_Unificacion_Regla` / `Regla2` | P_BDSTAGE | Vista de trabajo que alimenta las reglas. Se crea como tabla temporal en cada ejecución. Contiene el insumo pre-filtrado por regla. | 🔧 Se reconstruye | No es catálogo — es vista de trabajo. Se recrea en Redshift como parte del flujo migrado. |

### 6.2 Campos Cod_DW_* — Clasificación

| # | Campo | Clasificación | Cómo se genera/usa en Teradata | Reglas | Equivalente en XPM | Decisión migración |
|---|-------|--------------|-------------------------------|--------|--------------------|--------------------|
| 1 | `COD_DW_PERSONA_UBIC` | 🔑 **Surrogate key** (generada) | `CASE WHEN NULL THEN MAX_ID('RELACION_PERSONA_UBICACION') + SUM(1) OVER() ELSE valor_existente END` | R1,R2,R3 | ❌ No existe. Derivar como `xpm.id` + `xpm_location.index` | Generar con `IDENTITY` o `ROW_NUMBER()` en Redshift. Para registros nuevos (Regla 2), usar secuencia. |
| 2 | `COD_DW_DIRECCION_FISICA` | 🔑 **Surrogate key** (generada) | `CASE WHEN NULL THEN MAX_ID('DIRECCION_FISICA') + SUM(1) OVER() ELSE valor_existente END` | R2 | ❌ No existe. No hay tabla DIRECCION_FISICA en XPM | Generar con `IDENTITY` en Redshift. Solo se genera para registros nuevos de Regla 2. |
| 3 | `COD_DW_UBIC` | 🔗 **FK a datos** | FK a `UBICACION_ESTANDARIZADA`. Se usa en JOINs y como parte de PRIMARY INDEX. También se usa en JOIN con `DICCIONARIO_COMPLEMENTOS`. | R1,R2,R3 | ❌ No existe directamente. Posible: `xpm_location.index` | Derivar en Redshift. Candidato: `xpm_location.index` o generar con `ROW_NUMBER()`. |
| 4 | `COD_DW_TIPO_UBICACION_DIR` | 🔗 **FK a catálogo** | FK al tipo de uso de la dirección (RES/LAB/CRR). Se usa en PARTITION BY y condiciones de igualdad entre pares padre-hijo. | R1,R2 | 🔵 `contactinformations.val.contacttype` (BIGINT) | **Mapear a `contacttype`.** Falta catálogo de decodificación — confirmar valores con Experian. |
| 5 | `COD_DW_DOC_IDENT` | 🔗 **FK a identidad** | FK a tabla de documentos de identidad. Se usa en Regla 2 para identificar personas. | R2 | ⚠️ `bestidentifications.val.personidnumber` (VARCHAR) | Mapear a `personidnumber`. Ojo: en Teradata es INTEGER, en XPM es VARCHAR. |
| 6 | `COD_DW_MUNICIPIO` | 🔗 **FK a ubicación** | FK a tabla de municipios. Se usa en Regla 2. | R2 | ❌ No existe `municipalitycode`. Solo `citycode` y `statecode` | **Confirmar con Experian** si `citycode` equivale a municipio colombiano. Si no, crear catálogo de mapeo. |
| 7 | `COD_DW_RELACION_PERSONA_UBICACION` | 🔗 **FK compuesta** | Identifica la relación persona-ubicación. Aparece en PRO_UnificacionR2. | R2 | ❌ No existe | Derivar como combinación de `xpm.id` + `xpm_location.index` + `contactinformations.index`. |
| 8 | `COD_DW_PERSONA_UBIC_HIJO` | 📎 **Alias interno** | Alias de `COD_DW_PERSONA_UBIC` para el registro hijo en comparaciones padre-hijo. Variable de cursor. | R2 | N/A (interno) | Se maneja como alias en el SQL migrado. No requiere mapeo XPM. |
| 9 | `COD_DW_PERSONA_UBIC_PADRE` | 📎 **Alias interno** | Alias de `COD_DW_PERSONA_UBIC` para el registro padre. Se asigna como `A.COD_DW_PERSONA_UBIC AS ID_PADRE`. | R2 | N/A (interno) | Se maneja como alias en el SQL migrado. No requiere mapeo XPM. |
| 10 | `COD_DW_UBIC_H` | 📎 **Alias interno** | Variable `DECLARE V_COD_DW_UBIC_H VARCHAR(30)`. Se usa en cursor `Cur_Nomenclatura` para iterar sobre registros hijo. | R1,R2 | N/A (interno) | Se elimina — el cursor se reemplaza por operación set-based en Redshift. |

### 6.3 Patrón de Generación de Surrogate Keys — Teradata vs Redshift

```
-- TERADATA (patrón actual)
CASE WHEN DF.COD_DW_DIRECCION_FISICA IS NULL
  THEN ((SELECT ID FROM REC_MTDAT.MAX_ID WHERE NOMBRE_TABLA = 'DIRECCION_FISICA')
        + SUM(1) OVER (ROWS UNBOUNDED PRECEDING))
  ELSE DF.COD_DW_DIRECCION_FISICA
END AS COD_DW_DIRECCION_FISICA

-- REDSHIFT (equivalente propuesto)
-- Opción A: Secuencia
CREATE SEQUENCE bdm_datos.seq_direccion_fisica START WITH <max_actual + 1>;
CASE WHEN df.cod_dw_direccion_fisica IS NULL
  THEN NEXTVAL('bdm_datos.seq_direccion_fisica')
  ELSE df.cod_dw_direccion_fisica
END AS cod_dw_direccion_fisica

-- Opción B: ROW_NUMBER (si se procesan en batch)
CASE WHEN df.cod_dw_direccion_fisica IS NULL
  THEN <max_actual> + ROW_NUMBER() OVER (ORDER BY 1)
  ELSE df.cod_dw_direccion_fisica
END AS cod_dw_direccion_fisica
```

> **Nota:** `NEXTVAL` en Redshift no se puede usar dentro de un `CASE`. La Opción B (ROW_NUMBER) es más compatible con el patrón original de Teradata que usa `SUM(1) OVER()`.

### 6.4 Resumen de Decisiones

| Categoría | Cantidad | Acción |
|-----------|----------|--------|
| 🔑 Surrogate keys (generadas con MAX_ID) | 2 | Reemplazar con secuencia/ROW_NUMBER en Redshift |
| 🔗 FK a datos/catálogos | 5 | Mapear a campos XPM o derivar |
| 📎 Alias internos del proceso | 3 | Se manejan en SQL migrado, no requieren mapeo |
| Catálogos a crear en bdm_datos | 2 | NOMENCLATURA (89 reg), DICCIONARIO_COMPLEMENTOS |
| Catálogos que dependen de EDF | 1 | TMP_Unificacion_VIA_DIR (Regla 3) |
| Mecanismo a reemplazar | 1 | REC_MTDAT.MAX_ID → secuencias Redshift |

### 6.5 Preguntas adicionales para Experian

| # | Pregunta | Impacto | Prioridad |
|---|----------|---------|-----------|
| 1 | ¿Los 89 registros de NOMENCLATURA son estáticos o cambian entre ejecuciones? | Define si se carga una vez o se actualiza | Media |
| 2 | ¿DICCIONARIO_COMPLEMENTOS se genera en la estandarización (EDF) o es dato de entrada? | Define si Redshift lo recibe o lo crea | **Alta** |
| 3 | ¿`contacttype` (BIGINT) en XPM usa los mismos códigos que `Cod_DW_Tipo_Ubicacion_Dir`? ¿Cuál es el catálogo? | Mapeo directo vs tabla de conversión | **Alta** |
| 4 | ¿`citycode` en XPM equivale al código de municipio DANE colombiano? | Define si `COD_DW_MUNICIPIO` se puede mapear directo | Media |
| 5 | ¿La numeración de surrogate keys debe ser continua con la existente en Teradata o puede reiniciar en Redshift? | Define seed de secuencias | **Alta** |

---

*Sección agregada: 2026-04-24 | Fuente: análisis de Unificacion.sql + PRO_UnificacionR2.sql + sandbox XPM | Solicitado por: Juan Carlos Molina*

---

## 7. Hallazgos de Reunión Técnica con Experian (2026-04-24)

> Reunión con Juan Carlos Molina, John Bueno, John Andrade, Fernando y Wilmar.
> Objetivo: validar mapeo de campos y definir contrato de datos con equipo de Ingesta (IDF).

### 7.1 Confirmaciones

| Campo / Concepto | Lo que teníamos | Lo que confirmó Experian |
|-----------------|-----------------|-------------------------|
| Campos `Cod_DW_*` | Surrogate keys, no aplican en Redshift | ✅ Confirmado. Son llaves subrogadas del DW, autogeneradas. No se migran. Se navega el modelo por estos IDs pero en Redshift se reemplazan. |
| Complementos de dirección (torre, apto, etc.) | No existen separados en XPM | ✅ Confirmado. Vienen concatenados en la dirección completa. Existe una **UDF en C** que los separa (en carpeta `UDF/` del dump original). |
| `Fecha_Relacion_Persona_Ubicaci` | Hallazgo 🔵: `locationfirsteventdate` | ✅ Confirmado. Se mapeó a `location.val.locationfirsteventdate`. Es la fecha del primer evento por fuente de datos. |
| `Numero_Entidades_Reportan` | Derivable con COUNT DISTINCT | ✅ Confirmado. Es calculado. Lo hace la estandarización en Teradata. Contar suscriptores que reportan el mismo dato. |
| Catálogos (NOMENCLATURA, etc.) | Crear en bdm_datos | ✅ Ya existe proceso automático **Colibrí → Redshift** para carga de catálogos. No hay que inventar carga manual. |

### 7.2 Información nueva

| Campo / Concepto | Hallazgo | Impacto |
|-----------------|----------|---------|
| **Bloqueo** | No existe hoy en el modelo XPM. Debe venir de IDF como un **flag por dato de contacto**. Es funcionalidad de "Reclamación 2.0". Si un dato está bloqueado (fraude/reclamación), no debe usarse en ningún producto. | 🔴 **Agregar campo `bloqueado` a tablas de entrada en Redshift.** Hoy no está en `01_schemas_roles.sql`. |
| **`Ind_Unificacion`** | Es un flag que marca direcciones que fueron unificadas. Las marcadas no se muestran — se muestra la dirección nueva/mejorada que resultó de la unificación. | Ya lo teníamos como campo interno. Confirmado su uso. |
| **`Generada_Enriquecida`** | Nadie en la reunión recordaba qué era. Quedó pendiente de análisis en código. | ⚠️ Pendiente revisión en código Teradata. |
| **`MAT_REPORTE_REL_PERS_UBI`** | Es una tabla materializada con lógica de fechas de reportes (fecha inicio, fin, actualizaciones). Relaciona persona + ubicación + reporte. | ⚠️ Pendiente análisis más profundo. Posible equivalencia con `locationfirsteventdate` + `locationeventlastupdated`. |
| **`Cod_Pin_Persona`** | Agrupa a toda la persona (puede aparecer como NIT y como persona natural). Es diferente al `id` del XPM. | ⚠️ El pin de Teradata **no es el mismo** que el de Redshift/XPM. Verificar mapeo. |
| **Catálogos en Teradata** | Existe una tabla agnóstica con estructura: dato + descripción + tipo de catálogo. Contiene nomenclaturas, topónimos, acepciones, tipos de documento, etc. | Los catálogos se cargan desde **Colibrí** a Redshift. Simplifica la migración. |

### 7.3 Decisiones tomadas

| # | Decisión | Detalle |
|---|----------|---------|
| 1 | Los `Cod_DW_*` no se migran | Son surrogate keys de Teradata. En Redshift se reemplazan con mecanismos nativos. |
| 2 | `Fecha_Relacion_Persona_Ubicaci` = `locationfirsteventdate` | Mapeo confirmado en reunión. |
| 3 | Catálogos se cargan vía Colibrí | No crear proceso manual. Usar el flujo existente Colibrí → Redshift. |
| 4 | Completar Ordenamiento antes de llevar paquete a IDF | Para no tener reprocesos en el contrato de datos. |

### 7.4 Compromisos pendientes

| # | Compromiso | Responsable | Estado |
|---|-----------|-------------|--------|
| 1 | Definir con Ingesta si la separación de complementos se hace en estandarización (EDF) o en Reconocer (Redshift) | Equipo + Adriana | ⏳ Pendiente sesión |
| 2 | Wilmar revisar la UDF de estandarización de direcciones (C) compartida por John | Wilmar | ⏳ Pendiente |
| 3 | Proponer estructura de campos/tablas XPM incluyendo: bloqueo, complementos, y todos los campos identificados | Macondotek | ⏳ Pendiente |
| 4 | Completar análisis de Ordenamiento para tener paquete completo de requerimientos | Macondotek | ✅ Migración completada |
| 5 | Programar sesión con Adriana y equipo de proyecto para definir contrato con Ingesta | Fernando / Juan Carlos | ⏳ Pendiente |
| 6 | Revisar en código Teradata qué hace `Generada_Enriquecida` | Macondotek | ⏳ Pendiente |
| 7 | Análisis profundo de `MAT_REPORTE_REL_PERS_UBI` — lógica de fechas | Macondotek + John Bueno | ⏳ Pendiente |

### 7.5 Impacto en el checklist de pre-ejecución

El campo **`bloqueado`** debe agregarse a:
- `bdm_datos.relacion_persona_ubicacion` (flag por dato de contacto)
- El checklist `00_checklist_pre_ejecucion.sql` debe validar que este campo exista y tenga valores válidos

---

*Sección agregada: 2026-04-24 | Fuente: transcripción reunión técnica Experian | Asistentes: Juan Carlos Molina, John Bueno, John Andrade, Fernando, Wilmar*