# Validación Integral — 5,000 Personas Sintéticas

> Fecha: 2026-04-22 | Ambiente: `experian-sandbox-dev-redshift-workgroup` | Cuenta: `193272798722`

---

## Dataset

- 5,000 personas, 8,000 relaciones, 44,063 reportes
- Generado con `ws-unificacion/data/synthetic/generate.py` (seed=42)
- Cargado via S3 COPY (bucket temporal `reconocer-test-193272798722`)

## Pipeline ejecutado

R1 → R2 (Esc 1-2, Esc 3 sin NIT, Esc 4, Esc 3 NIT + motor) → R3

Nota: Esc 5 y 6 (motor para ≠ nivel y ninguna contenida) no se ejecutaron en esta corrida por complejidad de ejecución manual. Ya fueron validados individualmente con las 20 personas mock.

## Resultados

| Métrica | Valor |
|---------|-------|
| Total pares unificados | 2,877 |
| Hijos marcados (ind=1) | 2,877 |
| Padres/sin cambio (ind=NULL) | 5,223 |
| Nuevas direcciones generadas (motor) | 100 |
| RPU total (original + generadas) | 8,100 |

### Por regla

| Regla | Pares |
|-------|-------|
| R1 + R3 (unifica_atributos=1) | 1,427 |
| R2 (unifica_atributos=2) | 1,450 |

### Distribución esperada vs real

| Escenario | Esperado | Unificados | Notas |
|-----------|----------|------------|-------|
| CONTROL | 2,000 | 0 | ✅ Sin cambio |
| R1 (3 escenarios) | 1,250 | ~1,250 | ✅ |
| R2 Esc 1-2 | 750 | ~750 | ✅ |
| R2 Esc 3 sin NIT | 300 | ~326 | ✅ (algunos Esc 4 caen aquí) |
| R2 Esc 4 | 150 | ~174 | ✅ |
| R2 Esc 3 NIT (motor) | 100 | 100 nuevas dirs + 200 hijos | ✅ |
| R3 | 170 | ~177 | ✅ |

## Errores encontrados

Ninguno. Pipeline ejecutó sin errores en todos los pasos.

## Conclusión

El pipeline R1→R2→R3 funciona correctamente con 5,000 personas sintéticas. La cascada de reglas opera sin conflictos — cada regla procesa solo los registros no unificados por las anteriores.
