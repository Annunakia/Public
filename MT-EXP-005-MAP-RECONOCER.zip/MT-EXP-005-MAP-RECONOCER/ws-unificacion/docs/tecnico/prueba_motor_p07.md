# Prueba: Motor de Nuevas Direcciones — P07 (NIT, Escenario 3)

> Fecha: 2026-04-22 | Ambiente: `experian-sandbox-dev-redshift-workgroup` | Cuenta: `193272798722`

---

## Objetivo

Validar que el motor (`06_motor_nuevas_direcciones.sql`) genera correctamente una nueva dirección combinando complementos cuando las direcciones de un NIT tienen la misma nomenclatura pero diferente valor.

## Datos de entrada

| Registro | Id_Buro | Puerta | Complemento | Tipo Ident | Entidades |
|----------|---------|--------|-------------|------------|-----------|
| P07-A (100014) | 1007 | CL 10 20 30 | LC 101 | NIT (3) | 3 |
| P07-B (100015) | 1007 | CL 10 20 30 | LC 205 | NIT (3) | 3 |

Diccionario: LC 101 (freq=8), LC 205 (freq=4)

## Resultado esperado

Nueva dirección **"LC 101 LC 205"** generada. Ambos originales marcados como hijos.

## Resultado obtenido

### Checkpoints intermedios

| Checkpoint | Esperado | Obtenido | Estado |
|-----------|----------|----------|--------|
| stg_motor_input | 2 filas (100014, 100015) | 2 filas | ✅ |
| stg_motor_descomp | LC 101 nivel 6, LC 205 nivel 6 | Correcto | ✅ |
| MDIR | 100014=MDIR 1 (val 101), 100015=MDIR 2 (val 205) | Correcto | ✅ |
| Padre/Hijo | 100014=padre, 100015=hijo | Correcto | ✅ |
| stg_motor_diff | LC 205 (nomenclatura del hijo que difiere) | 1 fila: LC 205 | ✅ |
| stg_motor_resultado | "LC 101 LC 205" | Correcto | ✅ |
| stg_motor_final | nueva DF=6012, nueva RPU=100016 | Correcto | ✅ |

### Tests finales

| # | Test | Esperado | Obtenido | Estado |
|---|------|----------|----------|--------|
| 1 | Nueva dirección en DIRECCION_FISICA | "LC 101 LC 205", generada_enriquecida=1 | "LC 101 LC 205", generada_enriquecida=1 | **PASS** |
| 2 | P07-A y P07-B marcados como hijos | ind_unificacion=1 en ambos | ind_unificacion=1 en ambos | **PASS** |
| 3 | Nueva relación persona-ubicación | 100016 → persona 1007 → "LC 101 LC 205" | Correcto | **PASS** |
| 4 | Pares en UNIFICACION_DIRECCION | 100014→100016, 100015→100016 | Correcto | **PASS** |
| 5 | Conteo nuevas direcciones | 1 | 1 | **PASS** |
| 6 | Cero falsos positivos | 0 registros no-P07 tocados | 0 | **PASS** |

### Estado final de RELACION_PERSONA_UBICACION

| cod_dw_persona_ubic | ind_unificacion | cod_dw_direccion_fisica | fecha |
|---------------------|-----------------|------------------------|-------|
| 100014 | 1 (hijo) | 6010 (LC 101) | 2025-04-01 |
| 100015 | 1 (hijo) | 6011 (LC 205) | 2025-06-01 |
| 100016 | NULL (padre nuevo) | 6012 (LC 101 LC 205) | 2026-04-22 |

## Bug encontrado y corregido

**Problema**: El motor solo marcaba como hijo al registro con MDIR>1 (100015). Pero en escenarios que generan nuevas direcciones, el padre MDIR original (100014) también debe ser hijo del nuevo padre generado.

**Causa**: En Teradata, el SP `PRO_UnificacionR2` marca explícitamente ambos originales como hijos (N_ID='X4'). El motor genérico solo conoce padre/hijo del MDIR, no del nuevo padre.

**Fix aplicado**:
- `06_motor_nuevas_direcciones.sql` — paso 11: INSERT adicional del padre MDIR en UNIFICACION_DIRECCION. Paso 12: UPDATE ind_unificacion en padre MDIR + hijos.
- `07_regla2_esc3_nit.sql` — paso 5: UPDATE adicional de E2 para el padre MDIR original.

**Otro fix**: DISTKEY de `stg_regla2_e03_nit_pares` cambiado de `id_buro_persona` a `cod_dw_persona_ubic` (la tabla solo tiene esa columna).

## Conclusión

Motor funcional. 6/6 tests PASS después del fix. Listo para usar en escenarios 5 y 6 que también invocan al motor.
