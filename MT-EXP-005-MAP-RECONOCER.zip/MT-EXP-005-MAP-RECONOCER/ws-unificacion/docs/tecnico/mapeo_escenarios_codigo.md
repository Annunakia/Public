# Mapeo Escenario ↔ Código – PRO_UnificacionR2.sql

> Archivo: `PRO_UnificacionR2.sql` (6,220 líneas). Cada escenario del doc funcional mapeado a líneas exactas del SP.

---

## Mapa General

```
Líneas    Escenario                                    Tablas temporales
──────    ─────────                                    ──────────────────
1-68      Declaración de variables
72-246    ESCENARIO 1: Complemento vacío               Tmp_Unificacion_0E1 → Tmp_Unificacion_E1
250-439   ESCENARIO 2: Complemento incluido            Tmp_Unificacion_0E2 → Tmp_Unificacion_E2
444-1834  ESCENARIO 3: Misma nomenclatura, ≠ valor     Tmp_Unificacion_E03, E03_A, E03_E1, E031, E03_B
1838-2246 ESCENARIO 4: ≠ nomenclatura, mismo nivel     Tmp_Unificacion_E04, E04_A
2250-4011 ESCENARIO 5: ≠ nomenclatura, ≠ nivel         Tmp_Unificacion_E051 (subcaso 1 y 2)
4015-5847 ESCENARIO 6: Ninguna contenida en otra       Tmp_Unificacion_E06 (subcasos 1, 2, 3)
5911-6070 CONSOLIDACIÓN: R2_Vstg_Unificacion + SetComplement + Stats
6070-6220 SALIDA: Identificación registros existentes en DIRECCION_FISICA
```

---

## Detalle por Escenario

### Escenario 1: Un complemento vacío (L72-L246)

**Doc funcional**: "Si uno de los complementos no tiene información, se toma la dirección más completa."

| Líneas | Tabla temporal | Qué hace |
|--------|---------------|----------|
| 88-148 | `Tmp_Unificacion_0E1` | JOIN de V_Insumo_Regla2 consigo misma. Donde A tiene complemento y B no (y viceversa). Genera pares hijo→padre |
| 180-207 | `Tmp_Unificacion_E1` | Marca `Ind_Unificacion='S'` en hijos, `'N'` en no-unificados. Asigna `N_ID='H1'` |

**Lógica clave** (L123-124):
```sql
WHERE A.COMPLEMENTO IS NOT NULL AND B.COMPLEMENTO IS NULL
```

---

### Escenario 2: Un complemento incluido en otro (L250-L439)

**Doc funcional**: "Si un complemento está completamente incluido en el otro, se toma la dirección más completa."

| Líneas | Tabla temporal | Qué hace |
|--------|---------------|----------|
| 271-320 | `Tmp_Unificacion_0E2` | JOIN donde `A.COMPLEMENTO LIKE '%'||B.COMPLEMENTO||'%'`. Solo registros con `Ind_Unificacion='N'` |
| 360-399 | `Tmp_Unificacion_E2` | Marca hijos con `N_ID='K2'`. Hereda marcas de Escenario 1 |

**Lógica clave** (L282):
```sql
WHERE A.COMPLEMENTO LIKE '%' || B.COMPLEMENTO || '%'
  AND A.Ind_Unificacion = 'N'
```

---

### Escenario 3: Misma nomenclatura, diferente valor (L444-L1834)

**Doc funcional**: "La nomenclatura es la misma pero el valor que acompaña es diferente. Se valida número de entidades. Si es NIT, se combinan."

Este es el escenario más largo (1,390 líneas) porque tiene **2 casos**: sin NIT y con NIT.

#### Caso 1: Sin NIT (L462-L630)

| Líneas | Tabla temporal | Qué hace |
|--------|---------------|----------|
| 462-480 | `Tmp_Unificacion_E03` | Filtra registros NO NIT con `Ind_Unificacion='N'` |
| 510-580 | `Tmp_Unificacion_E03_A` | JOIN por misma nomenclatura (`NMC1.Nomenclatura=NMC2.Nomenclatura`). Calcula score: `fecha + entidades + 10000000`. Detecta empates |
| 590-630 | `Tmp_Unificacion_E03_E1` | Genera pares padre-hijo donde `A.ID > B.ID` (mayor score = padre) |

**Lógica clave** (L530-533):
```sql
INNER JOIN NOMENCLATURA NMC1 ON A.COMPLEMENTO LIKE NMC1.Nomenclatura || '%'
INNER JOIN NOMENCLATURA NMC2 ON B.COMPLEMENTO LIKE NMC2.Nomenclatura || '%'
WHERE NMC1.Nomenclatura = NMC2.Nomenclatura  -- misma nomenclatura
```

**Score** (L519):
```sql
CAST(COALESCE(Fecha, '1900/01/01') AS INTEGER) + COALESCE(Numero_entidades, 0) + 10000000
```

#### Caso 2: NIT (L632-L1834)

| Líneas | Tabla temporal | Qué hace |
|--------|---------------|----------|
| 632-680 | `Tmp_Unificacion_E031` | Filtra registros NIT con `Ind_Unificacion='N'` |
| 690-780 | `Tmp_Unificacion_E03_B` | Mismo patrón que E03_A pero para NITs |
| 797-1834 | Múltiples tablas `E03_B00`, `E051_D*` | **Llama a PRO_Unifi_MOTOR_TMP** — genera nuevas direcciones combinando complementos de NITs. Usa DICCIONARIO_COMPLEMENTOS, descompone nomenclaturas, genera SQL dinámico |

**Nota**: El caso NIT es donde entra el MOTOR_TMP (870 líneas adicionales) que genera las nuevas direcciones con SQL dinámico y XMLAGG.

---

### Escenario 4: Nomenclaturas diferentes, mismo nivel (L1838-L2246)

**Doc funcional**: "Si las nomenclaturas que difieren se encuentran al mismo nivel, se consulta el DICCIONARIO DE COMPLEMENTOS y se toma la de mayor frecuencia."

| Líneas | Tabla temporal | Qué hace |
|--------|---------------|----------|
| 1838-1950 | `Tmp_Unificacion_E04` | Filtra pares con nomenclaturas diferentes pero mismo `Nivel_Complemento` |
| 1950-2050 | `Tmp_Unificacion_E04_A` | JOIN con DICCIONARIO_COMPLEMENTOS. Compara frecuencias. Mayor frecuencia = padre |
| 2050-2246 | Merge a `Tmp_Unificacion_E2` | Actualiza `ID_PADRE` y `Ind_Unificacion` en la tabla acumulada |

**Lógica clave**:
```sql
WHERE NMC1.Nivel_Complemento = NMC2.Nivel_Complemento  -- mismo nivel
  AND NMC1.Nomenclatura <> NMC2.Nomenclatura            -- diferente nomenclatura
-- Luego JOIN con DICCIONARIO_COMPLEMENTOS para comparar frecuencias
```

---

### Escenario 5: Nomenclaturas diferentes, diferente nivel (L2250-L4011)

**Doc funcional**: "Si las nomenclaturas están en diferente nivel, se genera nueva dirección combinando ambas."

#### Subcaso 1: Valores diferentes → combina (L2250-L3607)

| Líneas | Tabla temporal | Qué hace |
|--------|---------------|----------|
| 2250-2400 | `Tmp_Unificacion_E051` | Filtra pares con nomenclaturas en diferente nivel |
| 2400-2600 | `Tmp_Unificacion_E051_D` | Prepara datos para el MOTOR. JOIN con DICCIONARIO_COMPLEMENTOS |
| 2600-3607 | Múltiples tablas `E051_D*` | **Llama a PRO_Unifi_MOTOR_TMP** — genera nuevas direcciones combinando nomenclaturas de diferentes niveles |

**Este es el bloque más complejo del SP** — invoca el motor de generación de direcciones con SQL dinámico.

#### Subcaso 2: Valores iguales → diccionario (L3612-L4011)

| Líneas | Tabla temporal | Qué hace |
|--------|---------------|----------|
| 3612-3830 | Filtro + JOIN DICCIONARIO | Misma lógica que Escenario 4 pero para nomenclaturas en diferente nivel con valores iguales |
| 3830-4011 | Merge a `Tmp_Unificacion_E2` | Actualiza padre-hijo |

---

### Escenario 6: Ninguna nomenclatura contenida en otra (L4015-L5847)

**Doc funcional**: "Cuando ninguna nomenclatura está contenida en otra, se evalúa si una está incluida en la otra, se arma nuevo complemento."

#### Subcaso 1: Nomenclaturas en diferente nivel → combina (L4015-L4708)

| Líneas | Tabla temporal | Qué hace |
|--------|---------------|----------|
| 4015-4339 | Filtro + preparación | Identifica pares donde ninguna nomenclatura contiene a la otra |
| 4339-4655 | **Llama a PRO_Unifi_MOTOR_TMP** | Genera nuevas direcciones |
| 4655-4708 | Merge | Actualiza padre-hijo |

#### Subcaso 2: Nomenclaturas en diferente nivel, otro patrón (L4715-L5448)

| Líneas | Tabla temporal | Qué hace |
|--------|---------------|----------|
| 4715-5395 | Filtro + MOTOR_TMP | Similar a subcaso 1 con variante de comparación |
| 5395-5448 | Merge | Actualiza padre-hijo |

#### Subcaso 3: Nomenclaturas en mismo nivel → diccionario (L5453-L5847)

| Líneas | Tabla temporal | Qué hace |
|--------|---------------|----------|
| 5453-5670 | JOIN con DICCIONARIO_COMPLEMENTOS | Compara frecuencias para mismo nivel |
| 5670-5847 | Merge | Actualiza padre-hijo. Mayor frecuencia = padre |

---

### Consolidación y Salida (L5911-L6220)

| Líneas | Qué hace |
|--------|----------|
| 5911-5915 | Renombra `Tmp_Unificacion_E2` → `R2_Vstg_Unificacion` |
| 5940-6030 | Aplica función `SetComplement()` (UDF en C) para limpiar complementos duplicados en direcciones generadas |
| 6055-6070 | Collect Statistics en `R2_Vstg_Unificacion` |
| 6070-6160 | Identifica registros que ya existen en `DIRECCION_FISICA` y `RELACION_PERSONA_UBICACION` (para evitar duplicados en INSERT) |
| 6160-6220 | Crea tabla final `R2_Vstg_Unificacion` con flag de existencia → alimenta P0020_130 para persistencia |

---

## Resumen: Dónde se invoca el MOTOR_TMP

El SP `PRO_Unifi_MOTOR_TMP` (generador de nuevas direcciones con SQL dinámico) se invoca en:

| Escenario | Caso | Líneas aprox | Razón |
|-----------|------|-------------|-------|
| 3 | NIT | ~797-1834 | NITs combinan complementos |
| 5 | Subcaso 1 | ~2600-3607 | Nomenclaturas en ≠ nivel, valores diferentes |
| 6 | Subcaso 1 | ~4339-4655 | Ninguna contenida, ≠ nivel |
| 6 | Subcaso 2 | ~4715-5395 | Variante de subcaso 1 |

**Total**: 4 invocaciones del MOTOR_TMP dentro del SP principal.

---

## Complejidad por Escenario (para planificar migración)

| Escenario | Líneas | Complejidad | Usa MOTOR_TMP | Estrategia migración |
|-----------|--------|-------------|---------------|---------------------|
| 1 | 174 | 🟢 Baja | No | Prompt directo |
| 2 | 189 | 🟢 Baja | No | Prompt directo |
| 3 | 1,390 | 🔴 Alta | Sí (caso NIT) | Spec Driven |
| 4 | 408 | 🟡 Media | No | Prompt directo + ajustes |
| 5 | 1,761 | 🔴 Muy Alta | Sí (subcaso 1) | Spec Driven |
| 6 | 1,832 | 🔴 Muy Alta | Sí (subcasos 1 y 2) | Spec Driven |
| Consolidación | 309 | 🟡 Media | No | Prompt directo |

---

*Generado: 2026-04-17 | Fuente: PRO_UnificacionR2.sql (6,220 líneas)*
