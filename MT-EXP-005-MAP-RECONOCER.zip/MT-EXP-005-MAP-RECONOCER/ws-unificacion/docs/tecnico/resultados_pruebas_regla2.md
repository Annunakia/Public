# Resultados de Pruebas — Regla 2 Unificación por Complementos

> Consolidado de todas las pruebas ejecutadas en sandbox Redshift.
> Ambiente: `experian-sandbox-dev-redshift-workgroup` | Cuenta: `193272798722`

---

## 1. Resumen ejecutivo

| Escenario | Script | Personas | Tests | Estado | Fecha |
|-----------|--------|----------|-------|--------|-------|
| Esc 1 (vacío) | 03_regla2_esc1_2.sql | P04 | 1/1 PASS | **Validado** | 2026-04-22 |
| Esc 2 (incluido) | 03_regla2_esc1_2.sql | P05 | 1/1 PASS | **Validado** | 2026-04-22 |
| Esc 3 sin NIT | 05_regla2_esc3_sin_nit.sql | P06 | 1/1 PASS | **Validado** | 2026-04-22 |
| Esc 3 con NIT | 07_regla2_esc3_nit.sql + 06_motor | P07 | 6/6 PASS | **Validado** | 2026-04-22 |
| Esc 4 (mismo nivel) | 04_regla2_esc4.sql | P08* | 0/0 | **No aplica** — P08 cae en Esc 3 | 2026-04-22 |
| Esc 4 (mismo nivel) | 04_regla2_esc4.sql | P20 | 1/1 PASS | **Validado** | 2026-04-22 |
| Esc 5 sub1 (≠ valor → motor) | 08_regla2_esc5.sql + 06_motor | P09, P11 | 4/4 PASS | **Validado** | 2026-04-22 |
| Esc 5 sub2 (= valor → diccionario) | 08_regla2_esc5.sql | P10 | 1/1 PASS | **Validado** | 2026-04-22 |
| Esc 6 sub3 (= nivel → diccionario) | 09_regla2_esc6.sql | P12 | 1/1 PASS | **Validado** | 2026-04-22 |

---

## 2. Detalle por prueba

### 2.1 Motor P07 — Escenario 3 NIT (2026-04-22)

**Input**: P07-A (LC 101) + P07-B (LC 205), ambos NIT, misma puerta CL 10 20 30.

**Resultado**: Nueva dirección **"LC 101 LC 205"** generada correctamente.

| Test | Verificación | Resultado |
|------|-------------|-----------|
| 1 | Nueva dirección en DIRECCION_FISICA | PASS — "LC 101 LC 205", generada_enriquecida=1 |
| 2 | P07-A y P07-B marcados como hijos | PASS — ind_unificacion=1 en ambos |
| 3 | Nueva relación persona-ubicación | PASS — 100016 → persona 1007 |
| 4 | Pares en UNIFICACION_DIRECCION | PASS — 100014→100016, 100015→100016 |
| 5 | Conteo nuevas direcciones | PASS — exactamente 1 |
| 6 | Cero falsos positivos | PASS — 0 registros no-P07 tocados |

### 2.2 Escenarios 1-2, 3 sin NIT, 4 — P04, P05, P06, P08 (2026-04-22)

| Persona | Escenario | Complementos | Resultado | N_ID |
|---------|-----------|-------------|-----------|------|
| P04 (1004) | Esc 1 | AP 802 vs vacío | Padre: AP 802 (tiene complemento) | H1 |
| P05 (1005) | Esc 2 | ED GALICIA AP 702 vs AP 702 | Padre: ED GALICIA AP 702 (más completo) | K2 |
| P06 (1006) | Esc 3 sin NIT | AP 105 vs AP 404 | Padre: AP 105 (mayor score) | L3 |
| P08 (1008) | Esc 3 sin NIT* | CS 312 vs CS 108 | Padre: CS 108 (mayor score por fecha) | L3 |

*P08 fue capturado por escenario 3 sin NIT (misma nomenclatura CS, diferente valor), no por escenario 4. Ver observación en sección 4.

### 2.3 Escenarios 5 y 6 — P09, P10, P11, P12 (2026-04-22)

| Persona | Escenario | Complementos | Resultado | N_ID |
|---------|-----------|-------------|-----------|------|
| P09 (1009) | Esc 5 sub1 | TO 3 + AP 504 | Nueva: **"TO 3 AP 504"** | M5 |
| P10 (1010) | Esc 5 sub2 | TO 3 vs AP 3 | Padre: AP 3 (mayor score) | D5 |
| P11 (1011) | Esc 5 sub1 | ED PROMOTOR + OF 2007 | Nueva: **"ED PROMOTOR OF 2007"** | M5 |
| P12 (1012) | Esc 6 sub3 | BR CASTILLA vs BR VENECIA | Padre: BR CASTILLA (freq=20) | D6 |

---

## 3. Bugs encontrados y corregidos

### Bug 1: Padre MDIR no marcado como hijo del nuevo padre (06_motor, 07_esc3_nit)

**Encontrado en**: Prueba P07
**Problema**: El motor solo marcaba como hijo al registro con MDIR>1. Pero en escenarios que generan nuevas direcciones, el padre MDIR original también debe ser hijo del nuevo padre generado.
**Causa**: En Teradata, el SP marca explícitamente ambos originales como hijos (N_ID='X4'). El motor genérico solo conocía padre/hijo del MDIR.
**Fix**: 
- `06_motor_nuevas_direcciones.sql` — paso 11: INSERT adicional del padre MDIR. Paso 12: UPDATE ambos.
- `07_regla2_esc3_nit.sql` — paso 5: UPDATE adicional de E2 para padre MDIR.
**Commit**: `753a970`

### Bug 2: DISTKEY incorrecto en stg_regla2_e03_nit_pares (07_esc3_nit)

**Encontrado en**: Prueba P07
**Problema**: `DISTKEY(id_buro_persona)` pero la tabla solo tiene `cod_dw_persona_ubic`.
**Fix**: Cambiar a `DISTKEY(cod_dw_persona_ubic)`.
**Commit**: `753a970`

### Bug 3: Subcaso 2 del escenario 5 no capturaba P10 (08_esc5)

**Encontrado en**: Prueba P10
**Problema**: El subcaso 2 filtraba desde `stg_regla2_e05_c` que ya excluía pares con `complemento2` iguales (por el filtro `NOT LIKE`). P10 (TO 3 y AP 3, ambos con complemento2="3") nunca llegaba al subcaso 2.
**Fix**: Cambiar filtro del subcaso 2 para que filtre directamente desde `stg_regla2_e05_a` con condición `TRIM(A.complemento2) = TRIM(B.complemento2) AND A.nivel_pri <> B.nivel_pri`.
**Commit**: `7c8f4ca`

---

## 4. Observaciones

### P10: Resultado difiere del README de datos mock

El README dice "padre = TO 3 (freq=12)" pero el resultado real es "padre = AP 3". Esto es correcto: el score es `(frecuencia + 10M) + fecha_como_entero`. AP 3 tiene fecha más reciente (20250501 vs 20250401) que compensa la menor frecuencia (4 vs 12). Score: AP 3 = 30250505 > TO 3 = 30250413. **El código es correcto, el README necesita ajustarse.**

### P11: Capturado por escenario 5, no por escenario 6

P11 (ED PROMOTOR nivel 2 + OF 2007 nivel 6) fue capturado por el escenario 5 subcaso 1 porque tiene nomenclaturas en diferente nivel. Esto es correcto — los escenarios se ejecutan en cascada y el 5 procesa antes que el 6. El escenario 6 solo procesa lo que queda sin unificar.

### P08: Capturado por escenario 3, no por escenario 4

P08 (CS 312 y CS 108) tiene la misma nomenclatura (CS) con diferente valor. Esto es escenario 3 (misma nomenclatura ≠ valor), no escenario 4 (nomenclaturas diferentes al mismo nivel). El escenario 3 usa score de fecha+entidades, no frecuencia del diccionario. CS 108 tiene mayor score (fecha 2025-08-01 > 2025-05-01). **El README necesita ajustarse: P08 no es un caso de escenario 4.**

---

## 5. Pendientes de validación

- [ ] Validación integral con las 20 personas de punta a punta (R1 → R2 completa)
- [x] Ajustar README_datos_mock.md: P10 (padre=AP 3), P08 (escenario 3, padre=CS 108)
- [x] Diseñar dato mock específico para escenario 4: P20 (PI 5 vs CS 201, nivel 5) — validado en sandbox

---

## Regla 3: Resultados de pruebas (2026-04-22)

| Persona | Escenario | Subcaso | Resultado | Estado |
|---------|-----------|---------|-----------|--------|
| P13 | Esc1 ≠ vía gen | Sub1 (solo uno geo) | Padre: 100026 (tiene lat/long) | **PASS** |
| P14 | Esc1 ≠ vía gen | Sub2 (sin geo) | Padre: 100028 (fecha más reciente) | **PASS** |
| P15 | Esc1 ≠ vía gen | Sub3 (ambos geo) | Padre: 100030 (dict: vía 181 freq=3) | **PASS** |
| P16 | — | — | Excluido (modificador "77A") | **PASS** |
| P17 | Esc2 ≠ puerta | Sub2 (sin geo) | Padre: 100034 (fecha más reciente) | **PASS** |
| P18 | Esc2 ≠ puerta ±2 | Sub3 (ambos geo) | Padre: 100036 (dict: puerta 55 freq=4) | **PASS** |
| P19 | — | — | Sin cambio (diferencia puerta >2) | **PASS** |

---

*Última actualización: 2026-04-22*
