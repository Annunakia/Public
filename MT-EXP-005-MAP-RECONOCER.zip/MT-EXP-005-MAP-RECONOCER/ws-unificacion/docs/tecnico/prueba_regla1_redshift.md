# Prueba de Migración – Regla 1 de Unificación

> Ejecutada: 2026-04-17 | Ambiente: Redshift Serverless (experian-sandbox-dev)

---

## 1. Flujo General de la Prueba

```
DATOS MOCK (CSVs)                  REDSHIFT (rec_mock)                    RESULTADO
─────────────────                  ───────────────────                    ─────────

RELACION_PERSONA_                  relacion_persona_                     unificacion_
UBICACION.csv ──────────────────▶  ubicacion ──────┐                     direccion
(39 registros)                     (39 registros)  │                     (4 pares
                                                   │                      padre-hijo)
UBICACION_                         ubicacion_      │    ┌──────────┐
ESTANDARIZADA.csv ──────────────▶  estandarizada ──┼──▶ │ REGLA 1  │──▶  relacion_persona_
(26 registros)                     (26 registros)  │    │          │     ubicacion
                                                   │    │ 01_regla1│     (4 hijos marcados
DIRECCION_                         direccion_      │    │ _unifica │      Ind_Unificacion=1)
FISICA.csv ─────────────────────▶  fisica ─────────┤    │ cion.sql │
(28 registros)                     (28 registros)  │    └──────────┘
                                                   │
REPORTE_RELACION_                  reporte_relacion│
PERSONA_UBICA.csv ──────────────▶  _persona_ubica ─┤
(59 registros)                     (59 registros)  │
                                                   │
CIIU_PERSONA.csv ───────────────▶  ciiu_persona ───┤
(19 registros)                     (19 registros)  │
                                                   │
TIPO_UBICACION_                    tipo_ubicacion_  │
DIR.csv ────────────────────────▶  dir ─────────────┘
(5 registros)                      (5 registros)
```

---

## 2. Equivalencia Teradata → Redshift

### Archivos de código

| Teradata (origen) | Redshift (migrado) | Qué contiene |
|-------------------|--------------------|-------------|
| `P0019_UNIFICACION_111.TPT` | `01_regla1_unificacion.sql` | Lógica de los 3 escenarios + generación de pares padre-hijo |
| `P0019_UNIFICACION_130.TPT` | (incluido en el mismo archivo) | Persistencia: INSERT en unificacion_direccion + UPDATE Ind_Unificacion=1 |

### Tablas

| Teradata | Redshift | Rol |
|----------|----------|-----|
| `REC_DATOS.RELACION_PERSONA_UBICACION` | `rec_mock.relacion_persona_ubicacion` | Relación persona-dirección (lectura + escritura) |
| `REC_DATOS.UBICACION_ESTANDARIZADA` | `rec_mock.ubicacion_estandarizada` | Dirección estandarizada (lectura) |
| `REC_DATOS.DIRECCION_FISICA` | `rec_mock.direccion_fisica` | Complemento de dirección (lectura) |
| `REC_DATOS.REPORTE_RELACION_PERSONA_UBICA` | `rec_mock.reporte_relacion_persona_ubica` | Reportes por suscriptor (lectura) |
| `bdm_vista.v_persona_act_economica_ciiu` | `rec_mock.ciiu_persona` | CIIU de la persona (lectura) |
| `REC_VISTA.V_Tipo_Ubicacion_Direccion` | `rec_mock.tipo_ubicacion_dir` | Catálogo RES/LAB/CRR (lectura) |
| `REC_DATOS.UNIFICACION_DIRECCION` | `rec_mock.unificacion_direccion` | Resultado: pares padre-hijo (escritura) |

### Tablas temporales (stage)

| Teradata | Redshift | Qué hace |
|----------|----------|----------|
| `STAGE.layout1` | `rec_mock.stg_regla1_insumo` | Materializa la vista de insumo con JOINs |
| `STAGE.layout2` | `rec_mock.stg_regla1_scored` | Calcula score y ranking por escenario |
| `STAGE.layout3` | `rec_mock.stg_regla1_pares` | Genera pares padre-hijo |

### Cambios de sintaxis Teradata → Redshift

| Teradata | Redshift | Razón |
|----------|----------|-------|
| `QUALIFY (ROW_NUMBER()...)=1` | Subquery con `WHERE orden = 1` | Redshift no soporta QUALIFY |
| `PRIMARY INDEX (col)` | No aplica | Redshift usa DISTKEY/SORTKEY |
| `WITH DATA` | Implícito en `CREATE TABLE AS` | Sintaxis diferente |
| `LOCKING ROW FOR ACCESS` | No aplica | Redshift usa MVCC |
| `CREATE MULTISET TABLE` | `CREATE TABLE` | Redshift no tiene SET/MULTISET |
| `CURRENT_USER` (largo) | `'admin'` (hardcoded) | VARCHAR(30) insuficiente para nombre SSO |

---

## 3. Datos Mock Usados para Regla 1

Solo 3 personas del dataset disparan Regla 1 (las que tienen **diferente tipo de uso** para la misma puerta):

### P01 — Escenario 1 (CIIU=10, Asalariado)

| Cod_DW_Persona_Ubic | Dirección | Tipo Uso | Entidades | CIIU |
|---------------------|-----------|----------|-----------|------|
| 100001 | CL 22 27 45 | **LAB** | 5 | 10 |
| 100002 | CL 22 27 45 | RES | 3 | 10 |

**Regla**: CIIU=10 → prefiere LAB/CRR → 100001 (LAB, 5 ent) es PADRE

### P02 — Escenario 2 (CIIU=81, Sin actividad)

| Cod_DW_Persona_Ubic | Dirección | Tipo Uso | Entidades | CIIU |
|---------------------|-----------|----------|-----------|------|
| 100003 | KR 15 80 22 | **RES** | 4 | 81 |
| 100004 | KR 15 80 22 | LAB | 2 | 81 |

**Regla**: CIIU=81 → prefiere RES/CRR → 100003 (RES, 4 ent) es PADRE

### P03 — Escenario 3 (CIIU=55, Otro)

| Cod_DW_Persona_Ubic | Dirección | Tipo Uso | Entidades | CIIU |
|---------------------|-----------|----------|-----------|------|
| 100005 | TV 70 114 55 | **CCL** | 7 | 55 |
| 100006 | TV 70 114 55 | RES | 3 | 55 |
| 100007 | TV 70 114 55 | LAB | 1 | 55 |

**Regla**: Otro CIIU → mayor entidades → 100005 (CCL, 7 ent) es PADRE de ambas

---

## 4. Resultado Obtenido en Redshift

### Tabla `unificacion_direccion` (4 registros)

```
HIJO (cod_dw_persona_ubic)    PADRE (cod_dw_direccion_unificada)
─────────────────────────     ──────────────────────────────────
100002 (P01, RES)        →   100001 (P01, LAB)     ← Esc 1 ✅
100004 (P02, LAB)        →   100003 (P02, RES)     ← Esc 2 ✅
100006 (P03, RES)        →   100005 (P03, CCL)     ← Esc 3 ✅
100007 (P03, LAB)        →   100005 (P03, CCL)     ← Esc 3 ✅
```

### Tabla `relacion_persona_ubicacion` (4 marcados)

```
cod_dw_persona_ubic    ind_unificacion
───────────────────    ───────────────
100002                 1  (HIJO)
100004                 1  (HIJO)
100006                 1  (HIJO)
100007                 1  (HIJO)
... resto              NULL (no tocados, disponibles para Regla 2 y 3)
```

---

## 5. Validación contra Resultado Esperado

| Persona | Esperado | Obtenido | ¿Correcto? |
|---------|----------|----------|-----------|
| P01 (CIIU=10) | 100001 (LAB) = PADRE | 100001 (LAB) = PADRE | ✅ |
| P02 (CIIU=81) | 100003 (RES) = PADRE | 100003 (RES) = PADRE | ✅ |
| P03 (CIIU=55) | 100005 (CCL, 7ent) = PADRE de 2 hijos | 100005 (CCL) = PADRE de 100006 y 100007 | ✅ |
| P04-P19 | Sin cambio (son de Regla 2 y 3) | Sin cambio (ind_unificacion = NULL) | ✅ |

**Resultado: 4/4 pares correctos. 0 falsos positivos. Regla 1 migrada exitosamente.**

---

## 6. Bug Encontrado y Corregido

**Bug**: La primera versión del código no filtraba por diferente tipo de uso. Unificaba cualquier par con diferente score, incluyendo personas de Regla 2 (mismo tipo de uso, diferente complemento).

**Causa**: Faltaba la condición `padre.cod_dw_tipo_ubicacion_dir <> hijo.cod_dw_tipo_ubicacion_dir` en el JOIN del Paso 3.

**Corrección**: Se agregó la condición al JOIN. Re-ejecutado y validado.

---

*Ambiente: experian-sandbox-dev-redshift-workgroup | Database: redshiftdb | Schema: rec_mock*
