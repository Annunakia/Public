# Modelo de Datos y Reglas – Proceso de Unificación

> Documento de referencia para presentación. Proyecto Reconocer – Migración Teradata → AWS.

---

## 1. ¿Qué es la Unificación?

La unificación toma las direcciones físicas ya estandarizadas de una persona y elimina duplicados lógicos. Cuando una persona tiene varias direcciones que son "la misma" (pero difieren en tipo de uso, complemento o pequeñas variaciones), el proceso escoge la mejor y marca las demás como "hijas".

El resultado es un ranking limpio de direcciones por persona, listo para el proceso de ordenamiento.

---

## 2. Las 3 Reglas de Unificación

Las reglas se ejecutan en **cascada**: Regla 1 → Regla 2 → Regla 3. El resultado de una alimenta la siguiente. Una dirección marcada como "hija" no vuelve a entrar.

### Regla 1: Unificación por Tipo de Uso + CIIU

**¿Qué resuelve?** Una persona tiene la misma dirección reportada como residencial (RES), laboral (LAB) y correspondencia (CRR). ¿Cuál queda?

**Criterio de agrupación**: Misma puerta + misma ciudad.

| Escenario | Condición | Cómo escoge al "Padre" |
|-----------|-----------|----------------------|
| 1 | CIIU = 10 (Asalariado) | Prefiere LAB o CRR. Si ambas, la de mayor número de entidades que reportan |
| 2 | CIIU = 81, 82, 90 (Sin actividad) | Prefiere RES o CRR. Si ambas, la de mayor número de entidades |
| 3 | Cualquier otro CIIU | No importa el tipo de uso. Escoge la de mayor número de entidades. Desempate: fecha más reciente |

**Ejemplo**: Juan tiene CL 22 27 45 reportada como RES por 3 bancos y como LAB por 1 banco. CIIU=10 (asalariado) → Escenario 1 → Queda la LAB/CRR. Si ambas son LAB, queda la de 3 entidades.

---

### Regla 2: Unificación por Complementos

**¿Qué resuelve?** Una persona tiene la misma puerta pero diferentes complementos (ej: "AP 401" vs "BR ALAMEDA AP 401"). ¿Cuál queda? ¿Se puede armar una mejor?

**Criterio de agrupación**: Misma Address_Geo + misma ciudad + mismo barrio + mismo tipo de dirección.

| Escenario | Condición | Resultado |
|-----------|-----------|-----------|
| 1 | Un complemento vacío, otro no | Queda el que tiene complemento |
| 2 | Un complemento incluido en el otro | Queda el más completo |
| 3 | Misma nomenclatura, diferente valor (ej: AP 105 vs AP 404) | Mayor número de entidades. Si es NIT: **combina ambos** creando nueva dirección |
| 4 | Nomenclaturas diferentes, mismo nivel | Consulta Diccionario de Complementos → mayor frecuencia |
| 5 | Nomenclaturas diferentes, diferente nivel | **Genera nueva dirección** combinando ambas nomenclaturas |
| 6 | Ninguna nomenclatura contenida en otra | Combina si niveles diferentes. Diccionario si mismo nivel |

**Particularidad**: Esta es la única regla que **crea nuevas direcciones físicas** en la base de datos (Padre Tipo 2). Las reglas 1 y 3 solo escogen entre las existentes.

**Ejemplo**: María tiene CL 80 15 20 con complemento "AP 401" y CL 80 15 20 con complemento "BR ALAMEDA". Son niveles diferentes → Escenario 5 → Se genera nueva dirección: CL 80 15 20 BR ALAMEDA AP 401.

---

### Regla 3: Unificación por Geolocalización

**¿Qué resuelve?** Una persona tiene direcciones que difieren en la vía generadora o el número de puerta (ej: CL 8 **6** 52 vs CL 8 **7** 52). ¿Son la misma dirección con error de digitación?

**Criterio de agrupación**: Mismo departamento + misma ciudad + misma zona. Solo direcciones tipo Vía (excluye Manzana y Rural).

**Precondición**: Requiere que se haya ejecutado el proceso de geocodificación (ESRI) para tener latitud/longitud.

#### Escenario 1: Diferencia en vía generadora

| Subcaso | Condición | Resultado |
|---------|-----------|-----------|
| 1 | Solo una tiene lat/long | Queda la que tiene geolocalización |
| 2 | Ninguna tiene lat/long | Mayor fecha de actualización. Desempate: mayor entidades |
| 3 | Ambas tienen lat/long | Consulta Diccionario de Vía → mayor frecuencia de vía generadora |

#### Escenario 2: Diferencia en número de puerta

| Subcaso | Condición | Resultado |
|---------|-----------|-----------|
| 1 | Solo una tiene lat/long | Queda la que tiene geolocalización |
| 2 | Ninguna tiene lat/long | Mayor fecha de actualización. Desempate: mayor entidades |
| 3 | Ambas tienen lat/long | Primero valida que la diferencia sea **±2 posiciones**. Si es mayor, no unifica. Si cumple → Diccionario de Vía → mayor frecuencia |

**Ejemplo**: Pedro tiene KR 7 **181** 75 y KR 7 **182** 75. Diferencia en vía generadora = 1 posición (< ±2). Ambas tienen lat/long → Diccionario dice que 181 tiene 15 reportes y 182 tiene 3 → Queda KR 7 181 75.

---

---

## Descomposición Completa: Reglas → Escenarios → Casos/Subcasos

```
PROCESO DE UNIFICACIÓN
│
├── REGLA 1: Por Tipo de Uso + CIIU (misma puerta, diferente tipo de uso)
│   ├── Escenario 1: CIIU = 10 (Asalariado)
│   │   ├── Si solo una tiene LAB o CRR → queda esa
│   │   └── Si ambas tienen LAB o CRR → mayor número de entidades
│   ├── Escenario 2: CIIU = 81, 82, 90 (Sin actividad)
│   │   ├── Si solo una tiene RES o CRR → queda esa
│   │   └── Si ambas tienen RES o CRR → mayor número de entidades
│   └── Escenario 3: Cualquier otro CIIU
│       └── Mayor número de entidades. Desempate: fecha más reciente
│
├── REGLA 2: Por Complementos (misma puerta, diferente complemento)
│   ├── Escenario 1: Un complemento vacío
│   │   └── Queda el que tiene complemento
│   ├── Escenario 2: Un complemento incluido en otro
│   │   └── Queda el más completo
│   ├── Escenario 3: Misma nomenclatura, diferente valor
│   │   ├── Caso Sin NIT → mayor entidades. Desempate: fecha
│   │   └── Caso NIT → COMBINA ambos complementos (nueva dirección)
│   ├── Escenario 4: Nomenclaturas diferentes, mismo nivel
│   │   └── Diccionario de frecuencias → mayor frecuencia. Desempate: fecha
│   ├── Escenario 5: Nomenclaturas diferentes, diferente nivel
│   │   ├── Subcaso 1: Valores diferentes → GENERA nueva dirección combinando
│   │   └── Subcaso 2: Valores iguales → diccionario de frecuencias
│   └── Escenario 6: Ninguna nomenclatura contenida en otra
│       ├── Subcaso 1: Niveles diferentes → GENERA nueva dirección combinando
│       ├── Subcaso 2: Variante de combinación → GENERA nueva dirección
│       └── Subcaso 3: Mismo nivel → diccionario de frecuencias
│
└── REGLA 3: Por Geolocalización (diferencia en vía generadora o puerta)
    ├── Escenario 1: Diferencia en vía generadora
    │   ├── Subcaso 1: Solo uno tiene lat/long → queda el geolocalizado
    │   ├── Subcaso 2: Ninguno tiene lat/long → mayor fecha. Desempate: entidades
    │   └── Subcaso 3: Ambos tienen lat/long → Diccionario de Vía → mayor frecuencia
    └── Escenario 2: Diferencia en número de puerta
        ├── Subcaso 1: Solo uno tiene lat/long → queda el geolocalizado
        ├── Subcaso 2: Ninguno tiene lat/long → mayor fecha. Desempate: entidades
        └── Subcaso 3: Ambos tienen lat/long → valida ±2 posiciones → Diccionario de Vía
```

**Leyenda**: "GENERA nueva dirección" = invoca el MOTOR_TMP que crea una dirección Padre Tipo 2 combinando nomenclaturas de las dos hijas.

---

## 3. Reglas Generales (aplican a las 3 reglas)

| Regla | Descripción |
|-------|-------------|
| **Pares** | La unificación se hace de a 2 direcciones. Si hay 3+, se unifican las primeras 2 y el resultado se unifica con la tercera (recursivo) |
| **Padre-Hijo** | El Padre es la dirección ganadora. El Hijo queda marcado con `Ind_Unificacion=1` y no vuelve a procesarse |
| **Cascada** | Regla 1 → Regla 2 → Regla 3. Un Padre de Regla 1 puede ser Hijo en Regla 2 |
| **Sin bloqueos** | Solo se procesan direcciones sin padre previo y sin bloqueos |

---

## 4. Tablas del Modelo de Datos

### 4.1 Tablas Principales (esquema REC_DATOS)

#### RELACION_PERSONA_UBICACION
**Qué es**: La tabla central del modelo. Relaciona una persona con una ubicación (dirección, teléfono, email). Cada fila es "la persona X tiene la ubicación Y".

| Columna | Tipo | Descripción |
|---------|------|-------------|
| Cod_DW_Persona_Ubic | BIGINT | PK — Identificador único de la relación persona-ubicación |
| Cod_Pin_Persona | INTEGER | Identificador interno de la persona (PIN) |
| Id_Buro_Persona | INTEGER | Identificador de la persona en el buró |
| Cod_DW_Ubic | BIGINT | FK → Ubicación estandarizada |
| Cod_DW_Direccion_Fisica | BIGINT | FK → Dirección física (complemento) |
| Cod_DW_Tipo_Ubicacion_Dir | INTEGER | Tipo de uso (ver tabla abajo) |

**Tipos de Uso de Dirección:**

| Código | Nombre | Significado | Ejemplo |
|--------|--------|------------|---------|
| RES | Residencial | Donde vive la persona | Dirección de la casa |
| LAB | Laboral | Donde trabaja la persona | Dirección de la oficina/empresa |
| CRR | Correspondencia | Donde recibe correo o notificaciones | Puede coincidir con RES o LAB |
| JUD | Judicial | Dirección para notificaciones judiciales | Usada en procesos legales |
| CCL | Comercial | Dirección comercial del negocio | Para personas jurídicas o independientes |

Una misma dirección física puede estar reportada con diferentes tipos de uso por diferentes entidades. La Regla 1 de unificación resuelve cuál tipo de uso prevalece según la actividad económica (CIIU) de la persona.
| Cod_DW_Telefono | INTEGER | FK → Teléfono (si aplica) |
| Cod_DW_Direccion_Electronica | INTEGER | FK → Email (si aplica) |
| Ind_Unificacion | INTEGER | **Flag de unificación**: NULL=no procesada, 1=ya unificada (hija) |
| Orden_Prioridad | INTEGER | Resultado del ordenamiento (ranking) |
| Orden_Prioridad_Anterior | INTEGER | Orden del ciclo anterior |
| Fecha_Relacion_Persona_Ubicaci | DATE | Fecha de la relación |
| Fecha_Modificacion | DATE | Última modificación |
| Fecha_Ult_Ordenamiento | DATE | Último ordenamiento ejecutado |
| Lote | INTEGER | Lote de carga |
| Lote_Actualizacion | INTEGER | Lote de última actualización |
| Severidad | BYTEINT | Nivel de severidad del registro |
| Usuario_BD | VARCHAR | Usuario que modificó |

**Rol en unificación**: Se lee como insumo (direcciones candidatas). Se actualiza marcando `Ind_Unificacion=1` en las hijas. En Regla 2, se insertan nuevas filas para las direcciones generadas.

---

#### UNIFICACION_DIRECCION
**Qué es**: Registra la relación Padre-Hijo resultado de la unificación. Cada fila dice "la dirección X fue unificada por la dirección Y".

| Columna | Tipo | Descripción |
|---------|------|-------------|
| Cod_DW_Persona_Ubic | BIGINT | PK — La dirección **hija** (la que se unificó) |
| Cod_DW_Direccion_Unificada | BIGINT | La dirección **padre** (la ganadora) |
| Unifica_Atributos | INTEGER | Atributos de la unificación (tipo de regla aplicada) |
| Fecha_Unificacion | DATE | Cuándo se unificó |
| Lote | INTEGER | Lote del proceso |
| Lote_Actualizacion | INTEGER | Lote de actualización |
| Severidad | BYTEINT | Severidad del registro |
| Usuario_BD | VARCHAR | Usuario que ejecutó |
| Fecha_Modificacion | DATE | Última modificación |

**Rol en unificación**: Se escribe en las 3 reglas. Es la tabla de trazabilidad — permite saber quién unificó a quién.

---

#### REPORTE_UNIFICACION_DIRECCION
**Qué es**: Detalle histórico de cada unificación. Similar a UNIFICACION_DIRECCION pero con granularidad de fecha de inicio del dato.

| Columna | Tipo | Descripción |
|---------|------|-------------|
| Cod_DW_Persona_Ubic | BIGINT | La dirección hija |
| Cod_DW_Direccion_Unificada | BIGINT | La dirección padre |
| Unifica_Atributos | INTEGER | Tipo de regla |
| Fecha_Unificacion | DATE | Cuándo se unificó |
| Fecha_Inicio_Dato | DATE | Desde cuándo aplica este dato |
| Lote | INTEGER | Lote del proceso |
| Lote_Actualizacion | INTEGER | Lote de actualización |
| Severidad | BYTEINT | Severidad |
| Usuario_BD | VARCHAR | Usuario |
| Fecha_Modificacion | DATE | Última modificación |

**Rol en unificación**: Se escribe en las 3 reglas. Permite auditoría temporal de las unificaciones.

---

#### DIRECCION_FISICA
**Qué es**: Contiene el detalle de cada dirección física: complemento, tipo de vía, vía principal, vía generadora, número de puerta.

| Columna | Tipo | Descripción |
|---------|------|-------------|
| Cod_DW_Direccion_Fisica | BIGINT | PK — Identificador único de la dirección física |
| Complemento | VARCHAR(100) | Complemento de la dirección (ej: BR ALAMEDA AP 401) |
| Tipo_Via_Principal | VARCHAR(20) | Tipo de vía (CL, KR, TV, DG, etc.) |
| Via_Principal | VARCHAR(100) | Nombre/número de la vía principal |
| Via_Generadora | INTEGER | Número de la vía generadora |
| Numero_Puerta | INTEGER | Número de puerta |
| Cod_DW_Ubic | BIGINT | FK → Ubicación estandarizada |
| Generada_Enriquecida | INTEGER | **Flag**: 1 = dirección generada por unificación Regla 2 |
| Fecha_Inactivacion | DATE | Fecha de inactivación (si aplica) |
| Lote | INTEGER | Lote de carga |
| Lote_Actualizacion | INTEGER | Lote de actualización |
| Severidad | INTEGER | Severidad |
| Usuario_BD | VARCHAR | Usuario |
| Fecha_Modificacion | DATE | Última modificación |

**Rol en unificación**: Se lee para obtener complementos. **Solo Regla 2 escribe aquí** — cuando genera nuevas direcciones combinando complementos (Padre Tipo 2), las inserta con `Generada_Enriquecida=1`.

---

#### UBICACION_ESTANDARIZADA
**Qué es**: La dirección ya estandarizada (resultado del proceso de estandarización). Contiene el texto normalizado y el código de ciudad.

| Columna | Tipo | Descripción |
|---------|------|-------------|
| Cod_DW_Ubic | BIGINT | PK — Identificador de la ubicación |
| Texto_Ubicacion | VARCHAR | Dirección estandarizada (ej: CL 22 27 45) |
| Cod_DW_Ciudad | INTEGER | Código DANE de la ciudad |
| Cod_DW_Tipo_Ubicacion | INTEGER | Tipo: Geográfica, Teléfono, Email, Celular |

**Rol en unificación**: Se lee como fuente. El `Texto_Ubicacion` es la "puerta" que se compara entre direcciones.

---

#### NOMENCLATURA
**Qué es**: Catálogo de nomenclaturas con sus niveles jerárquicos. Define el peso/prioridad de cada nomenclatura para la normalización y unificación.

| Columna | Tipo | Descripción |
|---------|------|-------------|
| Nomenclatura | VARCHAR | Código de la nomenclatura (ej: BR, AP, TO, PI, MZ) |
| Nivel_Complemento | INTEGER | Nivel jerárquico (1=más alto: Barrio, Urbanización. 7=más bajo: Apartamento) |

**Rol en unificación**: Regla 2 usa los niveles para decidir si dos nomenclaturas están al mismo nivel o diferente nivel (Escenarios 4, 5, 6).

**89 nomenclaturas en 7 niveles**:
- Nivel 1: Barrio, Ciudadela, Conjunto, Urbanización
- Nivel 2: Edificio, Multifamiliar, Portería, Parque, Zona
- Nivel 3-4: Manzana, Etapa, Bloque, Torre
- Nivel 5-7: Piso, Apartamento, Casa, Local, Oficina

---

#### BLOQUEO
**Qué es**: Direcciones bloqueadas que no deben procesarse.

| Columna | Tipo | Descripción |
|---------|------|-------------|
| Cod_DW_Bloqueo | BIGINT | PK |
| Cod_DW_Persona_Ubic | BIGINT | FK → Relación persona-ubicación bloqueada |
| Fecha_Bloqueo | DATE | Cuándo se bloqueó |
| Tipo_Bloqueo | INTEGER | Tipo de bloqueo (8 = por novedad) |
| Comentarios | VARCHAR | Razón del bloqueo |

**Rol en unificación**: Se lee para excluir direcciones bloqueadas. Regla 1 también inserta bloqueos por novedad.

---

### 4.2 Vistas de Insumo (esquema REC_STAGE)

Cada regla tiene su propia vista que prepara las direcciones candidatas:

#### V_Insumo_Unificacion_Regla1
**Qué hace**: Agrupa direcciones por persona que tienen la misma puerta pero diferente tipo de uso.

| Campo | Fuente | Descripción |
|-------|--------|-------------|
| Cod_DW_Persona_Ubic | RELACION_PERSONA_UBICACION | ID de la relación |
| Id_Buro_Persona | RELACION_PERSONA_UBICACION | Persona |
| Texto_Ubicacion | UBICACION_ESTANDARIZADA | Dirección estandarizada (puerta) |
| Complemento | DIRECCION_FISICA | Complemento de la dirección |
| Cod_DW_Ciudad | UBICACION_ESTANDARIZADA | Ciudad DANE |
| Cod_DW_Tipo_Ubicacion_Dir | RELACION_PERSONA_UBICACION | Tipo de uso (RES/LAB/CRR) |
| Cod_Act_Econo_CIIU_Fte | bdm_vista (CIIU) | Actividad económica de la persona |
| Numero_Entidades_Reportan | COUNT(DISTINCT suscriptores) | Cuántas entidades reportan esta dirección |

**Filtros**: Solo tipo ubicación = 'Geografica'. Solo `Ind_Unificacion IS NULL` (no procesadas). Sin bloqueos.

#### V_Insumo_Unificacion_Regla2
**Qué hace**: Agrupa direcciones que tienen la misma Address_Geo, ciudad, barrio y tipo, pero diferente complemento.

Campos adicionales vs Regla 1: `Cod_DW_Direccion_Fisica`, `Cod_DW_Doc_Ident`, `Cod_Tipo_Ident_Fte`, `Cod_DW_Municipio`, `Fecha_Relacion_Persona_Ubicaci`.

#### V_Insumo_Unificacion_Regla3
**Qué hace**: Agrupa direcciones que tienen el mismo departamento, ciudad y zona, pero difieren en vía generadora o número de puerta.

Campos adicionales: Latitud, Longitud, Fecha Reporte, Número de entidades.

---

### 4.3 Diccionarios Temporales (se crean y borran durante el proceso)

#### DICCIONARIO_COMPLEMENTOS (Regla 2)
**Qué es**: Frecuencia de cada nomenclatura reportada para una dirección GEO.

| Campo | Descripción |
|-------|-------------|
| Cod_DW_Ubic | Dirección GEO |
| Nomenclatura | Texto completo (ej: "TO 3") |
| Nomen | Nomenclatura abreviada (ej: "TO") |
| Valor | Valor numérico de la nomenclatura |
| Frecuencia | Número de veces reportada |

**Ejemplo**: Para CL 22 27 45, el diccionario dice: TO 3 → 15 veces, AP 404 → 5 veces, BR CASTILLA → 9 veces.

**Uso**: Escenarios 4 y 6 de Regla 2 consultan este diccionario para desempatar por frecuencia.

#### DICCIONARIO_VIA (Regla 3)
**Qué es**: Frecuencia de vías generadoras y números de puerta para una dirección.

| Campo | Descripción |
|-------|-------------|
| Llave | Texto de la dirección sin el componente variable |
| Componente | Vía generadora o número de puerta |
| Valor | El número específico |
| Frecuencia | Número de veces reportado |

**Ejemplo**: Para CL 34 _ 52 (llave), vía generadora 78 → 15 veces, vía generadora 79 → 3 veces.

**Uso**: Subcaso 3 de ambos escenarios de Regla 3 consulta este diccionario.

---

### 4.4 Tablas Externas (fuera de REC_DATOS)

| Tabla | Esquema | Descripción | Rol |
|-------|---------|-------------|-----|
| `v_persona_act_economica_ciiu` | bdm_vista | Actividad económica de la persona | Regla 1: obtener CIIU |
| `V_ACTIVIDAD_ECONOMICA_CIIU` | bdm_vista | Catálogo de códigos CIIU | Regla 1: decodificar CIIU |
| `MAT_REPORTE_REL_PERS_UBI` | REC_DATOS | Vista materializada de reportes históricos | Fuente para construir diccionarios |
| `V_TIPO_UBICACION` | REC_VISTA | Catálogo de tipos de ubicación | Filtro: solo 'Geografica' |
| `V_Tipo_Ubicacion_Direccion` | REC_VISTA | Catálogo de tipos de uso | Decodificar RES/LAB/CRR |

---

## 5. Flujo de Datos entre Tablas

```
                    LECTURA                              ESCRITURA
                    ───────                              ─────────

UBICACION_ESTANDARIZADA ──┐
DIRECCION_FISICA ─────────┤
RELACION_PERSONA_UBIC ────┤     ┌─── UNIFICACION_DIRECCION (padre-hijo)
CIIU (bdm_vista) ─────────┼──→  │
NOMENCLATURA ─────────────┤     ├─── REPORTE_UNIFICACION_DIRECCION (auditoría)
BLOQUEO ──────────────────┤     │
MAT_REPORTE (histórico) ──┘     ├─── RELACION_PERSONA_UBIC (Ind_Unificacion=1)
                                │
                                ├─── DIRECCION_FISICA (solo Regla 2: nuevas)
                                │
                                └─── BLOQUEO (solo Regla 1: por novedad)
```

---

---

## 6. Modelo de Datos en Redshift — Decisiones de Migración

La migración a Redshift se construye usando los steering files del entorno XPM/Redshift de Experian (`ws-unificacion/.kiro/steering/`). Estas son las decisiones aplicadas:

### Schemas

| Schema | Uso | Fuente |
|--------|-----|--------|
| `bdm_datos` | Tablas permanentes (ubicacion_estandarizada, relacion_persona_ubicacion, unificacion_direccion, etc.) | `ambiente-redshift-cliente.md` |
| `bdm_tempo` | Tablas de staging durante el procesamiento (stg_regla1_insumo, stg_regla1_scored, etc.). Se limpian al final de cada ejecución | `ambiente-redshift-cliente.md` |

### Encoding por tipo de dato

| Tipo | Encoding | Razón |
|------|----------|-------|
| BIGINT, INTEGER, DATE | AZ64 | Compresión nativa optimizada para enteros |
| VARCHAR corto (<256) | ZSTD | Mejor ratio para strings cortos |
| VARCHAR baja cardinalidad (tipo_ubicacion, CIIU) | BYTEDICT | Pocos valores distintos |

Fuente: `modelo-datos-xpm.md`, sección "Encoding y Distribución Recomendados"

### Distribución (DISTKEY / DISTSTYLE)

| Tabla | DISTKEY | Razón |
|-------|---------|-------|
| `relacion_persona_ubicacion` | `id_buro_persona` | JOINs frecuentes por persona con ciiu_persona y tablas de staging |
| `ubicacion_estandarizada` | `cod_dw_ubic` | JOINs con direccion_fisica y relacion_persona_ubicacion |
| `reporte_relacion_persona_ubica` | `cod_dw_persona_ubic` | JOIN directo con relacion_persona_ubicacion |
| `tipo_ubicacion_dir`, `nomenclatura` | DISTSTYLE ALL | Tablas lookup pequeñas — se replican en todos los nodos para evitar shuffle |
| Tablas de staging (`bdm_tempo`) | `id_buro_persona` | Co-localizar con tablas permanentes para JOINs eficientes |

Fuente: `modelo-datos-xpm.md`, sección "DISTKEY y SORTKEY por nivel"

### ANALYZE post-carga

Se ejecuta `ANALYZE` después de cada `CREATE TABLE AS` en staging y después de cada `INSERT`/`UPDATE` en tablas permanentes. Sin esto, el optimizador de Redshift elige planes de ejecución subóptimos porque no conoce la distribución real de los datos.

Fuente: `operaciones-nocturnas-redshift.md`

### Compatibilidad SQL

| Restricción Redshift | Cómo se maneja |
|---------------------|----------------|
| Sin CTEs recursivos | JOINs iterativos + tablas de staging |
| Sin ON CONFLICT (UPSERT) | DELETE + INSERT o MERGE |
| Sin LATERAL JOIN | Subqueries correlacionados |
| Puerto 5440 (no 5439) | Configuración de conexión |

Fuente: `sql-redshift-xpm.md`, `desarrollo-ia-redshift.md`

### Empaquetado para deploy

Cada regla migrada se empaqueta siguiendo el estándar del cliente:

```
src/redshift/
├── deploy_order.par          ← Orden de ejecución [SQL] y [REV-SQL]
├── sql/
│   ├── 01_schemas_roles.sql  ← Schemas + tablas permanentes
│   └── 02_regla1_*.sql       ← Lógica de negocio
├── rev-sql/
│   ├── 02_rollback_*.sql     ← Revierte lógica (orden inverso)
│   └── 01_rollback_*.sql     ← Elimina tablas
└── Documentacion/
    └── PAQUETE_*.yml         ← Metadata + validaciones post-deploy
```

Fuente: `estandar-paquete-deploy-sql.md`

---

*Documento actualizado: 2026-04-21 | Fuentes: documento funcional V1.0, análisis de scripts, DDLs de Unificacion.sql, steering files XPM/Redshift*
