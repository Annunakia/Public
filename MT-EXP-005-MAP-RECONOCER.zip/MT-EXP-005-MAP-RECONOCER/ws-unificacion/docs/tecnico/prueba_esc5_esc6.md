# Prueba: Escenarios 5 y 6 — P09, P10, P11, P12

> Fecha: 2026-04-22 | Ambiente: `experian-sandbox-dev-redshift-workgroup` | Cuenta: `193272798722`

---

## Resultados

| Persona | Escenario | Complementos | Resultado | N_ID | Estado |
|---------|-----------|-------------|-----------|------|--------|
| P09 (1009) | Esc 5 sub1 | TO 3 + AP 504 | Nueva: "TO 3 AP 504" | M5 | **PASS** |
| P10 (1010) | Esc 5 sub2 | TO 3 vs AP 3 | Padre: AP 3 (mayor score) | D5 | **PASS** |
| P11 (1011) | Esc 5 sub1* | ED PROMOTOR + OF 2007 | Nueva: "ED PROMOTOR OF 2007" | M5 | **PASS** |
| P12 (1012) | Esc 6 sub3 | BR CASTILLA vs BR VENECIA | Padre: BR CASTILLA (freq=20) | D6 | **PASS** |

*P11 fue capturado por escenario 5 (nomenclaturas en diferente nivel: ED=2, OF=6), no por escenario 6. Esto es correcto — el escenario 5 procesa primero en cascada.

## Bug encontrado y corregido

**Problema**: El subcaso 2 del escenario 5 filtraba desde `stg_regla2_e05_c` que ya excluía pares con `complemento2` iguales (por el filtro NOT LIKE). P10 nunca llegaba al subcaso 2.

**Fix**: Cambiar el filtro del subcaso 2 para que filtre directamente desde `stg_regla2_e05_a` con condición `TRIM(A.complemento2) = TRIM(B.complemento2) AND A.nivel_pri <> B.nivel_pri`.

## Nota sobre P10

El README de datos mock dice "padre = TO 3" pero el resultado real es "padre = AP 3". Esto es correcto: el score es `(frecuencia + 10M) + fecha_como_entero`. AP 3 tiene fecha más reciente (2025-05-01 vs 2025-04-01) que compensa la menor frecuencia (4 vs 12). El score de AP 3 (30250505) > TO 3 (30250413). El README necesita ajustarse.

## Pares generados

| Hijo | Padre | Tipo |
|------|-------|------|
| 100018 (TO 3) | 100026 (TO 3 AP 504) | Motor |
| 100019 (AP 504) | 100026 (TO 3 AP 504) | Motor |
| 100020 (TO 3) | 100021 (AP 3) | Diccionario |
| 100022 (ED PROMOTOR) | 100027 (ED PROMOTOR OF 2007) | Motor |
| 100023 (OF 2007) | 100027 (ED PROMOTOR OF 2007) | Motor |
| 100025 (BR VENECIA) | 100024 (BR CASTILLA) | Diccionario |
