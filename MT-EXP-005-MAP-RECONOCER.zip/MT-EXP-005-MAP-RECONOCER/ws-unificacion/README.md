# ws-unificacion — Migración Proceso de Unificación

Unificación de Direcciones Físicas: toma direcciones estandarizadas y las unifica (borrado lógico) cuando son iguales pero difieren en tipo de uso o complemento. 3 reglas en cascada, concepto Padre-Hijo.

## Estado

| Regla | Descripción | Estado |
|-------|-------------|--------|
| Regla 1 (P0019) | Misma puerta, diferente tipo de uso → CIIU | ✅ Migrada a Redshift |
| Regla 2 (P0020) | Misma puerta, diferente complemento | ⏳ Pendiente |
| Regla 3 (P0021) | Diferencia en vía generadora → lat/long | ⏳ Pendiente |

## Estructura

```
ws-unificacion/
├── .kiro/steering/
│   ├── context.md              ← Contexto para Kiro
│   └── map.md                  ← Mapa de navegación (dónde está cada cosa)
├── src/
│   ├── teradata/               ← Código fuente original (P0019, P0020, P0021)
│   └── redshift/               ← Código migrado (00_setup, 01_regla1)
├── docs/
│   ├── funcional/              ← Doc funcional unificación (MD + docx)
│   ├── tecnico/                ← Modelo datos, mapeo escenarios, análisis scripts
│   ├── preventa/               ← Entregables de preventa
│   └── comunicaciones/         ← Transcripciones relevantes
└── data/
    ├── mock/                   ← Datos de prueba (19 personas, 12 escenarios)
    └── parametros/             ← Vistas, catálogos, tipos de vía
```

## Orden de ejecución Teradata

P0019 (Regla 1) → P0020 (Regla 2) → P0021 (Regla 3)

Cada programa: `_111` setup → `_120` carga → `_130` transformación → `_140` resultado
