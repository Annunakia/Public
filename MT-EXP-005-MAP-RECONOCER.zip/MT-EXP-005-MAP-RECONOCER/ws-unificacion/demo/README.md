# Demo Regla 1 — Unificación de Direcciones

## Objetivo
Demostrar que Regla 1 de Unificación funciona en Redshift, cumpliendo los 8 criterios de aceptación consolidados (Kidar + Experian).

## Criterios que se validan

| ID | Criterio |
|:--:|----------|
| R1-01 | CIIU=10 → padre es LAB o CRR con mayor entidades |
| R1-02 | CIIU=81,82,90 → padre es RES o CRR con mayor entidades |
| R1-03 | Otro CIIU → mayor entidades sin importar tipo |
| R1-04 | Hijo queda con `ind_unificacion = 1` |
| R1-05 | Se inserta par en `unificacion_direccion` |
| R1-06 | Bloqueadas e hijas previas no se procesan |
| R1-07 | Baseline CIIU obligatorio (10, 81/82/90) |
| R1-08 | Empate persistente = no decisión |

## Ejecución

```bash
# 1. Crear tablas y cargar datos
./run_sql_file.sh ws-unificacion/demo/01_demo_setup.sql

# 2. Ejecutar Regla 1 (script migrado real)
./run_sql_file.sh ws-unificacion/src/redshift/sql/02_regla1_unificacion.sql

# 3. Validar criterios de aceptación
./run_sql_file.sh ws-unificacion/demo/02_demo_validacion.sql

# 4. Limpieza
./run_sql_file.sh ws-unificacion/demo/03_demo_cleanup.sql
```

## Ambiente
- Workgroup: experian-sandbox-dev-redshift-workgroup
- DB: dev
- Profile: sandbox
- Region: us-east-1

## Dataset
- 7 personas con escenarios diseñados para cubrir los 8 criterios
- Incluye datos inspirados en el XPM real (pin 7962867)
