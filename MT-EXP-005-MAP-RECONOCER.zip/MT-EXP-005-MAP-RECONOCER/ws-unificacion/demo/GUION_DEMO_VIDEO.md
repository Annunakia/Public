# Guion Demo — Regla 1 Unificación de Direcciones en Redshift

> **Duración estimada:** 15-20 minutos
> **Objetivo:** Demostrar que Regla 1 de Unificación funciona en Amazon Redshift, cumpliendo los 8 criterios de aceptación acordados con Experian.
> **Ambiente:** Redshift Serverless (experian-sandbox-trunk-ddm-xpm-workgroup)

---

## PARTE 0 — Conexión a Redshift (1 min)

### Lo que vas a decir:

> "Primero nos conectamos al ambiente de Redshift Serverless de Experian en AWS. Usamos SSO para autenticarnos."

### Comandos:

```bash
# 1. Login SSO (abre navegador para autenticar)
aws sso login --profile sandbox

# 2. Verificar identidad
aws sts get-caller-identity --profile sandbox
```

> "Confirmamos que estamos en la cuenta correcta (193272798722)."

```bash
# 3. Prueba de conectividad a Redshift
aws redshift-data execute-statement \
  --profile sandbox \
  --region us-east-1 \
  --workgroup-name experian-sandbox-trunk-ddm-xpm-workgroup \
  --database dev \
  --sql "SELECT 'Conexion exitosa a Redshift' AS status, CURRENT_DATE AS fecha, CURRENT_USER AS usuario"
```

> "Esperamos el Id de ejecución..."

```bash
# 4. Ver resultado (reemplazar <id> por el que devolvió el comando anterior)
aws redshift-data get-statement-result \
  --profile sandbox \
  --region us-east-1 \
  --id <id>
```

> "Conexión confirmada. Estamos conectados a Redshift Serverless, base de datos dev."

### Datos del ambiente:

| Parámetro | Valor |
|-----------|-------|
| Cuenta AWS | 193272798722 |
| Región | us-east-1 |
| Workgroup | experian-sandbox-trunk-ddm-xpm-workgroup |
| Database | dev |
| Perfil AWS CLI | sandbox |
| Autenticación | SSO (IAM Identity Center) |

### Posicionarse en la carpeta de la demo:

```bash
cd /Users/franciscopena/Macondo/Repos/MT-EXP-005-MAP-RECONOCER/ws-unificacion/demo
```

> "Todos los scripts de la demo están acá."

---

## PARTE 1 — Contexto (2 min)

### Lo que vas a decir:

> "Vamos a demostrar cómo funciona la Regla 1 de Unificación de Direcciones ya migrada a Amazon Redshift. Esta regla toma direcciones de una misma persona que comparten la misma puerta pero tienen diferente tipo de uso (Residencial, Laboral, Correspondencia), y decide cuál es la mejor según la actividad económica (CIIU) de la persona."

> "Los datos que vamos a usar simulan lo que llegaría del XPM después del proceso de Relationalize — es decir, el JSON del XPM ya convertido a tablas relacionales en Redshift."

### Diagrama de flujo (mostrarlo en pantalla o dibujar):

```
XPM (JSON) → Relationalize → Tablas en Redshift → REGLA 1 → Resultado (padre-hijo)
                                    ↑
                              Estamos acá
```

---

## PARTE 1.5 — Crear tablas y cargar datos (1 min)

### Lo que vas a decir:

> "Cargamos las tablas que simula el resultado del Relationalize: personas, direcciones, catálogos y reportes de suscriptores. Son 6 personas diseñadas para probar todos los escenarios de Regla 1."

### Comando:

```bash
./run_sql_file.sh 01_demo_setup.sql
```

> "Este script crea los schemas, las tablas con la estructura exacta que usa Unificación, y carga los datos de prueba."

### Verificar que se crearon:

```bash
./run_sql.sh "SELECT table_schema, table_name FROM information_schema.tables WHERE table_schema IN ('bdm_datos','bdm_tempo') ORDER BY table_schema, table_name"
```

---

## PARTE 2 — Estructura de tablas (3 min)

### Lo que vas a decir:

> "Primero veamos qué tablas existen. Estas se dividen en tres grupos: las que vienen del XPM, los catálogos, y las tablas de resultado."

### Comando:

```bash
./run_sql.sh "SELECT table_schema, table_name FROM information_schema.tables WHERE table_schema IN ('bdm_datos','bdm_tempo') ORDER BY table_schema, table_name"
```

### Explicación por grupo:

> "**Del XPM (via Relationalize)** — son las tablas que ya existen cuando Reconocer arranca:"
> - `relacion_persona_ubicacion` — cada dirección reportada por persona + tipo de uso
> - `ubicacion_estandarizada` — la puerta normalizada (ej: CL 45 12 33)
> - `direccion_fisica` — los componentes de la dirección (complemento)
> - `reporte_relacion_persona_ubica` — qué suscriptores reportan cada dirección
> - `ciiu_persona` — actividad económica de la persona
> - `bloqueo` — direcciones excluidas por reclamación

> "**Catálogos (de Collibra):**"
> - `tipo_ubicacion_dir` — traduce código a RES, LAB, CRR

> "**Output de Reconocer (vacía al inicio):**"
> - `unificacion_direccion` — aquí se guardan los pares padre-hijo después de ejecutar

---

## PARTE 3 — Los datos de entrada (5 min)

### Lo que vas a decir:

> "Cargamos 7 personas, cada una diseñada para probar un escenario específico de Regla 1. Veamos los datos."

### 3.1 — Catálogo de tipos de uso

```bash
./run_sql.sh "SELECT * FROM bdm_datos.tipo_ubicacion_dir"
```

> "Este catálogo traduce los códigos numéricos del XPM a las descripciones que usa Unificación: 1=RES, 2=LAB, 3=CRR."

### 3.2 — CIIU por persona

```bash
./run_sql.sh "SELECT * FROM bdm_datos.ciiu_persona ORDER BY id_buro_persona"
```

> "Cada persona tiene un CIIU que determina qué escenario de Regla 1 aplica:"
> - CIIU 10 = Asalariado → prefiere LAB o CRR
> - CIIU 81/82/90 = Sin actividad → prefiere RES o CRR
> - Otro CIIU = Sin preferencia → gana el de mayor entidades

### 3.3 — Direcciones por persona

```bash
./run_sql.sh "SELECT rpu.id_buro_persona AS persona, ubi.texto_ubicacion AS direccion, tud.descripcion_tipo_ubicacion_dir AS tipo_uso, rpu.cod_dw_persona_ubic AS id FROM bdm_datos.relacion_persona_ubicacion rpu JOIN bdm_datos.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir ORDER BY rpu.id_buro_persona, rpu.cod_dw_persona_ubic"
```

> "Cada persona tiene 2 direcciones con la MISMA puerta pero DIFERENTE tipo de uso. Esto es exactamente lo que Regla 1 busca resolver."

### 3.4 — Entidades que reportan cada dirección

```bash
./run_sql.sh "SELECT cod_dw_persona_ubic, COUNT(DISTINCT id_buro_suscriptor) AS entidades FROM bdm_datos.reporte_relacion_persona_ubica GROUP BY 1 ORDER BY 1"
```

> "El número de entidades (suscriptores diferentes que reportan la misma dirección) es el criterio de desempate. A mayor entidades, mayor confiabilidad de que la dirección es real."

### 3.5 — Bloqueo

```bash
./run_sql.sh "SELECT * FROM bdm_datos.bloqueo"
```

> "Tenemos una dirección bloqueada (id 600, persona 1006). Esta NO debe entrar al proceso."

---

## PARTE 4 — Los 8 escenarios de prueba (3 min)

### Lo que vas a decir:

> "Diseñamos 7 personas para cubrir los 8 criterios de aceptación. Así se ven:"

### Diagrama de escenarios (mostrar en pantalla):

```
┌─────────────────────────────────────────────────────────────────────────┐
│  ESCENARIOS DE PRUEBA — REGLA 1                                          │
├──────────┬────────┬────────────────┬──────────────┬─────────────────────┤
│ Persona  │ CIIU   │ Direcciones    │ Entidades    │ Resultado esperado  │
├──────────┼────────┼────────────────┼──────────────┼─────────────────────┤
│ 1001     │ 10     │ RES vs LAB     │ 2 vs 5      │ LAB gana (R1-01)    │
│ 1002     │ 81     │ LAB vs RES     │ 1 vs 4      │ RES gana (R1-02)    │
│ 1003     │ 55     │ RES vs CRR     │ 2 vs 6      │ CRR gana (R1-03)    │
│ 1004     │ 90     │ CRR vs RES     │ 1 vs 5      │ RES gana (R1-02)    │
│ 1005     │ 10     │ LAB vs CRR     │ 3 vs 3      │ NO UNIFICA (R1-08)  │
│ 1007     │ 82     │ RES† vs CRR    │ 2 vs 3      │ NO ENTRA (R1-06)    │
├──────────┴────────┴────────────────┴──────────────┴─────────────────────┤
│ † = ya unificada previamente (ind_unificacion=1)                         │
└─────────────────────────────────────────────────────────────────────────┘
```

> "La persona 1007 valida que el proceso EXCLUYE correctamente direcciones ya unificadas previamente — no las re-procesa."

---

## PARTE 5 — Ejecutar Regla 1 (1 min)

### Lo que vas a decir:

> "Ahora ejecutamos el script de Regla 1. Este es el código REAL migrado de Teradata a Redshift. No es una simulación ni una versión simplificada — es el mismo SQL que corre en producción."

### Comando:

```bash
./run_sql_file.sh ../src/redshift/sql/02_regla1_unificacion.sql
```

> "El script ejecuta 7 pasos:"
> 1. Materializa el insumo (JOIN entre personas, direcciones, catálogos)
> 2. Calcula un score por dirección según CIIU + tipo uso + entidades
> 3. Genera pares padre-hijo (mayor score = padre)
> 4. Persiste los pares en `unificacion_direccion`
> 5. Marca los hijos con `ind_unificacion = 1`
> 6. Actualiza estadísticas
> 7. Limpia tablas temporales

---

## PARTE 6 — Resultados (3 min)

### 6.1 — ¿Quién es padre, quién es hijo?

```bash
./run_sql.sh "SELECT ud.cod_dw_persona_ubic AS hijo, ud.cod_dw_direccion_unificada AS padre, ud.fecha_unificacion FROM bdm_datos.unificacion_direccion ud ORDER BY ud.cod_dw_persona_ubic"
```

> "Estos son los pares generados. Cada fila dice: esta dirección (hijo) fue absorbida por esta otra (padre)."

### 6.2 — Vista completa con explicación

```bash
./run_sql.sh "SELECT rpu.id_buro_persona AS persona, ubi.texto_ubicacion AS direccion, tud.descripcion_tipo_ubicacion_dir AS tipo_uso, COALESCE(ciiu.cod_act_econo_ciiu_fte,'') AS ciiu, CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO (absorbida)' ELSE 'VIGENTE (padre)' END AS estado FROM bdm_datos.relacion_persona_ubicacion rpu JOIN bdm_datos.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir LEFT JOIN bdm_datos.ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona ORDER BY rpu.id_buro_persona, rpu.ind_unificacion NULLS FIRST"
```

> "Aquí vemos el resultado final de forma visual: quién quedó vigente (padre) y quién fue absorbida (hijo). Las personas 1005, 1006 y 1007 no generaron unificación — exactamente lo esperado."

### 6.3 — Direcciones vigentes para Ordenamiento

```bash
./run_sql.sh "SELECT rpu.id_buro_persona AS persona, ubi.texto_ubicacion AS direccion, tud.descripcion_tipo_ubicacion_dir AS tipo_uso FROM bdm_datos.relacion_persona_ubicacion rpu JOIN bdm_datos.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic LEFT JOIN bdm_datos.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir WHERE rpu.ind_unificacion IS NULL ORDER BY rpu.id_buro_persona"
```

> "Estas son las direcciones que pasarían al siguiente proceso (Ordenamiento). Solo las vigentes — las hijas ya no están."

---

## PARTE 7 — Validación de criterios de aceptación (3 min)

### Lo que vas a decir:

> "Ahora validamos formalmente los 8 criterios de aceptación que acordamos con Experian. Cada uno devuelve PASS o FAIL."

### Comando:

```bash
./run_sql_file.sh 02_demo_validacion.sql
```

### Explicación de cada resultado:

> - **R1-01 PASS**: CIIU=10, el padre es LAB — correcto, prefiere dirección laboral para asalariados.
> - **R1-02 PASS**: CIIU=81 y 90, el padre es RES — correcto, prefiere residencial para personas sin actividad.
> - **R1-03 PASS**: CIIU=55 (otro), ganó CRR con 6 entidades vs RES con 2 — no privilegió tipo, solo entidades.
> - **R1-04 PASS**: Hay hijos marcados con `ind_unificacion = 1`.
> - **R1-05 PASS**: Existen pares en `unificacion_direccion`.
> - **R1-06a PASS**: Persona 1006 (bloqueada) no fue procesada.
> - **R1-06b PASS**: Persona 1007 (hija previa) no fue re-procesada.
> - **R1-07 PASS**: El CIIU usa los valores baseline de Teradata (10, 81/82/90).
> - **R1-08 PASS**: Persona 1005 con empate no generó unificación.

---

## PARTE 8 — Resumen ejecutivo (1 min)

### Lo que vas a decir:

> "Resumen:"
> - ✅ 8 de 8 criterios de aceptación cumplidos
> - ✅ Script de Regla 1 migrado ejecuta correctamente en Redshift Serverless
> - ✅ Los datos simulan el flujo XPM → Relationalize → tablas → Unificación
> - ✅ Los catálogos están precargados (tipo_ubicacion_dir desde Collibra)
> - ✅ Existe rollback para revertir si es necesario
> - ⏭️ Siguiente paso: Regla 2 (complementos) y Regla 3 (geolocalización)

---

## PARTE 9 — Limpieza (opcional, después de grabar)

```bash
./run_sql_file.sh 03_demo_cleanup.sql
```

---

## Notas para el video

- Graba la terminal en pantalla completa
- Antes de cada comando, pausa y explica qué va a pasar
- Después de cada resultado, señala los datos relevantes
- Mantén el diagrama de escenarios visible mientras explicas los resultados
- Al final, muestra el resumen de PASS/FAIL como cierre contundente
