-- ============================================================
-- 01_demo_setup.sql
-- Demo Regla 1 Unificación: Setup de tablas y carga de datos
-- Cubre 8 criterios de aceptación (Kidar + Experian)
-- ============================================================

-- Schemas
CREATE SCHEMA IF NOT EXISTS bdm_datos;
CREATE SCHEMA IF NOT EXISTS bdm_tempo;

-- ============================================================
-- TABLAS DE CATÁLOGO
-- ============================================================

DROP TABLE IF EXISTS bdm_datos.tipo_ubicacion_dir;
CREATE TABLE bdm_datos.tipo_ubicacion_dir (
  cod_dw_tipo_ubicacion_dir INTEGER ENCODE AZ64,
  descripcion_tipo_ubicacion_dir VARCHAR(20) ENCODE BYTEDICT
) DISTSTYLE ALL;

INSERT INTO bdm_datos.tipo_ubicacion_dir VALUES
(1, 'RES'),
(2, 'LAB'),
(3, 'CRR'),
(4, 'JUD'),
(5, 'CCL');

-- ============================================================
-- TABLAS PRINCIPALES
-- ============================================================

DROP TABLE IF EXISTS bdm_datos.ubicacion_estandarizada;
CREATE TABLE bdm_datos.ubicacion_estandarizada (
  cod_dw_ubic BIGINT ENCODE AZ64,
  texto_ubicacion VARCHAR(200) ENCODE ZSTD,
  cod_dw_ciudad INTEGER ENCODE AZ64
) DISTSTYLE ALL
SORTKEY(cod_dw_ubic);

DROP TABLE IF EXISTS bdm_datos.direccion_fisica;
CREATE TABLE bdm_datos.direccion_fisica (
  cod_dw_direccion_fisica BIGINT ENCODE AZ64,
  complemento VARCHAR(100) ENCODE ZSTD,
  cod_dw_ubic BIGINT ENCODE AZ64,
  generada_enriquecida INTEGER ENCODE AZ64
) DISTSTYLE ALL
SORTKEY(cod_dw_direccion_fisica);

DROP TABLE IF EXISTS bdm_datos.relacion_persona_ubicacion;
CREATE TABLE bdm_datos.relacion_persona_ubicacion (
  cod_dw_persona_ubic BIGINT ENCODE AZ64,
  id_buro_persona INTEGER ENCODE AZ64,
  cod_pin_persona INTEGER ENCODE AZ64,
  cod_dw_ubic BIGINT ENCODE AZ64,
  cod_dw_direccion_fisica BIGINT ENCODE AZ64,
  cod_dw_tipo_ubicacion_dir INTEGER ENCODE AZ64,
  ind_unificacion INTEGER ENCODE AZ64,
  orden_prioridad INTEGER ENCODE AZ64,
  fecha_relacion_persona_ubicaci DATE ENCODE AZ64,
  lote INTEGER ENCODE AZ64,
  cod_tipo_ident_fte INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, cod_dw_persona_ubic);

DROP TABLE IF EXISTS bdm_datos.ciiu_persona;
CREATE TABLE bdm_datos.ciiu_persona (
  id_buro_persona INTEGER ENCODE AZ64,
  cod_act_econo_ciiu_fte VARCHAR(10) ENCODE BYTEDICT
) DISTSTYLE KEY DISTKEY(id_buro_persona);

DROP TABLE IF EXISTS bdm_datos.reporte_relacion_persona_ubica;
CREATE TABLE bdm_datos.reporte_relacion_persona_ubica (
  cod_dw_persona_ubic BIGINT ENCODE AZ64,
  id_buro_suscriptor INTEGER ENCODE AZ64,
  fecha_reporte DATE ENCODE AZ64,
  lote INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
SORTKEY(cod_dw_persona_ubic);

DROP TABLE IF EXISTS bdm_datos.unificacion_direccion;
CREATE TABLE bdm_datos.unificacion_direccion (
  cod_dw_persona_ubic BIGINT ENCODE AZ64,
  cod_dw_direccion_unificada BIGINT ENCODE AZ64,
  unifica_atributos INTEGER ENCODE AZ64,
  fecha_unificacion DATE ENCODE AZ64,
  lote INTEGER ENCODE AZ64,
  severidad INTEGER ENCODE AZ64,
  usuario_bd VARCHAR(100) ENCODE ZSTD
) DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
SORTKEY(cod_dw_persona_ubic);

-- Tabla de bloqueos (para R1-06)
DROP TABLE IF EXISTS bdm_datos.bloqueo;
CREATE TABLE bdm_datos.bloqueo (
  cod_dw_persona_ubic BIGINT ENCODE AZ64,
  fecha_bloqueo DATE ENCODE AZ64
) DISTSTYLE ALL;

-- ============================================================
-- DATOS: UBICACIONES ESTANDARIZADAS (PUERTAS)
-- ============================================================
-- Inspiradas en XPM real (John pin 7962867)

INSERT INTO bdm_datos.ubicacion_estandarizada VALUES
(5001, 'AK 57 SUR 63 45', 1),       -- Persona 1 (del XPM John) — Bogotá
(5002, 'CL 6 18 72', 2),             -- Persona 2 — Zambrano
(5003, 'CL 13 36 61', 3),            -- Persona 3 — Soacha
(5004, 'KR 7 80 22', 1),             -- Persona 4 — Bogotá
(5005, 'CR 15 88 64', 1),            -- Persona 5 — Bogotá (empate)
(5006, 'TV 30 15 40', 4),            -- Persona 6 — bloqueada
(5007, 'DG 50 10 20', 1);            -- Persona 7 — hija previa

-- Direcciones físicas (complementos)
INSERT INTO bdm_datos.direccion_fisica VALUES
(6001, '', 5001, NULL),
(6002, '', 5002, NULL),
(6003, 'TO 26 AP 402', 5003, NULL),
(6004, '', 5004, NULL),
(6005, '', 5005, NULL),
(6006, '', 5006, NULL),
(6007, '', 5007, NULL);

-- ============================================================
-- DATOS: CIIU POR PERSONA
-- ============================================================

INSERT INTO bdm_datos.ciiu_persona VALUES
(1001, '10'),   -- Asalariado → R1-01
(1002, '81'),   -- Sin actividad → R1-02
(1003, '55'),   -- Otro CIIU → R1-03
(1004, '90'),   -- Sin actividad → R1-02 (segunda validación)
(1005, '10'),   -- Asalariado → R1-08 (empate)
(1007, '82');   -- Sin actividad → R1-06 (hija previa)

-- ============================================================
-- DATOS: RELACION_PERSONA_UBICACION
-- ============================================================
-- Cada persona tiene 2 direcciones con misma puerta pero ≠ tipo uso

-- Persona 1001 (CIIU=10): RES vs LAB → R1-01: LAB debe ganar
INSERT INTO bdm_datos.relacion_persona_ubicacion VALUES
(100, 1001, 9001, 5001, 6001, 1, NULL, NULL, '2025-03-01', 1, 1),  -- RES
(101, 1001, 9001, 5001, 6001, 2, NULL, NULL, '2025-06-01', 1, 1);  -- LAB

-- Persona 1002 (CIIU=81): LAB vs RES → R1-02: RES debe ganar
INSERT INTO bdm_datos.relacion_persona_ubicacion VALUES
(200, 1002, 9002, 5002, 6002, 2, NULL, NULL, '2025-04-01', 1, 1),  -- LAB
(201, 1002, 9002, 5002, 6002, 1, NULL, NULL, '2025-05-01', 1, 1);  -- RES

-- Persona 1003 (CIIU=55): RES vs CRR → R1-03: CRR gana por entidades
INSERT INTO bdm_datos.relacion_persona_ubicacion VALUES
(300, 1003, 9003, 5003, 6003, 1, NULL, NULL, '2025-02-01', 1, 1),  -- RES
(301, 1003, 9003, 5003, 6003, 3, NULL, NULL, '2025-07-01', 1, 1);  -- CRR

-- Persona 1004 (CIIU=90): CRR vs RES → R1-02: RES debe ganar
INSERT INTO bdm_datos.relacion_persona_ubicacion VALUES
(400, 1004, 9004, 5004, 6004, 3, NULL, NULL, '2025-01-01', 1, 1),  -- CRR
(401, 1004, 9004, 5004, 6004, 1, NULL, NULL, '2025-06-01', 1, 1);  -- RES

-- Persona 1005 (CIIU=10): LAB vs CRR, EMPATE → R1-08: no decisión
INSERT INTO bdm_datos.relacion_persona_ubicacion VALUES
(500, 1005, 9005, 5005, 6005, 2, NULL, NULL, '2025-05-01', 1, 1),  -- LAB
(501, 1005, 9005, 5005, 6005, 3, NULL, NULL, '2025-05-01', 1, 1);  -- CRR

-- Persona 1006 (CIIU=10): RES vs LAB — pero RES está BLOQUEADA → R1-06
-- NOTA: Escenario de bloqueo se mueve a demo de Regla 2
-- INSERT INTO bdm_datos.relacion_persona_ubicacion VALUES
-- (600, 1006, 9006, 5006, 6006, 1, NULL, NULL, '2025-04-01', 1, 1),  -- RES (bloqueada)
-- (601, 1006, 9006, 5006, 6006, 2, NULL, NULL, '2025-06-01', 1, 1);  -- LAB

-- Persona 1007 (CIIU=82): RES (ya unificada) vs CRR → R1-06: hija no entra
INSERT INTO bdm_datos.relacion_persona_ubicacion VALUES
(700, 1007, 9007, 5007, 6007, 1, 1, NULL, '2025-03-01', 1, 1),    -- RES ← ya ind_unificacion=1
(701, 1007, 9007, 5007, 6007, 3, NULL, NULL, '2025-05-01', 1, 1);  -- CRR

-- ============================================================
-- DATOS: REPORTES (entidades que reportan cada dirección)
-- ============================================================

-- Persona 1001: RES=2 entidades, LAB=5 entidades → LAB gana
INSERT INTO bdm_datos.reporte_relacion_persona_ubica VALUES
(100, 901, '2025-03-01', 1), (100, 902, '2025-03-01', 1),
(101, 901, '2025-06-01', 1), (101, 902, '2025-06-01', 1), (101, 903, '2025-06-01', 1),
(101, 904, '2025-06-01', 1), (101, 905, '2025-06-01', 1);

-- Persona 1002: LAB=1 entidad, RES=4 entidades → RES gana
INSERT INTO bdm_datos.reporte_relacion_persona_ubica VALUES
(200, 901, '2025-04-01', 1),
(201, 901, '2025-05-01', 1), (201, 902, '2025-05-01', 1),
(201, 903, '2025-05-01', 1), (201, 904, '2025-05-01', 1);

-- Persona 1003: RES=2 entidades, CRR=6 entidades → CRR gana (mayor entidades)
INSERT INTO bdm_datos.reporte_relacion_persona_ubica VALUES
(300, 901, '2025-02-01', 1), (300, 902, '2025-02-01', 1),
(301, 901, '2025-07-01', 1), (301, 902, '2025-07-01', 1), (301, 903, '2025-07-01', 1),
(301, 904, '2025-07-01', 1), (301, 905, '2025-07-01', 1), (301, 906, '2025-07-01', 1);

-- Persona 1004: CRR=1 entidad, RES=5 entidades → RES gana
INSERT INTO bdm_datos.reporte_relacion_persona_ubica VALUES
(400, 901, '2025-01-01', 1),
(401, 901, '2025-06-01', 1), (401, 902, '2025-06-01', 1), (401, 903, '2025-06-01', 1),
(401, 904, '2025-06-01', 1), (401, 905, '2025-06-01', 1);

-- Persona 1005: LAB=3 entidades, CRR=3 entidades → EMPATE
INSERT INTO bdm_datos.reporte_relacion_persona_ubica VALUES
(500, 901, '2025-05-01', 1), (500, 902, '2025-05-01', 1), (500, 903, '2025-05-01', 1),
(501, 904, '2025-05-01', 1), (501, 905, '2025-05-01', 1), (501, 906, '2025-05-01', 1);

-- Persona 1006: RES=3, LAB=4 (pero RES bloqueada, no entra)
-- NOTA: Escenario de bloqueo se mueve a demo de Regla 2
-- INSERT INTO bdm_datos.reporte_relacion_persona_ubica VALUES
-- (600, 901, '2025-04-01', 1), (600, 902, '2025-04-01', 1), (600, 903, '2025-04-01', 1),
-- (601, 901, '2025-06-01', 1), (601, 902, '2025-06-01', 1),
-- (601, 903, '2025-06-01', 1), (601, 904, '2025-06-01', 1);

-- Persona 1007: RES(ya unificada)=2, CRR=3 (pero RES no entra por ind_unificacion=1)
INSERT INTO bdm_datos.reporte_relacion_persona_ubica VALUES
(700, 901, '2025-03-01', 1), (700, 902, '2025-03-01', 1),
(701, 901, '2025-05-01', 1), (701, 902, '2025-05-01', 1), (701, 903, '2025-05-01', 1);

-- ============================================================
-- DATOS: BLOQUEO (para R1-06)
-- ============================================================
-- NOTA: Escenario de bloqueo se mueve a demo de Regla 2
-- INSERT INTO bdm_datos.bloqueo VALUES (600, '2025-04-01');

-- ============================================================
-- ESTADÍSTICAS
-- ============================================================

ANALYZE bdm_datos.tipo_ubicacion_dir;
ANALYZE bdm_datos.ubicacion_estandarizada;
ANALYZE bdm_datos.direccion_fisica;
ANALYZE bdm_datos.relacion_persona_ubicacion;
ANALYZE bdm_datos.ciiu_persona;
ANALYZE bdm_datos.reporte_relacion_persona_ubica;
ANALYZE bdm_datos.bloqueo;
