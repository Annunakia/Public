-- ============================================================
-- 03_demo_cleanup.sql
-- Demo Regla 1: Limpieza completa
-- ============================================================

DROP TABLE IF EXISTS bdm_tempo.stg_regla1_insumo;
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_scored;
DROP TABLE IF EXISTS bdm_tempo.stg_regla1_pares;

DROP TABLE IF EXISTS bdm_datos.unificacion_direccion;
DROP TABLE IF EXISTS bdm_datos.relacion_persona_ubicacion;
DROP TABLE IF EXISTS bdm_datos.reporte_relacion_persona_ubica;
DROP TABLE IF EXISTS bdm_datos.ubicacion_estandarizada;
DROP TABLE IF EXISTS bdm_datos.direccion_fisica;
DROP TABLE IF EXISTS bdm_datos.ciiu_persona;
DROP TABLE IF EXISTS bdm_datos.tipo_ubicacion_dir;
DROP TABLE IF EXISTS bdm_datos.bloqueo;

DROP SCHEMA IF EXISTS bdm_tempo CASCADE;
DROP SCHEMA IF EXISTS bdm_datos CASCADE;
