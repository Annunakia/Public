# Datos Mock – Diseño y Resultado Esperado

> Dataset de prueba para validar migración del proceso de Unificación a Redshift.

---

## Personas y Escenarios

Cada persona está diseñada para disparar un escenario específico. El resultado esperado indica quién debe quedar como Padre y quién como Hijo.

### REGLA 1: Por Tipo de Uso + CIIU

| Persona | Id_Buro | CIIU | Dirección (puerta) | Tipo Uso | Complemento | Entidades | Resultado esperado |
|---------|---------|------|-------------------|----------|-------------|-----------|-------------------|
| P01-A | 1001 | 10 | CL 22 27 45 | LAB | AP 101 | 5 | **PADRE** (Esc1: CIIU=10, tiene LAB, más entidades) |
| P01-B | 1001 | 10 | CL 22 27 45 | RES | AP 101 | 3 | HIJO |
| P02-A | 1002 | 81 | KR 15 80 22 | RES | OF 301 | 4 | **PADRE** (Esc2: CIIU=81, tiene RES, más entidades) |
| P02-B | 1002 | 81 | KR 15 80 22 | LAB | OF 301 | 2 | HIJO |
| P03-A | 1003 | 55 | TV 70 114 55 | CRR | BR SUBA | 7 | **PADRE** (Esc3: otro CIIU, más entidades) |
| P03-B | 1003 | 55 | TV 70 114 55 | RES | BR SUBA | 3 | HIJO |
| P03-C | 1003 | 55 | TV 70 114 55 | LAB | BR SUBA | 1 | HIJO |

### REGLA 2: Por Complementos

| Persona | Id_Buro | Dirección (puerta) | Complemento | Entidades | Fecha | Resultado esperado |
|---------|---------|-------------------|-------------|-----------|-------|-------------------|
| **Esc 1: Complemento vacío** |
| P04-A | 1004 | CL 80 15 20 | AP 802 | 3 | 2025-06-01 | **PADRE** (tiene complemento) |
| P04-B | 1004 | CL 80 15 20 | *(vacío)* | 5 | 2025-08-01 | HIJO |
| **Esc 2: Complemento incluido** |
| P05-A | 1005 | KR 7 45 12 | ED GALICIA AP 702 | 2 | 2025-05-01 | **PADRE** (más completo, contiene al otro) |
| P05-B | 1005 | KR 7 45 12 | AP 702 | 4 | 2025-09-01 | HIJO |
| **Esc 3 sin NIT: Misma nomenclatura, ≠ valor** |
| P06-A | 1006 | DG 50 30 10 | AP 105 | 6 | 2025-07-01 | **PADRE** (misma nomenclatura AP, más entidades) |
| P06-B | 1006 | DG 50 30 10 | AP 404 | 2 | 2025-03-01 | HIJO |
| **Esc 3 con NIT: Misma nomenclatura, ≠ valor** |
| P07-A | 1007 | CL 10 20 30 | LC 101 | 3 | 2025-04-01 | HIJO (NIT: se combinan) |
| P07-B | 1007 | CL 10 20 30 | LC 205 | 3 | 2025-06-01 | HIJO (NIT: se combinan) |
| P07-NEW | 1007 | CL 10 20 30 | LC 101 LC 205 | — | — | **PADRE NUEVO** (dirección generada) |
| **Esc 4: ≠ nomenclatura, mismo nivel** |
| P08-A | 1008 | KR 20 55 18 | CS 312 | 4 | 2025-05-01 | HIJO (Esc 3 sin NIT: misma nomenclatura CS, ≠ valor. Score por fecha) |
| P08-B | 1008 | KR 20 55 18 | CS 108 | 2 | 2025-08-01 | **PADRE** (mayor score: fecha 2025-08-01 compensa menor entidades) |
| P20-A | 1020 | AC 40 12 08 | PI 5 | 3 | 2025-04-01 | HIJO (Esc 4: PI nivel 5 vs CS nivel 5, freq PI=4 < freq CS=10) |
| P20-B | 1020 | AC 40 12 08 | CS 201 | 3 | 2025-04-01 | **PADRE** (diccionario: CS 201 freq=10 > PI 5 freq=4) |
| **Esc 5 subcaso 1: ≠ nomenclatura, ≠ nivel, valores ≠** |
| P09-A | 1009 | CL 45 22 10 | TO 3 | 2 | 2025-06-01 | HIJO (se combinan en nueva dirección) |
| P09-B | 1009 | CL 45 22 10 | AP 504 | 3 | 2025-07-01 | HIJO (se combinan en nueva dirección) |
| P09-NEW | 1009 | CL 45 22 10 | TO 3 AP 504 | — | — | **PADRE NUEVO** (combinación por ≠ nivel) |
| **Esc 5 subcaso 2: ≠ nomenclatura, ≠ nivel, valores =** |
| P10-A | 1010 | TV 30 15 40 | TO 3 | 5 | 2025-04-01 | HIJO (score: fecha 2025-04-01 pierde vs AP 3) |
| P10-B | 1010 | TV 30 15 40 | AP 3 | 2 | 2025-05-01 | **PADRE** (mayor score: fecha 2025-05-01 compensa menor frecuencia) |
| **Esc 6 subcaso 1: Ninguna contenida, ≠ nivel** |
| P11-A | 1011 | KR 10 27 45 | ED PROMOTOR | 2 | 2025-03-01 | HIJO (se combinan) |
| P11-B | 1011 | KR 10 27 45 | OF 2007 | 3 | 2025-06-01 | HIJO (se combinan) |
| P11-NEW | 1011 | KR 10 27 45 | ED PROMOTOR OF 2007 | — | — | **PADRE NUEVO** (combinación) |
| **Esc 6 subcaso 3: Ninguna contenida, mismo nivel** |
| P12-A | 1012 | DG 80 22 15 | BR CASTILLA | 4 | 2025-07-01 | **PADRE** (diccionario: BR CASTILLA más frecuente) |
| P12-B | 1012 | DG 80 22 15 | BR VENECIA | 1 | 2025-02-01 | HIJO |

### REGLA 3: Por Geolocalización

| Persona | Id_Buro | Dirección | Lat | Long | Entidades | Fecha | Resultado esperado |
|---------|---------|-----------|-----|------|-----------|-------|-------------------|
| **Esc 1 sub 1: ≠ vía generadora, solo uno tiene geo** |
| P13-A | 1013 | CL 8 6 52 | 4.60 | -74.08 | 3 | 2025-05-01 | **PADRE** (tiene lat/long) |
| P13-B | 1013 | CL 8 7 52 | NULL | NULL | 5 | 2025-09-01 | HIJO |
| **Esc 1 sub 2: ≠ vía generadora, ninguno tiene geo** |
| P14-A | 1014 | KR 55 14 30 | NULL | NULL | 2 | 2025-09-01 | **PADRE** (fecha más reciente) |
| P14-B | 1014 | KR 55 15 30 | NULL | NULL | 4 | 2025-03-01 | HIJO |
| **Esc 1 sub 3: ≠ vía generadora, ambos tienen geo** |
| P15-A | 1015 | KR 7 181 75 | 4.72 | -74.05 | 3 | 2025-06-01 | **PADRE** (diccionario: 181 más frecuente) |
| P15-B | 1015 | KR 7 182 75 | 4.72 | -74.05 | 2 | 2025-04-01 | HIJO |
| **Esc 2 sub 1: ≠ puerta, solo uno tiene geo** |
| P16-A | 1016 | AV BOYACA 77A 41 | NULL | NULL | 3 | 2025-07-01 | HIJO |
| P16-B | 1016 | AV BOYACA 77A 43 | 4.65 | -74.10 | 2 | 2025-05-01 | **PADRE** (tiene lat/long) |
| **Esc 2 sub 2: ≠ puerta, ninguno tiene geo** |
| P17-A | 1017 | CL 13 18 21 | NULL | NULL | 3 | 2025-10-01 | **PADRE** (fecha más reciente) |
| P17-B | 1017 | CL 13 18 23 | NULL | NULL | 5 | 2025-04-01 | HIJO |
| **Esc 2 sub 3: ≠ puerta (±2), ambos tienen geo** |
| P18-A | 1018 | KR 55 14 55 | 4.68 | -74.06 | 4 | 2025-06-01 | **PADRE** (diccionario: 55 más frecuente) |
| P18-B | 1018 | KR 55 14 57 | 4.68 | -74.06 | 2 | 2025-05-01 | HIJO |
| **Esc 2 sub 3: ≠ puerta (>2), no unifica** |
| P19-A | 1019 | CL 20 10 50 | 4.70 | -74.07 | 3 | 2025-06-01 | SIN CAMBIO (diferencia > ±2) |
| P19-B | 1019 | CL 20 10 60 | 4.70 | -74.07 | 2 | 2025-05-01 | SIN CAMBIO (diferencia > ±2) |

---

## Tablas de Catálogo Mock

### NOMENCLATURA (niveles)

| Nomenclatura | Nivel_Complemento |
|-------------|-------------------|
| BR | 1 |
| UR | 1 |
| CJ | 1 |
| ED | 2 |
| ZN | 2 |
| MZ | 3 |
| ET | 3 |
| TO | 4 |
| BQ | 4 |
| PI | 5 |
| CS | 5 |
| LC | 6 |
| OF | 6 |
| AP | 7 |
| IN | 7 |

### DICCIONARIO_COMPLEMENTOS (frecuencias mock para Regla 2)

| Cod_DW_Ubic | Nomenclatura | Nomen | Frecuencia |
|-------------|-------------|-------|------------|
| 5008 | CS 312 | CS | 15 |
| 5008 | CS 108 | CS | 3 |
| 5010 | TO 3 | TO | 12 |
| 5010 | AP 3 | AP | 4 |
| 5012 | BR CASTILLA | BR | 20 |
| 5012 | BR VENECIA | BR | 5 |

### DICCIONARIO_VIA (frecuencias mock para Regla 3)

| Llave | Componente | Valor | Frecuencia |
|-------|-----------|-------|------------|
| KR 7 _ 75 | Via_Generadora | 181 | 15 |
| KR 7 _ 75 | Via_Generadora | 182 | 3 |
| KR 55 14 _ | Numero_Puerta | 55 | 12 |
| KR 55 14 _ | Numero_Puerta | 57 | 4 |

### TIPO_IDENTIFICACION (para Escenario 3 NIT)

| Cod_Tipo_Ident_Fte | Nombre_Tipo_Ident |
|--------------------|-------------------|
| 1 | Cedula de Ciudadania |
| 3 | Nit |

---

## Resumen: 19 personas, 40 registros, 12 escenarios cubiertos

| Regla | Escenario | Personas | Resultado |
|-------|-----------|----------|-----------|
| R1 | Esc 1 (CIIU=10) | P01 | Padre existente |
| R1 | Esc 2 (CIIU=81) | P02 | Padre existente |
| R1 | Esc 3 (otro CIIU, 3 dirs) | P03 | Padre existente |
| R2 | Esc 1 (vacío) | P04 | Padre existente |
| R2 | Esc 2 (incluido) | P05 | Padre existente |
| R2 | Esc 3 sin NIT | P06 | Padre existente |
| R2 | Esc 3 con NIT | P07 | **Padre nuevo generado** |
| R2 | Esc 4 (mismo nivel) | P08 | Padre existente (Esc 3 sin NIT, no Esc 4) |
| R2 | Esc 4 (mismo nivel) | P20 | Padre existente (diccionario: CS 201 freq=10) |
| R2 | Esc 5 sub 1 (≠ nivel, ≠ valor) | P09 | **Padre nuevo generado** |
| R2 | Esc 5 sub 2 (≠ nivel, = valor) | P10 | Padre existente |
| R2 | Esc 6 sub 1 (≠ nivel) | P11 | **Padre nuevo generado** |
| R2 | Esc 6 sub 3 (= nivel) | P12 | Padre existente |
| R3 | Esc 1 sub 1 (geo parcial) | P13 | Padre existente |
| R3 | Esc 1 sub 2 (sin geo) | P14 | Padre existente |
| R3 | Esc 1 sub 3 (ambos geo) | P15 | Padre existente |
| R3 | Esc 2 sub 1 (geo parcial) | P16 | Padre existente |
| R3 | Esc 2 sub 2 (sin geo) | P17 | Padre existente |
| R3 | Esc 2 sub 3 (±2, geo) | P18 | Padre existente |
| R3 | Esc 2 sub 3 (>2, no unifica) | P19 | Sin cambio |

---

*Generado: 2026-04-17*
