-- ============================================================
-- validate_motor_p07.sql
-- Validación del motor de nuevas direcciones con P07 (NIT)
-- Ejecutar en sandbox Redshift
-- ============================================================
-- Resultado esperado:
--   P07-A (LC 101) y P07-B (LC 205) → HIJOS
--   Nueva dirección "LC 101 LC 205" → PADRE NUEVO generado
-- ============================================================

-- =====================
-- PARTE 1: LIMPIAR TODO
-- =====================
DELETE FROM bdm_datos.unificacion_direccion;
DELETE FROM bdm_datos.relacion_persona_ubicacion;
DELETE FROM bdm_datos.direccion_fisica;
DELETE FROM bdm_datos.ubicacion_estandarizada;
DELETE FROM bdm_datos.nomenclatura;
DELETE FROM bdm_datos.diccionario_complementos;
DELETE FROM bdm_datos.reporte_relacion_persona_ubica;
DELETE FROM bdm_datos.tipo_ubicacion_dir;
DELETE FROM bdm_datos.ciiu_persona;

-- =====================
-- PARTE 2: CARGAR CATÁLOGOS
-- =====================

-- Nomenclaturas
INSERT INTO bdm_datos.nomenclatura VALUES ('BR', 1);
INSERT INTO bdm_datos.nomenclatura VALUES ('ED', 2);
INSERT INTO bdm_datos.nomenclatura VALUES ('TO', 4);
INSERT INTO bdm_datos.nomenclatura VALUES ('CS', 5);
INSERT INTO bdm_datos.nomenclatura VALUES ('LC', 6);
INSERT INTO bdm_datos.nomenclatura VALUES ('OF', 6);
INSERT INTO bdm_datos.nomenclatura VALUES ('AP', 7);

-- Tipo ubicación
INSERT INTO bdm_datos.tipo_ubicacion_dir VALUES (1, 'RES');
INSERT INTO bdm_datos.tipo_ubicacion_dir VALUES (2, 'LAB');

-- Diccionario complementos para P07
INSERT INTO bdm_datos.diccionario_complementos VALUES (5007, 1007, 'LC 101', 'LC', '101', 8);
INSERT INTO bdm_datos.diccionario_complementos VALUES (5007, 1007, 'LC 205', 'LC', '205', 4);

ANALYZE bdm_datos.nomenclatura;
ANALYZE bdm_datos.tipo_ubicacion_dir;
ANALYZE bdm_datos.diccionario_complementos;

-- =====================
-- PARTE 3: CARGAR DATOS P07
-- =====================

-- Ubicación estandarizada
INSERT INTO bdm_datos.ubicacion_estandarizada VALUES (5007, 'CL 10 20 30', 11001, 1, NULL, NULL);

-- Direcciones físicas
INSERT INTO bdm_datos.direccion_fisica VALUES (6010, 'LC 101', 'CL', '10', 20, 30, 5007, 0);
INSERT INTO bdm_datos.direccion_fisica VALUES (6011, 'LC 205', 'CL', '10', 20, 30, 5007, 0);

-- Relación persona-ubicación (cod_tipo_ident_fte=3 → NIT)
INSERT INTO bdm_datos.relacion_persona_ubicacion VALUES (100014, 1007, 9007, 5007, 6010, 1, NULL, 1, '2025-04-01', 1, 3);
INSERT INTO bdm_datos.relacion_persona_ubicacion VALUES (100015, 1007, 9007, 5007, 6011, 1, NULL, 2, '2025-06-01', 1, 3);

-- Reportes (3 entidades cada uno)
INSERT INTO bdm_datos.reporte_relacion_persona_ubica VALUES (100014, 501, '2025-04-01');
INSERT INTO bdm_datos.reporte_relacion_persona_ubica VALUES (100014, 502, '2025-03-01');
INSERT INTO bdm_datos.reporte_relacion_persona_ubica VALUES (100014, 503, '2025-02-01');
INSERT INTO bdm_datos.reporte_relacion_persona_ubica VALUES (100015, 501, '2025-06-01');
INSERT INTO bdm_datos.reporte_relacion_persona_ubica VALUES (100015, 502, '2025-05-01');
INSERT INTO bdm_datos.reporte_relacion_persona_ubica VALUES (100015, 503, '2025-04-01');

ANALYZE bdm_datos.ubicacion_estandarizada;
ANALYZE bdm_datos.direccion_fisica;
ANALYZE bdm_datos.relacion_persona_ubicacion;
ANALYZE bdm_datos.reporte_relacion_persona_ubica;

-- =====================
-- PARTE 4: SIMULAR REGLA 1 (no aplica a P07, pero necesitamos stg_regla2_e2)
-- Ejecutar 02_regla1_unificacion.sql primero, luego 03_regla2_esc1_2.sql
-- que crea stg_regla2_e2.
-- Para esta validación aislada, creamos stg_regla2_e2 directamente:
-- =====================
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e2;
CREATE TABLE bdm_tempo.stg_regla2_e2
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  rpu.cod_dw_persona_ubic,
  CAST(NULL AS BIGINT) AS id_padre,
  rpu.id_buro_persona,
  rpu.cod_dw_tipo_ubicacion_dir,
  rpu.cod_dw_ubic,
  ubi.texto_ubicacion,
  rpu.cod_dw_direccion_fisica,
  df.complemento,
  CAST(NULL AS INTEGER) AS cod_dw_doc_ident,
  CAST(NULL AS VARCHAR(20)) AS cod_tipo_ident_fte,
  ubi.cod_dw_ciudad AS cod_dw_municipio,
  COALESCE(cnt.numero_entidades_reportan, 0) AS numero_entidades_reportan,
  rpu.fecha_relacion_persona_ubicaci,
  'N' AS ind_unificacion,
  0 AS row_u,
  CAST(NULL AS VARCHAR(100)) AS n_id
FROM bdm_datos.relacion_persona_ubicacion rpu
JOIN bdm_datos.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_datos.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN (
  SELECT cod_dw_persona_ubic, COUNT(DISTINCT id_buro_suscriptor) AS numero_entidades_reportan
  FROM bdm_datos.reporte_relacion_persona_ubica GROUP BY 1
) cnt ON rpu.cod_dw_persona_ubic = cnt.cod_dw_persona_ubic
WHERE rpu.ind_unificacion IS NULL;

ANALYZE bdm_tempo.stg_regla2_e2;

-- =====================
-- PARTE 5: EJECUTAR ESCENARIO 3 NIT (07_regla2_esc3_nit.sql pasos 1-3)
-- =====================

-- Paso 1: Filtrar NITs no-unificados
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e031;
CREATE TABLE bdm_tempo.stg_regla2_e031
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT a.*
FROM bdm_tempo.stg_regla2_e2 a
JOIN bdm_datos.relacion_persona_ubicacion rpu
  ON a.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE a.ind_unificacion = 'N'
  AND rpu.cod_tipo_ident_fte = 3;

ANALYZE bdm_tempo.stg_regla2_e031;

-- Paso 2: Encontrar pares con misma nomenclatura ≠ valor
DROP TABLE IF EXISTS bdm_tempo.stg_regla2_e03_nit_pares;
CREATE TABLE bdm_tempo.stg_regla2_e03_nit_pares
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT a.cod_dw_persona_ubic
FROM bdm_tempo.stg_regla2_e031 a
JOIN bdm_tempo.stg_regla2_e031 b
  ON  a.id_buro_persona          = b.id_buro_persona
  AND a.texto_ubicacion           = b.texto_ubicacion
  AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
  AND a.cod_dw_municipio          = b.cod_dw_municipio
  AND a.cod_dw_persona_ubic      <> b.cod_dw_persona_ubic
  AND a.complemento              <> b.complemento
JOIN bdm_datos.nomenclatura nmc1
  ON a.complemento LIKE nmc1.nomenclatura || '%'
JOIN bdm_datos.nomenclatura nmc2
  ON b.complemento LIKE nmc2.nomenclatura || '%'
WHERE nmc1.nomenclatura = nmc2.nomenclatura;

ANALYZE bdm_tempo.stg_regla2_e03_nit_pares;

-- Paso 3: Preparar stg_motor_input
DROP TABLE IF EXISTS bdm_tempo.stg_motor_input;
CREATE TABLE bdm_tempo.stg_motor_input
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  e.cod_dw_persona_ubic,
  e.cod_dw_ubic,
  e.complemento,
  e.id_buro_persona,
  e.cod_dw_tipo_ubicacion_dir,
  rpu.cod_pin_persona,
  rpu.cod_dw_direccion_fisica,
  e.texto_ubicacion,
  e.fecha_relacion_persona_ubicaci
FROM bdm_tempo.stg_regla2_e031 e
JOIN bdm_tempo.stg_regla2_e03_nit_pares p
  ON e.cod_dw_persona_ubic = p.cod_dw_persona_ubic
JOIN bdm_datos.relacion_persona_ubicacion rpu
  ON e.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

ANALYZE bdm_tempo.stg_motor_input;

-- Checkpoint: verificar que el input tiene 2 registros (P07-A y P07-B)
SELECT 'CHECKPOINT 1: stg_motor_input' AS test,
  COUNT(*) AS filas,
  CASE WHEN COUNT(*) = 2 THEN 'OK' ELSE 'FAIL' END AS resultado
FROM bdm_tempo.stg_motor_input;

-- ============================================================
-- PARTE 6: VERIFICACIONES
-- ============================================================

-- TEST 1: Nueva dirección "LC 101 LC 205" creada en DIRECCION_FISICA
SELECT 'TEST 1: Nueva dirección en DIRECCION_FISICA' AS test,
  complemento,
  generada_enriquecida,
  CASE WHEN complemento = 'LC 101 LC 205' AND generada_enriquecida = 1
    THEN 'PASS' ELSE 'FAIL' END AS resultado
FROM bdm_datos.direccion_fisica
WHERE generada_enriquecida = 1;

-- TEST 2: P07-A y P07-B marcados como hijos (ind_unificacion=1)
SELECT 'TEST 2: Hijos marcados' AS test,
  cod_dw_persona_ubic,
  ind_unificacion,
  CASE WHEN ind_unificacion = 1 THEN 'PASS' ELSE 'FAIL' END AS resultado
FROM bdm_datos.relacion_persona_ubicacion
WHERE cod_dw_persona_ubic IN (100014, 100015);

-- TEST 3: Nueva relación persona-ubicación creada
SELECT 'TEST 3: Nueva relación persona-ubicación' AS test,
  rpu.cod_dw_persona_ubic,
  rpu.id_buro_persona,
  df.complemento,
  CASE WHEN df.complemento = 'LC 101 LC 205' AND rpu.ind_unificacion IS NULL
    THEN 'PASS' ELSE 'FAIL' END AS resultado
FROM bdm_datos.relacion_persona_ubicacion rpu
JOIN bdm_datos.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.cod_dw_persona_ubic NOT IN (100014, 100015)
  AND rpu.id_buro_persona = 1007;

-- TEST 4: Pares en UNIFICACION_DIRECCION (2 hijos apuntando al padre nuevo)
SELECT 'TEST 4: Pares unificación' AS test,
  ud.cod_dw_persona_ubic AS hijo,
  ud.cod_dw_direccion_unificada AS padre,
  ud.unifica_atributos,
  CASE WHEN ud.cod_dw_persona_ubic IN (100014, 100015) THEN 'PASS' ELSE 'FAIL' END AS resultado
FROM bdm_datos.unificacion_direccion ud;

-- TEST 5: Conteo total — debe haber exactamente 1 nueva dirección
SELECT 'TEST 5: Conteo nuevas direcciones' AS test,
  COUNT(*) AS total_nuevas,
  CASE WHEN COUNT(*) = 1 THEN 'PASS' ELSE 'FAIL' END AS resultado
FROM bdm_datos.direccion_fisica
WHERE generada_enriquecida = 1;

-- TEST 6: 0 falsos positivos — ningún registro que no sea P07 fue tocado
SELECT 'TEST 6: Cero falsos positivos' AS test,
  COUNT(*) AS registros_no_p07_unificados,
  CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS resultado
FROM bdm_datos.relacion_persona_ubicacion
WHERE ind_unificacion = 1
  AND id_buro_persona <> 1007;

-- RESUMEN
SELECT '=== RESUMEN ===' AS info,
  (SELECT COUNT(*) FROM bdm_datos.direccion_fisica WHERE generada_enriquecida = 1) AS nuevas_direcciones,
  (SELECT COUNT(*) FROM bdm_datos.unificacion_direccion) AS pares_unificacion,
  (SELECT COUNT(*) FROM bdm_datos.relacion_persona_ubicacion WHERE ind_unificacion = 1) AS hijos_marcados,
  (SELECT COUNT(*) FROM bdm_datos.relacion_persona_ubicacion WHERE id_buro_persona = 1007 AND ind_unificacion IS NULL AND cod_dw_persona_ubic NOT IN (100014, 100015)) AS nuevas_relaciones;
