#!/bin/bash
# run_sql.sh - Ejecuta SQL en Redshift via Data API
# Uso: ./run_sql.sh "SELECT 1" [label]
PROFILE="sandbox"
REGION="us-east-1"
WORKGROUP="experian-sandbox-trunk-ddm-xpm-workgroup"
DB="dev"

SQL="$1"
LABEL="${2:-query}"

ID=$(aws redshift-data execute-statement \
  --workgroup-name "$WORKGROUP" --database "$DB" \
  --sql "$SQL" --profile "$PROFILE" --region "$REGION" \
  --query 'Id' --output text 2>&1)

if [[ "$ID" == *"ERROR"* ]]; then
  echo "ERROR ejecutando: $ID"
  exit 1
fi

# Poll hasta que termine
for i in $(seq 1 60); do
  STATUS=$(aws redshift-data describe-statement --id "$ID" \
    --profile "$PROFILE" --region "$REGION" \
    --query 'Status' --output text 2>/dev/null)
  if [[ "$STATUS" == "FINISHED" ]]; then
    echo "[$LABEL] OK"
    aws redshift-data get-statement-result --id "$ID" \
      --profile "$PROFILE" --region "$REGION" 2>/dev/null \
      | python3 -c "
import sys,json
d=json.load(sys.stdin)
if d.get('TotalNumRows',0)>0:
  cols=[c['label'] for c in d['ColumnMetadata']]
  print(' | '.join(cols))
  print('-'*60)
  for r in d['Records']:
    vals=[list(v.values())[0] if v else 'NULL' for v in r]
    print(' | '.join(str(x) for x in vals))
  print(f'({d[\"TotalNumRows\"]} filas)')
" 2>/dev/null
    exit 0
  elif [[ "$STATUS" == "FAILED" || "$STATUS" == "ABORTED" ]]; then
    ERR=$(aws redshift-data describe-statement --id "$ID" \
      --profile "$PROFILE" --region "$REGION" \
      --query 'Error' --output text 2>/dev/null)
    echo "[$LABEL] FAILED: $ERR"
    exit 1
  fi
  sleep 2
done
echo "[$LABEL] TIMEOUT"
exit 1
