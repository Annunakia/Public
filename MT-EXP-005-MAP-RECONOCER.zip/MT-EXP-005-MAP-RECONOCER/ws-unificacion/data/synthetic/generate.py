"""
Generador de dataset sintético para validación integral de Unificación.
5,000 personas con distribución realista de escenarios.
"""
import random
import csv
from datetime import date, timedelta

random.seed(42)

# Distribución de escenarios (5000 personas)
DIST = {
    'CONTROL': 2000,      # 1 sola dirección, no unifica
    'R1_ESC1': 500,       # CIIU=10, LAB vs RES
    'R1_ESC2': 400,       # CIIU=81, RES vs LAB
    'R1_ESC3': 350,       # Otro CIIU, más entidades
    'R2_ESC1': 400,       # Complemento vacío vs no vacío
    'R2_ESC2': 350,       # Complemento incluido
    'R2_ESC3_NONIT': 300, # Misma nomenclatura ≠ valor, no NIT
    'R2_ESC3_NIT': 100,   # Misma nomenclatura ≠ valor, NIT → motor
    'R2_ESC4': 150,       # ≠ nomenclatura, mismo nivel
    'R2_ESC5_SUB1': 100,  # ≠ nivel, ≠ valor → motor
    'R2_ESC5_SUB2': 50,   # ≠ nivel, = valor → diccionario
    'R2_ESC6_SUB1': 50,   # Ninguna contenida, ≠ nivel → motor
    'R2_ESC6_SUB3': 50,   # Ninguna contenida, = nivel → diccionario
    'R3_ESC1_SUB1': 50,   # ≠ vía gen, solo uno geo
    'R3_ESC1_SUB2': 30,   # ≠ vía gen, sin geo
    'R3_ESC1_SUB3': 30,   # ≠ vía gen, ambos geo
    'R3_ESC2_SUB2': 30,   # ≠ puerta, sin geo
    'R3_ESC2_SUB3': 30,   # ≠ puerta ±2, ambos geo
    'R3_NO_UNIF': 30,     # ≠ puerta >2, no unifica
}
assert sum(DIST.values()) == 5000

# Tipos de vía colombianos
TIPOS_VIA = ['CL', 'KR', 'TV', 'DG', 'AC']
# Nomenclaturas por nivel
NOM_NIVEL = {1: ['BR'], 2: ['ED'], 4: ['TO', 'BQ'], 5: ['PI', 'CS'], 6: ['LC', 'OF'], 7: ['AP', 'IN']}
CIIU_MAP = {'R1_ESC1': '10', 'R1_ESC2': '81', 'R1_ESC3': '55'}

# Contadores
id_buro = 10000
cod_dw_ubic = 50000
cod_dw_df = 60000
cod_dw_pu = 200000
suscriptor_base = 1000

# Tablas de salida
ubicaciones = []
direcciones = []
relaciones = []
reportes = []
ciiu_personas = []
dic_complementos = []
dic_via = []
# Resultado esperado
esperado = []

def rand_date(start_year=2024, end_year=2025):
    d = date(start_year, 1, 1) + timedelta(days=random.randint(0, 730))
    return min(d, date(2025, 12, 31))

def rand_entidades(cod_pu, n):
    global suscriptor_base
    reps = []
    for i in range(n):
        suscriptor_base += 1
        reps.append((cod_pu, suscriptor_base, rand_date()))
    return reps

def make_ubicacion(tipo_via, via_pri, via_gen, num_puerta, lat=None, lon=None):
    global cod_dw_ubic
    cod_dw_ubic += 1
    texto = f"{tipo_via} {via_pri} {via_gen} {num_puerta}"
    ubicaciones.append((cod_dw_ubic, texto, 11001, 1, lat, lon))
    return cod_dw_ubic

def make_df(complemento, tipo_via, via_pri, via_gen, num_puerta, ubic_id):
    global cod_dw_df
    cod_dw_df += 1
    direcciones.append((cod_dw_df, complemento, tipo_via, via_pri, via_gen, num_puerta, ubic_id, 0))
    return cod_dw_df

def make_rpu(id_buro_p, ubic_id, df_id, tipo_uso, fecha, cod_tipo_ident=1):
    global cod_dw_pu
    cod_dw_pu += 1
    pin = id_buro_p + 80000
    relaciones.append((cod_dw_pu, id_buro_p, pin, ubic_id, df_id, tipo_uso, None, None, fecha, 1, cod_tipo_ident))
    return cod_dw_pu

for escenario, count in DIST.items():
    for _ in range(count):
        id_buro += 1
        tipo_via = random.choice(TIPOS_VIA)
        via_pri = str(random.randint(1, 100))
        via_gen = random.randint(1, 200)
        num_puerta = random.randint(1, 99)
        fecha1 = rand_date()
        fecha2 = rand_date()
        ent1 = random.randint(1, 10)
        ent2 = random.randint(1, 10)

        if escenario == 'CONTROL':
            comp = random.choice(['AP', 'TO', 'BR']) + ' ' + str(random.randint(1, 500))
            u = make_ubicacion(tipo_via, via_pri, via_gen, num_puerta)
            d = make_df(comp, tipo_via, via_pri, via_gen, num_puerta, u)
            pu = make_rpu(id_buro, u, d, 1, fecha1)
            reportes.extend(rand_entidades(pu, ent1))
            esperado.append((id_buro, escenario, 'SIN_CAMBIO', None))

        elif escenario.startswith('R1'):
            comp = 'AP ' + str(random.randint(100, 999))
            u = make_ubicacion(tipo_via, via_pri, via_gen, num_puerta)
            d = make_df(comp, tipo_via, via_pri, via_gen, num_puerta, u)
            ciiu = CIIU_MAP[escenario]
            ciiu_personas.append((id_buro, ciiu))
            if escenario == 'R1_ESC1':
                pu1 = make_rpu(id_buro, u, d, 2, fecha1)  # LAB
                pu2 = make_rpu(id_buro, u, d, 1, fecha2)  # RES
            elif escenario == 'R1_ESC2':
                pu1 = make_rpu(id_buro, u, d, 1, fecha1)  # RES
                pu2 = make_rpu(id_buro, u, d, 2, fecha2)  # LAB
            else:
                pu1 = make_rpu(id_buro, u, d, 1, fecha1)
                pu2 = make_rpu(id_buro, u, d, 2, fecha2)
            reportes.extend(rand_entidades(pu1, max(ent1, ent2 + 1)))
            reportes.extend(rand_entidades(pu2, min(ent1, ent2)))
            esperado.append((id_buro, escenario, 'PADRE', pu1))

        elif escenario == 'R2_ESC1':
            comp = random.choice(['AP', 'TO', 'LC']) + ' ' + str(random.randint(1, 500))
            u = make_ubicacion(tipo_via, via_pri, via_gen, num_puerta)
            d1 = make_df(comp, tipo_via, via_pri, via_gen, num_puerta, u)
            d2 = make_df('', tipo_via, via_pri, via_gen, num_puerta, u)
            pu1 = make_rpu(id_buro, u, d1, 1, fecha1)
            pu2 = make_rpu(id_buro, u, d2, 1, fecha2)
            reportes.extend(rand_entidades(pu1, ent1))
            reportes.extend(rand_entidades(pu2, ent2))
            esperado.append((id_buro, escenario, 'PADRE', pu1))

        elif escenario == 'R2_ESC2':
            nom = random.choice(['AP', 'TO', 'ED'])
            val = str(random.randint(100, 999))
            comp_full = f"ED GALICIA {nom} {val}"
            comp_part = f"{nom} {val}"
            u = make_ubicacion(tipo_via, via_pri, via_gen, num_puerta)
            d1 = make_df(comp_full, tipo_via, via_pri, via_gen, num_puerta, u)
            d2 = make_df(comp_part, tipo_via, via_pri, via_gen, num_puerta, u)
            pu1 = make_rpu(id_buro, u, d1, 1, fecha1)
            pu2 = make_rpu(id_buro, u, d2, 1, fecha2)
            reportes.extend(rand_entidades(pu1, ent1))
            reportes.extend(rand_entidades(pu2, ent2))
            esperado.append((id_buro, escenario, 'PADRE', pu1))

        elif escenario == 'R2_ESC3_NONIT':
            nom = random.choice(['AP', 'CS', 'LC', 'TO'])
            v1, v2 = random.randint(100, 499), random.randint(500, 999)
            u = make_ubicacion(tipo_via, via_pri, via_gen, num_puerta)
            d1 = make_df(f"{nom} {v1}", tipo_via, via_pri, via_gen, num_puerta, u)
            d2 = make_df(f"{nom} {v2}", tipo_via, via_pri, via_gen, num_puerta, u)
            pu1 = make_rpu(id_buro, u, d1, 1, fecha1)
            pu2 = make_rpu(id_buro, u, d2, 1, fecha2)
            reportes.extend(rand_entidades(pu1, ent1))
            reportes.extend(rand_entidades(pu2, ent2))
            esperado.append((id_buro, escenario, 'SCORE', None))

        elif escenario == 'R2_ESC3_NIT':
            nom = random.choice(['LC', 'AP', 'CS'])
            v1, v2 = random.randint(100, 499), random.randint(500, 999)
            u = make_ubicacion(tipo_via, via_pri, via_gen, num_puerta)
            d1 = make_df(f"{nom} {v1}", tipo_via, via_pri, via_gen, num_puerta, u)
            d2 = make_df(f"{nom} {v2}", tipo_via, via_pri, via_gen, num_puerta, u)
            pu1 = make_rpu(id_buro, u, d1, 1, fecha1, cod_tipo_ident=3)
            pu2 = make_rpu(id_buro, u, d2, 1, fecha2, cod_tipo_ident=3)
            reportes.extend(rand_entidades(pu1, ent1))
            reportes.extend(rand_entidades(pu2, ent2))
            # Diccionario complementos
            dic_complementos.append((u, id_buro, f"{nom} {v1}", nom, str(v1), random.randint(1, 20)))
            dic_complementos.append((u, id_buro, f"{nom} {v2}", nom, str(v2), random.randint(1, 20)))
            esperado.append((id_buro, escenario, 'MOTOR', None))

        elif escenario == 'R2_ESC4':
            # ≠ nomenclatura, mismo nivel
            nivel = random.choice([5, 6, 7])
            noms = NOM_NIVEL[nivel]
            if len(noms) < 2:
                noms = NOM_NIVEL[5]  # fallback a PI, CS
            n1, n2 = random.sample(noms, 2)
            v1, v2 = random.randint(1, 500), random.randint(1, 500)
            u = make_ubicacion(tipo_via, via_pri, via_gen, num_puerta)
            d1 = make_df(f"{n1} {v1}", tipo_via, via_pri, via_gen, num_puerta, u)
            d2 = make_df(f"{n2} {v2}", tipo_via, via_pri, via_gen, num_puerta, u)
            pu1 = make_rpu(id_buro, u, d1, 1, fecha1)
            pu2 = make_rpu(id_buro, u, d2, 1, fecha2)
            reportes.extend(rand_entidades(pu1, ent1))
            reportes.extend(rand_entidades(pu2, ent2))
            dic_complementos.append((u, id_buro, f"{n1} {v1}", n1, str(v1), random.randint(1, 30)))
            dic_complementos.append((u, id_buro, f"{n2} {v2}", n2, str(v2), random.randint(1, 30)))
            esperado.append((id_buro, escenario, 'SCORE', None))

        elif escenario == 'R2_ESC5_SUB1':
            # ≠ nivel, ≠ valor → motor
            n1 = random.choice(NOM_NIVEL[4])  # TO/BQ nivel 4
            n2 = random.choice(NOM_NIVEL[7])  # AP/IN nivel 7
            v1, v2 = random.randint(1, 20), random.randint(100, 999)
            u = make_ubicacion(tipo_via, via_pri, via_gen, num_puerta)
            d1 = make_df(f"{n1} {v1}", tipo_via, via_pri, via_gen, num_puerta, u)
            d2 = make_df(f"{n2} {v2}", tipo_via, via_pri, via_gen, num_puerta, u)
            pu1 = make_rpu(id_buro, u, d1, 1, fecha1)
            pu2 = make_rpu(id_buro, u, d2, 1, fecha2)
            reportes.extend(rand_entidades(pu1, ent1))
            reportes.extend(rand_entidades(pu2, ent2))
            dic_complementos.append((u, id_buro, f"{n1} {v1}", n1, str(v1), random.randint(1, 20)))
            dic_complementos.append((u, id_buro, f"{n2} {v2}", n2, str(v2), random.randint(1, 20)))
            esperado.append((id_buro, escenario, 'MOTOR', None))

        elif escenario == 'R2_ESC5_SUB2':
            # ≠ nivel, = valor → diccionario
            n1 = random.choice(NOM_NIVEL[4])
            n2 = random.choice(NOM_NIVEL[7])
            val = str(random.randint(1, 20))
            u = make_ubicacion(tipo_via, via_pri, via_gen, num_puerta)
            d1 = make_df(f"{n1} {val}", tipo_via, via_pri, via_gen, num_puerta, u)
            d2 = make_df(f"{n2} {val}", tipo_via, via_pri, via_gen, num_puerta, u)
            pu1 = make_rpu(id_buro, u, d1, 1, fecha1)
            pu2 = make_rpu(id_buro, u, d2, 1, fecha2)
            reportes.extend(rand_entidades(pu1, ent1))
            reportes.extend(rand_entidades(pu2, ent2))
            dic_complementos.append((u, id_buro, f"{n1} {val}", n1, val, random.randint(1, 20)))
            dic_complementos.append((u, id_buro, f"{n2} {val}", n2, val, random.randint(1, 20)))
            esperado.append((id_buro, escenario, 'SCORE', None))

        elif escenario == 'R2_ESC6_SUB1':
            # Ninguna contenida, ≠ nivel → motor
            n1 = random.choice(NOM_NIVEL[2])  # ED nivel 2
            n2 = random.choice(NOM_NIVEL[6])  # LC/OF nivel 6
            v1 = random.choice(['GALICIA', 'PROMOTOR', 'CENTRAL'])
            v2 = random.randint(100, 999)
            u = make_ubicacion(tipo_via, via_pri, via_gen, num_puerta)
            d1 = make_df(f"{n1} {v1}", tipo_via, via_pri, via_gen, num_puerta, u)
            d2 = make_df(f"{n2} {v2}", tipo_via, via_pri, via_gen, num_puerta, u)
            pu1 = make_rpu(id_buro, u, d1, 1, fecha1)
            pu2 = make_rpu(id_buro, u, d2, 1, fecha2)
            reportes.extend(rand_entidades(pu1, ent1))
            reportes.extend(rand_entidades(pu2, ent2))
            dic_complementos.append((u, id_buro, f"{n1} {v1}", n1, v1, random.randint(1, 20)))
            dic_complementos.append((u, id_buro, f"{n2} {v2}", n2, str(v2), random.randint(1, 20)))
            esperado.append((id_buro, escenario, 'MOTOR', None))

        elif escenario == 'R2_ESC6_SUB3':
            # Ninguna contenida, = nivel → diccionario
            noms = random.choice([(1, ['BR']), (5, ['PI', 'CS'])])
            nivel, pool = noms
            if len(pool) < 2:
                n1 = n2 = pool[0]
            else:
                n1, n2 = random.sample(pool, 2)
            v1 = random.choice(['CASTILLA', 'VENECIA', 'SUBA']) if nivel == 1 else str(random.randint(1, 500))
            v2 = random.choice(['MODELIA', 'FONTIBON', 'USME']) if nivel == 1 else str(random.randint(1, 500))
            u = make_ubicacion(tipo_via, via_pri, via_gen, num_puerta)
            d1 = make_df(f"{n1} {v1}", tipo_via, via_pri, via_gen, num_puerta, u)
            d2 = make_df(f"{n2} {v2}", tipo_via, via_pri, via_gen, num_puerta, u)
            pu1 = make_rpu(id_buro, u, d1, 1, fecha1)
            pu2 = make_rpu(id_buro, u, d2, 1, fecha2)
            reportes.extend(rand_entidades(pu1, ent1))
            reportes.extend(rand_entidades(pu2, ent2))
            dic_complementos.append((u, id_buro, f"{n1} {v1}", n1, v1, random.randint(1, 30)))
            dic_complementos.append((u, id_buro, f"{n2} {v2}", n2, v2, random.randint(1, 30)))
            esperado.append((id_buro, escenario, 'SCORE', None))

        elif escenario.startswith('R3'):
            comp = ''  # R3 no usa complemento
            if 'ESC1' in escenario:
                via_gen2 = via_gen + random.choice([-1, 1])
                has_geo1 = 'SUB1' in escenario or 'SUB3' in escenario
                has_geo2 = 'SUB3' in escenario
                lat1 = round(4.5 + random.random() * 0.5, 6) if has_geo1 else None
                lon1 = round(-74.0 - random.random() * 0.2, 6) if has_geo1 else None
                lat2 = round(4.5 + random.random() * 0.5, 6) if has_geo2 else None
                lon2 = round(-74.0 - random.random() * 0.2, 6) if has_geo2 else None
                u1 = make_ubicacion(tipo_via, via_pri, via_gen, num_puerta, lat1, lon1)
                u2 = make_ubicacion(tipo_via, via_pri, via_gen2, num_puerta, lat2, lon2)
                d1 = make_df(comp, tipo_via, via_pri, via_gen, num_puerta, u1)
                d2 = make_df(comp, tipo_via, via_pri, via_gen2, num_puerta, u2)
            elif 'ESC2' in escenario or 'NO_UNIF' in escenario:
                if 'NO_UNIF' in escenario:
                    delta = random.choice([5, 10, 20])
                else:
                    delta = 2
                num_puerta2 = num_puerta + delta
                has_geo1 = 'SUB3' in escenario
                has_geo2 = 'SUB3' in escenario
                lat1 = round(4.5 + random.random() * 0.5, 6) if has_geo1 else None
                lon1 = round(-74.0 - random.random() * 0.2, 6) if has_geo1 else None
                lat2 = lat1
                lon2 = lon1
                u1 = make_ubicacion(tipo_via, via_pri, via_gen, num_puerta, lat1, lon1)
                u2 = make_ubicacion(tipo_via, via_pri, via_gen, num_puerta2, lat2, lon2)
                d1 = make_df(comp, tipo_via, via_pri, via_gen, num_puerta, u1)
                d2 = make_df(comp, tipo_via, via_pri, via_gen, num_puerta2, u2)
            pu1 = make_rpu(id_buro, u1, d1, 1, fecha1)
            pu2 = make_rpu(id_buro, u2, d2, 1, fecha2)
            reportes.extend(rand_entidades(pu1, ent1))
            reportes.extend(rand_entidades(pu2, ent2))
            tipo_esp = 'SIN_CAMBIO' if 'NO_UNIF' in escenario else 'PADRE_GEO'
            esperado.append((id_buro, escenario, tipo_esp, None))

# Escribir CSVs
OUT = 'ws-unificacion/data/synthetic/'

def write_csv(filename, headers, rows):
    with open(OUT + filename, 'w', newline='') as f:
        w = csv.writer(f, delimiter='|')
        w.writerow(headers)
        w.writerows(rows)
    print(f"  {filename}: {len(rows)} filas")

import os
os.makedirs(OUT, exist_ok=True)

write_csv('UBICACION_ESTANDARIZADA.csv',
    ['Cod_DW_Ubic','Texto_Ubicacion','Cod_DW_Ciudad','Cod_DW_Tipo_Ubicacion','Latitud','Longitud'],
    ubicaciones)

write_csv('DIRECCION_FISICA.csv',
    ['Cod_DW_Direccion_Fisica','Complemento','Tipo_Via_Principal','Via_Principal','Via_Generadora','Numero_Puerta','Cod_DW_Ubic','Generada_Enriquecida'],
    direcciones)

write_csv('RELACION_PERSONA_UBICACION.csv',
    ['Cod_DW_Persona_Ubic','Id_Buro_Persona','Cod_Pin_Persona','Cod_DW_Ubic','Cod_DW_Direccion_Fisica','Cod_DW_Tipo_Ubicacion_Dir','Ind_Unificacion','Orden_Prioridad','Fecha_Relacion_Persona_Ubicaci','Lote','Cod_Tipo_Ident_Fte'],
    relaciones)

write_csv('REPORTE_RELACION_PERSONA_UBICA.csv',
    ['Cod_DW_Persona_Ubic','Id_Buro_Suscriptor','Fecha_Reporte'],
    reportes)

write_csv('CIIU_PERSONA.csv',
    ['Id_Buro_Persona','Cod_Act_Econo_Ciiu_Fte'],
    ciiu_personas)

write_csv('DICCIONARIO_COMPLEMENTOS.csv',
    ['Cod_DW_Ubic','Id_Buro_Persona','Nomenclatura','Nomen','Valor','Frecuencia'],
    dic_complementos)

write_csv('ESPERADO.csv',
    ['Id_Buro_Persona','Escenario','Tipo_Resultado','Cod_DW_Persona_Ubic_Padre'],
    esperado)

# Nomenclatura (catálogo fijo)
write_csv('NOMENCLATURA.csv',
    ['Nomenclatura','Nivel_Complemento'],
    [('BR',1),('UR',1),('CJ',1),('ED',2),('ZN',2),('MZ',3),('ET',3),('TO',4),('BQ',4),('PI',5),('CS',5),('LC',6),('OF',6),('AP',7),('IN',7)])

write_csv('TIPO_UBICACION_DIR.csv',
    ['Cod_DW_Tipo_Ubicacion_Dir','Descripcion_Tipo_Ubicacion_Dir'],
    [(1,'RES'),(2,'LAB'),(5,'CRR')])

# Resumen
print(f"\nTotal: {id_buro - 10000} personas, {len(relaciones)} relaciones, {len(reportes)} reportes")
print(f"Distribución:")
for k, v in DIST.items():
    print(f"  {k}: {v}")
