/**
 * Smoke Tests — Validación Estructural
 *
 * Verifica requisitos estructurales y de código de los scripts SQL migrados:
 * 1. Sin SQL dinámico (EXECUTE, SP_EXECSTRING)
 * 2. Sin parámetros de BD de Teradata (P_BDDATOS, P_BDVISTA, P_BDSTAGE)
 * 3. Estructura de directorios correcta
 * 4. Encabezados estándar presentes en cada .sql
 * 5. Idempotencia (DROP TABLE IF EXISTS antes de cada CREATE TABLE)
 * 6. Archivos esperados existen según el documento de diseño
 *
 * Feature: migracion-ordenamiento-242
 * Requerimientos: 16.1, 16.2, 17.1, 17.2, 17.7, 20.1, 20.2, 20.3
 */

import { describe, it, expect, beforeAll } from 'vitest';
import { readFileSync, readdirSync, existsSync, statSync } from 'fs';
import { join, resolve, relative } from 'path';

// ============================================================
// Configuration
// ============================================================

const BASE_PATH = resolve(import.meta.dirname, '../../src/redshift');

const EXPECTED_DIRS = [
  'fase1_materializacion',
  'fase2_atributos_cuenta',
  'fase3_ubicaciones',
  'shared',
  '_disabled',
];

/**
 * Expected SQL files per the design document structure.
 * Each entry maps a directory to its expected files.
 */
const EXPECTED_FILES = {
  fase1_materializacion: [
    '01_materializa_btt.sql',
    '02_materializa_rec.sql',
    '03_unifica_btt_rec.sql',
    '04_limpieza_validacion.sql',
  ],
  fase2_atributos_cuenta: [
    '01_cta_atributos.sql',
    '02_cta_totales_personas.sql',
    '03_cta_totales_personas_1.sql',
    '04_cta_totales_personas_2.sql',
    '05_concat_atributos.sql',
  ],
  fase3_ubicaciones: [
    '01_ubic_direcciones.sql',
    '02_calc_ubicaciones.sql',
    '03_calc_ubicaciones_1.sql',
    '04_calc_ubicaciones_2.sql',
    '05_concat_direcciones.sql',
    '06_final_ubic_direcciones.sql',
  ],
  shared: [
    '00_schemas_tablas_control.sql',
    '01_log_ejecucion.sql',
  ],
  _disabled: [
    'final_cta_atributos_disabled.sql',
    'final_ubic_direcciones_v0_disabled.sql',
  ],
};

// Patterns that indicate dynamic SQL (must NOT be present outside comments)
const DYNAMIC_SQL_PATTERNS = [
  /\bEXECUTE\b/i,
  /\bSP_EXECSTRING\b/i,
  /\bSP_EXECSTRING_DES\b/i,
];

// Patterns that indicate Teradata BD parameters (must NOT be present outside comments)
const BD_PARAM_PATTERNS = [
  /\bP_BDDATOS\b/,
  /\bP_BDVISTA\b/,
  /\bP_BDSTAGE\b/,
];

// Required header fields in each .sql file
const REQUIRED_HEADERS = [
  { pattern: /^-- SP Original:/m, label: 'SP Original' },
  { pattern: /^-- Fase:/m, label: 'Fase' },
  { pattern: /^-- Modo:/m, label: 'Modo' },
];

// ============================================================
// Helpers
// ============================================================

/**
 * Recursively collects all .sql files from a directory.
 */
function collectSqlFiles(dir) {
  const files = [];
  if (!existsSync(dir)) return files;

  const entries = readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...collectSqlFiles(fullPath));
    } else if (entry.name.endsWith('.sql')) {
      files.push(fullPath);
    }
  }
  return files;
}

/**
 * Strips single-line SQL comments from content.
 * Used to avoid false positives from commented-out Teradata code.
 */
function stripComments(content) {
  return content
    .split('\n')
    .filter((line) => !line.trim().startsWith('--'))
    .join('\n');
}

// ============================================================
// Test Data
// ============================================================

let allSqlFiles = [];
let activeSqlFiles = []; // Excludes _disabled/

beforeAll(() => {
  for (const dir of EXPECTED_DIRS) {
    const dirPath = join(BASE_PATH, dir);
    allSqlFiles.push(...collectSqlFiles(dirPath));
  }
  activeSqlFiles = allSqlFiles.filter(
    (f) => !f.includes('_disabled')
  );
});

// ============================================================
// 1. Smoke: Sin SQL Dinámico
// ============================================================

describe('Smoke: Sin SQL Dinámico', () => {
  /**
   * Validates: Requirement 16.1
   * No script should contain dynamic SQL patterns (EXECUTE, SP_EXECSTRING)
   * in non-comment lines.
   */

  it('should not contain EXECUTE or SP_EXECSTRING in any .sql file (excluding comments)', () => {
    const violations = [];

    for (const filePath of allSqlFiles) {
      const content = readFileSync(filePath, 'utf-8');
      const codeOnly = stripComments(content);

      for (const pattern of DYNAMIC_SQL_PATTERNS) {
        if (pattern.test(codeOnly)) {
          const relPath = relative(BASE_PATH, filePath);
          violations.push(`${relPath}: contains ${pattern.source}`);
        }
      }
    }

    expect(violations, `Dynamic SQL found:\n${violations.join('\n')}`).toHaveLength(0);
  });
});

// ============================================================
// 2. Smoke: Sin Parámetros de BD
// ============================================================

describe('Smoke: Sin Parámetros de BD', () => {
  /**
   * Validates: Requirement 16.2
   * No script should reference Teradata BD parameters (P_BDDATOS, P_BDVISTA,
   * P_BDSTAGE) in non-comment lines.
   */

  it('should not contain P_BDDATOS, P_BDVISTA, or P_BDSTAGE in any .sql file (excluding comments)', () => {
    const violations = [];

    for (const filePath of allSqlFiles) {
      const content = readFileSync(filePath, 'utf-8');
      const codeOnly = stripComments(content);

      for (const pattern of BD_PARAM_PATTERNS) {
        if (pattern.test(codeOnly)) {
          const relPath = relative(BASE_PATH, filePath);
          violations.push(`${relPath}: contains ${pattern.source}`);
        }
      }
    }

    expect(violations, `BD parameters found:\n${violations.join('\n')}`).toHaveLength(0);
  });
});

// ============================================================
// 3. Smoke: Estructura de Directorio
// ============================================================

describe('Smoke: Estructura de Directorio', () => {
  /**
   * Validates: Requirement 20.1
   * Verifies that the expected directory structure exists.
   */

  it.each(EXPECTED_DIRS)(
    'should have directory: %s',
    (dir) => {
      const dirPath = join(BASE_PATH, dir);
      expect(existsSync(dirPath), `Directory ${dir}/ should exist`).toBe(true);
      expect(statSync(dirPath).isDirectory(), `${dir} should be a directory`).toBe(true);
    }
  );
});

// ============================================================
// 4. Smoke: Encabezados Presentes
// ============================================================

describe('Smoke: Encabezados Presentes', () => {
  /**
   * Validates: Requirements 20.2, 20.3
   * Every .sql file must have a standard header with:
   * - "-- SP Original:" line
   * - "-- Fase:" line
   * - "-- Modo:" line
   */

  it('should have standard headers (SP Original, Fase, Modo) in every .sql file', () => {
    const violations = [];

    for (const filePath of allSqlFiles) {
      const content = readFileSync(filePath, 'utf-8');
      const relPath = relative(BASE_PATH, filePath);

      for (const { pattern, label } of REQUIRED_HEADERS) {
        if (!pattern.test(content)) {
          violations.push(`${relPath}: missing header "-- ${label}:"`);
        }
      }
    }

    expect(violations, `Missing headers:\n${violations.join('\n')}`).toHaveLength(0);
  });
});

// ============================================================
// 5. Smoke: Idempotencia
// ============================================================

describe('Smoke: Idempotencia', () => {
  /**
   * Validates: Requirement 17.7
   * Every CREATE TABLE statement (except CREATE TABLE IF NOT EXISTS) must be
   * preceded by a DROP TABLE IF EXISTS for the same table name.
   */

  it('should have DROP TABLE IF EXISTS before every CREATE TABLE in active scripts', () => {
    const violations = [];

    const createTableRegex = /CREATE\s+TABLE\s+(?!IF\s+NOT\s+EXISTS)(\w+\.\w+)/gi;
    const dropTableRegex = /DROP\s+TABLE\s+IF\s+EXISTS\s+(\w+\.\w+)/gi;

    for (const filePath of activeSqlFiles) {
      const content = readFileSync(filePath, 'utf-8');
      const relPath = relative(BASE_PATH, filePath);

      // Collect all DROP TABLE IF EXISTS table names
      const dropMatches = [...content.matchAll(dropTableRegex)];
      const droppedTables = new Set(dropMatches.map((m) => m[1].toLowerCase()));

      // Collect all CREATE TABLE table names (excluding CREATE TABLE IF NOT EXISTS)
      const createMatches = [...content.matchAll(createTableRegex)];

      for (const match of createMatches) {
        const tableName = match[1].toLowerCase();
        if (!droppedTables.has(tableName)) {
          violations.push(`${relPath}: CREATE TABLE ${match[1]} without preceding DROP TABLE IF EXISTS`);
        }
      }
    }

    expect(violations, `Idempotency violations:\n${violations.join('\n')}`).toHaveLength(0);
  });
});

// ============================================================
// 6. Smoke: Archivos Esperados
// ============================================================

describe('Smoke: Archivos Esperados', () => {
  /**
   * Validates: Requirements 20.1, 20.2
   * All expected .sql files must exist per the design document.
   */

  for (const [dir, files] of Object.entries(EXPECTED_FILES)) {
    describe(`${dir}/`, () => {
      it.each(files)(
        'should have file: %s',
        (fileName) => {
          const filePath = join(BASE_PATH, dir, fileName);
          expect(
            existsSync(filePath),
            `Expected file ${dir}/${fileName} does not exist`
          ).toBe(true);
        }
      );
    });
  }
});
