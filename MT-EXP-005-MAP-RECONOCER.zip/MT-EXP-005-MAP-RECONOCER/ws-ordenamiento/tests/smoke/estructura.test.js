/**
 * Smoke Tests — Validación Estructural
 *
 * Verifica requisitos estructurales y de código de los scripts SQL migrados:
 * - Ausencia de SQL dinámico (EXECUTE, SP_EXECSTRING)
 * - Ausencia de parámetros de BD de Teradata (P_BDDATOS, P_BDVISTA, P_BDSTAGE)
 * - Estructura de directorios correcta
 * - Encabezados estándar presentes en cada .sql
 * - Idempotencia (DROP TABLE IF EXISTS antes de cada CREATE TABLE)
 *
 * Feature: migracion-ordenamiento-242
 * Requerimientos: 16.1, 16.2, 17.1, 17.2, 17.7, 20.1, 20.2, 20.3
 */

import { describe, it, expect, beforeAll } from 'vitest';
import { readFileSync, readdirSync, existsSync, statSync } from 'fs';
import { join, resolve, relative } from 'path';

// ============================================================
// Configuration
// ============================================================

const BASE_PATH = resolve(import.meta.dirname, '../../src/redshift');

const EXPECTED_DIRS = [
  'fase1_materializacion',
  'fase2_atributos_cuenta',
  'fase3_ubicaciones',
  'shared',
  '_disabled',
];

// Patterns that indicate dynamic SQL (must NOT be present)
const DYNAMIC_SQL_PATTERNS = [
  /\bEXECUTE\b/i,
  /\bSP_EXECSTRING\b/i,
  /\bSP_EXECSTRING_DES\b/i,
];

// Patterns that indicate Teradata BD parameters (must NOT be present)
const BD_PARAM_PATTERNS = [
  /\bP_BDDATOS\b/,
  /\bP_BDVISTA\b/,
  /\bP_BDSTAGE\b/,
  /\bP_BTTVISTA\b/,
];

// Required header fields (each .sql must have these comment lines)
const REQUIRED_HEADERS = [
  /^-- Archivo:/m,
  /^-- SP Original:/m,
  /^-- Fase:/m,
];

// ============================================================
// Helpers
// ============================================================

/**
 * Recursively collects all .sql files from a directory.
 */
function collectSqlFiles(dir) {
  const files = [];
  if (!existsSync(dir)) return files;

  const entries = readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...collectSqlFiles(fullPath));
    } else if (entry.name.endsWith('.sql')) {
      files.push(fullPath);
    }
  }
  return files;
}

/**
 * Strips SQL comments from content for pattern matching.
 * Only strips single-line comments (-- ...) to avoid false positives
 * from commented-out code.
 */
function stripComments(content) {
  return content
    .split('\n')
    .filter((line) => !line.trim().startsWith('--'))
    .join('\n');
}

// ============================================================
// Test Data
// ============================================================

let allSqlFiles = [];
let activeSqlFiles = []; // Excludes _disabled/

beforeAll(() => {
  // Only collect SQL files from the expected subdirectories (part of Ordenamiento 242 spec)
  for (const dir of EXPECTED_DIRS) {
    const dirPath = join(BASE_PATH, dir);
    allSqlFiles.push(...collectSqlFiles(dirPath));
  }
  activeSqlFiles = allSqlFiles.filter(
    (f) => !f.includes('_disabled')
  );
});

// ============================================================
// Smoke: Estructura de Directorios
// ============================================================

describe('Smoke: Estructura de Directorios', () => {
  /**
   * Validates: Requirement 20.1
   * Verifies that the expected directory structure exists.
   */

  it('should have all expected directories (fase1/, fase2/, fase3/, shared/, _disabled/)', () => {
    for (const dir of EXPECTED_DIRS) {
      const dirPath = join(BASE_PATH, dir);
      expect(existsSync(dirPath), `Directory ${dir}/ should exist`).toBe(true);
      expect(statSync(dirPath).isDirectory(), `${dir} should be a directory`).toBe(true);
    }
  });

  it('should have SQL files in fase1_materializacion/', () => {
    const dir = join(BASE_PATH, 'fase1_materializacion');
    const sqlFiles = readdirSync(dir).filter((f) => f.endsWith('.sql'));
    expect(sqlFiles.length).toBeGreaterThanOrEqual(4);
  });

  it('should have SQL files in fase2_atributos_cuenta/', () => {
    const dir = join(BASE_PATH, 'fase2_atributos_cuenta');
    const sqlFiles = readdirSync(dir).filter((f) => f.endsWith('.sql'));
    expect(sqlFiles.length).toBeGreaterThanOrEqual(5);
  });

  it('should have SQL files in fase3_ubicaciones/', () => {
    const dir = join(BASE_PATH, 'fase3_ubicaciones');
    const sqlFiles = readdirSync(dir).filter((f) => f.endsWith('.sql'));
    expect(sqlFiles.length).toBeGreaterThanOrEqual(6);
  });

  it('should have SQL files in shared/', () => {
    const dir = join(BASE_PATH, 'shared');
    const sqlFiles = readdirSync(dir).filter((f) => f.endsWith('.sql'));
    expect(sqlFiles.length).toBeGreaterThanOrEqual(2);
  });

  it('should have SQL files in _disabled/', () => {
    const dir = join(BASE_PATH, '_disabled');
    const sqlFiles = readdirSync(dir).filter((f) => f.endsWith('.sql'));
    expect(sqlFiles.length).toBeGreaterThanOrEqual(2);
  });
});

// ============================================================
// Smoke: Ausencia de SQL Dinámico
// ============================================================

describe('Smoke: Ausencia de SQL Dinámico', () => {
  /**
   * Validates: Requirement 16.1
   * No script should contain dynamic SQL patterns (EXECUTE, SP_EXECSTRING).
   * These are Teradata-specific and must be eliminated in the migration.
   */

  it('should not contain EXECUTE, SP_EXECSTRING, or SP_EXECSTRING_DES in any SQL file', () => {
    const violations = [];

    for (const filePath of allSqlFiles) {
      const content = readFileSync(filePath, 'utf-8');
      const codeOnly = stripComments(content);

      for (const pattern of DYNAMIC_SQL_PATTERNS) {
        if (pattern.test(codeOnly)) {
          const relPath = relative(BASE_PATH, filePath);
          violations.push(`${relPath}: contains ${pattern.source}`);
        }
      }
    }

    expect(violations, `Dynamic SQL found:\n${violations.join('\n')}`).toHaveLength(0);
  });
});

// ============================================================
// Smoke: Ausencia de Parámetros de BD
// ============================================================

describe('Smoke: Ausencia de Parámetros de BD', () => {
  /**
   * Validates: Requirement 16.2
   * No script should reference Teradata BD parameters (P_BDDATOS, P_BDVISTA,
   * P_BDSTAGE, P_BTTVISTA). These are replaced by fixed schema names in Redshift.
   */

  it('should not contain P_BDDATOS, P_BDVISTA, P_BDSTAGE, or P_BTTVISTA in any SQL file', () => {
    const violations = [];

    for (const filePath of allSqlFiles) {
      const content = readFileSync(filePath, 'utf-8');
      const codeOnly = stripComments(content);

      for (const pattern of BD_PARAM_PATTERNS) {
        if (pattern.test(codeOnly)) {
          const relPath = relative(BASE_PATH, filePath);
          violations.push(`${relPath}: contains ${pattern.source}`);
        }
      }
    }

    expect(violations, `BD parameters found:\n${violations.join('\n')}`).toHaveLength(0);
  });
});

// ============================================================
// Smoke: Encabezados Estándar
// ============================================================

describe('Smoke: Encabezados Estándar', () => {
  /**
   * Validates: Requirements 17.1, 17.2, 20.2
   * Every .sql file must have a standard header with at minimum:
   * - "-- Archivo:" line
   * - "-- SP Original:" line
   * - "-- Fase:" line
   */

  it('should have standard headers (Archivo, SP Original, Fase) in every .sql file', () => {
    const violations = [];

    for (const filePath of allSqlFiles) {
      const content = readFileSync(filePath, 'utf-8');
      const relPath = relative(BASE_PATH, filePath);

      for (const headerPattern of REQUIRED_HEADERS) {
        if (!headerPattern.test(content)) {
          violations.push(`${relPath}: missing header ${headerPattern.source}`);
        }
      }
    }

    expect(violations, `Missing headers:\n${violations.join('\n')}`).toHaveLength(0);
  });
});

// ============================================================
// Smoke: Log de Ejecución en Scripts Activos
// ============================================================

describe('Smoke: Log de Ejecución en Scripts Activos', () => {
  /**
   * Validates: Requirements 17.7, 20.3
   * Every active (non-disabled, non-shared infrastructure) script must contain
   * an INSERT into rec_stage.log_ejecucion for traceability.
   */

  it('should have INSERT into log_ejecucion in every active fase script', () => {
    const violations = [];
    const logPattern = /INSERT\s+INTO\s+rec_stage\.log_ejecucion/i;

    // Only check fase scripts (not shared infrastructure or disabled)
    const faseFiles = activeSqlFiles.filter(
      (f) => f.includes('fase1_') || f.includes('fase2_') || f.includes('fase3_')
    );

    for (const filePath of faseFiles) {
      const content = readFileSync(filePath, 'utf-8');
      const relPath = relative(BASE_PATH, filePath);

      if (!logPattern.test(content)) {
        violations.push(`${relPath}: missing INSERT into log_ejecucion`);
      }
    }

    expect(violations, `Missing log_ejecucion:\n${violations.join('\n')}`).toHaveLength(0);
  });
});

// ============================================================
// Smoke: Idempotencia (DROP TABLE IF EXISTS antes de CREATE TABLE)
// ============================================================

describe('Smoke: Idempotencia', () => {
  /**
   * Validates: Requirement 17.7
   * Every CREATE TABLE statement (except CREATE TABLE IF NOT EXISTS) must be
   * preceded by a DROP TABLE IF EXISTS for the same table name.
   * This ensures scripts can be re-executed without errors.
   */

  it('should have DROP TABLE IF EXISTS before every CREATE TABLE in active scripts', () => {
    const violations = [];

    // Match CREATE TABLE statements (not CREATE TABLE IF NOT EXISTS, not CREATE SCHEMA)
    const createTableRegex = /CREATE\s+TABLE\s+(?!IF\s+NOT\s+EXISTS)(\w+\.\w+)/gi;
    const dropTableRegex = /DROP\s+TABLE\s+IF\s+EXISTS\s+(\w+\.\w+)/gi;

    for (const filePath of activeSqlFiles) {
      const content = readFileSync(filePath, 'utf-8');
      const relPath = relative(BASE_PATH, filePath);

      // Collect all CREATE TABLE table names
      const createMatches = [...content.matchAll(createTableRegex)];
      // Collect all DROP TABLE IF EXISTS table names
      const dropMatches = [...content.matchAll(dropTableRegex)];
      const droppedTables = new Set(dropMatches.map((m) => m[1].toLowerCase()));

      for (const match of createMatches) {
        const tableName = match[1].toLowerCase();
        if (!droppedTables.has(tableName)) {
          violations.push(`${relPath}: CREATE TABLE ${match[1]} without preceding DROP TABLE IF EXISTS`);
        }
      }
    }

    expect(violations, `Idempotency violations:\n${violations.join('\n')}`).toHaveLength(0);
  });
});
