/**
 * Property-Based Tests — Migración Ordenamiento 242
 *
 * Validates the core business logic properties of the Ordenamiento 242 migration
 * from Teradata to Amazon Redshift using fast-check.
 *
 * Feature: migracion-ordenamiento-242
 * Requerimientos: 18.1, 18.2, 18.3, 18.4
 */

import { describe, it, expect } from 'vitest';
import fc from 'fast-check';
import { createHash } from 'crypto';

// ============================================================
// Pure business logic functions extracted from SQL migration
// ============================================================

/**
 * Filters records by date, returning only those after the control date.
 * Implements the logic of PRO_ORD_MATERIALIZA_BTT / PRO_ORD_MATERIALIZA_REC.
 *
 * @param {Array<{id: number, fechaCarga: Date}>} records
 * @param {Date} fechaControl - Last ordering date
 * @returns {Array} Records with fechaCarga > fechaControl
 */
export function filterByDate(records, fechaControl) {
  return records.filter((r) => r.fechaCarga > fechaControl);
}

/**
 * Deduplicates pairs (cod_pin_persona, id_buro_persona) from multiple sources.
 * Implements the UNION ALL + SELECT DISTINCT logic of PRO_ORD_UNIF_BTT_REC.
 *
 * @param {Array<Array<{codPin: number, idBuro: number}>>} sources - Multiple source arrays
 * @returns {Array<{codPin: number, idBuro: number}>} Unique pairs
 */
export function deduplicatePairs(sources) {
  const seen = new Set();
  const result = [];
  for (const source of sources) {
    for (const pair of source) {
      const key = `${pair.codPin}|${pair.idBuro}`;
      if (!seen.has(key)) {
        seen.add(key);
        result.push(pair);
      }
    }
  }
  return result;
}

/**
 * Detects errors in previous steps by checking the execution log.
 * Implements the validation logic of PRO_ORD_UNIF_BTT_REC_2.
 *
 * @param {Array<{evento: string, timestamp: number, procedimiento: string}>} logEntries
 * @returns {number} 0 if no errors, 1 if errors detected after last INICIO
 */
export function detectPreviousErrors(logEntries) {
  // Find the last INICIO timestamp
  const inicioEntries = logEntries.filter((e) => e.evento === 'INICIO');
  if (inicioEntries.length === 0) return 0;

  const lastInicio = Math.max(...inicioEntries.map((e) => e.timestamp));

  // Check for ERROR entries after last INICIO
  const errorsAfterInicio = logEntries.filter(
    (e) => e.evento === 'ERROR' && e.timestamp >= lastInicio
  );

  return errorsAfterInicio.length > 0 ? 1 : 0;
}

/**
 * Calculates the 12-month temporal window for a given date.
 * Implements DATEADD(month, -12, fecha_novedad) from PRO_ORD_CTA_TOTALES_PERSONAS.
 *
 * @param {Date} fechaNovedad
 * @returns {{fechaInicio: Date, fechaFin: Date}}
 */
export function calculateTemporalWindow(fechaNovedad) {
  const fechaInicio = new Date(fechaNovedad);
  fechaInicio.setMonth(fechaInicio.getMonth() - 12);
  return {
    fechaInicio,
    fechaFin: new Date(fechaNovedad),
  };
}

/**
 * Classifies an account into a Portfolio category.
 * Implements the CASE WHEN logic from PRO_ORD_CTA_TOTALES_PERSONAS_2.
 *
 * @param {number} tipoCuenta - Account type (1-5)
 * @param {number} tipoObligacion - Obligation type (1-15)
 * @param {number} cuotasPactadas - Agreed installments
 * @param {string} garantia - Guarantee type
 * @param {number} codSuscriptor - Subscriber code
 * @returns {string} Portfolio classification
 */
export function classifyPortfolio(tipoCuenta, tipoObligacion, cuotasPactadas, garantia, codSuscriptor) {
  if (tipoCuenta === 1) {
    if ([1, 2, 3].includes(tipoObligacion)) return 'CO';
    if ([4, 5, 6].includes(tipoObligacion)) return 'RO';
    if ([7, 8].includes(tipoObligacion)) {
      return cuotasPactadas > 60 ? 'HP' : 'VE';
    }
    if ([9, 10].includes(tipoObligacion)) return 'IN';
    return 'OT';
  }
  if (tipoCuenta === 2) {
    if ([1, 2].includes(tipoObligacion)) return 'CC';
    if ([3, 4, 5].includes(tipoObligacion)) return 'AH';
    return 'CT';
  }
  if (tipoCuenta === 3) return 'CO';
  if (tipoCuenta === 4) return 'RO';
  return 'OT';
}

/**
 * Filters persons to only those in the authorized set (unifica_btt_reconocer),
 * excluding blocked and unified persons.
 * Implements the filtering logic from PRO_ORD_UBIC_DIRECCIONES / PRO_ORD_CALC_UBICACIONES_2.
 *
 * @param {Array<{codPin: number, idBuro: number}>} reportRecords - All report records
 * @param {Set<string>} authorizedSet - Set of "codPin|idBuro" keys from unifica_btt_reconocer
 * @param {Set<string>} blockedSet - Set of "codPin|idBuro" keys that are blocked
 * @param {Set<string>} unifiedSet - Set of "codPin|idBuro" keys that are unified (to exclude)
 * @returns {Array<{codPin: number, idBuro: number}>} Filtered records
 */
export function filterAuthorizedPersons(reportRecords, authorizedSet, blockedSet, unifiedSet) {
  return reportRecords.filter((r) => {
    const key = `${r.codPin}|${r.idBuro}`;
    return authorizedSet.has(key) && !blockedSet.has(key) && !unifiedSet.has(key);
  });
}

/**
 * Applies conditional aggregation based on Id_Flag_Desde.
 * flag=0 → MAX (most recent), flag=1 → MIN (oldest).
 * Implements the GROUP BY logic from PRO_ORD_UBIC_DIRECCIONES.
 *
 * @param {Array<{partitionKey: string, flag: number, value: number, fecha: number}>} records
 * @returns {Map<string, {maxValue: number, minValue: number, maxFecha: number, minFecha: number}>}
 */
export function aggregateByFlag(records) {
  const groups = new Map();

  for (const r of records) {
    if (!groups.has(r.partitionKey)) {
      groups.set(r.partitionKey, {
        flag0Values: [],
        flag0Fechas: [],
        flag1Values: [],
        flag1Fechas: [],
      });
    }
    const g = groups.get(r.partitionKey);
    if (r.flag === 0) {
      g.flag0Values.push(r.value);
      g.flag0Fechas.push(r.fecha);
    } else {
      g.flag1Values.push(r.value);
      g.flag1Fechas.push(r.fecha);
    }
  }

  const result = new Map();
  for (const [key, g] of groups) {
    result.set(key, {
      maxValue: g.flag0Values.length > 0 ? Math.max(...g.flag0Values) : null,
      maxFecha: g.flag0Fechas.length > 0 ? Math.max(...g.flag0Fechas) : null,
      minValue: g.flag1Values.length > 0 ? Math.min(...g.flag1Values) : null,
      minFecha: g.flag1Fechas.length > 0 ? Math.min(...g.flag1Fechas) : null,
    });
  }
  return result;
}

/**
 * Selects the correct date for a location based on business rules.
 * Implements the date selection logic from PRO_ORD_CALC_UBICACIONES.
 *
 * Rules:
 * - If vigente AND (principal/pasivo/codeudor) AND new → Fecha_Apertura
 * - If vigente AND existing → Fecha_Reporte
 * - If NOT vigente → MIN(Fecha_Nov, Fecha_Reporte)
 *
 * @param {{vigente: boolean, esNuevo: boolean, fechaApertura: number, fechaReporte: number, fechaNov: number}} location
 * @returns {number} Selected date
 */
export function selectLocationDate(location) {
  if (location.vigente) {
    if (location.esNuevo) {
      return location.fechaApertura;
    }
    return location.fechaReporte;
  }
  return Math.min(location.fechaNov, location.fechaReporte);
}

/**
 * Limits records per partition to a maximum of N using ROW_NUMBER logic.
 * Implements the QUALIFY ROW_NUMBER() OVER(...) <= 3 → subquery pattern.
 *
 * @param {Array<{partitionKey: string, priority: number, data: any}>} records
 * @param {number} maxPerPartition - Maximum records per partition (default 3)
 * @returns {Array} Filtered records (top N per partition by priority DESC)
 */
export function limitByRowNumber(records, maxPerPartition = 3) {
  // Group by partition
  const partitions = new Map();
  for (const r of records) {
    if (!partitions.has(r.partitionKey)) {
      partitions.set(r.partitionKey, []);
    }
    partitions.get(r.partitionKey).push(r);
  }

  const result = [];
  for (const [, group] of partitions) {
    // Sort by priority descending (higher priority first)
    group.sort((a, b) => b.priority - a.priority);
    // Take top N
    result.push(...group.slice(0, maxPerPartition));
  }
  return result;
}

/**
 * Computes MD5 hash of a string (deterministic, 32 hex chars).
 * Implements the MD5() native Redshift function replacing rec_vista.hash_md5().
 *
 * @param {string} input
 * @returns {string} 32-character hex MD5 hash
 */
export function computeMD5(input) {
  return createHash('md5').update(input, 'utf8').digest('hex');
}

/**
 * Detects new and modified records by comparing current vs existing hash sets.
 * Implements the LEFT JOIN WHERE IS NULL (new) and JOIN WHERE hash differs (modified)
 * logic from PRO_ORD_FINAL_UBIC_DIRECCIONES1.
 *
 * @param {Map<string, string>} currentHashes - Map of key → hash (current execution)
 * @param {Map<string, string>} existingHashes - Map of key → hash (existing in DB)
 * @returns {{newKeys: string[], modifiedKeys: string[], unchangedKeys: string[]}}
 */
export function detectChanges(currentHashes, existingHashes) {
  const newKeys = [];
  const modifiedKeys = [];
  const unchangedKeys = [];

  for (const [key, hash] of currentHashes) {
    if (!existingHashes.has(key)) {
      newKeys.push(key);
    } else if (existingHashes.get(key) !== hash) {
      modifiedKeys.push(key);
    } else {
      unchangedKeys.push(key);
    }
  }

  return { newKeys, modifiedKeys, unchangedKeys };
}

// ============================================================
// Property-Based Tests
// ============================================================

describe('Feature: migracion-ordenamiento-242', () => {

  // ============================================================
  // Property 1: Filtrado por fecha identifica correctamente lotes nuevos
  // ============================================================
  describe('Property 1: Filtrado por fecha identifica correctamente lotes nuevos', () => {
    /**
     * Validates: Requirements 1.1, 2.1, 7.1, 8.1
     *
     * For any set of records with varied dates and a given control date,
     * the materialization process SHALL return exclusively records whose
     * load date is after the control date, without omitting any valid record
     * or including any prior record.
     */
    it('should return only records after control date, no omissions or incorrect inclusions', () => {
      fc.assert(
        fc.property(
          // Generator: control date + array of records with random dates
          fc.date({ min: new Date(2020, 0, 1), max: new Date(2025, 11, 31) }),
          fc.array(
            fc.record({
              id: fc.integer({ min: 1, max: 1_000_000 }),
              fechaCarga: fc.date({ min: new Date(2020, 0, 1), max: new Date(2025, 11, 31) }),
            }),
            { minLength: 0, maxLength: 50 }
          ),
          (fechaControl, records) => {
            const result = filterByDate(records, fechaControl);

            // All returned records must be after control date
            for (const r of result) {
              expect(r.fechaCarga.getTime()).toBeGreaterThan(fechaControl.getTime());
            }

            // No valid record should be omitted
            const expectedCount = records.filter((r) => r.fechaCarga > fechaControl).length;
            expect(result.length).toBe(expectedCount);

            // No record at or before control date should be included
            for (const r of result) {
              expect(r.fechaCarga.getTime()).not.toBeLessThanOrEqual(fechaControl.getTime());
            }
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  // ============================================================
  // Property 2: Deduplicación produce conjunto único
  // ============================================================
  describe('Property 2: Deduplicación produce conjunto único', () => {
    /**
     * Validates: Requirements 3.1, 3.3
     *
     * For any set of pairs (cod_pin_persona, id_buro_persona) from multiple
     * source tables with intentional duplicates, the UNIFICA_BTT_RECONOCER table
     * SHALL contain exactly the set of unique pairs (no duplicates) and no pair
     * that did not exist in at least one source table.
     */
    it('should produce unique pairs with COUNT = COUNT DISTINCT, no absent or invented pairs', () => {
      fc.assert(
        fc.property(
          // Generator: multiple sources with intentional duplicates
          fc.array(
            fc.array(
              fc.record({
                codPin: fc.integer({ min: 100_000, max: 200_000 }),
                idBuro: fc.integer({ min: 200_000, max: 300_000 }),
              }),
              { minLength: 0, maxLength: 20 }
            ),
            { minLength: 1, maxLength: 14 } // Up to 14 source tables like in the real process
          ),
          (sources) => {
            const result = deduplicatePairs(sources);

            // COUNT = COUNT DISTINCT (no duplicates in result)
            const resultKeys = result.map((r) => `${r.codPin}|${r.idBuro}`);
            const uniqueKeys = new Set(resultKeys);
            expect(resultKeys.length).toBe(uniqueKeys.size);

            // No pair absent: every unique pair from sources must be in result
            const allSourceKeys = new Set();
            for (const source of sources) {
              for (const pair of source) {
                allSourceKeys.add(`${pair.codPin}|${pair.idBuro}`);
              }
            }
            for (const key of allSourceKeys) {
              expect(uniqueKeys.has(key)).toBe(true);
            }

            // No invented pair: every result pair must exist in at least one source
            for (const key of uniqueKeys) {
              expect(allSourceKeys.has(key)).toBe(true);
            }
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  // ============================================================
  // Property 3: Detección de errores previos detiene ejecución
  // ============================================================
  describe('Property 3: Detección de errores previos detiene ejecución', () => {
    /**
     * Validates: Requirements 4.2, 22.2
     *
     * For any execution log state that contains at least one ERROR record
     * after the last INICIO of the current process, the validation SHALL
     * detect the error and signal a non-zero return code.
     */
    it('should return non-zero when ERROR exists after last INICIO', () => {
      fc.assert(
        fc.property(
          // Generator: log entries with varied events and timestamps
          fc.array(
            fc.record({
              evento: fc.constantFrom('INICIO', 'FIN', 'ERROR'),
              timestamp: fc.integer({ min: 1_000_000, max: 9_000_000 }),
              procedimiento: fc.constantFrom(
                'materializa_btt',
                'materializa_rec',
                'unifica_btt_rec',
                'limpieza_validacion'
              ),
            }),
            { minLength: 1, maxLength: 30 }
          ),
          (logEntries) => {
            const result = detectPreviousErrors(logEntries);

            // Find last INICIO
            const inicioEntries = logEntries.filter((e) => e.evento === 'INICIO');
            if (inicioEntries.length === 0) {
              // No INICIO → no error detection possible
              expect(result).toBe(0);
              return;
            }

            const lastInicio = Math.max(...inicioEntries.map((e) => e.timestamp));

            // Check if there's an ERROR after last INICIO
            const hasErrorAfterInicio = logEntries.some(
              (e) => e.evento === 'ERROR' && e.timestamp >= lastInicio
            );

            if (hasErrorAfterInicio) {
              expect(result).not.toBe(0);
            } else {
              expect(result).toBe(0);
            }
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  // ============================================================
  // Property 4: Ventana temporal de 12 meses es correcta
  // ============================================================
  describe('Property 4: Ventana temporal de 12 meses es correcta', () => {
    /**
     * Validates: Requirement 6.1
     *
     * For any valid novelty date, the temporal window calculation SHALL produce
     * a fecha_inicio exactly 12 months before fecha_novedad, and fecha_fin equal
     * to fecha_novedad, without overflow or truncation.
     */
    it('should produce fecha_inicio = DATEADD(month, -12, fecha_novedad) and fecha_fin = fecha_novedad', () => {
      fc.assert(
        fc.property(
          fc.date({ min: new Date(2015, 0, 1), max: new Date(2025, 11, 31) }),
          (fechaNovedad) => {
            const { fechaInicio, fechaFin } = calculateTemporalWindow(fechaNovedad);

            // fecha_fin must equal fecha_novedad
            expect(fechaFin.getTime()).toBe(fechaNovedad.getTime());

            // fecha_inicio must be exactly 12 months before
            const expected = new Date(fechaNovedad);
            expected.setMonth(expected.getMonth() - 12);
            expect(fechaInicio.getTime()).toBe(expected.getTime());

            // fecha_inicio must be before fecha_fin
            expect(fechaInicio.getTime()).toBeLessThanOrEqual(fechaFin.getTime());
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  // ============================================================
  // Property 5: Clasificación de Portafolio es determinista y completa
  // ============================================================
  describe('Property 5: Clasificación de Portafolio es determinista y completa', () => {
    /**
     * Validates: Requirement 8.2
     *
     * For any valid combination of account attributes, the classification SHALL
     * assign exactly one Portfolio value from {CO,RO,VE,HP,IN,OT,CC,AH,CT},
     * deterministically (same input → same output).
     */
    it('should always produce a valid portfolio and be deterministic', () => {
      const VALID_PORTFOLIOS = new Set(['CO', 'RO', 'VE', 'HP', 'IN', 'OT', 'CC', 'AH', 'CT']);

      fc.assert(
        fc.property(
          fc.integer({ min: 1, max: 5 }),           // tipoCuenta
          fc.integer({ min: 1, max: 15 }),          // tipoObligacion
          fc.integer({ min: 0, max: 120 }),         // cuotasPactadas
          fc.constantFrom('HIP', 'PRE', 'FID', 'PIG', 'SIN', 'OTR', 'AVA', 'CED'), // garantia
          fc.integer({ min: 100_000, max: 500_000 }), // codSuscriptor
          (tipoCuenta, tipoObligacion, cuotasPactadas, garantia, codSuscriptor) => {
            const result1 = classifyPortfolio(tipoCuenta, tipoObligacion, cuotasPactadas, garantia, codSuscriptor);
            const result2 = classifyPortfolio(tipoCuenta, tipoObligacion, cuotasPactadas, garantia, codSuscriptor);

            // Result must be in the valid set
            expect(VALID_PORTFOLIOS.has(result1)).toBe(true);

            // Determinism: same input → same output
            expect(result1).toBe(result2);
          }
        ),
        { numRuns: 100 }
      );
    });
  });


  // ============================================================
  // Property 6: Filtrado de personas preserva solo el conjunto autorizado
  // ============================================================
  describe('Property 6: Filtrado de personas preserva solo el conjunto autorizado', () => {
    /**
     * Validates: Requirements 9.1, 11.1, 12.2
     *
     * For any report table and unified table, the result SHALL contain exclusively
     * records of persons present in UNIFICA_BTT_RECONOCER, and SHALL exclude all
     * records marked as blocked or unified.
     */
    it('should include only authorized persons, excluding blocked and unified', () => {
      fc.assert(
        fc.property(
          // Generator: report records
          fc.array(
            fc.record({
              codPin: fc.integer({ min: 100_000, max: 110_000 }),
              idBuro: fc.integer({ min: 200_000, max: 210_000 }),
            }),
            { minLength: 1, maxLength: 40 }
          ),
          // Generator: authorized persons (subset)
          fc.array(
            fc.record({
              codPin: fc.integer({ min: 100_000, max: 110_000 }),
              idBuro: fc.integer({ min: 200_000, max: 210_000 }),
            }),
            { minLength: 0, maxLength: 20 }
          ),
          // Generator: blocked persons (subset)
          fc.array(
            fc.record({
              codPin: fc.integer({ min: 100_000, max: 110_000 }),
              idBuro: fc.integer({ min: 200_000, max: 210_000 }),
            }),
            { minLength: 0, maxLength: 5 }
          ),
          // Generator: unified persons (subset)
          fc.array(
            fc.record({
              codPin: fc.integer({ min: 100_000, max: 110_000 }),
              idBuro: fc.integer({ min: 200_000, max: 210_000 }),
            }),
            { minLength: 0, maxLength: 5 }
          ),
          (reportRecords, authorizedPersons, blockedPersons, unifiedPersons) => {
            const authorizedSet = new Set(authorizedPersons.map((p) => `${p.codPin}|${p.idBuro}`));
            const blockedSet = new Set(blockedPersons.map((p) => `${p.codPin}|${p.idBuro}`));
            const unifiedSet = new Set(unifiedPersons.map((p) => `${p.codPin}|${p.idBuro}`));

            const result = filterAuthorizedPersons(reportRecords, authorizedSet, blockedSet, unifiedSet);

            // All results must be in authorized set
            for (const r of result) {
              const key = `${r.codPin}|${r.idBuro}`;
              expect(authorizedSet.has(key)).toBe(true);
            }

            // No blocked person in result
            for (const r of result) {
              const key = `${r.codPin}|${r.idBuro}`;
              expect(blockedSet.has(key)).toBe(false);
            }

            // No unified person in result
            for (const r of result) {
              const key = `${r.codPin}|${r.idBuro}`;
              expect(unifiedSet.has(key)).toBe(false);
            }

            // No valid person omitted: every report record that is authorized, not blocked, not unified must be in result
            const expectedResult = reportRecords.filter((r) => {
              const key = `${r.codPin}|${r.idBuro}`;
              return authorizedSet.has(key) && !blockedSet.has(key) && !unifiedSet.has(key);
            });
            expect(result.length).toBe(expectedResult.length);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  // ============================================================
  // Property 7: Agregación condicional por flag aplica función correcta
  // ============================================================
  describe('Property 7: Agregación condicional por flag aplica función correcta', () => {
    /**
     * Validates: Requirement 9.2
     *
     * For any set of report records with Id_Flag_Desde (0 or 1), the aggregation
     * SHALL apply MAX for records with flag=0 (most recent) and MIN for records
     * with flag=1 (oldest), without mixing the functions.
     */
    it('should apply MAX when flag=0 and MIN when flag=1, no mixing', () => {
      fc.assert(
        fc.property(
          fc.array(
            fc.record({
              partitionKey: fc.stringOf(fc.constantFrom('A', 'B', 'C', 'D', 'E'), { minLength: 1, maxLength: 3 }),
              flag: fc.constantFrom(0, 1),
              value: fc.integer({ min: 1, max: 1_000_000 }),
              fecha: fc.integer({ min: 1_000_000, max: 9_000_000 }),
            }),
            { minLength: 1, maxLength: 40 }
          ),
          (records) => {
            const result = aggregateByFlag(records);

            // For each partition, verify aggregation correctness
            for (const [partitionKey, agg] of result) {
              const partitionRecords = records.filter((r) => r.partitionKey === partitionKey);
              const flag0Records = partitionRecords.filter((r) => r.flag === 0);
              const flag1Records = partitionRecords.filter((r) => r.flag === 1);

              // MAX for flag=0
              if (flag0Records.length > 0) {
                const expectedMaxValue = Math.max(...flag0Records.map((r) => r.value));
                const expectedMaxFecha = Math.max(...flag0Records.map((r) => r.fecha));
                expect(agg.maxValue).toBe(expectedMaxValue);
                expect(agg.maxFecha).toBe(expectedMaxFecha);
              } else {
                expect(agg.maxValue).toBeNull();
              }

              // MIN for flag=1
              if (flag1Records.length > 0) {
                const expectedMinValue = Math.min(...flag1Records.map((r) => r.value));
                const expectedMinFecha = Math.min(...flag1Records.map((r) => r.fecha));
                expect(agg.minValue).toBe(expectedMinValue);
                expect(agg.minFecha).toBe(expectedMinFecha);
              } else {
                expect(agg.minValue).toBeNull();
              }
            }
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  // ============================================================
  // Property 8: Reglas de fecha de ubicación seleccionan fecha correcta
  // ============================================================
  describe('Property 8: Reglas de fecha de ubicación seleccionan fecha correcta', () => {
    /**
     * Validates: Requirement 10.1
     *
     * For any location with a valid account, given its vigencia state and type,
     * the date rule SHALL select: Fecha_Apertura if vigente+new,
     * Fecha_Reporte if existing, MIN(Fecha_Nov, Fecha_Reporte) if not vigente.
     */
    it('should select date according to vigencia and newness rules', () => {
      fc.assert(
        fc.property(
          fc.record({
            vigente: fc.boolean(),
            esNuevo: fc.boolean(),
            fechaApertura: fc.integer({ min: 1_000_000, max: 9_000_000 }),
            fechaReporte: fc.integer({ min: 1_000_000, max: 9_000_000 }),
            fechaNov: fc.integer({ min: 1_000_000, max: 9_000_000 }),
          }),
          (location) => {
            const result = selectLocationDate(location);

            if (location.vigente) {
              if (location.esNuevo) {
                // Vigente + new → Fecha_Apertura
                expect(result).toBe(location.fechaApertura);
              } else {
                // Vigente + existing → Fecha_Reporte
                expect(result).toBe(location.fechaReporte);
              }
            } else {
              // Not vigente → MIN(Fecha_Nov, Fecha_Reporte)
              expect(result).toBe(Math.min(location.fechaNov, location.fechaReporte));
            }
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  // ============================================================
  // Property 9: Limitación por ROW_NUMBER respeta máximo por partición
  // ============================================================
  describe('Property 9: Limitación por ROW_NUMBER respeta máximo por partición', () => {
    /**
     * Validates: Requirement 10.2
     *
     * For any set of records grouped by partition key, the filtered result
     * SHALL contain at most 3 records per partition, and the selected records
     * SHALL be those with the highest priority.
     */
    it('should have COUNT per partition <= 3 and select highest priority records', () => {
      fc.assert(
        fc.property(
          fc.array(
            fc.record({
              partitionKey: fc.stringOf(fc.constantFrom('P1', 'P2', 'P3', 'P4', 'P5'), { minLength: 2, maxLength: 2 }),
              priority: fc.integer({ min: 1, max: 100 }),
              data: fc.string({ minLength: 1, maxLength: 10 }),
            }),
            { minLength: 1, maxLength: 60 }
          ),
          (records) => {
            const result = limitByRowNumber(records, 3);

            // Count per partition must be <= 3
            const partitionCounts = new Map();
            for (const r of result) {
              partitionCounts.set(r.partitionKey, (partitionCounts.get(r.partitionKey) || 0) + 1);
            }
            for (const [, count] of partitionCounts) {
              expect(count).toBeLessThanOrEqual(3);
            }

            // Selected records must be the highest priority ones
            const partitions = new Map();
            for (const r of records) {
              if (!partitions.has(r.partitionKey)) {
                partitions.set(r.partitionKey, []);
              }
              partitions.get(r.partitionKey).push(r);
            }

            for (const [partKey, group] of partitions) {
              const sorted = [...group].sort((a, b) => b.priority - a.priority);
              const expectedTop3 = sorted.slice(0, 3);
              const resultForPartition = result.filter((r) => r.partitionKey === partKey);

              // Same count as expected
              expect(resultForPartition.length).toBe(expectedTop3.length);

              // The priorities in result should match the top priorities
              const resultPriorities = resultForPartition.map((r) => r.priority).sort((a, b) => b - a);
              const expectedPriorities = expectedTop3.map((r) => r.priority).sort((a, b) => b - a);
              expect(resultPriorities).toEqual(expectedPriorities);
            }
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  // ============================================================
  // Property 10: Hash MD5 es determinista y de formato fijo
  // ============================================================
  describe('Property 10: Hash MD5 es determinista y de formato fijo', () => {
    /**
     * Validates: Requirements 13.1, 14.1
     *
     * For any input string (attribute concatenation), the MD5() function SHALL
     * always produce a hex string of exactly 32 characters, and the same input
     * SHALL always produce the same hash (determinism).
     */
    it('should produce LENGTH=32 and same input → same output', () => {
      fc.assert(
        fc.property(
          fc.string({ minLength: 0, maxLength: 500 }),
          (input) => {
            const hash1 = computeMD5(input);
            const hash2 = computeMD5(input);

            // Fixed length of 32 hex characters
            expect(hash1.length).toBe(32);

            // Only hex characters
            expect(/^[0-9a-f]{32}$/.test(hash1)).toBe(true);

            // Determinism: same input → same output
            expect(hash1).toBe(hash2);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  // ============================================================
  // Property 11: Detección de cambios identifica correctamente nuevos y modificados
  // ============================================================
  describe('Property 11: Detección de cambios identifica correctamente nuevos y modificados', () => {
    /**
     * Validates: Requirements 15.1, 15.3
     *
     * For any two sets of (key, hash) with partial overlap, the detection SHALL
     * classify as "new" every record whose key does not exist in the existing set,
     * as "modified" every record whose key exists but hash differs, and unchanged
     * records SHALL NOT be marked as new or modified.
     */
    it('should correctly identify new, modified, and unchanged records', () => {
      fc.assert(
        fc.property(
          // Generator: current hashes
          fc.array(
            fc.tuple(
              fc.string({ minLength: 1, maxLength: 20 }),
              fc.hexaString({ minLength: 32, maxLength: 32 })
            ),
            { minLength: 1, maxLength: 30 }
          ),
          // Generator: existing hashes
          fc.array(
            fc.tuple(
              fc.string({ minLength: 1, maxLength: 20 }),
              fc.hexaString({ minLength: 32, maxLength: 32 })
            ),
            { minLength: 0, maxLength: 30 }
          ),
          (currentEntries, existingEntries) => {
            const currentHashes = new Map(currentEntries);
            const existingHashes = new Map(existingEntries);

            const { newKeys, modifiedKeys, unchangedKeys } = detectChanges(currentHashes, existingHashes);

            // New: key in current but NOT in existing
            for (const key of newKeys) {
              expect(currentHashes.has(key)).toBe(true);
              expect(existingHashes.has(key)).toBe(false);
            }

            // Modified: key exists in both but hash differs
            for (const key of modifiedKeys) {
              expect(currentHashes.has(key)).toBe(true);
              expect(existingHashes.has(key)).toBe(true);
              expect(currentHashes.get(key)).not.toBe(existingHashes.get(key));
            }

            // Unchanged: key exists in both and hash is the same
            for (const key of unchangedKeys) {
              expect(currentHashes.has(key)).toBe(true);
              expect(existingHashes.has(key)).toBe(true);
              expect(currentHashes.get(key)).toBe(existingHashes.get(key));
            }

            // Completeness: all current keys must be classified
            const allClassified = new Set([...newKeys, ...modifiedKeys, ...unchangedKeys]);
            for (const key of currentHashes.keys()) {
              expect(allClassified.has(key)).toBe(true);
            }

            // No overlap between categories
            const newSet = new Set(newKeys);
            const modSet = new Set(modifiedKeys);
            const unchSet = new Set(unchangedKeys);
            for (const key of newKeys) {
              expect(modSet.has(key)).toBe(false);
              expect(unchSet.has(key)).toBe(false);
            }
            for (const key of modifiedKeys) {
              expect(newSet.has(key)).toBe(false);
              expect(unchSet.has(key)).toBe(false);
            }
          }
        ),
        { numRuns: 100 }
      );
    });
  });
});
