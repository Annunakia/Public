"""Parsea Caracteristicas.txt y clasifica las sentencias SQL por canal y fase."""
import csv, re, json
from collections import defaultdict

rows = []
with open('ws-ordenamiento/data/parametros/Caracteristicas.txt', 'r', encoding='utf-8') as f:
    reader = csv.reader(f, delimiter='|')
    header = next(reader)
    for row in reader:
        if len(row) >= 3:
            cod = row[0].strip()
            desc = row[1].strip()
            sql = row[2].replace('\r', '\n').strip()
            rows.append({'cod': cod, 'desc': desc, 'sql': sql})

# Clasificar por canal
canales = defaultdict(list)
for r in rows:
    cod = r['cod']
    if 'Tele' in cod: canal = 'TEL'
    elif 'Movil' in cod: canal = 'CEL'
    elif 'Mail' in cod: canal = 'EMA'
    elif 'Direc' in cod: canal = 'DIR'
    else: canal = 'OTRO'
    canales[canal].append(r)

# Clasificar por fase
fases = {'CREATE': 0, 'DROP': 0, 'COLLECT': 0, 'INSERT': 0, 'OTHER': 0}
caracteristicas = defaultdict(lambda: {'metricas': set(), 'categorias': set(), 'pesos': set(), 'score': set(), 'otros': set()})

for r in rows:
    sql_upper = r['sql'].upper()
    cod = r['cod']
    if 'Tele' in cod: canal = 'TEL'
    elif 'Movil' in cod: canal = 'CEL'
    elif 'Mail' in cod: canal = 'EMA'
    elif 'Direc' in cod: canal = 'DIR'
    else: canal = 'OTRO'

    # Extraer nombre de tabla/característica
    m = re.search(r'(CO\d+[A-Z]+\d+)', r['sql'])
    caract = m.group(1) if m else None

    if '_Peso' in r['sql'] or '_peso' in r['sql']:
        if caract: caracteristicas[canal]['pesos'].add(caract)
    elif '_cat' in r['sql']:
        if caract: caracteristicas[canal]['categorias'].add(caract)
    elif 'Score' in r['sql'] or 'SCORE' in r['sql'] or 'Sumatoria' in r['sql']:
        if caract: caracteristicas[canal]['score'].add(caract)
    elif caract and 'CREATE' in sql_upper:
        caracteristicas[canal]['metricas'].add(caract)

    if sql_upper.startswith('CREATE'): fases['CREATE'] += 1
    elif sql_upper.startswith('DROP'): fases['DROP'] += 1
    elif sql_upper.startswith('COLLECT'): fases['COLLECT'] += 1
    elif sql_upper.startswith('INSERT'): fases['INSERT'] += 1
    else: fases['OTHER'] += 1

# Extraer rangos de categorización y betas
cat_ranges = {}
for r in rows:
    m = re.search(r'(CO\d+[A-Z]+\d+)_cat', r['sql'])
    if m and 'CASE' in r['sql']:
        caract = m.group(1)
        # Extraer CASE WHEN
        cases = re.findall(r'WHEN\s+\w+\s*([<>=!]+)\s*([\d.]+)', r['sql'])
        max_cat = len(re.findall(r'THEN\s+(\d+)', r['sql']))
        cat_ranges[caract] = {'rangos': cases, 'max_cat': max_cat}

# Extraer fórmula de peso
peso_formulas = {}
for r in rows:
    m = re.search(r'(CO\d+[A-Z]+\d+)_Peso', r['sql'], re.IGNORECASE)
    if m and 'CAST' in r['sql']:
        caract = m.group(1)
        # Extraer divisor (max_cat)
        div = re.search(r'/(\d+)\)', r['sql'])
        peso_formulas[caract] = {'divisor': int(div.group(1)) if div else None}

# Output
print("=" * 60)
print(f"TOTAL: {len(rows)} sentencias SQL")
print(f"Tipos: {fases}")
print()
print("POR CANAL:")
for canal, items in sorted(canales.items()):
    print(f"  {canal}: {len(items)} sentencias")
print()

print("CARACTERÍSTICAS POR CANAL:")
for canal in ['TEL', 'CEL', 'EMA', 'DIR']:
    c = caracteristicas[canal]
    print(f"\n  {canal}:")
    print(f"    Métricas brutas: {sorted(c['metricas'])}")
    print(f"    Categorías (_cat): {sorted(c['categorias'])}")
    print(f"    Pesos (_Peso): {sorted(c['pesos'])}")

print(f"\nRANGOS DE CATEGORIZACIÓN ({len(cat_ranges)} características):")
for caract, info in sorted(cat_ranges.items()):
    print(f"  {caract}: max_cat={info['max_cat']}, rangos={info['rangos'][:4]}")

print(f"\nFÓRMULAS DE PESO ({len(peso_formulas)} características):")
for caract, info in sorted(peso_formulas.items()):
    print(f"  {caract}: (cat/{info['divisor']}) * Beta")

# Guardar resumen como MD
with open('ws-ordenamiento/docs/tecnico/analisis_caracteristicas.md', 'w') as f:
    f.write("# Análisis de Caracteristicas.txt — Modelo de Scoring\n\n")
    f.write(f"> Generado automáticamente. {len(rows)} sentencias SQL en 4 canales.\n\n---\n\n")
    f.write(f"## Resumen\n\n| Métrica | Valor |\n|---------|-------|\n")
    f.write(f"| Total sentencias | {len(rows)} |\n")
    for canal, items in sorted(canales.items()):
        f.write(f"| Canal {canal} | {len(items)} sentencias |\n")
    f.write(f"| CREATE | {fases['CREATE']} |\n| DROP | {fases['DROP']} |\n| COLLECT STATS | {fases['COLLECT']} |\n\n")

    f.write("## Características por Canal\n\n")
    for canal in ['TEL', 'CEL', 'EMA', 'DIR']:
        c = caracteristicas[canal]
        all_chars = sorted(c['metricas'] | c['categorias'] | c['pesos'])
        f.write(f"### {canal} ({len(all_chars)} características)\n\n")
        f.write("| Característica | Métrica | Categoría | Peso | Divisor | Rangos |\n")
        f.write("|---------------|---------|-----------|------|---------|--------|\n")
        for ch in all_chars:
            has_met = '✅' if ch in c['metricas'] else '—'
            has_cat = '✅' if ch in c['categorias'] else '—'
            has_peso = '✅' if ch in c['pesos'] else '—'
            div = peso_formulas.get(ch, {}).get('divisor', '?')
            rangos = cat_ranges.get(ch, {}).get('rangos', [])
            rng_str = ', '.join([f"{op}{v}" for op, v in rangos[:3]]) if rangos else '—'
            f.write(f"| {ch} | {has_met} | {has_cat} | {has_peso} | {div} | {rng_str} |\n")
        f.write("\n")

    f.write("## Fórmula de Score\n\n```\n")
    f.write("Score = Σ (categoría_i / max_categoría_i) × Beta_i\n")
    f.write("Lugar = ROW_NUMBER() OVER (PARTITION BY persona ORDER BY Score DESC)\n```\n\n")
    f.write("## Tablas de Coeficientes Beta\n\n")
    f.write("| Vista | Canal |\n|-------|-------|\n")
    f.write("| V_Beta_Ordenamiento_Tel | TEL |\n| V_Beta_Ordenamiento_Cel | CEL |\n")
    f.write("| V_Beta_Ordenamiento_Email | EMA |\n| V_Beta_Ordenamiento_Dir | DIR |\n")

print("\n✅ Análisis guardado en ws-ordenamiento/docs/tecnico/analisis_caracteristicas.md")
