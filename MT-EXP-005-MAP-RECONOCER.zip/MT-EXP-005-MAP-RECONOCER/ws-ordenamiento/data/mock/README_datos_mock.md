# Datos Mock — Ordenamiento (Scoring de Contactabilidad)

> 10 personas por canal, con valores diseñados para producir scores calculables.

---

## Coeficientes Beta (mock)

Valores ficticios pero realistas para calcular scores esperados.

### DIR (12 características)

| Cod_Caracteristica | Valor_Beta | Descripción |
|-------------------|------------|-------------|
| CO00DIR001IN | 0.15 | Meses desde primer reporte |
| CO00DIR004RO | 0.12 | Reportes recientes |
| CO00DIR007TO | 0.10 | Total reportes últimos meses |
| CO00DIR010FI | 0.08 | Sector financiero |
| CO00DIR013OT | 0.07 | % reportes otros sectores |
| CO00DIR017 | 0.10 | Tipo ubicación (RES/LAB/CRR) |
| CO00DIR019 | 0.05 | Indicador binario |
| CO00DIR034FI | 0.06 | Sector financiero detalle |
| CO00DIR050TO | 0.08 | Total reportes persona |
| CO00DIR057 | 0.09 | Conteo direcciones |
| CO00DIR059 | 0.05 | % reportes financieros |
| CO01DIR009 | 0.05 | Entidades que reportan |

### TEL, CEL, EMA — misma estructura, betas diferentes

(Se generan en el script de carga)

---

## Personas Mock — Canal DIR

| Persona | Id_Buro | Direcciones | Meses_reporte | Entidades | Tipo_Uso | Score esperado (aprox) |
|---------|---------|-------------|---------------|-----------|----------|----------------------|
| D01 | 20001 | 2 dirs | 36 meses | 5 | RES | Alto (muchos reportes, financiero) |
| D02 | 20001 | 2 dirs | 6 meses | 2 | LAB | Bajo (pocos reportes) |
| D03 | 20002 | 1 dir | 48 meses | 8 | RES | Muy alto |
| D04 | 20003 | 3 dirs | 12 meses | 3 | CRR | Medio |
| D05 | 20003 | 3 dirs | 3 meses | 1 | RES | Bajo |
| D06 | 20003 | 3 dirs | 24 meses | 4 | LAB | Medio-alto |

Resultado esperado: D01 > D02 (persona 20001), D03 sola (20002), D06 > D04 > D05 (persona 20003)
