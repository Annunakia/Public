#!/bin/bash
# ==============================================================================
# split_dataset.sh — Divide dataset_10k.sql en batches de máximo 80KB
# Usa Python para parsear sentencias completas (DDL + INSERT multi-línea).
# Genera: batches/batch_001.sql, batch_002.sql, etc.
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
DATASET="$SCRIPT_DIR/dataset_10k.sql"
BATCH_DIR="$SCRIPT_DIR/batches"
MAX_BATCH_SIZE=81920  # 80KB en bytes

if [[ ! -f "$DATASET" ]]; then
  echo "ERROR: No se encontró $DATASET"
  echo "Ejecute primero: python3 ws-ordenamiento/data/synthetic/generate.py"
  exit 1
fi

echo "=== Split Dataset ==="
echo "    Archivo: $DATASET"
echo "    Tamaño: $(du -h "$DATASET" | cut -f1)"
echo "    Max batch: 80KB"
echo ""

# Limpiar directorio de batches previos
rm -rf "$BATCH_DIR"
mkdir -p "$BATCH_DIR"

# ==============================================================================
# Usar Python para split inteligente por sentencias completas
# ==============================================================================
python3 -c "
import os, sys

dataset_path = '$DATASET'
batch_dir = '$BATCH_DIR'
max_size = $MAX_BATCH_SIZE

# Leer archivo completo
with open(dataset_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Dividir por ';' respetando strings
statements = []
current = []
in_quote = False
for i, ch in enumerate(content):
    if ch == \"'\" and not in_quote:
        in_quote = True
        current.append(ch)
    elif ch == \"'\" and in_quote:
        # Check for escaped quote ''
        if i + 1 < len(content) and content[i+1] == \"'\":
            current.append(ch)
        else:
            in_quote = False
            current.append(ch)
    elif ch == ';' and not in_quote:
        stmt = ''.join(current).strip()
        if stmt:
            statements.append(stmt + ';')
        current = []
    else:
        current.append(ch)

# Last statement without trailing ;
last = ''.join(current).strip()
if last:
    statements.append(last)

# Filter out pure comment statements
import re
filtered = []
for stmt in statements:
    clean = re.sub(r'--[^\n]*', '', stmt)
    clean = re.sub(r'/\*.*?\*/', '', clean, flags=re.DOTALL)
    if clean.strip().rstrip(';').strip():
        filtered.append(stmt)

print(f'    Sentencias SQL encontradas: {len(filtered)}')

# Generate batches
batch_num = 1
batch_content = ''
batch_count = 0
total_size = 0

for stmt in filtered:
    stmt_size = len(stmt.encode('utf-8'))
    
    # If adding this statement exceeds limit, close current batch
    if len(batch_content.encode('utf-8')) + stmt_size > max_size and batch_content:
        batch_file = os.path.join(batch_dir, f'batch_{batch_num:03d}.sql')
        with open(batch_file, 'w', encoding='utf-8') as f:
            f.write(batch_content)
        batch_size = len(batch_content.encode('utf-8'))
        total_size += batch_size
        batch_num += 1
        batch_content = ''
    
    # If a single statement exceeds max_size, put it alone in a batch
    if stmt_size > max_size:
        if batch_content:
            batch_file = os.path.join(batch_dir, f'batch_{batch_num:03d}.sql')
            with open(batch_file, 'w', encoding='utf-8') as f:
                f.write(batch_content)
            total_size += len(batch_content.encode('utf-8'))
            batch_num += 1
            batch_content = ''
        
        batch_file = os.path.join(batch_dir, f'batch_{batch_num:03d}.sql')
        with open(batch_file, 'w', encoding='utf-8') as f:
            f.write(stmt + '\n')
        total_size += stmt_size
        batch_num += 1
    else:
        batch_content += stmt + '\n\n'

# Write last batch
if batch_content.strip():
    batch_file = os.path.join(batch_dir, f'batch_{batch_num:03d}.sql')
    with open(batch_file, 'w', encoding='utf-8') as f:
        f.write(batch_content)
    total_size += len(batch_content.encode('utf-8'))

# Count actual batches
batch_files = sorted([f for f in os.listdir(batch_dir) if f.startswith('batch_')])
num_batches = len(batch_files)

# Stats
max_batch = 0
for bf in batch_files:
    size = os.path.getsize(os.path.join(batch_dir, bf))
    if size > max_batch:
        max_batch = size

avg_size = total_size // num_batches if num_batches > 0 else 0

print(f'')
print(f'=== Resultado ===')
print(f'    Batches generados: {num_batches}')
print(f'    Directorio: {batch_dir}/')
print(f'    Tamaño total: {total_size // 1024}KB')
print(f'    Tamaño promedio: {avg_size // 1024}KB por batch')
print(f'    Batch más grande: {max_batch // 1024}KB')

# Warn if any batch exceeds 95KB
for bf in batch_files:
    size = os.path.getsize(os.path.join(batch_dir, bf))
    if size > 97280:
        print(f'    WARN: {bf} excede 95KB ({size // 1024}KB)')

print(f'=== Split completado ===')
"

EXIT_CODE=$?
exit $EXIT_CODE
