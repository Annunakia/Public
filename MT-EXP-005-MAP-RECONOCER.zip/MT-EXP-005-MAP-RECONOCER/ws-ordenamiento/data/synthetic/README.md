# Dataset Sintético — Ordenamiento 242

## Descripción

Dataset sintético de **10,000 personas** generado para validar el flujo completo de migración del proceso Ordenamiento 242 (Teradata → Redshift). El dataset es **determinista** (seed=42) y reproduce distribuciones realistas del entorno de producción.

## Archivos

| Archivo | Descripción | Tamaño |
|---------|-------------|--------|
| `generate.py` | Script generador (Python 3, sin dependencias externas) | ~12 KB |
| `dataset_10k.sql` | SQL INSERT statements para Redshift | ~8.8 MB |
| `BETA_ORDENAMIENTO.csv` | Coeficientes Beta (legacy, del generador anterior) | ~2 KB |
| `INSUMO_*.csv` | Insumos por canal (legacy, del generador anterior) | Variable |

## Ejecución

```bash
python3 ws-ordenamiento/data/synthetic/generate.py
```

Genera `dataset_10k.sql` en el mismo directorio. No requiere dependencias externas.

## Distribución del Dataset

### Personas

| Métrica | Valor |
|---------|-------|
| Personas únicas | 10,000 |
| Duplicados intencionales | 500 (~5%) |
| Registros bloqueados | 300 (~3%) |
| Registros unificados | 200 (~2%) |
| Total en tabla raw (con duplicados) | 10,500 |

### Cuentas (VU_CUENTA)

| Métrica | Valor |
|---------|-------|
| Total cuentas | ~40,900 |
| Cuentas por persona | 1-15 (media ~4) |
| Distribución tipo_cuenta | 1: 35%, 2: 30%, 3: 15%, 4: 12%, 5: 8% |
| tipo_obligacion | 1-15 (uniforme) |
| cuotas_pactadas | 0-120 (uniforme) |
| estado_vigencia | A: 70%, I: 30% |
| Portafolios generados | CO, RO, VE, HP, IN, OT, CC, AH, CT |

### Ubicaciones (relacion_persona_ubicacion)

| Métrica | Valor |
|---------|-------|
| Total ubicaciones | ~31,700 |
| Ubicaciones por persona | 1-8 (media ~3) |
| id_flag_desde | 0: 75%, 1: 25% |
| id_flag_nuevo | 0: 67%, 1: 33% |
| Tipos ubicación | RES, LAB, CRR, REF, COB |
| Gestión registro | ACTIVA, INACTIVA, PENDIENTE, VERIFICADA |

### Distribución Geográfica (códigos DANE)

| Ciudad | DANE | Peso |
|--------|------|------|
| Bogotá | 11001 | 35% |
| Medellín | 5001 | 15% |
| Cali | 76001 | 12% |
| Barranquilla | 8001 | 8% |
| Cartagena | 13001 | 5% |
| Bucaramanga | 68001 | 4% |
| Otras (9 ciudades) | Varios | 21% |

Las coordenadas (latitud/longitud) se generan con variación aleatoria ±0.05° respecto al centro de cada ciudad.

### Metadata de Carga (Lotes)

| Métrica | Valor |
|---------|-------|
| Total lotes | 150 |
| Lotes post-control (nuevos) | ~60% |
| Lotes pre-control (históricos) | ~40% |
| Tablas fuente | V_CUENTA, V_BURO_PERSONA, V_COMPORTAMIENTO_CUENTA, etc. |
| Estados | EXITOSO (~75%), ERROR (~25%) |

### Hashes Pre-calculados

| Tabla | Registros | Uso |
|-------|-----------|-----|
| cuenta_atributo_hash | ~8,200 (~20% de cuentas) | Detección de cambios en atributos |
| ubicacion_atributo_hash | ~6,400 (~20% de ubicaciones) | Detección de cambios en direcciones |

Los hashes se calculan con MD5 sobre la concatenación de atributos separados por `|`.

## Estructura de Tablas Generadas

### rec_datos.control_ordenamiento
Tabla de control con la fecha del último ordenamiento (`2024-06-15`).

### rec_datos.metadata_carga_log
Lotes de carga con fechas variadas. Los tests de materialización filtran lotes con `fecha_carga > fecha_ult_ord`.

### rec_stage.personas_raw
Tabla con 10,500 registros (10,000 únicos + 500 duplicados). Los tests de deduplicación verifican que `SELECT DISTINCT` produce exactamente 10,000 registros.

### rec_datos.vu_cuenta
Cuentas con atributos completos. Incluye `portafolio` pre-calculado para validación de la clasificación CASE WHEN.

### rec_datos.relacion_persona_ubicacion
Ubicaciones con coordenadas, DANE, tipo, gestión y flags. Soporta tests de agregación condicional (MAX/MIN por flag) y ROW_NUMBER ≤ 3.

### rec_datos.v_bloqueo
300 personas bloqueadas. Los tests de filtrado verifican que estas personas se excluyen del resultado final.

### rec_datos.v_unificacion_direccion
200 personas unificadas (origen → destino). Los tests verifican exclusión de personas origen.

### rec_datos.cuenta_atributo_hash / ubicacion_atributo_hash
Hashes existentes para detección de cambios. Los tests de persistencia verifican:
- **Nuevos**: registros en datos actuales que NO están en la tabla de hash → INSERT
- **Modificados**: registros cuya clave existe pero hash difiere → UPDATE
- **Sin cambios**: registros con mismo hash → no se tocan

## Casos de Test Soportados

| Propiedad | Datos relevantes |
|-----------|-----------------|
| P1: Filtrado por fecha | metadata_carga_log con fechas antes/después de control |
| P2: Deduplicación | personas_raw con 500 duplicados intencionales |
| P3: Detección de errores | metadata_carga_log con estado ERROR |
| P5: Clasificación Portafolio | vu_cuenta con variedad de tipos y obligaciones |
| P6: Filtrado personas | v_bloqueo + v_unificacion_direccion |
| P7: Agregación por flag | relacion_persona_ubicacion con id_flag_desde 0/1 |
| P9: ROW_NUMBER ≤ 3 | Múltiples ubicaciones por persona (hasta 8) |
| P10: Hash MD5 | cuenta_atributo_hash + ubicacion_atributo_hash |
| P11: Detección de cambios | Hashes pre-calculados vs datos actuales |

## Reproducibilidad

El generador usa `random.seed(42)`. Ejecutar el script siempre produce el mismo archivo SQL byte a byte. Esto permite:
- Comparar resultados entre ejecuciones
- Pre-calcular valores esperados para assertions
- Debugging determinista de fallos

## Fecha de Control

La fecha de control es `2024-06-15`. Los tests de materialización deben:
- Incluir lotes con `fecha_carga > 2024-06-15` (nuevos)
- Excluir lotes con `fecha_carga <= 2024-06-15` (ya procesados)

## Carga en Redshift

```sql
-- Ejecutar directamente en Redshift
\i dataset_10k.sql

-- O desde psql:
psql -h cluster.region.redshift.amazonaws.com -U admin -d dbname -f dataset_10k.sql
```

El archivo es auto-contenido: crea schemas, tablas y carga datos. Es idempotente (usa DROP IF EXISTS).
