-- ============================================================
-- cleanup_test.sql — Limpieza post-prueba Ordenamiento 242
-- Idempotente: seguro ejecutar múltiples veces
-- PRESERVA: rec_datos.control_ordenamiento,
--           rec_datos.cuenta_atributo_hash,
--           rec_datos.ubicacion_atributo_hash,
--           rec_datos.metadata_carga_log,
--           rec_datos.vu_cuenta,
--           rec_datos.relacion_persona_ubicacion,
--           rec_datos.v_bloqueo,
--           rec_datos.v_unificacion_direccion
-- ============================================================

-- Fase 1: Tablas de materialización
DROP TABLE IF EXISTS rec_stage.estructuras_mtdat_bdm;
DROP TABLE IF EXISTS rec_stage.calcula_lote_btt;
DROP TABLE IF EXISTS rec_stage.paso_v_cuenta;
DROP TABLE IF EXISTS rec_stage.paso_v_buro_persona;
DROP TABLE IF EXISTS rec_stage.paso_v_comportamiento_cuenta;
DROP TABLE IF EXISTS rec_stage.paso_v_comport_cta_activo;
DROP TABLE IF EXISTS rec_stage.paso_v_comport_cta_pasivo;
DROP TABLE IF EXISTS rec_stage.calcula_lote_rec;
DROP TABLE IF EXISTS rec_stage.paso_reporte_ubic_original;
DROP TABLE IF EXISTS rec_stage.paso_rpu;
DROP TABLE IF EXISTS rec_stage.paso_rrpu;
DROP TABLE IF EXISTS rec_stage.paso_v_bloqueo;
DROP TABLE IF EXISTS rec_stage.paso_v_rela_ubic_estandar_geo;
DROP TABLE IF EXISTS rec_stage.paso_v_ubicacion_original;
DROP TABLE IF EXISTS rec_stage.paso_v_ubicacion_estandarizada;
DROP TABLE IF EXISTS rec_stage.paso_v_log_ubic_estandarizada;
DROP TABLE IF EXISTS rec_stage.paso_v_unificacion_direccion;
DROP TABLE IF EXISTS rec_stage.unifica_btt_reconocer;

-- Fase 2: Tablas de atributos de cuenta
DROP TABLE IF EXISTS rec_stage.cta_totales_personas_tmp1;
DROP TABLE IF EXISTS rec_stage.tmp_cnta_fechas;
DROP TABLE IF EXISTS rec_stage.stg_comportamiento_cta_activo;
DROP TABLE IF EXISTS rec_stage.tmp_comportamiento_pasivo;
DROP TABLE IF EXISTS rec_stage.cta_totales_personas_tmp2;
DROP TABLE IF EXISTS rec_stage.cta_totales_personas_tmp3;
DROP TABLE IF EXISTS rec_stage.concatena_atributos;

-- Fase 3: Tablas de ubicaciones
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal_mat;
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal1;
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal11;
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal2;
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal3;
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal6;
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal61;
DROP TABLE IF EXISTS rec_stage.vmo_reporte_relacion_pers_ubi;
DROP TABLE IF EXISTS rec_stage.vector_ubi_insumo_base;
DROP TABLE IF EXISTS rec_stage.datos_ubic_estandarizadas;
DROP TABLE IF EXISTS rec_stage.datos_tipo_persona;
DROP TABLE IF EXISTS rec_stage.datos_tipo_cuenta;
DROP TABLE IF EXISTS rec_stage.hash_carac_direc;

-- Log de ejecución (limpiar contenido, mantener tabla)
TRUNCATE TABLE rec_stage.log_ejecucion;

-- Dataset de entrada
DROP TABLE IF EXISTS rec_stage.personas_raw;
