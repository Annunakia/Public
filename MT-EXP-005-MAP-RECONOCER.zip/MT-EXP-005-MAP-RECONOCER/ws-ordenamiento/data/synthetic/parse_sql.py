#!/usr/bin/env python3
"""
parse_sql.py — Parsea un archivo SQL y extrae sentencias individuales.
Approach: elimina comentarios, luego divide por ';'.
Maneja strings con comillas simples correctamente.
Output: sentencias separadas por <<<STMT_SEPARATOR>>>
"""
import sys
import re

if len(sys.argv) < 2:
    print("Uso: parse_sql.py <archivo.sql>", file=sys.stderr)
    sys.exit(1)

sql_file = sys.argv[1]

with open(sql_file, 'r', encoding='utf-8') as f:
    content = f.read()

# Step 1: Remove block comments /* ... */
# Must handle nested-like patterns carefully
content_no_block = re.sub(r'/\*.*?\*/', '', content, flags=re.DOTALL)

# Step 2: Remove line comments -- ...
# But preserve strings! We need to be careful not to remove -- inside 'strings'
# Simple approach: process line by line, track if we're inside a string
lines = content_no_block.split('\n')
clean_lines = []
in_string = False

for line in lines:
    clean_chars = []
    i = 0
    while i < len(line):
        ch = line[i]
        if ch == "'" and not in_string:
            in_string = True
            clean_chars.append(ch)
            i += 1
        elif ch == "'" and in_string:
            if i + 1 < len(line) and line[i+1] == "'":
                clean_chars.append("''")
                i += 2
            else:
                in_string = False
                clean_chars.append(ch)
                i += 1
        elif line[i:i+2] == '--' and not in_string:
            # Rest of line is comment, skip
            break
        else:
            clean_chars.append(ch)
            i += 1
    clean_lines.append(''.join(clean_chars))

clean_content = '\n'.join(clean_lines)

# Step 3: Split by ';' respecting strings
statements = []
current = []
in_string = False

for i, ch in enumerate(clean_content):
    if ch == "'" and not in_string:
        in_string = True
        current.append(ch)
    elif ch == "'" and in_string:
        if i + 1 < len(clean_content) and clean_content[i+1] == "'":
            current.append("''")
        else:
            in_string = False
            current.append(ch)
    elif ch == ';' and not in_string:
        stmt = ''.join(current).strip()
        if stmt:
            statements.append(stmt)
        current = []
    else:
        current.append(ch)

# Last statement
last = ''.join(current).strip()
if last:
    statements.append(last)

# Filter empty
filtered = [s for s in statements if s.strip()]

# Output
DELIM = '<<<STMT_SEPARATOR>>>'
print(DELIM.join(filtered))
