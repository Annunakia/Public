#!/bin/bash
# ==============================================================================
# run_sql_file.sh — Ejecuta un archivo SQL completo contra Redshift
# Usa parse_sql.py para dividir sentencias, escribe a archivos temporales.
# Uso: ./run_sql_file.sh <archivo.sql> [--dry-run]
# Exit: 0=éxito, 1=error
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

SQL_FILE="$1"
DRY_RUN=0

if [[ "$2" == "--dry-run" ]]; then
  DRY_RUN=1
fi

if [[ -z "$SQL_FILE" ]]; then
  echo "Uso: $0 <archivo.sql> [--dry-run]"
  exit 1
fi

if [[ ! -f "$SQL_FILE" ]]; then
  echo "ERROR: Archivo no encontrado: $SQL_FILE"
  exit 1
fi

BASENAME=$(basename "$SQL_FILE" .sql)

echo "=== Ejecutando: $SQL_FILE ==="

# Parse statements using Python — writes individual files to temp dir
TEMP_DIR=$(mktemp -d)
trap "rm -rf $TEMP_DIR" EXIT

python3 -c "
import sys, os, re

sql_file = '$SQL_FILE'
temp_dir = '$TEMP_DIR'

with open(sql_file, 'r', encoding='utf-8') as f:
    content = f.read()

# Remove block comments
content_clean = re.sub(r'/\*.*?\*/', '', content, flags=re.DOTALL)

# Remove line comments (respecting strings)
lines = content_clean.split('\n')
clean_lines = []
in_string = False
for line in lines:
    clean_chars = []
    i = 0
    while i < len(line):
        ch = line[i]
        if ch == \"'\" and not in_string:
            in_string = True
            clean_chars.append(ch)
            i += 1
        elif ch == \"'\" and in_string:
            if i + 1 < len(line) and line[i+1] == \"'\":
                clean_chars.append(\"''\")
                i += 2
            else:
                in_string = False
                clean_chars.append(ch)
                i += 1
        elif line[i:i+2] == '--' and not in_string:
            break
        else:
            clean_chars.append(ch)
            i += 1
    clean_lines.append(''.join(clean_chars))

clean_content = '\n'.join(clean_lines)

# Split by ';' respecting strings
statements = []
current = []
in_string = False
i = 0
while i < len(clean_content):
    ch = clean_content[i]
    if ch == \"'\" and not in_string:
        in_string = True
        current.append(ch)
        i += 1
    elif ch == \"'\" and in_string:
        if i + 1 < len(clean_content) and clean_content[i+1] == \"'\":
            current.append(\"''\")
            i += 2
        else:
            in_string = False
            current.append(ch)
            i += 1
    elif ch == ';' and not in_string:
        stmt = ''.join(current).strip()
        if stmt:
            statements.append(stmt)
        current = []
        i += 1
    else:
        current.append(ch)
        i += 1

last = ''.join(current).strip()
if last:
    statements.append(last)

# Filter empty
filtered = [s for s in statements if s.strip()]

# Write count
with open(os.path.join(temp_dir, 'count.txt'), 'w') as f:
    f.write(str(len(filtered)))

# Write each statement to a numbered file
for i, stmt in enumerate(filtered):
    with open(os.path.join(temp_dir, f'stmt_{i+1:04d}.sql'), 'w') as f:
        f.write(stmt)
"

PARSE_EXIT=$?
if [[ $PARSE_EXIT -ne 0 ]]; then
  echo "ERROR parseando archivo"
  exit 1
fi

TOTAL=$(cat "$TEMP_DIR/count.txt")
echo "    Sentencias encontradas: $TOTAL"

if [[ "$TOTAL" == "0" ]]; then
  echo "WARN: No se encontraron sentencias SQL"
  exit 0
fi

if [[ $DRY_RUN -eq 1 ]]; then
  echo ""
  echo "=== DRY RUN ==="
  for f in $(ls "$TEMP_DIR"/stmt_*.sql | sort); do
    NUM=$(basename "$f" .sql | sed 's/stmt_//')
    STMT=$(head -c 200 "$f")
    echo "  [$NUM/$TOTAL] $STMT"
    echo ""
  done
  echo "=== Fin DRY RUN ==="
  exit 0
fi

# Execute each statement
for f in $(ls "$TEMP_DIR"/stmt_*.sql | sort); do
  NUM=$(basename "$f" .sql | sed 's/stmt_0*//')
  STMT=$(cat "$f")
  LABEL="${BASENAME}:${NUM}/${TOTAL}"

  OUTPUT=$("$SCRIPT_DIR/run_sql.sh" "$STMT" "$LABEL" 2>&1)
  EXIT_CODE=$?

  if [[ $EXIT_CODE -eq 0 ]]; then
    echo "$OUTPUT" | head -1
  else
    echo "$OUTPUT"
    echo ""
    echo "╔══════════════════════════════════════════════════════════════"
    echo "║ ERROR en sentencia $NUM de $TOTAL"
    echo "║ Archivo: $SQL_FILE"
    echo "║ SQL: ${STMT:0:200}"
    if [[ ${#STMT} -gt 200 ]]; then
      echo "║      ..."
    fi
    echo "╚══════════════════════════════════════════════════════════════"
    exit 1
  fi
done

echo "=== Completado: $SQL_FILE ($TOTAL sentencias) ==="
exit 0
