#!/bin/bash
# ==============================================================================
# validate_fase3.sh — Validaciones Checkpoint Fase 3 (Ubicaciones)
# Ejecuta queries de validación y reporta PASS/FAIL por cada una.
# Exit: número de errores (0 = todo OK)
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ERRORS=0

echo ""
echo "╔══════════════════════════════════════════════════════════════"
echo "║ CHECKPOINT FASE 3 — Ubicaciones / Direcciones"
echo "╚══════════════════════════════════════════════════════════════"
echo ""

# ==============================================================================
# V3.1: 0 NULL desc_tipo_persona en datos_tipo_cuenta
# ==============================================================================
echo -n "  V3.1 Sin NULL en desc_tipo_persona ... "
RESULT=$("$SCRIPT_DIR/run_sql.sh" \
  "SELECT COUNT(*) AS sin_tipo_persona FROM rec_stage.datos_tipo_cuenta WHERE desc_tipo_persona IS NULL;" \
  "V3.1_null_tipo" 2>&1)

if echo "$RESULT" | grep -q "FAILED\|ERROR ejecutando\|TIMEOUT"; then
  echo "FAIL (error ejecutando query)"
  echo "       $RESULT"
  ERRORS=$((ERRORS + 1))
else
  COUNT=$(echo "$RESULT" | grep -oP '\d+' | tail -1)
  if [[ "$COUNT" == "0" ]]; then
    echo "PASS (0 NULL)"
  else
    echo "FAIL ($COUNT filas con desc_tipo_persona NULL)"
    ERRORS=$((ERRORS + 1))
  fi
fi

# ==============================================================================
# V3.2: 0 hashes con LENGTH != 32 en hash_carac_direc
# ==============================================================================
echo -n "  V3.2 Hashes ubicación formato correcto (32 chars) ... "
RESULT=$("$SCRIPT_DIR/run_sql.sh" \
  "SELECT COUNT(*) AS hash_invalido FROM rec_stage.hash_carac_direc WHERE LENGTH(cod_hash) != 32;" \
  "V3.2_hash_len" 2>&1)

if echo "$RESULT" | grep -q "FAILED\|ERROR ejecutando\|TIMEOUT"; then
  echo "FAIL (error ejecutando query)"
  echo "       $RESULT"
  ERRORS=$((ERRORS + 1))
else
  COUNT=$(echo "$RESULT" | grep -oP '\d+' | tail -1)
  if [[ "$COUNT" == "0" ]]; then
    echo "PASS (todos 32 chars)"
  else
    echo "FAIL ($COUNT hashes con LENGTH != 32)"
    ERRORS=$((ERRORS + 1))
  fi
fi

# ==============================================================================
# V3.3: Nuevos registros insertados hoy en ubicacion_atributo_hash (> 0)
# ==============================================================================
echo -n "  V3.3 Nuevos registros insertados hoy ... "
RESULT=$("$SCRIPT_DIR/run_sql.sh" \
  "SELECT COUNT(*) AS nuevos_hoy FROM rec_datos.ubicacion_atributo_hash WHERE fecha_insercion = CURRENT_DATE;" \
  "V3.3_inserts" 2>&1)

if echo "$RESULT" | grep -q "FAILED\|ERROR ejecutando\|TIMEOUT"; then
  echo "FAIL (error ejecutando query)"
  echo "       $RESULT"
  ERRORS=$((ERRORS + 1))
else
  COUNT=$(echo "$RESULT" | grep -oP '\d+' | tail -1)
  if [[ -n "$COUNT" && "$COUNT" -gt 0 ]]; then
    echo "PASS ($COUNT nuevos registros)"
  else
    echo "FAIL (0 registros insertados hoy)"
    ERRORS=$((ERRORS + 1))
  fi
fi

# ==============================================================================
# V3.4: Registros actualizados hoy (> 0)
# ==============================================================================
echo -n "  V3.4 Registros actualizados hoy ... "
RESULT=$("$SCRIPT_DIR/run_sql.sh" \
  "SELECT COUNT(*) AS actualizados_hoy FROM rec_datos.ubicacion_atributo_hash WHERE fecha_actualizacion = CURRENT_DATE AND fecha_insercion < CURRENT_DATE;" \
  "V3.4_updates" 2>&1)

if echo "$RESULT" | grep -q "FAILED\|ERROR ejecutando\|TIMEOUT"; then
  echo "FAIL (error ejecutando query)"
  echo "       $RESULT"
  ERRORS=$((ERRORS + 1))
else
  COUNT=$(echo "$RESULT" | grep -oP '\d+' | tail -1)
  if [[ -n "$COUNT" && "$COUNT" -gt 0 ]]; then
    echo "PASS ($COUNT registros actualizados)"
  else
    echo "FAIL (0 registros actualizados hoy)"
    ERRORS=$((ERRORS + 1))
  fi
fi

# ==============================================================================
# V3.5: 0 errores en log para Fase 3
# ==============================================================================
echo -n "  V3.5 Sin errores en log para Fase 3 ... "
RESULT=$("$SCRIPT_DIR/run_sql.sh" \
  "SELECT COUNT(*) AS errores FROM rec_stage.log_ejecucion WHERE evento = 'ERROR' AND nombre_procedimiento IN ('ubic_direcciones', 'calc_ubicaciones', 'calc_ubicaciones_1', 'calc_ubicaciones_2', 'concat_direcciones', 'final_ubic_direcciones');" \
  "V3.5_errors" 2>&1)

if echo "$RESULT" | grep -q "FAILED\|ERROR ejecutando\|TIMEOUT"; then
  echo "FAIL (error ejecutando query)"
  echo "       $RESULT"
  ERRORS=$((ERRORS + 1))
else
  COUNT=$(echo "$RESULT" | grep -oP '\d+' | tail -1)
  if [[ "$COUNT" == "0" ]]; then
    echo "PASS (0 errores)"
  else
    echo "FAIL ($COUNT errores en log)"
    ERRORS=$((ERRORS + 1))
  fi
fi

# ==============================================================================
# Resumen
# ==============================================================================
echo ""
if [[ $ERRORS -eq 0 ]]; then
  echo "  ✅ CHECKPOINT FASE 3: PASSED (5/5 validaciones OK)"
else
  echo "  ❌ CHECKPOINT FASE 3: FAILED ($ERRORS errores)"
fi
echo ""

exit $ERRORS
