#!/bin/bash
# ==============================================================================
# validate_fase1.sh — Validaciones Checkpoint Fase 1 (Materialización)
# Ejecuta queries de validación y reporta PASS/FAIL por cada una.
# Exit: número de errores (0 = todo OK)
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ERRORS=0

echo ""
echo "╔══════════════════════════════════════════════════════════════"
echo "║ CHECKPOINT FASE 1 — Materialización + Unificación"
echo "╚══════════════════════════════════════════════════════════════"
echo ""

# ==============================================================================
# V1.1: COUNT unifica_btt_reconocer = 10,000
# ==============================================================================
echo -n "  V1.1 COUNT unifica_btt_reconocer = 10000 ... "
RESULT=$("$SCRIPT_DIR/run_sql.sh" \
  "SELECT COUNT(*) AS total FROM rec_stage.unifica_btt_reconocer;" \
  "V1.1_count" 2>&1)

if echo "$RESULT" | grep -q "FAILED\|ERROR\|TIMEOUT"; then
  echo "FAIL (error ejecutando query)"
  echo "       $RESULT"
  ERRORS=$((ERRORS + 1))
elif echo "$RESULT" | grep -q "10000"; then
  echo "PASS"
else
  ACTUAL=$(echo "$RESULT" | grep -oP '\d+' | tail -1)
  echo "FAIL (esperado: 10000, obtenido: ${ACTUAL:-desconocido})"
  ERRORS=$((ERRORS + 1))
fi

# ==============================================================================
# V1.2: COUNT DISTINCT = total (sin duplicados)
# ==============================================================================
echo -n "  V1.2 Sin duplicados (DISTINCT = total) ... "
RESULT=$("$SCRIPT_DIR/run_sql.sh" \
  "SELECT COUNT(*) AS total, COUNT(DISTINCT cod_pin_persona || '-' || CAST(id_buro_persona AS VARCHAR)) AS distintos FROM rec_stage.unifica_btt_reconocer;" \
  "V1.2_distinct" 2>&1)

if echo "$RESULT" | grep -q "FAILED\|ERROR\|TIMEOUT"; then
  echo "FAIL (error ejecutando query)"
  echo "       $RESULT"
  ERRORS=$((ERRORS + 1))
else
  # Extraer total y distintos de la salida
  TOTAL=$(echo "$RESULT" | grep -oP '\d+' | head -1)
  DISTINTOS=$(echo "$RESULT" | grep -oP '\d+' | tail -1)
  if [[ "$TOTAL" == "$DISTINTOS" && -n "$TOTAL" ]]; then
    echo "PASS (total=$TOTAL, distintos=$DISTINTOS)"
  else
    echo "FAIL (total=${TOTAL:-?}, distintos=${DISTINTOS:-?})"
    ERRORS=$((ERRORS + 1))
  fi
fi

# ==============================================================================
# V1.3: 0 errores en log_ejecucion
# ==============================================================================
echo -n "  V1.3 Sin errores en log_ejecucion ... "
RESULT=$("$SCRIPT_DIR/run_sql.sh" \
  "SELECT COUNT(*) AS errores FROM rec_stage.log_ejecucion WHERE evento = 'ERROR';" \
  "V1.3_errors" 2>&1)

if echo "$RESULT" | grep -q "FAILED\|ERROR ejecutando\|TIMEOUT"; then
  echo "FAIL (error ejecutando query)"
  echo "       $RESULT"
  ERRORS=$((ERRORS + 1))
elif echo "$RESULT" | grep -qP "^\s*0\s*$|\ 0\ |\|\ 0\ \||^0$"; then
  echo "PASS (0 errores)"
else
  ACTUAL=$(echo "$RESULT" | grep -oP '\d+' | tail -1)
  if [[ "$ACTUAL" == "0" ]]; then
    echo "PASS (0 errores)"
  else
    echo "FAIL (errores encontrados: ${ACTUAL:-desconocido})"
    ERRORS=$((ERRORS + 1))
  fi
fi

# ==============================================================================
# V1.4: Log tiene >= 4 registros de Fase 1
# ==============================================================================
echo -n "  V1.4 Log tiene >= 4 registros Fase 1 ... "
RESULT=$("$SCRIPT_DIR/run_sql.sh" \
  "SELECT COUNT(*) AS registros_log FROM rec_stage.log_ejecucion WHERE fase = 'Fase 1';" \
  "V1.4_log_count" 2>&1)

if echo "$RESULT" | grep -q "FAILED\|ERROR\|TIMEOUT"; then
  echo "FAIL (error ejecutando query)"
  echo "       $RESULT"
  ERRORS=$((ERRORS + 1))
else
  COUNT=$(echo "$RESULT" | grep -oP '\d+' | tail -1)
  if [[ -n "$COUNT" && "$COUNT" -ge 4 ]]; then
    echo "PASS ($COUNT registros)"
  else
    echo "FAIL (esperado >= 4, obtenido: ${COUNT:-0})"
    ERRORS=$((ERRORS + 1))
  fi
fi

# ==============================================================================
# Resumen
# ==============================================================================
echo ""
if [[ $ERRORS -eq 0 ]]; then
  echo "  ✅ CHECKPOINT FASE 1: PASSED (4/4 validaciones OK)"
else
  echo "  ❌ CHECKPOINT FASE 1: FAILED ($ERRORS errores)"
fi
echo ""

exit $ERRORS
