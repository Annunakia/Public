#!/bin/bash
# ==============================================================================
# run_sql.sh — Ejecuta una sentencia SQL individual contra Redshift via Data API
# Uso: ./run_sql.sh "SQL_STATEMENT" [label]
# Exit: 0=éxito, 1=error/timeout
# ==============================================================================

PROFILE="sandbox"
REGION="us-east-1"
WORKGROUP="experian-sandbox-trunk-ddm-xpm-workgroup"
DB="dev"

SQL="$1"
LABEL="${2:-query}"

if [[ -z "$SQL" ]]; then
  echo "Uso: $0 \"SQL_STATEMENT\" [label]"
  exit 1
fi

# Ejecutar sentencia
ID=$(aws redshift-data execute-statement \
  --workgroup-name "$WORKGROUP" --database "$DB" \
  --sql "$SQL" --profile "$PROFILE" --region "$REGION" \
  --query 'Id' --output text 2>&1)

if [[ "$ID" == *"ERROR"* || "$ID" == *"error"* ]]; then
  echo "[$LABEL] ERROR ejecutando: $ID"
  exit 1
fi

# Polling cada 3s, timeout 180s (60 iteraciones × 3s)
for i in $(seq 1 60); do
  STATUS=$(aws redshift-data describe-statement --id "$ID" \
    --profile "$PROFILE" --region "$REGION" \
    --query 'Status' --output text 2>/dev/null)

  if [[ "$STATUS" == "FINISHED" ]]; then
    echo "[$LABEL] OK"
    # Imprimir resultados si hay filas
    aws redshift-data get-statement-result --id "$ID" \
      --profile "$PROFILE" --region "$REGION" 2>/dev/null \
      | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
    if d.get('TotalNumRows', 0) > 0:
        cols = [c['label'] for c in d['ColumnMetadata']]
        print(' | '.join(cols))
        print('-' * 60)
        for r in d['Records']:
            vals = [list(v.values())[0] if v else 'NULL' for v in r]
            print(' | '.join(str(x) for x in vals))
        print(f'({d[\"TotalNumRows\"]} filas)')
except:
    pass
" 2>/dev/null
    exit 0

  elif [[ "$STATUS" == "FAILED" || "$STATUS" == "ABORTED" ]]; then
    ERR=$(aws redshift-data describe-statement --id "$ID" \
      --profile "$PROFILE" --region "$REGION" \
      --query 'Error' --output text 2>/dev/null)
    echo "[$LABEL] FAILED: $ERR"
    exit 1
  fi

  sleep 3
done

echo "[$LABEL] TIMEOUT (180s)"
exit 1
