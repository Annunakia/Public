#!/bin/bash
# ==============================================================================
# validate_fase2.sh — Validaciones Checkpoint Fase 2 (Atributos de Cuenta)
# Ejecuta queries de validación y reporta PASS/FAIL por cada una.
# Exit: número de errores (0 = todo OK)
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ERRORS=0

echo ""
echo "╔══════════════════════════════════════════════════════════════"
echo "║ CHECKPOINT FASE 2 — Atributos de Cuenta"
echo "╚══════════════════════════════════════════════════════════════"
echo ""

# ==============================================================================
# V2.1: Ningún portafolio inválido
# ==============================================================================
echo -n "  V2.1 Sin portafolios inválidos ... "
RESULT=$("$SCRIPT_DIR/run_sql.sh" \
  "SELECT COUNT(*) AS invalidos FROM rec_stage.cta_totales_personas_tmp3 WHERE portafolio NOT IN ('CO','RO','VE','HP','IN','OT','CC','AH','CT');" \
  "V2.1_portafolio" 2>&1)

if echo "$RESULT" | grep -q "FAILED\|ERROR ejecutando\|TIMEOUT"; then
  echo "FAIL (error ejecutando query)"
  echo "       $RESULT"
  ERRORS=$((ERRORS + 1))
else
  COUNT=$(echo "$RESULT" | grep -oP '\d+' | tail -1)
  if [[ "$COUNT" == "0" ]]; then
    echo "PASS (0 inválidos)"
  else
    echo "FAIL ($COUNT portafolios inválidos encontrados)"
    ERRORS=$((ERRORS + 1))
  fi
fi

# ==============================================================================
# V2.2: 0 portafolios NULL
# ==============================================================================
echo -n "  V2.2 Sin portafolios NULL ... "
RESULT=$("$SCRIPT_DIR/run_sql.sh" \
  "SELECT COUNT(*) AS sin_portafolio FROM rec_stage.cta_totales_personas_tmp3 WHERE portafolio IS NULL;" \
  "V2.2_null_port" 2>&1)

if echo "$RESULT" | grep -q "FAILED\|ERROR ejecutando\|TIMEOUT"; then
  echo "FAIL (error ejecutando query)"
  echo "       $RESULT"
  ERRORS=$((ERRORS + 1))
else
  COUNT=$(echo "$RESULT" | grep -oP '\d+' | tail -1)
  if [[ "$COUNT" == "0" ]]; then
    echo "PASS (0 NULL)"
  else
    echo "FAIL ($COUNT portafolios NULL)"
    ERRORS=$((ERRORS + 1))
  fi
fi

# ==============================================================================
# V2.3: 0 hashes con LENGTH != 32
# ==============================================================================
echo -n "  V2.3 Hashes MD5 formato correcto (32 chars) ... "
RESULT=$("$SCRIPT_DIR/run_sql.sh" \
  "SELECT COUNT(*) AS hash_invalido FROM rec_stage.concatena_atributos WHERE LENGTH(cod_hash) != 32;" \
  "V2.3_hash_len" 2>&1)

if echo "$RESULT" | grep -q "FAILED\|ERROR ejecutando\|TIMEOUT"; then
  echo "FAIL (error ejecutando query)"
  echo "       $RESULT"
  ERRORS=$((ERRORS + 1))
else
  COUNT=$(echo "$RESULT" | grep -oP '\d+' | tail -1)
  if [[ "$COUNT" == "0" ]]; then
    echo "PASS (todos 32 chars)"
  else
    echo "FAIL ($COUNT hashes con LENGTH != 32)"
    ERRORS=$((ERRORS + 1))
  fi
fi

# ==============================================================================
# V2.4: 0 concatena vacíos o NULL
# ==============================================================================
echo -n "  V2.4 Sin concatena vacíos ... "
RESULT=$("$SCRIPT_DIR/run_sql.sh" \
  "SELECT COUNT(*) AS concat_vacio FROM rec_stage.concatena_atributos WHERE concatena IS NULL OR concatena = '';" \
  "V2.4_concat" 2>&1)

if echo "$RESULT" | grep -q "FAILED\|ERROR ejecutando\|TIMEOUT"; then
  echo "FAIL (error ejecutando query)"
  echo "       $RESULT"
  ERRORS=$((ERRORS + 1))
else
  COUNT=$(echo "$RESULT" | grep -oP '\d+' | tail -1)
  if [[ "$COUNT" == "0" ]]; then
    echo "PASS (0 vacíos)"
  else
    echo "FAIL ($COUNT concatena vacíos/NULL)"
    ERRORS=$((ERRORS + 1))
  fi
fi

# ==============================================================================
# V2.5: 0 errores en log para Fase 2
# ==============================================================================
echo -n "  V2.5 Sin errores en log para Fase 2 ... "
RESULT=$("$SCRIPT_DIR/run_sql.sh" \
  "SELECT COUNT(*) AS errores FROM rec_stage.log_ejecucion WHERE evento = 'ERROR' AND nombre_procedimiento IN ('cta_atributos', 'cta_totales_personas', 'cta_totales_personas_1', 'cta_totales_personas_2', 'concat_atributos');" \
  "V2.5_errors" 2>&1)

if echo "$RESULT" | grep -q "FAILED\|ERROR ejecutando\|TIMEOUT"; then
  echo "FAIL (error ejecutando query)"
  echo "       $RESULT"
  ERRORS=$((ERRORS + 1))
else
  COUNT=$(echo "$RESULT" | grep -oP '\d+' | tail -1)
  if [[ "$COUNT" == "0" ]]; then
    echo "PASS (0 errores)"
  else
    echo "FAIL ($COUNT errores en log)"
    ERRORS=$((ERRORS + 1))
  fi
fi

# ==============================================================================
# Resumen
# ==============================================================================
echo ""
if [[ $ERRORS -eq 0 ]]; then
  echo "  ✅ CHECKPOINT FASE 2: PASSED (5/5 validaciones OK)"
else
  echo "  ❌ CHECKPOINT FASE 2: FAILED ($ERRORS errores)"
fi
echo ""

exit $ERRORS
