"""
Generador de dataset sintetico COMPLETO para Ordenamiento 242 - 10,000 personas.

Genera un dataset determinista (seed=42) con TODAS las tablas referenciadas por
los scripts SQL migrados de Teradata a Redshift.

Salida: dataset_10k.sql con INSERT statements cargables en Redshift.

Tablas generadas (31 tablas):
  1. Control & Metadata: control_ordenamiento, metadata_carga_log, metadata_ordenamiento
  2. Bureau/Account: v_buro_persona, vu_cuenta (+ VIEW v_cuenta), vu_persona
  3. Behavior: vu_comportamiento_cta_activo, vu_comportamiento_cta_pasivo
  4. Location: relacion_persona_ubicacion, mat_reporte_rel_pers_ubi,
     v_ubicacion_estandarizada, direccion_fisica, relacion_ubicac_estandar_geo
  5. Reference/Lookup: v_razon_bloqueo, v_fuente_dato, v_cod_entrega_dato,
     v_gestion_registro, v_tipo_ubicacion_direccion, v_tipo_persona,
     v_tipo_cuenta, v_fuente, v_geografia
  6. Blocking & Logging: bloqueo, v_bloqueo, log_td
  7. REC Model: v_reporte_ubicacion_original, vu_relacion_persona_ubicacion,
     vu_reporte_relacion_pers_ubi, v_ubicacion_original,
     v_log_ubicacion_estandariza, v_relacion_ubicac_estandar_geo,
     v_unificacion_direccion
  8. Hash: cuenta_atributo_hash, ubicacion_atributo_hash
  9. Stage: personas_raw (rec_stage)

Requerimientos: 18.1, 18.2, 18.3, 18.4
"""

import random
import hashlib
import os
from datetime import date, timedelta

# ============================================================
# Configuracion determinista
# ============================================================
random.seed(42)
NUM_PERSONAS = 10_000
FECHA_CONTROL = date(2024, 6, 15)

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
OUT_FILE = os.path.join(OUT_DIR, 'dataset_10k.sql')

# ============================================================
# Constantes y distribuciones
# ============================================================

DANE_CODES = [
    11001, 5001, 76001, 8001, 13001, 68001, 54001, 73001,
    17001, 66001, 25754, 5360, 76109, 50001, 23001,
]
DANE_WEIGHTS = [35, 15, 12, 8, 5, 4, 3, 3, 2, 2, 2, 2, 2, 3, 2]
DANE_DEPARTAMENTOS = {
    11001: 11, 5001: 5, 76001: 76, 8001: 8, 13001: 13,
    68001: 68, 54001: 54, 73001: 73, 17001: 17, 66001: 66,
    25754: 25, 5360: 5, 76109: 76, 50001: 50, 23001: 23,
}
DANE_COORDS = {
    11001: (4.6097, -74.0817), 5001: (6.2442, -75.5812),
    76001: (3.4516, -76.5320), 8001: (10.9685, -74.7813),
    13001: (10.3910, -75.5144), 68001: (7.1254, -73.1198),
    54001: (7.8939, -72.5078), 73001: (4.4389, -75.2322),
    17001: (5.0689, -75.5174), 66001: (4.8133, -75.6961),
    25754: (4.5793, -74.2168), 5360: (6.1685, -75.6076),
    76109: (3.8801, -77.0311), 50001: (4.1420, -73.6266),
    23001: (8.7479, -75.8814),
}

TIPOS_VIA = ['CL', 'KR', 'TV', 'DG', 'AC', 'AV']
COMPLEMENTOS_DIR = ['AP', 'TO', 'BR', 'ED', 'LC', 'OF', 'CS', 'PI', 'INT', 'MZ']
BARRIOS = [
    'CHAPINERO', 'SUBA', 'KENNEDY', 'USAQUEN', 'ENGATIVA',
    'FONTIBON', 'BOSA', 'TEUSAQUILLO', 'PUENTE ARANDA', 'RAFAEL URIBE',
    'CIUDAD BOLIVAR', 'SAN CRISTOBAL', 'TUNJUELITO', 'ANTONIO NARINO',
    'SANTA FE', 'LA CANDELARIA', 'MARTIRES', 'BARRIOS UNIDOS',
    'POBLADO', 'LAURELES', 'BELEN', 'CASTILLA', 'ROBLEDO',
]

# Suscriptores (codigos de 6 digitos)
SUSCRIPTORES = [
    '020001', '020023', '030045', '040003', '040076', '040909',
    '050058', '060012', '070034', '080056', '090078', '100001',
    '110023', '120045', '130067', '140089', '150001', '160023',
    '170045', '180110', '180015', '190067', '200059', '210089',
    '220001', '230023', '240045', '250067', '260089', '270001',
    '280023', '290045', '300067', '310089', '320001', '330023',
    '340045', '350067', '360089', '370001', '380023', '390045',
    '400067', '410089', '420001', '430023', '440045', '450043',
    '450030', '460089', '470001', '480023', '490045', '510067',
    '510089',
]

# Tipos de cuenta (cod_tipo_cta_fte values used in portafolio logic)
TIPOS_CTA_FTE = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10',
                 '11', '13', '14', '15', '16', '18', '19', '20', '21',
                 '22', '23', '24', '26', '27', '28', '29', '30', '31',
                 '32', '33', '34', '35', '36', '37', '38', '39', '41',
                 '42', '43', '44', '45', '46', '49']
TIPOS_CTA_FTE_WEIGHTS = [20, 15, 8, 5, 5, 4, 4, 3, 3, 2,
                         2, 5, 2, 2, 2, 3, 2, 1, 1,
                         1, 4, 4, 1, 2, 1, 1, 1, 1,
                         1, 1, 1, 1, 1, 1, 1, 1, 1,
                         1, 1, 1, 1, 1, 1]

TIPOS_OBLIGACION_FTE = ['1', '2', '3']
GARANTIAS_BURO = ['0', '1', '2', '3', '4', '5']

ESTADOS_VIGENCIA = ['A', 'I']
ESTADOS_VIGENCIA_WEIGHTS = [70, 30]

TIPO_REL_CTA_FTE = ['P', 'C', 'D']
TIPO_REL_CTA_WEIGHTS = [60, 25, 15]

NATU_CTA_FTE = ['ACTIVO', 'PASIVO']
NATU_CTA_WEIGHTS = [70, 30]

TIPO_REL_CTA_NOMBRE = {'P': 'PRINCIPAL', 'C': 'CODEUDOR', 'D': 'DEUDOR SOLIDARIO'}

# BTT tables for metadata_ordenamiento
BTT_TABLES = [
    'CUENTA', 'BURO_PERSONA', 'COMPORTAMIENTO_CUENTA',
    'COMPORTAMIENTO_CUENTA_ACTIVO', 'COMPORTAMIENTO_CUENTA_PASIVO',
]
# REC tables for metadata_ordenamiento
REC_TABLES = [
    'REPORTE_UBICACION_ORIGINAL', 'RELACION_PERSONA_UBICACION',
    'REPORTE_RELACION_PERSONA_UBICA', 'BLOQUEO',
    'RELACION_UBICAC_ESTANDAR_GEO', 'UBICACION_ORIGINAL',
    'UBICACION_ESTANDARIZADA', 'LOG_UBICACION_ESTANDARIZADA',
    'UNIFICACION_DIRECCION',
]

# ============================================================
# Funciones auxiliares
# ============================================================

def rand_date(start=date(2022, 1, 1), end=date(2025, 6, 30)):
    delta = (end - start).days
    return start + timedelta(days=random.randint(0, delta))

def rand_date_before_control():
    return rand_date(date(2022, 1, 1), FECHA_CONTROL - timedelta(days=1))

def rand_date_after_control():
    return rand_date(FECHA_CONTROL + timedelta(days=1), date(2025, 6, 30))

def gen_direccion():
    tipo_via = random.choice(TIPOS_VIA)
    num1 = random.randint(1, 170)
    num2 = random.randint(1, 150)
    num3 = random.randint(1, 99)
    return f"{tipo_via} {num1} {num2} {num3}"

def gen_complemento():
    comp = random.choice(COMPLEMENTOS_DIR)
    num = random.randint(1, 999)
    return f"{comp} {num}"

def gen_coord(dane_code):
    base_lat, base_lon = DANE_COORDS.get(dane_code, (4.6, -74.0))
    lat = base_lat + random.uniform(-0.05, 0.05)
    lon = base_lon + random.uniform(-0.05, 0.05)
    return round(lat, 6), round(lon, 6)

def md5_hash(text):
    return hashlib.md5(text.encode('utf-8')).hexdigest()

def sql_str(val):
    if val is None:
        return 'NULL'
    if isinstance(val, str):
        return "'" + val.replace("'", "''") + "'"
    if isinstance(val, date):
        return f"'{val.isoformat()}'"
    if isinstance(val, float):
        return f"{val:.6f}"
    return str(val)

def write_batch_inserts(f, table_name, rows, batch_size=100):
    """Write INSERT statements in batches of batch_size."""
    for batch_start in range(0, len(rows), batch_size):
        batch = rows[batch_start:batch_start + batch_size]
        f.write(f"INSERT INTO {table_name} VALUES\n")
        lines = []
        for row in batch:
            vals = ','.join(sql_str(v) for v in row)
            lines.append(f"({vals})")
        f.write(",\n".join(lines) + ";\n")


# ============================================================
# Generacion del dataset
# ============================================================

print("Generando dataset sintetico COMPLETO de 10,000 personas...")
print(f"  Fecha de control: {FECHA_CONTROL}")
print(f"  Seed: 42 (determinista)")
print()

# --- ID counters ---
next_cod_dw_cta = 1_000_000
next_cod_dw_persona_ubic = 2_000_000
next_cod_dw_ubic = 3_000_000
next_cod_dw_reporte = 4_000_000

# --- Reference table data ---
# v_razon_bloqueo
REF_RAZON_BLOQUEO = [(i, f'RB{i:03d}') for i in range(1, 11)]

# v_fuente_dato
REF_FUENTE_DATO = [(i, f'FD{i:03d}') for i in range(1, 16)]

# v_cod_entrega_dato
REF_COD_ENTREGA = [(i, rand_date(date(2015, 1, 1), date(2023, 12, 31))) for i in range(1, 21)]

# v_gestion_registro - MUST have 'Valida'
REF_GESTION_REGISTRO = [
    (1, 'Valida'),
    (2, 'Invalida'),
    (3, 'Pendiente'),
    (4, 'Rechazada'),
    (5, 'En Proceso'),
]

# v_tipo_ubicacion_direccion
REF_TIPO_UBIC_DIR = [
    (1, 'RESIDENCIAL'),
    (2, 'LABORAL'),
    (3, 'CORRESPONDENCIA'),
    (4, 'REFERENCIA'),
    (5, 'COBRO'),
]

# v_tipo_persona
REF_TIPO_PERSONA = [
    (1, 'NATURAL'),
    (2, 'JURIDICA'),
]

# v_tipo_cuenta
REF_TIPO_CUENTA = [(i, f'TIPO CTA {i}') for i in range(1, 50)]

# v_fuente
REF_FUENTE = [(i, f'FUENTE {i}') for i in range(1, 11)]

# v_geografia
REF_GEOGRAFIA = [(i+1, dane, DANE_DEPARTAMENTOS[dane]) for i, dane in enumerate(DANE_CODES)]

# ============================================================
# Generate 10,000 persons
# ============================================================
personas = []
for i in range(NUM_PERSONAS):
    cod_pin = 100_000 + i
    id_buro = 200_000 + i
    personas.append((cod_pin, id_buro))

# personas_raw: 10,500 rows (10K unique + 500 dupes)
num_duplicados = 500
dup_indices = random.sample(range(NUM_PERSONAS), num_duplicados)
personas_raw = [(p[0], p[1]) for p in personas]
for idx in dup_indices:
    personas_raw.append(personas[idx])
random.shuffle(personas_raw)

print(f"  Personas unicas: {NUM_PERSONAS}")
print(f"  personas_raw rows: {len(personas_raw)}")

# ============================================================
# Generate lotes (150 lotes for metadata_carga_log)
# ============================================================
NUM_LOTES = 150
lotes = []
for lote_id in range(1, NUM_LOTES + 1):
    if random.random() < 0.6:
        fecha_carga = rand_date_after_control()
    else:
        fecha_carga = rand_date_before_control()
    tabla = random.choice(BTT_TABLES + REC_TABLES)
    inserts_count = random.randint(100, 50000)
    updates_count = random.randint(0, 5000)
    descripcion = random.choices(['Ok', 'Ok', 'Ok', 'Error'], weights=[80, 10, 5, 5], k=1)[0]
    lotes.append((lote_id, tabla, inserts_count, updates_count, descripcion, fecha_carga))

# Ensure we have lotes for each table type with fecha > control and 'Ok'
for tbl in BTT_TABLES + REC_TABLES:
    matching = [l for l in lotes if l[1] == tbl and l[5] > FECHA_CONTROL and l[4] == 'Ok']
    if not matching:
        lote_id = len(lotes) + 1
        lotes.append((lote_id, tbl, random.randint(500, 10000), random.randint(0, 1000),
                      'Ok', rand_date_after_control()))

NUM_LOTES = len(lotes)
all_lote_ids = [l[0] for l in lotes]
post_control_lotes = [l[0] for l in lotes if l[5] > FECHA_CONTROL and l[4] == 'Ok']

print(f"  Lotes metadata: {NUM_LOTES}")

# ============================================================
# Generate metadata_ordenamiento (catalog mapping tables to BTT/REC)
# ============================================================
metadata_ordenamiento = []
for tbl in BTT_TABLES:
    metadata_ordenamiento.append((tbl, 'BTT'))
for tbl in REC_TABLES:
    metadata_ordenamiento.append((tbl, 'REC'))

# ============================================================
# Generate log_td (for materializa_rec)
# ============================================================
log_td_rows = []
for l in lotes:
    lote_id, tabla, ins, upd, desc, fecha = l
    if desc == 'Ok':
        estado = random.choice(['Cargue Ok', 'Finalizado OK'])
    else:
        estado = 'Error'
    log_td_rows.append((lote_id, fecha, tabla, estado))

# ============================================================
# Generate v_buro_persona
# ============================================================
print("Generando v_buro_persona...")
v_buro_persona_rows = []
for cod_pin, id_buro in personas:
    lote = random.choice(all_lote_ids)
    lote_act = random.choice(all_lote_ids)
    v_buro_persona_rows.append((cod_pin, id_buro, lote, lote_act))

# ============================================================
# Generate vu_persona
# ============================================================
print("Generando vu_persona...")
vu_persona_rows = []
for cod_pin, id_buro in personas:
    tipo_persona = random.choices([1, 2], weights=[85, 15], k=1)[0]
    vu_persona_rows.append((cod_pin, id_buro, tipo_persona))

# ============================================================
# Generate vu_cuenta (the BIG one, ~40K rows, ~60 columns)
# ============================================================
print("Generando vu_cuenta (~40K rows)...")
vu_cuenta_rows = []
cuenta_by_persona = {}  # id_buro -> list of cod_dw_cta

for i, (cod_pin, id_buro) in enumerate(personas):
    n_cuentas = random.choices(
        range(1, 6), weights=[25, 30, 25, 12, 8], k=1
    )[0]
    cuenta_by_persona[id_buro] = []

    for _ in range(n_cuentas):
        next_cod_dw_cta += 1
        cod_dw_cta = next_cod_dw_cta

        cod_dw_tipo_cta = random.randint(1, 49)
        cod_tipo_cta_fte = random.choices(TIPOS_CTA_FTE, weights=TIPOS_CTA_FTE_WEIGHTS, k=1)[0]
        num_cta = f'{random.randint(1000000000, 9999999999)}'
        id_buro_suscriptor = random.randint(300000, 399999)
        nit_suscriptor = f'{random.randint(800000000, 999999999)}'
        id_buro_cliente = id_buro  # IMPORTANT: id_buro_cliente = id_buro_persona
        cod_tipo_ident_fte = random.choice(['CC', 'CE', 'NI', 'TI', 'PA'])
        num_ident = f'{random.randint(10000000, 99999999)}'
        cod_dw_doc_ident = random.randint(1, 5)
        num_contr = f'{random.randint(100000, 999999)}'
        fecha_apertura = rand_date(date(2015, 1, 1), date(2024, 12, 31))
        fecha_vencimiento = rand_date(fecha_apertura + timedelta(days=365), date(2030, 12, 31))
        ind_moneda_legal = random.choice(['S', 'N'])
        cod_dw_est_mod = random.randint(1, 5)
        cod_est_mod_fte = random.choice(['A', 'I', 'C', 'S'])
        ind_tarjeta_amparada = random.choice(['S', 'N', None])
        nombre_ciudad_radicacion = random.choice(['BOGOTA', 'MEDELLIN', 'CALI', 'BARRANQUILLA', 'CARTAGENA'])
        cod_dw_razon_bloqueo = random.choice([r[0] for r in REF_RAZON_BLOQUEO] + [None, None, None])
        num_plastico = f'{random.randint(1000000000000000, 9999999999999999)}' if random.random() < 0.3 else None
        cod_dw_clase_tarjeta_credito = random.randint(1, 5) if random.random() < 0.3 else None
        cod_clase_tarjeta_credito_fte = random.choice(['ORO', 'PLA', 'CLA', 'BLA', None])
        cod_dw_franquicia = random.randint(1, 5) if random.random() < 0.3 else None
        cod_franquicia_fte = random.choice(['VISA', 'MC', 'AMEX', None])
        cod_marca_privada_fte = random.choice(['S', 'N', None])
        cod_dw_tipo_rel_con_cta = random.randint(1, 3)
        cod_tipo_rel_con_cta_fte = random.choices(TIPO_REL_CTA_FTE, weights=TIPO_REL_CTA_WEIGHTS, k=1)[0]
        cod_dw_motivo_origen = random.randint(1, 10)
        cod_motivo_origen_fte = f'MO{random.randint(1,10):02d}'
        cod_dw_tipo_obligacion = random.randint(1, 3)
        cod_tipo_obligacion_fte = random.choice(TIPOS_OBLIGACION_FTE)
        cod_dw_clase_cta = random.randint(1, 5)
        cod_clase_cta_fte = f'CC{random.randint(1,5):02d}'
        cod_dw_clase_garantia_buro = random.randint(0, 5)
        cod_clase_garantia_buro_fte = random.choice(GARANTIAS_BURO)
        cod_dw_tipo_bloqueo = random.choice([1, 2, 3, None])
        cod_tipo_bloqueo_fte = random.choice(['TB1', 'TB2', 'TB3', None])
        fecha_ultima_actualizacion = rand_date(fecha_apertura, date(2025, 6, 30))
        cod_dw_pais = 1
        cod_pais_geo_fte = 'CO'
        cod_dw_fte_dato = random.choice([r[0] for r in REF_FUENTE_DATO])
        cod_dw_evento_entrega_dato = random.randint(1, 5)
        nombre_cod_entrega_dato = f'ENT{random.randint(1,20):03d}'
        desc_cod_entrega_dato = f'Entrega tipo {random.randint(1,5)}'
        cod_entrega_dato_fte = random.choice(SUSCRIPTORES)
        cod_nov_buro_fte = random.choice(['01', '02', '03', '04', '05', None])
        desc_est_vigencia = random.choices(ESTADOS_VIGENCIA, weights=ESTADOS_VIGENCIA_WEIGHTS, k=1)[0]
        fecha_ultima_actualizacion_nov = rand_date(fecha_apertura, date(2025, 6, 30))
        cod_dw_est_suscriptor = random.randint(1, 3)
        fecha_est = rand_date(fecha_apertura, date(2025, 6, 30))
        cod_est_suscriptor_fte = random.choice(['A', 'I', 'S'])
        cod_motivo_bloqueo_fte = random.choice(['MB1', 'MB2', None])
        cod_dw_natu_cta = random.choices([1, 2], weights=NATU_CTA_WEIGHTS, k=1)[0]
        cod_natu_cta_fte = NATU_CTA_FTE[cod_dw_natu_cta - 1]
        fecha_nov = rand_date(fecha_apertura, date(2025, 6, 30))
        cod_calif_comp_cta_fte = random.choice(['A', 'B', 'C', 'D', 'E', None])
        cod_dw_entrega_dato = random.choice([r[0] for r in REF_COD_ENTREGA])
        lote = random.choice(all_lote_ids)
        lote_actualizacion = random.choice(all_lote_ids)
        num_cuotas_pactadas = random.randint(0, 120)

        row = (
            cod_dw_cta, cod_dw_tipo_cta, cod_tipo_cta_fte, num_cta,
            id_buro_suscriptor, nit_suscriptor, id_buro_cliente, cod_pin,
            cod_tipo_ident_fte, num_ident, cod_dw_doc_ident, num_contr,
            fecha_apertura, fecha_vencimiento, ind_moneda_legal,
            cod_dw_est_mod, cod_est_mod_fte, ind_tarjeta_amparada,
            nombre_ciudad_radicacion, cod_dw_razon_bloqueo, num_plastico,
            cod_dw_clase_tarjeta_credito, cod_clase_tarjeta_credito_fte,
            cod_dw_franquicia, cod_franquicia_fte, cod_marca_privada_fte,
            cod_dw_tipo_rel_con_cta, cod_tipo_rel_con_cta_fte,
            cod_dw_motivo_origen, cod_motivo_origen_fte,
            cod_dw_tipo_obligacion, cod_tipo_obligacion_fte,
            cod_dw_clase_cta, cod_clase_cta_fte,
            cod_dw_clase_garantia_buro, cod_clase_garantia_buro_fte,
            cod_dw_tipo_bloqueo, cod_tipo_bloqueo_fte,
            fecha_ultima_actualizacion, cod_dw_pais, cod_pais_geo_fte,
            cod_dw_fte_dato, cod_dw_evento_entrega_dato,
            nombre_cod_entrega_dato, desc_cod_entrega_dato,
            cod_entrega_dato_fte, cod_nov_buro_fte, desc_est_vigencia,
            fecha_ultima_actualizacion_nov, cod_dw_est_suscriptor,
            fecha_est, cod_est_suscriptor_fte, cod_motivo_bloqueo_fte,
            cod_dw_natu_cta, cod_natu_cta_fte, fecha_nov,
            cod_calif_comp_cta_fte, cod_dw_entrega_dato,
            lote, lote_actualizacion, num_cuotas_pactadas,
        )
        vu_cuenta_rows.append(row)
        cuenta_by_persona[id_buro].append(cod_dw_cta)

    if (i + 1) % 2000 == 0:
        print(f"    {i+1}/{NUM_PERSONAS} personas procesadas (cuentas)...")

print(f"  Total cuentas: {len(vu_cuenta_rows)}")


# ============================================================
# Generate behavior tables
# ============================================================
print("Generando comportamiento cta activo y pasivo...")
comportamiento_activo_rows = []
comportamiento_pasivo_rows = []

all_cod_dw_cta = [r[0] for r in vu_cuenta_rows]
# For each account, generate 1-2 behavior records (weighted toward 1)
for row in vu_cuenta_rows:
    cod_dw_cta = row[0]
    fecha_nov_cta = row[55]  # fecha_nov
    cod_natu_cta_fte = row[54]  # cod_natu_cta_fte

    n_behavior = random.choices([1, 2], weights=[75, 25], k=1)[0]

    for _ in range(n_behavior):
        # fecha_nov within 12 months of account fecha_nov
        offset_days = random.randint(-365, 0)
        behavior_fecha = fecha_nov_cta + timedelta(days=offset_days)
        if behavior_fecha < date(2020, 1, 1):
            behavior_fecha = date(2020, 1, 1)

        if cod_natu_cta_fte == 'ACTIVO':
            valor_inicial = round(random.uniform(500000, 50000000), 2)
            valor_cuota_mensual = round(random.uniform(50000, 5000000), 2)
            valor_saldo = round(random.uniform(0, valor_inicial), 2)
            numero_dias_mora = random.choices([0, 0, 0, 30, 60, 90, 120, 150, 180],
                                             weights=[50, 15, 10, 8, 5, 4, 3, 3, 2], k=1)[0]
            valor_saldo_mora = round(valor_cuota_mensual * (numero_dias_mora / 30), 2) if numero_dias_mora > 0 else 0
            num_cuotas_pagadas = random.randint(0, 60)
            valor_disponible = round(random.uniform(0, 20000000), 2)
            num_cuotas_mora = numero_dias_mora // 30
            num_cuotas_pactadas = random.randint(1, 120)
            cod_altura_mora_fte = str(min(numero_dias_mora // 30, 9))

            comportamiento_activo_rows.append((
                cod_dw_cta, valor_inicial, valor_cuota_mensual, valor_saldo,
                numero_dias_mora, valor_saldo_mora, num_cuotas_pagadas,
                valor_disponible, num_cuotas_mora, num_cuotas_pactadas,
                behavior_fecha, cod_altura_mora_fte
            ))
        else:  # PASIVO
            valor_debitos_efec = round(random.uniform(0, 10000000), 2)
            valor_creditos_efec = round(random.uniform(0, 10000000), 2)
            valor_debitos_transf = round(random.uniform(0, 5000000), 2)
            valor_creditos_transf = round(random.uniform(0, 5000000), 2)
            valor_cheques_pags = round(random.uniform(0, 3000000), 2)
            valor_cheques_devs = round(random.uniform(0, 500000), 2)
            cantidad_cheques_devs = random.randint(0, 5)
            cantidad_cheques_pags = random.randint(0, 20)
            dias_sobregiro_aut = random.randint(0, 30)
            valor_cupo_sobregiro_aut = round(random.uniform(0, 5000000), 2)

            comportamiento_pasivo_rows.append((
                cod_dw_cta, behavior_fecha, valor_debitos_efec, valor_creditos_efec,
                valor_debitos_transf, valor_creditos_transf, valor_cheques_pags,
                valor_cheques_devs, cantidad_cheques_devs, cantidad_cheques_pags,
                dias_sobregiro_aut, valor_cupo_sobregiro_aut
            ))

print(f"  Comportamiento activo rows: {len(comportamiento_activo_rows)}")
print(f"  Comportamiento pasivo rows: {len(comportamiento_pasivo_rows)}")

# v_comportamiento_cuenta (generic, with lote columns for materializa_btt)
# This is a separate table used only for lote-based person detection
v_comportamiento_cuenta_rows = []
for row in vu_cuenta_rows:
    cod_dw_cta = row[0]
    lote = row[58]  # lote
    lote_act = row[59]  # lote_actualizacion
    v_comportamiento_cuenta_rows.append((cod_dw_cta, lote, lote_act))

# v_comportamiento_cuenta_activo (with lote columns for materializa_btt)
v_comportamiento_cuenta_activo_lote_rows = []
for row in comportamiento_activo_rows:
    cod_dw_cta = row[0]
    lote = random.choice(all_lote_ids)
    lote_act = random.choice(all_lote_ids)
    v_comportamiento_cuenta_activo_lote_rows.append((cod_dw_cta, lote, lote_act))

# v_comportamiento_cuenta_pasivo (with lote columns for materializa_btt)
v_comportamiento_cuenta_pasivo_lote_rows = []
for row in comportamiento_pasivo_rows:
    cod_dw_cta = row[0]
    lote = random.choice(all_lote_ids)
    lote_act = random.choice(all_lote_ids)
    v_comportamiento_cuenta_pasivo_lote_rows.append((cod_dw_cta, lote, lote_act))

print(f"  v_comportamiento_cuenta (lote): {len(v_comportamiento_cuenta_rows)}")
print(f"  v_comportamiento_cuenta_activo (lote): {len(v_comportamiento_cuenta_activo_lote_rows)}")
print(f"  v_comportamiento_cuenta_pasivo (lote): {len(v_comportamiento_cuenta_pasivo_lote_rows)}")

# ============================================================
# Generate location tables (~30K locations)
# ============================================================
print("Generando ubicaciones (~30K rows)...")
relacion_persona_ubicacion_rows = []
v_ubicacion_estandarizada_rows = []
direccion_fisica_rows = []
relacion_ubicac_estandar_geo_rows = []
mat_reporte_rel_pers_ubi_rows = []
ubic_by_persona = {}  # id_buro -> list of (cod_dw_persona_ubic, cod_dw_ubic)

for i, (cod_pin, id_buro) in enumerate(personas):
    n_ubicaciones = random.choices(
        range(1, 5), weights=[20, 35, 30, 15], k=1
    )[0]
    ubic_by_persona[id_buro] = []

    for _ in range(n_ubicaciones):
        next_cod_dw_persona_ubic += 1
        next_cod_dw_ubic += 1
        cod_dw_persona_ubic = next_cod_dw_persona_ubic
        cod_dw_ubic = next_cod_dw_ubic

        dane_code = random.choices(DANE_CODES, weights=DANE_WEIGHTS, k=1)[0]
        cod_dw_tipo_ubicacion_dir = random.randint(1, 5)
        orden_prioridad = random.randint(1, 10)
        ind_unificacion = None  # Most are not unified
        if random.random() < 0.02:
            ind_unificacion = 'U'

        cod_dw_telefono = random.randint(5000000, 5999999)
        cod_dw_direccion_electronica = random.randint(6000000, 6999999)
        cod_dw_direccion_fisica = random.randint(7000000, 7999999)

        lote = random.choice(all_lote_ids)
        lote_act = random.choice(all_lote_ids)

        relacion_persona_ubicacion_rows.append((
            cod_pin, id_buro, cod_dw_persona_ubic, cod_dw_ubic,
            cod_dw_telefono, cod_dw_direccion_electronica,
            cod_dw_direccion_fisica, cod_dw_tipo_ubicacion_dir,
            orden_prioridad, ind_unificacion
        ))

        ubic_by_persona[id_buro].append((cod_dw_persona_ubic, cod_dw_ubic))

        # v_ubicacion_estandarizada
        texto_ubicacion = gen_direccion()
        cod_dw_fuente_est = random.choice([r[0] for r in REF_FUENTE])
        cod_dw_ciudad = random.choice([r[0] for r in REF_GEOGRAFIA])
        cod_dw_gestion_registro = 1  # 'Valida' most of the time
        if random.random() < 0.1:
            cod_dw_gestion_registro = random.randint(2, 5)

        v_ubicacion_estandarizada_rows.append((
            cod_dw_ubic, random.randint(1, 5), texto_ubicacion,
            cod_dw_fuente_est, cod_dw_ciudad, cod_dw_gestion_registro,
            lote, lote_act
        ))

        # direccion_fisica
        complemento = gen_complemento()
        direccion_fisica_rows.append((
            cod_dw_ubic, cod_dw_direccion_fisica, complemento
        ))

        # relacion_ubicac_estandar_geo
        lat, lon = gen_coord(dane_code)
        barrio = random.choice(BARRIOS)
        relacion_ubicac_estandar_geo_rows.append((
            cod_dw_ubic, barrio, lat, lon
        ))

        # mat_reporte_rel_pers_ubi (1-2 reports per location)
        n_reports = random.choices([1, 2], weights=[70, 30], k=1)[0]
        cuentas_persona = cuenta_by_persona.get(id_buro, [])

        for rep_idx in range(n_reports):
            next_cod_dw_reporte += 1
            id_buro_suscriptor_rep = random.randint(300000, 399999)
            cod_dw_cta_rep = random.choice(cuentas_persona) if cuentas_persona else -1
            fecha_reporte = rand_date(date(2020, 1, 1), date(2025, 6, 30))
            fecha_apertura_rep = rand_date(date(2015, 1, 1), fecha_reporte)
            fecha_nov_rep = rand_date(fecha_apertura_rep, date(2025, 6, 30))
            desc_est_vig = random.choices(ESTADOS_VIGENCIA, weights=ESTADOS_VIGENCIA_WEIGHTS, k=1)[0]
            nombre_natu = random.choices(NATU_CTA_FTE, weights=NATU_CTA_WEIGHTS, k=1)[0]
            rel_tipo = random.choices(TIPO_REL_CTA_FTE, weights=TIPO_REL_CTA_WEIGHTS, k=1)[0]
            nombre_tipo_rel = TIPO_REL_CTA_NOMBRE[rel_tipo]
            cod_dw_motivo_bloqueo = random.choice([0, 0, 0, 1, 2, 3])
            id_flag_nuevo = random.choice([0, 0, 1])
            id_flag_desde = random.choice([0, 0, 0, 1])
            flag_bloqueo = 0 if cod_dw_motivo_bloqueo == 0 else 1
            cod_dw_fuente_rep = random.choice([r[0] for r in REF_FUENTE])
            cod_dw_matricula = random.choice([-1, -1, random.randint(1, 1000)])

            mat_reporte_rel_pers_ubi_rows.append((
                next_cod_dw_reporte, cod_dw_persona_ubic,
                id_buro_suscriptor_rep, cod_dw_cta_rep,
                fecha_reporte, fecha_apertura_rep, fecha_nov_rep,
                desc_est_vig, nombre_natu, nombre_tipo_rel,
                cod_dw_motivo_bloqueo, id_flag_nuevo, id_flag_desde,
                flag_bloqueo, cod_dw_fuente_rep, cod_dw_matricula
            ))

    if (i + 1) % 2000 == 0:
        print(f"    {i+1}/{NUM_PERSONAS} personas procesadas (ubicaciones)...")

print(f"  Total ubicaciones: {len(relacion_persona_ubicacion_rows)}")
print(f"  Total reportes mat: {len(mat_reporte_rel_pers_ubi_rows)}")


# ============================================================
# Generate blocking tables (~300 blocked locations)
# ============================================================
print("Generando bloqueos...")
num_bloqueados = 300
all_persona_ubics = [(r[2], r[3]) for r in relacion_persona_ubicacion_rows]  # (cod_dw_persona_ubic, cod_dw_ubic)
blocked_indices = random.sample(range(len(all_persona_ubics)), min(num_bloqueados, len(all_persona_ubics)))

bloqueo_rows = []  # rec_datos.bloqueo (cod_dw_persona_ubic)
v_bloqueo_rows = []  # rec_datos.v_bloqueo (cod_dw_persona_ubic, fecha_bloqueo)

for idx in blocked_indices:
    cod_dw_persona_ubic = all_persona_ubics[idx][0]
    fecha_bloqueo = rand_date(date(2023, 1, 1), date(2025, 6, 30))
    bloqueo_rows.append((cod_dw_persona_ubic,))
    v_bloqueo_rows.append((cod_dw_persona_ubic, fecha_bloqueo))

print(f"  Bloqueos: {len(bloqueo_rows)}")

# ============================================================
# Generate REC Model tables
# ============================================================
print("Generando tablas modelo REC...")

# v_reporte_ubicacion_original
v_reporte_ubicacion_original_rows = []
sample_personas_rec = random.sample(range(NUM_PERSONAS), min(5000, NUM_PERSONAS))
for idx in sample_personas_rec:
    cod_pin, id_buro = personas[idx]
    lote = random.choice(post_control_lotes) if random.random() < 0.6 else random.choice(all_lote_ids)
    lote_act = random.choice(all_lote_ids)
    v_reporte_ubicacion_original_rows.append((cod_pin, id_buro, lote, lote_act))

# vu_relacion_persona_ubicacion (same structure as relacion_persona_ubicacion but with lote)
vu_relacion_persona_ubicacion_rows = []
for row in relacion_persona_ubicacion_rows:
    cod_pin, id_buro, cod_dw_persona_ubic = row[0], row[1], row[2]
    lote = random.choice(all_lote_ids)
    lote_act = random.choice(all_lote_ids)
    vu_relacion_persona_ubicacion_rows.append((cod_pin, id_buro, cod_dw_persona_ubic, lote, lote_act))

# vu_reporte_relacion_pers_ubi
vu_reporte_relacion_pers_ubi_rows = []
sample_ubics = random.sample(range(len(all_persona_ubics)), min(8000, len(all_persona_ubics)))
for idx in sample_ubics:
    cod_dw_persona_ubic = all_persona_ubics[idx][0]
    lote = random.choice(all_lote_ids)
    lote_act = random.choice(all_lote_ids)
    vu_reporte_relacion_pers_ubi_rows.append((cod_dw_persona_ubic, lote, lote_act))

# v_ubicacion_original
v_ubicacion_original_rows = []
all_ubics = [r[3] for r in relacion_persona_ubicacion_rows]  # cod_dw_ubic
sample_ubic_orig = random.sample(range(len(all_ubics)), min(6000, len(all_ubics)))
for idx in sample_ubic_orig:
    cod_dw_ubic = all_ubics[idx]
    lote = random.choice(all_lote_ids)
    lote_act = random.choice(all_lote_ids)
    v_ubicacion_original_rows.append((cod_dw_ubic, lote, lote_act))

# v_log_ubicacion_estandariza
v_log_ubicacion_estandariza_rows = []
sample_log_ubic = random.sample(range(len(all_ubics)), min(4000, len(all_ubics)))
for idx in sample_log_ubic:
    cod_dw_ubic = all_ubics[idx]
    lote = random.choice(all_lote_ids)
    lote_act = random.choice(all_lote_ids)
    v_log_ubicacion_estandariza_rows.append((cod_dw_ubic, lote, lote_act))

# v_relacion_ubicac_estandar_geo (with lote columns - for materializa_rec)
v_relacion_ubicac_estandar_geo_rows = []
for row in relacion_ubicac_estandar_geo_rows:
    cod_dw_ubic = row[0]
    lote = random.choice(all_lote_ids)
    lote_act = random.choice(all_lote_ids)
    v_relacion_ubicac_estandar_geo_rows.append((cod_dw_ubic, lote, lote_act))

# v_unificacion_direccion (with lote columns)
v_unificacion_direccion_rows = []
num_unificados = 200
unif_indices = random.sample(range(len(all_persona_ubics)), min(num_unificados, len(all_persona_ubics)))
for idx in unif_indices:
    cod_dw_persona_ubic = all_persona_ubics[idx][0]
    lote = random.choice(all_lote_ids)
    lote_act = random.choice(all_lote_ids)
    v_unificacion_direccion_rows.append((cod_dw_persona_ubic, lote, lote_act))

print(f"  v_reporte_ubicacion_original: {len(v_reporte_ubicacion_original_rows)}")
print(f"  vu_relacion_persona_ubicacion: {len(vu_relacion_persona_ubicacion_rows)}")
print(f"  vu_reporte_relacion_pers_ubi: {len(vu_reporte_relacion_pers_ubi_rows)}")
print(f"  v_ubicacion_original: {len(v_ubicacion_original_rows)}")
print(f"  v_log_ubicacion_estandariza: {len(v_log_ubicacion_estandariza_rows)}")
print(f"  v_relacion_ubicac_estandar_geo: {len(v_relacion_ubicac_estandar_geo_rows)}")
print(f"  v_unificacion_direccion: {len(v_unificacion_direccion_rows)}")

# ============================================================
# Generate hash tables (pre-existing for change detection)
# ============================================================
print("Generando hashes pre-calculados...")

# cuenta_atributo_hash (~20% of accounts)
cuenta_hash_rows = []
hash_sample_cta = random.sample(range(len(vu_cuenta_rows)), int(len(vu_cuenta_rows) * 0.2))
for idx in hash_sample_cta:
    r = vu_cuenta_rows[idx]
    cod_pin = r[7]
    id_buro = r[6]  # id_buro_cliente
    cod_dw_cta = r[0]
    concat_str = '|'.join([str(r[2]), str(r[31]), str(r[60]), str(r[35]), str(r[45])])
    h = md5_hash(concat_str)
    fecha_ins = rand_date(date(2023, 1, 1), date(2024, 6, 15))
    cuenta_hash_rows.append((cod_pin, id_buro, cod_dw_cta, concat_str, h, fecha_ins))

# ubicacion_atributo_hash (~20% of locations)
ubicacion_hash_rows = []
hash_sample_ubic = random.sample(range(len(relacion_persona_ubicacion_rows)),
                                 int(len(relacion_persona_ubicacion_rows) * 0.2))
for idx in hash_sample_ubic:
    r = relacion_persona_ubicacion_rows[idx]
    cod_pin = r[0]
    id_buro = r[1]
    cod_dw_persona_ubic = r[2]
    concat_str = f"{r[2]}|{r[3]}|{r[7]}|{r[8]}"
    h = md5_hash(concat_str)
    fecha_ins = rand_date(date(2023, 1, 1), date(2024, 6, 15))
    ubicacion_hash_rows.append((cod_pin, id_buro, cod_dw_persona_ubic, concat_str, h, fecha_ins, None))

print(f"  cuenta_atributo_hash: {len(cuenta_hash_rows)}")
print(f"  ubicacion_atributo_hash: {len(ubicacion_hash_rows)}")


# ============================================================
# Write SQL file
# ============================================================
print(f"\nEscribiendo {OUT_FILE}...")

with open(OUT_FILE, 'w', encoding='utf-8') as f:
    f.write("-- ============================================================\n")
    f.write("-- dataset_10k.sql\n")
    f.write("-- Dataset sintetico COMPLETO para pruebas de Ordenamiento 242\n")
    f.write("-- Generado deterministicamente con seed=42\n")
    f.write(f"-- Fecha de control: {FECHA_CONTROL}\n")
    f.write(f"-- Personas: {NUM_PERSONAS}\n")
    f.write(f"-- Cuentas: {len(vu_cuenta_rows)}\n")
    f.write(f"-- Ubicaciones: {len(relacion_persona_ubicacion_rows)}\n")
    f.write(f"-- Comportamiento activo: {len(comportamiento_activo_rows)}\n")
    f.write(f"-- Comportamiento pasivo: {len(comportamiento_pasivo_rows)}\n")
    f.write("-- ============================================================\n\n")

    # --- Schemas ---
    f.write("CREATE SCHEMA IF NOT EXISTS rec_datos;\n")
    f.write("CREATE SCHEMA IF NOT EXISTS rec_stage;\n\n")

    # ==========================================================
    # 1. CONTROL & METADATA TABLES
    # ==========================================================
    f.write("-- ============================================================\n")
    f.write("-- 1. CONTROL & METADATA\n")
    f.write("-- ============================================================\n\n")

    # control_ordenamiento
    f.write("DROP TABLE IF EXISTS rec_datos.control_ordenamiento;\n")
    f.write("CREATE TABLE rec_datos.control_ordenamiento (\n")
    f.write("    fecha_ult_ord DATE\n")
    f.write(") DISTSTYLE ALL;\n\n")
    f.write(f"INSERT INTO rec_datos.control_ordenamiento VALUES ('{FECHA_CONTROL}');\n\n")

    # metadata_carga_log
    f.write("DROP TABLE IF EXISTS rec_datos.metadata_carga_log;\n")
    f.write("CREATE TABLE rec_datos.metadata_carga_log (\n")
    f.write("    lote_id BIGINT,\n")
    f.write("    tabla_nombre VARCHAR(100),\n")
    f.write("    inserts_count BIGINT,\n")
    f.write("    updates_count BIGINT,\n")
    f.write("    descripcion VARCHAR(50),\n")
    f.write("    fecha_carga DATE\n")
    f.write(") DISTSTYLE ALL;\n\n")
    write_batch_inserts(f, 'rec_datos.metadata_carga_log', lotes)
    f.write("\n")

    # metadata_ordenamiento
    f.write("DROP TABLE IF EXISTS rec_datos.metadata_ordenamiento;\n")
    f.write("CREATE TABLE rec_datos.metadata_ordenamiento (\n")
    f.write("    nombre_tabla VARCHAR(100),\n")
    f.write("    nombre_db VARCHAR(10)\n")
    f.write(") DISTSTYLE ALL;\n\n")
    write_batch_inserts(f, 'rec_datos.metadata_ordenamiento', metadata_ordenamiento)
    f.write("\n")

    # ==========================================================
    # 2. REFERENCE/LOOKUP TABLES
    # ==========================================================
    f.write("-- ============================================================\n")
    f.write("-- 2. REFERENCE/LOOKUP TABLES\n")
    f.write("-- ============================================================\n\n")

    # v_razon_bloqueo
    f.write("DROP TABLE IF EXISTS rec_datos.v_razon_bloqueo;\n")
    f.write("CREATE TABLE rec_datos.v_razon_bloqueo (\n")
    f.write("    cod_dw_razon_bloqueo INTEGER,\n")
    f.write("    cod_razon_bloqueo_fte VARCHAR(20)\n")
    f.write(") DISTSTYLE ALL;\n\n")
    write_batch_inserts(f, 'rec_datos.v_razon_bloqueo', REF_RAZON_BLOQUEO)
    f.write("\n")

    # v_fuente_dato
    f.write("DROP TABLE IF EXISTS rec_datos.v_fuente_dato;\n")
    f.write("CREATE TABLE rec_datos.v_fuente_dato (\n")
    f.write("    cod_dw_fte_dato INTEGER,\n")
    f.write("    cod_fte_dato_fte VARCHAR(20)\n")
    f.write(") DISTSTYLE ALL;\n\n")
    write_batch_inserts(f, 'rec_datos.v_fuente_dato', REF_FUENTE_DATO)
    f.write("\n")

    # v_cod_entrega_dato
    f.write("DROP TABLE IF EXISTS rec_datos.v_cod_entrega_dato;\n")
    f.write("CREATE TABLE rec_datos.v_cod_entrega_dato (\n")
    f.write("    cod_dw_entrega_dato INTEGER,\n")
    f.write("    fecha_ingreso_suscriptor DATE\n")
    f.write(") DISTSTYLE ALL;\n\n")
    write_batch_inserts(f, 'rec_datos.v_cod_entrega_dato', REF_COD_ENTREGA)
    f.write("\n")

    # v_gestion_registro
    f.write("DROP TABLE IF EXISTS rec_datos.v_gestion_registro;\n")
    f.write("CREATE TABLE rec_datos.v_gestion_registro (\n")
    f.write("    cod_dw_gestion_registro INTEGER,\n")
    f.write("    descripcion_gestion_registro VARCHAR(50)\n")
    f.write(") DISTSTYLE ALL;\n\n")
    write_batch_inserts(f, 'rec_datos.v_gestion_registro', REF_GESTION_REGISTRO)
    f.write("\n")

    # v_tipo_ubicacion_direccion
    f.write("DROP TABLE IF EXISTS rec_datos.v_tipo_ubicacion_direccion;\n")
    f.write("CREATE TABLE rec_datos.v_tipo_ubicacion_direccion (\n")
    f.write("    cod_dw_tipo_ubicacion_dir INTEGER,\n")
    f.write("    descripcion_tipo_ubicacion_dir VARCHAR(50)\n")
    f.write(") DISTSTYLE ALL;\n\n")
    write_batch_inserts(f, 'rec_datos.v_tipo_ubicacion_direccion', REF_TIPO_UBIC_DIR)
    f.write("\n")

    # v_tipo_persona
    f.write("DROP TABLE IF EXISTS rec_datos.v_tipo_persona;\n")
    f.write("CREATE TABLE rec_datos.v_tipo_persona (\n")
    f.write("    cod_dw_tipo_persona INTEGER,\n")
    f.write("    desc_tipo_persona VARCHAR(20)\n")
    f.write(") DISTSTYLE ALL;\n\n")
    write_batch_inserts(f, 'rec_datos.v_tipo_persona', REF_TIPO_PERSONA)
    f.write("\n")

    # v_tipo_cuenta
    f.write("DROP TABLE IF EXISTS rec_datos.v_tipo_cuenta;\n")
    f.write("CREATE TABLE rec_datos.v_tipo_cuenta (\n")
    f.write("    cod_dw_tipo_cta INTEGER,\n")
    f.write("    desc_tipo_cta VARCHAR(50)\n")
    f.write(") DISTSTYLE ALL;\n\n")
    write_batch_inserts(f, 'rec_datos.v_tipo_cuenta', REF_TIPO_CUENTA)
    f.write("\n")

    # v_fuente
    f.write("DROP TABLE IF EXISTS rec_datos.v_fuente;\n")
    f.write("CREATE TABLE rec_datos.v_fuente (\n")
    f.write("    cod_dw_fuente INTEGER,\n")
    f.write("    descripcion_fuente VARCHAR(50)\n")
    f.write(") DISTSTYLE ALL;\n\n")
    write_batch_inserts(f, 'rec_datos.v_fuente', REF_FUENTE)
    f.write("\n")

    # v_geografia
    f.write("DROP TABLE IF EXISTS rec_datos.v_geografia;\n")
    f.write("CREATE TABLE rec_datos.v_geografia (\n")
    f.write("    cod_dw_ciudad INTEGER,\n")
    f.write("    cod_dane_municipio INTEGER,\n")
    f.write("    cod_dane_departamento INTEGER\n")
    f.write(") DISTSTYLE ALL;\n\n")
    write_batch_inserts(f, 'rec_datos.v_geografia', REF_GEOGRAFIA)
    f.write("\n")

    # ==========================================================
    # 3. BUREAU/ACCOUNT TABLES
    # ==========================================================
    f.write("-- ============================================================\n")
    f.write("-- 3. BUREAU/ACCOUNT TABLES\n")
    f.write("-- ============================================================\n\n")

    # v_buro_persona
    f.write("DROP TABLE IF EXISTS rec_datos.v_buro_persona;\n")
    f.write("CREATE TABLE rec_datos.v_buro_persona (\n")
    f.write("    cod_pin_persona INTEGER,\n")
    f.write("    id_buro_persona INTEGER,\n")
    f.write("    lote BIGINT,\n")
    f.write("    lote_actualizacion BIGINT\n")
    f.write(") DISTSTYLE KEY DISTKEY(id_buro_persona);\n\n")
    write_batch_inserts(f, 'rec_datos.v_buro_persona', v_buro_persona_rows)
    f.write("\n")

    # vu_cuenta (the big one with ~60 columns)
    f.write("DROP TABLE IF EXISTS rec_datos.vu_cuenta;\n")
    f.write("CREATE TABLE rec_datos.vu_cuenta (\n")
    f.write("    cod_dw_cta BIGINT,\n")
    f.write("    cod_dw_tipo_cta INTEGER,\n")
    f.write("    cod_tipo_cta_fte VARCHAR(10),\n")
    f.write("    num_cta VARCHAR(30),\n")
    f.write("    id_buro_suscriptor INTEGER,\n")
    f.write("    nit_suscriptor VARCHAR(20),\n")
    f.write("    id_buro_cliente INTEGER,\n")
    f.write("    cod_pin_persona INTEGER,\n")
    f.write("    cod_tipo_ident_fte VARCHAR(5),\n")
    f.write("    num_ident VARCHAR(20),\n")
    f.write("    cod_dw_doc_ident INTEGER,\n")
    f.write("    num_contr VARCHAR(20),\n")
    f.write("    fecha_apertura DATE,\n")
    f.write("    fecha_vencimiento DATE,\n")
    f.write("    ind_moneda_legal CHAR(1),\n")
    f.write("    cod_dw_est_mod INTEGER,\n")
    f.write("    cod_est_mod_fte CHAR(1),\n")
    f.write("    ind_tarjeta_amparada CHAR(1),\n")
    f.write("    nombre_ciudad_radicacion VARCHAR(50),\n")
    f.write("    cod_dw_razon_bloqueo INTEGER,\n")
    f.write("    num_plastico VARCHAR(20),\n")
    f.write("    cod_dw_clase_tarjeta_credito INTEGER,\n")
    f.write("    cod_clase_tarjeta_credito_fte VARCHAR(10),\n")
    f.write("    cod_dw_franquicia INTEGER,\n")
    f.write("    cod_franquicia_fte VARCHAR(10),\n")
    f.write("    cod_marca_privada_fte CHAR(1),\n")
    f.write("    cod_dw_tipo_rel_con_cta INTEGER,\n")
    f.write("    cod_tipo_rel_con_cta_fte CHAR(1),\n")
    f.write("    cod_dw_motivo_origen INTEGER,\n")
    f.write("    cod_motivo_origen_fte VARCHAR(10),\n")
    f.write("    cod_dw_tipo_obligacion INTEGER,\n")
    f.write("    cod_tipo_obligacion_fte VARCHAR(5),\n")
    f.write("    cod_dw_clase_cta INTEGER,\n")
    f.write("    cod_clase_cta_fte VARCHAR(10),\n")
    f.write("    cod_dw_clase_garantia_buro INTEGER,\n")
    f.write("    cod_clase_garantia_buro_fte VARCHAR(5),\n")
    f.write("    cod_dw_tipo_bloqueo INTEGER,\n")
    f.write("    cod_tipo_bloqueo_fte VARCHAR(10),\n")
    f.write("    fecha_ultima_actualizacion DATE,\n")
    f.write("    cod_dw_pais INTEGER,\n")
    f.write("    cod_pais_geo_fte VARCHAR(5),\n")
    f.write("    cod_dw_fte_dato INTEGER,\n")
    f.write("    cod_dw_evento_entrega_dato INTEGER,\n")
    f.write("    nombre_cod_entrega_dato VARCHAR(20),\n")
    f.write("    desc_cod_entrega_dato VARCHAR(50),\n")
    f.write("    cod_entrega_dato_fte VARCHAR(10),\n")
    f.write("    cod_nov_buro_fte VARCHAR(5),\n")
    f.write("    desc_est_vigencia CHAR(1),\n")
    f.write("    fecha_ultima_actualizacion_nov DATE,\n")
    f.write("    cod_dw_est_suscriptor INTEGER,\n")
    f.write("    fecha_est DATE,\n")
    f.write("    cod_est_suscriptor_fte CHAR(1),\n")
    f.write("    cod_motivo_bloqueo_fte VARCHAR(10),\n")
    f.write("    cod_dw_natu_cta INTEGER,\n")
    f.write("    cod_natu_cta_fte VARCHAR(10),\n")
    f.write("    fecha_nov DATE,\n")
    f.write("    cod_calif_comp_cta_fte CHAR(1),\n")
    f.write("    cod_dw_entrega_dato INTEGER,\n")
    f.write("    lote BIGINT,\n")
    f.write("    lote_actualizacion BIGINT,\n")
    f.write("    num_cuotas_pactadas INTEGER\n")
    f.write(") DISTSTYLE KEY DISTKEY(id_buro_cliente);\n\n")
    write_batch_inserts(f, 'rec_datos.vu_cuenta', vu_cuenta_rows)
    f.write("\n")

    # v_cuenta as VIEW pointing to vu_cuenta
    f.write("-- v_cuenta is a VIEW over vu_cuenta (same data)\n")
    f.write("DROP VIEW IF EXISTS rec_datos.v_cuenta;\n")
    f.write("CREATE VIEW rec_datos.v_cuenta AS SELECT * FROM rec_datos.vu_cuenta;\n\n")

    # vu_persona
    f.write("DROP TABLE IF EXISTS rec_datos.vu_persona;\n")
    f.write("CREATE TABLE rec_datos.vu_persona (\n")
    f.write("    cod_pin_persona INTEGER,\n")
    f.write("    id_buro_persona INTEGER,\n")
    f.write("    cod_dw_tipo_persona INTEGER\n")
    f.write(") DISTSTYLE KEY DISTKEY(id_buro_persona);\n\n")
    write_batch_inserts(f, 'rec_datos.vu_persona', vu_persona_rows)
    f.write("\n")


    # ==========================================================
    # 4. BEHAVIOR TABLES
    # ==========================================================
    f.write("-- ============================================================\n")
    f.write("-- 4. BEHAVIOR TABLES\n")
    f.write("-- ============================================================\n\n")

    # vu_comportamiento_cta_activo
    f.write("DROP TABLE IF EXISTS rec_datos.vu_comportamiento_cta_activo;\n")
    f.write("CREATE TABLE rec_datos.vu_comportamiento_cta_activo (\n")
    f.write("    cod_dw_cta BIGINT,\n")
    f.write("    valor_inicial DECIMAL(18,2),\n")
    f.write("    valor_cuota_mensual DECIMAL(18,2),\n")
    f.write("    valor_saldo DECIMAL(18,2),\n")
    f.write("    numero_dias_mora INTEGER,\n")
    f.write("    valor_saldo_mora DECIMAL(18,2),\n")
    f.write("    num_cuotas_pagadas INTEGER,\n")
    f.write("    valor_disponible DECIMAL(18,2),\n")
    f.write("    num_cuotas_mora INTEGER,\n")
    f.write("    num_cuotas_pactadas INTEGER,\n")
    f.write("    fecha_nov DATE,\n")
    f.write("    cod_altura_mora_fte VARCHAR(5)\n")
    f.write(") DISTSTYLE KEY DISTKEY(cod_dw_cta);\n\n")
    write_batch_inserts(f, 'rec_datos.vu_comportamiento_cta_activo', comportamiento_activo_rows)
    f.write("\n")

    # vu_comportamiento_cta_pasivo
    f.write("DROP TABLE IF EXISTS rec_datos.vu_comportamiento_cta_pasivo;\n")
    f.write("CREATE TABLE rec_datos.vu_comportamiento_cta_pasivo (\n")
    f.write("    cod_dw_cta BIGINT,\n")
    f.write("    fecha_nov DATE,\n")
    f.write("    valor_debitos_efec DECIMAL(18,2),\n")
    f.write("    valor_creditos_efec DECIMAL(18,2),\n")
    f.write("    valor_debitos_transf DECIMAL(18,2),\n")
    f.write("    valor_creditos_transf DECIMAL(18,2),\n")
    f.write("    valor_cheques_pags DECIMAL(18,2),\n")
    f.write("    valor_cheques_devs DECIMAL(18,2),\n")
    f.write("    cantidad_cheques_devs INTEGER,\n")
    f.write("    cantidad_cheques_pags INTEGER,\n")
    f.write("    dias_sobregiro_aut INTEGER,\n")
    f.write("    valor_cupo_sobregiro_aut DECIMAL(18,2)\n")
    f.write(") DISTSTYLE KEY DISTKEY(cod_dw_cta);\n\n")
    write_batch_inserts(f, 'rec_datos.vu_comportamiento_cta_pasivo', comportamiento_pasivo_rows)
    f.write("\n")

    # v_comportamiento_cuenta (with lote columns, for materializa_btt step 5)
    f.write("DROP TABLE IF EXISTS rec_datos.v_comportamiento_cuenta;\n")
    f.write("CREATE TABLE rec_datos.v_comportamiento_cuenta (\n")
    f.write("    cod_dw_cta BIGINT,\n")
    f.write("    lote BIGINT,\n")
    f.write("    lote_actualizacion BIGINT\n")
    f.write(") DISTSTYLE KEY DISTKEY(cod_dw_cta);\n\n")
    write_batch_inserts(f, 'rec_datos.v_comportamiento_cuenta', v_comportamiento_cuenta_rows)
    f.write("\n")

    # v_comportamiento_cuenta_activo (with lote columns, for materializa_btt step 6)
    f.write("DROP TABLE IF EXISTS rec_datos.v_comportamiento_cuenta_activo;\n")
    f.write("CREATE TABLE rec_datos.v_comportamiento_cuenta_activo (\n")
    f.write("    cod_dw_cta BIGINT,\n")
    f.write("    lote BIGINT,\n")
    f.write("    lote_actualizacion BIGINT\n")
    f.write(") DISTSTYLE KEY DISTKEY(cod_dw_cta);\n\n")
    write_batch_inserts(f, 'rec_datos.v_comportamiento_cuenta_activo', v_comportamiento_cuenta_activo_lote_rows)
    f.write("\n")

    # v_comportamiento_cuenta_pasivo (with lote columns, for materializa_btt step 7)
    f.write("DROP TABLE IF EXISTS rec_datos.v_comportamiento_cuenta_pasivo;\n")
    f.write("CREATE TABLE rec_datos.v_comportamiento_cuenta_pasivo (\n")
    f.write("    cod_dw_cta BIGINT,\n")
    f.write("    lote BIGINT,\n")
    f.write("    lote_actualizacion BIGINT\n")
    f.write(") DISTSTYLE KEY DISTKEY(cod_dw_cta);\n\n")
    write_batch_inserts(f, 'rec_datos.v_comportamiento_cuenta_pasivo', v_comportamiento_cuenta_pasivo_lote_rows)
    f.write("\n")

    # ==========================================================
    # 5. LOCATION TABLES
    # ==========================================================
    f.write("-- ============================================================\n")
    f.write("-- 5. LOCATION TABLES\n")
    f.write("-- ============================================================\n\n")

    # relacion_persona_ubicacion
    f.write("DROP TABLE IF EXISTS rec_datos.relacion_persona_ubicacion;\n")
    f.write("CREATE TABLE rec_datos.relacion_persona_ubicacion (\n")
    f.write("    cod_pin_persona INTEGER,\n")
    f.write("    id_buro_persona INTEGER,\n")
    f.write("    cod_dw_persona_ubic BIGINT,\n")
    f.write("    cod_dw_ubic BIGINT,\n")
    f.write("    cod_dw_telefono BIGINT,\n")
    f.write("    cod_dw_direccion_electronica BIGINT,\n")
    f.write("    cod_dw_direccion_fisica BIGINT,\n")
    f.write("    cod_dw_tipo_ubicacion_dir INTEGER,\n")
    f.write("    orden_prioridad INTEGER,\n")
    f.write("    ind_unificacion CHAR(1)\n")
    f.write(") DISTSTYLE KEY DISTKEY(id_buro_persona);\n\n")
    write_batch_inserts(f, 'rec_datos.relacion_persona_ubicacion', relacion_persona_ubicacion_rows)
    f.write("\n")

    # Also create v_relacion_persona_ubicacion as same table (used in materializa_rec)
    f.write("-- v_relacion_persona_ubicacion (same structure, used in materializa_rec for resolving persons)\n")
    f.write("DROP TABLE IF EXISTS rec_datos.v_relacion_persona_ubicacion;\n")
    f.write("CREATE TABLE rec_datos.v_relacion_persona_ubicacion (\n")
    f.write("    cod_pin_persona INTEGER,\n")
    f.write("    id_buro_persona INTEGER,\n")
    f.write("    cod_dw_persona_ubic BIGINT,\n")
    f.write("    cod_dw_ubic BIGINT,\n")
    f.write("    cod_dw_telefono BIGINT,\n")
    f.write("    cod_dw_direccion_electronica BIGINT,\n")
    f.write("    cod_dw_direccion_fisica BIGINT,\n")
    f.write("    cod_dw_tipo_ubicacion_dir INTEGER,\n")
    f.write("    orden_prioridad INTEGER,\n")
    f.write("    ind_unificacion CHAR(1)\n")
    f.write(") DISTSTYLE KEY DISTKEY(id_buro_persona);\n\n")
    # Insert same data
    write_batch_inserts(f, 'rec_datos.v_relacion_persona_ubicacion', relacion_persona_ubicacion_rows)
    f.write("\n")

    # mat_reporte_rel_pers_ubi
    f.write("DROP TABLE IF EXISTS rec_datos.mat_reporte_rel_pers_ubi;\n")
    f.write("CREATE TABLE rec_datos.mat_reporte_rel_pers_ubi (\n")
    f.write("    cod_dw_reporte_persona_ubic BIGINT,\n")
    f.write("    cod_dw_persona_ubic BIGINT,\n")
    f.write("    id_buro_suscriptor INTEGER,\n")
    f.write("    cod_dw_cta BIGINT,\n")
    f.write("    fecha_reporte DATE,\n")
    f.write("    fecha_apertura DATE,\n")
    f.write("    fecha_nov DATE,\n")
    f.write("    desc_est_vigencia CHAR(1),\n")
    f.write("    nombre_natu_cta VARCHAR(10),\n")
    f.write("    nombre_tipo_rel_con_cta VARCHAR(20),\n")
    f.write("    cod_dw_motivo_bloqueo INTEGER,\n")
    f.write("    id_flag_nuevo SMALLINT,\n")
    f.write("    id_flag_desde SMALLINT,\n")
    f.write("    flag_bloqueo SMALLINT,\n")
    f.write("    cod_dw_fuente INTEGER,\n")
    f.write("    cod_dw_matricula INTEGER\n")
    f.write(") DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic);\n\n")
    write_batch_inserts(f, 'rec_datos.mat_reporte_rel_pers_ubi', mat_reporte_rel_pers_ubi_rows)
    f.write("\n")

    # v_ubicacion_estandarizada
    f.write("DROP TABLE IF EXISTS rec_datos.v_ubicacion_estandarizada;\n")
    f.write("CREATE TABLE rec_datos.v_ubicacion_estandarizada (\n")
    f.write("    cod_dw_ubic BIGINT,\n")
    f.write("    cod_dw_tipo_ubicacion INTEGER,\n")
    f.write("    texto_ubicacion VARCHAR(200),\n")
    f.write("    cod_dw_fuente_est INTEGER,\n")
    f.write("    cod_dw_ciudad INTEGER,\n")
    f.write("    cod_dw_gestion_registro INTEGER,\n")
    f.write("    lote BIGINT,\n")
    f.write("    lote_actualizacion BIGINT\n")
    f.write(") DISTSTYLE KEY DISTKEY(cod_dw_ubic);\n\n")
    write_batch_inserts(f, 'rec_datos.v_ubicacion_estandarizada', v_ubicacion_estandarizada_rows)
    f.write("\n")

    # direccion_fisica
    f.write("DROP TABLE IF EXISTS rec_datos.direccion_fisica;\n")
    f.write("CREATE TABLE rec_datos.direccion_fisica (\n")
    f.write("    cod_dw_ubic BIGINT,\n")
    f.write("    cod_dw_direccion_fisica BIGINT,\n")
    f.write("    complemento VARCHAR(200)\n")
    f.write(") DISTSTYLE KEY DISTKEY(cod_dw_ubic);\n\n")
    write_batch_inserts(f, 'rec_datos.direccion_fisica', direccion_fisica_rows)
    f.write("\n")

    # relacion_ubicac_estandar_geo
    f.write("DROP TABLE IF EXISTS rec_datos.relacion_ubicac_estandar_geo;\n")
    f.write("CREATE TABLE rec_datos.relacion_ubicac_estandar_geo (\n")
    f.write("    cod_dw_ubic BIGINT,\n")
    f.write("    urbanizacion_barrio VARCHAR(100),\n")
    f.write("    latitud DECIMAL(10,6),\n")
    f.write("    longitud DECIMAL(10,6)\n")
    f.write(") DISTSTYLE KEY DISTKEY(cod_dw_ubic);\n\n")
    write_batch_inserts(f, 'rec_datos.relacion_ubicac_estandar_geo', relacion_ubicac_estandar_geo_rows)
    f.write("\n")

    # ==========================================================
    # 6. BLOCKING & LOGGING TABLES
    # ==========================================================
    f.write("-- ============================================================\n")
    f.write("-- 6. BLOCKING & LOGGING TABLES\n")
    f.write("-- ============================================================\n\n")

    # bloqueo
    f.write("DROP TABLE IF EXISTS rec_datos.bloqueo;\n")
    f.write("CREATE TABLE rec_datos.bloqueo (\n")
    f.write("    cod_dw_persona_ubic BIGINT\n")
    f.write(") DISTSTYLE ALL;\n\n")
    write_batch_inserts(f, 'rec_datos.bloqueo', bloqueo_rows)
    f.write("\n")

    # v_bloqueo
    f.write("DROP TABLE IF EXISTS rec_datos.v_bloqueo;\n")
    f.write("CREATE TABLE rec_datos.v_bloqueo (\n")
    f.write("    cod_dw_persona_ubic BIGINT,\n")
    f.write("    fecha_bloqueo DATE\n")
    f.write(") DISTSTYLE ALL;\n\n")
    write_batch_inserts(f, 'rec_datos.v_bloqueo', v_bloqueo_rows)
    f.write("\n")

    # log_td
    f.write("DROP TABLE IF EXISTS rec_datos.log_td;\n")
    f.write("CREATE TABLE rec_datos.log_td (\n")
    f.write("    lote BIGINT,\n")
    f.write("    fecha_hora_inicio DATE,\n")
    f.write("    tabla_destino_prod VARCHAR(100),\n")
    f.write("    estado_ejecucion VARCHAR(50)\n")
    f.write(") DISTSTYLE ALL;\n\n")
    write_batch_inserts(f, 'rec_datos.log_td', log_td_rows)
    f.write("\n")


    # ==========================================================
    # 7. REC MODEL TABLES
    # ==========================================================
    f.write("-- ============================================================\n")
    f.write("-- 7. REC MODEL TABLES (for materializa_rec)\n")
    f.write("-- ============================================================\n\n")

    # v_reporte_ubicacion_original
    f.write("DROP TABLE IF EXISTS rec_datos.v_reporte_ubicacion_original;\n")
    f.write("CREATE TABLE rec_datos.v_reporte_ubicacion_original (\n")
    f.write("    cod_pin_persona INTEGER,\n")
    f.write("    id_buro_persona INTEGER,\n")
    f.write("    lote BIGINT,\n")
    f.write("    lote_actualizacion BIGINT\n")
    f.write(") DISTSTYLE KEY DISTKEY(id_buro_persona);\n\n")
    write_batch_inserts(f, 'rec_datos.v_reporte_ubicacion_original', v_reporte_ubicacion_original_rows)
    f.write("\n")

    # vu_relacion_persona_ubicacion
    f.write("DROP TABLE IF EXISTS rec_datos.vu_relacion_persona_ubicacion;\n")
    f.write("CREATE TABLE rec_datos.vu_relacion_persona_ubicacion (\n")
    f.write("    cod_pin_persona INTEGER,\n")
    f.write("    id_buro_persona INTEGER,\n")
    f.write("    cod_dw_persona_ubic BIGINT,\n")
    f.write("    lote BIGINT,\n")
    f.write("    lote_actualizacion BIGINT\n")
    f.write(") DISTSTYLE KEY DISTKEY(id_buro_persona);\n\n")
    write_batch_inserts(f, 'rec_datos.vu_relacion_persona_ubicacion', vu_relacion_persona_ubicacion_rows)
    f.write("\n")

    # vu_reporte_relacion_pers_ubi
    f.write("DROP TABLE IF EXISTS rec_datos.vu_reporte_relacion_pers_ubi;\n")
    f.write("CREATE TABLE rec_datos.vu_reporte_relacion_pers_ubi (\n")
    f.write("    cod_dw_persona_ubic BIGINT,\n")
    f.write("    lote BIGINT,\n")
    f.write("    lote_actualizacion BIGINT\n")
    f.write(") DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic);\n\n")
    write_batch_inserts(f, 'rec_datos.vu_reporte_relacion_pers_ubi', vu_reporte_relacion_pers_ubi_rows)
    f.write("\n")

    # v_ubicacion_original
    f.write("DROP TABLE IF EXISTS rec_datos.v_ubicacion_original;\n")
    f.write("CREATE TABLE rec_datos.v_ubicacion_original (\n")
    f.write("    cod_dw_ubic BIGINT,\n")
    f.write("    lote BIGINT,\n")
    f.write("    lote_actualizacion BIGINT\n")
    f.write(") DISTSTYLE KEY DISTKEY(cod_dw_ubic);\n\n")
    write_batch_inserts(f, 'rec_datos.v_ubicacion_original', v_ubicacion_original_rows)
    f.write("\n")

    # v_log_ubicacion_estandariza
    f.write("DROP TABLE IF EXISTS rec_datos.v_log_ubicacion_estandariza;\n")
    f.write("CREATE TABLE rec_datos.v_log_ubicacion_estandariza (\n")
    f.write("    cod_dw_ubic BIGINT,\n")
    f.write("    lote BIGINT,\n")
    f.write("    lote_actualizacion BIGINT\n")
    f.write(") DISTSTYLE KEY DISTKEY(cod_dw_ubic);\n\n")
    write_batch_inserts(f, 'rec_datos.v_log_ubicacion_estandariza', v_log_ubicacion_estandariza_rows)
    f.write("\n")

    # v_relacion_ubicac_estandar_geo (with lote columns for materializa_rec)
    f.write("DROP TABLE IF EXISTS rec_datos.v_relacion_ubicac_estandar_geo;\n")
    f.write("CREATE TABLE rec_datos.v_relacion_ubicac_estandar_geo (\n")
    f.write("    cod_dw_ubic BIGINT,\n")
    f.write("    lote BIGINT,\n")
    f.write("    lote_actualizacion BIGINT\n")
    f.write(") DISTSTYLE KEY DISTKEY(cod_dw_ubic);\n\n")
    write_batch_inserts(f, 'rec_datos.v_relacion_ubicac_estandar_geo', v_relacion_ubicac_estandar_geo_rows)
    f.write("\n")

    # v_unificacion_direccion
    f.write("DROP TABLE IF EXISTS rec_datos.v_unificacion_direccion;\n")
    f.write("CREATE TABLE rec_datos.v_unificacion_direccion (\n")
    f.write("    cod_dw_persona_ubic BIGINT,\n")
    f.write("    lote BIGINT,\n")
    f.write("    lote_actualizacion BIGINT\n")
    f.write(") DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic);\n\n")
    write_batch_inserts(f, 'rec_datos.v_unificacion_direccion', v_unificacion_direccion_rows)
    f.write("\n")

    # ==========================================================
    # 8. HASH TABLES
    # ==========================================================
    f.write("-- ============================================================\n")
    f.write("-- 8. HASH TABLES (pre-existing for change detection)\n")
    f.write("-- ============================================================\n\n")

    # cuenta_atributo_hash
    f.write("DROP TABLE IF EXISTS rec_datos.cuenta_atributo_hash;\n")
    f.write("CREATE TABLE rec_datos.cuenta_atributo_hash (\n")
    f.write("    cod_pin_persona INTEGER,\n")
    f.write("    id_buro_persona INTEGER,\n")
    f.write("    cod_dw_cta BIGINT,\n")
    f.write("    concatena VARCHAR(4000),\n")
    f.write("    cod_hash VARCHAR(32),\n")
    f.write("    fecha_insercion DATE\n")
    f.write(") DISTSTYLE KEY DISTKEY(id_buro_persona);\n\n")
    write_batch_inserts(f, 'rec_datos.cuenta_atributo_hash', cuenta_hash_rows)
    f.write("\n")

    # ubicacion_atributo_hash
    f.write("DROP TABLE IF EXISTS rec_datos.ubicacion_atributo_hash;\n")
    f.write("CREATE TABLE rec_datos.ubicacion_atributo_hash (\n")
    f.write("    cod_pin_persona INTEGER,\n")
    f.write("    id_buro_persona INTEGER,\n")
    f.write("    cod_dw_persona_ubic BIGINT,\n")
    f.write("    concatena VARCHAR(4000),\n")
    f.write("    cod_hash VARCHAR(32),\n")
    f.write("    fecha_insercion DATE,\n")
    f.write("    fecha_actualizacion DATE\n")
    f.write(") DISTSTYLE KEY DISTKEY(id_buro_persona);\n\n")
    write_batch_inserts(f, 'rec_datos.ubicacion_atributo_hash', ubicacion_hash_rows)
    f.write("\n")

    # ==========================================================
    # 9. STAGE TABLES
    # ==========================================================
    f.write("-- ============================================================\n")
    f.write("-- 9. STAGE TABLES\n")
    f.write("-- ============================================================\n\n")

    # personas_raw (for deduplication test)
    f.write("DROP TABLE IF EXISTS rec_stage.personas_raw;\n")
    f.write("CREATE TABLE rec_stage.personas_raw (\n")
    f.write("    cod_pin_persona INTEGER,\n")
    f.write("    id_buro_persona INTEGER\n")
    f.write(") DISTSTYLE KEY DISTKEY(id_buro_persona);\n\n")
    write_batch_inserts(f, 'rec_stage.personas_raw', personas_raw)
    f.write("\n")

    # log_ejecucion (empty, for test scripts to write into)
    f.write("DROP TABLE IF EXISTS rec_stage.log_ejecucion;\n")
    f.write("CREATE TABLE rec_stage.log_ejecucion (\n")
    f.write("    id_log BIGINT IDENTITY(1,1),\n")
    f.write("    nombre_procedimiento VARCHAR(100),\n")
    f.write("    fase VARCHAR(50),\n")
    f.write("    evento VARCHAR(20),\n")
    f.write("    timestamp_evento TIMESTAMP,\n")
    f.write("    registros_afectados BIGINT,\n")
    f.write("    mensaje_error VARCHAR(2000),\n")
    f.write("    duracion_segundos INTEGER\n")
    f.write(") DISTSTYLE ALL;\n\n")

    # ==========================================================
    # ANALYZE all tables
    # ==========================================================
    f.write("-- ============================================================\n")
    f.write("-- ANALYZE all tables\n")
    f.write("-- ============================================================\n\n")

    all_tables = [
        'rec_datos.control_ordenamiento',
        'rec_datos.metadata_carga_log',
        'rec_datos.metadata_ordenamiento',
        'rec_datos.v_razon_bloqueo',
        'rec_datos.v_fuente_dato',
        'rec_datos.v_cod_entrega_dato',
        'rec_datos.v_gestion_registro',
        'rec_datos.v_tipo_ubicacion_direccion',
        'rec_datos.v_tipo_persona',
        'rec_datos.v_tipo_cuenta',
        'rec_datos.v_fuente',
        'rec_datos.v_geografia',
        'rec_datos.v_buro_persona',
        'rec_datos.vu_cuenta',
        'rec_datos.vu_persona',
        'rec_datos.vu_comportamiento_cta_activo',
        'rec_datos.vu_comportamiento_cta_pasivo',
        'rec_datos.v_comportamiento_cuenta',
        'rec_datos.v_comportamiento_cuenta_activo',
        'rec_datos.v_comportamiento_cuenta_pasivo',
        'rec_datos.relacion_persona_ubicacion',
        'rec_datos.v_relacion_persona_ubicacion',
        'rec_datos.mat_reporte_rel_pers_ubi',
        'rec_datos.v_ubicacion_estandarizada',
        'rec_datos.direccion_fisica',
        'rec_datos.relacion_ubicac_estandar_geo',
        'rec_datos.bloqueo',
        'rec_datos.v_bloqueo',
        'rec_datos.log_td',
        'rec_datos.v_reporte_ubicacion_original',
        'rec_datos.vu_relacion_persona_ubicacion',
        'rec_datos.vu_reporte_relacion_pers_ubi',
        'rec_datos.v_ubicacion_original',
        'rec_datos.v_log_ubicacion_estandariza',
        'rec_datos.v_relacion_ubicac_estandar_geo',
        'rec_datos.v_unificacion_direccion',
        'rec_datos.cuenta_atributo_hash',
        'rec_datos.ubicacion_atributo_hash',
        'rec_stage.personas_raw',
        'rec_stage.log_ejecucion',
    ]
    for tbl in all_tables:
        f.write(f"ANALYZE {tbl};\n")

    f.write("\n-- ============================================================\n")
    f.write("-- FIN del dataset sintetico completo\n")
    f.write("-- ============================================================\n")

# ============================================================
# Final stats
# ============================================================
file_size = os.path.getsize(OUT_FILE)
print(f"\nDataset generado exitosamente:")
print(f"  Archivo: {OUT_FILE}")
print(f"  Tamano: {file_size / 1024 / 1024:.1f} MB")
print(f"  Personas: {NUM_PERSONAS}")
print(f"  Cuentas (vu_cuenta): {len(vu_cuenta_rows)}")
print(f"  Ubicaciones: {len(relacion_persona_ubicacion_rows)}")
print(f"  Comportamiento activo: {len(comportamiento_activo_rows)}")
print(f"  Comportamiento pasivo: {len(comportamiento_pasivo_rows)}")
print(f"  Reportes mat: {len(mat_reporte_rel_pers_ubi_rows)}")
print(f"  Bloqueos: {len(bloqueo_rows)}")
print(f"  Hashes cuenta: {len(cuenta_hash_rows)}")
print(f"  Hashes ubicacion: {len(ubicacion_hash_rows)}")
print(f"  Lotes metadata: {NUM_LOTES}")
print(f"  personas_raw: {len(personas_raw)}")
