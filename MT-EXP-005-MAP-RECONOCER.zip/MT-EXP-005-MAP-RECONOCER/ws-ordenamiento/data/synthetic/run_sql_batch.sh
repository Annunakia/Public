#!/bin/bash
# ==============================================================================
# run_sql_batch.sh — Ejecuta un archivo SQL completo como un solo statement
# Usa el contenido del archivo directamente (max 100KB).
# Para archivos con múltiples sentencias separadas por ';'.
# Uso: ./run_sql_batch.sh <archivo.sql> [label]
# Exit: 0=éxito, 1=error
# ==============================================================================

PROFILE="sandbox"
REGION="us-east-1"
WORKGROUP="experian-sandbox-trunk-ddm-xpm-workgroup"
DB="dev"

SQL_FILE="$1"
LABEL="${2:-$(basename "$SQL_FILE" .sql)}"

if [[ -z "$SQL_FILE" || ! -f "$SQL_FILE" ]]; then
  echo "ERROR: Archivo no encontrado: $SQL_FILE"
  exit 1
fi

# Read file content
SQL=$(cat "$SQL_FILE")

if [[ -z "$SQL" ]]; then
  echo "[$LABEL] WARN: Archivo vacío"
  exit 0
fi

# Check size (Data API limit is 100KB)
SIZE=$(wc -c < "$SQL_FILE")
if [[ $SIZE -gt 102400 ]]; then
  echo "[$LABEL] ERROR: Archivo excede 100KB ($SIZE bytes)"
  exit 1
fi

# Execute via Data API
ID=$(aws redshift-data execute-statement \
  --workgroup-name "$WORKGROUP" --database "$DB" \
  --sql "$SQL" --profile "$PROFILE" --region "$REGION" \
  --query 'Id' --output text 2>&1)

if [[ "$ID" == *"ERROR"* || "$ID" == *"error"* ]]; then
  echo "[$LABEL] ERROR ejecutando: $ID"
  exit 1
fi

# Polling cada 3s, timeout 300s (100 iteraciones × 3s)
for i in $(seq 1 100); do
  STATUS=$(aws redshift-data describe-statement --id "$ID" \
    --profile "$PROFILE" --region "$REGION" \
    --query 'Status' --output text 2>/dev/null)

  if [[ "$STATUS" == "FINISHED" ]]; then
    echo "[$LABEL] OK"
    exit 0
  elif [[ "$STATUS" == "FAILED" || "$STATUS" == "ABORTED" ]]; then
    ERR=$(aws redshift-data describe-statement --id "$ID" \
      --profile "$PROFILE" --region "$REGION" \
      --query 'Error' --output text 2>/dev/null)
    echo "[$LABEL] FAILED: $ERR"
    exit 1
  fi
  sleep 3
done

echo "[$LABEL] TIMEOUT (300s)"
exit 1
