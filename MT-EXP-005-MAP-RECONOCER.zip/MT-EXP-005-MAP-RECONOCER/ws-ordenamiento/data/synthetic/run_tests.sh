#!/bin/bash
# ==============================================================================
# run_tests.sh — Orquestador maestro del pipeline de pruebas Ordenamiento 242
# Ejecuta: shared → split → load batches → Fase1 → validate1 → Fase2 →
#           validate2 → Fase3 → validate3 → resumen
#
# Flags:
#   --skip-load       Salta la carga del dataset (asume ya cargado)
#   --skip-to-fase N  Salta directamente a fase N (asume fases previas OK)
#   --cleanup-only    Solo ejecuta limpieza
#
# Exit: 0=todo OK, 1=algún paso falló
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SQL_DIR="$SCRIPT_DIR/../../src/redshift"

# ==============================================================================
# Parsear argumentos
# ==============================================================================
SKIP_LOAD=0
SKIP_TO_FASE=0
CLEANUP_ONLY=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --skip-load)
      SKIP_LOAD=1
      shift
      ;;
    --skip-to-fase)
      SKIP_TO_FASE="$2"
      shift 2
      ;;
    --cleanup-only)
      CLEANUP_ONLY=1
      shift
      ;;
    *)
      echo "Flag desconocido: $1"
      echo "Uso: $0 [--skip-load] [--skip-to-fase N] [--cleanup-only]"
      exit 1
      ;;
  esac
done

# ==============================================================================
# Utilidades
# ==============================================================================
STEP_TIMES=()
STEP_NAMES=()
STEP_RESULTS=()
TOTAL_START=$(date +%s)

run_step() {
  local STEP_NAME="$1"
  local STEP_CMD="$2"

  local START=$(date +%s)
  echo ""
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "[STEP] $STEP_NAME"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  eval "$STEP_CMD"
  local EXIT_CODE=$?

  local END=$(date +%s)
  local ELAPSED=$((END - START))

  STEP_NAMES+=("$STEP_NAME")
  STEP_TIMES+=("${ELAPSED}s")

  if [[ $EXIT_CODE -eq 0 ]]; then
    echo "[STEP] $STEP_NAME — OK (${ELAPSED}s)"
    STEP_RESULTS+=("OK")
    return 0
  else
    echo "[STEP] $STEP_NAME — FAILED (${ELAPSED}s)"
    STEP_RESULTS+=("FAILED")
    return 1
  fi
}

print_summary() {
  local TOTAL_END=$(date +%s)
  local TOTAL_ELAPSED=$((TOTAL_END - TOTAL_START))

  echo ""
  echo "╔══════════════════════════════════════════════════════════════"
  echo "║ RESUMEN DE EJECUCIÓN"
  echo "╠══════════════════════════════════════════════════════════════"
  printf "║ %-40s %-8s %s\n" "Paso" "Estado" "Tiempo"
  echo "║ ────────────────────────────────────────────────────────────"

  for i in "${!STEP_NAMES[@]}"; do
    local ICON="✅"
    if [[ "${STEP_RESULTS[$i]}" == "FAILED" ]]; then
      ICON="❌"
    fi
    printf "║ %s %-38s %-8s %s\n" "$ICON" "${STEP_NAMES[$i]}" "${STEP_RESULTS[$i]}" "${STEP_TIMES[$i]}"
  done

  echo "╠══════════════════════════════════════════════════════════════"
  echo "║ Tiempo total: ${TOTAL_ELAPSED}s"
  echo "╚══════════════════════════════════════════════════════════════"
}

# ==============================================================================
# Cleanup only
# ==============================================================================
if [[ $CLEANUP_ONLY -eq 1 ]]; then
  echo "=== Ejecutando solo limpieza ==="
  run_step "Cleanup" "$SCRIPT_DIR/run_sql_file.sh $SCRIPT_DIR/cleanup_test.sql"
  print_summary
  exit $?
fi

# ==============================================================================
# Pipeline principal
# ==============================================================================

echo ""
echo "╔══════════════════════════════════════════════════════════════"
echo "║ PIPELINE DE PRUEBAS — Ordenamiento 242"
echo "║ Dataset: 10K personas (seed=42)"
echo "║ Ambiente: experian-sandbox-dev-redshift-workgroup"
echo "╚══════════════════════════════════════════════════════════════"
echo ""
echo "  Flags: skip-load=$SKIP_LOAD, skip-to-fase=$SKIP_TO_FASE"
echo ""

# ------------------------------------------------------------------------------
# Paso 1: Infraestructura (shared)
# ------------------------------------------------------------------------------
if [[ $SKIP_TO_FASE -eq 0 ]]; then

  run_step "Shared: schemas + tablas control" \
    "$SCRIPT_DIR/run_sql_file.sh $SQL_DIR/shared/00_schemas_tablas_control.sql"
  if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

  run_step "Shared: log_ejecucion" \
    "$SCRIPT_DIR/run_sql_file.sh $SQL_DIR/shared/01_log_ejecucion.sql"
  if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

  # ----------------------------------------------------------------------------
  # Paso 2: Split y carga del dataset
  # ----------------------------------------------------------------------------
  if [[ $SKIP_LOAD -eq 0 ]]; then

    run_step "Split dataset en batches" \
      "$SCRIPT_DIR/split_dataset.sh"
    if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

    # Cargar batches secuencialmente
    BATCH_COUNT=$(ls "$SCRIPT_DIR/batches"/batch_*.sql 2>/dev/null | wc -l)
    echo ""
    echo "  Cargando $BATCH_COUNT batches..."

    LOAD_START=$(date +%s)
    BATCH_NUM=0
    for BATCH_FILE in $(ls "$SCRIPT_DIR/batches"/batch_*.sql | sort); do
      BATCH_NUM=$((BATCH_NUM + 1))
      echo -n "    [$BATCH_NUM/$BATCH_COUNT] $(basename $BATCH_FILE) ... "

      OUTPUT=$("$SCRIPT_DIR/run_sql_file.sh" "$BATCH_FILE" 2>&1)
      if [[ $? -ne 0 ]]; then
        echo "FAILED"
        echo "$OUTPUT" | tail -5
        LOAD_END=$(date +%s)
        STEP_NAMES+=("Carga dataset ($BATCH_NUM/$BATCH_COUNT batches)")
        STEP_TIMES+=("$((LOAD_END - LOAD_START))s")
        STEP_RESULTS+=("FAILED")
        print_summary
        exit 1
      fi
      echo "OK"
    done

    LOAD_END=$(date +%s)
    STEP_NAMES+=("Carga dataset ($BATCH_COUNT batches)")
    STEP_TIMES+=("$((LOAD_END - LOAD_START))s")
    STEP_RESULTS+=("OK")
    echo "  [STEP] Carga dataset — OK ($((LOAD_END - LOAD_START))s)"

  else
    echo "  [SKIP] Carga de dataset (--skip-load)"
  fi
fi

# ------------------------------------------------------------------------------
# Paso 3: Fase 1 — Materialización
# ------------------------------------------------------------------------------
if [[ $SKIP_TO_FASE -le 1 ]]; then

  run_step "Fase 1: 01_materializa_btt" \
    "$SCRIPT_DIR/run_sql_file.sh $SQL_DIR/fase1_materializacion/01_materializa_btt.sql"
  if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

  run_step "Fase 1: 02_materializa_rec" \
    "$SCRIPT_DIR/run_sql_file.sh $SQL_DIR/fase1_materializacion/02_materializa_rec.sql"
  if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

  run_step "Fase 1: 03_unifica_btt_rec" \
    "$SCRIPT_DIR/run_sql_file.sh $SQL_DIR/fase1_materializacion/03_unifica_btt_rec.sql"
  if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

  run_step "Fase 1: 04_limpieza_validacion" \
    "$SCRIPT_DIR/run_sql_file.sh $SQL_DIR/fase1_materializacion/04_limpieza_validacion.sql"
  if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

  # Validar Fase 1
  run_step "Validación Fase 1" \
    "$SCRIPT_DIR/validate_fase1.sh"
  if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

fi

# ------------------------------------------------------------------------------
# Paso 4: Fase 2 — Atributos de Cuenta
# ------------------------------------------------------------------------------
if [[ $SKIP_TO_FASE -le 2 ]]; then

  run_step "Fase 2: 01_cta_atributos" \
    "$SCRIPT_DIR/run_sql_file.sh $SQL_DIR/fase2_atributos_cuenta/01_cta_atributos.sql"
  if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

  run_step "Fase 2: 02_cta_totales_personas" \
    "$SCRIPT_DIR/run_sql_file.sh $SQL_DIR/fase2_atributos_cuenta/02_cta_totales_personas.sql"
  if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

  run_step "Fase 2: 03_cta_totales_personas_1" \
    "$SCRIPT_DIR/run_sql_file.sh $SQL_DIR/fase2_atributos_cuenta/03_cta_totales_personas_1.sql"
  if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

  run_step "Fase 2: 04_cta_totales_personas_2" \
    "$SCRIPT_DIR/run_sql_file.sh $SQL_DIR/fase2_atributos_cuenta/04_cta_totales_personas_2.sql"
  if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

  run_step "Fase 2: 05_concat_atributos" \
    "$SCRIPT_DIR/run_sql_file.sh $SQL_DIR/fase2_atributos_cuenta/05_concat_atributos.sql"
  if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

  # Validar Fase 2
  run_step "Validación Fase 2" \
    "$SCRIPT_DIR/validate_fase2.sh"
  if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

fi

# ------------------------------------------------------------------------------
# Paso 5: Fase 3 — Ubicaciones
# ------------------------------------------------------------------------------
if [[ $SKIP_TO_FASE -le 3 ]]; then

  run_step "Fase 3: 01_ubic_direcciones" \
    "$SCRIPT_DIR/run_sql_file.sh $SQL_DIR/fase3_ubicaciones/01_ubic_direcciones.sql"
  if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

  run_step "Fase 3: 02_calc_ubicaciones" \
    "$SCRIPT_DIR/run_sql_file.sh $SQL_DIR/fase3_ubicaciones/02_calc_ubicaciones.sql"
  if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

  run_step "Fase 3: 03_calc_ubicaciones_1" \
    "$SCRIPT_DIR/run_sql_file.sh $SQL_DIR/fase3_ubicaciones/03_calc_ubicaciones_1.sql"
  if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

  run_step "Fase 3: 04_calc_ubicaciones_2" \
    "$SCRIPT_DIR/run_sql_file.sh $SQL_DIR/fase3_ubicaciones/04_calc_ubicaciones_2.sql"
  if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

  run_step "Fase 3: 05_concat_direcciones" \
    "$SCRIPT_DIR/run_sql_file.sh $SQL_DIR/fase3_ubicaciones/05_concat_direcciones.sql"
  if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

  run_step "Fase 3: 06_final_ubic_direcciones" \
    "$SCRIPT_DIR/run_sql_file.sh $SQL_DIR/fase3_ubicaciones/06_final_ubic_direcciones.sql"
  if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

  # Validar Fase 3
  run_step "Validación Fase 3" \
    "$SCRIPT_DIR/validate_fase3.sh"
  if [[ $? -ne 0 ]]; then print_summary; exit 1; fi

fi

# ==============================================================================
# Resumen final
# ==============================================================================
print_summary
echo ""
echo "🎉 Pipeline completado exitosamente"
exit 0
