-- ============================================================
-- Archivo: shared/01_log_ejecucion.sql
-- SP Original: N/A - infraestructura de logging
-- Fase: shared
-- Modo: N/A
-- Dependencias: shared/00_schemas_tablas_control.sql (schema rec_stage)
-- Input: N/A
-- Output: rec_stage.log_ejecucion
-- Requerimientos: 22.1, 22.3
-- ============================================================

-- ============================================================
-- Tabla de Log de Ejecución
-- Registra inicio, fin y errores de cada script del proceso
-- de Ordenamiento 242. Usada por todos los scripts de fase
-- para trazabilidad y detección de errores previos.
-- ============================================================

CREATE TABLE IF NOT EXISTS rec_stage.log_ejecucion (
    id_log              BIGINT IDENTITY(1,1) ENCODE AZ64,
    nombre_procedimiento VARCHAR(100)        ENCODE ZSTD,
    fase                VARCHAR(50)          ENCODE ZSTD,
    evento              VARCHAR(20)          ENCODE ZSTD,  -- INICIO, FIN, ERROR
    timestamp_evento    TIMESTAMP            ENCODE AZ64,
    registros_afectados BIGINT               ENCODE AZ64,
    mensaje_error       VARCHAR(2000)        ENCODE ZSTD,
    duracion_segundos   INTEGER              ENCODE AZ64
)
DISTSTYLE ALL;

-- ============================================================
-- Patrón de Logging — Ejemplos de referencia
-- Los siguientes INSERTs son ejemplos para copiar en cada script.
-- Cada script debe registrar INICIO al comenzar y FIN o ERROR
-- al terminar.
-- ============================================================

-- ------------------------------------------------------------
-- Ejemplo: Registro de INICIO de un script
-- (Copiar al inicio de cada script, ajustando nombre y fase)
-- ------------------------------------------------------------
-- INSERT INTO rec_stage.log_ejecucion
--     (nombre_procedimiento, fase, evento, timestamp_evento)
-- VALUES ('materializa_btt', 'Fase 1', 'INICIO', GETDATE());

-- ------------------------------------------------------------
-- Ejemplo: Registro de FIN exitoso con conteo de registros
-- (Copiar al final de cada script tras ejecución exitosa)
-- ------------------------------------------------------------
-- INSERT INTO rec_stage.log_ejecucion
--     (nombre_procedimiento, fase, evento, timestamp_evento, registros_afectados)
-- VALUES ('materializa_btt', 'Fase 1', 'FIN', GETDATE(),
--     (SELECT COUNT(*) FROM rec_stage.paso_v_cuenta));

-- ------------------------------------------------------------
-- Ejemplo: Registro de ERROR (capturado por orquestador)
-- (Usar cuando se detecta un error en la ejecución)
-- ------------------------------------------------------------
-- INSERT INTO rec_stage.log_ejecucion
--     (nombre_procedimiento, fase, evento, timestamp_evento, mensaje_error)
-- VALUES ('materializa_btt', 'Fase 1', 'ERROR', GETDATE(), 'Mensaje del error');
