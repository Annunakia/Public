-- ============================================================
-- Archivo: shared/00_schemas_tablas_control.sql
-- SP Original: N/A - infraestructura
-- Fase: shared
-- Modo: N/A
-- Dependencias: ninguna
-- Input: N/A
-- Output: rec_stage (schema), rec_datos (schema),
--         rec_datos.control_ordenamiento,
--         rec_datos.cuenta_atributo_hash,
--         rec_datos.ubicacion_atributo_hash
-- ============================================================

-- ============================================================
-- Creación de schemas
-- ============================================================

CREATE SCHEMA IF NOT EXISTS rec_stage;
CREATE SCHEMA IF NOT EXISTS rec_datos;

-- ============================================================
-- Tablas definitivas en rec_datos
-- ============================================================

-- Tabla de control de ejecución
CREATE TABLE IF NOT EXISTS rec_datos.control_ordenamiento (
    id_control              BIGINT IDENTITY(1,1) ENCODE AZ64,
    fecha_ult_ord           DATE                 ENCODE AZ64,
    fecha_ejecucion         TIMESTAMP            ENCODE AZ64,
    estado                  VARCHAR(20)          ENCODE ZSTD,
    registros_procesados    BIGINT               ENCODE AZ64
)
DISTSTYLE ALL;

-- Tabla de hash de atributos de cuenta
CREATE TABLE IF NOT EXISTS rec_datos.cuenta_atributo_hash (
    cod_pin_persona         INTEGER     ENCODE AZ64,
    id_buro_persona         INTEGER     ENCODE AZ64,
    cod_dw_cta              BIGINT      ENCODE AZ64,
    concatena               VARCHAR(4000) ENCODE ZSTD,
    cod_hash                VARCHAR(32)  ENCODE ZSTD,
    fecha_insercion         DATE         ENCODE AZ64
)
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, cod_pin_persona);

-- Tabla de hash de ubicaciones/direcciones
CREATE TABLE IF NOT EXISTS rec_datos.ubicacion_atributo_hash (
    cod_pin_persona         INTEGER      ENCODE AZ64,
    id_buro_persona         INTEGER      ENCODE AZ64,
    cod_dw_persona_ubic     BIGINT       ENCODE AZ64,
    concatena               VARCHAR(4000) ENCODE ZSTD,
    cod_hash                VARCHAR(32)   ENCODE ZSTD,
    fecha_insercion         DATE          ENCODE AZ64,
    fecha_actualizacion     DATE          ENCODE AZ64
)
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, cod_pin_persona);
