-- ============================================================
-- Archivo: _disabled/final_cta_atributos_disabled.sql
-- SP Original: PRO_ORD_FINAL_CTA_ATRIBUTOS
-- Fase: 2 - Atributos de Cuenta
-- Modo: DESHABILITADO
-- Estado: *** DISABLED — NO SE EJECUTA ***
-- Dependencias: fase2_atributos_cuenta/05_concat_atributos.sql
-- Input: rec_stage.concatena_atributos, rec_datos.v_cuenta_atributo_hash
-- Output: rec_stage.nuevos_datos_caract_atributo, rec_datos.cuenta_atributo_hash
-- Requerimientos: 19.1, 19.3
-- ============================================================
--
-- ╔══════════════════════════════════════════════════════════════╗
-- ║  ESTE SCRIPT ESTÁ DESHABILITADO — SOLO CÓDIGO DE REFERENCIA ║
-- ╚══════════════════════════════════════════════════════════════╝
--
-- RAZÓN DE DESHABILITACIÓN:
-- -------------------------
-- El SP original PRO_ORD_FINAL_CTA_ATRIBUTOS en Teradata contiene al inicio:
--
--     SET V_PASO = 1;
--     IF V_PASO > 0 THEN
--         LEAVE L1;
--     END IF;
--
-- Esto hace que la lógica NUNCA se ejecute. El SP fue deshabilitado
-- intencionalmente por Carlos Castillo el 2018-10-05 según la bitácora
-- del script ORDENAMIENTO_242_131.BTQ.
--
-- Adicionalmente, la sección de UPDATE de hashes modificados fue comentada
-- en el código original "por solicitud de Experian" — solo se implementó
-- la detección de registros NUEVOS (INSERT), no de MODIFICADOS (UPDATE).
--
-- FUNCIONALIDAD (si estuviera activo):
-- ------------------------------------
-- 1. Detecta registros NUEVOS comparando concatena_atributos contra
--    V_CUENTA_ATRIBUTO_HASH mediante LEFT JOIN WHERE IS NULL
--    (clave compuesta: cod_pin_persona, id_buro_persona, cod_dw_cta, cod_hash)
-- 2. Inserta los registros nuevos en rec_datos.cuenta_atributo_hash
--
-- ACTIVACIÓN FUTURA:
-- ------------------
-- Para activar este script:
-- 1. Mover a fase2_atributos_cuenta/06_final_cta_atributos.sql
-- 2. Descomentar la lógica SQL
-- 3. Agregar INSERT en log_ejecucion (inicio/fin)
-- 4. Incluir en el orquestador después de 05_concat_atributos.sql
-- 5. Considerar agregar lógica de UPDATE para hashes modificados
--    (similar a fase3/06_final_ubic_direcciones.sql)
--
-- ============================================================

-- ============================================================
-- LÓGICA DESHABILITADA — INICIO
-- La siguiente lógica NO se ejecuta. Se conserva como referencia
-- para una posible activación futura.
-- ============================================================

-- ------------------------------------------------------------
-- Paso 1: Detectar registros nuevos por comparación de hash
-- LEFT JOIN contra V_CUENTA_ATRIBUTO_HASH donde la clave no existe
-- (cod_pin_persona, id_buro_persona, cod_dw_cta, cod_hash)
-- Si el registro no existe en la tabla de hash → es nuevo
-- ------------------------------------------------------------

/*
DROP TABLE IF EXISTS rec_stage.nuevos_datos_caract_atributo;
CREATE TABLE rec_stage.nuevos_datos_caract_atributo
DISTSTYLE KEY DISTKEY(cod_dw_cta)
AS
SELECT a.*
FROM rec_stage.concatena_atributos a
LEFT JOIN rec_datos.v_cuenta_atributo_hash b
    ON  a.cod_pin_persona = b.cod_pin_persona
    AND a.id_buro_persona = b.id_buro_persona
    AND a.cod_dw_cta      = b.cod_dw_cta
    AND a.cod_hash        = b.cod_dw_hash
WHERE b.cod_pin_persona IS NULL
  AND b.id_buro_persona IS NULL
  AND b.cod_dw_cta      IS NULL
  AND b.cod_dw_hash     IS NULL;

ANALYZE rec_stage.nuevos_datos_caract_atributo;
*/

-- ------------------------------------------------------------
-- Paso 2: Insertar registros nuevos en tabla definitiva
-- CUENTA_ATRIBUTO_HASH almacena el hash por cuenta para
-- detección de cambios entre ejecuciones
-- ------------------------------------------------------------

/*
INSERT INTO rec_datos.cuenta_atributo_hash
    (cod_pin_persona, id_buro_persona, cod_dw_cta, concatena, cod_hash, fecha_insercion)
SELECT a.cod_pin_persona,
       a.id_buro_persona,
       a.cod_dw_cta,
       a.concatena,
       a.cod_hash,
       CURRENT_DATE
FROM rec_stage.nuevos_datos_caract_atributo a;
*/

-- ------------------------------------------------------------
-- Paso 3 (NO IMPLEMENTADO en original):
-- UPDATE de hashes modificados — comentado en el SP original
-- "Por solicitud de Experian se deja en comentario esta parte"
--
-- Si se activara, la lógica sería:
-- ------------------------------------------------------------

/*
UPDATE rec_datos.cuenta_atributo_hash dest
SET cod_hash = src.cod_hash,
    fecha_insercion = CURRENT_DATE
FROM rec_stage.concatena_atributos src
WHERE dest.cod_pin_persona = src.cod_pin_persona
  AND dest.id_buro_persona = src.id_buro_persona
  AND dest.cod_dw_cta      = src.cod_dw_cta
  AND dest.cod_hash       <> src.cod_hash;
*/

-- ============================================================
-- LÓGICA DESHABILITADA — FIN
-- ============================================================

-- NOTA: No se incluye INSERT en log_ejecucion porque este script
-- está deshabilitado y no debe ejecutarse en el flujo normal.
