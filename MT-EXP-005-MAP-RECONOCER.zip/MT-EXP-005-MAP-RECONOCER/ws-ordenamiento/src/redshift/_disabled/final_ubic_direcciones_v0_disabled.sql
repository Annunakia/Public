-- ============================================================
-- Archivo: _disabled/final_ubic_direcciones_v0_disabled.sql
-- SP Original: PRO_ORD_FINAL_UBIC_DIRECCIONES
-- Fase: 3 - Ubicaciones
-- Modo: DESHABILITADO
-- Estado: *** DISABLED — NO SE EJECUTA ***
-- Dependencias: fase3_ubicaciones/05_concat_direcciones.sql
-- Input: rec_stage.hash_carac_direc, rec_datos.ubicacion_atributo_hash
-- Output: rec_datos.ubicacion_atributo_hash (solo INSERT, sin UPDATE)
-- Requerimientos: 19.2, 19.3
-- ============================================================
--
-- ╔══════════════════════════════════════════════════════════════╗
-- ║  ESTE SCRIPT ESTÁ DESHABILITADO — SOLO CÓDIGO DE REFERENCIA ║
-- ╚══════════════════════════════════════════════════════════════╝
--
-- RAZÓN DE DESHABILITACIÓN:
-- -------------------------
-- Este SP (PRO_ORD_FINAL_UBIC_DIRECCIONES) fue reemplazado por
-- PRO_ORD_FINAL_UBIC_DIRECCIONES1, que agrega la capacidad de UPDATE
-- para registros modificados (hash existente pero diferente).
--
-- La versión original (esta) SOLO detecta registros NUEVOS e INSERT.
-- NO detecta ni actualiza registros cuyo hash cambió entre ejecuciones.
-- Esto significa que si una dirección cambia, el cambio no se refleja
-- en la tabla definitiva hasta que se ejecute la versión activa (v1).
--
-- VERSIÓN ACTIVA:
-- ---------------
-- La versión activa es PRO_ORD_FINAL_UBIC_DIRECCIONES1, migrada en:
--   fase3_ubicaciones/06_final_ubic_direcciones.sql
--
-- Diferencias clave entre v0 (esta) y v1 (activa):
--   v0: Solo INSERT de registros nuevos (LEFT JOIN WHERE IS NULL)
--   v1: INSERT de nuevos + UPDATE de modificados (hash difiere)
--
-- FUNCIONALIDAD (si estuviera activo):
-- ------------------------------------
-- 1. Detecta registros NUEVOS comparando hash_carac_direc contra
--    ubicacion_atributo_hash mediante LEFT JOIN WHERE IS NULL
--    (clave: cod_pin_persona, id_buro_persona, cod_dw_persona_ubic, cod_hash)
-- 2. Inserta los registros nuevos en rec_datos.ubicacion_atributo_hash
-- 3. NO realiza UPDATE de registros modificados (diferencia con v1)
--
-- ACTIVACIÓN FUTURA:
-- ------------------
-- NO se recomienda activar esta versión. En su lugar, usar la versión
-- activa (06_final_ubic_direcciones.sql) que incluye tanto INSERT como
-- UPDATE. Si por alguna razón se necesita solo INSERT:
-- 1. Mover a fase3_ubicaciones/ con nombre apropiado
-- 2. Descomentar la lógica SQL
-- 3. Agregar INSERT en log_ejecucion (inicio/fin)
-- 4. Incluir en el orquestador después de 05_concat_direcciones.sql
--
-- ============================================================

-- ============================================================
-- LÓGICA DESHABILITADA — INICIO
-- La siguiente lógica NO se ejecuta. Se conserva como referencia.
-- ============================================================

-- ------------------------------------------------------------
-- Paso 1: Detectar registros nuevos por comparación de hash
-- LEFT JOIN contra ubicacion_atributo_hash donde la clave no existe
-- (cod_pin_persona, id_buro_persona, cod_dw_persona_ubic, cod_hash)
-- Si el registro no existe en la tabla de hash → es nuevo
-- ------------------------------------------------------------

/*
DROP TABLE IF EXISTS rec_stage.nuevos_datos_direcciones;
CREATE TABLE rec_stage.nuevos_datos_direcciones
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  a.cod_pin_persona,
        a.id_buro_persona,
        a.cod_dw_persona_ubic,
        a.concatena,
        a.cod_hash
FROM rec_stage.hash_carac_direc a
LEFT JOIN rec_datos.ubicacion_atributo_hash b
    ON  a.cod_pin_persona     = b.cod_pin_persona
    AND a.id_buro_persona     = b.id_buro_persona
    AND a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
    AND a.cod_hash            = b.cod_hash
WHERE b.cod_pin_persona     IS NULL
  AND b.id_buro_persona     IS NULL
  AND b.cod_dw_persona_ubic IS NULL
  AND b.cod_hash            IS NULL;

ANALYZE rec_stage.nuevos_datos_direcciones;
*/

-- ------------------------------------------------------------
-- Paso 2: Insertar registros nuevos en tabla definitiva
-- UBICACION_ATRIBUTO_HASH almacena el hash por dirección para
-- detección de cambios entre ejecuciones
-- ------------------------------------------------------------

/*
INSERT INTO rec_datos.ubicacion_atributo_hash
    (cod_pin_persona, id_buro_persona, cod_dw_persona_ubic, concatena, cod_hash, fecha_insercion)
SELECT  a.cod_pin_persona,
        a.id_buro_persona,
        a.cod_dw_persona_ubic,
        a.concatena,
        a.cod_hash,
        CURRENT_DATE
FROM rec_stage.nuevos_datos_direcciones a;
*/

-- ------------------------------------------------------------
-- Paso 3 (NO EXISTE en esta versión):
-- UPDATE de hashes modificados — NO IMPLEMENTADO
--
-- Esta es la diferencia clave con PRO_ORD_FINAL_UBIC_DIRECCIONES1:
-- La versión activa (v1) agrega aquí un paso que detecta registros
-- cuya clave existe pero cuyo hash difiere, y ejecuta UPDATE.
--
-- Si se necesita esta funcionalidad, usar la versión activa:
--   fase3_ubicaciones/06_final_ubic_direcciones.sql
-- ------------------------------------------------------------

-- ============================================================
-- LÓGICA DESHABILITADA — FIN
-- ============================================================

-- NOTA: No se incluye INSERT en log_ejecucion porque este script
-- está deshabilitado y no debe ejecutarse en el flujo normal.
