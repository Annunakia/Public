-- ============================================================
-- Archivo: fase2_atributos_cuenta/01_cta_atributos.sql
-- SP Original: PRO_ORD_CTA_ATRIBUTOS
-- Fase: 2 - Atributos de Cuenta
-- Modo: Paralelo (con fase3_ubicaciones/01_ubic_direcciones.sql)
-- Dependencias: fase1_materializacion/03_unifica_btt_rec.sql
-- Input: rec_stage.unifica_btt_reconocer,
--        rec_datos.vu_cuenta,
--        rec_datos.v_razon_bloqueo,
--        rec_datos.v_fuente_dato,
--        rec_datos.v_cod_entrega_dato
-- Output: rec_stage.cta_totales_personas_tmp1
-- Requerimientos: 5.1, 5.2, 5.3, 16.1, 20.3, 22.3
-- ============================================================
-- Objetivo: Extrae todas las cuentas de las personas identificadas
--           en unifica_btt_reconocer desde VU_CUENTA y las enriquece
--           con datos de razón de bloqueo, fuente de dato y código
--           de entrega. Genera la tabla base cta_totales_personas_tmp1
--           con ~55 columnas de atributos de cuenta.
-- ============================================================

-- ------------------------------------------------------------
-- Registro de INICIO
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento)
VALUES ('cta_atributos', 'Fase 2', 'INICIO', GETDATE());

-- ============================================================
-- Paso 1: Extraer cuentas de personas a ordenar (tabla intermedia)
-- Selecciona todas las cuentas de VU_CUENTA para las personas
-- presentes en unifica_btt_reconocer. Incluye columnas calculadas
-- (Valor_Score, Ind_Rel_Suscriptor, Ind_TEC_Score, cod_suscriptor).
-- ============================================================
DROP TABLE IF EXISTS rec_stage.cta_totales_personas_tmp1_ant;
CREATE TABLE rec_stage.cta_totales_personas_tmp1_ant
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  b.cod_dw_cta,
        b.cod_dw_tipo_cta,
        b.cod_tipo_cta_fte,
        b.num_cta,
        b.id_buro_suscriptor,
        b.nit_suscriptor,
        b.id_buro_cliente,
        b.cod_pin_persona,
        b.cod_tipo_ident_fte,
        b.num_ident,
        b.cod_dw_doc_ident,
        b.num_contr,
        b.fecha_apertura,
        b.fecha_vencimiento,
        b.ind_moneda_legal,
        b.cod_dw_est_mod,
        b.cod_est_mod_fte,
        b.ind_tarjeta_amparada,
        b.nombre_ciudad_radicacion,
        b.cod_dw_razon_bloqueo,
        b.num_plastico,
        b.cod_dw_clase_tarjeta_credito,
        b.cod_clase_tarjeta_credito_fte,
        b.cod_dw_franquicia,
        b.cod_franquicia_fte,
        b.cod_marca_privada_fte,
        b.cod_dw_tipo_rel_con_cta,
        b.cod_tipo_rel_con_cta_fte,
        b.cod_dw_motivo_origen,
        b.cod_motivo_origen_fte,
        b.cod_dw_tipo_obligacion,
        b.cod_tipo_obligacion_fte,
        b.cod_dw_clase_cta,
        b.cod_clase_cta_fte,
        b.cod_dw_clase_garantia_buro,
        b.cod_clase_garantia_buro_fte,
        b.cod_dw_tipo_bloqueo,
        b.cod_tipo_bloqueo_fte,
        b.fecha_ultima_actualizacion,
        b.cod_dw_pais,
        b.cod_pais_geo_fte,
        b.cod_dw_fte_dato,
        b.cod_dw_evento_entrega_dato,
        b.nombre_cod_entrega_dato,
        b.desc_cod_entrega_dato,
        b.cod_entrega_dato_fte,
        b.cod_nov_buro_fte,
        b.desc_est_vigencia,
        b.fecha_ultima_actualizacion_nov,
        b.cod_dw_est_suscriptor,
        b.fecha_est,
        b.cod_est_suscriptor_fte,
        b.cod_motivo_bloqueo_fte,
        b.cod_dw_natu_cta,
        b.cod_natu_cta_fte,
        b.fecha_nov,
        b.cod_calif_comp_cta_fte,
        b.id_buro_cliente                   AS id_buro_persona,
        CAST(NULL AS DECIMAL(18,4))         AS valor_score,
        CAST(NULL AS CHAR(1))               AS ind_rel_suscriptor,
        CAST(NULL AS CHAR(1))               AS ind_tec_score,
        b.cod_entrega_dato_fte              AS cod_suscriptor,
        b.cod_dw_entrega_dato
FROM rec_datos.vu_cuenta b
WHERE b.id_buro_cliente IN (
    SELECT id_buro_persona
    FROM rec_stage.unifica_btt_reconocer
);
ANALYZE rec_stage.cta_totales_personas_tmp1_ant;

-- ============================================================
-- Paso 2: Enriquecer con LEFT JOINs a tablas de referencia
-- Cruza la tabla intermedia con V_Razon_Bloqueo, V_FUENTE_DATO
-- y V_COD_ENTREGA_DATO para agregar columnas de enriquecimiento.
-- Genera la tabla final cta_totales_personas_tmp1.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.cta_totales_personas_tmp1;
CREATE TABLE rec_stage.cta_totales_personas_tmp1
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  b.cod_dw_cta,
        b.cod_dw_tipo_cta,
        b.cod_tipo_cta_fte,
        b.num_cta,
        b.id_buro_suscriptor,
        b.nit_suscriptor,
        b.id_buro_cliente,
        b.cod_pin_persona,
        b.cod_tipo_ident_fte,
        b.num_ident,
        b.cod_dw_doc_ident,
        b.num_contr,
        b.fecha_apertura,
        b.fecha_vencimiento,
        b.ind_moneda_legal,
        b.cod_dw_est_mod,
        b.cod_est_mod_fte,
        b.ind_tarjeta_amparada,
        b.nombre_ciudad_radicacion,
        b.cod_dw_razon_bloqueo,
        b.num_plastico,
        b.cod_dw_clase_tarjeta_credito,
        b.cod_clase_tarjeta_credito_fte,
        b.cod_dw_franquicia,
        b.cod_franquicia_fte,
        b.cod_marca_privada_fte,
        b.cod_dw_tipo_rel_con_cta,
        b.cod_tipo_rel_con_cta_fte,
        b.cod_dw_motivo_origen,
        b.cod_motivo_origen_fte,
        b.cod_dw_tipo_obligacion,
        b.cod_tipo_obligacion_fte,
        b.cod_dw_clase_cta,
        b.cod_clase_cta_fte,
        b.cod_dw_clase_garantia_buro,
        b.cod_clase_garantia_buro_fte,
        b.cod_dw_tipo_bloqueo,
        b.cod_tipo_bloqueo_fte,
        b.fecha_ultima_actualizacion,
        b.cod_dw_pais,
        b.cod_pais_geo_fte,
        b.cod_dw_fte_dato,
        b.cod_dw_evento_entrega_dato,
        b.nombre_cod_entrega_dato,
        b.desc_cod_entrega_dato,
        b.cod_entrega_dato_fte,
        b.cod_nov_buro_fte,
        b.desc_est_vigencia,
        b.fecha_ultima_actualizacion_nov,
        b.cod_dw_est_suscriptor,
        b.fecha_est,
        b.cod_est_suscriptor_fte,
        b.cod_motivo_bloqueo_fte,
        b.cod_dw_natu_cta,
        b.cod_natu_cta_fte,
        b.fecha_nov,
        b.cod_calif_comp_cta_fte,
        b.id_buro_persona,
        c.cod_razon_bloqueo_fte,
        d.cod_fte_dato_fte,
        e.fecha_ingreso_suscriptor,
        b.valor_score,
        b.ind_rel_suscriptor,
        b.ind_tec_score,
        b.cod_suscriptor
FROM rec_stage.cta_totales_personas_tmp1_ant b
LEFT JOIN rec_datos.v_razon_bloqueo c
    ON b.cod_dw_razon_bloqueo = c.cod_dw_razon_bloqueo
LEFT JOIN rec_datos.v_fuente_dato d
    ON b.cod_dw_fte_dato = d.cod_dw_fte_dato
LEFT JOIN rec_datos.v_cod_entrega_dato e
    ON b.cod_dw_entrega_dato = e.cod_dw_entrega_dato;
ANALYZE rec_stage.cta_totales_personas_tmp1;

-- ============================================================
-- Paso 3: Limpieza de tabla intermedia
-- Elimina la tabla auxiliar que ya no se necesita.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.cta_totales_personas_tmp1_ant;

-- ------------------------------------------------------------
-- Registro de FIN exitoso
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento, registros_afectados)
VALUES ('cta_atributos', 'Fase 2', 'FIN', GETDATE(),
    (SELECT COUNT(*) FROM rec_stage.cta_totales_personas_tmp1));
