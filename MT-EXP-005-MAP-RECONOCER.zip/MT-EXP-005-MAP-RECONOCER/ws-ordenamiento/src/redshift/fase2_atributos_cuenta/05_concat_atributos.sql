-- ============================================================
-- Archivo: fase2_atributos_cuenta/05_concat_atributos.sql
-- SP Original: PRO_ORD_CONCAT_ATRIBUTOS
-- Fase: 2 - Atributos de Cuenta
-- Modo: Secuencial (depende de 04_cta_totales_personas_2.sql)
-- Dependencias: fase2_atributos_cuenta/04_cta_totales_personas_2.sql
-- Input: rec_stage.cta_totales_personas_tmp3
-- Output: rec_stage.concatena_atributos
-- Requerimientos: 13.1, 13.2, 13.3, 17.4, 20.3, 22.3
-- ============================================================
-- Objetivo: Concatena ~20 atributos numéricos de cuenta en un solo
--           string y calcula el hash MD5 para detección de cambios.
--           Genera la tabla CONCATENA_ATRIBUTOS con las columnas
--           originales más Concatena (string concatenado) y cod_hash
--           (hash MD5 de 32 caracteres).
--
-- Conversiones Teradata → Redshift aplicadas:
--   - CREATE MULTISET TABLE ... WITH DATA → DROP IF EXISTS + CREATE TABLE AS
--   - PRIMARY INDEX(Cod_DW_Cta) → DISTKEY(id_buro_persona)
--   - COLLECT STATISTICS → ANALYZE
--   - rec_vista.hash_md5(concatena) → MD5(concatena) nativo Redshift
--   - SQL dinámico (SP_EXECSTRING_DES) → SQL estático inline
--   - Esquemas dinámicos (P_BDSTAGE) → esquema fijo rec_stage
-- ============================================================

-- ------------------------------------------------------------
-- Registro de INICIO
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento)
VALUES ('concat_atributos', 'Fase 2', 'INICIO', GETDATE());

-- ============================================================
-- Paso 1: Crear tabla CONCATENA_ATRIBUTOS
-- Concatena atributos de cuenta y comportamiento en un solo string.
-- Calcula hash MD5 del string concatenado para detección de cambios.
--
-- Atributos concatenados (en orden):
--   1. cod_dw_tipo_cta           - Tipo de cuenta (DW)
--   2. cod_tipo_cta_fte          - Tipo de cuenta (fuente)
--   3. cod_dw_est_mod            - Estado modificado (DW)
--   4. cod_est_mod_fte           - Estado modificado (fuente)
--   5. cod_dw_razon_bloqueo      - Razón de bloqueo (DW)
--   6. cod_dw_tipo_rel_con_cta   - Tipo relación con cuenta (DW)
--   7. cod_tipo_rel_con_cta_fte  - Tipo relación con cuenta (fuente)
--   8. cod_dw_tipo_obligacion    - Tipo obligación (DW)
--   9. cod_tipo_obligacion_fte   - Tipo obligación (fuente)
--  10. cod_dw_clase_cta          - Clase de cuenta (DW)
--  11. cod_clase_cta_fte         - Clase de cuenta (fuente)
--  12. cod_dw_clase_garantia_buro - Clase garantía buró (DW)
--  13. cod_clase_garantia_buro_fte - Clase garantía buró (fuente)
--  14. cod_dw_tipo_bloqueo       - Tipo de bloqueo (DW)
--  15. cod_tipo_bloqueo_fte      - Tipo de bloqueo (fuente)
--  16. num_cuotas_pactadas       - Número de cuotas pactadas
--  17. portafolio                - Clasificación de portafolio
--  18. portafolio_nuevo          - Clasificación de portafolio nuevo
--  19. sector                    - Sector
--  20. valor_saldo               - Saldo de la cuenta
--  21. valor_saldo_mora          - Saldo en mora
--  22. num_cuotas_mora           - Número de cuotas en mora
--  23. valor_inicial             - Valor inicial
--  24. valor_cuota_mensual       - Valor cuota mensual
--  25. numero_dias_mora          - Número de días en mora
--  26. num_cuotas_pagadas        - Número de cuotas pagadas
--  27. valor_disponible          - Valor disponible
--  28. valor_debitos_efec        - Valor débitos efectivos
--  29. valor_creditos_efec       - Valor créditos efectivos
--  30. valor_debitos_transf      - Valor débitos transferencia
--  31. valor_creditos_transf     - Valor créditos transferencia
--  32. valor_cheques_pags        - Valor cheques pagados
--  33. valor_cheques_devs        - Valor cheques devueltos
--  34. valor_score               - Score calculado
--  35. ind_rel_suscriptor        - Indicador relación suscriptor
--  36. ind_tec_score             - Indicador TEC score
-- ============================================================
DROP TABLE IF EXISTS rec_stage.concatena_atributos;
CREATE TABLE rec_stage.concatena_atributos
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  a.cod_pin_persona,
        a.id_buro_persona,
        a.cod_dw_cta,
        -- String concatenado de atributos de cuenta
        COALESCE(CAST(a.cod_dw_tipo_cta AS VARCHAR(100)), '')
        || COALESCE(CAST(a.cod_tipo_cta_fte AS VARCHAR(100)), '')
        || COALESCE(CAST(a.cod_dw_est_mod AS VARCHAR(100)), '')
        || COALESCE(CAST(a.cod_est_mod_fte AS VARCHAR(100)), '')
        || COALESCE(CAST(a.cod_dw_razon_bloqueo AS VARCHAR(100)), '')
        || COALESCE(CAST(a.cod_dw_tipo_rel_con_cta AS VARCHAR(100)), '')
        || COALESCE(CAST(a.cod_tipo_rel_con_cta_fte AS VARCHAR(100)), '')
        || COALESCE(CAST(a.cod_dw_tipo_obligacion AS VARCHAR(100)), '')
        || COALESCE(CAST(a.cod_tipo_obligacion_fte AS VARCHAR(100)), '')
        || COALESCE(CAST(a.cod_dw_clase_cta AS VARCHAR(100)), '')
        || COALESCE(CAST(a.cod_clase_cta_fte AS VARCHAR(100)), '')
        || COALESCE(CAST(a.cod_dw_clase_garantia_buro AS VARCHAR(100)), '')
        || COALESCE(CAST(a.cod_clase_garantia_buro_fte AS VARCHAR(100)), '')
        || COALESCE(CAST(a.cod_dw_tipo_bloqueo AS VARCHAR(100)), '')
        || COALESCE(CAST(a.cod_tipo_bloqueo_fte AS VARCHAR(100)), '')
        || COALESCE(CAST(a.num_cuotas_pactadas AS VARCHAR(100)), '')
        || COALESCE(CAST(a.portafolio AS VARCHAR(100)), '')
        || COALESCE(CAST(a.portafolio_nuevo AS VARCHAR(100)), '')
        || COALESCE(CAST(a.sector AS VARCHAR(100)), '')
        || COALESCE(CAST(a.valor_saldo AS VARCHAR(100)), '')
        || COALESCE(CAST(a.valor_saldo_mora AS VARCHAR(100)), '')
        || COALESCE(CAST(a.num_cuotas_mora AS VARCHAR(100)), '')
        || COALESCE(CAST(a.valor_inicial AS VARCHAR(100)), '')
        || COALESCE(CAST(a.valor_cuota_mensual AS VARCHAR(100)), '')
        || COALESCE(CAST(a.numero_dias_mora AS VARCHAR(100)), '')
        || COALESCE(CAST(a.num_cuotas_pagadas AS VARCHAR(100)), '')
        || COALESCE(CAST(a.valor_disponible AS VARCHAR(100)), '')
        || COALESCE(CAST(a.valor_debitos_efec AS VARCHAR(100)), '')
        || COALESCE(CAST(a.valor_creditos_efec AS VARCHAR(100)), '')
        || COALESCE(CAST(a.valor_debitos_transf AS VARCHAR(100)), '')
        || COALESCE(CAST(a.valor_creditos_transf AS VARCHAR(100)), '')
        || COALESCE(CAST(a.valor_cheques_pags AS VARCHAR(100)), '')
        || COALESCE(CAST(a.valor_cheques_devs AS VARCHAR(100)), '')
        || COALESCE(CAST(a.valor_score AS VARCHAR(100)), '')
        || COALESCE(CAST(a.ind_rel_suscriptor AS VARCHAR(100)), '')
        || COALESCE(CAST(a.ind_tec_score AS VARCHAR(100)), '')
        AS concatena,
        -- Hash MD5 del string concatenado (reemplaza rec_vista.hash_md5)
        MD5(
            COALESCE(CAST(a.cod_dw_tipo_cta AS VARCHAR(100)), '')
            || COALESCE(CAST(a.cod_tipo_cta_fte AS VARCHAR(100)), '')
            || COALESCE(CAST(a.cod_dw_est_mod AS VARCHAR(100)), '')
            || COALESCE(CAST(a.cod_est_mod_fte AS VARCHAR(100)), '')
            || COALESCE(CAST(a.cod_dw_razon_bloqueo AS VARCHAR(100)), '')
            || COALESCE(CAST(a.cod_dw_tipo_rel_con_cta AS VARCHAR(100)), '')
            || COALESCE(CAST(a.cod_tipo_rel_con_cta_fte AS VARCHAR(100)), '')
            || COALESCE(CAST(a.cod_dw_tipo_obligacion AS VARCHAR(100)), '')
            || COALESCE(CAST(a.cod_tipo_obligacion_fte AS VARCHAR(100)), '')
            || COALESCE(CAST(a.cod_dw_clase_cta AS VARCHAR(100)), '')
            || COALESCE(CAST(a.cod_clase_cta_fte AS VARCHAR(100)), '')
            || COALESCE(CAST(a.cod_dw_clase_garantia_buro AS VARCHAR(100)), '')
            || COALESCE(CAST(a.cod_clase_garantia_buro_fte AS VARCHAR(100)), '')
            || COALESCE(CAST(a.cod_dw_tipo_bloqueo AS VARCHAR(100)), '')
            || COALESCE(CAST(a.cod_tipo_bloqueo_fte AS VARCHAR(100)), '')
            || COALESCE(CAST(a.num_cuotas_pactadas AS VARCHAR(100)), '')
            || COALESCE(CAST(a.portafolio AS VARCHAR(100)), '')
            || COALESCE(CAST(a.portafolio_nuevo AS VARCHAR(100)), '')
            || COALESCE(CAST(a.sector AS VARCHAR(100)), '')
            || COALESCE(CAST(a.valor_saldo AS VARCHAR(100)), '')
            || COALESCE(CAST(a.valor_saldo_mora AS VARCHAR(100)), '')
            || COALESCE(CAST(a.num_cuotas_mora AS VARCHAR(100)), '')
            || COALESCE(CAST(a.valor_inicial AS VARCHAR(100)), '')
            || COALESCE(CAST(a.valor_cuota_mensual AS VARCHAR(100)), '')
            || COALESCE(CAST(a.numero_dias_mora AS VARCHAR(100)), '')
            || COALESCE(CAST(a.num_cuotas_pagadas AS VARCHAR(100)), '')
            || COALESCE(CAST(a.valor_disponible AS VARCHAR(100)), '')
            || COALESCE(CAST(a.valor_debitos_efec AS VARCHAR(100)), '')
            || COALESCE(CAST(a.valor_creditos_efec AS VARCHAR(100)), '')
            || COALESCE(CAST(a.valor_debitos_transf AS VARCHAR(100)), '')
            || COALESCE(CAST(a.valor_creditos_transf AS VARCHAR(100)), '')
            || COALESCE(CAST(a.valor_cheques_pags AS VARCHAR(100)), '')
            || COALESCE(CAST(a.valor_cheques_devs AS VARCHAR(100)), '')
            || COALESCE(CAST(a.valor_score AS VARCHAR(100)), '')
            || COALESCE(CAST(a.ind_rel_suscriptor AS VARCHAR(100)), '')
            || COALESCE(CAST(a.ind_tec_score AS VARCHAR(100)), '')
        ) AS cod_hash
FROM rec_stage.cta_totales_personas_tmp3 a;

ANALYZE rec_stage.concatena_atributos;

-- ------------------------------------------------------------
-- Registro de FIN exitoso
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento, registros_afectados)
VALUES ('concat_atributos', 'Fase 2', 'FIN', GETDATE(),
    (SELECT COUNT(*) FROM rec_stage.concatena_atributos));
