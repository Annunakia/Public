-- ============================================================
-- Archivo: fase2_atributos_cuenta/04_cta_totales_personas_2.sql
-- SP Original: PRO_ORD_CTA_TOTALES_PERSONAS_2
-- Fase: 2 - Atributos de Cuenta
-- Modo: Paralelo (depende de 02_cta_totales_personas.sql y 03_cta_totales_personas_1.sql)
-- Dependencias: fase2_atributos_cuenta/02_cta_totales_personas.sql,
--               fase2_atributos_cuenta/03_cta_totales_personas_1.sql
-- Input: rec_stage.tmp_cnta_fechas,
--        rec_datos.vu_comportamiento_cta_pasivo,
--        rec_stage.cta_totales_personas_tmp1,
--        rec_stage.stg_comportamiento_cta_activo
-- Output: rec_stage.tmp_comportamiento_pasivo (intermedia),
--         rec_stage.cta_totales_personas_tmp2 (intermedia),
--         rec_stage.cta_totales_personas_tmp3 (final con Portafolio, Portafolio_Nuevo, Sector)
-- Requerimientos: 8.1, 8.2, 8.3, 8.4, 20.3, 22.3
-- ============================================================
-- Objetivo: (1) Extrae el comportamiento pasivo dentro de la ventana de
--           12 meses. (2) Cruza CTA_TOTALES_PERSONAS_TMP1 con el
--           comportamiento activo (stg_comportamiento_cta_activo) y pasivo
--           (tmp_comportamiento_pasivo) para generar CTA_TOTALES_PERSONAS_TMP2.
--           (3) Clasifica cada cuenta en Portafolio (CO, RO, VE, HP, IN, OT,
--           CC, AH, CT), Portafolio_Nuevo y Sector usando lógica CASE WHEN
--           compleja basada en tipo de cuenta, tipo de obligación, cuotas
--           pactadas, garantía y código de suscriptor.
--
-- Conversiones Teradata → Redshift aplicadas:
--   - CREATE MULTISET TABLE ... WITH DATA → DROP IF EXISTS + CREATE TABLE AS
--   - PRIMARY INDEX(col) → DISTKEY(id_buro_persona)
--   - COLLECT STATISTICS → ANALYZE
--   - SQL dinámico (SP_EXECSTRING_DES) → SQL estático inline
--   - Esquemas dinámicos (P_BDSTAGE, P_BTTVISTA) → esquemas fijos
--   - SUBSTR(col, 1, 2) → SUBSTRING(col, 1, 2) (compatible en Redshift)
-- ============================================================

-- ------------------------------------------------------------
-- Registro de INICIO
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento)
VALUES ('cta_totales_personas_2', 'Fase 2', 'INICIO', GETDATE());

-- ============================================================
-- Paso 1: Crear tabla TMP_COMPORTAMIENTO_PASIVO
-- Cruza tmp_cnta_fechas con la vista de comportamiento de cuenta
-- pasivo. Filtra registros donde la fecha de novedad del
-- comportamiento cae dentro de la ventana de 12 meses
-- (BETWEEN fecha_nov_ini AND fecha_nov).
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_comportamiento_pasivo;
CREATE TABLE rec_stage.tmp_comportamiento_pasivo
DISTSTYLE KEY DISTKEY(cod_dw_cta)
AS
SELECT  a.cod_dw_cta,
        b.fecha_nov,
        a.valor_debitos_efec,
        a.valor_creditos_efec,
        a.valor_debitos_transf,
        a.valor_creditos_transf,
        a.valor_cheques_pags,
        a.valor_cheques_devs,
        a.cantidad_cheques_devs,
        a.cantidad_cheques_pags,
        a.dias_sobregiro_aut,
        a.valor_cupo_sobregiro_aut
FROM rec_stage.tmp_cnta_fechas b
INNER JOIN rec_datos.vu_comportamiento_cta_pasivo a
    ON b.cod_dw_cta = a.cod_dw_cta
    AND a.fecha_nov BETWEEN b.fecha_nov_ini AND b.fecha_nov;

ANALYZE rec_stage.tmp_comportamiento_pasivo;

-- ============================================================
-- Paso 2: Limpieza de tabla tmp_cnta_fechas (ya no se necesita)
-- El SP original la elimina en este punto.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_cnta_fechas;

-- ============================================================
-- Paso 3: Crear tabla CTA_TOTALES_PERSONAS_TMP2
-- Cruza CTA_TOTALES_PERSONAS_TMP1 con las tablas precalculadas
-- de comportamiento activo (stg_comportamiento_cta_activo) y
-- pasivo (tmp_comportamiento_pasivo). Agrega columnas de ambos
-- comportamientos y flags indicando si existen datos.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.cta_totales_personas_tmp2;
CREATE TABLE rec_stage.cta_totales_personas_tmp2
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  a.*,
        g.valor_inicial,
        g.valor_saldo,
        g.valor_cuota_mensual,
        g.numero_dias_mora,
        g.valor_saldo_mora,
        g.num_cuotas_pagadas,
        g.valor_disponible,
        g.num_cuotas_mora,
        g.num_cuotas_pactadas,
        g.flag_comp_cta_activo,
        h.valor_debitos_efec,
        h.valor_creditos_efec,
        h.valor_debitos_transf,
        h.valor_creditos_transf,
        h.valor_cheques_pags,
        h.valor_cheques_devs,
        h.cantidad_cheques_devs,
        h.cantidad_cheques_pags,
        h.dias_sobregiro_aut,
        h.valor_cupo_sobregiro_aut,
        CASE WHEN h.cod_dw_cta IS NOT NULL THEN 'Y' ELSE 'N' END AS flag_comp_cta_pasivo
FROM rec_stage.cta_totales_personas_tmp1 a
LEFT JOIN rec_stage.stg_comportamiento_cta_activo g
    ON a.cod_dw_cta = g.cod_dw_cta
LEFT JOIN rec_stage.tmp_comportamiento_pasivo h
    ON a.cod_dw_cta = h.cod_dw_cta;

ANALYZE rec_stage.cta_totales_personas_tmp2;

-- ============================================================
-- Paso 4: Limpieza de tablas intermedias que ya no se necesitan
-- El SP original elimina CTA_TOTALES_PERSONAS_TMP1 y
-- STG_COMPORTAMIENTO_CTA_ACTIVO en este punto.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.cta_totales_personas_tmp1;
DROP TABLE IF EXISTS rec_stage.stg_comportamiento_cta_activo;

-- ============================================================
-- Paso 5: Crear tabla CTA_TOTALES_PERSONAS_TMP3
-- Agrega las columnas de clasificación:
--   - Portafolio: CO, RO, VE, HP, IN, OT, CC, AH, CT
--   - Portafolio_Nuevo: clasificación basada en cod_suscriptor
--   - Sector: agrupación de Portafolio_Nuevo (CO, CC, RE, FI, OT)
--
-- Lógica de Portafolio:
--   1. Si tiene comportamiento pasivo (Flag_Comp_Cta_Pasivo = 'Y'):
--      - Si tipo_cta=1 y suscriptor empieza con '51' → AH (Ahorro)
--      - Si tipo_cta=1 y suscriptor NO empieza con '51' → CT (Cupo de Crédito)
--      - Otros → '--'
--   2. Si tiene comportamiento activo (Flag_Comp_Cta_Activo = 'Y'):
--      - CO: Relación con cuenta = 'C' y tipo_cta <> 2
--      - RO: tipo_cta IN (2,3) o condiciones de rotativo
--      - VE: Vehículo (garantía='1', cuotas 1-60)
--      - HP: Hipotecario (tipo_cta=13 o cuotas>60 con garantía)
--      - IN: Institucional (tipos de cuenta específicos)
--      - OT: Otros (default)
--      - CC: Cuenta Corriente (tipo_cta IN (23,24))
--   3. Si no tiene ningún comportamiento → OT
--
-- NOTA: Redshift no permite referenciar alias de columna en el mismo
-- nivel de SELECT. Se usa una subquery intermedia para calcular
-- portafolio primero, luego portafolio_nuevo, y finalmente sector.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.cta_totales_personas_tmp3;
CREATE TABLE rec_stage.cta_totales_personas_tmp3
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  sub2.*,
        -- ========================================
        -- Clasificación de SECTOR
        -- Agrupación de Portafolio_Nuevo
        -- ========================================
        CASE
            WHEN sub2.portafolio_nuevo = 'CO' THEN 'CO'
            WHEN sub2.portafolio_nuevo = 'CC' THEN 'CC'
            WHEN sub2.portafolio_nuevo IN ('RC', 'RS') THEN 'RE'
            WHEN sub2.portafolio_nuevo IN ('IN', 'RO', 'HP', 'VE', 'CP', 'FR') THEN 'FI'
            ELSE 'OT'
        END AS sector
FROM (
    SELECT  sub1.*,
            -- ========================================
            -- Clasificación de PORTAFOLIO_NUEVO
            -- Basada en cod_suscriptor (primeros 2 dígitos)
            -- y listas específicas de códigos de suscriptor
            -- ========================================
            CASE
                WHEN sub1.portafolio = 'CO' THEN 'CO'
                WHEN SUBSTRING(sub1.cod_suscriptor, 1, 2) IN ('02', '03') THEN 'RO'
                WHEN SUBSTRING(sub1.cod_suscriptor, 1, 2) = '05' THEN 'IN'
                WHEN (SUBSTRING(sub1.cod_suscriptor, 1, 2) = '04'
                      AND sub1.cod_suscriptor IN ('040003', '040076', '040909', '040301', '040131',
                                                  '040657', '040803', '040129', '040039', '042627',
                                                  '041336', '040125', '040099', '040980', '040895',
                                                  '040390', '040195', '040022', '042027', '041901',
                                                  '040249', '040368', '041409', '040142', '040218',
                                                  '040127', '040290', '040468', '040190', '041153',
                                                  '040507', '043410', '040199', '040189', '040188'))
                     OR (SUBSTRING(sub1.cod_suscriptor, 1, 2) = '05'
                         AND sub1.cod_suscriptor = '050058')
                     OR (SUBSTRING(sub1.cod_suscriptor, 1, 2) = '18'
                         AND sub1.cod_suscriptor IN ('180110', '180015', '180007', '180185',
                                                     '189905', '180151', '180114'))
                     OR (SUBSTRING(sub1.cod_suscriptor, 1, 2) = '20'
                         AND sub1.cod_suscriptor = '200059')
                     OR (SUBSTRING(sub1.cod_suscriptor, 1, 2) = '45'
                         AND sub1.cod_suscriptor IN ('450043', '450030', '450053', '450050',
                                                     '450035', '450036', '450034', '450051',
                                                     '450028', '450045', '450048', '450074',
                                                     '450032', '450052', '450031', '450042',
                                                     '450033', '450039', '450049', '450041',
                                                     '450044', '450112'))
                    THEN 'VE'
                WHEN SUBSTRING(sub1.cod_suscriptor, 1, 2) = '13' THEN 'HP'
                WHEN SUBSTRING(sub1.cod_suscriptor, 1, 2) IN ('07', '14', '17', '18', '20', '48', '49') THEN 'FR'
                WHEN SUBSTRING(sub1.cod_suscriptor, 1, 2) IN ('23', '24') THEN 'CC'
                WHEN SUBSTRING(sub1.cod_suscriptor, 1, 2) IN ('06', '27') THEN 'CP'
                WHEN SUBSTRING(sub1.cod_suscriptor, 1, 2) IN ('04', '09', '10', '11', '19', '22', '28', '32', '34', '35', '37', '39', '45', '47') THEN 'RC'
                WHEN SUBSTRING(sub1.cod_suscriptor, 1, 2) IN ('08', '12', '15', '16', '21', '25', '26', '29', '30', '31', '33', '36', '38', '40', '41', '42', '43', '44', '46') THEN 'RS'
                WHEN SUBSTRING(sub1.cod_suscriptor, 1, 2) IN ('51', '01') THEN 'CT'
                ELSE 'OT'
            END AS portafolio_nuevo
    FROM (
        SELECT  a.*,
                -- ========================================
                -- Clasificación de PORTAFOLIO
                -- ========================================
                CASE
                    WHEN a.flag_comp_cta_pasivo = 'Y' THEN
                        CASE
                            WHEN CAST(a.cod_tipo_cta_fte AS INTEGER) = 1
                                 AND SUBSTRING(a.cod_suscriptor, 1, 2) = '51'
                                THEN 'AH'
                            WHEN CAST(a.cod_tipo_cta_fte AS INTEGER) = 1
                                 AND SUBSTRING(a.cod_suscriptor, 1, 2) <> '51'
                                THEN 'CT'
                            ELSE '--'
                        END
                    ELSE
                        CASE
                            WHEN a.flag_comp_cta_activo = 'Y' THEN
                                CASE
                                    -- CO: Comercial (relación con cuenta = 'C' y tipo_cta <> 2)
                                    WHEN a.cod_tipo_rel_con_cta_fte = 'C'
                                         AND CAST(a.cod_tipo_cta_fte AS INTEGER) <> 2
                                        THEN 'CO'
                                    -- RO: Rotativo
                                    WHEN (CAST(a.cod_tipo_cta_fte AS INTEGER) IN (2, 3))
                                         OR ((CAST(a.cod_tipo_cta_fte AS INTEGER) IN (5, 6, 27, 49))
                                             AND (CAST(a.cod_tipo_obligacion_fte AS INTEGER) = 2
                                                  AND a.num_cuotas_pactadas = 0
                                                  AND a.cod_clase_garantia_buro_fte <> '1'))
                                         OR (CAST(a.cod_tipo_cta_fte AS INTEGER) = 18
                                             AND (CAST(a.cod_tipo_obligacion_fte AS INTEGER) = 2
                                                  AND a.num_cuotas_pactadas = 0
                                                  AND a.cod_clase_garantia_buro_fte <> '1'))
                                        THEN 'RO'
                                    -- VE: Vehículo (garantía='1', cuotas entre 1 y 60)
                                    WHEN (((CAST(a.cod_tipo_cta_fte AS INTEGER) IN (5, 6, 7, 8, 18, 27, 49))
                                               AND CAST(a.cod_tipo_obligacion_fte AS INTEGER) = 2)
                                          OR (CAST(a.cod_tipo_cta_fte AS INTEGER) = 18
                                              AND CAST(a.cod_tipo_obligacion_fte AS INTEGER) = 1))
                                         AND a.num_cuotas_pactadas BETWEEN 1 AND 60
                                         AND a.cod_clase_garantia_buro_fte = '1'
                                        THEN 'VE'
                                    -- HP: Hipotecario (tipo_cta=13 o cuotas>60 con garantía)
                                    WHEN CAST(a.cod_tipo_cta_fte AS INTEGER) = 13
                                         OR ((CAST(a.cod_tipo_cta_fte AS INTEGER) IN (5, 6, 7, 8, 27, 49))
                                             AND (CAST(a.cod_tipo_obligacion_fte AS INTEGER) = 3
                                                  OR (a.num_cuotas_pactadas > 60
                                                      AND a.cod_clase_garantia_buro_fte = '1')))
                                        THEN 'HP'
                                    -- IN: Institucional
                                    WHEN CAST(a.cod_tipo_cta_fte AS INTEGER) IN (5, 6, 7, 8, 9, 14, 18, 27, 33, 46, 49)
                                        THEN 'IN'
                                    -- OT: Otros (condiciones específicas)
                                    WHEN ((CAST(a.cod_tipo_cta_fte AS INTEGER) IN (4, 9, 10, 11, 15, 16, 19, 20, 21, 22, 26, 28, 29, 34, 35, 36, 43, 44, 45)
                                               AND CAST(a.cod_tipo_obligacion_fte AS INTEGER) = 2)
                                          OR (CAST(a.cod_tipo_cta_fte AS INTEGER) IN (15, 16)
                                              AND CAST(a.cod_tipo_obligacion_fte AS INTEGER) = 3))
                                         OR (((CAST(a.cod_tipo_cta_fte AS INTEGER) IN (4, 9, 10, 11, 19, 20, 21, 22, 26, 28, 29, 34, 35, 36, 43, 44, 45))
                                                  AND CAST(a.cod_tipo_obligacion_fte AS INTEGER) <> 2)
                                             OR ((CAST(a.cod_tipo_cta_fte AS INTEGER) IN (15, 16)
                                                  AND CAST(a.cod_tipo_obligacion_fte AS INTEGER) NOT IN (3, 2))
                                                 OR CAST(a.cod_tipo_cta_fte AS INTEGER) IN (30, 31, 32, 37, 38, 39, 41, 42)))
                                        THEN 'OT'
                                    -- CC: Cuenta Corriente
                                    WHEN CAST(a.cod_tipo_cta_fte AS INTEGER) IN (23, 24)
                                        THEN 'CC'
                                    -- Default: Otros
                                    ELSE 'OT'
                                END
                            -- Sin comportamiento activo ni pasivo → OT
                            ELSE 'OT'
                        END
                END AS portafolio
        FROM rec_stage.cta_totales_personas_tmp2 a
    ) sub1
) sub2;

ANALYZE rec_stage.cta_totales_personas_tmp3;

-- ============================================================
-- Paso 6: Limpieza de tabla intermedia CTA_TOTALES_PERSONAS_TMP2
-- El SP original elimina TMP2 después de crear TMP3.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.cta_totales_personas_tmp2;

-- ------------------------------------------------------------
-- Registro de FIN exitoso
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento, registros_afectados)
VALUES ('cta_totales_personas_2', 'Fase 2', 'FIN', GETDATE(),
    (SELECT COUNT(*) FROM rec_stage.cta_totales_personas_tmp3));
