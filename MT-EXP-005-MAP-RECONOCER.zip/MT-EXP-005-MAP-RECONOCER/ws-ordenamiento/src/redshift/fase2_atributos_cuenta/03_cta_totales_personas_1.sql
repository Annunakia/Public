-- ============================================================
-- Archivo: fase2_atributos_cuenta/03_cta_totales_personas_1.sql
-- SP Original: PRO_ORD_CTA_TOTALES_PERSONAS_1
-- Fase: 2 - Atributos de Cuenta
-- Modo: Paralelo (depende de 02_cta_totales_personas.sql)
-- Dependencias: fase2_atributos_cuenta/02_cta_totales_personas.sql
-- Input: rec_stage.tmp_cnta_fechas,
--        rec_datos.vu_comportamiento_cta_activo,
--        rec_stage.cta_totales_personas_tmp1
-- Output: rec_stage.stg_comportamiento_cta_activo
-- Requerimientos: 7.1, 7.2, 7.3, 20.3, 22.3
-- ============================================================
-- Objetivo: Extrae el comportamiento de cuenta activo dentro de la
--           ventana de 12 meses calculada en tmp_cnta_fechas. Cruza
--           tmp_cnta_fechas con la vista de comportamiento de cuenta
--           activo usando BETWEEN en fechas para filtrar solo registros
--           dentro de la ventana. Luego genera la tabla precalculada
--           stg_comportamiento_cta_activo cruzando con cta_totales_personas_tmp1.
--
-- Conversiones Teradata → Redshift aplicadas:
--   - CREATE MULTISET TABLE ... WITH DATA → DROP IF EXISTS + CREATE TABLE AS
--   - PRIMARY INDEX(col) → DISTKEY(id_buro_persona)
--   - COLLECT STATISTICS → ANALYZE
--   - SQL dinámico (SP_EXECSTRING_DES) → SQL estático inline
--   - Esquemas dinámicos (P_BDSTAGE, P_BTTVISTA) → esquemas fijos
-- ============================================================

-- ------------------------------------------------------------
-- Registro de INICIO
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento)
VALUES ('cta_totales_personas_1', 'Fase 2', 'INICIO', GETDATE());

-- ============================================================
-- Paso 1: Crear tabla TMP_COMPORTAMIENTO_ACTIVO
-- Cruza tmp_cnta_fechas con la vista de comportamiento de cuenta
-- activo. Filtra registros donde la fecha de novedad del
-- comportamiento cae dentro de la ventana de 12 meses
-- (BETWEEN fecha_nov_ini AND fecha_nov).
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_comportamiento_activo;
CREATE TABLE rec_stage.tmp_comportamiento_activo
DISTSTYLE KEY DISTKEY(cod_dw_cta)
AS
SELECT  a.cod_dw_cta,
        a.valor_inicial,
        a.valor_cuota_mensual,
        a.valor_saldo,
        a.numero_dias_mora,
        a.valor_saldo_mora,
        a.num_cuotas_pagadas,
        a.valor_disponible,
        a.num_cuotas_mora,
        a.num_cuotas_pactadas,
        a.fecha_nov,
        CASE WHEN a.cod_dw_cta IS NOT NULL THEN 'Y' ELSE 'N' END AS flag_comp_cta_activo,
        a.cod_altura_mora_fte
FROM rec_stage.tmp_cnta_fechas b
INNER JOIN rec_datos.vu_comportamiento_cta_activo a
    ON a.cod_dw_cta = b.cod_dw_cta
    AND a.fecha_nov BETWEEN b.fecha_nov_ini AND b.fecha_nov;

ANALYZE rec_stage.tmp_comportamiento_activo;

-- ============================================================
-- Paso 2: Crear tabla STG_COMPORTAMIENTO_CTA_ACTIVO
-- Cruza TMP_COMPORTAMIENTO_ACTIVO con CTA_TOTALES_PERSONAS_TMP1
-- para retener solo los registros de comportamiento activo que
-- corresponden a cuentas en la tabla base (misma fecha_nov y
-- cod_dw_cta). Incluye id_buro_persona de tmp_cnta_fechas para
-- distribución óptima.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.stg_comportamiento_cta_activo;
CREATE TABLE rec_stage.stg_comportamiento_cta_activo
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  a.cod_dw_cta,
        a.valor_inicial,
        a.valor_cuota_mensual,
        a.valor_saldo,
        a.numero_dias_mora,
        a.valor_saldo_mora,
        a.num_cuotas_pagadas,
        a.valor_disponible,
        a.num_cuotas_mora,
        a.num_cuotas_pactadas,
        a.fecha_nov,
        a.flag_comp_cta_activo,
        b.id_buro_persona
FROM rec_stage.tmp_comportamiento_activo a
INNER JOIN rec_stage.cta_totales_personas_tmp1 b
    ON a.fecha_nov = b.fecha_nov
    AND a.cod_dw_cta = b.cod_dw_cta;

ANALYZE rec_stage.stg_comportamiento_cta_activo;

-- ------------------------------------------------------------
-- Registro de FIN exitoso
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento, registros_afectados)
VALUES ('cta_totales_personas_1', 'Fase 2', 'FIN', GETDATE(),
    (SELECT COUNT(*) FROM rec_stage.stg_comportamiento_cta_activo));
