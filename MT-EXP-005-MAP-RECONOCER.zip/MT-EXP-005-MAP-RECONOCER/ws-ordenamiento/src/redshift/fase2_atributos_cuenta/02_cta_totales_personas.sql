-- ============================================================
-- Archivo: fase2_atributos_cuenta/02_cta_totales_personas.sql
-- SP Original: PRO_ORD_CTA_TOTALES_PERSONAS
-- Fase: 2 - Atributos de Cuenta
-- Modo: Secuencial (depende de 01_cta_atributos.sql)
-- Dependencias: fase2_atributos_cuenta/01_cta_atributos.sql
-- Input: rec_stage.cta_totales_personas_tmp1
-- Output: rec_stage.tmp_cnta_fechas
-- Requerimientos: 6.1, 6.2, 6.3, 17.6, 20.3, 22.3
-- ============================================================
-- Objetivo: Calcula la ventana temporal de 12 meses para cada cuenta
--           presente en cta_totales_personas_tmp1. Para cada cuenta,
--           genera fecha_inicio (12 meses atrás desde fecha_novedad)
--           y fecha_fin (fecha_novedad). Esta ventana delimita el
--           período de búsqueda de comportamiento histórico usado
--           por los pasos posteriores (cta_totales_personas_1 y _2).
--
-- Conversiones Teradata → Redshift aplicadas:
--   - ADD_MONTHS(fecha_nov, -12) → DATEADD(month, -12, fecha_nov)
--   - CREATE MULTISET TABLE ... WITH DATA → DROP IF EXISTS + CREATE TABLE AS
--   - PRIMARY INDEX(cols) → DISTKEY(id_buro_persona)
--   - COLLECT STATISTICS → ANALYZE
--   - SQL dinámico (SP_EXECSTRING_DES) → SQL estático inline
-- ============================================================

-- ------------------------------------------------------------
-- Registro de INICIO
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento)
VALUES ('cta_totales_personas', 'Fase 2', 'INICIO', GETDATE());

-- ============================================================
-- Paso 1: Crear tabla TMP_CNTA_FECHAS con ventana temporal de 12 meses
-- Para cada cuenta en cta_totales_personas_tmp1, calcula:
--   - fecha_nov_ini: 12 meses antes de fecha_nov (inicio de ventana)
--   - fecha_nov: fecha de novedad original (fin de ventana)
-- Estas fechas se usan en pasos posteriores para filtrar
-- comportamiento activo y pasivo dentro de la ventana.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_cnta_fechas;
CREATE TABLE rec_stage.tmp_cnta_fechas
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  a.cod_dw_cta,
        a.id_buro_persona,
        a.cod_pin_persona,
        DATEADD(month, -12, a.fecha_nov) AS fecha_nov_ini,
        a.fecha_nov
FROM rec_stage.cta_totales_personas_tmp1 a;
ANALYZE rec_stage.tmp_cnta_fechas;

-- ------------------------------------------------------------
-- Registro de FIN exitoso
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento, registros_afectados)
VALUES ('cta_totales_personas', 'Fase 2', 'FIN', GETDATE(),
    (SELECT COUNT(*) FROM rec_stage.tmp_cnta_fechas));
