-- ============================================================
-- 00_checklist_pre_ejecucion.sql
-- CHECKLIST DE INSUMOS — Ordenamiento (Scoring de Contactabilidad)
-- ============================================================
--
-- OBJETIVO:
-- Garantizar que sobre Redshift Experian se encuentren TODOS los
-- insumos necesarios para ejecutar la lógica migrada de Ordenamiento.
--
-- DISEÑO:
-- Tolerante a tablas faltantes — nunca se revienta.
-- Primero valida existencia via information_schema, luego datos.
--
-- USO:
-- Ejecutar este script completo en Redshift Experian.
--   PASS = OK
--   FAIL = Bloqueante — NO ejecutar Ordenamiento
--   WARN = No bloqueante
--
-- Fecha: 2026-04-24
-- ============================================================

-- =====================
-- 1. SCHEMAS
-- =====================
SELECT '1.1' AS check_id, 'SCHEMA' AS categoria,
  'bdm_datos existe' AS validacion,
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END AS estado,
  NULL AS detalle
FROM information_schema.schemata WHERE schema_name = 'bdm_datos'

-- =====================
-- 2. EXISTENCIA DE TABLAS
-- =====================

UNION ALL
SELECT '2.1', 'TABLA', 'beta_ordenamiento existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='beta_ordenamiento'

UNION ALL
SELECT '2.2', 'TABLA', 'insumo_direccion existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='insumo_direccion'

UNION ALL
SELECT '2.3', 'TABLA', 'insumo_telefono existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='insumo_telefono'

UNION ALL
SELECT '2.4', 'TABLA', 'insumo_celular existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='insumo_celular'

UNION ALL
SELECT '2.5', 'TABLA', 'insumo_email existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='insumo_email'

UNION ALL
SELECT '2.6', 'TABLA', 'score_ordenamiento existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='score_ordenamiento'

UNION ALL
SELECT '2.7', 'TABLA', 'relacion_persona_ubicacion existe (para persistencia)',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='relacion_persona_ubicacion'

-- =====================
-- 3. COLUMNAS CRÍTICAS
-- =====================

UNION ALL
SELECT '3.1', 'COLUMNA', 'beta_ordenamiento.canal existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.columns
WHERE table_schema='bdm_datos' AND table_name='beta_ordenamiento' AND column_name='canal'

UNION ALL
SELECT '3.2', 'COLUMNA', 'beta_ordenamiento.cod_caracteristica existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.columns
WHERE table_schema='bdm_datos' AND table_name='beta_ordenamiento' AND column_name='cod_caracteristica'

UNION ALL
SELECT '3.3', 'COLUMNA', 'beta_ordenamiento.valor_beta existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.columns
WHERE table_schema='bdm_datos' AND table_name='beta_ordenamiento' AND column_name='valor_beta'

UNION ALL
SELECT '3.4', 'COLUMNA', 'relacion_persona_ubicacion.orden_prioridad existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.columns
WHERE table_schema='bdm_datos' AND table_name='relacion_persona_ubicacion' AND column_name='orden_prioridad'

UNION ALL
SELECT '3.5', 'COLUMNA', 'insumo_direccion.id_buro_persona existe',
  CASE WHEN COUNT(*) > 0 THEN 'PASS' ELSE 'FAIL' END, NULL
FROM information_schema.columns
WHERE table_schema='bdm_datos' AND table_name='insumo_direccion' AND column_name='id_buro_persona'

ORDER BY check_id;

-- ============================================================
-- BLOQUE 2: VALIDACIÓN DE DATOS
-- Ejecutar DESPUÉS del bloque 1.
-- Solo valida tablas que existan.
-- ============================================================

CREATE TEMP TABLE IF NOT EXISTS _checklist_datos (
  check_id VARCHAR(10), categoria VARCHAR(20),
  validacion VARCHAR(200), estado VARCHAR(10), detalle VARCHAR(200)
);
TRUNCATE _checklist_datos;

-- =====================
-- 4. DATOS — Tablas de entrada tienen registros
-- =====================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='insumo_direccion') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''4.1'', ''DATOS'', ''insumo_direccion tiene registros'',
      CASE WHEN COUNT(*)>0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' registros''
      FROM bdm_datos.insumo_direccion';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='insumo_telefono') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''4.2'', ''DATOS'', ''insumo_telefono tiene registros'',
      CASE WHEN COUNT(*)>0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' registros''
      FROM bdm_datos.insumo_telefono';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='insumo_celular') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''4.3'', ''DATOS'', ''insumo_celular tiene registros'',
      CASE WHEN COUNT(*)>0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' registros''
      FROM bdm_datos.insumo_celular';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='insumo_email') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''4.4'', ''DATOS'', ''insumo_email tiene registros'',
      CASE WHEN COUNT(*)>0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' registros''
      FROM bdm_datos.insumo_email';
  END IF;
END $$;

-- =====================
-- 5. DATOS — Coeficientes Beta completos por canal
-- =====================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='beta_ordenamiento') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''5.0'', ''BETA'', ''beta_ordenamiento total (esperado 47)'',
      CASE WHEN COUNT(*)>=47 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' coeficientes''
      FROM bdm_datos.beta_ordenamiento';
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''5.1'', ''BETA'', ''canal DIR (esperado 12)'',
      CASE WHEN COUNT(*)>=12 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' coeficientes''
      FROM bdm_datos.beta_ordenamiento WHERE canal=''DIR''';
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''5.2'', ''BETA'', ''canal TEL (esperado 11)'',
      CASE WHEN COUNT(*)>=11 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' coeficientes''
      FROM bdm_datos.beta_ordenamiento WHERE canal=''TEL''';
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''5.3'', ''BETA'', ''canal CEL (esperado 11)'',
      CASE WHEN COUNT(*)>=11 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' coeficientes''
      FROM bdm_datos.beta_ordenamiento WHERE canal=''CEL''';
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''5.4'', ''BETA'', ''canal EMA (esperado 13)'',
      CASE WHEN COUNT(*)>=13 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' coeficientes''
      FROM bdm_datos.beta_ordenamiento WHERE canal=''EMA''';
  END IF;
END $$;

-- =====================
-- 6. CALIDAD — NULLs en columnas críticas
-- =====================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='bdm_datos' AND table_name='beta_ordenamiento' AND column_name='valor_beta') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''6.1'', ''CALIDAD'', ''beta_ordenamiento.valor_beta NOT NULL'',
      CASE WHEN COUNT(*)=0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' NULLs''
      FROM bdm_datos.beta_ordenamiento WHERE valor_beta IS NULL';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='bdm_datos' AND table_name='insumo_direccion' AND column_name='id_buro_persona') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''6.2'', ''CALIDAD'', ''insumo_direccion.id_buro_persona NOT NULL'',
      CASE WHEN COUNT(*)=0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' NULLs''
      FROM bdm_datos.insumo_direccion WHERE id_buro_persona IS NULL';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='bdm_datos' AND table_name='insumo_telefono' AND column_name='id_buro_persona') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''6.3'', ''CALIDAD'', ''insumo_telefono.id_buro_persona NOT NULL'',
      CASE WHEN COUNT(*)=0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' NULLs''
      FROM bdm_datos.insumo_telefono WHERE id_buro_persona IS NULL';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='bdm_datos' AND table_name='insumo_celular' AND column_name='id_buro_persona') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''6.4'', ''CALIDAD'', ''insumo_celular.id_buro_persona NOT NULL'',
      CASE WHEN COUNT(*)=0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' NULLs''
      FROM bdm_datos.insumo_celular WHERE id_buro_persona IS NULL';
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='bdm_datos' AND table_name='insumo_email' AND column_name='id_buro_persona') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''6.5'', ''CALIDAD'', ''insumo_email.id_buro_persona NOT NULL'',
      CASE WHEN COUNT(*)=0 THEN ''PASS'' ELSE ''FAIL'' END, COUNT(*)::VARCHAR||'' NULLs''
      FROM bdm_datos.insumo_email WHERE id_buro_persona IS NULL';
  END IF;
END $$;

-- =====================
-- 7. INTEGRIDAD REFERENCIAL
-- =====================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='insumo_direccion')
     AND EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='bdm_datos' AND table_name='relacion_persona_ubicacion') THEN
    EXECUTE 'INSERT INTO _checklist_datos SELECT ''7.1'', ''FK'', ''insumo_direccion.cod_dw_persona_ubic → relacion_persona_ubicacion'',
      CASE WHEN COUNT(*)=0 THEN ''PASS'' ELSE ''WARN'' END, COUNT(*)::VARCHAR||'' sin match''
      FROM bdm_datos.insumo_direccion i
      LEFT JOIN bdm_datos.relacion_persona_ubicacion r ON i.cod_dw_persona_ubic=r.cod_dw_persona_ubic
      WHERE r.cod_dw_persona_ubic IS NULL AND i.cod_dw_persona_ubic IS NOT NULL';
  END IF;
END $$;

-- =====================
-- RESULTADO BLOQUE 2
-- =====================
SELECT * FROM _checklist_datos ORDER BY check_id;

DROP TABLE IF EXISTS _checklist_datos;
