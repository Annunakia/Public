-- ============================================================
-- Archivo: fase3_ubicaciones/04_calc_ubicaciones_2.sql
-- SP Original: PRO_ORD_CALC_UBICACIONES_2
-- Fase: 3 - Ubicaciones
-- Modo: Paralelo (depende de 02_calc_ubicaciones.sql y 03_calc_ubicaciones_1.sql)
-- Dependencias: fase3_ubicaciones/02_calc_ubicaciones.sql,
--               fase3_ubicaciones/03_calc_ubicaciones_1.sql
-- Input: rec_stage.tmp_ord_cal3,
--        rec_stage.tmp_ord_cal6,
--        rec_stage.unifica_btt_reconocer,
--        rec_datos.relacion_persona_ubicacion,
--        rec_datos.bloqueo,
--        rec_datos.v_ubicacion_estandarizada,
--        rec_datos.v_gestion_registro,
--        rec_datos.v_fuente,
--        rec_datos.v_geografia,
--        rec_datos.v_tipo_ubicacion_direccion,
--        rec_datos.vu_persona,
--        rec_datos.v_tipo_persona,
--        rec_datos.vu_cuenta,
--        rec_datos.v_tipo_cuenta,
--        rec_datos.direccion_fisica,
--        rec_datos.relacion_ubicac_estandar_geo
-- Output: rec_stage.datos_tipo_cuenta
-- Requerimientos: 12.1, 12.2, 12.3, 12.4, 17.2, 20.3, 22.3
-- ============================================================
-- Objetivo: SP más complejo del flujo de ubicaciones (~1300 líneas en Teradata).
--           Consolida los resultados de calc_ubicaciones (con cuenta) y
--           calc_ubicaciones_1 (sin cuenta), luego enriquece progresivamente
--           con datos de estandarización, geografía, tipo persona y tipo cuenta.
--
--           Flujo de tablas intermedias:
--             1. vmo_reporte_relacion_pers_ubi: UNION ALL de tmp_ord_cal3 + tmp_ord_cal6
--             2. vector_ubi_insumo_base: Cruce personas × relacion_persona_ubicacion
--                (excluyendo bloqueados y unificados)
--             3. datos_ubic_estandarizadas: Enriquecido con ubicación estandarizada
--                (texto, fuente, geografía, tipo ubicación)
--             4. datos_tipo_persona: Enriquecido con tipo persona (natural/jurídica)
--             5. datos_tipo_cuenta: Enriquecido con tipo cuenta + complemento +
--                barrio + latitud + longitud (TABLA FINAL)
-- ============================================================

-- ------------------------------------------------------------
-- Registro de INICIO
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento)
VALUES ('calc_ubicaciones_2', 'Fase 3', 'INICIO', GETDATE());

-- ============================================================
-- Paso 1: Crear tabla VMO_REPORTE_RELACION_PERS_UBI
-- Consolida tmp_ord_cal3 (ubicaciones con cuenta) y tmp_ord_cal6
-- (ubicaciones sin cuenta) en una sola tabla.
-- Reemplaza CREATE SET TABLE + INSERT de Teradata por
-- SELECT DISTINCT sobre UNION ALL.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.vmo_reporte_relacion_pers_ubi;
CREATE TABLE rec_stage.vmo_reporte_relacion_pers_ubi
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT
        cod_dw_reporte_persona_ubic,
        cod_dw_persona_ubic,
        id_buro_suscriptor,
        cod_dw_cta,
        fecha_reporte_step1,
        fecha_apertura,
        fecha_nov,
        desc_est_vigencia,
        nombre_natu_cta,
        nombre_tipo_rel_con_cta,
        cod_dw_motivo_bloqueo,
        id_flag_nuevo,
        id_flag_desde,
        fecha_reporte,
        cod_dw_matricula,
        id_buro_persona
FROM (
    SELECT  cod_dw_reporte_persona_ubic,
            cod_dw_persona_ubic,
            id_buro_suscriptor,
            cod_dw_cta,
            fecha_reporte_step1,
            fecha_apertura,
            fecha_nov,
            desc_est_vigencia,
            nombre_natu_cta,
            nombre_tipo_rel_con_cta,
            cod_dw_motivo_bloqueo,
            id_flag_nuevo,
            id_flag_desde,
            fecha_reporte,
            cod_dw_matricula,
            id_buro_persona
    FROM rec_stage.tmp_ord_cal3

    UNION ALL

    SELECT  cod_dw_reporte_persona_ubic,
            cod_dw_persona_ubic,
            id_buro_suscriptor,
            cod_dw_cta,
            fecha_reporte_step1,
            fecha_apertura,
            fecha_nov,
            desc_est_vigencia,
            nombre_natu_cta,
            nombre_tipo_rel_con_cta,
            cod_dw_motivo_bloqueo,
            id_flag_nuevo,
            id_flag_desde,
            fecha_reporte,
            cod_dw_matricula,
            id_buro_persona
    FROM rec_stage.tmp_ord_cal6
);
ANALYZE rec_stage.vmo_reporte_relacion_pers_ubi;

-- Limpieza: eliminar tablas de entrada ya consumidas
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal3;
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal6;

-- ============================================================
-- Paso 2: Crear tabla VECTOR_UBI_INSUMO_BASE
-- Cruza personas de UNIFICA_BTT_RECONOCER con
-- relacion_persona_ubicacion para obtener cod_dw_ubic y demás
-- atributos de ubicación.
-- Excluye:
--   - Registros con bloqueo (LEFT JOIN bloqueo WHERE IS NULL)
--   - Registros con unificación (Ind_Unificacion IS NULL)
-- Luego enriquece con datos de vmo_reporte_relacion_pers_ubi.
--
-- Nota: En Teradata se hacía en 2 pasos (VECTOR_UBI_INSUMO_BASE_0
-- y luego VECTOR_UBI_INSUMO_BASE). Aquí se consolida en uno solo.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.vector_ubi_insumo_base;
CREATE TABLE rec_stage.vector_ubi_insumo_base
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  a.cod_pin_persona,
        a.id_buro_persona,
        b.cod_dw_persona_ubic,
        b.cod_dw_ubic,
        b.cod_dw_telefono,
        b.cod_dw_direccion_electronica,
        b.cod_dw_direccion_fisica,
        b.cod_dw_tipo_ubicacion_dir,
        b.orden_prioridad,
        b.ind_unificacion,
        c.cod_dw_reporte_persona_ubic,
        c.cod_dw_cta,
        c.id_buro_suscriptor,
        c.fecha_reporte,
        c.id_flag_desde,
        c.id_flag_nuevo
FROM rec_stage.unifica_btt_reconocer a
INNER JOIN rec_datos.relacion_persona_ubicacion b
    ON a.cod_pin_persona = b.cod_pin_persona
   AND a.id_buro_persona = b.id_buro_persona
-- Excluir registros con bloqueo
LEFT JOIN rec_datos.bloqueo d
    ON b.cod_dw_persona_ubic = d.cod_dw_persona_ubic
-- Enriquecer con datos de reporte
INNER JOIN rec_stage.vmo_reporte_relacion_pers_ubi c
    ON b.cod_dw_persona_ubic = c.cod_dw_persona_ubic
WHERE d.cod_dw_persona_ubic IS NULL    -- Sin bloqueo
  AND b.ind_unificacion IS NULL;       -- Sin unificación
ANALYZE rec_stage.vector_ubi_insumo_base;

-- Limpieza: eliminar vmo_reporte_relacion_pers_ubi ya consumida
DROP TABLE IF EXISTS rec_stage.vmo_reporte_relacion_pers_ubi;

-- ============================================================
-- Paso 3: Crear tabla auxiliar TMP_UBIC_ESTANDARIZA_242
-- Extrae datos de ubicación estandarizada válida (gestión = 'Valida')
-- para las ubicaciones presentes en vector_ubi_insumo_base.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_ubic_estandariza_242;
CREATE TABLE rec_stage.tmp_ubic_estandariza_242
DISTSTYLE KEY DISTKEY(cod_dw_ubic)
AS
SELECT  b.cod_dw_ubic,
        b.cod_dw_tipo_ubicacion,
        b.texto_ubicacion,
        b.cod_dw_fuente_est,
        b.cod_dw_ciudad,
        'Valida' AS descripcion_gestion_registro
FROM rec_datos.v_ubicacion_estandarizada b
WHERE b.cod_dw_ubic IN (SELECT cod_dw_ubic FROM rec_stage.vector_ubi_insumo_base)
  AND b.cod_dw_gestion_registro = (
      SELECT cod_dw_gestion_registro
      FROM rec_datos.v_gestion_registro
      WHERE descripcion_gestion_registro = 'Valida'
  );
ANALYZE rec_stage.tmp_ubic_estandariza_242;

-- ============================================================
-- Paso 4: Crear tabla auxiliar TMP_UBIC_ESTANDARIZA_242_1
-- Enriquece con descripción de fuente y códigos DANE (geografía).
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_ubic_estandariza_242_1;
CREATE TABLE rec_stage.tmp_ubic_estandariza_242_1
DISTSTYLE KEY DISTKEY(cod_dw_ubic)
AS
SELECT  b.cod_dw_ubic,
        b.cod_dw_tipo_ubicacion,
        b.texto_ubicacion,
        e.descripcion_fuente,
        b.descripcion_gestion_registro,
        b.cod_dw_fuente_est,
        b.cod_dw_ciudad,
        f.cod_dane_municipio    AS cod_dane_ciudad,
        f.cod_dane_departamento
FROM rec_stage.tmp_ubic_estandariza_242 b
LEFT JOIN rec_datos.v_fuente e
    ON b.cod_dw_fuente_est = e.cod_dw_fuente
LEFT JOIN rec_datos.v_geografia f
    ON b.cod_dw_ciudad = f.cod_dw_ciudad;
ANALYZE rec_stage.tmp_ubic_estandariza_242_1;

-- Limpieza: eliminar tabla intermedia
DROP TABLE IF EXISTS rec_stage.tmp_ubic_estandariza_242;

-- ============================================================
-- Paso 5: Crear tabla DATOS_UBIC_ESTANDARIZADAS
-- Cruza vector_ubi_insumo_base con datos de estandarización
-- y tipo de ubicación de dirección.
-- Agrega Periodo_Reporte (YYYYMM) calculado desde Fecha_Reporte.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.datos_ubic_estandarizadas;
CREATE TABLE rec_stage.datos_ubic_estandarizadas
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  a.cod_pin_persona,
        a.id_buro_persona,
        a.cod_dw_persona_ubic,
        a.cod_dw_ubic,
        a.cod_dw_telefono,
        a.cod_dw_direccion_electronica,
        a.cod_dw_direccion_fisica,
        a.cod_dw_tipo_ubicacion_dir,
        a.orden_prioridad,
        a.ind_unificacion,
        a.cod_dw_reporte_persona_ubic,
        a.cod_dw_cta,
        a.id_buro_suscriptor,
        a.fecha_reporte,
        a.id_flag_desde,
        a.id_flag_nuevo,
        b.cod_dw_tipo_ubicacion,
        b.texto_ubicacion,
        b.descripcion_fuente,
        c.descripcion_tipo_ubicacion_dir,
        b.descripcion_gestion_registro,
        (EXTRACT(YEAR FROM a.fecha_reporte) * 100) + EXTRACT(MONTH FROM a.fecha_reporte) AS periodo_reporte,
        b.cod_dane_ciudad,
        b.cod_dane_departamento
FROM rec_stage.vector_ubi_insumo_base a
INNER JOIN rec_stage.tmp_ubic_estandariza_242_1 b
    ON a.cod_dw_ubic = b.cod_dw_ubic
INNER JOIN rec_datos.v_tipo_ubicacion_direccion c
    ON a.cod_dw_tipo_ubicacion_dir = c.cod_dw_tipo_ubicacion_dir;
ANALYZE rec_stage.datos_ubic_estandarizadas;

-- Limpieza: eliminar tablas intermedias ya consumidas
DROP TABLE IF EXISTS rec_stage.vector_ubi_insumo_base;
DROP TABLE IF EXISTS rec_stage.tmp_ubic_estandariza_242_1;

-- ============================================================
-- Paso 6: Crear tabla auxiliar TMP_PERSONAS_242
-- Extrae tipo de persona (natural/jurídica) para todas las
-- personas del sistema.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_personas_242;
CREATE TABLE rec_stage.tmp_personas_242
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  b.cod_pin_persona,
        b.id_buro_persona,
        c.desc_tipo_persona
FROM rec_datos.vu_persona b
LEFT JOIN rec_datos.v_tipo_persona c
    ON b.cod_dw_tipo_persona = c.cod_dw_tipo_persona;
ANALYZE rec_stage.tmp_personas_242;

-- ============================================================
-- Paso 7: Crear tabla DATOS_TIPO_PERSONA
-- Enriquece datos_ubic_estandarizadas con tipo de persona.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.datos_tipo_persona;
CREATE TABLE rec_stage.datos_tipo_persona
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  a.cod_pin_persona,
        a.id_buro_persona,
        a.cod_dw_persona_ubic,
        a.cod_dw_ubic,
        a.cod_dw_telefono,
        a.cod_dw_direccion_electronica,
        a.cod_dw_direccion_fisica,
        a.cod_dw_tipo_ubicacion_dir,
        a.orden_prioridad,
        a.ind_unificacion,
        a.cod_dw_reporte_persona_ubic,
        a.cod_dw_cta,
        a.id_buro_suscriptor,
        a.fecha_reporte,
        a.id_flag_desde,
        a.id_flag_nuevo,
        a.cod_dw_tipo_ubicacion,
        a.texto_ubicacion,
        a.descripcion_fuente,
        a.descripcion_tipo_ubicacion_dir,
        a.descripcion_gestion_registro,
        a.periodo_reporte,
        a.cod_dane_ciudad,
        a.cod_dane_departamento,
        b.desc_tipo_persona
FROM rec_stage.datos_ubic_estandarizadas a
INNER JOIN rec_stage.tmp_personas_242 b
    ON a.cod_pin_persona = b.cod_pin_persona
   AND a.id_buro_persona = b.id_buro_persona;
ANALYZE rec_stage.datos_tipo_persona;

-- Limpieza: eliminar tablas intermedias
DROP TABLE IF EXISTS rec_stage.datos_ubic_estandarizadas;
DROP TABLE IF EXISTS rec_stage.tmp_personas_242;

-- ============================================================
-- Paso 8: Crear tabla auxiliar TMP_DESC_CTA_242
-- Extrae descripción de tipo de cuenta para las cuentas
-- presentes en datos_tipo_persona.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_desc_cta_242;
CREATE TABLE rec_stage.tmp_desc_cta_242
DISTSTYLE KEY DISTKEY(cod_dw_cta)
AS
SELECT  b.cod_dw_cta,
        c.desc_tipo_cta
FROM rec_datos.vu_cuenta b
LEFT JOIN rec_datos.v_tipo_cuenta c
    ON b.cod_dw_tipo_cta = c.cod_dw_tipo_cta
WHERE b.cod_dw_cta IN (SELECT cod_dw_cta FROM rec_stage.datos_tipo_persona);
ANALYZE rec_stage.tmp_desc_cta_242;

-- ============================================================
-- Paso 9: Crear tabla intermedia DATOS_TIPO_CUENTA_PRE
-- Enriquece datos_tipo_persona con descripción de tipo de cuenta.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.datos_tipo_cuenta_pre;
CREATE TABLE rec_stage.datos_tipo_cuenta_pre
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  a.cod_pin_persona,
        a.id_buro_persona,
        a.cod_dw_persona_ubic,
        a.cod_dw_ubic,
        a.cod_dw_telefono,
        a.cod_dw_direccion_electronica,
        a.cod_dw_direccion_fisica,
        a.cod_dw_tipo_ubicacion_dir,
        a.orden_prioridad,
        a.ind_unificacion,
        a.cod_dw_reporte_persona_ubic,
        a.cod_dw_cta,
        a.id_buro_suscriptor,
        a.fecha_reporte,
        a.id_flag_desde,
        a.id_flag_nuevo,
        a.cod_dw_tipo_ubicacion,
        a.texto_ubicacion,
        a.descripcion_fuente,
        a.descripcion_tipo_ubicacion_dir,
        a.descripcion_gestion_registro,
        a.periodo_reporte,
        a.cod_dane_ciudad,
        a.cod_dane_departamento,
        a.desc_tipo_persona,
        b.desc_tipo_cta
FROM rec_stage.datos_tipo_persona a
LEFT JOIN rec_stage.tmp_desc_cta_242 b
    ON a.cod_dw_cta = b.cod_dw_cta;
ANALYZE rec_stage.datos_tipo_cuenta_pre;

-- Limpieza: eliminar tablas intermedias
DROP TABLE IF EXISTS rec_stage.datos_tipo_persona;
DROP TABLE IF EXISTS rec_stage.tmp_desc_cta_242;

-- ============================================================
-- Paso 10: Crear tabla auxiliar TMP_AGR_DIRFIS_242
-- Extrae complemento de dirección física para las ubicaciones
-- presentes en datos_tipo_cuenta_pre (solo donde
-- cod_dw_direccion_fisica > -1).
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_agr_dirfis_242;
CREATE TABLE rec_stage.tmp_agr_dirfis_242
DISTSTYLE KEY DISTKEY(cod_dw_ubic)
AS
SELECT  cod_dw_ubic,
        cod_dw_direccion_fisica,
        complemento
FROM rec_datos.direccion_fisica
WHERE (cod_dw_ubic, cod_dw_direccion_fisica) IN (
    SELECT cod_dw_ubic, cod_dw_direccion_fisica
    FROM rec_stage.datos_tipo_cuenta_pre
    WHERE cod_dw_direccion_fisica > -1
    GROUP BY cod_dw_ubic, cod_dw_direccion_fisica
);
ANALYZE rec_stage.tmp_agr_dirfis_242;

-- ============================================================
-- Paso 11: Crear tabla intermedia DATOS_COMPL_DIR_FISICA
-- Agrega complemento y dirección física completa
-- (texto_ubicacion + complemento).
-- ============================================================
DROP TABLE IF EXISTS rec_stage.datos_compl_dir_fisica;
CREATE TABLE rec_stage.datos_compl_dir_fisica
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  a.cod_pin_persona,
        a.id_buro_persona,
        a.cod_dw_persona_ubic,
        a.cod_dw_ubic,
        a.cod_dw_telefono,
        a.cod_dw_direccion_electronica,
        a.cod_dw_direccion_fisica,
        a.cod_dw_tipo_ubicacion_dir,
        a.orden_prioridad,
        a.ind_unificacion,
        a.cod_dw_reporte_persona_ubic,
        a.cod_dw_cta,
        a.id_buro_suscriptor,
        a.fecha_reporte,
        a.id_flag_desde,
        a.id_flag_nuevo,
        a.cod_dw_tipo_ubicacion,
        a.texto_ubicacion,
        a.descripcion_fuente,
        a.descripcion_tipo_ubicacion_dir,
        a.descripcion_gestion_registro,
        a.periodo_reporte,
        a.cod_dane_ciudad,
        a.cod_dane_departamento,
        a.desc_tipo_persona,
        a.desc_tipo_cta,
        TRIM(a.texto_ubicacion || ' ' || COALESCE(b.complemento, ' ')) AS direccion_fisica,
        b.complemento
FROM rec_stage.datos_tipo_cuenta_pre a
LEFT JOIN rec_stage.tmp_agr_dirfis_242 b
    ON a.cod_dw_ubic = b.cod_dw_ubic
   AND a.cod_dw_direccion_fisica = b.cod_dw_direccion_fisica;
ANALYZE rec_stage.datos_compl_dir_fisica;

-- Limpieza: eliminar tablas intermedias
DROP TABLE IF EXISTS rec_stage.datos_tipo_cuenta_pre;
DROP TABLE IF EXISTS rec_stage.tmp_agr_dirfis_242;

-- ============================================================
-- Paso 12: Crear tabla auxiliar TMP_RELUBICESTANGEO_242
-- Extrae barrio, latitud y longitud de
-- relacion_ubicac_estandar_geo para las ubicaciones presentes
-- en datos_compl_dir_fisica.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_relubicestangeo_242;
CREATE TABLE rec_stage.tmp_relubicestangeo_242
DISTSTYLE KEY DISTKEY(cod_dw_ubic)
AS
SELECT  b.cod_dw_ubic,
        b.urbanizacion_barrio,
        b.latitud,
        b.longitud
FROM rec_datos.relacion_ubicac_estandar_geo b
WHERE b.cod_dw_ubic IN (
    SELECT cod_dw_ubic
    FROM rec_stage.datos_compl_dir_fisica
    GROUP BY cod_dw_ubic
);
ANALYZE rec_stage.tmp_relubicestangeo_242;

-- ============================================================
-- Paso 13: Crear tabla final DATOS_TIPO_CUENTA
-- Agrega barrio, latitud y longitud. Esta es la tabla final
-- enriquecida de direcciones que será consumida por
-- 05_concat_direcciones.sql para el cálculo de hash MD5.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.datos_tipo_cuenta;
CREATE TABLE rec_stage.datos_tipo_cuenta
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  a.cod_pin_persona,
        a.id_buro_persona,
        a.cod_dw_persona_ubic,
        a.cod_dw_ubic,
        a.cod_dw_telefono,
        a.cod_dw_direccion_electronica,
        a.cod_dw_direccion_fisica,
        a.cod_dw_tipo_ubicacion_dir,
        a.orden_prioridad,
        a.ind_unificacion,
        a.cod_dw_reporte_persona_ubic,
        a.cod_dw_cta,
        a.id_buro_suscriptor,
        a.fecha_reporte,
        a.id_flag_desde,
        a.id_flag_nuevo,
        a.cod_dw_tipo_ubicacion,
        a.texto_ubicacion,
        a.descripcion_fuente,
        a.descripcion_tipo_ubicacion_dir,
        a.descripcion_gestion_registro,
        a.periodo_reporte,
        a.cod_dane_ciudad,
        a.cod_dane_departamento,
        a.desc_tipo_persona,
        a.desc_tipo_cta,
        a.direccion_fisica,
        a.complemento,
        b.urbanizacion_barrio,
        b.latitud,
        b.longitud
FROM rec_stage.datos_compl_dir_fisica a
LEFT JOIN rec_stage.tmp_relubicestangeo_242 b
    ON a.cod_dw_ubic = b.cod_dw_ubic;
ANALYZE rec_stage.datos_tipo_cuenta;

-- Limpieza: eliminar tablas intermedias
DROP TABLE IF EXISTS rec_stage.datos_compl_dir_fisica;
DROP TABLE IF EXISTS rec_stage.tmp_relubicestangeo_242;

-- ------------------------------------------------------------
-- Registro de FIN exitoso
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento, registros_afectados)
VALUES ('calc_ubicaciones_2', 'Fase 3', 'FIN', GETDATE(),
    (SELECT COUNT(*) FROM rec_stage.datos_tipo_cuenta));
