-- ============================================================
-- Archivo: fase3_ubicaciones/06_final_ubic_direcciones.sql
-- SP Original: PRO_ORD_FINAL_UBIC_DIRECCIONES1
-- Fase: 3 - Ubicaciones
-- Modo: Secuencial (depende de 05_concat_direcciones.sql)
-- Dependencias: fase3_ubicaciones/05_concat_direcciones.sql
-- Input: rec_stage.hash_carac_direc, rec_datos.ubicacion_atributo_hash
-- Output: rec_datos.ubicacion_atributo_hash (INSERT nuevos + UPDATE modificados)
-- Requerimientos: 15.1, 15.2, 15.3, 15.4, 17.4, 20.3, 22.3
-- ============================================================
-- Objetivo: Persiste los hashes de ubicaciones/direcciones en la tabla
--           definitiva rec_datos.ubicacion_atributo_hash. Detecta registros
--           NUEVOS (clave no existe) e INSERT, y registros MODIFICADOS
--           (clave existe pero hash difiere) y UPDATE.
--
-- Nota: Esta es la versión ACTIVA (PRO_ORD_FINAL_UBIC_DIRECCIONES1).
--       La versión deshabilitada (PRO_ORD_FINAL_UBIC_DIRECCIONES) solo
--       hacía INSERT sin UPDATE y está en _disabled/.
--
-- Lógica de detección de cambios:
--   - NUEVO: cod_dw_persona_ubic no existe en ubicacion_atributo_hash
--            (LEFT JOIN WHERE IS NULL) → INSERT
--   - MODIFICADO: cod_dw_persona_ubic existe pero cod_hash difiere
--            (JOIN WHERE hash <>) → UPDATE cod_hash + fecha_actualizacion
--
-- Conversiones Teradata → Redshift aplicadas:
--   - CREATE MULTISET TABLE ... WITH DATA → DROP IF EXISTS + CREATE TABLE AS
--   - PRIMARY INDEX(Cod_DW_Persona_Ubic) → DISTKEY(id_buro_persona)
--   - COLLECT STATISTICS → ANALYZE
--   - SQL dinámico (SP_EXECSTRING_DES) → SQL estático inline
--   - Esquemas dinámicos (P_BDSTAGE, P_BDDATOS) → esquemas fijos
--   - UPDATE A FROM ... , ... SET → UPDATE dest SET ... FROM src WHERE
--   - rec_vista.hash_md5() → MD5() (ya calculado en paso previo)
-- ============================================================

-- ------------------------------------------------------------
-- Registro de INICIO
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento)
VALUES ('final_ubic_direcciones', 'Fase 3', 'INICIO', GETDATE());

-- ============================================================
-- Paso 1: Detectar registros NUEVOS
-- LEFT JOIN hash_carac_direc contra ubicacion_atributo_hash
-- donde la clave compuesta (cod_pin_persona, id_buro_persona,
-- cod_dw_persona_ubic, cod_hash) no existe en la tabla definitiva.
-- Un registro es NUEVO cuando su combinación completa de clave + hash
-- no se encuentra en la tabla de persistencia.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.nuevos_datos_direcciones;
CREATE TABLE rec_stage.nuevos_datos_direcciones
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  a.cod_pin_persona,
        a.id_buro_persona,
        a.cod_dw_persona_ubic,
        a.concatena,
        a.cod_hash
FROM rec_stage.hash_carac_direc a
LEFT JOIN rec_datos.ubicacion_atributo_hash b
    ON  a.cod_pin_persona   = b.cod_pin_persona
    AND a.id_buro_persona   = b.id_buro_persona
    AND a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
    AND a.cod_hash          = b.cod_hash
WHERE b.cod_pin_persona     IS NULL
  AND b.id_buro_persona     IS NULL
  AND b.cod_dw_persona_ubic IS NULL
  AND b.cod_hash            IS NULL;

ANALYZE rec_stage.nuevos_datos_direcciones;

-- ============================================================
-- Paso 2: INSERT registros nuevos en tabla definitiva
-- Inserta en rec_datos.ubicacion_atributo_hash los registros
-- detectados como nuevos (no existían previamente).
-- ============================================================
INSERT INTO rec_datos.ubicacion_atributo_hash
    (cod_pin_persona, id_buro_persona, cod_dw_persona_ubic, concatena, cod_hash, fecha_insercion)
SELECT  a.cod_pin_persona,
        a.id_buro_persona,
        a.cod_dw_persona_ubic,
        a.concatena,
        a.cod_hash,
        CURRENT_DATE
FROM rec_stage.nuevos_datos_direcciones a;

ANALYZE rec_datos.ubicacion_atributo_hash;

-- ============================================================
-- Paso 3: Detectar registros MODIFICADOS
-- JOIN donde la clave existe (cod_pin_persona, id_buro_persona,
-- cod_dw_persona_ubic) pero el hash difiere.
-- Esto identifica registros cuya dirección cambió desde la
-- última ejecución.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.modificados_datos_direcciones;
CREATE TABLE rec_stage.modificados_datos_direcciones
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  src.cod_pin_persona,
        src.id_buro_persona,
        src.cod_dw_persona_ubic,
        src.concatena,
        src.cod_hash
FROM rec_stage.hash_carac_direc src
INNER JOIN rec_datos.ubicacion_atributo_hash dest
    ON  src.cod_pin_persona     = dest.cod_pin_persona
    AND src.id_buro_persona     = dest.id_buro_persona
    AND src.cod_dw_persona_ubic = dest.cod_dw_persona_ubic
WHERE src.cod_hash <> dest.cod_hash;

ANALYZE rec_stage.modificados_datos_direcciones;

-- ============================================================
-- Paso 4: UPDATE registros modificados en tabla definitiva
-- Actualiza el hash y la fecha de actualización para registros
-- cuya clave existe pero cuyo hash cambió.
-- Usa sintaxis Redshift: UPDATE ... SET ... FROM ... WHERE
-- ============================================================
UPDATE rec_datos.ubicacion_atributo_hash dest
SET cod_hash            = src.cod_hash,
    concatena           = src.concatena,
    fecha_actualizacion = CURRENT_DATE
FROM rec_stage.modificados_datos_direcciones src
WHERE dest.cod_pin_persona     = src.cod_pin_persona
  AND dest.id_buro_persona     = src.id_buro_persona
  AND dest.cod_dw_persona_ubic = src.cod_dw_persona_ubic;

ANALYZE rec_datos.ubicacion_atributo_hash;

-- ------------------------------------------------------------
-- Registro de FIN exitoso
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento, registros_afectados)
VALUES ('final_ubic_direcciones', 'Fase 3', 'FIN', GETDATE(),
    (SELECT COUNT(*) FROM rec_stage.nuevos_datos_direcciones)
    + (SELECT COUNT(*) FROM rec_stage.modificados_datos_direcciones));
