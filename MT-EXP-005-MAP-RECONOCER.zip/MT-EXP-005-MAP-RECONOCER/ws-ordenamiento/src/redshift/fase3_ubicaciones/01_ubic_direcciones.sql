-- ============================================================
-- Archivo: fase3_ubicaciones/01_ubic_direcciones.sql
-- SP Original: PRO_ORD_UBIC_DIRECCIONES
-- Fase: 3 - Ubicaciones
-- Modo: Paralelo (con fase2_atributos_cuenta/01_cta_atributos.sql)
-- Dependencias: fase1_materializacion/03_unifica_btt_rec.sql
-- Input: rec_datos.relacion_persona_ubicacion,
--        rec_datos.mat_reporte_rel_pers_ubi,
--        rec_stage.unifica_btt_reconocer
-- Output: rec_stage.tmp_ord_cal_mat
-- Requerimientos: 9.1, 9.2, 9.3, 9.4, 20.3, 22.3
-- ============================================================
-- Objetivo: Filtra desde MAT_REPORTE_REL_PERS_UBI solo las personas
--           presentes en unifica_btt_reconocer. Agrupa por persona-
--           ubicación calculando MAX/MIN de Cod_DW_Reporte_Persona_Ubic
--           y Fecha_Reporte según Id_Flag_Desde:
--             - Flag 0 (más reciente): MAX
--             - Flag 1 (más antiguo): MIN
--           Genera la tabla tmp_ord_cal_mat con resultados agrupados.
-- ============================================================

-- ------------------------------------------------------------
-- Registro de INICIO
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento)
VALUES ('ubic_direcciones', 'Fase 3', 'INICIO', GETDATE());

-- ============================================================
-- Paso 1: Crear tabla auxiliar TMP_RelPerUbic_242
-- Filtra relacion_persona_ubicacion para obtener solo los
-- cod_dw_persona_ubic de personas en unifica_btt_reconocer.
-- Esta tabla intermedia optimiza el JOIN posterior con la
-- tabla materializada de reportes.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_relperubic_242;
CREATE TABLE rec_stage.tmp_relperubic_242
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT  cod_dw_persona_ubic,
        id_buro_persona
FROM rec_datos.relacion_persona_ubicacion
WHERE (cod_pin_persona, id_buro_persona) IN (
    SELECT cod_pin_persona, id_buro_persona
    FROM rec_stage.unifica_btt_reconocer
);
ANALYZE rec_stage.tmp_relperubic_242;

-- ============================================================
-- Paso 2: Crear tabla TMP_ORD_CAL_MAT
-- Agrupa MAT_REPORTE_REL_PERS_UBI por persona-ubicación con
-- agregación condicional según Id_Flag_Desde:
--   - Id_Flag_Desde = 0: MAX(Cod_DW_Reporte_Persona_Ubic),
--                        MAX(Fecha_Reporte) → más reciente
--   - Id_Flag_Desde = 1: MIN(Cod_DW_Reporte_Persona_Ubic),
--                        MIN(Fecha_Reporte) → más antiguo
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal_mat;
CREATE TABLE rec_stage.tmp_ord_cal_mat
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  CASE
            WHEN a.id_flag_desde = 0
            THEN MAX(a.cod_dw_reporte_persona_ubic)
            ELSE MIN(a.cod_dw_reporte_persona_ubic)
        END                                         AS cod_dw_reporte_persona_ubic,
        a.cod_dw_persona_ubic,
        COALESCE(a.id_buro_suscriptor, -1)          AS id_buro_suscriptor,
        COALESCE(a.cod_dw_cta, -1)                  AS cod_dw_cta,
        CASE
            WHEN a.id_flag_desde = 0
            THEN MAX(a.fecha_reporte)
            ELSE MIN(a.fecha_reporte)
        END                                         AS fecha_reporte,
        a.fecha_apertura,
        a.fecha_nov,
        a.desc_est_vigencia,
        a.nombre_natu_cta,
        a.nombre_tipo_rel_con_cta,
        a.cod_dw_motivo_bloqueo,
        a.id_flag_nuevo,
        a.id_flag_desde,
        a.flag_bloqueo,
        a.cod_dw_fuente,
        COALESCE(a.cod_dw_matricula, -1)            AS cod_dw_matricula,
        b.id_buro_persona
FROM rec_datos.mat_reporte_rel_pers_ubi a
INNER JOIN rec_stage.tmp_relperubic_242 b
    ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
WHERE a.id_flag_desde IN (0, 1)
GROUP BY
        a.cod_dw_persona_ubic,
        a.id_buro_suscriptor,
        a.cod_dw_cta,
        a.fecha_apertura,
        a.fecha_nov,
        a.desc_est_vigencia,
        a.nombre_natu_cta,
        a.nombre_tipo_rel_con_cta,
        a.cod_dw_motivo_bloqueo,
        a.id_flag_nuevo,
        a.id_flag_desde,
        a.flag_bloqueo,
        a.cod_dw_fuente,
        a.cod_dw_matricula,
        b.id_buro_persona;
ANALYZE rec_stage.tmp_ord_cal_mat;

-- ============================================================
-- Paso 3: Limpieza de tabla auxiliar
-- Elimina TMP_RelPerUbic_242 que ya no se necesita.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_relperubic_242;

-- ------------------------------------------------------------
-- Registro de FIN exitoso
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento, registros_afectados)
VALUES ('ubic_direcciones', 'Fase 3', 'FIN', GETDATE(),
    (SELECT COUNT(*) FROM rec_stage.tmp_ord_cal_mat));
