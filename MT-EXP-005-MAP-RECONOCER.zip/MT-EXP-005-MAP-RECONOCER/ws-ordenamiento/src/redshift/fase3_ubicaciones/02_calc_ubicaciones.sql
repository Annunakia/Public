-- ============================================================
-- Archivo: fase3_ubicaciones/02_calc_ubicaciones.sql
-- SP Original: PRO_ORD_CALC_UBICACIONES
-- Fase: 3 - Ubicaciones
-- Modo: Paralelo (con fase3_ubicaciones/03_calc_ubicaciones_1.sql)
-- Dependencias: fase3_ubicaciones/01_ubic_direcciones.sql
-- Input: rec_stage.tmp_ord_cal_mat,
--        rec_datos.vu_cuenta,
--        rec_datos.relacion_persona_ubicacion
-- Output: rec_stage.tmp_ord_cal3
-- Requerimientos: 10.1, 10.2, 10.3, 10.4, 17.3, 20.3, 22.3
-- ============================================================
-- Objetivo: Calcula fechas de reporte ajustadas para ubicaciones que
--           tienen cuenta válida (cod_dw_cta existe en VU_CUENTA).
--           Aplica reglas de negocio:
--             1) Si cuenta vigente (Desc_Est_Vigencia='A') y tipo es
--                principal/pasivo/codeudor:
--                - Registro nuevo (Id_Flag_Nuevo=1) → Fecha_Apertura
--                - Registro existente → Fecha_Reporte
--             2) Si cuenta NO vigente:
--                - MIN(Fecha_Nov, Fecha_Reporte)
--           Luego agrega Cod_Entrega_Dato_Fte desde VU_CUENTA y limita
--           a 3 registros por combinación persona-ubicación usando
--           ROW_NUMBER (subquery pattern en lugar de QUALIFY).
--
--           Tablas intermedias generadas:
--             - tmp_ord_cal1: Ubicaciones con cuenta (flag_desde=0) + fechas ajustadas
--             - tmp_ord_cal11: Ubicaciones históricas (flag_desde=1) con Fecha_Act
--             - tmp_ord_cal2: Unión de cal1 + cal11 con Cod_Entrega_Dato_Fte
--             - tmp_ord_cal3: Resultado final (top 3 por partición)
-- ============================================================

-- ------------------------------------------------------------
-- Registro de INICIO
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento)
VALUES ('calc_ubicaciones', 'Fase 3', 'INICIO', GETDATE());

-- ============================================================
-- Paso 1: Crear tabla TMP_ORD_CAL1
-- Filtra ubicaciones de TMP_ORD_CAL_MAT que tienen cuenta válida
-- en VU_CUENTA (cod_dw_cta > -1 y existe en vu_cuenta).
-- Aplica reglas de negocio para calcular Fecha_Reporte ajustada:
--   - Vigente (A) + principal/pasivo/codeudor:
--       nuevo → Fecha_Apertura, existente → Fecha_Reporte
--   - No vigente o motivo bloqueo <> 1 y flag_desde=0:
--       MIN(Fecha_Nov, Fecha_Reporte)
--   - Otros casos: Fecha_Reporte
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal1;
CREATE TABLE rec_stage.tmp_ord_cal1
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  a.cod_dw_reporte_persona_ubic,
        a.cod_dw_persona_ubic,
        a.id_buro_suscriptor,
        a.cod_dw_cta,
        a.fecha_reporte                             AS fecha_reporte_step1,
        a.fecha_apertura,
        a.fecha_nov,
        a.desc_est_vigencia,
        a.nombre_natu_cta,
        a.nombre_tipo_rel_con_cta,
        a.cod_dw_motivo_bloqueo,
        a.id_flag_nuevo,
        a.id_flag_desde,
        CASE
            WHEN a.desc_est_vigencia = 'A' THEN
                CASE
                    WHEN a.nombre_natu_cta = 'PASIVO'
                         OR (a.nombre_natu_cta = 'ACTIVO' AND a.nombre_tipo_rel_con_cta = 'PRINCIPAL')
                         OR a.nombre_tipo_rel_con_cta = 'CODEUDOR'
                    THEN
                        CASE
                            WHEN a.id_flag_nuevo = 1 AND a.fecha_reporte IS NOT NULL
                            THEN a.fecha_apertura
                            ELSE a.fecha_reporte
                        END
                END
            ELSE
                CASE
                    WHEN (a.desc_est_vigencia <> 'A' OR a.cod_dw_motivo_bloqueo <> 1)
                         AND a.id_flag_desde = 0
                    THEN
                        CASE
                            WHEN a.fecha_reporte > a.fecha_nov
                            THEN a.fecha_nov
                            ELSE a.fecha_reporte
                        END
                    ELSE a.fecha_reporte
                END
        END                                         AS fecha_reporte,
        a.cod_dw_matricula,
        a.id_buro_persona
FROM rec_stage.tmp_ord_cal_mat a
WHERE a.cod_dw_cta IN (SELECT cod_dw_cta FROM rec_datos.vu_cuenta)
  AND a.cod_dw_cta > -1;
ANALYZE rec_stage.tmp_ord_cal1;

-- ============================================================
-- Paso 2: Crear tabla TMP_ORD_CAL11
-- Calcula registros históricos (flag_desde=1) con la fecha más
-- reciente (Fecha_Act) obtenida del MAX(Fecha_Reporte) agrupado
-- por persona + cuenta. Solo incluye registros que también tienen
-- un registro con flag_desde=0 (registro actual).
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal11;
CREATE TABLE rec_stage.tmp_ord_cal11
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  a.cod_dw_reporte_persona_ubic,
        a.cod_dw_persona_ubic,
        a.id_buro_suscriptor,
        a.cod_dw_cta,
        c.fecha_act                                 AS fecha_reporte,
        a.fecha_apertura,
        a.fecha_nov,
        a.desc_est_vigencia,
        a.nombre_natu_cta,
        a.nombre_tipo_rel_con_cta,
        a.cod_dw_motivo_bloqueo,
        0                                           AS id_flag_nuevo,
        2                                           AS id_flag_desde,
        c.fecha_act,
        a.cod_dw_matricula,
        a.id_buro_persona
FROM rec_stage.tmp_ord_cal_mat a
INNER JOIN (
    SELECT  b.cod_pin_persona,
            b.id_buro_persona,
            mat.cod_dw_cta,
            MAX(mat.fecha_reporte)                  AS fecha_act
    FROM rec_stage.tmp_ord_cal_mat mat
    INNER JOIN rec_datos.relacion_persona_ubicacion b
        ON mat.cod_dw_persona_ubic = b.cod_dw_persona_ubic
    WHERE mat.id_flag_desde = 1
      AND mat.cod_dw_cta <> -1
      AND mat.cod_dw_cta IS NOT NULL
    GROUP BY b.cod_pin_persona, b.id_buro_persona, mat.cod_dw_cta
) c
    ON a.id_buro_persona = c.id_buro_persona
   AND a.cod_dw_cta = c.cod_dw_cta
INNER JOIN (
    SELECT  cod_dw_reporte_persona_ubic,
            cod_dw_cta,
            cod_dw_persona_ubic,
            id_buro_suscriptor,
            id_flag_desde
    FROM rec_stage.tmp_ord_cal_mat
    WHERE id_flag_desde = 0
) d
    ON a.cod_dw_cta = d.cod_dw_cta
   AND a.cod_dw_persona_ubic = d.cod_dw_persona_ubic
   AND a.id_buro_suscriptor = d.id_buro_suscriptor
   AND a.id_flag_desde = d.id_flag_desde
GROUP BY
    a.cod_dw_reporte_persona_ubic,
    a.cod_dw_persona_ubic,
    a.id_buro_suscriptor,
    a.cod_dw_cta,
    c.fecha_act,
    a.fecha_apertura,
    a.fecha_nov,
    a.desc_est_vigencia,
    a.nombre_natu_cta,
    a.nombre_tipo_rel_con_cta,
    a.cod_dw_motivo_bloqueo,
    a.cod_dw_matricula,
    a.id_buro_persona;
ANALYZE rec_stage.tmp_ord_cal11;

-- ============================================================
-- Paso 2.1: Insertar registros históricos en TMP_ORD_CAL1
-- Combina los registros de flag_desde=0 (ya en cal1) con los
-- registros históricos calculados en cal11.
-- Nota: tmp_ord_cal11 tiene columnas compatibles con tmp_ord_cal1
--       (fecha_reporte = fecha_act, id_flag_nuevo=0, id_flag_desde=2)
-- ============================================================
INSERT INTO rec_stage.tmp_ord_cal1
    (cod_dw_reporte_persona_ubic, cod_dw_persona_ubic, id_buro_suscriptor,
     cod_dw_cta, fecha_reporte_step1, fecha_apertura, fecha_nov,
     desc_est_vigencia, nombre_natu_cta, nombre_tipo_rel_con_cta,
     cod_dw_motivo_bloqueo, id_flag_nuevo, id_flag_desde,
     fecha_reporte, cod_dw_matricula, id_buro_persona)
SELECT  cod_dw_reporte_persona_ubic,
        cod_dw_persona_ubic,
        id_buro_suscriptor,
        cod_dw_cta,
        fecha_reporte,          -- fecha_reporte_step1 = fecha_act
        fecha_apertura,
        fecha_nov,
        desc_est_vigencia,
        nombre_natu_cta,
        nombre_tipo_rel_con_cta,
        cod_dw_motivo_bloqueo,
        id_flag_nuevo,          -- 0
        id_flag_desde,          -- 2
        fecha_act,              -- fecha_reporte = fecha_act
        cod_dw_matricula,
        id_buro_persona
FROM rec_stage.tmp_ord_cal11;
ANALYZE rec_stage.tmp_ord_cal1;

-- Limpieza: eliminar tmp_ord_cal11 ya consumida
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal11;

-- ============================================================
-- Paso 3: Crear tabla auxiliar TMP_AGR_CNTAS_242
-- Extrae Cod_Entrega_Dato_Fte de VU_CUENTA para las cuentas
-- presentes en TMP_ORD_CAL1.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_agr_cntas_242;
CREATE TABLE rec_stage.tmp_agr_cntas_242
DISTSTYLE KEY DISTKEY(cod_dw_cta)
AS
SELECT  cod_dw_cta,
        cod_entrega_dato_fte
FROM rec_datos.vu_cuenta
WHERE cod_dw_cta IN (SELECT cod_dw_cta FROM rec_stage.tmp_ord_cal1);
ANALYZE rec_stage.tmp_agr_cntas_242;

-- ============================================================
-- Paso 4: Crear tabla TMP_ORD_CAL2
-- Agrega Cod_Entrega_Dato_Fte a los registros de TMP_ORD_CAL1
-- mediante LEFT JOIN con TMP_AGR_CNTAS_242.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal2;
CREATE TABLE rec_stage.tmp_ord_cal2
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  a.cod_dw_reporte_persona_ubic,
        a.cod_dw_persona_ubic,
        a.id_buro_suscriptor,
        a.cod_dw_cta,
        a.fecha_reporte_step1,
        a.fecha_apertura,
        a.fecha_nov,
        a.desc_est_vigencia,
        a.nombre_natu_cta,
        a.nombre_tipo_rel_con_cta,
        a.cod_dw_motivo_bloqueo,
        a.id_flag_nuevo,
        a.id_flag_desde,
        a.fecha_reporte,
        a.cod_dw_matricula,
        b.cod_entrega_dato_fte,
        a.id_buro_persona
FROM rec_stage.tmp_ord_cal1 a
LEFT JOIN rec_stage.tmp_agr_cntas_242 b
    ON a.cod_dw_cta = b.cod_dw_cta;
ANALYZE rec_stage.tmp_ord_cal2;

-- Limpieza: eliminar tablas intermedias ya consumidas
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal1;
DROP TABLE IF EXISTS rec_stage.tmp_agr_cntas_242;

-- ============================================================
-- Paso 5: Crear tabla TMP_ORD_CAL3 (resultado final)
-- Aplica ROW_NUMBER para limitar a 3 registros por combinación
-- (Cod_Entrega_Dato_Fte, Cod_DW_Persona_Ubic, Cod_DW_Cta, Id_Flag_Desde).
-- Reemplaza QUALIFY ROW_NUMBER() OVER(...) <= 3 de Teradata
-- por subquery con WHERE rn <= 3.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal3;
CREATE TABLE rec_stage.tmp_ord_cal3
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  cod_dw_reporte_persona_ubic,
        cod_dw_persona_ubic,
        id_buro_suscriptor,
        cod_dw_cta,
        fecha_reporte_step1,
        fecha_apertura,
        fecha_nov,
        desc_est_vigencia,
        nombre_natu_cta,
        nombre_tipo_rel_con_cta,
        cod_dw_motivo_bloqueo,
        id_flag_nuevo,
        id_flag_desde,
        fecha_reporte,
        cod_dw_matricula,
        id_buro_persona
FROM (
    SELECT  a.cod_dw_reporte_persona_ubic,
            a.cod_dw_persona_ubic,
            a.id_buro_suscriptor,
            a.cod_dw_cta,
            a.fecha_reporte_step1,
            a.fecha_apertura,
            a.fecha_nov,
            a.desc_est_vigencia,
            a.nombre_natu_cta,
            a.nombre_tipo_rel_con_cta,
            a.cod_dw_motivo_bloqueo,
            a.id_flag_nuevo,
            a.id_flag_desde,
            a.fecha_reporte,
            a.cod_dw_matricula,
            a.id_buro_persona,
            ROW_NUMBER() OVER (
                PARTITION BY a.cod_entrega_dato_fte,
                             a.cod_dw_persona_ubic,
                             a.cod_dw_cta,
                             a.id_flag_desde
                ORDER BY a.id_flag_desde
            ) AS rn
    FROM rec_stage.tmp_ord_cal2 a
) sub
WHERE rn <= 3;
ANALYZE rec_stage.tmp_ord_cal3;

-- Limpieza: eliminar TMP_ORD_CAL2 ya consumida
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal2;

-- ------------------------------------------------------------
-- Registro de FIN exitoso
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento, registros_afectados)
VALUES ('calc_ubicaciones', 'Fase 3', 'FIN', GETDATE(),
    (SELECT COUNT(*) FROM rec_stage.tmp_ord_cal3));
