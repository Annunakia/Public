-- ============================================================
-- Archivo: fase3_ubicaciones/03_calc_ubicaciones_1.sql
-- SP Original: PRO_ORD_CALC_UBICACIONES_1
-- Fase: 3 - Ubicaciones
-- Modo: Paralelo (con fase3_ubicaciones/02_calc_ubicaciones.sql)
-- Dependencias: fase3_ubicaciones/01_ubic_direcciones.sql
-- Input: rec_stage.tmp_ord_cal_mat,
--        rec_datos.vu_cuenta (para exclusión),
--        rec_datos.relacion_persona_ubicacion
-- Output: rec_stage.tmp_ord_cal6
-- Requerimientos: 11.1, 11.2, 11.3, 17.3, 20.3, 22.3
-- ============================================================
-- Objetivo: Calcula fechas de reporte ajustadas para ubicaciones que
--           NO tienen cuenta válida (cod_dw_cta NOT IN VU_CUENTA o
--           cod_dw_cta = -1).
--           Aplica las mismas reglas de negocio de fecha que
--           02_calc_ubicaciones.sql:
--             1) Si cuenta vigente (Desc_Est_Vigencia='A') y tipo es
--                principal/pasivo/codeudor:
--                - Registro nuevo (Id_Flag_Nuevo=1) → Fecha_Apertura
--                - Registro existente → Fecha_Reporte
--             2) Si cuenta NO vigente:
--                - MIN(Fecha_Nov, Fecha_Reporte)
--           Luego calcula registros históricos (flag_desde=1) y limita
--           a 3 registros por combinación persona-ubicación usando
--           ROW_NUMBER (subquery pattern en lugar de QUALIFY).
--
--           Tablas generadas:
--             - tmp_ord_cal6: Ubicaciones sin cuenta + fechas ajustadas
--                             (incluye históricos y top 3 final)
--             - tmp_ord_cal61: Registros históricos (flag_desde=1) con Fecha_Act
--                              (tabla intermedia, se elimina al final)
-- ============================================================

-- ------------------------------------------------------------
-- Registro de INICIO
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento)
VALUES ('calc_ubicaciones_1', 'Fase 3', 'INICIO', GETDATE());

-- ============================================================
-- Paso 1: Crear tabla TMP_ORD_CAL6
-- Filtra ubicaciones de TMP_ORD_CAL_MAT que NO tienen cuenta
-- válida en VU_CUENTA (cod_dw_cta NOT IN vu_cuenta).
-- Aplica reglas de negocio para calcular Fecha_Reporte ajustada:
--   - Vigente (A) + principal/pasivo/codeudor:
--       nuevo → Fecha_Apertura, existente → Fecha_Reporte
--   - No vigente o motivo bloqueo <> 1 y flag_desde=0:
--       MIN(Fecha_Nov, Fecha_Reporte)
--   - Otros casos: Fecha_Reporte
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal6;
CREATE TABLE rec_stage.tmp_ord_cal6
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  a.cod_dw_reporte_persona_ubic,
        a.cod_dw_persona_ubic,
        a.id_buro_suscriptor,
        a.cod_dw_cta,
        a.fecha_reporte                             AS fecha_reporte_step1,
        a.fecha_apertura,
        a.fecha_nov,
        a.desc_est_vigencia,
        a.nombre_natu_cta,
        a.nombre_tipo_rel_con_cta,
        a.cod_dw_motivo_bloqueo,
        a.id_flag_nuevo,
        a.id_flag_desde,
        CASE
            WHEN a.desc_est_vigencia = 'A' THEN
                CASE
                    WHEN a.nombre_natu_cta = 'PASIVO'
                         OR (a.nombre_natu_cta = 'ACTIVO' AND a.nombre_tipo_rel_con_cta = 'PRINCIPAL')
                         OR a.nombre_tipo_rel_con_cta = 'CODEUDOR'
                    THEN
                        CASE
                            WHEN a.id_flag_nuevo = 1 AND a.fecha_reporte IS NOT NULL
                            THEN a.fecha_apertura
                            ELSE a.fecha_reporte
                        END
                END
            ELSE
                CASE
                    WHEN (a.desc_est_vigencia <> 'A' OR a.cod_dw_motivo_bloqueo <> 1)
                         AND a.id_flag_desde = 0
                    THEN
                        CASE
                            WHEN a.fecha_reporte > a.fecha_nov
                            THEN a.fecha_nov
                            ELSE a.fecha_reporte
                        END
                    ELSE a.fecha_reporte
                END
        END                                         AS fecha_reporte,
        a.cod_dw_matricula,
        a.id_buro_persona
FROM rec_stage.tmp_ord_cal_mat a
WHERE a.cod_dw_cta NOT IN (SELECT cod_dw_cta FROM rec_datos.vu_cuenta);
ANALYZE rec_stage.tmp_ord_cal6;

-- ============================================================
-- Paso 2: Crear tabla TMP_ORD_CAL61
-- Calcula registros históricos (flag_desde=1) con la fecha más
-- reciente (Fecha_Act) obtenida del MAX(Fecha_Reporte) agrupado
-- por persona + ubicación + fuente + matrícula.
-- Solo incluye registros que también tienen un registro con
-- flag_desde=0 (registro actual).
-- Nota: A diferencia de calc_ubicaciones, aquí se agrupa por
-- Cod_DW_Persona_Ubic, Cod_DW_Fuente y Cod_DW_Matricula
-- (en lugar de cod_dw_cta) ya que no hay cuenta válida.
-- Filtro: cod_dw_cta = -1 OR cod_dw_cta IS NULL
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal61;
CREATE TABLE rec_stage.tmp_ord_cal61
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  a.cod_dw_reporte_persona_ubic,
        a.cod_dw_persona_ubic,
        a.id_buro_suscriptor,
        a.cod_dw_cta,
        c.fecha_act                                 AS fecha_reporte,
        a.fecha_apertura,
        a.fecha_nov,
        a.desc_est_vigencia,
        a.nombre_natu_cta,
        a.nombre_tipo_rel_con_cta,
        a.cod_dw_motivo_bloqueo,
        0                                           AS id_flag_nuevo,
        2                                           AS id_flag_desde,
        c.fecha_act,
        a.cod_dw_matricula,
        a.id_buro_persona
FROM rec_stage.tmp_ord_cal_mat a
INNER JOIN rec_datos.relacion_persona_ubicacion b
    ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
INNER JOIN (
    SELECT  b2.cod_pin_persona,
            b2.id_buro_persona,
            mat.cod_dw_persona_ubic,
            mat.cod_dw_fuente,
            mat.cod_dw_matricula,
            MAX(mat.fecha_reporte)                  AS fecha_act
    FROM rec_stage.tmp_ord_cal_mat mat
    INNER JOIN rec_datos.relacion_persona_ubicacion b2
        ON mat.cod_dw_persona_ubic = b2.cod_dw_persona_ubic
    WHERE mat.id_flag_desde = 1
      AND (mat.cod_dw_cta = -1 OR mat.cod_dw_cta IS NULL)
    GROUP BY b2.cod_pin_persona, b2.id_buro_persona,
             mat.cod_dw_persona_ubic, mat.cod_dw_fuente, mat.cod_dw_matricula
) c
    ON b.cod_pin_persona = c.cod_pin_persona
   AND b.id_buro_persona = c.id_buro_persona
   AND a.cod_dw_persona_ubic = c.cod_dw_persona_ubic
   AND a.cod_dw_fuente = c.cod_dw_fuente
   AND a.cod_dw_matricula = c.cod_dw_matricula
INNER JOIN (
    SELECT  cod_dw_reporte_persona_ubic,
            cod_dw_cta,
            cod_dw_persona_ubic,
            id_buro_suscriptor,
            cod_dw_matricula
    FROM rec_stage.tmp_ord_cal_mat
    WHERE id_flag_desde = 0
) d
    ON a.cod_dw_cta = d.cod_dw_cta
   AND a.cod_dw_persona_ubic = d.cod_dw_persona_ubic
   AND a.id_buro_suscriptor = d.id_buro_suscriptor
   AND a.cod_dw_matricula = d.cod_dw_matricula
GROUP BY
    a.cod_dw_reporte_persona_ubic,
    a.cod_dw_persona_ubic,
    a.id_buro_suscriptor,
    a.cod_dw_cta,
    c.fecha_act,
    a.fecha_apertura,
    a.fecha_nov,
    a.desc_est_vigencia,
    a.nombre_natu_cta,
    a.nombre_tipo_rel_con_cta,
    a.cod_dw_motivo_bloqueo,
    a.cod_dw_matricula,
    a.id_buro_persona;
ANALYZE rec_stage.tmp_ord_cal61;

-- ============================================================
-- Paso 2.1: Insertar registros históricos en TMP_ORD_CAL6
-- Combina los registros de flag_desde=0 (ya en cal6) con los
-- registros históricos calculados en cal61.
-- Nota: tmp_ord_cal61 tiene columnas compatibles con tmp_ord_cal6
--       (fecha_reporte = fecha_act, id_flag_nuevo=0, id_flag_desde=2)
-- ============================================================
INSERT INTO rec_stage.tmp_ord_cal6
    (cod_dw_reporte_persona_ubic, cod_dw_persona_ubic, id_buro_suscriptor,
     cod_dw_cta, fecha_reporte_step1, fecha_apertura, fecha_nov,
     desc_est_vigencia, nombre_natu_cta, nombre_tipo_rel_con_cta,
     cod_dw_motivo_bloqueo, id_flag_nuevo, id_flag_desde,
     fecha_reporte, cod_dw_matricula, id_buro_persona)
SELECT  cod_dw_reporte_persona_ubic,
        cod_dw_persona_ubic,
        id_buro_suscriptor,
        cod_dw_cta,
        fecha_reporte,          -- fecha_reporte_step1 = fecha_act
        fecha_apertura,
        fecha_nov,
        desc_est_vigencia,
        nombre_natu_cta,
        nombre_tipo_rel_con_cta,
        cod_dw_motivo_bloqueo,
        id_flag_nuevo,          -- 0
        id_flag_desde,          -- 2
        fecha_act,              -- fecha_reporte = fecha_act
        cod_dw_matricula,
        id_buro_persona
FROM rec_stage.tmp_ord_cal61;
ANALYZE rec_stage.tmp_ord_cal6;

-- Limpieza: eliminar tmp_ord_cal61 ya consumida
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal61;

-- ============================================================
-- Paso 3: Aplicar ROW_NUMBER para limitar a 3 registros
-- por combinación (Cod_DW_Persona_Ubic, Cod_DW_Cta, Id_Flag_Desde).
-- Reemplaza QUALIFY ROW_NUMBER() OVER(...) <= 3 de Teradata
-- por subquery con WHERE rn <= 3.
-- Nota: A diferencia de calc_ubicaciones, no se particiona por
-- Cod_Entrega_Dato_Fte ya que no hay cuenta válida.
-- Se recrea tmp_ord_cal6 con el resultado filtrado.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal6_pre;
ALTER TABLE rec_stage.tmp_ord_cal6 RENAME TO tmp_ord_cal6_pre;

CREATE TABLE rec_stage.tmp_ord_cal6
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  cod_dw_reporte_persona_ubic,
        cod_dw_persona_ubic,
        id_buro_suscriptor,
        cod_dw_cta,
        fecha_reporte_step1,
        fecha_apertura,
        fecha_nov,
        desc_est_vigencia,
        nombre_natu_cta,
        nombre_tipo_rel_con_cta,
        cod_dw_motivo_bloqueo,
        id_flag_nuevo,
        id_flag_desde,
        fecha_reporte,
        cod_dw_matricula,
        id_buro_persona
FROM (
    SELECT  a.cod_dw_reporte_persona_ubic,
            a.cod_dw_persona_ubic,
            a.id_buro_suscriptor,
            a.cod_dw_cta,
            a.fecha_reporte_step1,
            a.fecha_apertura,
            a.fecha_nov,
            a.desc_est_vigencia,
            a.nombre_natu_cta,
            a.nombre_tipo_rel_con_cta,
            a.cod_dw_motivo_bloqueo,
            a.id_flag_nuevo,
            a.id_flag_desde,
            a.fecha_reporte,
            a.cod_dw_matricula,
            a.id_buro_persona,
            ROW_NUMBER() OVER (
                PARTITION BY a.cod_dw_persona_ubic,
                             a.cod_dw_cta,
                             a.id_flag_desde
                ORDER BY a.id_flag_desde
            ) AS rn
    FROM rec_stage.tmp_ord_cal6_pre a
) sub
WHERE rn <= 3;
ANALYZE rec_stage.tmp_ord_cal6;

-- Limpieza: eliminar tabla pre-filtrado
DROP TABLE IF EXISTS rec_stage.tmp_ord_cal6_pre;

-- ------------------------------------------------------------
-- Registro de FIN exitoso
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento, registros_afectados)
VALUES ('calc_ubicaciones_1', 'Fase 3', 'FIN', GETDATE(),
    (SELECT COUNT(*) FROM rec_stage.tmp_ord_cal6));
