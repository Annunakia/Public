-- ============================================================
-- Archivo: fase3_ubicaciones/05_concat_direcciones.sql
-- SP Original: PRO_ORD_CONCAT_DIRECCIONES
-- Fase: 3 - Ubicaciones
-- Modo: Secuencial (depende de 04_calc_ubicaciones_2.sql)
-- Dependencias: fase3_ubicaciones/04_calc_ubicaciones_2.sql
-- Input: rec_stage.datos_tipo_cuenta
-- Output: rec_stage.hash_carac_direc
-- Requerimientos: 14.1, 14.2, 14.3, 17.4, 20.3, 22.3
-- ============================================================
-- Objetivo: Concatena atributos de dirección en un solo string y
--           calcula el hash MD5 para detección de cambios entre
--           ejecuciones. Genera la tabla hash_carac_direc con el
--           hash calculado por cada registro de dirección.
--
-- Nota: En Teradata el SP lee de DIRECCIONES_TEMP (alias de la
--       tabla final del flujo de ubicaciones). En esta migración
--       la tabla equivalente es rec_stage.datos_tipo_cuenta,
--       generada por 04_calc_ubicaciones_2.sql.
--
-- Atributos concatenados (en orden):
--   1. texto_ubicacion              - Texto de ubicación estandarizada
--   2. descripcion_tipo_ubicacion_dir - Tipo de ubicación (dirección)
--   3. descripcion_gestion_registro - Gestión del registro (Valida)
--   4. cod_dane_ciudad              - Código DANE municipio
--   5. cod_dane_departamento        - Código DANE departamento
--   6. desc_tipo_persona            - Tipo persona (natural/jurídica)
--   7. desc_tipo_cta                - Tipo de cuenta
--   8. direccion_fisica             - Dirección física completa
--   9. complemento                  - Complemento de dirección
--  10. urbanizacion_barrio          - Barrio / urbanización
--  11. latitud                      - Latitud geográfica
--  12. longitud                     - Longitud geográfica
--
-- Conversiones Teradata → Redshift aplicadas:
--   - CREATE MULTISET TABLE ... WITH DATA → DROP IF EXISTS + CREATE TABLE AS
--   - PRIMARY INDEX(Cod_dw_reporte_Persona_ubic) → DISTKEY(id_buro_persona)
--   - COLLECT STATISTICS → ANALYZE
--   - rec_vista.hash_md5(concatena) → MD5(concatena) nativo Redshift
--   - SQL dinámico (SP_EXECSTRING_DES) → SQL estático inline
--   - Esquemas dinámicos (P_BDSTAGE) → esquema fijo rec_stage
--   - TRIM() en cada atributo para consistencia con Teradata
-- ============================================================

-- ------------------------------------------------------------
-- Registro de INICIO
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento)
VALUES ('concat_direcciones', 'Fase 3', 'INICIO', GETDATE());

-- ============================================================
-- Paso 1: Crear tabla HASH_CARAC_DIREC
-- Concatena atributos de dirección y calcula hash MD5.
-- Usa COALESCE con '0' como valor por defecto para NULLs,
-- manteniendo compatibilidad con el SP original de Teradata.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.hash_carac_direc;
CREATE TABLE rec_stage.hash_carac_direc
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT  a.cod_pin_persona,
        a.id_buro_persona,
        a.cod_dw_persona_ubic,
        -- String concatenado de atributos de dirección
        COALESCE(CAST(TRIM(a.texto_ubicacion) AS VARCHAR(100)), '0')
        || COALESCE(CAST(TRIM(a.descripcion_tipo_ubicacion_dir) AS VARCHAR(200)), '0')
        || COALESCE(CAST(TRIM(a.descripcion_gestion_registro) AS VARCHAR(200)), '0')
        || COALESCE(CAST(TRIM(a.cod_dane_ciudad) AS VARCHAR(20)), '0')
        || COALESCE(CAST(TRIM(a.cod_dane_departamento) AS VARCHAR(20)), '0')
        || COALESCE(CAST(TRIM(a.desc_tipo_persona) AS VARCHAR(500)), '0')
        || COALESCE(CAST(TRIM(a.desc_tipo_cta) AS VARCHAR(500)), '0')
        || COALESCE(CAST(TRIM(a.direccion_fisica) AS VARCHAR(201)), '0')
        || COALESCE(CAST(TRIM(a.complemento) AS VARCHAR(100)), '0')
        || COALESCE(CAST(TRIM(a.urbanizacion_barrio) AS VARCHAR(20)), '0')
        || COALESCE(CAST(TRIM(a.latitud) AS VARCHAR(50)), '0')
        || COALESCE(CAST(TRIM(a.longitud) AS VARCHAR(50)), '0')
        AS concatena,
        -- Hash MD5 del string concatenado (reemplaza rec_vista.hash_md5)
        MD5(
            COALESCE(CAST(TRIM(a.texto_ubicacion) AS VARCHAR(100)), '0')
            || COALESCE(CAST(TRIM(a.descripcion_tipo_ubicacion_dir) AS VARCHAR(200)), '0')
            || COALESCE(CAST(TRIM(a.descripcion_gestion_registro) AS VARCHAR(200)), '0')
            || COALESCE(CAST(TRIM(a.cod_dane_ciudad) AS VARCHAR(20)), '0')
            || COALESCE(CAST(TRIM(a.cod_dane_departamento) AS VARCHAR(20)), '0')
            || COALESCE(CAST(TRIM(a.desc_tipo_persona) AS VARCHAR(500)), '0')
            || COALESCE(CAST(TRIM(a.desc_tipo_cta) AS VARCHAR(500)), '0')
            || COALESCE(CAST(TRIM(a.direccion_fisica) AS VARCHAR(201)), '0')
            || COALESCE(CAST(TRIM(a.complemento) AS VARCHAR(100)), '0')
            || COALESCE(CAST(TRIM(a.urbanizacion_barrio) AS VARCHAR(20)), '0')
            || COALESCE(CAST(TRIM(a.latitud) AS VARCHAR(50)), '0')
            || COALESCE(CAST(TRIM(a.longitud) AS VARCHAR(50)), '0')
        ) AS cod_hash
FROM rec_stage.datos_tipo_cuenta a;

ANALYZE rec_stage.hash_carac_direc;

-- ------------------------------------------------------------
-- Registro de FIN exitoso
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento, registros_afectados)
VALUES ('concat_direcciones', 'Fase 3', 'FIN', GETDATE(),
    (SELECT COUNT(*) FROM rec_stage.hash_carac_direc));
