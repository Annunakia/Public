-- ============================================================
-- Archivo: fase1_materializacion/01_materializa_btt.sql
-- SP Original: PRO_ORD_MATERIALIZA_BTT
-- Fase: 1 - Materialización
-- Modo: Paralelo (con 02_materializa_rec.sql)
-- Dependencias: shared/00_schemas_tablas_control.sql,
--               shared/01_log_ejecucion.sql
-- Input: rec_datos.control_ordenamiento,
--        rec_datos.metadata_carga_log,
--        rec_datos.v_cuenta,
--        rec_datos.v_buro_persona,
--        rec_datos.v_comportamiento_cuenta,
--        rec_datos.v_comportamiento_cuenta_activo,
--        rec_datos.v_comportamiento_cuenta_pasivo,
--        rec_datos.vu_cuenta
-- Output: rec_stage.estructuras_mtdat_bdm,
--         rec_stage.calcula_lote_btt,
--         rec_stage.paso_v_cuenta,
--         rec_stage.paso_v_buro_persona,
--         rec_stage.paso_v_comportamiento_cuenta,
--         rec_stage.paso_v_comport_cta_activo,
--         rec_stage.paso_v_comport_cta_pasivo
-- Requerimientos: 1.1, 1.2, 1.3, 1.4, 16.1, 16.2, 16.3, 17.7, 20.3, 22.3
-- ============================================================
-- Objetivo: Identifica personas afectadas por cambios en el modelo
--           Bureau (BTT) desde la última ejecución de ordenamiento.
--           Consulta el log de metadata para encontrar lotes con
--           inserts/updates y extrae los pares (Cod_Pin_Persona,
--           Id_Buro_Persona) de las tablas modificadas.
-- ============================================================

-- ------------------------------------------------------------
-- Registro de INICIO
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento)
VALUES ('materializa_btt', 'Fase 1', 'INICIO', GETDATE());

-- ============================================================
-- Paso 1: Crear tabla de estructuras de metadata (log de carga)
-- Convierte la fecha del log de metadata a formato DATE y
-- extrae la información de lotes, tablas e inserts/updates.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.estructuras_mtdat_bdm;
CREATE TABLE rec_stage.estructuras_mtdat_bdm AS
SELECT  lote_id         AS no_lote,
        tabla_nombre    AS tabla1,
        inserts_count   AS insert_1,
        updates_count   AS update_1,
        descripcion,
        fecha_carga     AS fechaproc
FROM rec_datos.metadata_carga_log;
ANALYZE rec_stage.estructuras_mtdat_bdm;

-- ============================================================
-- Paso 2: Calcular lotes BTT con cambios desde último ordenamiento
-- Filtra los lotes que tienen inserts o updates posteriores a la
-- fecha del último ordenamiento y cuyas tablas pertenecen al
-- modelo BTT (catálogo metadata_ordenamiento).
-- ============================================================
DROP TABLE IF EXISTS rec_stage.calcula_lote_btt;
CREATE TABLE rec_stage.calcula_lote_btt AS
SELECT  a.no_lote,
        a.fechaproc,
        a.tabla1
FROM rec_stage.estructuras_mtdat_bdm a
INNER JOIN rec_datos.control_ordenamiento b
    ON a.fechaproc >= b.fecha_ult_ord
WHERE a.tabla1 IN (
        SELECT nombre_tabla
        FROM rec_datos.metadata_ordenamiento
        WHERE nombre_db = 'BTT'
    )
    AND (a.insert_1 > 0 OR a.update_1 > 0)
    AND TRIM(a.descripcion) = 'Ok';
ANALYZE rec_stage.calcula_lote_btt;

-- ============================================================
-- Paso 3: Extraer personas de V_CUENTA modificadas
-- Identifica los pares (Cod_Pin_Persona, Id_Buro_Persona) de
-- cuentas que pertenecen a lotes con cambios en la tabla CUENTA.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.paso_v_cuenta;
CREATE TABLE rec_stage.paso_v_cuenta
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(cod_pin_persona, id_buro_persona)
AS
SELECT  c.cod_pin_persona,
        a.id_buro_cliente AS id_buro_persona
FROM rec_datos.v_cuenta a
INNER JOIN rec_stage.calcula_lote_btt b
    ON (a.lote = b.no_lote OR a.lote_actualizacion = b.no_lote)
    AND b.tabla1 = 'CUENTA'
INNER JOIN rec_datos.v_buro_persona c
    ON a.id_buro_cliente = c.id_buro_persona
GROUP BY 1, 2;
ANALYZE rec_stage.paso_v_cuenta;

-- ============================================================
-- Paso 4: Extraer personas de V_BURO_PERSONA modificadas
-- Identifica personas directamente modificadas en la tabla
-- BURO_PERSONA.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.paso_v_buro_persona;
CREATE TABLE rec_stage.paso_v_buro_persona
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(cod_pin_persona, id_buro_persona)
AS
SELECT  a.cod_pin_persona,
        a.id_buro_persona
FROM rec_datos.v_buro_persona a
INNER JOIN rec_stage.calcula_lote_btt b
    ON (a.lote = b.no_lote OR a.lote_actualizacion = b.no_lote)
    AND b.tabla1 = 'BURO_PERSONA'
GROUP BY 1, 2;
ANALYZE rec_stage.paso_v_buro_persona;

-- ============================================================
-- Paso 5: Extraer personas de V_COMPORTAMIENTO_CUENTA modificadas
-- Primero identifica las cuentas (Cod_DW_Cta) con cambios en
-- comportamiento, luego obtiene los Id_Buro_Cliente via VU_CUENTA,
-- y finalmente resuelve Cod_Pin_Persona via V_BURO_PERSONA.
-- ============================================================

-- 5a: Cuentas con cambios en comportamiento
DROP TABLE IF EXISTS rec_stage.tmp_paso_comcta_242;
CREATE TABLE rec_stage.tmp_paso_comcta_242 AS
SELECT  a.cod_dw_cta
FROM rec_datos.v_comportamiento_cuenta a
WHERE a.lote IN (
        SELECT no_lote FROM rec_stage.calcula_lote_btt
        WHERE tabla1 = 'COMPORTAMIENTO_CUENTA'
    )
    OR a.lote_actualizacion IN (
        SELECT no_lote FROM rec_stage.calcula_lote_btt
        WHERE tabla1 = 'COMPORTAMIENTO_CUENTA'
    )
GROUP BY 1;

-- 5b: Obtener Id_Buro_Cliente de las cuentas afectadas
DROP TABLE IF EXISTS rec_stage.tmp_paso_comcta_1_242;
CREATE TABLE rec_stage.tmp_paso_comcta_1_242 AS
SELECT  id_buro_cliente
FROM rec_datos.vu_cuenta
WHERE cod_dw_cta IN (SELECT cod_dw_cta FROM rec_stage.tmp_paso_comcta_242)
GROUP BY 1;

-- 5c: Resolver Cod_Pin_Persona y crear tabla final de paso
DROP TABLE IF EXISTS rec_stage.paso_v_comportamiento_cuenta;
CREATE TABLE rec_stage.paso_v_comportamiento_cuenta
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(cod_pin_persona, id_buro_persona)
AS
SELECT  c.cod_pin_persona,
        a.id_buro_cliente AS id_buro_persona
FROM rec_stage.tmp_paso_comcta_1_242 a
INNER JOIN rec_datos.v_buro_persona c
    ON a.id_buro_cliente = c.id_buro_persona
GROUP BY 1, 2;
ANALYZE rec_stage.paso_v_comportamiento_cuenta;

-- Limpieza de tablas auxiliares del paso 5
DROP TABLE IF EXISTS rec_stage.tmp_paso_comcta_242;
DROP TABLE IF EXISTS rec_stage.tmp_paso_comcta_1_242;

-- ============================================================
-- Paso 6: Extraer personas de V_COMPORTAMIENTO_CUENTA_ACTIVO
-- Identifica cuentas con cambios en comportamiento activo,
-- resuelve Id_Buro_Cliente via VU_CUENTA y Cod_Pin_Persona
-- via V_BURO_PERSONA.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.paso_v_comport_cta_activo;
CREATE TABLE rec_stage.paso_v_comport_cta_activo
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(cod_pin_persona, id_buro_persona)
AS
SELECT  c.cod_pin_persona,
        x.id_buro_cliente AS id_buro_persona
FROM rec_datos.v_comportamiento_cuenta_activo a
INNER JOIN rec_stage.calcula_lote_btt b
    ON (a.lote = b.no_lote OR a.lote_actualizacion = b.no_lote)
    AND b.tabla1 = 'COMPORTAMIENTO_CUENTA_ACTIVO'
INNER JOIN rec_datos.vu_cuenta x
    ON a.cod_dw_cta = x.cod_dw_cta
INNER JOIN rec_datos.v_buro_persona c
    ON x.id_buro_cliente = c.id_buro_persona
GROUP BY 1, 2;
ANALYZE rec_stage.paso_v_comport_cta_activo;

-- ============================================================
-- Paso 7: Extraer personas de V_COMPORTAMIENTO_CUENTA_PASIVO
-- Mismo patrón que paso 6 pero para comportamiento pasivo.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.paso_v_comport_cta_pasivo;
CREATE TABLE rec_stage.paso_v_comport_cta_pasivo
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(cod_pin_persona, id_buro_persona)
AS
SELECT  c.cod_pin_persona,
        x.id_buro_cliente AS id_buro_persona
FROM rec_datos.v_comportamiento_cuenta_pasivo a
INNER JOIN rec_stage.calcula_lote_btt b
    ON (a.lote = b.no_lote OR a.lote_actualizacion = b.no_lote)
    AND b.tabla1 = 'COMPORTAMIENTO_CUENTA_PASIVO'
INNER JOIN rec_datos.vu_cuenta x
    ON a.cod_dw_cta = x.cod_dw_cta
INNER JOIN rec_datos.v_buro_persona c
    ON x.id_buro_cliente = c.id_buro_persona
GROUP BY 1, 2;
ANALYZE rec_stage.paso_v_comport_cta_pasivo;

-- ------------------------------------------------------------
-- Registro de FIN exitoso
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento, registros_afectados)
VALUES ('materializa_btt', 'Fase 1', 'FIN', GETDATE(),
    (SELECT COUNT(*) FROM rec_stage.paso_v_cuenta)
    + (SELECT COUNT(*) FROM rec_stage.paso_v_buro_persona)
    + (SELECT COUNT(*) FROM rec_stage.paso_v_comportamiento_cuenta)
    + (SELECT COUNT(*) FROM rec_stage.paso_v_comport_cta_activo)
    + (SELECT COUNT(*) FROM rec_stage.paso_v_comport_cta_pasivo)
);
