-- ============================================================
-- Archivo: fase1_materializacion/04_limpieza_validacion.sql
-- SP Original: PRO_ORD_UNIF_BTT_REC_2
-- Fase: 1 - Materialización
-- Modo: Secuencial (depende de 03_unifica_btt_rec.sql y
--        procesos dependientes de unifica_btt_reconocer)
-- Dependencias: fase1_materializacion/03_unifica_btt_rec.sql,
--               fase2_atributos_cuenta/ (todos),
--               fase3_ubicaciones/ (todos)
-- Input: rec_stage.log_ejecucion
-- Output: (limpieza de tablas temporales de paso)
-- Requerimientos: 4.1, 4.2, 4.3, 17.7, 22.2
-- ============================================================
-- Objetivo: Valida que no hubo errores en pasos anteriores
--           consultando el log de ejecución. Si se detectan
--           errores, genera una excepción (RAISE) para detener
--           la ejecución. Si todo está correcto, elimina todas
--           las tablas temporales de paso (~17 tablas) del
--           esquema rec_stage para liberar espacio.
-- ============================================================

-- ============================================================
-- Procedimiento wrapper: permite usar RAISE EXCEPTION para
-- señalar errores al orquestador (código de retorno ≠ 0).
-- Los scripts SQL estáticos no pueden usar RAISE directamente;
-- se requiere un bloque procedural.
-- ============================================================
CREATE OR REPLACE PROCEDURE rec_stage.sp_limpieza_validacion()
AS $$
DECLARE
    v_errores INTEGER;
BEGIN
    -- --------------------------------------------------------
    -- Registro de INICIO
    -- --------------------------------------------------------
    INSERT INTO rec_stage.log_ejecucion
        (nombre_procedimiento, fase, evento, timestamp_evento)
    VALUES ('limpieza_validacion', 'Fase 1', 'INICIO', GETDATE());

    -- ========================================================
    -- Paso 1: Validar que no hubo errores en pasos anteriores
    -- Consulta el log_ejecucion buscando eventos ERROR
    -- posteriores al último INICIO del proceso de
    -- materialización (que marca el inicio de la ejecución
    -- actual del pipeline).
    -- ========================================================
    SELECT COUNT(*) INTO v_errores
    FROM rec_stage.log_ejecucion
    WHERE evento = 'ERROR'
      AND timestamp_evento >= (
          SELECT MAX(timestamp_evento)
          FROM rec_stage.log_ejecucion
          WHERE evento = 'INICIO'
            AND nombre_procedimiento = 'materializa_btt'
      );

    IF v_errores > 0 THEN
        -- Registrar el error en el log antes de abortar
        INSERT INTO rec_stage.log_ejecucion
            (nombre_procedimiento, fase, evento, timestamp_evento, mensaje_error)
        VALUES ('limpieza_validacion', 'Fase 1', 'ERROR', GETDATE(),
            'Se detectaron ' || v_errores::VARCHAR || ' errores en pasos anteriores. Abortando limpieza.');

        RAISE EXCEPTION 'Limpieza abortada: se detectaron % errores en pasos anteriores.', v_errores;
    END IF;

    -- ========================================================
    -- Paso 2: Eliminar tablas temporales de paso
    -- Usa DROP TABLE IF EXISTS para evitar errores si alguna
    -- tabla no existe (Req 4.3, 17.7).
    -- ========================================================

    -- Tablas de materializa_btt (5 tablas de paso)
    DROP TABLE IF EXISTS rec_stage.paso_v_cuenta;
    DROP TABLE IF EXISTS rec_stage.paso_v_buro_persona;
    DROP TABLE IF EXISTS rec_stage.paso_v_comportamiento_cuenta;
    DROP TABLE IF EXISTS rec_stage.paso_v_comport_cta_activo;
    DROP TABLE IF EXISTS rec_stage.paso_v_comport_cta_pasivo;

    -- Tablas de materializa_rec (9 tablas de paso)
    DROP TABLE IF EXISTS rec_stage.paso_reporte_ubic_original;
    DROP TABLE IF EXISTS rec_stage.paso_rpu;
    DROP TABLE IF EXISTS rec_stage.paso_rrpu;
    DROP TABLE IF EXISTS rec_stage.paso_v_bloqueo;
    DROP TABLE IF EXISTS rec_stage.paso_v_rela_ubic_estandar_geo;
    DROP TABLE IF EXISTS rec_stage.paso_v_ubicacion_original;
    DROP TABLE IF EXISTS rec_stage.paso_v_ubicacion_estandarizada;
    DROP TABLE IF EXISTS rec_stage.paso_v_log_ubic_estandarizada;
    DROP TABLE IF EXISTS rec_stage.paso_v_unificacion_direccion;

    -- Tablas auxiliares de materialización
    DROP TABLE IF EXISTS rec_stage.estructuras_mtdat_bdm;
    DROP TABLE IF EXISTS rec_stage.calcula_lote_btt;
    DROP TABLE IF EXISTS rec_stage.calcula_lote_rec;

    -- --------------------------------------------------------
    -- Registro de FIN exitoso
    -- --------------------------------------------------------
    INSERT INTO rec_stage.log_ejecucion
        (nombre_procedimiento, fase, evento, timestamp_evento, registros_afectados)
    VALUES ('limpieza_validacion', 'Fase 1', 'FIN', GETDATE(), 17);

EXCEPTION
    WHEN OTHERS THEN
        -- Si el error no fue generado por nuestra validación,
        -- registrar en log y re-lanzar
        INSERT INTO rec_stage.log_ejecucion
            (nombre_procedimiento, fase, evento, timestamp_evento, mensaje_error)
        VALUES ('limpieza_validacion', 'Fase 1', 'ERROR', GETDATE(), SQLERRM);
        RAISE;
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- Ejecutar el procedimiento
-- ============================================================
CALL rec_stage.sp_limpieza_validacion();
