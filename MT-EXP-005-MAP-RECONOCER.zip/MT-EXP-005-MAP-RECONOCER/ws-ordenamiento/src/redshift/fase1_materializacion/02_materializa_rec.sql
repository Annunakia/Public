-- ============================================================
-- Archivo: fase1_materializacion/02_materializa_rec.sql
-- SP Original: PRO_ORD_MATERIALIZA_REC
-- Fase: 1 - Materialización
-- Modo: Paralelo (con 01_materializa_btt.sql)
-- Dependencias: shared/00_schemas_tablas_control.sql,
--               shared/01_log_ejecucion.sql
-- Input: rec_datos.control_ordenamiento,
--        rec_datos.log_td,
--        rec_datos.metadata_ordenamiento,
--        rec_datos.v_reporte_ubicacion_original,
--        rec_datos.vu_relacion_persona_ubicacion,
--        rec_datos.vu_reporte_relacion_pers_ubi,
--        rec_datos.v_bloqueo,
--        rec_datos.v_relacion_persona_ubicacion,
--        rec_datos.v_relacion_ubicac_estandar_geo,
--        rec_datos.v_ubicacion_original,
--        rec_datos.v_ubicacion_estandarizada,
--        rec_datos.v_log_ubicacion_estandariza,
--        rec_datos.v_unificacion_direccion
-- Output: rec_stage.calcula_lote_rec,
--         rec_stage.paso_reporte_ubic_original,
--         rec_stage.paso_rpu,
--         rec_stage.paso_rrpu,
--         rec_stage.paso_v_bloqueo,
--         rec_stage.paso_v_rela_ubic_estandar_geo,
--         rec_stage.paso_v_ubicacion_original,
--         rec_stage.paso_v_ubicacion_estandarizada,
--         rec_stage.paso_v_log_ubic_estandarizada,
--         rec_stage.paso_v_unificacion_direccion
-- Requerimientos: 2.1, 2.2, 2.3, 2.4, 16.1, 16.2, 16.3, 17.7, 20.3, 22.3
-- ============================================================
-- Objetivo: Identifica personas afectadas por cambios en el modelo
--           Reconocer (REC) desde la última ejecución de ordenamiento.
--           Consulta el log de carga (log_td) para encontrar lotes con
--           cargas exitosas y extrae los pares (Cod_Pin_Persona,
--           Id_Buro_Persona) de las 10 tablas fuente de ubicaciones,
--           relaciones persona-ubicación, bloqueos, estandarización
--           y unificación.
-- ============================================================

-- ------------------------------------------------------------
-- Registro de INICIO
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento)
VALUES ('materializa_rec', 'Fase 1', 'INICIO', GETDATE());

-- ============================================================
-- Paso 1: Calcular lotes REC con cargas exitosas desde último
-- ordenamiento. Consulta log_td para identificar lotes cuyas
-- tablas destino pertenecen al modelo REC (según metadata) y
-- cuyo estado de ejecución indica carga exitosa.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.calcula_lote_rec;
CREATE TABLE rec_stage.calcula_lote_rec AS
SELECT  a.lote,
        a.fecha_hora_inicio,
        a.tabla_destino_prod
FROM rec_datos.log_td a
INNER JOIN rec_datos.control_ordenamiento b
    ON a.fecha_hora_inicio >= b.fecha_ult_ord
WHERE TRIM(a.tabla_destino_prod) IN (
        SELECT nombre_tabla
        FROM rec_datos.metadata_ordenamiento
        WHERE nombre_db = 'REC'
    )
    AND a.estado_ejecucion IN ('Cargue Ok', 'Finalizado OK');
ANALYZE rec_stage.calcula_lote_rec;

-- ============================================================
-- Paso 2: Extraer personas de REPORTE_UBICACION_ORIGINAL
-- Identifica pares (Cod_Pin_Persona, Id_Buro_Persona) de
-- reportes de ubicación original que pertenecen a lotes con
-- cambios en la tabla REPORTE_UBICACION_ORIGINAL.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.paso_reporte_ubic_original;
CREATE TABLE rec_stage.paso_reporte_ubic_original
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(cod_pin_persona, id_buro_persona)
AS
SELECT  a.cod_pin_persona,
        a.id_buro_persona
FROM rec_datos.v_reporte_ubicacion_original a
WHERE a.lote IN (
        SELECT lote FROM rec_stage.calcula_lote_rec
        WHERE tabla_destino_prod = 'REPORTE_UBICACION_ORIGINAL'
    )
    OR a.lote_actualizacion IN (
        SELECT lote FROM rec_stage.calcula_lote_rec
        WHERE tabla_destino_prod = 'REPORTE_UBICACION_ORIGINAL'
    )
GROUP BY 1, 2;
ANALYZE rec_stage.paso_reporte_ubic_original;

-- ============================================================
-- Paso 3: Extraer personas de RELACION_PERSONA_UBICACION (RPU)
-- Identifica personas cuya relación persona-ubicación fue
-- modificada en lotes recientes.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.paso_rpu;
CREATE TABLE rec_stage.paso_rpu
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(cod_pin_persona, id_buro_persona)
AS
SELECT  a.cod_pin_persona,
        a.id_buro_persona
FROM rec_datos.vu_relacion_persona_ubicacion a
INNER JOIN rec_stage.calcula_lote_rec b
    ON (a.lote = b.lote OR a.lote_actualizacion = b.lote)
    AND b.tabla_destino_prod = 'RELACION_PERSONA_UBICACION'
GROUP BY 1, 2;
ANALYZE rec_stage.paso_rpu;

-- ============================================================
-- Paso 4: Extraer personas de REPORTE_RELACION_PERSONA_UBICA (RRPU)
-- Primero identifica Cod_DW_Persona_Ubic con cambios en reportes
-- de relación, luego resuelve las personas via la tabla de
-- relación persona-ubicación.
-- ============================================================

-- 4a: Obtener Cod_DW_Persona_Ubic con cambios en reportes
DROP TABLE IF EXISTS rec_stage.tmp_paso_rrpu_242;
CREATE TABLE rec_stage.tmp_paso_rrpu_242 AS
SELECT  cod_dw_persona_ubic
FROM rec_datos.vu_reporte_relacion_pers_ubi
WHERE lote IN (
        SELECT lote FROM rec_stage.calcula_lote_rec
        WHERE tabla_destino_prod = 'REPORTE_RELACION_PERSONA_UBICA'
    )
    OR lote_actualizacion IN (
        SELECT lote FROM rec_stage.calcula_lote_rec
        WHERE tabla_destino_prod = 'REPORTE_RELACION_PERSONA_UBICA'
    )
GROUP BY 1;
ANALYZE rec_stage.tmp_paso_rrpu_242;

-- 4b: Resolver personas desde la relación persona-ubicación
DROP TABLE IF EXISTS rec_stage.paso_rrpu;
CREATE TABLE rec_stage.paso_rrpu
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(cod_pin_persona, id_buro_persona)
AS
SELECT  b.cod_pin_persona,
        b.id_buro_persona
FROM rec_stage.tmp_paso_rrpu_242 a
INNER JOIN rec_datos.vu_relacion_persona_ubicacion b
    ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
GROUP BY 1, 2;
ANALYZE rec_stage.paso_rrpu;

-- Limpieza de tabla auxiliar del paso 4
DROP TABLE IF EXISTS rec_stage.tmp_paso_rrpu_242;

-- ============================================================
-- Paso 5: Extraer personas de V_BLOQUEO
-- Identifica personas cuyas ubicaciones fueron bloqueadas
-- después de la última ejecución de ordenamiento. Cruza
-- V_BLOQUEO con Control_Ordenamiento por fecha y resuelve
-- personas via V_RELACION_PERSONA_UBICACION.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.paso_v_bloqueo;
CREATE TABLE rec_stage.paso_v_bloqueo
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(cod_pin_persona, id_buro_persona)
AS
SELECT  x.cod_pin_persona,
        x.id_buro_persona
FROM rec_datos.v_bloqueo a
INNER JOIN rec_datos.control_ordenamiento b
    ON a.fecha_bloqueo >= b.fecha_ult_ord
INNER JOIN rec_datos.v_relacion_persona_ubicacion x
    ON a.cod_dw_persona_ubic = x.cod_dw_persona_ubic
GROUP BY 1, 2;
ANALYZE rec_stage.paso_v_bloqueo;

-- ============================================================
-- Paso 6: Extraer personas de RELACION_UBICAC_ESTANDAR_GEO
-- Primero identifica Cod_DW_Ubic con cambios en la relación
-- ubicación-estandarización geográfica, luego resuelve personas
-- via V_RELACION_PERSONA_UBICACION.
-- ============================================================

-- 6a: Obtener Cod_DW_Ubic con cambios en estandarización geo
DROP TABLE IF EXISTS rec_stage.tmp_relaubicestangeo_242;
CREATE TABLE rec_stage.tmp_relaubicestangeo_242 AS
SELECT  cod_dw_ubic
FROM rec_datos.v_relacion_ubicac_estandar_geo
WHERE lote IN (
        SELECT lote FROM rec_stage.calcula_lote_rec
        WHERE tabla_destino_prod = 'RELACION_UBICAC_ESTANDAR_GEO'
    )
    OR lote_actualizacion IN (
        SELECT lote FROM rec_stage.calcula_lote_rec
        WHERE tabla_destino_prod = 'RELACION_UBICAC_ESTANDAR_GEO'
    )
GROUP BY 1;
ANALYZE rec_stage.tmp_relaubicestangeo_242;

-- 6b: Resolver personas desde la relación persona-ubicación
DROP TABLE IF EXISTS rec_stage.paso_v_rela_ubic_estandar_geo;
CREATE TABLE rec_stage.paso_v_rela_ubic_estandar_geo
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(cod_pin_persona, id_buro_persona)
AS
SELECT  cod_pin_persona,
        id_buro_persona
FROM rec_datos.v_relacion_persona_ubicacion
WHERE cod_dw_ubic IN (SELECT cod_dw_ubic FROM rec_stage.tmp_relaubicestangeo_242)
GROUP BY 1, 2;
ANALYZE rec_stage.paso_v_rela_ubic_estandar_geo;

-- Limpieza de tabla auxiliar del paso 6
DROP TABLE IF EXISTS rec_stage.tmp_relaubicestangeo_242;

-- ============================================================
-- Paso 7: Extraer personas de V_UBICACION_ORIGINAL
-- Primero identifica Cod_DW_Ubic con cambios en ubicación
-- original, luego resuelve personas via
-- V_RELACION_PERSONA_UBICACION.
-- ============================================================

-- 7a: Obtener Cod_DW_Ubic con cambios en ubicación original
DROP TABLE IF EXISTS rec_stage.tmp_lote_relperubic_242;
CREATE TABLE rec_stage.tmp_lote_relperubic_242 AS
SELECT  cod_dw_ubic
FROM rec_datos.v_ubicacion_original
WHERE lote IN (
        SELECT lote FROM rec_stage.calcula_lote_rec
        WHERE tabla_destino_prod = 'UBICACION_ORIGINAL'
    )
    OR lote_actualizacion IN (
        SELECT lote FROM rec_stage.calcula_lote_rec
        WHERE tabla_destino_prod = 'UBICACION_ORIGINAL'
    )
GROUP BY 1;
ANALYZE rec_stage.tmp_lote_relperubic_242;

-- 7b: Resolver personas desde la relación persona-ubicación
DROP TABLE IF EXISTS rec_stage.paso_v_ubicacion_original;
CREATE TABLE rec_stage.paso_v_ubicacion_original
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(cod_pin_persona, id_buro_persona)
AS
SELECT  cod_pin_persona,
        id_buro_persona
FROM rec_datos.v_relacion_persona_ubicacion
WHERE cod_dw_ubic IN (SELECT cod_dw_ubic FROM rec_stage.tmp_lote_relperubic_242)
GROUP BY 1, 2;
ANALYZE rec_stage.paso_v_ubicacion_original;

-- Limpieza de tabla auxiliar del paso 7
DROP TABLE IF EXISTS rec_stage.tmp_lote_relperubic_242;

-- ============================================================
-- Paso 8: Extraer personas de V_UBICACION_ESTANDARIZADA
-- Identifica ubicaciones estandarizadas con cambios en lotes
-- recientes y resuelve personas via V_RELACION_PERSONA_UBICACION.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.paso_v_ubicacion_estandarizada;
CREATE TABLE rec_stage.paso_v_ubicacion_estandarizada
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(cod_pin_persona, id_buro_persona)
AS
SELECT  x.cod_pin_persona,
        x.id_buro_persona
FROM rec_datos.v_ubicacion_estandarizada a
INNER JOIN rec_stage.calcula_lote_rec b
    ON (a.lote = b.lote OR a.lote_actualizacion = b.lote)
    AND b.tabla_destino_prod = 'UBICACION_ESTANDARIZADA'
INNER JOIN rec_datos.v_relacion_persona_ubicacion x
    ON a.cod_dw_ubic = x.cod_dw_ubic
GROUP BY 1, 2;
ANALYZE rec_stage.paso_v_ubicacion_estandarizada;

-- ============================================================
-- Paso 9: Extraer personas de V_LOG_UBICACION_ESTANDARIZADA
-- Identifica registros de log de ubicación estandarizada con
-- cambios en lotes recientes y resuelve personas via
-- V_RELACION_PERSONA_UBICACION.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.paso_v_log_ubic_estandarizada;
CREATE TABLE rec_stage.paso_v_log_ubic_estandarizada
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(cod_pin_persona, id_buro_persona)
AS
SELECT  x.cod_pin_persona,
        x.id_buro_persona
FROM rec_datos.v_log_ubicacion_estandariza a
INNER JOIN rec_stage.calcula_lote_rec b
    ON (a.lote = b.lote OR a.lote_actualizacion = b.lote)
    AND b.tabla_destino_prod = 'LOG_UBICACION_ESTANDARIZADA'
INNER JOIN rec_datos.v_relacion_persona_ubicacion x
    ON a.cod_dw_ubic = x.cod_dw_ubic
GROUP BY 1, 2;
ANALYZE rec_stage.paso_v_log_ubic_estandarizada;

-- ============================================================
-- Paso 10: Extraer personas de V_UNIFICACION_DIRECCION
-- Identifica registros de unificación de dirección con cambios
-- en lotes recientes y resuelve personas via
-- V_RELACION_PERSONA_UBICACION usando Cod_DW_Persona_Ubic.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.paso_v_unificacion_direccion;
CREATE TABLE rec_stage.paso_v_unificacion_direccion
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(cod_pin_persona, id_buro_persona)
AS
SELECT  x.cod_pin_persona,
        x.id_buro_persona
FROM rec_datos.v_unificacion_direccion a
INNER JOIN rec_stage.calcula_lote_rec b
    ON (a.lote = b.lote OR a.lote_actualizacion = b.lote)
    AND b.tabla_destino_prod = 'UNIFICACION_DIRECCION'
INNER JOIN rec_datos.v_relacion_persona_ubicacion x
    ON a.cod_dw_persona_ubic = x.cod_dw_persona_ubic
GROUP BY 1, 2;
ANALYZE rec_stage.paso_v_unificacion_direccion;

-- ------------------------------------------------------------
-- Registro de FIN exitoso
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento, registros_afectados)
VALUES ('materializa_rec', 'Fase 1', 'FIN', GETDATE(),
    (SELECT COUNT(*) FROM rec_stage.paso_reporte_ubic_original)
    + (SELECT COUNT(*) FROM rec_stage.paso_rpu)
    + (SELECT COUNT(*) FROM rec_stage.paso_rrpu)
    + (SELECT COUNT(*) FROM rec_stage.paso_v_bloqueo)
    + (SELECT COUNT(*) FROM rec_stage.paso_v_rela_ubic_estandar_geo)
    + (SELECT COUNT(*) FROM rec_stage.paso_v_ubicacion_original)
    + (SELECT COUNT(*) FROM rec_stage.paso_v_ubicacion_estandarizada)
    + (SELECT COUNT(*) FROM rec_stage.paso_v_log_ubic_estandarizada)
    + (SELECT COUNT(*) FROM rec_stage.paso_v_unificacion_direccion)
);
