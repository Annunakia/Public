-- ============================================================
-- Archivo: fase1_materializacion/03_unifica_btt_rec.sql
-- SP Original: PRO_ORD_UNIF_BTT_REC
-- Fase: 1 - Materialización
-- Modo: Secuencial (depende de 01_materializa_btt.sql y
--        02_materializa_rec.sql)
-- Dependencias: fase1_materializacion/01_materializa_btt.sql,
--               fase1_materializacion/02_materializa_rec.sql
-- Input: rec_stage.paso_v_cuenta,
--        rec_stage.paso_v_buro_persona,
--        rec_stage.paso_v_comportamiento_cuenta,
--        rec_stage.paso_v_comport_cta_activo,
--        rec_stage.paso_v_comport_cta_pasivo,
--        rec_stage.paso_reporte_ubic_original,
--        rec_stage.paso_rpu,
--        rec_stage.paso_rrpu,
--        rec_stage.paso_v_bloqueo,
--        rec_stage.paso_v_rela_ubic_estandar_geo,
--        rec_stage.paso_v_ubicacion_original,
--        rec_stage.paso_v_ubicacion_estandarizada,
--        rec_stage.paso_v_log_ubic_estandarizada,
--        rec_stage.paso_v_unificacion_direccion
-- Output: rec_stage.unifica_btt_reconocer
-- Requerimientos: 3.1, 3.2, 3.3, 17.2, 20.3, 22.3
-- ============================================================
-- Objetivo: Consolida las personas identificadas por ambos modelos
--           (BTT y REC) en una sola tabla sin duplicados. Ejecuta
--           UNION ALL de las 14 tablas de paso y aplica SELECT
--           DISTINCT para reemplazar el comportamiento de CREATE
--           SET TABLE de Teradata.
-- ============================================================

-- ------------------------------------------------------------
-- Registro de INICIO
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento)
VALUES ('unifica_btt_rec', 'Fase 1', 'INICIO', GETDATE());

-- ============================================================
-- Paso 1: Unificar las 14 tablas de paso con SELECT DISTINCT
-- En Teradata se usaba CREATE SET TABLE que elimina duplicados
-- automáticamente. En Redshift se reemplaza con SELECT DISTINCT
-- sobre el UNION ALL de todas las tablas de paso.
-- ============================================================
DROP TABLE IF EXISTS rec_stage.unifica_btt_reconocer;
CREATE TABLE rec_stage.unifica_btt_reconocer
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, cod_pin_persona)
AS
SELECT DISTINCT cod_pin_persona, id_buro_persona
FROM (
    -- Tablas de materializa_btt (5)
    SELECT cod_pin_persona, id_buro_persona FROM rec_stage.paso_v_cuenta
    UNION ALL
    SELECT cod_pin_persona, id_buro_persona FROM rec_stage.paso_v_buro_persona
    UNION ALL
    SELECT cod_pin_persona, id_buro_persona FROM rec_stage.paso_v_comportamiento_cuenta
    UNION ALL
    SELECT cod_pin_persona, id_buro_persona FROM rec_stage.paso_v_comport_cta_activo
    UNION ALL
    SELECT cod_pin_persona, id_buro_persona FROM rec_stage.paso_v_comport_cta_pasivo
    UNION ALL
    -- Tablas de materializa_rec (9)
    SELECT cod_pin_persona, id_buro_persona FROM rec_stage.paso_reporte_ubic_original
    UNION ALL
    SELECT cod_pin_persona, id_buro_persona FROM rec_stage.paso_rpu
    UNION ALL
    SELECT cod_pin_persona, id_buro_persona FROM rec_stage.paso_rrpu
    UNION ALL
    SELECT cod_pin_persona, id_buro_persona FROM rec_stage.paso_v_bloqueo
    UNION ALL
    SELECT cod_pin_persona, id_buro_persona FROM rec_stage.paso_v_rela_ubic_estandar_geo
    UNION ALL
    SELECT cod_pin_persona, id_buro_persona FROM rec_stage.paso_v_ubicacion_original
    UNION ALL
    SELECT cod_pin_persona, id_buro_persona FROM rec_stage.paso_v_ubicacion_estandarizada
    UNION ALL
    SELECT cod_pin_persona, id_buro_persona FROM rec_stage.paso_v_log_ubic_estandarizada
    UNION ALL
    SELECT cod_pin_persona, id_buro_persona FROM rec_stage.paso_v_unificacion_direccion
);
ANALYZE rec_stage.unifica_btt_reconocer;

-- ------------------------------------------------------------
-- Registro de FIN exitoso
-- ------------------------------------------------------------
INSERT INTO rec_stage.log_ejecucion
    (nombre_procedimiento, fase, evento, timestamp_evento, registros_afectados)
VALUES ('unifica_btt_rec', 'Fase 1', 'FIN', GETDATE(),
    (SELECT COUNT(*) FROM rec_stage.unifica_btt_reconocer)
);
