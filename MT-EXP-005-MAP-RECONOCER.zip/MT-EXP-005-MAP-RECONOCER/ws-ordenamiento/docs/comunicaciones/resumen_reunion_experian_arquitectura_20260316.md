# Resumen – Reunión con Experian (Arquitectura y Planeación)
**Fecha**: 16 de marzo de 2026  
**Tipo**: Reunión con cliente (Experian)  
**Participantes**: Equipo Macondotek (Fer, Adriana, Wilmar) + Equipo Experian (Carlitos/Carlos, Janet, Ricardo Martínez, Diego Reina, Julián Méndez)

---

## Contexto

Sesión de planeación y alineación arquitectónica para definir workshops, dependencias y prioridades del proyecto de migración de Reconocer.

---

## Decisiones y Acuerdos Clave

### 1. POC de Estandarización – Pipeline IFR
- Se confirmó que la POC de Libpostal se ejecutará sobre el **pipeline de IFR** (no sobre Alfa), en la etapa de **Curation**.
- IFR es el pipeline que va a quedar como definitivo.
- La POC puede ejecutarse sin certeza de dónde se ejecutará finalmente (IFR o Alfa), porque el proceso de Curation será el mismo.

### 2. Dependencia Crítica: IFR
- El proyecto tiene **dependencia directa de IFR**. Si IFR no sale, Reconocer no sale.
- Fecha tentativa de IFR: **agosto 2026**, pero depende de certificación de datos.
- Se acordó **priorizar la data que requiere Reconocer dentro de IFR** para no bloquear el proyecto.

### 3. Deadline de Teradata
- Fecha límite para apagar Teradata: **abril-mayo 2027** (renovación de licenciamiento).
- Si no se termina la migración, hay que renovar Teradata (costo significativo).

### 4. Validación de la POC – Triple Aprobación
- La POC se dará por exitosa con **tres aprobaciones**:
  1. **Equipo de Datos** (Caterina): Que la estandarización cumpla criterios definidos.
  2. **Equipo de Producto** (Diego Reina / Julián Méndez): Que la salida sirva para el producto Reconocer.
  3. **Equipo de IFR/Pipeline**: Que el impacto en tiempo y performance sea aceptable.

### 5. Sección Locations del XPM
- Se debe validar si la **sección Locations del XPM** tiene todos los campos que necesita Reconocer.
- Si no los tiene, hay que evaluar si se agregan a Locations o se crea una nueva sección.
- Crear una nueva sección tiene un proceso formal (gobierno de datos).
- **Tarea asignada**: Diego Santucci revisará con Johnny si Locations ya tiene todo lo necesario.

### 6. Métricas Base
- Se necesitan **métricas actuales** del proceso de estandarización en Teradata para tener punto de comparación:
  - Tiempos de la malla de estandarización (Control-M).
  - Tiempos de Curation en el pipeline actual.
- **Tarea**: Revisar con Alejandro Restrepo las métricas de Curation de IFR.
- **Tarea**: Revisar con el equipo de Control-M las métricas de la malla de estandarización.

---

## Workshops Definidos

### Workshop 1: Alineación Técnica Interna
- Revisar videos y análisis previos del proceso de Reconocer.
- Participantes: Adriana, Juan Carlos, Wilmar.

### Workshop 2: Sesión con Producto y Datos
- Levantamiento de criterios de aceptación de la estandarización.
- Definir qué espera Producto de la salida estandarizada.
- Participantes: Diego Reina (Producto), Caterina (Datos), equipo Macondotek.

### Workshop 3: Revisión de Artefactos en Teradata
- Tablas, vistas y procedimientos almacenados.
- Entender la estructura actual para planificar migración.

### Workshop 4: Revisión de Malla de Ordenamiento
- Entender el proceso de ordenamiento actual.
- Mapear dependencias y complejidad.

### Workshop 5: Sesión Técnica de Redshift
- Compatibilidad de datos entre Teradata y Redshift.
- Configuración y aprovisionamiento de Redshift.
- Participantes: Equipo de infraestructura + Johnny + Néstor.

---

## Priorización de Frentes

Se definieron **tres frentes en orden de prioridad**:

1. **Tratamiento y alistamiento de datos** (EDF + Redshift) – Prioridad inmediata, todo abril.
2. **Producto Batch** – Después de cerrar datos.
3. **Producto en Línea** – Último frente.

---

## Hallazgos Relevantes sobre Ordenamiento

- Los procedimientos almacenados de ordenamiento en Teradata son **muy grandes** (ej: 420 pasos para teléfonos).
- La estructura de tablas en Redshift **no es la misma** que en Teradata (nombres diferentes, tablas particionadas diferente).
- Esto implica que **no se puede copiar SQL directamente** de Teradata a Redshift.
- Hay que hacer un **mapeo de fuentes, campos y tablas** entre ambas plataformas.
- Se identificó que el algoritmo de ordenamiento puede requerir **re-implementación**, no solo migración.
- Las reglas de ordenamiento están documentadas en un documento que fue entregado previamente.

### Riesgo Nuevo: Funciones Nativas de Teradata
- Algunos procedimientos usan funciones nativas de Teradata que **no existen en Redshift**.
- Si esto ocurre, hay que definir cómo reemplazarlas.

---

## Sobre DB2 y Orquestación
- DB2 tiene dos responsabilidades: resultado en línea y parametría de procesos Batch.
- Hay **6 mallas** de Control-M para el producto Batch: inicio, sincronización, explotación, transferencia, distanciamiento.
- Se acordó **no abordar DB2 ni consumo de producto** hasta cerrar el frente de datos.
- La orquestación de procesos Batch se evaluará si se puede integrar con el framework existente.

---

## Información Adicional Solicitada (por correo)
- Versión de Redshift aprovisionado.
- Cantidad de tablas, tamaño, tipo de máquinas.
- Volúmenes de procedimientos almacenados.
- Configuración actual de Redshift.
