# Resumen – Reunión Interna Macondotek
**Fecha**: 17 de marzo de 2026  
**Tipo**: Reunión interna Macondotek  
**Participantes**: Wilmar (Líder de Preventa), Lorena (Planeación), Francisco (Líder Técnico Plataforma/EDF)

---

## Contexto

Sesión interna para presentar el proyecto de migración de Reconocer a Francisco, quien liderará la línea de trabajo de EDF (estandarización). Se discutió viabilidad técnica, estrategia de equipos y estimación de esfuerzo.

---

## Presentación del Proyecto a Francisco

### Alcance General
- Teradata tiene deadline de apagado (31 marzo 2027). Nubitral migra la mayoría de procesos batch, pero **Reconocer quedó por fuera** y fue asignado a Macondotek.
- El proyecto se divide en:
  1. **Estandarización** (Teradata → EDF/Curation): Reemplazar algoritmos en C por Libpostal.
  2. **Ordenamiento** (Teradata → Redshift): Migrar procedimientos almacenados SQL.
  3. **Cálculos y exposición** (Teradata → Redshift → DB2): Tablas y vistas para productos en línea.

### Estrategia de 5 Líneas de Trabajo
Wilmar propuso abrir 5 equipos paralelos:
1. **EDF + POC Libpostal** (línea azul) – Francisco lidera.
2. **Arquitectura y validación** – Redefinir y validar con Experian.
3. **Redshift – Migración de procedimientos almacenados**.
4. **Orquestación del proceso** (EDF → Redshift, scheduling).
5. **Entendimiento del producto** (configuraciones DB2, batch, servicio en línea).

**Fecha de entrega**: Octubre 2026.

---

## Viabilidad Técnica – Evaluación de Francisco

### Sobre Libpostal
- Francisco **ve viable** la estrategia de usar Libpostal como reemplazo de los algoritmos en C.
- Confirmó que una **librería Java funciona dentro de Scala** (interoperabilidad JVM), lo cual es clave porque Curation en EDF está escrito en Scala.
- No se necesita un perfil Java dedicado; se necesita un perfil **Scala con conocimiento deseable de Java**.

### Sobre la POC
- Francisco advierte que el mes propuesto para la POC **puede quedarse corto**.
- La POC debería estar **alineada al mundo real de IDF**, no ser un ejercicio aislado.
- Sugiere que la POC se despliegue al menos hasta **demo** con datos suficientes para probar.
- El pipeline objetivo es **IFR** (no Alfa), lo cual sube la complejidad.

### Propuesta de POC Interna Previa
- Francisco propone hacer primero un **ejercicio interno** (sin ambiente Experian):
  - Tomar direcciones de ejemplo.
  - Pasarlas por Libpostal.
  - Evaluar si la salida se parece a lo que produce el sistema actual.
  - Esto disipa incertidumbre rápidamente antes de entrar al ambiente formal.
- Para esto se pueden usar herramientas de IA (Claude Code, Kiro) ya que es fuera del ambiente Experian.

### Sobre el Ordenamiento en Redshift
- Francisco mencionó que la estructura de tablas en Redshift **no es la misma** que en Teradata.
- Los nombres de tablas cambian, lo que en Teradata es 1 tabla en Redshift puede ser 5.
- Esto implica que **no se pueden migrar los procedimientos almacenados directamente**.
- Sugirió evaluar si tiene más sentido hacer el ordenamiento en **EDF** en lugar de Redshift, aprovechando Spark, Iceberg y el ecosistema de catálogo de datos.

### Sobre EDF vs Redshift para Ordenamiento
- EDF tiene Spark, catálogo de datos, Iceberg, y más versatilidad que PL/SQL de Redshift.
- Francisco y Wilmar acordaron estar **abiertos a tener esa conversación** con arquitectura.

---

## Definición de Equipos y Roles

### Línea EDF (Azul) – POC + Estandarización
- **Líder técnico**: Francisco (parcial, compartido con plataforma).
- **Desarrollador/Guía**: Diego (conoce Curation, ha trabajado con equipo de arquitectura y Jorman).
- **Desarrollador adicional**: 1 persona Scala (con deseable Java), 100% dedicada.
- Se confirmó que **solo se impactará Curation**, el resto del pipeline no se toca.

### Línea Redshift (Morada) – Ordenamiento
- **Líder técnico**: Francisco también lideraría esta línea (conceptualización, revisión).
- **Perfil necesario**: Data Engineer con SQL fuerte (perfil tipo PL/SQL, no Scala).
- **QA**: Se necesita un recurso de QA/Cuba para pruebas.
- Diego no lidera, pero guía al desarrollador con su conocimiento de Curation.

### Modelo de Liderazgo
- Francisco como **líder técnico de ambas líneas** (EDF y Redshift).
- Diego como **guía/desarrollador senior** en la línea EDF.
- Un desarrollador Scala dedicado 100% a la implementación en EDF.
- Un Data Engineer SQL dedicado a Redshift.

---

## Ventana de Tiempo

- **Deadline real para EDF**: Junio 2026 (datos estandarizados en XPM).
- La POC tiene margen de moverse, pero **junio es inamovible** para tener la ingesta y estandarización lista.
- El XPM que salga de EDF alimenta Redshift; si cambia, impacta todo el proyecto.
- Estrategia: **definir un XPM base** y que los demás equipos trabajen sobre eso, mientras EDF ajusta internamente.

---

## Sobre el Equipo de Plataforma
- Francisco será sacado **parcialmente** del equipo de plataforma para liderar Reconocer.
- Laura ya está empoderada en plataforma (habla con Oxygen, se defiende en inglés, maneja dailies).
- Diego sigue en rol técnico puro con mínima comunicación (solo daily).
- Se necesita reforzar el equipo de plataforma con nuevas contrataciones para compensar.
- Hay una entrevista pendiente con **Diego Poveda** para evaluar si entra a ingesta o plataforma.

---

## Contexto Administrativo
- Experian va a **erradicar el modelo de staffing**. Los servicios de Macondotek (ingesta, plataforma) se quedan porque no son staffing sino servicios con entregables.
- Esto da margen de maniobra para mover recursos entre proyectos internamente.
- Si hay conflictos de asignación, escalar a Edwin.

---

## Acciones Inmediatas
1. **Francisco**: Evaluar complejidad de Curation con Diego, entender qué tanto conoce.
2. **Francisco**: Revisar perfil de Diego Poveda para posible incorporación.
3. **Wilmar/Lorena**: Armar Excel con plan de equipos, roles y dedicación.
4. **Equipo**: Sesión a las 3:30pm del mismo día para continuar planeación.
5. **Próximo paso**: Planear inicio en abril, con setup de equipo y levantamiento de información (workshops, accesos a Teradata, insumos).
