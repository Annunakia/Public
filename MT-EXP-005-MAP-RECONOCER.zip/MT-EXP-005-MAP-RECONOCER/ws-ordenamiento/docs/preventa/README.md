# Preventa

Los documentos de preventa se centralizaron en una única ubicación canónica:

👉 [proyecto/preventa/](../../../proyecto/preventa/)

Esta carpeta ya no contiene archivos individuales para evitar duplicados entre workspaces.
