# Reporte Consolidado de Inputs EDF v2 — Análisis Exacto del Código Fuente Teradata

> Identifica las tablas y columnas exactas que los procesos de Ordenamiento y Unificación necesitan recibir desde EDF (Spark/Scala) como insumo en Redshift.
> Fecha: 2025-01-27 | Fuente: Código Teradata original (`Ordenamiento.sql`, `Unificacion.sql`, `Caracteristicas.txt`)

---

## 1. Ordenamiento — Tablas INPUT exactas

### 1.1 Fase 1: Materialización

#### PRO_ORD_MATERIALIZA_BTT (schema P_BTTVISTA / P_BDDATOS)

| # | Tabla | Columnas requeridas | Cant. cols |
|---|-------|-------------------|-----------|
| 1 | MetadataCargaLog | No_Lote (lote_id), Tabla1 (tabla_nombre), Insert_1 (inserts_count), Update_1 (updates_count), descripcion, fecha (fecha_carga) | 6 |
| 2 | V_CUENTA | Cod_DW_Cta, Id_Buro_Cliente, Lote, Lote_Actualizacion | 4 |
| 3 | V_buro_persona | Id_Buro_Persona, Cod_Pin_Persona, Lote, Lote_Actualizacion | 4 |
| 4 | V_COMPORTAMIENTO_CUENTA | Cod_DW_Cta, Lote, Lote_Actualizacion | 3 |
| 5 | VU_CUENTA | Cod_DW_Cta, Id_Buro_Cliente | 2 |
| 6 | V_COMPORTAMIENTO_CUENTA_ACTIVO | Cod_DW_Cta, Lote, Lote_Actualizacion | 3 |
| 7 | V_COMPORTAMIENTO_CUENTA_PASIVO | Cod_DW_Cta, Lote, Lote_Actualizacion | 3 |

#### PRO_ORD_MATERIALIZA_REC (schema P_BDVISTA / P_BDDATOS)

| # | Tabla | Columnas requeridas | Cant. cols |
|---|-------|-------------------|-----------|
| 8 | LOG_TD | Lote, Fecha_Hora_Inicio, Tabla_Destino_Prod, Estado_Ejecucion | 4 |
| 9 | CONTROL_ORDENAMIENTO | Fecha_Ult_Ord | 1 |
| 10 | METADATA_ORDENAMIENTO | Nombre_Tabla, Nombre_DB | 2 |
| 11 | V_reporte_ubicacion_original | Cod_Pin_Persona, Id_Buro_Persona, Lote, Lote_Actualizacion | 4 |
| 12 | VU_RELACION_PERSONA_UBICACION | Cod_Pin_Persona, Id_Buro_Persona, Cod_DW_Persona_Ubic, Lote, Lote_Actualizacion | 5 |
| 13 | VU_Reporte_Relacion_Pers_Ubi | Cod_DW_Persona_Ubic, Lote, Lote_Actualizacion | 3 |
| 14 | V_BLOQUEO | Cod_DW_Persona_Ubic, Fecha_Bloqueo | 2 |
| 15 | V_RELACION_PERSONA_UBICACION | Cod_DW_Persona_Ubic, Cod_Pin_Persona, Id_Buro_Persona | 3 |
| 16 | v_RELACION_UBICAC_ESTANDAR_GEO | Cod_DW_Ubic, Lote, Lote_Actualizacion | 3 |
| 17 | V_UBICACION_ORIGINAL | Cod_DW_Ubic, Lote, Lote_Actualizacion | 3 |
| 18 | V_UBICACION_ESTANDARIZADA | Cod_DW_Ubic, Lote, Lote_Actualizacion | 3 |
| 19 | V_Log_Ubicacion_Estandariza | Cod_DW_Ubic, Lote, Lote_Actualizacion | 3 |
| 20 | V_UNIFICACION_DIRECCION | Cod_DW_Persona_Ubic, Lote, Lote_Actualizacion | 3 |

---

### 1.2 Fase 2: Atributos de Cuenta

#### PRO_ORD_CTA_ATRIBUTOS (schema P_BTTVISTA)

| # | Tabla | Columnas requeridas | Cant. cols |
|---|-------|-------------------|-----------|
| 21 | VU_CUENTA (full) | Cod_DW_Cta, Cod_DW_Tipo_Cta, Cod_Tipo_Cta_Fte, Num_Cta, Id_Buro_Suscriptor, Nit_Suscriptor, Id_Buro_Cliente, Cod_Pin_Persona, Cod_Tipo_Ident_Fte, Num_Ident, Cod_DW_Doc_Ident, Num_Contr, Fecha_Apertura, Fecha_Vencimiento, Ind_Moneda_Legal, Cod_DW_Est_Mod, Cod_Est_Mod_Fte, Ind_Tarjeta_Amparada, Nombre_Ciudad_Radicacion, Cod_DW_Razon_Bloqueo, Num_Plastico, Cod_DW_Clase_Tarjeta_Credito, Cod_Clase_Tarjeta_Credito_Fte, Cod_DW_Franquicia, Cod_Franquicia_Fte, Cod_Marca_Privada_Fte, Cod_DW_Tipo_Rel_Con_Cta, Cod_Tipo_Rel_Con_Cta_Fte, Cod_DW_Motivo_Origen, Cod_Motivo_Origen_Fte, Cod_DW_Tipo_Obligacion, Cod_Tipo_Obligacion_Fte, Cod_DW_Clase_Cta, Cod_Clase_Cta_Fte, Cod_DW_Clase_Garantia_Buro, Cod_Clase_Garantia_Buro_Fte, Cod_DW_Tipo_Bloqueo, Cod_Tipo_Bloqueo_Fte, Fecha_Ultima_Actualizacion, Cod_DW_Pais, Cod_Pais_Geo_Fte, Cod_DW_Fte_Dato, Cod_DW_Evento_Entrega_Dato, Nombre_Cod_Entrega_Dato, Desc_Cod_Entrega_Dato, Cod_Entrega_Dato_Fte, Cod_Nov_Buro_Fte, Desc_Est_Vigencia, Fecha_Ultima_Actualizacion_Nov, Cod_DW_Est_Suscriptor, Fecha_Est, Cod_Est_Suscriptor_Fte, Cod_Motivo_Bloqueo_Fte, Cod_DW_Natu_Cta, Cod_Natu_Cta_Fte, Fecha_Nov, Cod_Calif_Comp_Cta_Fte, Cod_DW_Entrega_Dato | 57 |

#### PRO_ORD_CTA_ATRIBUTOS (schema P_BDVISTA)

| # | Tabla | Columnas requeridas | Cant. cols |
|---|-------|-------------------|-----------|
| 22 | V_Razon_Bloqueo | Cod_DW_Razon_Bloqueo, Cod_Razon_Bloqueo_Fte | 2 |
| 23 | V_FUENTE_DATO | Cod_DW_Fte_Dato, Cod_Fte_Dato_Fte | 2 |
| 24 | V_COD_ENTREGA_DATO | Cod_DW_Entrega_Dato, Fecha_Ingreso_Suscriptor | 2 |

#### PRO_ORD_CTA_TOTALES_PERSONAS_1 (schema P_BTTVISTA)

| # | Tabla | Columnas requeridas | Cant. cols |
|---|-------|-------------------|-----------|
| 25 | vu_comportamiento_cta_Activo | Cod_DW_Cta, Valor_Inicial, Valor_Cuota_Mensual, Valor_Saldo, Numero_Dias_Mora, Valor_Saldo_Mora, Num_Cuotas_Pagadas, Valor_Disponible, Num_Cuotas_Mora, Num_Cuotas_Pactadas, Fecha_Nov, Cod_Altura_Mora_Fte | 12 |

#### PRO_ORD_CTA_TOTALES_PERSONAS_2 (schema P_BTTVISTA)

| # | Tabla | Columnas requeridas | Cant. cols |
|---|-------|-------------------|-----------|
| 26 | vu_comportamiento_cta_pasivo | COD_DW_CTA, Fecha_Nov, Valor_Debitos_Efec, Valor_Creditos_Efec, Valor_Debitos_Transf, Valor_Creditos_Transf, Valor_Cheques_Pags, Valor_Cheques_Devs, Cantidad_Cheques_Devs, Cantidad_Cheques_Pags, Dias_Sobregiro_Aut, Valor_Cupo_Sobregiro_Aut | 12 |

#### PRO_ORD_FINAL_CTA_ATRIBUTOS (schema P_BDVISTA)

| # | Tabla | Columnas requeridas | Cant. cols |
|---|-------|-------------------|-----------|
| 27 | V_CUENTA_ATRIBUTO_HASH | Cod_Pin_Persona, Id_Buro_Persona, Cod_DW_Cta, Cod_DW_HASH | 4 |

---

### 1.3 Fase 3: Ubicaciones

#### PRO_ORD_UBIC_DIRECCIONES (schema P_BDDATOS)

| # | Tabla | Columnas requeridas | Cant. cols |
|---|-------|-------------------|-----------|
| 28 | relacion_persona_ubicacion | cod_pin_persona, id_buro_persona, cod_dw_persona_ubic | 3 |
| 29 | MAT_REPORTE_REL_PERS_UBI | Cod_DW_Reporte_Persona_Ubic, Cod_DW_Persona_Ubic, Id_Buro_Suscriptor, Cod_DW_Cta, Fecha_Reporte, Fecha_Apertura, Fecha_Nov, Desc_Est_Vigencia, Nombre_Natu_Cta, Nombre_Tipo_Rel_con_Cta, Cod_DW_Motivo_Bloqueo, Id_Flag_Nuevo, Id_Flag_Desde, Flag_Bloqueo, Cod_DW_Fuente, Cod_DW_Matricula | 16 |

#### PRO_ORD_CALC_UBICACIONES (schema P_BTTVISTA)

| # | Tabla | Columnas requeridas (adicionales) | Cant. cols |
|---|-------|-------------------|-----------|
| — | VU_CUENTA | (ya listada en #5/#21) — col adicional usada: Cod_Entrega_Dato_Fte | — |

#### PRO_ORD_CALC_UBICACIONES_2 (schema P_BDDATOS + P_BDVISTA + P_BTTVISTA)

| # | Tabla | Columnas requeridas | Cant. cols |
|---|-------|-------------------|-----------|
| 30 | bloqueo | cod_dw_persona_ubic | 1 |
| 31 | V_Ubicacion_estandarizada (full) | Cod_DW_Ubic, Cod_DW_Tipo_Ubicacion, Texto_Ubicacion, Cod_DW_Fuente_Est, cod_Dw_ciudad, Cod_DW_Gestion_Registro | 6 |
| 32 | v_gestion_registro | Cod_DW_Gestion_Registro, descripcion_gestion_registro | 2 |
| 33 | v_Fuente | Cod_DW_Fuente, Descripcion_Fuente | 2 |
| 34 | V_Geografia | cod_dw_ciudad, Cod_Dane_Municipio, Cod_Dane_Departamento | 3 |
| 35 | V_Tipo_Ubicacion_Direccion | Cod_DW_Tipo_Ubicacion_Dir, Descripcion_Tipo_Ubicacion_Dir | 2 |
| 36 | VU_Persona | cod_pin_persona, id_buro_persona, Cod_DW_Tipo_Persona | 3 |
| 37 | V_Tipo_persona | Cod_DW_Tipo_Persona, Desc_Tipo_Persona | 2 |
| 38 | v_tipo_cuenta | cod_dw_tipo_cta, Desc_Tipo_Cta | 2 |
| 39 | direccion_fisica | cod_dw_ubic, cod_dw_direccion_fisica, Complemento | 3 |
| 40 | relacion_ubicac_estandar_Geo | cod_dw_ubic, Urbanizacion_Barrio, Latitud, Longitud | 4 |

#### PRO_ORD_FINAL_UBIC_DIRECCIONES1 (schema P_BDVISTA)

| # | Tabla | Columnas requeridas | Cant. cols |
|---|-------|-------------------|-----------|
| 41 | V_UBICACION_ATRIBUTO_HASH | cod_pin_persona, id_buro_persona, Cod_DW_Persona_Ubic, Cod_DW_Hash | 4 |

---

### 1.4 Fase 4: Scoring por Canal (Caracteristicas.txt — 260 sentencias SQL dinámicas)

> Fuente: `Caracteristicas.txt` (133KB). Ejecutado por PRO_Cursor_caract* (4 cursores, uno por canal).

#### Tablas de Coeficientes Beta (schema REC_VISTA)

| # | Tabla | Columnas requeridas | Cant. cols | Canal |
|---|-------|-------------------|-----------|-------|
| 42 | V_Beta_Ordenamiento_Tel | Cod_Caracteristica_Fte, Valor_Beta | 2 | TEL |
| 43 | V_Beta_Ordenamiento_Cel | Cod_Caracteristica_Fte, Valor_Beta | 2 | CEL |
| 44 | V_Beta_Ordenamiento_Email | Cod_Caracteristica_Fte, Valor_Beta | 2 | EMA |
| 45 | V_Beta_Ordenamiento_Dir | Cod_Caracteristica_Fte, Valor_Beta | 2 | DIR |

#### Tablas de Referencia para Scoring (schema REC_VISTA)

| # | Tabla | Columnas requeridas | Cant. cols | Uso |
|---|-------|-------------------|-----------|-----|
| 46 | VM_Reporte_Relacion_Pers_Ubi | Cod_DW_Persona_Ubic, Id_Buro_Suscriptor, Fecha_Reporte, Cod_DW_Cta, Descripcion_Gestion_Registro | 5 | Insumo base para todos los canales |
| 47 | V_DIRECCION_ELECTRONICA | Cod_DW_Persona_Ubic, Direccion_Electronica, Dominio | 3 | Canal EMA — dominio del email |
| 48 | V_Ind_Efectiv_Orden_Peso_Email | Cod_Caracteristica_Fte, Valor_Peso | 2 | Canal EMA — peso de efectividad |
| 49 | V_Operador_Ord_Cel | Prefijo, Operador, Cod_Operador | 3 | Canal CEL — clasificación por operador |
| 50 | V_Tipo_Cuenta_Ord | Cod_DW_Tipo_Cta, Tipo_Cuenta_Ord | 2 | Todos — clasificación tipo cuenta para scoring |
| 51 | V_Tipo_Ubicacion | Cod_DW_Tipo_Ubicacion, Descripcion_Tipo_Ubicacion | 2 | Canal DIR — tipo de ubicación |

#### Tabla de Configuración (schema REC_DATOS)

| # | Tabla | Columnas requeridas | Cant. cols | Uso |
|---|-------|-------------------|-----------|-----|
| 52 | CARACTERISTICA | Cod_Caracteristica_Fte, Descripcion_Caracteristica, SQL_String | 3 | Almacena las 260 sentencias SQL del scoring |

---

## 2. Unificación — Tablas INPUT exactas

> Fuente: `Unificacion.sql` + `mapeo_campos_xpm.md` (32 campos requeridos)

| # | Tabla | Columnas requeridas | Cant. cols | Reglas que la usan |
|---|-------|-------------------|-----------|-------------------|
| 1 | RELACION_PERSONA_UBICACION | Id_Buro_Persona, Cod_Pin_Persona, Cod_DW_Persona_Ubic, Cod_DW_Ubic, Cod_DW_Direccion_Fisica, Cod_DW_Tipo_Ubicacion_Dir, Ind_Unificacion, Orden_Prioridad, Fecha_Relacion_Persona_Ubicaci, Lote, Cod_Tipo_Ident_Fte, Bloqueado, Cod_DW_Municipio | 13 | R1, R2, R3 |
| 2 | UBICACION_ESTANDARIZADA | Cod_DW_Ubic, Texto_Ubicacion, Cod_DW_Ciudad, Cod_DW_Tipo_Ubicacion, Latitud, Longitud | 6 | R1, R2, R3 |
| 3 | DIRECCION_FISICA | Cod_DW_Ubic, Cod_DW_Direccion_Fisica, Complemento, Tipo_Via_Principal, Via_Principal, Via_Generadora, Numero_Puerta, Generada_Enriquecida | 8 | R2, R3 |
| 4 | REPORTE_RELACION_PERSONA_UBICA | Cod_DW_Persona_Ubic, Id_Buro_Suscriptor, Fecha_Reporte | 3 | R1, R2, R3 |
| 5 | CIIU_PERSONA (bdm_vista.v_persona_act_economica_ciiu) | Id_Buro_Persona, Cod_Act_Econo_CIIU_Fte | 2 | R1 |
| 6 | TIPO_UBICACION_DIR | Cod_DW_Tipo_Ubicacion_Dir, Descripcion_Tipo_Ubicacion_Dir | 2 | R1, R2 |
| 7 | NOMENCLATURA | Nomenclatura, Nivel_Complemento | 2 | R1, R2 |
| 8 | V_Tipo_Identificacion | Cod_Tipo_Ident_Fte, Nombre_Tipo_Ident | 2 | R2 |
| 9 | MAX_ID (REC_MTDAT) | ID, NOMBRE_TABLA | 2 | R2 |
| 10 | DICCIONARIO_COMPLEMENTOS | cod_dw_ubic, nomenclatura, nomen, valor, frecuencia | 5 | R1, R2 |
| 11 | UNIFICACION_DIRECCION (output/input) | Cod_DW_Persona_Ubic, Cod_DW_Direccion_Unificada, Unifica_Atributos, Fecha_Unificacion, Lote, Severidad, Usuario_BD | 7 | R1, R2, R3 |

> **Nota sobre tabla #10 (DICCIONARIO_COMPLEMENTOS):** Es una tabla STAGE que se puebla durante la ejecución del proceso, pero se lee de vuelta en pasos posteriores. Funciona como input intermedio.

> **Nota sobre tabla #11 (UNIFICACION_DIRECCION):** Es tanto output como input — cada regla lee los resultados de las reglas anteriores para no re-unificar registros ya procesados.

---

## 3. Resumen Cuantitativo

### Conteo de tablas únicas

| Proceso | Tablas únicas | Total columnas (sin duplicar) |
|---------|--------------|------------------------------|
| Ordenamiento (Fase 1-3: Materialización + Atributos + Ubicaciones) | **41** | ~170 |
| Ordenamiento (Fase 4: Scoring por Canal) | **11** | ~26 |
| **Ordenamiento TOTAL** | **52** | ~196 |
| Unificación | **11** | ~52 |
| **Total combinado (sin duplicar entre procesos)** | **55** | ~230 |

#### Detalle de deduplicación — Ordenamiento

Las siguientes tablas aparecen en múltiples SPs pero se cuentan UNA sola vez:

| Tabla | Aparece en |
|-------|-----------|
| VU_CUENTA | Fase 1 (#5), Fase 2 (#21), Fase 3 (PRO_ORD_CALC_UBICACIONES) |
| V_UBICACION_ESTANDARIZADA | Fase 1 (#18), Fase 3 (#31) |
| relacion_persona_ubicacion | Fase 1 (#12 como VU_), Fase 3 (#28) |

Tablas únicas Ordenamiento: 41 listadas − 4 duplicadas = **37 tablas únicas**

#### Detalle de deduplicación — Unificación

No hay duplicados internos. Las 11 tablas listadas son todas únicas.

#### Tablas compartidas entre ambos procesos

Ver Sección 4.

---

## 4. Tablas Compartidas entre Ordenamiento y Unificación

| # | Tabla | Uso en Ordenamiento | Uso en Unificación |
|---|-------|--------------------|--------------------|
| 1 | RELACION_PERSONA_UBICACION / V_RELACION_PERSONA_UBICACION / VU_RELACION_PERSONA_UBICACION | Fase 1 (#12, #15), Fase 3 (#28) | Input principal (#1) |
| 2 | UBICACION_ESTANDARIZADA / V_UBICACION_ESTANDARIZADA | Fase 1 (#18), Fase 3 (#31) | Input (#2) |
| 3 | DIRECCION_FISICA | Fase 3 (#39) | Input (#3) |
| 4 | UNIFICACION_DIRECCION / V_UNIFICACION_DIRECCION | Fase 1 (#20) — lee resultado de Unificación | Output/Input (#11) |
| 5 | BLOQUEO / V_BLOQUEO | Fase 1 (#14), Fase 3 (#30) | Implícito en campo `Bloqueado` de RELACION_PERSONA_UBICACION |
| 6 | TIPO_UBICACION_DIR / V_Tipo_Ubicacion_Direccion | Fase 3 (#35) | Input (#6) |
| 7 | relacion_ubicac_estandar_Geo | Fase 1 (#16), Fase 3 (#40) | Implícito (Latitud/Longitud en UBICACION_ESTANDARIZADA) |

**Total tablas compartidas: 7** (de las 44 combinadas, 7 son la misma tabla usada por ambos procesos)

**Total tablas verdaderamente únicas (global): 44 − 4 compartidas que se contaron doble = ~44** (ya deduplicadas en el conteo de la Sección 3)

---

## 5. Notas sobre Ambigüedades Resueltas

### 5.1 V_CUENTA vs VU_CUENTA

| Aspecto | V_CUENTA | VU_CUENTA |
|---------|----------|-----------|
| Schema | P_BTTVISTA | P_BTTVISTA |
| Tipo | Vista simple sobre tabla base | Vista con JOINs a tablas adicionales |
| Columnas | 4 (Cod_DW_Cta, Id_Buro_Cliente, Lote, Lote_Actualizacion) | 57 columnas (incluye datos de suscriptor, tipo cuenta, etc.) |
| Uso | Fase 1 — solo para verificar lotes | Fase 2 y 3 — atributos completos de cuenta |
| **Conclusión** | **Son DIFERENTES vistas en Teradata.** V_CUENTA es un subconjunto. VU_CUENTA tiene JOINs con tablas de catálogos. En la migración se trataron como la misma pero técnicamente son distintas. |

### 5.2 V_RELACION_PERSONA_UBICACION vs RELACION_PERSONA_UBICACION

| Aspecto | V_RELACION_PERSONA_UBICACION | RELACION_PERSONA_UBICACION |
|---------|------------------------------|---------------------------|
| Tipo | VIEW (prefijo V_) | Tabla base |
| Datos | Mismos datos subyacentes | Tabla física |
| Uso en Ordenamiento | Fase 1 (#15) — lectura | Fase 3 (#28) — lectura directa |
| Uso en Unificación | — | Input principal (#1) |
| **Conclusión** | **El prefijo V_ indica una VIEW sobre la tabla base.** Mismos datos subyacentes. En Redshift se puede usar una sola tabla. |

### 5.3 V_UBICACION_ATRIBUTO_HASH vs UBICACION_ATRIBUTO_HASH

| Aspecto | V_UBICACION_ATRIBUTO_HASH | UBICACION_ATRIBUTO_HASH |
|---------|--------------------------|------------------------|
| Tipo | VIEW | Tabla base |
| Datos | Mismos datos | Tabla física con hash calculado |
| Uso | Fase 3 (#41) — lectura para comparar cambios | Tabla destino donde se escriben los hashes |
| **Conclusión** | **VIEW vs TABLE — mismos datos.** En Redshift se implementa como una sola tabla. |

### 5.4 V_CUENTA_ATRIBUTO_HASH vs CUENTA_ATRIBUTO_HASH

| Aspecto | V_CUENTA_ATRIBUTO_HASH | CUENTA_ATRIBUTO_HASH |
|---------|------------------------|---------------------|
| Tipo | VIEW | Tabla base |
| Datos | Mismos datos | Tabla física con hash calculado |
| Uso | Fase 2 (#27) — lectura para comparar cambios | Tabla destino donde se escriben los hashes |
| **Conclusión** | **VIEW vs TABLE — mismos datos.** En Redshift se implementa como una sola tabla. |

### 5.5 VU_RELACION_PERSONA_UBICACION vs V_RELACION_PERSONA_UBICACION

| Aspecto | VU_ (prefijo) | V_ (prefijo) |
|---------|---------------|--------------|
| Patrón | VU_ = Vista con JOINs (Unión/enriquecida) | V_ = Vista simple sobre tabla base |
| Ejemplo | VU_CUENTA tiene 57 cols con JOINs | V_CUENTA tiene 4 cols directas |
| **Conclusión** | **VU_ y V_ son vistas DIFERENTES** aunque apuntan a la misma tabla base. VU_ incluye JOINs con catálogos. |

---

## 6. Dependencia de Ejecución entre Procesos

```
EDF (Ingesta + Estandarización)
        │
        ▼
┌─────────────────────┐
│   UNIFICACIÓN       │  ← Ejecuta primero (R1 → R2 → R3)
│   (11 tablas input) │
└─────────┬───────────┘
          │ Produce: UNIFICACION_DIRECCION
          ▼
┌─────────────────────┐
│   ORDENAMIENTO      │  ← Ejecuta después (lee V_UNIFICACION_DIRECCION)
│   (37 tablas input) │
└─────────────────────┘
```

**Ordenamiento depende de Unificación:** La tabla `V_UNIFICACION_DIRECCION` (Fase 1, #20) es el output del proceso de Unificación. Ordenamiento la lee para saber qué direcciones fueron unificadas y cuáles son las "ganadoras".

---

## 7. Clasificación por Origen de Datos

### Tablas que DEBEN venir de EDF (datos transaccionales)

| Categoría | Tablas | Proceso |
|-----------|--------|---------|
| Cuentas | V_CUENTA, VU_CUENTA, V_COMPORTAMIENTO_CUENTA, V_COMPORTAMIENTO_CUENTA_ACTIVO, V_COMPORTAMIENTO_CUENTA_PASIVO, vu_comportamiento_cta_Activo, vu_comportamiento_cta_pasivo | Ordenamiento |
| Personas | V_buro_persona, VU_Persona, CIIU_PERSONA | Ambos |
| Ubicaciones | RELACION_PERSONA_UBICACION, UBICACION_ESTANDARIZADA, DIRECCION_FISICA, V_UBICACION_ORIGINAL, relacion_ubicac_estandar_Geo, V_reporte_ubicacion_original | Ambos |
| Reportes | REPORTE_RELACION_PERSONA_UBICA, MAT_REPORTE_REL_PERS_UBI, VU_Reporte_Relacion_Pers_Ubi | Ambos |
| Bloqueos | V_BLOQUEO, bloqueo | Ambos |
| Hashes | V_CUENTA_ATRIBUTO_HASH, V_UBICACION_ATRIBUTO_HASH | Ordenamiento |

### Tablas de catálogos (carga vía Colibrí → Redshift)

| Tabla | Proceso |
|-------|---------|
| V_Razon_Bloqueo | Ordenamiento |
| V_FUENTE_DATO | Ordenamiento |
| V_COD_ENTREGA_DATO | Ordenamiento |
| v_gestion_registro | Ordenamiento |
| v_Fuente | Ordenamiento |
| V_Geografia | Ordenamiento |
| V_Tipo_Ubicacion_Direccion / TIPO_UBICACION_DIR | Ambos |
| V_Tipo_persona | Ordenamiento |
| v_tipo_cuenta | Ordenamiento |
| NOMENCLATURA | Unificación |
| V_Tipo_Identificacion | Unificación |

### Tablas de control/metadatos (internas de Redshift)

| Tabla | Proceso |
|-------|---------|
| MetadataCargaLog | Ordenamiento |
| LOG_TD | Ordenamiento |
| CONTROL_ORDENAMIENTO | Ordenamiento |
| METADATA_ORDENAMIENTO | Ordenamiento |
| MAX_ID (REC_MTDAT) | Unificación |
| UNIFICACION_DIRECCION | Unificación (output/input) |
| DICCIONARIO_COMPLEMENTOS | Unificación (stage intermedio) |
| V_Log_Ubicacion_Estandariza | Ordenamiento |

---

*Documento generado: 2025-01-27 | Fuentes: Código Teradata original (Ordenamiento.sql, Unificacion.sql, Caracteristicas.txt, PRO_ORD_* stored procedures) + mapeo_campos_xpm.md*
