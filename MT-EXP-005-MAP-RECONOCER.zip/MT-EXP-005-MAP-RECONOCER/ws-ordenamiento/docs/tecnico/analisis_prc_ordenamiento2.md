# Análisis de Stored Procedures de Ordenamiento (Malla Control-M)

> Análisis de los 17 SPs en `ws-ordenamiento/src/teradata/sps_individuales/`.
> Objetivo: documentar qué hace cada SP, inputs, outputs, tablas temporales, dependencias y complejidad de migración a Redshift.

---

## Resumen Ejecutivo

Los SPs del proceso de Ordenamiento 242 se ejecutan en secuencia/paralelo desde el script `ORDENAMIENTO_242_131.BTQ`. El flujo general es:

1. **Materialización** — Identificar personas afectadas por cambios recientes (lotes nuevos)
2. **Unificación BTT+REC** — Consolidar personas de ambos modelos en una sola tabla
3. **Cálculo de Atributos de Cuenta** — Enriquecer cuentas con comportamiento activo/pasivo y clasificar portafolio
4. **Cálculo de Ubicaciones** — Calcular fechas de reporte y construir vector de insumo para direcciones
5. **Concatenación y Hash** — Generar hashes MD5 para detectar cambios en atributos y direcciones
6. **Persistencia Final** — Insertar solo registros nuevos (sin hash previo) en tablas definitivas

---

## Orden de Ejecución (Malla Control-M)

| # | SP | Modo | Fase |
|---|-----|------|------|
| 1 | PRO_ORD_MATERIALIZA_BTT | Paralelo | Materialización |
| 2 | PRO_ORD_MATERIALIZA_REC | Paralelo | Materialización |
| 3 | PRO_ORD_UNIF_BTT_REC | Secuencial | Unificación |
| 4 | PRO_ORD_CTA_ATRIBUTOS | Paralelo | Cálculo Atributos |
| 5 | PRO_ORD_UBIC_DIRECCIONES | Paralelo | Cálculo Ubicaciones |
| 6 | PRO_ORD_CTA_TOTALES_PERSONAS | Secuencial | Cálculo Atributos |
| 7 | PRO_ORD_CTA_TOTALES_PERSONAS_1 | Paralelo | Cálculo Atributos |
| 8 | PRO_ORD_CALC_UBICACIONES | Paralelo | Cálculo Ubicaciones |
| 9 | PRO_ORD_CALC_UBICACIONES_1 | Paralelo | Cálculo Ubicaciones |
| 10 | PRO_ORD_UNIF_BTT_REC_2 | Secuencial | Limpieza |
| 11 | PRO_ORD_CTA_TOTALES_PERSONAS_2 | Paralelo | Cálculo Atributos |
| 12 | PRO_ORD_CALC_UBICACIONES_2 | Paralelo | Cálculo Ubicaciones |
| 13 | PRO_ORD_CONCAT_ATRIBUTOS | Secuencial | Hash Atributos |
| 14 | PRO_ORD_CONCAT_DIRECCIONES | Secuencial | Hash Direcciones |
| 15 | PRO_ORD_FINAL_CTA_ATRIBUTOS | Secuencial | Persistencia |
| 16 | PRO_ORD_FINAL_UBIC_DIRECCIONES | Secuencial | Persistencia |
| 17 | PRO_ORD_FINAL_UBIC_DIRECCIONES1 | Secuencial | Persistencia |

---

## Análisis Detallado por SP

---

### 1. PRO_ORD_MATERIALIZA_BTT

| Aspecto | Detalle |
|---------|---------|
| **Qué hace** | Identifica personas afectadas por cambios en tablas del modelo BTT (Bureau). Consulta el log de metadata (`MetadataCargaLog`) para encontrar lotes con inserts/updates desde la última ejecución de ordenamiento, y extrae los `Cod_Pin_Persona` + `Id_Buro_Persona` de las tablas modificadas. |
| **Inputs** | `bdm_mtdat.MetadataCargaLog`, `Control_Ordenamiento` (fecha último ordenamiento), `METADATA_ORDENAMIENTO` (catálogo de tablas), Vistas BTT: `V_CUENTA`, `V_BURO_PERSONA`, `V_COMPORTAMIENTO_CUENTA`, `V_COMPORTAMIENTO_CUENTA_ACTIVO`, `V_COMPORTAMIENTO_CUENTA_PASIVO`, `VU_CUENTA` |
| **Outputs (tablas temporales)** | `Estructuras_MTDAT_BDM`, `CALCULA_LOTE_BTT`, `PASO_V_CUENTA`, `PASO_V_BURO_PERSONA`, `TMP_PASO_COMCTA_242`, `TMP_PASO_COMCTA_1_242`, `PASO_V_COMPORTAMIENTO_CUENTA`, `PASO_V_COMPORT_CTA_ACTIVO`, `PASO_V_COMPORT_CTA_PASIVO` |
| **Dependencias** | Ninguna (se ejecuta en paralelo con MATERIALIZA_REC) |
| **Complejidad migración** | **MEDIA** — SQL dinámico con concatenación de nombres de BD. Lógica condicional para query dinámico (`P_VARQUERY1`). En Redshift se simplifica eliminando el SQL dinámico y usando esquemas fijos. |

---

### 2. PRO_ORD_MATERIALIZA_REC

| Aspecto | Detalle |
|---------|---------|
| **Qué hace** | Identifica personas afectadas por cambios en tablas del modelo Reconocer. Consulta `log_td` para encontrar lotes con cargas exitosas desde la última ejecución, y extrae personas de las tablas modificadas (ubicaciones, relaciones persona-ubicación, bloqueos, estandarización, unificación). |
| **Inputs** | `log_td`, `Control_Ordenamiento`, `METADATA_ORDENAMIENTO`, Vistas REC: `V_reporte_ubicacion_original`, `VU_RELACION_PERSONA_UBICACION`, `VU_Reporte_Relacion_Pers_Ubi`, `V_BLOQUEO`, `V_RELACION_PERSONA_UBICACION`, `v_RELACION_UBICAC_ESTANDAR_GEO`, `V_UBICACION_ORIGINAL`, `V_UBICACION_ESTANDARIZADA`, `V_Log_Ubicacion_Estandariza`, `V_UNIFICACION_DIRECCION` |
| **Outputs (tablas temporales)** | `CALCULA_LOTE_REC`, `PASO_REPORTE_UBIC_ORIGINAL`, `PASO_RPU`, `TMP_PASO_RRPU_242`, `PASO_RRPU`, `PASO_V_BLOQUEO`, `TMP_RELAUBICESTANGEO_242`, `PASO_V_RELA_UBIC_ESTANDAR_GEO`, `TMP_Lote_RELPERUBIC_242`, `PASO_V_UBICACION_ORIGINAL`, `PASO_V_UBICACION_ESTANDARIZADA`, `PASO_V_LOG_UBIC_ESTANDARIZADA`, `PASO_V_UNIFICACION_DIRECCION` |
| **Dependencias** | Ninguna (se ejecuta en paralelo con MATERIALIZA_BTT) |
| **Complejidad migración** | **MEDIA-ALTA** — Mismo patrón que BTT pero con más tablas (10 tablas de paso). SQL dinámico. Muchos JOINs con lotes. |

---

### 3. PRO_ORD_UNIF_BTT_REC

| Aspecto | Detalle |
|---------|---------|
| **Qué hace** | Unifica (UNION ALL) todas las tablas de paso generadas por MATERIALIZA_BTT y MATERIALIZA_REC en una sola tabla SET (sin duplicados) `UNIFICA_BTT_RECONOCER`. Esta tabla contiene todas las personas que deben ser re-ordenadas. |
| **Inputs** | Todas las tablas PASO_* creadas por los 2 SPs anteriores (14 tablas en total) |
| **Outputs** | `UNIFICA_BTT_RECONOCER` (SET TABLE — elimina duplicados automáticamente) |
| **Dependencias** | Requiere que MATERIALIZA_BTT y MATERIALIZA_REC hayan terminado |
| **Complejidad migración** | **BAJA** — Es un UNION ALL simple de 14 tablas. En Redshift se traduce directamente. La tabla SET se reemplaza con SELECT DISTINCT o GROUP BY. |

---

### 4. PRO_ORD_UNIF_BTT_REC_2

| Aspecto | Detalle |
|---------|---------|
| **Qué hace** | Limpieza (DROP) de todas las tablas temporales PASO_* creadas por MATERIALIZA_BTT y MATERIALIZA_REC. También valida si hubo errores en pasos anteriores consultando `log_td_detalle`. |
| **Inputs** | `rec_mtdat.log_td_detalle` (para validación de errores) |
| **Outputs** | Ninguna tabla nueva. Borra ~15 tablas temporales. Retorna error si detecta fallos previos. |
| **Dependencias** | Se ejecuta después de UNIF_BTT_REC, CTA_ATRIBUTOS y UBIC_DIRECCIONES |
| **Complejidad migración** | **BAJA** — Solo DROPs y validación. En Redshift se puede reemplazar con DROP TABLE IF EXISTS o simplemente no crear tablas intermedias persistentes. |

---

### 5. PRO_ORD_CTA_ATRIBUTOS

| Aspecto | Detalle |
|---------|---------|
| **Qué hace** | Extrae todas las cuentas de las personas a ordenar (desde `VU_CUENTA`) y las enriquece con datos de razón de bloqueo, fuente de dato y código de entrega. Genera la tabla base `CTA_TOTALES_PERSONAS_TMP1` con ~55 columnas de atributos de cuenta. |
| **Inputs** | `UNIFICA_BTT_RECONOCER`, `VU_CUENTA` (BTT), `V_Razon_Bloqueo`, `V_FUENTE_DATO`, `V_COD_ENTREGA_DATO` |
| **Outputs** | `CTA_TOTALES_PERSONAS_TMP1_ANT` (intermedia, se borra), `CTA_TOTALES_PERSONAS_TMP1` (resultado final) |
| **Dependencias** | Requiere `UNIFICA_BTT_RECONOCER` (de UNIF_BTT_REC) |
| **Complejidad migración** | **MEDIA** — Query grande (~55 columnas) con LEFT JOINs. Traducción directa a Redshift. La complejidad está en el volumen de columnas y la necesidad de mapear las vistas BTT. |

---

### 6. PRO_ORD_CTA_TOTALES_PERSONAS

| Aspecto | Detalle |
|---------|---------|
| **Qué hace** | Calcula ventana temporal de 12 meses (`ADD_MONTHS(fecha_nov, -12)`) para cada cuenta. Genera tabla `TMP_CNTA_FECHAS` con rango de fechas para buscar comportamiento histórico. |
| **Inputs** | `CTA_TOTALES_PERSONAS_TMP1` |
| **Outputs** | `TMP_CNTA_FECHAS` |
| **Dependencias** | Requiere `CTA_TOTALES_PERSONAS_TMP1` (de CTA_ATRIBUTOS) |
| **Complejidad migración** | **BAJA** — Query simple. `ADD_MONTHS` existe en Redshift como `DATEADD(month, -12, fecha)`. |

---

### 7. PRO_ORD_CTA_TOTALES_PERSONAS_1

| Aspecto | Detalle |
|---------|---------|
| **Qué hace** | Extrae comportamiento de cuenta ACTIVO dentro de la ventana de 12 meses. Cruza `TMP_CNTA_FECHAS` con `vu_comportamiento_cta_Activo` usando BETWEEN en fechas. Genera tabla precalculada `STG_COMPORTAMIENTO_CTA_ACTIVO`. |
| **Inputs** | `TMP_CNTA_FECHAS`, `vu_comportamiento_cta_Activo` (BTT), `CTA_TOTALES_PERSONAS_TMP1` |
| **Outputs** | `TMP_COMPORTAMIENTO_ACTIVO` (intermedia), `STG_COMPORTAMIENTO_CTA_ACTIVO` |
| **Dependencias** | Requiere `TMP_CNTA_FECHAS` (de CTA_TOTALES_PERSONAS) |
| **Complejidad migración** | **BAJA** — JOINs con BETWEEN en fechas. Traducción directa. |

---

### 8. PRO_ORD_CTA_TOTALES_PERSONAS_2

| Aspecto | Detalle |
|---------|---------|
| **Qué hace** | (1) Extrae comportamiento PASIVO en ventana de 12 meses. (2) Cruza TMP1 con comportamiento activo y pasivo para generar `CTA_TOTALES_PERSONAS_TMP2`. (3) Clasifica cada cuenta en **Portafolio** (CO, RO, VE, HP, IN, OT, CC, AH, CT) y **Portafolio_Nuevo** y **Sector** usando lógica CASE WHEN compleja basada en tipo de cuenta, tipo de obligación, cuotas pactadas, garantía, y código de suscriptor. |
| **Inputs** | `TMP_CNTA_FECHAS`, `vu_comportamiento_cta_pasivo`, `CTA_TOTALES_PERSONAS_TMP1`, `STG_COMPORTAMIENTO_CTA_ACTIVO` |
| **Outputs** | `TMP_COMPORTAMIENTO_PASIVO`, `CTA_TOTALES_PERSONAS_TMP2` (intermedia), `CTA_TOTALES_PERSONAS_TMP3` (con Portafolio, Portafolio_Nuevo, Sector) |
| **Dependencias** | Requiere `TMP_CNTA_FECHAS`, `CTA_TOTALES_PERSONAS_TMP1`, `STG_COMPORTAMIENTO_CTA_ACTIVO` |
| **Complejidad migración** | **ALTA** — La lógica de clasificación de Portafolio es un CASE WHEN anidado de ~80 líneas con múltiples condiciones cruzadas (tipo cuenta, tipo obligación, cuotas, garantía, código suscriptor). Requiere validación exhaustiva con datos reales. El Portafolio_Nuevo usa listas hardcodeadas de códigos de suscriptor (~50 valores). |

---

### 9. PRO_ORD_UBIC_DIRECCIONES

| Aspecto | Detalle |
|---------|---------|
| **Qué hace** | Prepara la tabla materializada de reportes de relación persona-ubicación (`TMP_ORD_CAL_MAT`). Filtra desde `MAT_REPORTE_REL_PERS_UBI` solo las personas en `UNIFICA_BTT_RECONOCER`, agrupando por persona-ubicación y calculando MAX/MIN de `Cod_DW_Reporte_Persona_Ubic` y `Fecha_Reporte` según `Id_Flag_Desde`. |
| **Inputs** | `UNIFICA_BTT_RECONOCER`, `relacion_persona_ubicacion` (datos), `MAT_REPORTE_REL_PERS_UBI` (datos) |
| **Outputs** | `TMP_RelPerUbic_242` (intermedia, se borra), `TMP_ORD_CAL_MAT` |
| **Dependencias** | Requiere `UNIFICA_BTT_RECONOCER` (de UNIF_BTT_REC) |
| **Complejidad migración** | **MEDIA** — GROUP BY con CASE WHEN para MAX/MIN condicional. Traducción directa pero requiere entender la semántica de `Id_Flag_Desde` (0=más reciente, 1=más antiguo). |

---

### 10. PRO_ORD_CALC_UBICACIONES

| Aspecto | Detalle |
|---------|---------|
| **Qué hace** | Calcula fechas de reporte ajustadas para ubicaciones CON cuenta válida en `VU_CUENTA`. Aplica reglas de negocio: (1) Si vigente y principal/pasivo/codeudor → usa Fecha_Apertura si es nuevo, sino Fecha_Reporte. (2) Si no vigente → MIN(Fecha_Nov, Fecha_Reporte). Luego agrega `Cod_Entrega_Dato_Fte` y aplica QUALIFY ROW_NUMBER para limitar a 3 registros por combinación. |
| **Inputs** | `TMP_ORD_CAL_MAT`, `VU_CUENTA`, `RELACION_PERSONA_UBICACION` (datos) |
| **Outputs** | `TMP_ORD_CAL1`, `TMP_ORD_CAL11` (para flag_desde=1), `TMP_AGR_CNTAS_242`, `TMP_ORD_CAL2`, `TMP_ORD_CAL3` |
| **Dependencias** | Requiere `TMP_ORD_CAL_MAT` (de UBIC_DIRECCIONES) |
| **Complejidad migración** | **ALTA** — Lógica de negocio compleja con CASE WHEN anidados para fechas. QUALIFY con ROW_NUMBER (soportado en Redshift). Self-joins sobre TMP_ORD_CAL_MAT para calcular Fecha_Act de registros históricos. |

---

### 11. PRO_ORD_CALC_UBICACIONES_1

| Aspecto | Detalle |
|---------|---------|
| **Qué hace** | Mismo cálculo que CALC_UBICACIONES pero para ubicaciones SIN cuenta válida en `VU_CUENTA` (`COD_DW_CTA NOT IN VU_CUENTA`). Aplica las mismas reglas de fecha. Genera `TMP_ORD_CAL6` y `TMP_ORD_CAL61` (para registros históricos sin cuenta). |
| **Inputs** | `TMP_ORD_CAL_MAT`, `VU_CUENTA` (para exclusión), `RELACION_PERSONA_UBICACION` (datos) |
| **Outputs** | `TMP_ORD_CAL6`, `TMP_ORD_CAL61` |
| **Dependencias** | Requiere `TMP_ORD_CAL_MAT` (de UBIC_DIRECCIONES) |
| **Complejidad migración** | **ALTA** — Misma lógica que CALC_UBICACIONES. Self-joins complejos con GROUP BY de 15 columnas. |

---

### 12. PRO_ORD_CALC_UBICACIONES_2

| Aspecto | Detalle |
|---------|---------|
| **Qué hace** | (1) Consolida TMP_ORD_CAL3 + TMP_ORD_CAL6 en `vmo_reporte_relacion_pers_ubi`. (2) Construye `VECTOR_UBI_INSUMO_BASE` cruzando personas con relación_persona_ubicación (excluyendo bloqueados y unificados). (3) Enriquece con datos de ubicación estandarizada (texto, fuente, geografía). (4) Agrega tipo de persona y tipo de cuenta. Genera `DATOS_UBIC_ESTANDARIZADAS` → `DATOS_TIPO_PERSONA` → `DATOS_TIPO_CUENTA`. |
| **Inputs** | `TMP_ORD_CAL3`, `TMP_ORD_CAL6`, `UNIFICA_BTT_RECONOCER`, `relacion_persona_ubicacion`, `bloqueo`, `V_Ubicacion_estandarizada`, `v_gestion_registro`, `v_Fuente`, `V_Geografia`, `V_Tipo_Ubicacion_Direccion`, `VU_Persona`, `V_Tipo_persona`, `vu_cuenta`, `v_tipo_cuenta` |
| **Outputs** | `vmo_reporte_relacion_pers_ubi`, `VECTOR_UBI_INSUMO_BASE_0`, `VECTOR_UBI_INSUMO_BASE`, `TMP_UBIC_ESTANDARIZA_242`, `TMP_UBIC_ESTANDARIZA_242_1`, `DATOS_UBIC_ESTANDARIZADAS`, `TMP_PERSONAS_242`, `DATOS_TIPO_PERSONA`, `TMP_Desc_Cta_242`, `DATOS_TIPO_CUENTA` |
| **Dependencias** | Requiere `TMP_ORD_CAL3` (de CALC_UBICACIONES), `TMP_ORD_CAL6` (de CALC_UBICACIONES_1), `UNIFICA_BTT_RECONOCER` |
| **Complejidad migración** | **MUY ALTA** — SP más largo (~1300 líneas). Múltiples etapas encadenadas. Muchos JOINs con tablas de referencia. Genera la tabla final de direcciones enriquecida. Es el SP más crítico del flujo de ubicaciones. |

---

### 13. PRO_ORD_CONCAT_ATRIBUTOS

| Aspecto | Detalle |
|---------|---------|
| **Qué hace** | Concatena ~20 atributos numéricos de cuenta en un solo string y calcula hash MD5 usando la UDF `rec_vista.hash_md5()`. Genera tabla `CONCATENA_ATRIBUTOS` con columnas `Concatena` y `cod_hash`. |
| **Inputs** | `CTA_TOTALES_PERSONAS_TMP2` (nota: debería ser TMP3 según flujo) |
| **Outputs** | `CONCATENA_ATRIBUTOS` |
| **Dependencias** | Requiere `CTA_TOTALES_PERSONAS_TMP2` (de CTA_TOTALES_PERSONAS_2) |
| **Complejidad migración** | **MEDIA** — La concatenación es directa. La UDF `hash_md5` debe reemplazarse por `MD5()` nativo de Redshift. Validar que el resultado sea idéntico. |

---

### 14. PRO_ORD_CONCAT_DIRECCIONES

| Aspecto | Detalle |
|---------|---------|
| **Qué hace** | Concatena atributos de dirección (texto ubicación, tipo, gestión, DANE, tipo persona, tipo cuenta, dirección física, complemento, barrio, lat/long) y calcula hash MD5. Genera `hash_Carac_direc`. |
| **Inputs** | `DIRECCIONES_TEMP` (generada por CALC_UBICACIONES_2 como DATOS_TIPO_CUENTA — ver nota) |
| **Outputs** | `hash_Carac_direc` |
| **Dependencias** | Requiere `DIRECCIONES_TEMP` (tabla final del flujo de ubicaciones) |
| **Complejidad migración** | **MEDIA** — Mismo patrón que CONCAT_ATRIBUTOS. UDF `hash_md5` → `MD5()` en Redshift. |

---

### 15. PRO_ORD_FINAL_CTA_ATRIBUTOS

| Aspecto | Detalle |
|---------|---------|
| **Qué hace** | Detecta registros NUEVOS comparando hash actual vs `V_CUENTA_ATRIBUTO_HASH`. Si el hash no existe, inserta en la tabla definitiva `CUENTA_ATRIBUTO_HASH`. **NOTA: Actualmente deshabilitado** — tiene `IF V_PASO > 0 THEN LEAVE L1` al inicio, lo que hace que nunca ejecute la lógica. |
| **Inputs** | `CONCATENA_ATRIBUTOS`, `V_CUENTA_ATRIBUTO_HASH` |
| **Outputs** | `NUEVOS_DATOS_CARACT_ATRIBUTO` (stage), INSERT en `CUENTA_ATRIBUTO_HASH` (definitiva) |
| **Dependencias** | Requiere `CONCATENA_ATRIBUTOS` (de CONCAT_ATRIBUTOS) |
| **Complejidad migración** | **BAJA** — Lógica simple de LEFT JOIN + WHERE IS NULL para detectar nuevos. Actualmente deshabilitado. |

---

### 16. PRO_ORD_FINAL_UBIC_DIRECCIONES

| Aspecto | Detalle |
|---------|---------|
| **Qué hace** | Detecta direcciones NUEVAS comparando hash actual vs `V_UBICACION_ATRIBUTO_HASH`. Si el hash no existe, inserta en `UBICACION_ATRIBUTO_HASH`. **NOTA: Actualmente deshabilitado** — mismo patrón que FINAL_CTA_ATRIBUTOS con `IF V_PASO > 0 THEN LEAVE L1`. |
| **Inputs** | `DIRECCIONES_TEMP`, `V_UBICACION_ATRIBUTO_HASH` |
| **Outputs** | `NUEVOS_DATOS_DIRECCIONES` (stage), INSERT en `UBICACION_ATRIBUTO_HASH` (definitiva) |
| **Dependencias** | Requiere `DIRECCIONES_TEMP` (del flujo de ubicaciones) |
| **Complejidad migración** | **BAJA** — Deshabilitado. Lógica simple cuando se active. |

---

### 17. PRO_ORD_FINAL_UBIC_DIRECCIONES1

| Aspecto | Detalle |
|---------|---------|
| **Qué hace** | Versión ACTIVA de FINAL_UBIC_DIRECCIONES (sin el `LEAVE L1`). Detecta direcciones nuevas por hash, inserta en `UBICACION_ATRIBUTO_HASH`, y además hace UPDATE de hashes que cambiaron (a diferencia de la versión deshabilitada). |
| **Inputs** | `DIRECCIONES_TEMP`, `V_UBICACION_ATRIBUTO_HASH`, `hash_Carac_direc` |
| **Outputs** | `NUEVOS_DATOS_DIRECCIONES` (stage), INSERT + UPDATE en `UBICACION_ATRIBUTO_HASH` (definitiva) |
| **Dependencias** | Requiere `DIRECCIONES_TEMP` y `hash_Carac_direc` (de CONCAT_DIRECCIONES) |
| **Complejidad migración** | **MEDIA** — INSERT + UPDATE. El UPDATE con JOIN cruzado requiere sintaxis diferente en Redshift (`UPDATE ... FROM ... WHERE`). La UDF `hash_md5` se reemplaza por `MD5()`. |

---

## Grafo de Dependencias

```
PRO_ORD_MATERIALIZA_BTT ──┐
                          ├──► PRO_ORD_UNIF_BTT_REC ──┬──► PRO_ORD_CTA_ATRIBUTOS ──► PRO_ORD_CTA_TOTALES_PERSONAS
PRO_ORD_MATERIALIZA_REC ──┘                           │                                        │
                                                      │                              PRO_ORD_CTA_TOTALES_PERSONAS_1
                                                      │                                        │
                                                      │                              PRO_ORD_CTA_TOTALES_PERSONAS_2
                                                      │                                        │
                                                      │                              PRO_ORD_CONCAT_ATRIBUTOS
                                                      │                                        │
                                                      │                              PRO_ORD_FINAL_CTA_ATRIBUTOS
                                                      │
                                                      ├──► PRO_ORD_UBIC_DIRECCIONES ──► PRO_ORD_CALC_UBICACIONES
                                                      │                                PRO_ORD_CALC_UBICACIONES_1
                                                      │                                        │
                                                      │                              PRO_ORD_CALC_UBICACIONES_2
                                                      │                                        │
                                                      │                              PRO_ORD_CONCAT_DIRECCIONES
                                                      │                                        │
                                                      │                              PRO_ORD_FINAL_UBIC_DIRECCIONES(1)
                                                      │
                                                      └──► PRO_ORD_UNIF_BTT_REC_2 (limpieza + validación)
```

---

## Tablas Definitivas (Destino Final)

| Tabla | SP que escribe | Tipo operación |
|-------|---------------|----------------|
| `CUENTA_ATRIBUTO_HASH` | PRO_ORD_FINAL_CTA_ATRIBUTOS | INSERT (deshabilitado) |
| `UBICACION_ATRIBUTO_HASH` | PRO_ORD_FINAL_UBIC_DIRECCIONES1 | INSERT + UPDATE |

---

## Resumen de Complejidad para Migración a Redshift

| Complejidad | SPs | Notas |
|-------------|-----|-------|
| **MUY ALTA** | CALC_UBICACIONES_2 | 1300+ líneas, múltiples etapas, muchos JOINs |
| **ALTA** | CTA_TOTALES_PERSONAS_2, CALC_UBICACIONES, CALC_UBICACIONES_1 | Lógica CASE WHEN compleja, self-joins, clasificación de portafolio |
| **MEDIA-ALTA** | MATERIALIZA_REC | 10 tablas de paso, SQL dinámico |
| **MEDIA** | MATERIALIZA_BTT, CTA_ATRIBUTOS, UBIC_DIRECCIONES, CONCAT_ATRIBUTOS, CONCAT_DIRECCIONES, FINAL_UBIC_DIRECCIONES1 | SQL dinámico o UDFs a reemplazar |
| **BAJA** | UNIF_BTT_REC, UNIF_BTT_REC_2, CTA_TOTALES_PERSONAS, CTA_TOTALES_PERSONAS_1, FINAL_CTA_ATRIBUTOS, FINAL_UBIC_DIRECCIONES | UNION simples, DROPs, queries directos, o deshabilitados |

---

## Consideraciones Clave para Migración

### 1. SQL Dinámico
Todos los SPs usan `SP_EXECSTRING_DES` para ejecutar SQL construido como strings. En Redshift no hay equivalente directo. Opciones:
- Convertir a SQL estático (preferido — los nombres de BD/esquema son fijos en AWS)
- Usar procedimientos almacenados de Redshift con `EXECUTE`

### 2. UDF hash_md5
La función `rec_vista.hash_md5()` se usa en CONCAT_ATRIBUTOS y CONCAT_DIRECCIONES. Redshift tiene `MD5()` nativo. Validar que produzca el mismo resultado.

### 3. SET TABLE (deduplicación)
`UNIFICA_BTT_RECONOCER` usa `CREATE SET TABLE` (Teradata elimina duplicados automáticamente). En Redshift usar `SELECT DISTINCT` o `GROUP BY`.

### 4. QUALIFY ROW_NUMBER
Usado en CALC_UBICACIONES. Redshift soporta window functions pero no `QUALIFY`. Usar subquery con `WHERE rn <= 3`.

### 5. Tablas Volátiles vs Temporales
Teradata usa tablas persistentes en stage que se borran manualmente. En Redshift se pueden usar:
- Tablas temporales (`CREATE TEMP TABLE`) — se borran al cerrar sesión
- CTEs para queries intermedios simples
- Tablas regulares con `DROP TABLE IF EXISTS` para el patrón actual

### 6. COLLECT STATISTICS
No existe en Redshift. Se reemplaza con `ANALYZE` (automático en la mayoría de casos).

### 7. SPs Deshabilitados
`PRO_ORD_FINAL_CTA_ATRIBUTOS` y `PRO_ORD_FINAL_UBIC_DIRECCIONES` están deshabilitados con `IF V_PASO > 0 THEN LEAVE L1`. Solo `PRO_ORD_FINAL_UBIC_DIRECCIONES1` está activo. Confirmar con Experian si los deshabilitados se deben migrar.

### 8. Parámetros de BD
Todos los SPs reciben 10+ parámetros de nombres de BD/esquema (`P_BDDATOS`, `P_BDVISTA`, `P_BDSTAGE`, etc.). En Redshift con esquemas fijos, estos parámetros desaparecen.
