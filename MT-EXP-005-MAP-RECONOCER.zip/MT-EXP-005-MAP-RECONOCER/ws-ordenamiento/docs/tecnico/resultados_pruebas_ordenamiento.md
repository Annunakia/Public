# Resultados de Pruebas — Ordenamiento (Scoring de Contactabilidad)

> Fecha: 2026-04-22 | Ambiente: `experian-sandbox-dev-redshift-workgroup` | Cuenta: `193272798722`

---

## Resumen

| Script | Canal | Sentencias Teradata | Líneas Redshift | Características | Estado |
|--------|-------|--------------------:|----------------:|----------------:|--------|
| 02_scoring_dir.sql | DIR | 70 | ~140 | 12 | **Validado** |
| 03_scoring_tel.sql | TEL | 82 | ~90 | 11 | **Validado** |
| 04_scoring_cel.sql | CEL | 63 | ~80 | 11 | **Validado** |
| 05_scoring_ema.sql | EMA | 38 | ~90 | 13 | **Validado** |
| 06_consolidacion.sql | — | ~50 | ~24 | — | **Validado** |
| **Total** | | **253** | **~420** | **47** | |

## Resultados del scoring (9 personas, 15 scores)

| Canal | Persona | Score | Lugar | Coherente |
|-------|---------|-------|-------|-----------|
| DIR | 20001 - CL 22 27 45 (RES) | 0.7500 | 1 | ✅ Más reportes, financiero |
| DIR | 20001 - KR 15 80 22 (LAB) | 0.7233 | 2 | ✅ Menos reportes |
| DIR | 20002 - TV 70 114 55 (RES) | 0.7050 | 1 | ✅ Única dirección |
| DIR | 20003 - DG 50 30 10 (CRR) | 0.8000 | 1 | ✅ Más reportes recientes |
| DIR | 20003 - AC 40 12 08 (LAB) | 0.7533 | 2 | ✅ |
| DIR | 20003 - KR 7 45 12 (RES) | 0.6783 | 3 | ✅ Solo 1 reporte |
| TEL | 20004 - CL 10 20 30 | 0.6900 | 1 | ✅ Más reportes válidos |
| TEL | 20004 - KR 20 55 18 | 0.4250 | 2 | ✅ Reporte NO VALIDA |
| TEL | 20005 - TV 30 15 40 | 0.6875 | 1 | ✅ |
| CEL | 20006 - 3209876543 | 0.6675 | 1 | ✅ |
| CEL | 20006 - 3101234567 | 0.5825 | 2 | ✅ |
| CEL | 20007 - 3001112233 | 0.6875 | 1 | ✅ |
| EMA | 20008 - user1@gmail.com | 0.6042 | 1 | ✅ Dominio conocido, más reportes |
| EMA | 20008 - work@empresa.co | 0.3967 | 2 | ✅ Dominio desconocido |
| EMA | 20009 - otro@hotmail.com | 0.5092 | 1 | ✅ |

## Persistencia

`orden_prioridad` actualizado correctamente en `relacion_persona_ubicacion` para los 15 registros con score.

## Bugs encontrados y corregidos

### Bug 1: Window functions en GROUP BY (02_scoring_dir)
**Problema**: `SUM() OVER()` y `COUNT(DISTINCT) OVER()` dentro de un GROUP BY no son soportados en Redshift.
**Fix**: Separar en CTE `persona_stats` con GROUP BY propio, luego JOIN.

### Bug 2: Agrupación por registro vs dirección (02_scoring_dir)
**Problema**: GROUP BY por `cod_dw_persona_ubic` generaba un score por cada registro de reporte, no por dirección.
**Fix**: GROUP BY por `id_buro_persona + direccion_fisica` (o celular, email según canal).

## Validación integral — 5,000 personas (2026-04-22)

Dataset: 5,000 personas, 95,210 registros de insumo (seed=42).

| Canal | Insumo | Scores | Personas | Min | Avg | Max | Max Lugar |
|-------|--------|--------|----------|-----|-----|-----|-----------|
| DIR | 36,446 | 9,713 | 5,000 | 0.6013 | 0.7190 | 0.8883 | 4 |
| TEL | 22,511 | 4,995 | 3,562 | 0.3525 | 0.6222 | 0.7975 | 2 |
| CEL | 22,848 | 6,576 | 3,999 | 0.4375 | 0.6298 | 0.7850 | 3 |
| EMA | 13,405 | 3,824 | 2,930 | 0.3792 | 0.5704 | 0.7500 | 2 |
| **Total** | **95,210** | **25,108** | | | | | |

0 errores. Datos cargados via S3 COPY, bucket temporal eliminado.

---

*Última actualización: 2026-04-22*
