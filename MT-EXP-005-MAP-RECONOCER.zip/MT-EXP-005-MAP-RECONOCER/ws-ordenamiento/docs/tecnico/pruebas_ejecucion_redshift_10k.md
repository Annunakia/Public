# Pruebas de Ejecución — Ordenamiento 242 (10K personas)

> Fecha: 2026-05-13 | Ambiente: experian-sandbox-trunk-ddm-xpm-workgroup | Dataset: 10K (seed=42)

---

## Resumen

| Fase | Scripts | OK | FAILED | Notas |
|------|---------|----|---------|----|
| Shared | 2 | 2 | 0 | Schemas + tablas creados correctamente |
| Carga dataset | 121 batches | 121 | 0 | 10,500 personas, 40,943 cuentas, 31,759 ubicaciones |
| Fase 1 | 4 | 3 | 1* | *04_limpieza requiere `run_sql_batch.sh` (dollar-quoting) |
| Fase 2 | 5 | 2 | 3** | **Scripts dependen de columnas no presentes en dataset sintético |
| Fase 3 | 6 | 0 | 6** | **Depende de Fase 2 |

## Hallazgos Principales

### 1. Infraestructura y Carga: OK ✅

- `shared/00_schemas_tablas_control.sql` — 5 sentencias, todas OK
- `shared/01_log_ejecucion.sql` — 1 sentencia, OK
- Dataset 10K cargado en 121 batches sin errores
- Conteos verificados: personas_raw=10,500, vu_cuenta=40,943, relacion_persona_ubicacion=31,759

### 2. Fase 1 Materialización: PARCIAL ⚠️

**Problema**: Los scripts 01_materializa_btt y 02_materializa_rec dependen de tablas del modelo completo de Teradata que no existen en el dataset sintético:
- `rec_datos.metadata_ordenamiento` (catálogo de tablas por modelo BTT/REC)
- `rec_datos.log_td` (log de carga del modelo REC)
- `rec_datos.v_buro_persona` (con columnas lote, lote_actualizacion)
- `rec_datos.v_comportamiento_cuenta` (con columnas lote)
- `rec_datos.v_comportamiento_cuenta_activo/pasivo`
- `rec_datos.vu_relacion_persona_ubicacion`
- `rec_datos.vu_reporte_relacion_pers_ubi`
- `rec_datos.v_ubicacion_estandarizada` (con columna lote)
- etc.

**Workaround aplicado**: Se creó `unifica_btt_reconocer` directamente desde `personas_raw` con SELECT DISTINCT, simulando el resultado esperado de la materialización.

**Resultado**: 10,000 registros únicos, 0 duplicados. ✅

### 3. Fase 2 Atributos de Cuenta: BLOQUEADA ❌

**Problema**: El script `01_cta_atributos.sql` espera que `rec_datos.vu_cuenta` tenga ~55 columnas del modelo completo de Teradata:
- `id_buro_cliente`, `cod_dw_tipo_cta`, `cod_tipo_cta_fte`, `num_cta`, `id_buro_suscriptor`, `nit_suscriptor`, `cod_tipo_ident_fte`, `num_ident`, `cod_dw_doc_ident`, `num_contr`, `fecha_apertura`, `fecha_vencimiento`, `ind_moneda_legal`, `cod_dw_est_mod`, `cod_est_mod_fte`, `ind_tarjeta_amparada`, `nombre_ciudad_radicacion`, `cod_dw_razon_bloqueo`, `num_plastico`, `cod_dw_clase_tarjeta_credito`, `cod_clase_tarjeta_credito_fte`, `cod_dw_franquicia`, `cod_franquicia_fte`, `cod_marca_privada_fte`, `cod_dw_tipo_rel_con_cta`, `cod_tipo_rel_con_cta_fte`, `cod_dw_motivo_origen`, `cod_motivo_origen_fte`, `cod_dw_tipo_obligacion`, `cod_tipo_obligacion_fte`, `cod_dw_clase_cta`, `cod_clase_cta_fte`, `cod_dw_clase_garantia_buro`, `cod_clase_garantia_buro_fte`, `cod_dw_tipo_bloqueo`, `cod_tipo_bloqueo_fte`, `fecha_ultima_actualizacion`, `cod_dw_pais`, `cod_pais_geo_fte`, `cod_dw_fte_dato`, `cod_dw_evento_entrega_dato`, `nombre_cod_entrega_dato`, `desc_cod_entrega_dato`, `cod_entrega_dato_fte`, `cod_nov_buro_fte`, `desc_est_vigencia`, `fecha_ultima_actualizacion_nov`, `cod_dw_est_suscriptor`, `fecha_est`, `cod_est_suscriptor_fte`, `cod_motivo_bloqueo_fte`, `cod_dw_natu_cta`, `cod_natu_cta_fte`, `fecha_nov`, `cod_calif_comp_cta_fte`, `cod_dw_entrega_dato`

Nuestro dataset sintético solo tiene: `cod_dw_cta`, `cod_pin_persona`, `id_buro_persona`, `tipo_cuenta`, `tipo_obligacion`, `cuotas_pactadas`, `garantia`, `cod_suscriptor`, `fecha_apertura`, `fecha_novedad`, `estado_vigencia`, `portafolio`, `lote_id`

**Tablas de referencia faltantes**:
- `rec_datos.v_razon_bloqueo`
- `rec_datos.v_fuente_dato`
- `rec_datos.v_cod_entrega_dato`
- `rec_datos.vu_comportamiento_cta_activo`
- `rec_datos.vu_comportamiento_cta_pasivo`

### 4. Fase 3 Ubicaciones: BLOQUEADA ❌

Depende de tablas generadas por Fase 2 y de tablas adicionales del modelo completo:
- `rec_datos.mat_reporte_rel_pers_ubi`
- `rec_datos.v_ubicacion_estandarizada` (con columnas de estandarización)
- `rec_datos.v_gestion_registro`
- `rec_datos.v_fuente`
- `rec_datos.v_geografia`
- `rec_datos.v_tipo_ubicacion_direccion`
- `rec_datos.vu_persona`
- `rec_datos.v_tipo_persona`
- `rec_datos.v_tipo_cuenta`
- `rec_datos.direccion_fisica`
- `rec_datos.relacion_ubicac_estandar_geo`
- `rec_datos.bloqueo`

### 5. Script con Dollar-Quoting: Requiere `run_sql_batch.sh`

El script `04_limpieza_validacion.sql` usa `$$` para definir un stored procedure. El parser `run_sql_file.sh` no maneja dollar-quoting. Solución: ejecutar con `run_sql_batch.sh` que envía el archivo completo como un solo statement.

---

## Conclusión

### Lo que funciona ✅
1. **Infraestructura**: Schemas, tablas de control y log se crean correctamente en Redshift
2. **Carga de datos**: El pipeline de batches (split + load) funciona correctamente para archivos de ~9MB
3. **Sintaxis SQL**: Los scripts son sintácticamente válidos en Redshift (no hay errores de sintaxis)
4. **Deduplicación**: SELECT DISTINCT produce correctamente 10,000 registros únicos de 10,500 con duplicados
5. **Stored Procedures**: El dollar-quoting funciona cuando se ejecuta como batch completo

### Lo que falta para prueba completa ❌
1. **Dataset con modelo completo**: El generador `generate.py` necesita producir tablas con el esquema completo de Teradata (~55 columnas en vu_cuenta, tablas de referencia, tablas de comportamiento, etc.)
2. **Tablas de referencia**: Crear tablas de catálogo (v_razon_bloqueo, v_fuente_dato, v_tipo_persona, v_geografia, etc.) con datos de referencia
3. **Tablas de comportamiento**: Crear vu_comportamiento_cta_activo/pasivo con datos dentro de la ventana de 12 meses
4. **Tablas de ubicación completas**: mat_reporte_rel_pers_ubi, v_ubicacion_estandarizada con todas las columnas

### Próximos Pasos
1. Extender `generate.py` para producir el modelo de datos completo (estimado: 2-3 horas de desarrollo)
2. Re-ejecutar el pipeline con el dataset completo
3. Alternativamente: solicitar un dump parcial del ambiente de desarrollo de Experian para usar como datos de prueba

---

## Ambiente

- **Workgroup**: experian-sandbox-trunk-ddm-xpm-workgroup
- **Database**: dev
- **Region**: us-east-1
- **Profile**: sandbox
- **Cuenta**: 193272798722

---

*Última actualización: 2026-05-13*
