# Análisis de Caracteristicas.txt — Modelo de Scoring

> 260 sentencias SQL en 4 canales. Regresión logística con coeficientes Beta.

---

## Resumen

| Métrica | Valor |
|---------|-------|
| Total sentencias SQL | 260 |
| Canal TEL (teléfono fijo) | 82 sentencias, 11 características |
| Canal CEL (celular) | 63 sentencias, 11 características |
| Canal EMA (email) | 38 sentencias, 13 características |
| Canal DIR (dirección) | 70 sentencias, 5+ características |
| CREATE TABLE | 179 |
| DROP TABLE | 15 |
| COLLECT STATISTICS | 55 |

## Patrón de 3 fases por característica

```
Fase 1: Métrica bruta     → CO01TEL001 (ej: % reportes últimos 12 meses)
Fase 2: Categorización    → CO01TEL001_cat (CASE WHEN <8.33 THEN 1 ... THEN 4)
Fase 3: Peso ponderado    → CO01TEL001_Peso = (cat/max_cat) × Beta
```

## Fórmula de Score

```
Score = Σ (categoría_i / max_categoría_i) × Beta_i
Lugar = ROW_NUMBER() OVER (PARTITION BY persona ORDER BY Score DESC)
```

## Características por Canal

### TEL — Teléfono Fijo (11 características)

| Característica | max_cat | Divisor | Descripción probable |
|---------------|---------|---------|---------------------|
| CO01TEL001 | 4 | 4 | % reportes últimos 12 meses |
| CO01TEL002 | 4 | 4 | Total reportes |
| CO01TEL003 | 4 | 4 | Meses desde primer reporte |
| CO01TEL006 | 4 | 4 | Reportes últimos 6 meses |
| CO01TEL007 | 4 | 4 | Reportes últimos 6 meses (conteo) |
| CO01TEL010 | 4 | 4 | Entidades que reportan |
| CO01TEL017 | 4 | 4 | Sector financiero |
| CO01TEL019 | 3 | 3 | Tipo de cuenta |
| CO01TEL020 | 4 | 4 | Coincidencia geográfica |
| CO01TEL023 | 4 | 4 | % reportes locales |
| CO01TEL025 | 4 | 4 | Meses último reporte |

### CEL — Celular (11 características)

| Característica | max_cat | Divisor | Descripción probable |
|---------------|---------|---------|---------------------|
| CO01CEL003 | 4 | 4 | Meses desde primer reporte |
| CO01CEL006 | 4 | 4 | Reportes últimos 6 meses |
| CO01CEL007 | — | 4 | Reportes últimos 6 meses (conteo) |
| CO01CEL013 | — | 4 | Operador (prefijo) |
| CO01CEL014 | — | 4 | Tipo cuenta |
| CO01CEL015 | — | 4 | % suscriptores |
| CO01CEL017 | — | 4 | Sector financiero |
| CO01CEL018 | 4 | 4 | Volumen reportes |
| CO01CEL019 | 3 | 4 | Tipo cuenta |
| CO01CEL020 | 4 | 4 | Total reportes persona |
| CO01CEL023 | 4 | 4 | Indicador binario |

### EMA — Email (13 características)

| Característica | max_cat | Divisor | Descripción probable |
|---------------|---------|---------|---------------------|
| CO01EMA003 | 4 | 4 | Meses desde primer reporte |
| CO01EMA007 | 4 | 4 | Reportes últimos 6 meses |
| CO01EMA010 | — | 4 | Entidades que reportan |
| CO01EMA014 | — | 4 | Dominio conocido |
| CO01EMA015 | — | 4 | % suscriptores |
| CO01EMA016 | — | 4 | Sector financiero |
| CO01EMA017 | — | 4 | Tipo cuenta |
| CO01EMA018 | 1 | 3 | Indicador binario |
| CO01EMA020 | 3 | 4 | Volumen reportes |
| CO01EMA021 | 4 | 4 | Total reportes persona |
| CO01EMA023 | 3 | 4 | Indicador |
| CO01EMA024 | 1 | 4 | Indicador binario |
| CO01EMA025 | 3 | 4 | Meses último reporte |

### DIR — Dirección (5+ características)

| Característica | Divisor | Descripción probable |
|---------------|---------|---------------------|
| CO00DIR017 | 3 | Tipo uso (RES/LAB/CRR) |
| CO00DIR019 | 2 | Indicador binario |
| CO00DIR057 | 6 | Conteo direcciones |
| CO00DIR059 | 5 | Sector financiero |
| CO01DIR009 | 3 | Entidades que reportan |

## Tablas de Coeficientes Beta

| Vista | Canal | Clave |
|-------|-------|-------|
| V_Beta_Ordenamiento_Tel | TEL | Cod_Caracteristica_Fte + Valor_Beta |
| V_Beta_Ordenamiento_Cel | CEL | Cod_Caracteristica_Fte + Valor_Beta |
| V_Beta_Ordenamiento_Email | EMA | Cod_Caracteristica_Fte + Valor_Beta |
| V_Beta_Ordenamiento_Dir | DIR | Cod_Caracteristica_Fte + Valor_Beta |

## Score Final por Canal

| Canal | Características sumadas | Tabla resultado |
|-------|------------------------|-----------------|
| TEL | 11 pesos | Orden_TelF |
| CEL | 11 pesos | Orden_TM |
| EMA | 13 pesos | Orden_Email |
| DIR | 5 pesos | Orden_Direcc |

## Estrategia de Migración

En Teradata, cada característica es una sentencia SQL separada ejecutada por un cursor. En Redshift, podemos:

1. **Consolidar en CTEs** — Cada canal es un solo query con CTEs encadenados
2. **Eliminar tablas intermedias** — Las métricas, categorías y pesos se calculan inline
3. **Mantener tabla Beta** — Los coeficientes se cargan como tabla de parámetros

Estimación: ~4 scripts SQL (uno por canal), cada uno de ~100-150 líneas.

---

*Generado: 2026-04-22 | Fuente: Caracteristicas.txt (133 KB, 260 sentencias)*
