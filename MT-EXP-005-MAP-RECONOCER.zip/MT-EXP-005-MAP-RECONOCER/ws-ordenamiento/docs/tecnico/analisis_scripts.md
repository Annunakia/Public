# Análisis Técnico de Scripts – Proceso de Ordenamiento

> Análisis del código fuente Teradata para migración. Actualizado 2026-04-17.

---

## Hallazgo Principal: Arquitectura Data-Driven

El ordenamiento NO tiene lógica hardcodeada en los scripts. Usa una **tabla de configuración** (`CARACTERISTICA`) que contiene sentencias SQL como datos. Los SPs leen esas sentencias y las ejecutan dinámicamente. Esto es fundamentalmente diferente a la unificación.

---

## Flujo de Ejecución

```
BTEQ_CURSOR_131.BTQ                    ORDENAMIENTO_242_131.BTQ
(Cálculo de características)            (Ordenamiento + Score)
┌─────────────────────────┐             ┌──────────────────────────────┐
│ PRO_Cursor_Drop (S)     │             │ PRO_ORD_MATERIALIZA_BTT (P)  │
│ Limpia tablas temp      │             │ PRO_ORD_MATERIALIZA_REC (P)  │
│                         │             │ PRO_ORD_UNIF_BTT_REC (S)     │
│ En paralelo:            │             │ PRO_ORD_CTA_ATRIBUTOS (P)    │
│ ├ PRO_Cursor_caract     │             │ PRO_ORD_UBIC_DIRECCIONES (P) │
│ │ TeleFijo              │             │ PRO_ORD_CTA_TOTALES_PERS (S) │
│ ├ PRO_Cursor_caract     │             │ PRO_ORD_CTA_TOTALES_PERS_1(P)│
│ │ Movil                 │             │ PRO_ORD_CALC_UBICACIONES (P) │
│ ├ PRO_Cursor_caract     │             │ PRO_ORD_CALC_UBICACIONES_1(P)│
│ │ Email                 │             │ PRO_ORD_UNIF_BTT_REC_2 (S)   │
│ └ PRO_Cursor_caract     │             │ PRO_ORD_CTA_TOTALES_PERS_2(P)│
│   Direc                 │             │ PRO_ORD_CALC_UBICACIONES_2(P)│
└─────────────────────────┘             └──────────────────────────────┘
         │                                          │
         ▼                                          ▼
    Tablas stage:                              Tablas stage:
    Orden_TelF                                 (scores calculados)
    Orden_TM                                        │
    Orden_Email                                     ▼
    Orden_Direcc                          P0027_111 (consolida)
         │                                TablaResultCaract_TUbic
         └──────────────┬───────────────────────────┘
                        ▼
                  P0027_130 (persistencia)
                  UPDATE RELACION_PERSONA_UBICACION
                  SET Orden_Prioridad = Lugar
```

**P = Paralelo | S = Secuencial** — El shell ejecuta SPs en paralelo donde es posible.

---

## BTEQ_CURSOR_131 — Cálculo de Características por Canal

### Arquitectura

Script shell que ejecuta **5 SPs en paralelo**, uno por canal de contacto:

| SP | Canal | Filtro en tabla CARACTERISTICA |
|----|-------|-------------------------------|
| `PRO_Cursor_caracteristicaTele` | Teléfono fijo | `Cod_Caracteristica_Fte = '1.3- Calc Caracteristica_Tele'` |
| `PRO_Cursor_caracteristicaMovil` | Celular | `Cod_Caracteristica_Fte = '1.3- Calc Caracteristica_Movil'` |
| `PRO_Cursor_caracteristicaEmail` | Email | `Cod_Caracteristica_Fte = '1.3- Calc Caracteristica_Email'` |
| `PRO_Cursor_caracteristicaDirec` | Dirección física | `Cod_Caracteristica_Fte = '1.3- Calc Caracteristica_Direc'` |
| `PRO_Cursor_caract` | General (todos) | Sin filtro — ejecuta todas las características |

### Patrón de los SPs (todos idénticos)

```sql
-- 1. Lee sentencias SQL de la tabla CARACTERISTICA
SELECT Cod_Caracteristica_Fte, Descripcion_Caracteristica, SQL_String
FROM CARACTERISTICA
WHERE Cod_Caracteristica_Fte = '1.3- Calc Caracteristica_Direc'
ORDER BY 1, 2;

-- 2. Por cada fila, reemplaza variables y ejecuta
SET V_CADENA = OREPLACE(OREPLACE(OREPLACE(
    V_SQL,
    'REC_STAGE', P_BDSTAGE),
    'REC_VISTA', P_BDVISTA),
    'P_LOTE', CAST(P_Lote AS VARCHAR(12)));

CALL SP_EXECSTRING_DES(..., V_CADENA, ...);
```

**⭐ Implicación clave**: La lógica real de scoring está en la tabla `CARACTERISTICA`, no en los SPs. El archivo `Caracteristicas.txt` (133 KB) probablemente contiene esas sentencias SQL.

### Salida

Cada SP genera una tabla stage con scores:
- `Orden_TelF` — Score de teléfonos fijos
- `Orden_TM` — Score de celulares
- `Orden_Email` — Score de emails
- `Orden_Direcc` — Score de direcciones

---

## ORDENAMIENTO_242_131 — Cálculo de Ordenamiento Principal

### Arquitectura

Script shell que ejecuta **12 SPs** en secuencia controlada (paralelo donde es posible):

```
Fase 1 (Paralelo):
  PRO_ORD_MATERIALIZA_BTT     — Materializa datos BTT
  PRO_ORD_MATERIALIZA_REC     — Materializa datos REC

Fase 2 (Secuencial):
  PRO_ORD_UNIF_BTT_REC        — Unifica BTT + REC

Fase 3 (Paralelo):
  PRO_ORD_CTA_ATRIBUTOS       — Cuenta atributos
  PRO_ORD_UBIC_DIRECCIONES     — Ubicaciones y direcciones

Fase 4 (Secuencial):
  PRO_ORD_CTA_TOTALES_PERSONAS — Totales por persona

Fase 5 (Paralelo):
  PRO_ORD_CTA_TOTALES_PERSONAS_1 — Totales parte 1
  PRO_ORD_CALC_UBICACIONES       — Cálculo ubicaciones

Fase 6 (Paralelo):
  PRO_ORD_CALC_UBICACIONES_1     — Cálculo ubicaciones parte 1

Fase 7 (Secuencial):
  PRO_ORD_UNIF_BTT_REC_2         — Unifica BTT + REC parte 2

Fase 8 (Paralelo):
  PRO_ORD_CTA_TOTALES_PERSONAS_2 — Totales parte 2
  PRO_ORD_CALC_UBICACIONES_2     — Cálculo ubicaciones parte 2
```

**Parámetro de fecha**: Recibe `ELOTE` del archivo de parámetros para filtrar por rango de fechas. Soporta fecha única o rango.

**⚠️ Nota**: Estos 12 SPs NO están en `Ordenamiento.sql` (17.7 KB). Están probablemente en el DDL de Estandarización (681 KB) o en otro archivo no incluido. Los SPs en `Ordenamiento.sql` son solo los de cursor de características.

---

## P0027_111 — Consolidación de Scores

### Lógica

Consolida las 4 tablas de score en una sola:

```sql
CREATE TABLE TablaResultCaract_TUbic AS (
    SELECT Cod_DW_Persona_Ubic, SCORE AS Orden_prioridad, Lugar, Cod_Pin_Persona, Id_Buro_Persona
    FROM Orden_TM          -- Celulares
    UNION ALL
    SELECT ... FROM Orden_Email    -- Emails
    UNION ALL
    SELECT ... FROM Orden_TelF     -- Teléfonos fijos
    UNION ALL
    SELECT ... FROM Orden_Direcc   -- Direcciones
)
```

Luego crea tabla intermedia y vista final `VstgUBI_ORDENAMIENTO` con:
- JOIN contra `RELACION_PERSONA_UBICACION` para obtener datos actuales
- Calcula `SEVERIDAD_UPDATE` y `SEVERIDAD` para control de persistencia

---

## P0027_130 — Persistencia del Ordenamiento

UPDATE a `RELACION_PERSONA_UBICACION` en 2 pasos:

```sql
-- Paso 1: Guarda orden anterior y marca fecha
UPDATE RELACION_PERSONA_UBICACION
SET LOTE_ACTUALIZACION = @LOTE,
    Fecha_Modificacion = CURRENT_DATE,
    Fecha_Ult_Ordenamiento = CURRENT_DATE,
    Orden_Prioridad_Anterior = :IN_Orden_Prioridad
WHERE Cod_DW_Persona_Ubic = :IN_Cod_DW_Persona_Ubic;

-- Paso 2: Asigna nuevo orden
UPDATE RELACION_PERSONA_UBICACION
SET Orden_Prioridad = :IN_Lugar
WHERE Cod_DW_Persona_Ubic = :IN_Cod_DW_Persona_Ubic;
```

También actualiza `CONTROL_ORDENAMIENTO.Fecha_Ult_Ord`.

---

## Tabla CARACTERISTICA — El Corazón del Ordenamiento

### Estructura

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `Cod_Caracteristica_Fte` | VARCHAR | Código/categoría (ej: `'1.3- Calc Caracteristica_Direc'`) |
| `Descripcion_Caracteristica` | VARCHAR | Descripción del paso |
| `SQL_String` | VARCHAR(32000) | **Sentencia SQL completa a ejecutar** |

### Funcionamiento

La tabla contiene filas ordenadas por `Cod_Caracteristica_Fte` y `Descripcion_Caracteristica`. Cada fila es un paso SQL que:
1. Crea tablas temporales con cálculos intermedios
2. Calcula scores basados en variables de negocio
3. Genera las tablas finales `Orden_TelF`, `Orden_TM`, `Orden_Email`, `Orden_Direcc`

### Archivo Caracteristicas.txt (133 KB) — ANALIZADO

Dump de la tabla `CARACTERISTICA`. Contiene ~160 sentencias SQL que implementan un **modelo de scoring por regresión logística** con coeficientes Beta.

#### Patrón de Scoring (3 fases por canal)

```
Fase 1: Calcular métricas brutas
  → Meses de reporte, total reportes, reportes por ventana temporal

Fase 2: Categorizar en rangos (discretización)
  → CASE WHEN valor < X THEN 1 WHEN valor < Y THEN 2 ... END AS _cat

Fase 3: Ponderar con coeficiente Beta
  → (categoría / max_categoría) * Beta → _Peso
  → Σ pesos → SCORE
  → ROW_NUMBER() OVER (PARTITION BY persona ORDER BY SCORE DESC) → Lugar
```

#### Características por Canal

| Canal | Prefijo | # Características | Ejemplos |
|-------|---------|-------------------|----------|
| Teléfono fijo | CO01TEL | ~12 | Meses reporte, % reportes 3/6/12m, coincidencia geo, ciudad DANE |
| Celular | CO01CEL | ~11 | Meses reporte, operador (prefijo 3 dígitos), tipo cuenta, % suscriptores |
| Email | CO01EMA | ~10 | Meses reporte, dominio conocido (gmail/hotmail/yahoo), volumen |
| Dirección | CO00DIR | ~12 | Meses reporte, sector financiero, tipo uso (RES/LAB/CRR), conteo direcciones |

#### Tablas de Coeficientes Beta

| Vista | Canal |
|-------|-------|
| `V_Beta_Ordenamiento_Tel` | Teléfono fijo |
| `V_Beta_Ordenamiento_Cel` | Celular |
| `V_Beta_Ordenamiento_Email` | Email |
| `V_Beta_Ordenamiento_Dir` | Dirección |

#### Fórmula de Score

```sql
Score = Σ (categoría_i / max_categoría_i) × Beta_i
Lugar = ROW_NUMBER() OVER (PARTITION BY persona ORDER BY Score DESC)
```

#### Migración

Todo el SQL es **estándar y migrable a Redshift** con ajustes menores:
- `COLLECT STATISTICS` → `ANALYZE`
- `PRIMARY INDEX` → `DISTKEY`/`SORTKEY`
- `CREATE MULTISET TABLE` → `CREATE TABLE`
- Window functions (`ROW_NUMBER`, `SUM OVER`) → funcionan igual

**La migración del ordenamiento es significativamente más simple que la de unificación.**

---

## Modelo de Datos

### Tablas que se escriben

| Tabla | Operación |
|-------|-----------|
| `REC_DATOS.RELACION_PERSONA_UBICACION` | UPDATE `Orden_Prioridad`, `Orden_Prioridad_Anterior`, `Fecha_Ult_Ordenamiento` |
| `REC_DATOS.TablaResultCaract_TUbic` | CREATE (consolidación de scores) |
| `REC_DATOS.TablaResult_Inter` | CREATE (intermedia) |
| `REC_DATOS.TablaResult_SDUP` | CREATE (sin duplicados) |
| `REC_DATOS.CONTROL_ORDENAMIENTO` | UPDATE `Fecha_Ult_Ord` |

### Tablas stage que se leen (generadas por SPs)

| Tabla | Contenido |
|-------|-----------|
| `Orden_TM` | Scores de celulares |
| `Orden_Email` | Scores de emails |
| `Orden_TelF` | Scores de teléfonos fijos |
| `Orden_Direcc` | Scores de direcciones |

---

## Indicadores de Movilidad (P0029)

Scripts separados del ordenamiento principal:

| Script | Paso | Descripción |
|--------|------|-------------|
| `P0029_INDICADORES_MOVILIDAD_111.BTQ` | Setup | Creación de tablas para indicadores |
| `P0029_INDICADORES_MOVILIDAD_120.TPT` | Carga | Carga de datos |
| `P0029_INDICADORES_MOVILIDAD_130.TPT` | Transformación | Cálculo de indicadores (8.5 KB) |
| `P0029_INDICADORES_MOVILIDAD_140.TPT` | Resultado | Exportación |

**Pendiente**: Analizar estos scripts en detalle. Probablemente calculan cambios de dirección, frecuencia de movilidad y patrones de desplazamiento.

---

## Resumen de Complejidad para Migración

| Componente | Complejidad | Estrategia sugerida |
|------------|-------------|---------------------|
| **Shell de orquestación** (ORDENAMIENTO_242, BTEQ_CURSOR) | 🟢 Baja | Reemplazar con Step Functions, Airflow o script Python |
| **SPs de cursor** (PRO_Cursor_caract*) | 🟢 Baja | Patrón simple: leer SQL de tabla y ejecutar. Reemplazar con loop en Python/SQL |
| **Tabla CARACTERISTICA** | 🔴 Crítica | Contiene TODA la lógica de scoring. Hay que extraer y analizar las sentencias SQL (133 KB) |
| **P0027_111** (consolidación) | 🟢 Baja | UNION ALL + JOINs simples → directo a Redshift |
| **P0027_130** (persistencia) | 🟢 Baja | 2 UPDATEs simples → directo a Redshift |
| **12 SPs de ORD_*** | 🟡 Media-Alta | No están en el DDL disponible. Hay que localizarlos |
| **P0029** (movilidad) | 🟡 Media | Pendiente análisis detallado |

### Diferencia clave vs Unificación

| Aspecto | Unificación | Ordenamiento |
|---------|-------------|-------------|
| Lógica | Hardcodeada en SPs (SQL dinámico complejo) | Data-driven (tabla CARACTERISTICA) |
| Complejidad de código | 🔴 Muy alta (XMLAGG, columnas dinámicas) | 🟡 Media (patrón cursor simple) |
| Complejidad de negocio | 🔴 Alta (6 escenarios con subcasos) | 🔴 Alta (scoring multi-variable, pero en datos) |
| Migración de lógica | Requiere reescritura | Requiere extraer SQL de tabla CARACTERISTICA |
| Paralelismo | No explícito | Sí (shell ejecuta SPs en paralelo) |

### Próximo paso crítico

**Analizar `Caracteristicas.txt` (133 KB)** — Este archivo contiene las sentencias SQL que definen toda la lógica de scoring. Sin entender su contenido, no se puede migrar el ordenamiento.

### Insumos faltantes

- **12 SPs de PRO_ORD_*** — No están en `Ordenamiento.sql`. Posiblemente en otro DDL o en el ambiente de Teradata directamente.
- **Tabla CARACTERISTICA completa** — El archivo `Caracteristicas.txt` necesita análisis.

---

*Generado: 2026-04-17 | Fuente: `Experian Reconocer/Ordenamiento/`*
