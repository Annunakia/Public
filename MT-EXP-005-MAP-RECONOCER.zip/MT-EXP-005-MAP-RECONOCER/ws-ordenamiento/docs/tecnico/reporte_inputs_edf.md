# Reporte Consolidado de Inputs EDF — Unificación y Ordenamiento

> **Fecha de generación:** 2025-01  
> **Propósito:** Documentar TODAS las tablas y columnas que los procesos de Unificación y Ordenamiento consumen desde EDF (upstream data source, esquema `rec_datos` / `bdm_datos`).  
> **Uso:** Validar contratos de datos con EDF, planificar pruebas de integración, y asegurar que todas las dependencias upstream estén cubiertas.

---

## 1. Proceso: ORDENAMIENTO

### 1.1 rec_datos.control_ordenamiento

| Campo | Tipo de uso |
|-------|-------------|
| fecha_ult_ord | Filtro temporal (fecha último ordenamiento) |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase1_materializacion/01_materializa_btt.sql`
- **Línea:** 68
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase1_materializacion/01_materializa_btt.sql | 68`

---

### 1.2 rec_datos.metadata_carga_log

| Campo | Tipo de uso |
|-------|-------------|
| lote_id | Identificador de lote |
| tabla_nombre | Nombre de tabla cargada |
| inserts_count | Conteo de inserts |
| updates_count | Conteo de updates |
| descripcion | Estado de la carga ('Ok') |
| fecha_carga | Fecha de procesamiento |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase1_materializacion/01_materializa_btt.sql`
- **Línea:** 46
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase1_materializacion/01_materializa_btt.sql | 46`

---

### 1.3 rec_datos.metadata_ordenamiento

| Campo | Tipo de uso |
|-------|-------------|
| nombre_tabla | Catálogo de tablas por modelo |
| nombre_db | Discriminador de modelo (BTT/REC) |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase1_materializacion/01_materializa_btt.sql`
- **Línea:** 70
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase1_materializacion/01_materializa_btt.sql | 70`

---

### 1.4 rec_datos.v_buro_persona

| Campo | Tipo de uso |
|-------|-------------|
| cod_pin_persona | Clave persona (PIN) |
| id_buro_persona | Clave persona (Buró) |
| lote | Filtro por lote de carga |
| lote_actualizacion | Filtro por lote de actualización |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase1_materializacion/01_materializa_btt.sql`
- **Línea:** 87
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase1_materializacion/01_materializa_btt.sql | 87`

---

### 1.5 rec_datos.v_cuenta

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_cta | Clave cuenta |
| id_buro_cliente | Relación con persona |
| lote | Filtro por lote |
| lote_actualizacion | Filtro por lote |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase1_materializacion/01_materializa_btt.sql`
- **Línea:** 83
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase1_materializacion/01_materializa_btt.sql | 83`

---

### 1.6 rec_datos.vu_cuenta

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_cta | Clave cuenta |
| cod_dw_tipo_cta | Tipo de cuenta |
| cod_tipo_cta_fte | Tipo cuenta fuente |
| num_cta | Número de cuenta |
| id_buro_suscriptor | Suscriptor |
| nit_suscriptor | NIT suscriptor |
| id_buro_cliente | Relación con persona |
| cod_pin_persona | PIN persona |
| cod_tipo_ident_fte | Tipo identificación fuente |
| num_ident | Número identificación |
| cod_dw_doc_ident | Documento identidad |
| num_contr | Número contrato |
| fecha_apertura | Fecha apertura cuenta |
| fecha_vencimiento | Fecha vencimiento |
| ind_moneda_legal | Indicador moneda legal |
| cod_dw_est_mod | Estado modificación |
| cod_est_mod_fte | Estado modificación fuente |
| ind_tarjeta_amparada | Indicador tarjeta amparada |
| nombre_ciudad_radicacion | Ciudad radicación |
| cod_dw_razon_bloqueo | Razón bloqueo |
| num_plastico | Número plástico |
| cod_dw_clase_tarjeta_credito | Clase tarjeta crédito |
| cod_clase_tarjeta_credito_fte | Clase tarjeta fuente |
| cod_dw_franquicia | Franquicia |
| cod_franquicia_fte | Franquicia fuente |
| cod_marca_privada_fte | Marca privada fuente |
| cod_dw_tipo_rel_con_cta | Tipo relación con cuenta |
| cod_tipo_rel_con_cta_fte | Tipo relación fuente |
| cod_dw_motivo_origen | Motivo origen |
| cod_motivo_origen_fte | Motivo origen fuente |
| cod_dw_tipo_obligacion | Tipo obligación |
| cod_tipo_obligacion_fte | Tipo obligación fuente |
| cod_dw_clase_cta | Clase cuenta |
| cod_clase_cta_fte | Clase cuenta fuente |
| cod_dw_clase_garantia_buro | Clase garantía buró |
| cod_clase_garantia_buro_fte | Clase garantía fuente |
| cod_dw_tipo_bloqueo | Tipo bloqueo |
| cod_tipo_bloqueo_fte | Tipo bloqueo fuente |
| fecha_ultima_actualizacion | Fecha última actualización |
| cod_dw_pais | País |
| cod_pais_geo_fte | País geográfico fuente |
| cod_dw_fte_dato | Fuente dato |
| cod_dw_evento_entrega_dato | Evento entrega dato |
| nombre_cod_entrega_dato | Nombre código entrega |
| desc_cod_entrega_dato | Descripción código entrega |
| cod_entrega_dato_fte | Código entrega fuente |
| cod_nov_buro_fte | Novedad buró fuente |
| desc_est_vigencia | Estado vigencia |
| fecha_ultima_actualizacion_nov | Fecha actualización novedad |
| cod_dw_est_suscriptor | Estado suscriptor |
| fecha_est | Fecha estado |
| cod_est_suscriptor_fte | Estado suscriptor fuente |
| cod_motivo_bloqueo_fte | Motivo bloqueo fuente |
| cod_dw_natu_cta | Naturaleza cuenta |
| cod_natu_cta_fte | Naturaleza cuenta fuente |
| fecha_nov | Fecha novedad |
| cod_calif_comp_cta_fte | Calificación comportamiento |
| cod_dw_entrega_dato | Entrega dato |
| lote | Lote de carga |
| lote_actualizacion | Lote actualización |
| num_cuotas_pactadas | Número cuotas pactadas |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase2_atributos_cuenta/01_cta_atributos.sql`
- **Línea:** 50
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase2_atributos_cuenta/01_cta_atributos.sql | 50`

---

### 1.7 rec_datos.v_comportamiento_cuenta

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_cta | Clave cuenta |
| lote | Filtro por lote |
| lote_actualizacion | Filtro por lote |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase1_materializacion/01_materializa_btt.sql`
- **Línea:** 103
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase1_materializacion/01_materializa_btt.sql | 103`

---

### 1.8 rec_datos.v_comportamiento_cuenta_activo

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_cta | Clave cuenta |
| lote | Filtro por lote |
| lote_actualizacion | Filtro por lote |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase1_materializacion/01_materializa_btt.sql`
- **Línea:** 127
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase1_materializacion/01_materializa_btt.sql | 127`

---

### 1.9 rec_datos.v_comportamiento_cuenta_pasivo

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_cta | Clave cuenta |
| lote | Filtro por lote |
| lote_actualizacion | Filtro por lote |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase1_materializacion/01_materializa_btt.sql`
- **Línea:** 141
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase1_materializacion/01_materializa_btt.sql | 141`

---

### 1.10 rec_datos.vu_comportamiento_cta_activo

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_cta | Clave cuenta |
| valor_inicial | Valor inicial del crédito |
| valor_cuota_mensual | Cuota mensual |
| valor_saldo | Saldo actual |
| numero_dias_mora | Días en mora |
| valor_saldo_mora | Saldo en mora |
| num_cuotas_pagadas | Cuotas pagadas |
| valor_disponible | Cupo disponible |
| num_cuotas_mora | Cuotas en mora |
| num_cuotas_pactadas | Cuotas pactadas |
| fecha_nov | Fecha novedad (filtro ventana 12 meses) |
| cod_altura_mora_fte | Altura de mora fuente |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase2_atributos_cuenta/03_cta_totales_personas_1.sql`
- **Línea:** 56
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase2_atributos_cuenta/03_cta_totales_personas_1.sql | 56`

---

### 1.11 rec_datos.vu_comportamiento_cta_pasivo

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_cta | Clave cuenta |
| fecha_nov | Fecha novedad (filtro ventana 12 meses) |
| valor_debitos_efec | Débitos efectivo |
| valor_creditos_efec | Créditos efectivo |
| valor_debitos_transf | Débitos transferencia |
| valor_creditos_transf | Créditos transferencia |
| valor_cheques_pags | Cheques pagados |
| valor_cheques_devs | Cheques devueltos |
| cantidad_cheques_devs | Cantidad cheques devueltos |
| cantidad_cheques_pags | Cantidad cheques pagados |
| dias_sobregiro_aut | Días sobregiro autorizado |
| valor_cupo_sobregiro_aut | Cupo sobregiro autorizado |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase2_atributos_cuenta/04_cta_totales_personas_2.sql`
- **Línea:** 60
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase2_atributos_cuenta/04_cta_totales_personas_2.sql | 60`

---

### 1.12 rec_datos.log_td

| Campo | Tipo de uso |
|-------|-------------|
| lote | Identificador de lote |
| fecha_hora_inicio | Fecha/hora inicio carga |
| tabla_destino_prod | Tabla destino en producción |
| estado_ejecucion | Estado de la ejecución ('Cargue Ok', 'Finalizado OK') |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql`
- **Línea:** 56
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql | 56`

---

### 1.13 rec_datos.v_reporte_ubicacion_original

| Campo | Tipo de uso |
|-------|-------------|
| cod_pin_persona | Clave persona (PIN) |
| id_buro_persona | Clave persona (Buró) |
| lote | Filtro por lote |
| lote_actualizacion | Filtro por lote |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql`
- **Línea:** 78
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql | 78`

---

### 1.14 rec_datos.vu_relacion_persona_ubicacion

| Campo | Tipo de uso |
|-------|-------------|
| cod_pin_persona | Clave persona (PIN) |
| id_buro_persona | Clave persona (Buró) |
| cod_dw_persona_ubic | Clave relación persona-ubicación |
| lote | Filtro por lote |
| lote_actualizacion | Filtro por lote |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql`
- **Línea:** 95
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql | 95`

---

### 1.15 rec_datos.vu_reporte_relacion_pers_ubi

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_persona_ubic | Clave relación persona-ubicación |
| lote | Filtro por lote |
| lote_actualizacion | Filtro por lote |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql`
- **Línea:** 112
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql | 112`

---

### 1.16 rec_datos.v_bloqueo

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_persona_ubic | Clave relación persona-ubicación |
| fecha_bloqueo | Fecha del bloqueo (filtro temporal) |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql`
- **Línea:** 139
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql | 139`

---

### 1.17 rec_datos.v_relacion_persona_ubicacion

| Campo | Tipo de uso |
|-------|-------------|
| cod_pin_persona | Clave persona (PIN) |
| id_buro_persona | Clave persona (Buró) |
| cod_dw_persona_ubic | Clave relación persona-ubicación |
| cod_dw_ubic | Clave ubicación |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql`
- **Línea:** 141
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql | 141`

---

### 1.18 rec_datos.v_relacion_ubicac_estandar_geo

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_ubic | Clave ubicación |
| lote | Filtro por lote |
| lote_actualizacion | Filtro por lote |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql`
- **Línea:** 153
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql | 153`

---

### 1.19 rec_datos.v_ubicacion_original

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_ubic | Clave ubicación |
| lote | Filtro por lote |
| lote_actualizacion | Filtro por lote |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql`
- **Línea:** 172
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql | 172`

---

### 1.20 rec_datos.v_ubicacion_estandarizada

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_ubic | Clave ubicación |
| cod_dw_tipo_ubicacion | Tipo de ubicación |
| texto_ubicacion | Texto de la dirección estandarizada |
| cod_dw_fuente_est | Fuente de estandarización |
| cod_dw_ciudad | Ciudad |
| cod_dw_gestion_registro | Gestión del registro (filtro 'Valida') |
| lote | Filtro por lote |
| lote_actualizacion | Filtro por lote |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql`
- **Línea:** 191
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql | 191`

---

### 1.21 rec_datos.v_log_ubicacion_estandariza

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_ubic | Clave ubicación |
| lote | Filtro por lote |
| lote_actualizacion | Filtro por lote |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql`
- **Línea:** 207
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql | 207`

---

### 1.22 rec_datos.v_unificacion_direccion

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_persona_ubic | Clave relación persona-ubicación |
| lote | Filtro por lote |
| lote_actualizacion | Filtro por lote |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql`
- **Línea:** 223
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase1_materializacion/02_materializa_rec.sql | 223`

---

### 1.23 rec_datos.v_razon_bloqueo

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_razon_bloqueo | Clave razón bloqueo (JOIN) |
| cod_razon_bloqueo_fte | Código razón bloqueo fuente |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase2_atributos_cuenta/01_cta_atributos.sql`
- **Línea:** 101
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase2_atributos_cuenta/01_cta_atributos.sql | 101`

---

### 1.24 rec_datos.v_fuente_dato

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_fte_dato | Clave fuente dato (JOIN) |
| cod_fte_dato_fte | Código fuente dato fuente |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase2_atributos_cuenta/01_cta_atributos.sql`
- **Línea:** 103
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase2_atributos_cuenta/01_cta_atributos.sql | 103`

---

### 1.25 rec_datos.v_cod_entrega_dato

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_entrega_dato | Clave entrega dato (JOIN) |
| fecha_ingreso_suscriptor | Fecha ingreso del suscriptor |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase2_atributos_cuenta/01_cta_atributos.sql`
- **Línea:** 105
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase2_atributos_cuenta/01_cta_atributos.sql | 105`

---

### 1.26 rec_datos.relacion_persona_ubicacion

| Campo | Tipo de uso |
|-------|-------------|
| cod_pin_persona | Clave persona (PIN) |
| id_buro_persona | Clave persona (Buró) |
| cod_dw_persona_ubic | Clave relación persona-ubicación |
| cod_dw_ubic | Clave ubicación |
| cod_dw_telefono | Clave teléfono |
| cod_dw_direccion_electronica | Clave dirección electrónica |
| cod_dw_direccion_fisica | Clave dirección física |
| cod_dw_tipo_ubicacion_dir | Tipo ubicación dirección |
| orden_prioridad | Orden de prioridad |
| ind_unificacion | Indicador de unificación |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase3_ubicaciones/01_ubic_direcciones.sql`
- **Línea:** 40
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase3_ubicaciones/01_ubic_direcciones.sql | 40`

---

### 1.27 rec_datos.mat_reporte_rel_pers_ubi

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_reporte_persona_ubic | Clave reporte persona-ubicación |
| cod_dw_persona_ubic | Clave relación persona-ubicación |
| id_buro_suscriptor | Suscriptor |
| cod_dw_cta | Clave cuenta |
| fecha_reporte | Fecha del reporte |
| fecha_apertura | Fecha apertura |
| fecha_nov | Fecha novedad |
| desc_est_vigencia | Estado vigencia |
| nombre_natu_cta | Naturaleza cuenta |
| nombre_tipo_rel_con_cta | Tipo relación con cuenta |
| cod_dw_motivo_bloqueo | Motivo bloqueo |
| id_flag_nuevo | Flag nuevo |
| id_flag_desde | Flag desde (0=reciente, 1=antiguo) |
| flag_bloqueo | Flag bloqueo |
| cod_dw_fuente | Fuente |
| cod_dw_matricula | Matrícula |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase3_ubicaciones/01_ubic_direcciones.sql`
- **Línea:** 55
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase3_ubicaciones/01_ubic_direcciones.sql | 55`

---

### 1.28 rec_datos.bloqueo

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_persona_ubic | Clave relación persona-ubicación (exclusión) |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase3_ubicaciones/04_calc_ubicaciones_2.sql`
- **Línea:** 133
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase3_ubicaciones/04_calc_ubicaciones_2.sql | 133`

---

### 1.29 rec_datos.v_gestion_registro

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_gestion_registro | Clave gestión registro |
| descripcion_gestion_registro | Descripción (filtro 'Valida') |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase3_ubicaciones/04_calc_ubicaciones_2.sql`
- **Línea:** 157
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase3_ubicaciones/04_calc_ubicaciones_2.sql | 157`

---

### 1.30 rec_datos.v_fuente

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_fuente | Clave fuente (JOIN) |
| descripcion_fuente | Descripción de la fuente |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase3_ubicaciones/04_calc_ubicaciones_2.sql`
- **Línea:** 172
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase3_ubicaciones/04_calc_ubicaciones_2.sql | 172`

---

### 1.31 rec_datos.v_geografia

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_ciudad | Clave ciudad (JOIN) |
| cod_dane_municipio | Código DANE municipio |
| cod_dane_departamento | Código DANE departamento |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase3_ubicaciones/04_calc_ubicaciones_2.sql`
- **Línea:** 174
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase3_ubicaciones/04_calc_ubicaciones_2.sql | 174`

---

### 1.32 rec_datos.v_tipo_ubicacion_direccion

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_tipo_ubicacion_dir | Clave tipo ubicación dirección (JOIN) |
| descripcion_tipo_ubicacion_dir | Descripción tipo ubicación |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase3_ubicaciones/04_calc_ubicaciones_2.sql`
- **Línea:** 207
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase3_ubicaciones/04_calc_ubicaciones_2.sql | 207`

---

### 1.33 rec_datos.vu_persona

| Campo | Tipo de uso |
|-------|-------------|
| cod_pin_persona | Clave persona (PIN) |
| id_buro_persona | Clave persona (Buró) |
| cod_dw_tipo_persona | Tipo persona (JOIN con v_tipo_persona) |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase3_ubicaciones/04_calc_ubicaciones_2.sql`
- **Línea:** 222
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase3_ubicaciones/04_calc_ubicaciones_2.sql | 222`

---

### 1.34 rec_datos.v_tipo_persona

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_tipo_persona | Clave tipo persona (JOIN) |
| desc_tipo_persona | Descripción (Natural/Jurídica) |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase3_ubicaciones/04_calc_ubicaciones_2.sql`
- **Línea:** 223
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase3_ubicaciones/04_calc_ubicaciones_2.sql | 223`

---

### 1.35 rec_datos.v_tipo_cuenta

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_tipo_cta | Clave tipo cuenta (JOIN) |
| desc_tipo_cta | Descripción tipo cuenta |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase3_ubicaciones/04_calc_ubicaciones_2.sql`
- **Línea:** 258
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase3_ubicaciones/04_calc_ubicaciones_2.sql | 258`

---

### 1.36 rec_datos.direccion_fisica

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_ubic | Clave ubicación |
| cod_dw_direccion_fisica | Clave dirección física |
| complemento | Complemento de la dirección |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase3_ubicaciones/04_calc_ubicaciones_2.sql`
- **Línea:** 283
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase3_ubicaciones/04_calc_ubicaciones_2.sql | 283`

---

### 1.37 rec_datos.relacion_ubicac_estandar_geo

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_ubic | Clave ubicación |
| urbanizacion_barrio | Barrio/urbanización |
| latitud | Latitud geográfica |
| longitud | Longitud geográfica |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase3_ubicaciones/04_calc_ubicaciones_2.sql`
- **Línea:** 320
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase3_ubicaciones/04_calc_ubicaciones_2.sql | 320`

---

### 1.38 rec_datos.ubicacion_atributo_hash

| Campo | Tipo de uso |
|-------|-------------|
| cod_pin_persona | Clave persona (PIN) |
| id_buro_persona | Clave persona (Buró) |
| cod_dw_persona_ubic | Clave relación persona-ubicación |
| concatena | Concatenación de atributos |
| cod_hash | Hash MD5 de la dirección |
| fecha_insercion | Fecha de inserción |
| fecha_actualizacion | Fecha de actualización |

- **Archivo primera referencia:** `ws-ordenamiento/src/redshift/fase3_ubicaciones/06_final_ubic_direcciones.sql`
- **Línea:** 55
- **Comando nvim:** `:e ws-ordenamiento/src/redshift/fase3_ubicaciones/06_final_ubic_direcciones.sql | 55`

---

## 2. Proceso: UNIFICACIÓN

> **Nota:** En Unificación el esquema se llama `bdm_datos` (equivalente a `rec_datos` en Ordenamiento). Ambos son tablas provistas por EDF.

### 2.1 bdm_datos.relacion_persona_ubicacion

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_persona_ubic | Clave relación persona-ubicación |
| id_buro_persona | Clave persona (Buró) |
| cod_pin_persona | Clave persona (PIN) |
| cod_dw_ubic | Clave ubicación |
| cod_dw_direccion_fisica | Clave dirección física |
| cod_dw_tipo_ubicacion_dir | Tipo ubicación dirección |
| ind_unificacion | Indicador de unificación (filtro IS NULL) |
| orden_prioridad | Orden de prioridad |
| fecha_relacion_persona_ubicaci | Fecha de la relación |
| lote | Lote de carga |
| cod_tipo_ident_fte | Tipo identificación fuente (filtro NIT) |
| bloqueado | Indicador de bloqueo |

- **Archivo primera referencia:** `ws-unificacion/src/redshift/sql/02_regla1_unificacion.sql`
- **Línea:** 24
- **Comando nvim:** `:e ws-unificacion/src/redshift/sql/02_regla1_unificacion.sql | 24`

---

### 2.2 bdm_datos.ubicacion_estandarizada

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_ubic | Clave ubicación (JOIN con RPU) |
| texto_ubicacion | Texto de la dirección estandarizada |
| cod_dw_ciudad | Ciudad (agrupación Regla 1) |
| cod_dw_tipo_ubicacion | Tipo de ubicación |
| latitud | Latitud (Regla 3 geolocalización) |
| longitud | Longitud (Regla 3 geolocalización) |

- **Archivo primera referencia:** `ws-unificacion/src/redshift/sql/02_regla1_unificacion.sql`
- **Línea:** 26
- **Comando nvim:** `:e ws-unificacion/src/redshift/sql/02_regla1_unificacion.sql | 26`

---

### 2.3 bdm_datos.direccion_fisica

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_direccion_fisica | Clave dirección física (JOIN) |
| complemento | Complemento de la dirección |
| tipo_via_principal | Tipo vía principal (Regla 3) |
| via_principal | Vía principal (Regla 3) |
| via_generadora | Vía generadora (Regla 3) |
| numero_puerta | Número de puerta (Regla 3) |
| cod_dw_ubic | Clave ubicación |
| generada_enriquecida | Flag dirección generada por motor |

- **Archivo primera referencia:** `ws-unificacion/src/redshift/sql/02_regla1_unificacion.sql`
- **Línea:** 28
- **Comando nvim:** `:e ws-unificacion/src/redshift/sql/02_regla1_unificacion.sql | 28`

---

### 2.4 bdm_datos.reporte_relacion_persona_ubica

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_persona_ubic | Clave relación persona-ubicación |
| id_buro_suscriptor | Suscriptor (conteo entidades) |
| fecha_reporte | Fecha del reporte |

- **Archivo primera referencia:** `ws-unificacion/src/redshift/sql/02_regla1_unificacion.sql`
- **Línea:** 30
- **Comando nvim:** `:e ws-unificacion/src/redshift/sql/02_regla1_unificacion.sql | 30`

---

### 2.5 bdm_datos.ciiu_persona

| Campo | Tipo de uso |
|-------|-------------|
| id_buro_persona | Clave persona (Buró) |
| cod_act_econo_ciiu_fte | Código CIIU (actividad económica) |

- **Archivo primera referencia:** `ws-unificacion/src/redshift/sql/02_regla1_unificacion.sql`
- **Línea:** 32
- **Comando nvim:** `:e ws-unificacion/src/redshift/sql/02_regla1_unificacion.sql | 32`

---

### 2.6 bdm_datos.tipo_ubicacion_dir

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_tipo_ubicacion_dir | Clave tipo ubicación dirección |
| descripcion_tipo_ubicacion_dir | Descripción (LAB, RES, CRR, etc.) |

- **Archivo primera referencia:** `ws-unificacion/src/redshift/sql/02_regla1_unificacion.sql`
- **Línea:** 34
- **Comando nvim:** `:e ws-unificacion/src/redshift/sql/02_regla1_unificacion.sql | 34`

---

### 2.7 bdm_datos.nomenclatura

| Campo | Tipo de uso |
|-------|-------------|
| nomenclatura | Abreviatura de nomenclatura (AP, CS, TO, etc.) |
| nivel_complemento | Nivel jerárquico del complemento |

- **Archivo primera referencia:** `ws-unificacion/src/redshift/sql/04_regla2_esc4.sql`
- **Línea:** 62 (JOIN bdm_datos.nomenclatura NMC1)
- **Comando nvim:** `:e ws-unificacion/src/redshift/sql/04_regla2_esc4.sql | 62`

---

### 2.8 bdm_datos.diccionario_complementos

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_ubic | Clave ubicación |
| id_buro_persona | Clave persona (Buró) |
| nomenclatura | Nomenclatura del complemento |
| nomen | Abreviatura de nomenclatura |
| valor | Valor del complemento |
| frecuencia | Frecuencia de aparición |

- **Archivo primera referencia:** `ws-unificacion/src/redshift/sql/04_regla2_esc4.sql`
- **Línea:** 100 (LEFT JOIN bdm_datos.diccionario_complementos dc)
- **Comando nvim:** `:e ws-unificacion/src/redshift/sql/04_regla2_esc4.sql | 100`

---

### 2.9 bdm_datos.unificacion_direccion (tabla de salida/lectura)

| Campo | Tipo de uso |
|-------|-------------|
| cod_dw_persona_ubic | Clave relación persona-ubicación |
| cod_dw_direccion_unificada | Dirección padre unificada |
| unifica_atributos | Tipo de unificación (1=R1, 2=R2) |
| fecha_unificacion | Fecha de unificación |
| lote | Lote |
| severidad | Severidad |
| usuario_bd | Usuario que ejecutó |

- **Archivo primera referencia:** `ws-unificacion/src/redshift/sql/02_regla1_unificacion.sql`
- **Línea:** 78 (INSERT INTO bdm_datos.unificacion_direccion)
- **Comando nvim:** `:e ws-unificacion/src/redshift/sql/02_regla1_unificacion.sql | 78`

---

### 2.10 bdm_datos.diccionario_via

| Campo | Tipo de uso |
|-------|-------------|
| tipo | Tipo de diccionario (Via_Generadora / Numero_Puerta) |
| llave | Llave compuesta (tipo_via + via_principal + componente) |
| via_generadora | Vía generadora o número puerta |
| cod_dw_municipio | Municipio |
| conteo | Frecuencia de aparición |

- **Archivo primera referencia:** `ws-unificacion/src/redshift/sql/10_regla3_geo.sql`
- **Línea:** 95 (DELETE FROM bdm_datos.diccionario_via)
- **Comando nvim:** `:e ws-unificacion/src/redshift/sql/10_regla3_geo.sql | 95`

---

## 3. Resumen Consolidado

### Totales por proceso

| Proceso | Tablas EDF | Columnas únicas referenciadas |
|---------|-----------|-------------------------------|
| **Ordenamiento** | 38 | ~145 |
| **Unificación** | 10 | ~42 |
| **TOTAL** | **48** | **~187** |

> **Nota:** Algunas tablas son compartidas entre ambos procesos (ej: `relacion_persona_ubicacion`, `ubicacion_estandarizada`, `direccion_fisica`). El conteo total incluye duplicados entre procesos.

### Tablas compartidas entre ambos procesos

| Tabla (Ordenamiento: rec_datos / Unificación: bdm_datos) | Ordenamiento | Unificación |
|----------------------------------------------------------|:---:|:---:|
| relacion_persona_ubicacion | ✓ | ✓ |
| ubicacion_estandarizada / v_ubicacion_estandarizada | ✓ | ✓ |
| direccion_fisica | ✓ | ✓ |
| relacion_ubicac_estandar_geo / v_relacion_ubicac_estandar_geo | ✓ | — |
| unificacion_direccion / v_unificacion_direccion | ✓ | ✓ |

### Clasificación por tipo de tabla

| Tipo | Cantidad | Ejemplos |
|------|----------|----------|
| **Tablas transaccionales** (datos de personas/cuentas) | 18 | v_cuenta, vu_cuenta, v_buro_persona, vu_persona |
| **Tablas de ubicación** (direcciones, estandarización) | 14 | ubicacion_estandarizada, direccion_fisica, relacion_persona_ubicacion |
| **Tablas de referencia** (catálogos) | 10 | v_tipo_cuenta, v_tipo_persona, v_gestion_registro, nomenclatura |
| **Tablas de control** (logs, metadata) | 6 | control_ordenamiento, metadata_carga_log, log_td |

---

## 4. Notas Técnicas

1. **Esquemas equivalentes:** `rec_datos` (Ordenamiento) ≡ `bdm_datos` (Unificación). Ambos apuntan al mismo data lake EDF.
2. **Vistas vs tablas:** En Ordenamiento se usan prefijos `v_` (vistas) y `vu_` (vistas unificadas). En Unificación se acceden como tablas directas.
3. **Columnas de control de lote:** Casi todas las tablas transaccionales tienen `lote` y `lote_actualizacion` para filtrado incremental.
4. **Dependencia crítica:** El proceso de Ordenamiento depende de que Unificación haya completado (consume `v_unificacion_direccion`).
