# Documentación Funcional — Ordenamiento

> ⏳ Documentación funcional pendiente de elaboración.

Esta carpeta contendrá la documentación funcional del proceso de Ordenamiento (Scoring de Contactabilidad) una vez se complete el análisis funcional detallado.

## Contenido esperado

- Documento funcional del modelo de scoring
- Reglas de negocio por canal (teléfono fijo, celular, email, dirección)
- Mapeo de variables y coeficientes Beta
