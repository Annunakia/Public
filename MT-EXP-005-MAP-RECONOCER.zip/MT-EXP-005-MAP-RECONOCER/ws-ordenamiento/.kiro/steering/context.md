# Proyecto: Migración Proceso de Ordenamiento – Reconocer

## Contexto
Migración del proceso de Ordenamiento de datos de contacto del sistema Reconocer de Experian, desde Teradata hacia AWS (Redshift).

## Qué hace este proceso
Calcula un score de contactabilidad para cada dato de contacto (dirección, teléfono fijo, celular, email) de una persona, y genera un ranking (Orden_Prioridad) que indica cuál es el dato más probable para contactar a esa persona.

## Modelo de Scoring
Regresión logística con coeficientes Beta. Por cada canal:
1. Calcula ~10-12 características (meses reporte, % reportes por ventana temporal, sector, tipo uso)
2. Discretiza en categorías (CASE WHEN rangos)
3. Pondera: (categoría / max) × Beta
4. Suma pesos → Score
5. ROW_NUMBER() ORDER BY Score DESC → Lugar

## Arquitectura data-driven
La lógica NO está hardcodeada en SPs. Está en la tabla `CARACTERISTICA` que contiene sentencias SQL ejecutadas dinámicamente por cursores. Los coeficientes Beta están en vistas `V_Beta_Ordenamiento_*`.

## Código fuente
- `src/teradata/` — Scripts originales Teradata
- `src/redshift/` — Código migrado (destino)
- `data/parametros/Caracteristicas.txt` — Dump de tabla CARACTERISTICA (133KB, ~160 sentencias SQL)

## Canales (procesados en paralelo)
- Teléfono fijo (CO01TEL) — tabla resultado: Orden_TelF
- Celular (CO01CEL) — tabla resultado: Orden_TM
- Email (CO01EMA) — tabla resultado: Orden_Email
- Dirección (CO00DIR) — tabla resultado: Orden_Direcc

## Migración
SQL estándar, migrable casi directo a Redshift. Significativamente más simple que Unificación.
