# map.md — Mapa de navegación: Ordenamiento

## Entender la lógica de negocio (scoring)
→ `docs/tecnico/analisis_scripts.md` — Modelo de regresión logística, 4 canales, coeficientes Beta

## Ver el código fuente original (Teradata)
→ `src/teradata/Ordenamiento.sql` — DDL + SPs cursor (17.7KB)
→ `src/teradata/ORDENAMIENTO_242_131.BTQ` — Orquestador (llama 12 SPs)
→ `src/teradata/BTEQ_CURSOR_131.BTQ` — Cálculo de características por cursor
→ `src/teradata/P0027_*` — Consolidación + persistencia de scores
→ `src/teradata/P0029_*` — Indicadores de movilidad

## Ver el código migrado (Redshift)
→ `src/redshift/` — (pendiente)

## Parámetros del modelo
→ `data/parametros/Caracteristicas.txt` — Tabla CARACTERISTICA (133KB, ~160 sentencias SQL dinámicas)

## Contexto de preventa
→ `docs/preventa/` — Entregables de preventa (arquitectura, fases, WBS, riesgos)

## Comunicaciones relevantes
→ `docs/comunicaciones/` — Transcripciones de reuniones sobre ordenamiento
