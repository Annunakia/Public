# ws-ordenamiento — Migración Proceso de Ordenamiento

Scoring de contactabilidad: calcula un score por dato de contacto usando regresión logística con coeficientes Beta. 4 canales: teléfono fijo, celular, email, dirección.

## Estado

| Componente | Descripción | Estado |
|------------|-------------|--------|
| Modelo de scoring | Regresión logística, ~45 características, 4 canales | ✅ Entendido |
| Caracteristicas.txt | ~160 sentencias SQL dinámicas descifradas | ✅ Analizado |
| 12 SPs PRO_ORD_* | Stored procedures del orquestador | ❌ No localizados |
| Migración a Redshift | Traducción de SQL | ⏳ Pendiente |

## Estructura

```
ws-ordenamiento/
├── .kiro/steering/
│   ├── context.md              ← Contexto para Kiro
│   └── map.md                  ← Mapa de navegación
├── src/
│   ├── teradata/               ← Código fuente original (P0027, P0029, cursores)
│   └── redshift/               ← Código migrado (pendiente)
├── docs/
│   ├── funcional/              ← (pendiente doc funcional)
│   ├── tecnico/                ← Análisis técnico del modelo de scoring
│   ├── preventa/               ← Entregables de preventa
│   └── comunicaciones/         ← Transcripciones relevantes
└── data/
    └── parametros/
        └── Caracteristicas.txt ← Tabla CARACTERISTICA (133KB, ~160 SQL)
```

## Modelo de scoring

```
Score = Σ (categoría / max) × Beta    por canal (TelFijo, Celular, Email, Dirección)
```

Arquitectura data-driven: la lógica está en la tabla CARACTERISTICA, no hardcodeada en SPs.
