# AGENTS.md — Contexto para agentes de IA

## Qué es este repo

Migración del sistema **Reconocer** de Experian Colombia. Procesa ~65-70M registros de datos de contacto (direcciones, teléfonos, emails) de ciudadanos colombianos. Se migra de Teradata (con UDFs en C) hacia AWS: EDF (Spark/Scala) para estandarización y Amazon Redshift (SQL) para unificación, ordenamiento y cálculo.

## Estructura del repo

```
├── ws-unificacion/          → Workspace migración Unificación (Teradata → Redshift)
├── ws-ordenamiento/         → Workspace migración Ordenamiento (Teradata → Redshift)
├── proyecto/                → Documentación transversal
│   ├── comunicaciones/      → Comunicaciones transversales (workshops generales)
│   ├── entregables/         → Archivos binarios y multimedia (Excel, VTT)
│   ├── gestion/             → Reuniones, compromisos, plan de trabajo, avance
│   ├── metodologia/         → Lecciones aprendidas, comparativas de herramientas
│   ├── orquestacion/        → Control-M, framework batch, orquestación de procesos
│   └── preventa/            → Documentos de preventa centralizados
├── Experian Reconocer/      → Código fuente original del cliente (SOLO LECTURA)
├── MT-Comercial - Preventa/ → Framework de preventa Macondotek (NO MODIFICAR)
├── AGENTS.md
├── README.md
└── .gitignore
```

## Reglas estrictas

1. **NO modificar** nada en `MT-Comercial - Preventa/` — es el framework de preventa de la empresa
2. **NO modificar** nada en `Experian Reconocer/` — es el dump original del cliente
3. Código migrado va en `src/redshift/` de cada workspace
4. Documentación técnica nueva va en `docs/tecnico/` del workspace correspondiente
5. Documentación transversal (arquitectura, gestión) va en `proyecto/`

## Workspaces de migración

### ws-unificacion/

Migra el proceso de **Unificación de Direcciones Físicas**: toma direcciones estandarizadas y las unifica (borrado lógico) cuando son iguales pero difieren en tipo de uso o complemento. 3 reglas en cascada:

- **Regla 1** (P0019): Misma puerta, diferente tipo de uso → escoge por CIIU. **Ya migrada a Redshift.**
- **Regla 2** (P0020): Misma puerta, diferente complemento → puede generar nuevas direcciones. La más compleja.
- **Regla 3** (P0021): Diferencia en vía generadora → usa lat/long y diccionario de vía.

Archivos clave:
- `src/teradata/Unificacion.sql` — DDL + SPs (311KB, contiene PRO_Unifi_MOTOR_TMP con 6,220 líneas)
- `docs/funcional/documento_funcional_v1.md` — Lógica de negocio de las 3 reglas
- `docs/tecnico/modelo_datos.md` — Modelo de datos con explicaciones por tabla
- `docs/tecnico/mapeo_escenarios_codigo.md` — Mapeo regla/escenario ↔ líneas de código
- `data/mock/` — Datos de prueba (19 personas, 12 escenarios)

### ws-ordenamiento/

Migra el proceso de **Ordenamiento (Scoring de Contactabilidad)**: calcula un score por dato de contacto usando regresión logística con coeficientes Beta. 4 canales: teléfono fijo, celular, email, dirección.

Archivos clave:
- `src/teradata/Ordenamiento.sql` — DDL + SPs cursor
- `data/parametros/Caracteristicas.txt` — 133KB, ~160 sentencias SQL ejecutadas dinámicamente
- `docs/tecnico/analisis_scripts.md` — Análisis del modelo de scoring

## Arquitectura objetivo

```
COBOL (ICBDIR) → EDF (Spark/Scala) → REDSHIFT (SQL) → DB2 (Online)
                  Ingesta +            Unificación
                  Estandarización      Ordenamiento
                  (Curation)           Cálculo + Batch
```

## Convenciones de código Teradata

- `_111` = Setup (creación tablas/vistas)
- `_120` = Carga de datos
- `_130` = Transformación principal (lógica de negocio)
- `_140` = Exportación/resultado
- `.TPT` = Teradata Parallel Transporter
- `.BTQ` = BTEQ script

## Tecnologías

- **Origen**: Teradata SQL + UDFs en C + COBOL + Control-M
- **Destino**: Amazon Redshift (SQL), EDF/Spark (Scala), Lambda (orquestación)
- **Herramientas de migración**: Kiro CLI, AWS Q Transform Custom (en evaluación)
