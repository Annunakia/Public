# MT-EXP-005-MAP-RECONOCER

Migración del sistema **Reconocer** de Experian Colombia: procesamiento de ~65-70M registros de datos de contacto (direcciones, teléfonos, emails) desde Teradata hacia AWS (EDF + Redshift).

---

## Navegación rápida

### Construcción técnica (migración)

| Workspace | Proceso | Estado |
|-----------|---------|--------|
| [ws-unificacion/](ws-unificacion/) | Unificación de direcciones (3 reglas, Padre-Hijo) | Regla 1 migrada, Reglas 2-3 pendientes |
| [ws-ordenamiento/](ws-ordenamiento/) | Scoring de contactabilidad (4 canales, regresión logística) | Entendimiento 80%, migración pendiente |

### Documentación transversal

| Carpeta | Contenido |
|---------|-----------|
| [proyecto/](proyecto/) | Arquitectura, decisiones, gestión, orquestación, metodología |
| [proyecto/comunicaciones/](proyecto/comunicaciones/) | Comunicaciones transversales (workshops, reuniones generales) |
| [proyecto/entregables/](proyecto/entregables/) | Archivos binarios y multimedia (Excel, VTT) |
| [proyecto/gestion/](proyecto/gestion/) | Reuniones, compromisos, plan de trabajo, avance |
| [proyecto/metodologia/](proyecto/metodologia/) | Lecciones aprendidas, comparativas de herramientas |
| [proyecto/orquestacion/](proyecto/orquestacion/) | Control-M, framework batch, orquestación de procesos |
| [proyecto/preventa/](proyecto/preventa/) | Documentos de preventa centralizados (contexto, fases, riesgos) |

### Código fuente original (solo lectura)

| Carpeta | Contenido |
|---------|-----------|
| [Experian Reconocer/](Experian%20Reconocer/) | Dump original: scripts Teradata, UDFs en C, DDLs |

### Preventa (no modificar)

| Carpeta | Contenido |
|---------|-----------|
| [MT-Comercial - Preventa/](MT-Comercial%20-%20Preventa/) | Framework de preventa Macondotek + proyectos comerciales |

---

## Arquitectura de migración

```
COBOL (ICBDIR)  →  EDF Pipeline  →  REDSHIFT  →  DB2
                   (Spark/Scala)     (SQL)         (Online)
                   Ingesta +         Unificación
                   Estandarización   Ordenamiento
                                     Cálculo
```

- **EDF**: Ingesta + Estandarización (8 etapas) en etapa Curation
- **Redshift**: Unificación + Ordenamiento + Cálculo + Batch
- **DB2**: Servicio en línea (consulta)

## Deadlines

- Batch: octubre 2026
- Servicio en línea: noviembre 2026
- Dependencia crítica: IFR (agosto 2026)
