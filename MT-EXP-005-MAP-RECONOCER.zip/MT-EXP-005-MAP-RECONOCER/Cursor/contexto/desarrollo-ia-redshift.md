---
inclusion: auto
---

# Desarrollo Asistido por IA en Proyectos Redshift/XPM

> Steering agnóstico de proyecto. Lecciones aprendidas usando Kiro y Cursor
> para desarrollar sobre Amazon Redshift con datos XPM. Aplica a cualquier
> proyecto que use IA para generar SQL, scripts o documentación sobre Redshift.

---

## 1. Errores Comunes de la IA con Redshift

La IA tiende a generar SQL PostgreSQL puro. Estos son los errores más frecuentes:

| Error | Qué genera la IA | Qué es correcto en Redshift |
|-------|------------------|----------------------------|
| CTEs recursivos | `WITH RECURSIVE cte AS (...)` | No soportado — usar JOINs iterativos o tablas temporales |
| LATERAL JOIN | `FROM tabla, LATERAL (...)` | No soportado — usar subqueries correlacionados |
| ON CONFLICT | `INSERT ... ON CONFLICT DO UPDATE` | No soportado — usar `MERGE` o `DELETE + INSERT` |
| Arrays | `ARRAY[1,2,3]`, `unnest()` | No soportado — usar SUPER type o tablas auxiliares |
| JSONB | `column->>'key'` | Usar `JSON_EXTRACT_PATH_TEXT()` o SUPER type |
| SERIAL | `id SERIAL PRIMARY KEY` | Usar `id BIGINT IDENTITY(1,1)` |
| BOOLEAN en WHERE | `WHERE flag` | Usar `WHERE flag = TRUE` (más explícito) |
| CREATE ROLE IF NOT EXISTS | Sintaxis PostgreSQL | No existe en Redshift — verificar en `pg_roles` primero |
| GRANT en funciones | `GRANT EXECUTE ON FUNCTION schema.func(args)` | Redshift requiere firma completa con tipos |

### Prompt correctivo sugerido

Incluir en el steering o como contexto inicial:

> "Genera SQL compatible con Amazon Redshift (no PostgreSQL puro).
> No uses CTEs recursivos, LATERAL JOIN, ON CONFLICT, arrays nativos ni JSONB.
> Usa IDENTITY en vez de SERIAL. Usa MERGE en vez de ON CONFLICT."

---

## 2. Cómo Estructurar Steering Files Efectivos

### Principios que funcionaron

1. **Un archivo por dominio** — no mezclar modelo de datos con seguridad con deploy
2. **Inclusión condicional** — usar `fileMatch` para SQL, `manual` para deploy, `auto` para contexto base
3. **Reglas de validación al final** — la IA las usa como checklist antes de responder
4. **Ejemplos SQL reales** — la IA replica patrones mejor que instrucciones abstractas
5. **Tamaño controlado** — 100-250 líneas por archivo para no saturar el contexto

### Estructura recomendada de un steering file

```markdown
---
inclusion: auto|manual|fileMatch
fileMatchPattern: "*.sql"  # solo si fileMatch
---

# Título descriptivo

> Una línea explicando qué es y cuándo aplica.

## Secciones con contenido concreto
- Tablas, diagramas, ejemplos SQL
- Patrones correctos vs incorrectos (✅ / ❌)

## Reglas de Validación para el Agente IA
1. Regla concreta y verificable
2. Otra regla
```

### Qué NO poner en steering

- Código completo de implementación (va en specs o src/)
- Credenciales o endpoints reales de producción
- Instrucciones paso a paso de un deploy específico (va en docs/)

---

## 3. Specs que Funcionaron

### Patrón exitoso: Spec con requirements → design → tasks

```
.kiro/specs/mi-feature/
├── requirements.md    ← Qué se necesita (funcional)
├── design.md          ← Cómo se implementa (técnico)
└── tasks.md           ← Pasos de implementación (checklist)
```

### Lo que funcionó bien

- **Requirements con criterios de aceptación claros** — la IA genera tests que validan exactamente eso
- **Design con SQL de ejemplo** — la IA replica el patrón en vez de inventar
- **Tasks con orden de dependencia** — la IA respeta el orden y no salta pasos
- **Referencias a archivos existentes** con `#[[file:src/sql/dev/02_funciones.sql]]` — la IA lee el archivo y mantiene consistencia

### Lo que NO funcionó

- Specs vagos ("implementar seguridad") — la IA genera soluciones genéricas
- Tasks sin orden de dependencia — la IA ejecuta en orden arbitrario
- Design sin ejemplos SQL — la IA genera PostgreSQL en vez de Redshift

---

## 4. Hooks Útiles para Proyectos Redshift

### Validar SQL al guardar

```json
{
  "name": "Validate SQL Syntax",
  "version": "1.0.0",
  "when": {
    "type": "fileEdited",
    "patterns": ["*.sql"]
  },
  "then": {
    "type": "askAgent",
    "prompt": "Revisa que este archivo SQL use sintaxis compatible con Amazon Redshift (no PostgreSQL puro). Verifica: no CTEs recursivos, no LATERAL JOIN, no ON CONFLICT, columnas con puntos entre comillas dobles, JOINs con relationalizelastupdate."
  }
}
```

### Verificar rollback al crear script SQL

```json
{
  "name": "Check Rollback Exists",
  "version": "1.0.0",
  "when": {
    "type": "fileCreated",
    "patterns": ["src/sql/**/[0-9]*.sql"]
  },
  "then": {
    "type": "askAgent",
    "prompt": "Se creó un nuevo script SQL. Verifica que exista su correspondiente script de rollback en la carpeta rev-sql/ con el prefijo correcto y operaciones inversas (DROP IF EXISTS, REVOKE, etc.)."
  }
}
```

---

## 5. Contexto que la IA Necesita para Redshift/XPM

### Mínimo viable (siempre incluir)

1. **Motor:** Amazon Redshift (Serverless o RA3)
2. **Puerto:** 5440 (no 5439)
3. **Schema principal:** `edf_views` (tablas XPM)
4. **Regla de JOIN:** siempre incluir `relationalizelastupdate`
5. **Columnas con puntos:** requieren comillas dobles

### Contexto adicional según tarea

| Tarea | Contexto necesario |
|-------|-------------------|
| Crear vista | DDL de la tabla base + funciones disponibles |
| Crear función | Funciones existentes (para mantener consistencia) |
| Permisos | Roles existentes + matriz de permisos actual |
| Deploy | Estándar de paquete + deploy_order.par |
| Testing | Patrones de SET SESSION AUTHORIZATION |

---

## 6. Patrones de Testing con IA

### SET SESSION AUTHORIZATION para validar permisos

```sql
-- Simular acceso como analista
SET SESSION AUTHORIZATION analyst_test;
SELECT * FROM mi_schema.mi_vista LIMIT 5;
-- Esperado: datos visibles (o enmascarados según el caso)
RESET SESSION AUTHORIZATION;

-- Simular acceso denegado
SET SESSION AUTHORIZATION analyst_test;
SELECT * FROM edf_views.xpm LIMIT 1;
-- Esperado: ERROR: permission denied for schema edf_views
RESET SESSION AUTHORIZATION;
```

### Patrón de test de determinismo

```sql
-- Verificar que la misma entrada produce la misma salida
SELECT
    v1.campo AS run1,
    v2.campo AS run2,
    CASE WHEN v1.campo = v2.campo THEN 'PASS' ELSE 'FAIL' END AS determinismo
FROM mi_vista v1
JOIN mi_vista v2 ON v1.id = v2.id
LIMIT 10;
```

---

## 7. Workflow Recomendado con IA

```
1. Dar contexto (steering auto + modelo de datos)
2. Definir spec (requirements → design → tasks)
3. Implementar por tasks (la IA ejecuta una a una)
4. Validar cada task (tests SQL + diagnostics)
5. Empaquetar (generar zip con deploy_order.par)
6. Documentar (la IA genera docs basándose en lo implementado)
```

> La IA es más efectiva cuando tiene ejemplos concretos que cuando recibe
> instrucciones abstractas. Siempre incluir SQL de referencia.

---

## Reglas de Validación para el Agente IA

1. Generar SQL compatible con Redshift, no PostgreSQL puro
2. Siempre incluir `relationalizelastupdate` en JOINs entre tablas XPM
3. Columnas con puntos entre comillas dobles
4. Todo script SQL debe tener rollback correspondiente
5. Usar patrones existentes del proyecto antes de inventar nuevos
6. Verificar encoding, DISTKEY y SORTKEY al crear tablas
