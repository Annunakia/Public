---
inclusion: fileMatch
fileMatchPattern: "*.sql"
---

# Patrones SQL para Redshift sobre Tablas XPM

> Steering agnóstico de proyecto. Patrones SQL específicos para Amazon Redshift
> al trabajar con tablas XPM generadas por Glue Rationalize.
> Se activa automáticamente al editar archivos .sql.

---

## 1. Sintaxis Redshift vs PostgreSQL

Redshift es compatible con PostgreSQL pero tiene diferencias importantes:

| Característica | PostgreSQL | Redshift |
|---------------|-----------|----------|
| CTEs recursivos | ✅ Soportado | ❌ No soportado |
| LATERAL JOIN | ✅ Soportado | ❌ No soportado |
| Arrays nativos | ✅ Soportado | ❌ No soportado |
| JSONB | ✅ Soportado | ⚠️ Solo SUPER type (limitado) |
| CREATE OR REPLACE VIEW | ✅ Soportado | ✅ Soportado |
| CREATE OR REPLACE FUNCTION | ✅ Soportado | ✅ Soportado |
| IF NOT EXISTS (CREATE TABLE) | ✅ Soportado | ✅ Soportado |
| IF NOT EXISTS (CREATE SCHEMA) | ✅ Soportado | ✅ Soportado |
| IDENTITY columns | ✅ SERIAL | ✅ IDENTITY(seed, step) |
| UPSERT | ✅ ON CONFLICT | ❌ Usar MERGE o DELETE+INSERT |
| Window functions | ✅ Completo | ✅ Completo |
| Materialized views | ✅ Completo | ⚠️ Sin masking policies, REFRESH manual |

---

## 2. Columnas con Dot Notation (Rationalize)

```sql
-- ❌ INCORRECTO — Redshift interpreta puntos como schema.tabla.columna
SELECT bestaccounts.val.accountnumber FROM edf_views.xpm_bestaccounts;

-- ✅ CORRECTO — comillas dobles escapan el nombre completo
SELECT "bestaccounts.val.accountnumber" FROM edf_views.xpm_bestaccounts;

-- ✅ CORRECTO — con alias para legibilidad
SELECT
    "bestaccounts.val.accountnumber" AS accountnumber,
    "bestaccounts.val.accounttype"   AS accounttype
FROM edf_views.xpm_bestaccounts;

-- ✅ CORRECTO — CAST explícito cuando se pasa a funciones
SELECT ddm_functions.hash_modulo("bestaccounts.val.personidnumber"::VARCHAR, 15)
FROM edf_views.xpm_bestaccounts;
```

---

## 3. JOINs entre Tablas XPM

```sql
-- ✅ CORRECTO — clave compuesta completa
SELECT x.*, ba.*
FROM edf_views.xpm x
JOIN edf_views.xpm_bestaccounts ba
  ON x.id = ba.id
 AND x.relationalizelastupdate = ba.relationalizelastupdate;

-- ❌ INCORRECTO — falta relationalizelastupdate (produce duplicados silenciosos)
SELECT x.*, ba.*
FROM edf_views.xpm x
JOIN edf_views.xpm_bestaccounts ba
  ON x.id = ba.id;

-- ✅ JOIN multinivel (Nivel 0 → 1 → 2)
SELECT
    x."bestname.firstname",
    loc."location.val.stratum",
    ci."location.val.contactinformations.val.contactasreported"
FROM edf_views.xpm x
JOIN edf_views.xpm_location loc
  ON x.id = loc.id
 AND x.relationalizelastupdate = loc.relationalizelastupdate
JOIN edf_views.xpm_location_val_contactinformations ci
  ON loc.id = ci.id
 AND loc."index" = ci."index"
 AND loc.relationalizelastupdate = ci.relationalizelastupdate;
```

---

## 4. Funciones Nativas Útiles de Redshift

### Hash y criptografía
```sql
-- SHA2 (256 bits) — retorna hex string de 64 caracteres
SELECT SHA2('texto', 256);

-- STRTOL — convierte hex string a BIGINT
SELECT STRTOL('1a2b3c', 16);  -- retorna 1715004

-- Combinación: hash determinístico de longitud fija
SELECT LPAD(
    (ABS(STRTOL(LEFT(SHA2('valor', 256), 15), 16)) % POW(10, 15)::BIGINT)::VARCHAR,
    15, '0'
);
```

### Texto
```sql
-- SOUNDEX — código fonético (útil para pseudonimización)
SELECT SOUNDEX('VICTOR');  -- retorna 'V236'

-- TRANSLATE — sustitución carácter a carácter
SELECT TRANSLATE('3101234567', '0123456789', '9876543210');  -- '6898765432'

-- REGEXP_REPLACE
SELECT REGEXP_REPLACE('Juan Carlos 123', '[A-Za-z]', 'X');  -- 'XXXX XXXXXXX 123'
```

### Fechas (epoch → legible)
```sql
-- Epoch milisegundos → TIMESTAMP
SELECT TIMESTAMP 'epoch' + (1711929600000 / 1000) * INTERVAL '1 second';

-- Epoch días → DATE
SELECT DATE '1970-01-01' + 19814 * INTERVAL '1 day';

-- GETDATE() — timestamp actual en Redshift
SELECT GETDATE();

-- DATEADD / DATEDIFF
SELECT DATEADD(day, -7, GETDATE());
SELECT DATEDIFF(seconds, starttime, endtime) FROM stl_query LIMIT 1;
```

---

## 5. Patrones de Idempotencia

```sql
-- Schemas
CREATE SCHEMA IF NOT EXISTS mi_schema;

-- Tablas
CREATE TABLE IF NOT EXISTS mi_schema.mi_tabla (
    id BIGINT ENCODE AZ64,
    nombre VARCHAR(256) ENCODE ZSTD
);

-- Vistas (siempre idempotente con OR REPLACE)
CREATE OR REPLACE VIEW mi_schema.mi_vista AS
SELECT id, nombre FROM mi_schema.mi_tabla;

-- Funciones (siempre idempotente con OR REPLACE)
CREATE OR REPLACE FUNCTION mi_schema.mi_funcion(val VARCHAR)
RETURNS VARCHAR
STABLE AS $
    SELECT UPPER($1)
$ LANGUAGE SQL;

-- Roles (NO tienen IF NOT EXISTS en Redshift — verificar antes)
-- Usar bloque DO o verificar en pg_roles
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mi_rol') THEN
        EXECUTE 'CREATE ROLE mi_rol';
    END IF;
END $$;
```

---

## 6. Anti-Patterns en Redshift

### ❌ SELECT * en tablas anchas
```sql
-- ❌ xpm_bestaccounts tiene 80+ columnas — escanea todo
SELECT * FROM edf_views.xpm_bestaccounts LIMIT 10;

-- ✅ Proyectar solo columnas necesarias
SELECT "bestaccounts.val.accountnumber", "bestaccounts.val.accounttype"
FROM edf_views.xpm_bestaccounts LIMIT 10;
```

### ❌ Funciones en WHERE (impide pushdown de SORTKEY)
```sql
-- ❌ No aprovecha SORTKEY
WHERE SHA2("bestaccounts.val.personidnumber", 256) = 'abc123'

-- ✅ Filtrar por columnas nativas
WHERE "bestaccounts.val.cutoffdate" >= 20250101
```

### ❌ CROSS JOIN implícito por falta de relationalizelastupdate
```sql
-- ❌ Produce N×M filas si hay múltiples cargues
JOIN edf_views.xpm_bestaccounts ba ON x.id = ba.id

-- ✅ Clave compuesta completa
JOIN edf_views.xpm_bestaccounts ba
  ON x.id = ba.id
 AND x.relationalizelastupdate = ba.relationalizelastupdate
```

### ❌ ORDER BY sin LIMIT en tablas grandes
```sql
-- ❌ Ordena millones de filas en memoria
SELECT * FROM edf_views.xpm ORDER BY "bestname.firstname";

-- ✅ Siempre con LIMIT o en subquery acotada
SELECT * FROM edf_views.xpm
WHERE relationalizelastupdate >= 20250101
ORDER BY "bestname.firstname"
LIMIT 100;
```

---

## 7. Monitoreo de Queries

```sql
-- Queries lentas (últimas 24h, >10 segundos)
SELECT q.query, u.usename, q.starttime,
       DATEDIFF(seconds, q.starttime, q.endtime) AS duration_sec,
       LEFT(q.querytxt, 200) AS query_preview
FROM stl_query q
JOIN pg_user u ON q.userid = u.usesysid
WHERE q.starttime >= DATEADD(day, -1, GETDATE())
  AND DATEDIFF(seconds, q.starttime, q.endtime) > 10
ORDER BY duration_sec DESC
LIMIT 20;

-- Verificar encoding y distribución de una tabla
SELECT "column", type, encoding, distkey, sortkey
FROM pg_table_def
WHERE schemaname = 'edf_views' AND tablename = 'xpm'
ORDER BY "column";

-- Verificar estadísticas (post-ANALYZE)
SELECT schemaname, tablename, encoded, diststyle, sortkey1
FROM svv_table_info
WHERE schemaname = 'edf_views'
ORDER BY tablename;
```

---

## 8. Encoding Recomendado por Tipo

| Tipo de dato | Encoding | Razón |
|-------------|----------|-------|
| BIGINT | AZ64 | Compresión nativa optimizada para enteros |
| INT | AZ64 | Consistente con BIGINT |
| VARCHAR(<256) | ZSTD | Mejor ratio para strings cortos |
| VARCHAR(16383) | LZO | Mejor para strings largos |
| VARCHAR baja cardinalidad | BYTEDICT | Pocos valores distintos |
| BOOLEAN | RAW | Ya es 1 byte |
| FLOAT8 | RAW | Compresión no beneficia floats |

---

## Reglas de Validación para el Agente IA

1. Usar sintaxis Redshift, no PostgreSQL puro (sin CTEs recursivos, sin LATERAL, sin ON CONFLICT)
2. Columnas con puntos SIEMPRE entre comillas dobles
3. JOINs entre tablas XPM SIEMPRE con `relationalizelastupdate`
4. No usar `SELECT *` en tablas anchas — proyectar columnas
5. No usar funciones en cláusulas WHERE sobre columnas con SORTKEY
6. Scripts deben ser idempotentes: `CREATE OR REPLACE`, `IF NOT EXISTS`
7. Incluir `ANALYZE` después de cargas masivas
