---
inclusion: manual
---

# Estándar de Paquete de Despliegue SQL para Redshift

> Steering agnóstico de proyecto. Define el estándar para empaquetar y desplegar
> scripts SQL en Amazon Redshift. Aplica a cualquier proyecto que despliegue
> objetos SQL (schemas, tablas, vistas, funciones, permisos) en el cluster.

---

## 1. Estructura del Paquete (.zip)

```
PAQUETE_XXXX/
├── deploy_order.par                    # Orden de ejecución (OBLIGATORIO)
├── Documentacion/
│   ├── GUIA_INSTALACION.md            # Prerequisitos y pasos de despliegue
│   ├── INDICE_COMPLETO.md             # Descripción de cada archivo incluido
│   └── PAQUETE_XXXX.yml               # Metadata del paquete (versión, SHA256)
├── sql/
│   ├── 01_<nombre_objeto>.sql         # Scripts en orden de ejecución
│   ├── 02_<nombre_objeto>.sql
│   └── NN_<nombre_objeto>.sql
└── rev-sql/
    ├── NN_rollback_<nombre_objeto>.sql # Scripts de rollback en orden INVERSO
    ├── 02_rollback_<nombre_objeto>.sql
    └── 01_rollback_<nombre_objeto>.sql
```

---

## 2. Archivo deploy_order.par

Define el orden exacto de ejecución. Formato:

```
# Deploy Order - PAQUETE_XXXX
# Ambiente: [develop|stage|qa|prod]
# Fecha: YYYY-MM-DD
# Autor: <nombre>

[SQL]
01_schemas_roles.sql
02_funciones.sql
03_tablas.sql
04_vistas.sql
05_permisos.sql

[REV-SQL]
05_rollback_permisos.sql
04_rollback_vistas.sql
03_rollback_tablas.sql
02_rollback_funciones.sql
01_rollback_schemas_roles.sql
```

---

## 3. Convenciones de Nomenclatura

### Prefijos numéricos obligatorios

Scripts SQL van numerados `01_` a `NN_` en orden de dependencia.
Scripts rev-sql van numerados en orden INVERSO al de sql.

### Orden estándar de dependencias

```
01_ → Schemas y roles (base — siempre primero)
02_ → Funciones / UDFs
03_ → Tablas (DDL)
04_ → Vistas (dependen de tablas y funciones)
05_ → Permisos (GRANTs — siempre último)
```

> El número define el orden de ejecución. No cambiar sin actualizar `deploy_order.par`.

---

## 4. Contenido Mínimo de PAQUETE_XXXX.yml

```yaml
proceso: PAQUETE_XXXX
descripcion: "Descripción del cambio"
version: "1.0.0"
fecha_creacion: "YYYY-MM-DD"
autor: "<nombre>"
ambiente_destino: [develop|stage|qa|prod]
sha256_paquete: "<hash del .zip>"

dependencias:
  - schema: edf_views
    estado: debe_existir

scripts_sql:
  - orden: 1
    archivo: "01_schemas_roles.sql"
    descripcion: "Crea schemas y roles"
    rollback: "01_rollback_schemas_roles.sql"

validaciones_post_deploy:
  - "SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name = 'mi_schema'"
  - "SELECT has_schema_privilege('mi_rol', 'mi_schema', 'USAGE')"
```

---

## 5. Reglas por Ambiente

| Regla | develop | stage/QA | prod |
|-------|---------|----------|------|
| Aprobación previa | No | Revisión técnica | Aprobación formal |
| Datos de prueba en scripts | Permitido | No | No |
| Rollback validado | Recomendado | Obligatorio | Validado en QA |
| SHA256 verificado | No | Recomendado | Obligatorio |
| Ventana de mantenimiento | No | Recomendada | Obligatoria |
| Usuario de ejecución | Desarrollo | Operador | DBA con MFA |

---

## 6. Proceso de Despliegue (CLI)

```bash
# 1. Descomprimir paquete
unzip PAQUETE_XXXX.zip -d /tmp/deploy/

# 2. Validar estructura
ls /tmp/deploy/PAQUETE_XXXX/sql/
ls /tmp/deploy/PAQUETE_XXXX/rev-sql/
cat /tmp/deploy/PAQUETE_XXXX/deploy_order.par

# 3. Ejecutar scripts en orden definido en deploy_order.par [SQL]
psql -h <host> -U <user> -d <database> -f /tmp/deploy/PAQUETE_XXXX/sql/01_schemas_roles.sql
psql -h <host> -U <user> -d <database> -f /tmp/deploy/PAQUETE_XXXX/sql/02_funciones.sql
# ... continuar en orden

# 4. Validar post-deploy
psql -h <host> -U <user> -d <database> -c "<validacion del .yml>"
```

---

## 7. Proceso de Rollback (CLI)

```bash
# Ejecutar scripts rev-sql en orden definido en deploy_order.par [REV-SQL]
psql -h <host> -U <user> -d <database> -f /tmp/deploy/PAQUETE_XXXX/rev-sql/05_rollback_permisos.sql
psql -h <host> -U <user> -d <database> -f /tmp/deploy/PAQUETE_XXXX/rev-sql/04_rollback_vistas.sql
# ... continuar en orden inverso
```

---

## 8. Despliegue por Unidades (Avanzado)

Para paquetes grandes, dividir en unidades independientes con rollback granular:

```
Unidad 1: Infraestructura Base (schemas, roles)
Unidad 2: Funciones y tablas auxiliares
Unidad 3: Objetos principales (vistas, tablas de negocio)
Unidad 4: Permisos finales
```

Cada unidad tiene:
- Scripts SQL propios
- Validación automática post-ejecución
- Rollback independiente

```powershell
# Ejemplo de script orquestador
.\deploy_by_units.ps1 -Unit 2          # Solo unidad 2
.\deploy_by_units.ps1 -RollbackUnit 3  # Rollback solo unidad 3
```

---

## 9. Checklist Pre-Deploy

- [ ] `deploy_order.par` actualizado con todos los scripts
- [ ] Todos los scripts en `sql/` tienen su correspondiente en `rev-sql/`
- [ ] Scripts son idempotentes (`CREATE OR REPLACE`, `IF NOT EXISTS`, `IF EXISTS` en DROP)
- [ ] No hay credenciales hardcodeadas en ningún script
- [ ] Datos de prueba excluidos (si no es develop)
- [ ] SHA256 del .zip calculado y registrado en .yml
- [ ] Rollback probado en ambiente inferior
- [ ] Backup del estado actual documentado

---

## 10. Checklist Post-Deploy

- [ ] Validaciones del .yml ejecutadas y pasando
- [ ] Schemas/tablas/vistas/funciones existen
- [ ] Permisos verificados por rol
- [ ] Queries de prueba ejecutados exitosamente
- [ ] Monitoreo activo las primeras 24 horas

---

## 11. Reglas Críticas

- NUNCA ejecutar scripts fuera del orden definido en `deploy_order.par`
- NUNCA omitir la carpeta `rev-sql` — todo despliegue debe tener rollback
- NUNCA hardcodear credenciales en ningún script del paquete
- NUNCA incluir `DROP SCHEMA` o `DROP TABLE` sin `IF EXISTS` en rev-sql
- Los scripts SQL deben ser idempotentes cuando sea posible
- NO usar Terraform para despliegue de objetos SQL — solo SQL y CLI

---

## Reglas de Validación para el Agente IA

1. Todo script SQL generado debe tener su correspondiente rollback en rev-sql
2. Usar prefijos numéricos en orden de dependencia
3. Incluir `deploy_order.par` con secciones [SQL] y [REV-SQL]
4. Scripts deben ser idempotentes
5. No incluir datos de prueba en paquetes para stage/qa/prod
6. Incluir validaciones post-deploy en el .yml
