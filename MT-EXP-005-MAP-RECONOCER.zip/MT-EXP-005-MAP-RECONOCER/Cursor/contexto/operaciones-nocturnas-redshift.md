---
inclusion: manual
---

# Operaciones Nocturnas y Mantenimiento en Redshift

> Steering agnóstico de proyecto. Documenta el impacto de las operaciones nocturnas
> del pipeline de ingesta sobre objetos SQL (vistas, permisos, policies) y patrones
> de mantenimiento para Amazon Redshift.

---

## 1. Impacto por Tipo de Operación del Pipeline

El pipeline de ingesta (Glue/Airflow) recarga datos en `edf_views` cada noche.
El tipo de operación determina el impacto sobre objetos dependientes:

| Operación | Vistas (CREATE VIEW) | GRANTs por tabla | Masking Policies (ATTACH) | Estadísticas |
|-----------|---------------------|-----------------|--------------------------|-------------|
| `TRUNCATE + COPY` | ✅ Sin impacto | ✅ Sin impacto | ✅ Sin impacto | ⚠️ Requiere ANALYZE |
| `DELETE + INSERT` | ✅ Sin impacto | ✅ Sin impacto | ✅ Sin impacto | ⚠️ Requiere ANALYZE |
| `DROP + CREATE` (misma estructura) | ⚠️ Se invalida temporalmente | ❌ Se pierden | ❌ Se pierden | ⚠️ Requiere ANALYZE |
| `DROP + CREATE` (estructura cambia) | ❌ Se rompe | ❌ Se pierden | ❌ Se pierden | ⚠️ Requiere ANALYZE |
| `INSERT` incremental | ✅ Sin impacto | ✅ Sin impacto | ✅ Sin impacto | ⚠️ Requiere ANALYZE |

> **Recomendación:** Preferir `TRUNCATE + COPY` sobre `DROP + CREATE`.
> Si se usa DROP+CREATE, agregar paso post-carga para restaurar dependencias.

---

## 2. Qué Sobrevive y Qué No al DROP+CREATE

| Componente | ¿Sobrevive al DROP+CREATE? | Razón |
|------------|---------------------------|-------|
| Vistas (`CREATE VIEW`) | ⚠️ Se invalida, se resuelve si la estructura es igual | La vista referencia la tabla. Al dropear, queda rota. Al recrear con misma estructura, se resuelve |
| Masking policies (ATTACH) | ❌ Se pierden | Los ATTACH están vinculados a la tabla física. Las policies (CREATE) sobreviven, los ATTACH no |
| GRANTs por tabla | ❌ Se pierden | Los permisos `GRANT SELECT ON tabla` se eliminan con la tabla |
| GRANTs por schema | ✅ Sobreviven | `GRANT USAGE ON SCHEMA` no depende de tablas individuales |
| DEFAULT PRIVILEGES | ✅ Sobreviven | Se aplican automáticamente a tablas nuevas en el schema |
| Funciones (UDF) | ✅ Sin impacto | Objetos independientes en otro schema |
| Tablas auxiliares (lookup, config) | ✅ Sin impacto | Objetos independientes |
| Roles | ✅ Sin impacto | Objetos a nivel de cluster |

---

## 3. Patrón de Restauración Post-Carga

Si el pipeline usa DROP+CREATE, agregar estos pasos al final del DAG de Airflow:

### Paso 1: Re-ejecutar GRANTs por tabla

```sql
-- Re-otorgar permisos que se perdieron con el DROP
GRANT SELECT ON edf_views.xpm TO ROLE rol_admin;
GRANT SELECT ON edf_views.xpm_bestaccounts TO ROLE rol_admin;
-- ... para cada tabla recargada
```

### Paso 2: Re-adjuntar masking policies (si aplica)

```sql
-- Re-ejecutar el script de ATTACH policies
-- psql -f sql/attach_masking_policies.sql
```

### Paso 3: Verificar vistas

```sql
-- Verificar que las vistas siguen válidas
SELECT table_schema, table_name
FROM information_schema.views
WHERE table_schema = 'mi_schema';

-- Test rápido
SELECT COUNT(*) FROM mi_schema.mi_vista LIMIT 1;
```

### Paso 4: Actualizar estadísticas

```sql
ANALYZE edf_views.xpm;
ANALYZE edf_views.xpm_bestaccounts;
-- ... para cada tabla recargada
```

### Alternativa: Usar DEFAULT PRIVILEGES

```sql
-- Configurar una vez — aplica automáticamente a tablas nuevas
ALTER DEFAULT PRIVILEGES FOR USER pipeline_user IN SCHEMA edf_views
    GRANT SELECT ON TABLES TO ROLE rol_admin;

ALTER DEFAULT PRIVILEGES FOR USER pipeline_user IN SCHEMA edf_views
    GRANT SELECT ON TABLES TO ROLE rol_analyst;
```

> Con DEFAULT PRIVILEGES, los GRANTs se aplican automáticamente cuando el
> `pipeline_user` crea tablas nuevas. No requiere paso post-carga.

---

## 4. ANALYZE Post-Carga

Después de cargas masivas, las estadísticas del optimizador quedan desactualizadas.
Esto puede degradar el rendimiento de queries significativamente.

```sql
-- ANALYZE por tabla (recomendado — más rápido)
ANALYZE edf_views.xpm;
ANALYZE edf_views.xpm_bestaccounts;

-- ANALYZE de todo el schema (más lento pero completo)
-- No existe comando directo — iterar por tabla:
SELECT 'ANALYZE edf_views.' || tablename || ';'
FROM pg_tables
WHERE schemaname = 'edf_views';
```

> Incluir ANALYZE como paso obligatorio en el DAG de Airflow post-carga.

---

## 5. Monitoreo Post-Carga

### Queries de verificación

```sql
-- Verificar que las tablas tienen datos
SELECT schemaname, tablename, tbl_rows
FROM svv_table_info
WHERE schemaname = 'edf_views'
ORDER BY tablename;

-- Verificar que las vistas son consultables
SELECT table_schema, table_name
FROM information_schema.views
WHERE table_schema IN ('mi_schema')
ORDER BY table_name;

-- Verificar permisos post-carga
SELECT
    schemaname, tablename,
    has_table_privilege('usuario_test', schemaname || '.' || tablename, 'SELECT') AS has_select
FROM pg_tables
WHERE schemaname = 'edf_views'
ORDER BY tablename;

-- Verificar masking policies adjuntas (si aplica)
SELECT policy_name, schema_name, table_name, input_columns, grantee
FROM svv_attached_masking_policy
WHERE schema_name = 'edf_views'
ORDER BY table_name, priority;
```

### Alertas recomendadas

| Alerta | Condición | Acción |
|--------|----------|--------|
| Tabla vacía post-carga | `tbl_rows = 0` en `svv_table_info` | Investigar pipeline |
| Vista rota | `SELECT COUNT(*) FROM vista` falla | Recrear vista |
| Permisos perdidos | `has_table_privilege = false` | Re-ejecutar GRANTs |
| Policies desadjuntadas | `COUNT(svv_attached_masking_policy) < esperado` | Re-ejecutar ATTACH |
| Query lenta post-carga | `duration > 30s` en `stl_query` | Ejecutar ANALYZE |

---

## 6. Tareas de Mantenimiento Periódico

### Semanal

- [ ] Revisar queries lentas sobre vistas (`stl_query WHERE duration > 10s`)
- [ ] Verificar que ANALYZE se ejecutó post-carga
- [ ] Revisar logs de acceso no autorizado (si hay auditoría)

### Mensual

- [ ] Verificar encoding y distribución de tablas (`pg_table_def`)
- [ ] Revisar y optimizar queries frecuentes
- [ ] Rotar credenciales de usuarios de servicio
- [ ] Exportar logs de auditoría a S3 (si retención > 90 días)

### Trimestral

- [ ] Revisar y actualizar permisos por rol
- [ ] Evaluar nuevas capacidades de Redshift
- [ ] Revisar costos y optimizar workloads
- [ ] Rotar claves KMS y secretos en Secrets Manager

---

## 7. Concurrency Scaling

Para picos de consultas concurrentes:

```sql
-- Verificar si Concurrency Scaling está habilitado
SELECT * FROM stv_wlm_service_class_config
WHERE service_class >= 6;

-- Monitorear uso de Concurrency Scaling
SELECT service_class, num_queued_queries, num_executing_queries
FROM stv_wlm_service_class_state
WHERE service_class >= 6;
```

> Habilitar Concurrency Scaling en el workgroup para escalar automáticamente
> durante picos de consultas (ej: reportes matutinos post-carga nocturna).

---

## Reglas de Validación para el Agente IA

1. Siempre incluir ANALYZE después de cargas masivas en scripts de pipeline
2. Preferir TRUNCATE+COPY sobre DROP+CREATE para preservar dependencias
3. Si se usa DROP+CREATE, incluir paso de restauración de GRANTs y ATTACHs
4. Considerar DEFAULT PRIVILEGES para automatizar permisos en tablas nuevas
5. Incluir verificación de vistas post-carga en scripts de validación
6. No asumir que las estadísticas están actualizadas después de una carga
