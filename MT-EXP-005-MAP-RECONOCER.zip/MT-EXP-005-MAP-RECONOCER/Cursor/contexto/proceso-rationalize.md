---
inclusion: manual
---

# Proceso Rationalize — AWS Glue sobre XPM

> Steering agnóstico de proyecto. Documenta cómo AWS Glue Relationalize transforma
> el JSON/Avro anidado del XPM en tablas planas en Redshift, y las implicaciones
> prácticas para cualquier proyecto que trabaje con esas tablas.

---

## 1. Qué Hace Rationalize

AWS Glue Relationalize es una transformación PySpark que convierte estructuras JSON anidadas
en un conjunto de tablas relacionales planas. Cada array genera una tabla hija; cada objeto
se aplana como columnas en la tabla padre.

### Flujo

```
Avro (S3 — fuente bureau)
    │
    ▼
Airflow DAG → AWS Glue Job (PySpark)
    │
    │  glueContext.create_dynamic_frame(...)
    │  .relationalize("xpm", s3_temp_path)
    │
    ▼
~20 tablas Parquet (S3 — staging)
    │
    ▼
Redshift COPY → schema edf_views
```

### Reglas de Transformación

| Estructura JSON | Resultado en Redshift | Ejemplo |
|----------------|----------------------|---------|
| Objeto `{}` | Columnas aplanadas en tabla padre con dot notation | `bestname.firstname`, `bestpersonalinformation.age` |
| Array `[]` | Nueva tabla hija con FK (`id` + `relationalizelastupdate`) | `xpm_bestaccounts`, `xpm_disputes` |
| Array dentro de array | Tabla nieta (Nivel 2) con FK (`id` + `index` + `relationalizelastupdate`) | `xpm_location_val_contactinformations` |
| Valor escalar | Columna directa en tabla padre | `xpmversion`, `has_chamberofcommerce` |
| Campo BIGINT en raíz con nombre de sección | Conteo de hijos (NO es FK relacional) | `bestaccounts BIGINT` = cantidad de cuentas |

---

## 2. Convenciones de Nombres Generadas

### Tablas

```
xpm                                          ← Nivel 0 (raíz)
xpm_{seccion}                                ← Nivel 1 (ej: xpm_bestaccounts)
xpm_{seccion}_val_{subseccion}               ← Nivel 2 (ej: xpm_location_val_contactinformations)
xpm_{seccion}_val_{sub}_val_{subsub}         ← Nivel 3+ (raro, pero posible)
```

### Columnas

```
{seccion}.val.{campo}                        ← Nivel 1 (ej: bestaccounts.val.accountnumber)
{seccion}.val.{subseccion}.val.{campo}       ← Nivel 2 (ej: location.val.contactinformations.val.contacttype)
```

> En Redshift, estas columnas con puntos se referencian con comillas dobles:
> `"bestaccounts.val.accountnumber"`, `"location.val.contactinformations.val.contacttype"`

### Campos de control (generados automáticamente)

| Campo | Tipo | Presente en | Generado por |
|-------|------|-------------|-------------|
| `id` | BIGINT | Todas las tablas | Rationalize — surrogate key del perfil raíz |
| `index` | INT | Tablas Nivel 1+ | Rationalize — posición en el array original |
| `relationalizelastupdate` | INT | Todas las tablas | Rationalize — timestamp del cargue incremental |

---

## 3. Gotchas y Lecciones Aprendidas

### 3.1 Columnas con dot notation requieren comillas dobles

```sql
-- ❌ INCORRECTO — Redshift interpreta los puntos como referencia a schema.tabla.columna
SELECT personalinformation.val.personidnumber FROM edf_views.xpm_personalinformation;

-- ✅ CORRECTO — comillas dobles escapan el nombre completo
SELECT "personalinformation.val.personidnumber" FROM edf_views.xpm_personalinformation;
```

> Este es el error #1 más común al trabajar con tablas Rationalize.

### 3.2 Fechas llegan como BIGINT (epoch), no TIMESTAMP

Rationalize preserva los tipos del Avro original. Las fechas son epoch en milisegundos o días:

```sql
-- Convertir epoch (milisegundos) a fecha legible
SELECT
    TIMESTAMP 'epoch' + ("bestaccounts.val.cutoffdate" / 1000) * INTERVAL '1 second'
    AS cutoffdate_readable
FROM edf_views.xpm_bestaccounts
LIMIT 5;

-- O si es epoch en días
SELECT
    DATE '1970-01-01' + "bestaccounts.val.cutoffdate" * INTERVAL '1 day'
FROM edf_views.xpm_bestaccounts;
```

> Verificar la unidad del epoch (milisegundos vs días vs segundos) antes de convertir.

### 3.3 VARCHAR(16383) para secciones no normalizadas

Algunas secciones del JSON no se normalizan en tablas hijas. Llegan como VARCHAR(16383)
serializado en la tabla raíz. No son consultables como columnas individuales.

```sql
-- Esto NO funciona — es un string serializado, no columnas
SELECT sisben.score FROM edf_views.xpm;  -- ERROR

-- Esto es lo que hay — un blob de texto
SELECT sisben FROM edf_views.xpm WHERE sisben IS NOT NULL LIMIT 1;
-- Retorna: '{"score": 45, "level": "B2", ...}'
```

Secciones conocidas como VARCHAR(16383): `sisben`, `alerts`, `judicialinformation`,
`bureauattributes`, `inquiryfootprints`, `globalindebtedness`, `bureaumodels`.

### 3.4 DISTSTYLE y SORTKEY no los define Glue

Glue Rationalize genera las tablas sin DISTKEY ni SORTKEY. Redshift asigna DISTSTYLE AUTO
por defecto. Para optimizar:

- Tabla raíz: `DISTSTYLE KEY DISTKEY(id) SORTKEY(relationalizelastupdate)`
- Tablas hijas: dejar `DISTSTYLE AUTO` (Redshift optimiza según uso)

### 3.5 Encoding no lo define Glue

Las tablas cargadas con COPY heredan encoding por defecto. Para optimizar post-carga:

```sql
-- Verificar encoding actual
SELECT column, type, encoding
FROM pg_table_def
WHERE schemaname = 'edf_views' AND tablename = 'xpm_bestaccounts'
ORDER BY column;
```

### 3.6 Tablas Nivel 2 tienen nombres muy largos

```
xpm_chamberofcommerce_val_detailofmercantileregistrations_associatedpersons
```

Redshift tiene límite de 127 caracteres para nombres de tabla. Verificar que los nombres
generados no excedan este límite.

### 3.7 El campo `index` es palabra reservada

`index` es palabra reservada en Redshift. Siempre usar comillas dobles:

```sql
SELECT "index" FROM edf_views.xpm_bestaccounts;
```

---

## 4. Impacto de Operaciones Nocturnas del Pipeline

| Operación del pipeline | Vistas sobre las tablas | Permisos GRANT | Masking policies ATTACH |
|------------------------|------------------------|----------------|------------------------|
| `TRUNCATE + COPY` | ✅ Sin impacto | ✅ Sin impacto | ✅ Sin impacto |
| `DELETE + INSERT` | ✅ Sin impacto | ✅ Sin impacto | ✅ Sin impacto |
| `DROP + CREATE` (misma estructura) | ⚠️ Vistas se invalidan temporalmente, se resuelven al recrear | ❌ Se pierden GRANTs por tabla | ❌ Se pierden ATTACHs |
| `DROP + CREATE` (estructura cambia) | ❌ Vistas se rompen | ❌ Se pierden | ❌ Se pierden |
| `INSERT` incremental | ✅ Sin impacto | ✅ Sin impacto | ✅ Sin impacto |

> **Recomendación:** Preferir `TRUNCATE + COPY` sobre `DROP + CREATE` para evitar
> pérdida de permisos, vistas y policies. Si se usa DROP+CREATE, agregar paso post-carga
> en Airflow para re-ejecutar GRANTs y ATTACHs.

### Post-carga obligatorio

```sql
-- Después de cargas masivas, actualizar estadísticas
ANALYZE edf_views.xpm;
ANALYZE edf_views.xpm_bestaccounts;
-- ... para cada tabla recargada
```

---

## 5. Ubicación de Datos en S3

```
s3://{env}-{account}-batch-cmrs-bureau-analytics/xpm_full/
├── xpm/                                    ← Tabla raíz (Parquet)
├── xpm_bestAccounts/                       ← Nivel 1
├── xpm_bestAccounts.val.frequentBehaviour/ ← Nivel 2
├── xpm_location/                           ← Nivel 1
├── xpm_location.val.contactInformations/   ← Nivel 2
├── xpm_personalInformation/                ← Nivel 1
├── xpm_counterparties/                     ← Nivel 1
├── xpm_disputes/                           ← Nivel 1
├── xpm_legal/                              ← Nivel 1
└── ...
```

> Los nombres de carpeta en S3 usan camelCase (ej: `bestAccounts`).
> Los nombres de tabla en Redshift usan lowercase (ej: `xpm_bestaccounts`).

---

## Reglas de Validación para el Agente IA

1. Siempre usar comillas dobles para columnas con puntos: `"seccion.val.campo"`
2. Siempre incluir `relationalizelastupdate` en JOINs entre tablas XPM
3. Las fechas son BIGINT epoch — no usar funciones de TIMESTAMP directamente
4. Verificar si una sección es tabla hija normalizada o VARCHAR serializado antes de consultarla
5. No asumir DISTKEY/SORTKEY — verificar con `SELECT * FROM pg_table_def`
6. El campo `index` es reservado — siempre entre comillas dobles
