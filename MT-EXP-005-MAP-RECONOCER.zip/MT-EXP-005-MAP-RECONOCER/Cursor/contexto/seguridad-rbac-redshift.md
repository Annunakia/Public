---
inclusion: manual
---

# Seguridad y RBAC en Amazon Redshift — Patrones Genéricos

> Steering agnóstico de proyecto. Patrones de seguridad, control de acceso por roles,
> IAM, cifrado y auditoría para proyectos en Amazon Redshift.

---

## 1. Diseño de Roles RBAC

### Principio: Menor Privilegio

Cada rol accede solo a lo estrictamente necesario para su función.
Nunca otorgar permisos a usuarios directamente — siempre a través de roles.

### Patrón de roles por capas

```
┌─────────────────────────────────────────────────────────┐
│  CAPA 1: Roles RBAC (controlan acceso por schema)       │
│                                                         │
│  rol_admin     → Acceso completo a datos originales     │
│  rol_analyst   → Acceso solo a vistas/datos procesados  │
│  rol_auditor   → Acceso solo a logs de auditoría        │
│  rol_operador  → Acceso a ejecución de procesos batch   │
└─────────────────────────────────────────────────────────┘
                              +
┌─────────────────────────────────────────────────────────┐
│  CAPA 2: Roles funcionales (opcional, para masking)     │
│                                                         │
│  admin_unmasked   → Passthrough en masking policies     │
│  auditor_unmasked → Passthrough para auditoría          │
└─────────────────────────────────────────────────────────┘
```

### Creación de roles

```sql
-- Roles RBAC
CREATE ROLE rol_admin;
CREATE ROLE rol_analyst;
CREATE ROLE rol_auditor;

-- Asignar roles a usuarios
GRANT ROLE rol_analyst TO usuario_analista;
GRANT ROLE rol_admin TO usuario_admin;
```

> En Redshift, `CREATE ROLE` falla si el rol ya existe. Verificar antes:
> `SELECT 1 FROM pg_roles WHERE rolname = 'rol_analyst';`

---

## 2. Permisos por Schema

### Patrón estándar

```sql
-- Revocar acceso público
REVOKE ALL ON SCHEMA mi_schema FROM PUBLIC;

-- Otorgar USAGE (permite ver objetos del schema)
GRANT USAGE ON SCHEMA mi_schema TO ROLE rol_analyst;

-- Otorgar SELECT en todas las tablas/vistas del schema
GRANT SELECT ON ALL TABLES IN SCHEMA mi_schema TO ROLE rol_analyst;

-- Para tablas futuras (automático)
ALTER DEFAULT PRIVILEGES IN SCHEMA mi_schema
    GRANT SELECT ON TABLES TO ROLE rol_analyst;
```

### Matriz de permisos tipo

```
Objeto                    │ rol_admin │ rol_analyst │ rol_auditor │
──────────────────────────┼───────────┼─────────────┼─────────────┤
SCHEMA datos_originales   │  USAGE    │     ✗       │     ✗       │
TABLE  datos_originales.* │  SELECT   │     ✗       │     ✗       │
──────────────────────────┼───────────┼─────────────┼─────────────┤
SCHEMA vistas_procesadas  │  USAGE    │  USAGE      │     ✗       │
VIEW   vistas_procesadas.*│  SELECT   │  SELECT     │     ✗       │
──────────────────────────┼───────────┼─────────────┼─────────────┤
SCHEMA funciones          │  USAGE    │  USAGE      │     ✗       │
FUNC   funciones.*        │  EXECUTE  │  EXECUTE    │     ✗       │
──────────────────────────┼───────────┼─────────────┼─────────────┤
SCHEMA auditoria          │  USAGE    │     ✗       │  USAGE      │
TABLE  auditoria.*        │  SELECT   │     ✗       │  SELECT     │
──────────────────────────┴───────────┴─────────────┴─────────────┘
```

---

## 3. Usuarios de Servicio

Para procesos automatizados (Lambda, Airflow, CI/CD):

```sql
-- Crear usuario de servicio sin password interactivo
CREATE USER svc_mi_proceso PASSWORD DISABLE;

-- Otorgar solo los permisos necesarios
GRANT USAGE ON SCHEMA mi_schema TO svc_mi_proceso;
GRANT SELECT ON TABLE mi_schema.mi_tabla TO svc_mi_proceso;
```

> Usuarios de servicio se autentican vía IAM (GetClusterCredentials o Data API),
> no con password. Usar `PASSWORD DISABLE` para prevenir acceso interactivo.

---

## 4. Integración IAM

### Roles IAM por función

| Rol IAM | Propósito | Permisos clave |
|---------|-----------|----------------|
| `iam-role-{proyecto}-lambda-{funcion}` | Lambda que ejecuta SQL | `redshift-data:ExecuteStatement`, `secretsmanager:GetSecretValue` |
| `iam-role-{proyecto}-deploy` | Despliegue de scripts SQL | `redshift-data:ExecuteStatement`, `redshift-data:BatchExecuteStatement` |
| `iam-role-{proyecto}-redshift-service` | Rol del cluster/workgroup | `s3:GetObject`, `kms:Decrypt` |

### Restricciones por ambiente

| Restricción | DEV | QA | STG | PROD |
|-------------|-----|----|-----|------|
| MFA para deploy | No | Sí | Sí | Obligatorio |
| IP fija | No | Sí | Sí | Sí |
| Rotación credenciales | Semestral | Trimestral | Trimestral | Trimestral |

---

## 5. Cifrado

### Datos en reposo

| Recurso | Cifrado | Clave |
|---------|---------|-------|
| Redshift (cluster/workgroup) | AES-256 con KMS CMK | `alias/{proyecto}-redshift-{ambiente}` |
| S3 (datos y logs) | SSE-KMS con AES-256 | `alias/{proyecto}-s3-{ambiente}` |
| Secrets Manager | AES-256 con KMS CMK | `alias/{proyecto}-secrets-{ambiente}` |

### Datos en tránsito

| Conexión | Protocolo |
|----------|-----------|
| Cliente → Redshift | TLS 1.2+ (puerto 5440) |
| Lambda → Redshift Data API | HTTPS/TLS 1.2+ |
| Redshift → S3 (COPY/UNLOAD) | HTTPS interno AWS |

```sql
-- Verificar SSL habilitado
SELECT name, setting FROM pg_settings WHERE name IN ('ssl', 'ssl_ciphers');
```

---

## 6. Auditoría

### Tres niveles complementarios

```
Nivel 1: AWS CloudTrail
  ¿Quién hizo qué en AWS? (IAM, Secrets Manager, Redshift API)
  Retención: 1 año en S3

Nivel 2: Redshift STL/SVL
  ¿Qué queries se ejecutaron?
  Retención: 90 días en Redshift

Nivel 3: Tablas de auditoría propias
  ¿Qué eventos de negocio ocurrieron?
  Retención: configurable (90 días en Redshift + exportar a S3)
```

### Queries de monitoreo

```sql
-- Queries ejecutadas en las últimas 24h
SELECT q.query, u.usename, q.starttime,
       DATEDIFF(seconds, q.starttime, q.endtime) AS duration_sec
FROM stl_query q
JOIN pg_user u ON q.userid = u.usesysid
WHERE q.starttime >= DATEADD(day, -1, GETDATE())
ORDER BY q.starttime DESC
LIMIT 50;

-- Conexiones recientes
SELECT username, remotehost, remoteport, recordtime
FROM stl_connection_log
WHERE recordtime >= DATEADD(day, -1, GETDATE())
ORDER BY recordtime DESC
LIMIT 20;

-- Verificar permisos de un usuario
SELECT
    nspname AS schema,
    has_schema_privilege('<usuario>', nspname, 'USAGE') AS has_usage
FROM pg_namespace
WHERE nspname NOT LIKE 'pg_%' AND nspname != 'information_schema';
```

---

## 7. Gestión de Secretos con AWS Secrets Manager

### Patrón de sincronización

```
Secrets Manager (fuente de verdad)
    │
    │  Lambda (trigger: rotación o EventBridge)
    ▼
Tabla de configuración en Redshift (cache local)
    │
    │  Funciones/SPs leen de la tabla
    ▼
Lógica de negocio (funciones, vistas, procesos)
```

### Convención de nombres

```
{proyecto}/{ambiente}/{tipo}/{campo}

Ejemplos:
  miproyecto/prod/db_password/default
  miproyecto/prod/api_key/servicio_externo
  miproyecto/prod/salt/campo_hash
```

---

## 8. Testing de Seguridad

### Patrón: SET SESSION AUTHORIZATION

```sql
-- Verificar que un rol SÍ tiene acceso
SET SESSION AUTHORIZATION usuario_con_rol_analyst;
SELECT COUNT(*) FROM mi_schema.mi_vista;
-- Esperado: número > 0
RESET SESSION AUTHORIZATION;

-- Verificar que un rol NO tiene acceso
SET SESSION AUTHORIZATION usuario_con_rol_analyst;
SELECT COUNT(*) FROM datos_originales.mi_tabla;
-- Esperado: ERROR: permission denied
RESET SESSION AUTHORIZATION;

-- Verificar permisos programáticamente
SELECT
    has_schema_privilege('usuario_test', 'mi_schema', 'USAGE') AS schema_usage,
    has_table_privilege('usuario_test', 'mi_schema.mi_tabla', 'SELECT') AS table_select;
```

---

## Reglas de Validación para el Agente IA

1. Nunca otorgar permisos directamente a usuarios — siempre a roles
2. Nunca hardcodear credenciales en scripts SQL
3. Usar `REVOKE ALL FROM PUBLIC` antes de otorgar permisos específicos
4. Todo script de permisos debe tener rollback (REVOKE correspondiente)
5. Usuarios de servicio con `PASSWORD DISABLE`
6. Verificar permisos con `has_schema_privilege` / `has_table_privilege`
7. SSL obligatorio en todas las conexiones
