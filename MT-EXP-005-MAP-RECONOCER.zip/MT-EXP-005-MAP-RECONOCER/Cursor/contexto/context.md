# Proyecto: Migración Proceso de Unificación – Reconocer

## Contexto
Migración del proceso de Unificación de Direcciones Físicas del sistema Reconocer de Experian, desde Teradata hacia AWS (Redshift/EDF).

## Qué hace este proceso
Toma direcciones estandarizadas de tipo vía y las unifica (borrado lógico) cuando son iguales pero difieren en tipo de uso o complemento. Genera un ranking de la "mejor" dirección por persona usando concepto Padre-Hijo.

## 3 Reglas de Unificación
- **Regla 1**: Misma puerta, diferente tipo de uso (RES/LAB/CRR). Escoge por CIIU + número de entidades.
- **Regla 2**: Misma puerta, diferente complemento. Puede generar nuevas direcciones combinando nomenclaturas. La más compleja.
- **Regla 3**: Diferencia en vía generadora o número de puerta. Usa lat/long y diccionario de vía.

## Cascada
Regla 1 → Regla 2 → Regla 3. Resultado de una es insumo de la siguiente. Hija no vuelve a entrar.

## Código fuente
- `src/teradata/` — Scripts originales Teradata (P0019=Regla1, P0020=Regla2, P0021=Regla3)
- `src/redshift/` — Código migrado (destino)

## Tablas principales
- `REC_DATOS.RELACION_PERSONA_UBICACION` — Relación persona-ubicación (Ind_Unificacion=1)
- `REC_DATOS.UNIFICACION_DIRECCION` — Relaciones Padre-Hijo
- `REC_DATOS.DIRECCION_FISICA` — Direcciones (Regla 2 crea nuevas aquí)
- `REC_DATOS.NOMENCLATURA` — Niveles de nomenclaturas para comparación

## Aproximaciones de migración a probar
1. Prompt directo (IDE) — mejor para Regla 1
2. AWS Q Transform Custom — pendiente demo
3. Spec Driven Development — mejor para Regla 2 (SQL dinámico complejo)
