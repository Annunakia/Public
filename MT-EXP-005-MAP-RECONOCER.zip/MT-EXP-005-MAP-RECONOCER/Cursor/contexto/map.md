# map.md — Mapa de navegación: Unificación

## Entender la lógica de negocio
→ `docs/funcional/documento_funcional_v1.md` — 3 reglas, escenarios, concepto Padre-Hijo

## Ver el modelo de datos
→ `docs/tecnico/modelo_datos.md` — Explicación tabla por tabla

## Mapear regla/escenario a líneas de código
→ `docs/tecnico/mapeo_escenarios_codigo.md` — Regla X, Escenario Y → líneas N-M del SP

## Ver el código fuente original (Teradata)
→ `src/teradata/P0019_*` — Regla 1 (Tipo Uso + CIIU)
→ `src/teradata/P0020_*` — Regla 2 (Complementos)
→ `src/teradata/P0021_*` — Regla 3 (Geolocalización)
→ `src/teradata/Unificacion.sql` — DDL + SPs completos (311KB)
→ `src/teradata/PRO_Unifi_MOTOR_TMP.sql` — SP principal extraído (6,220 líneas)

## Ver el código migrado (Redshift)
→ `src/redshift/00_setup_schema.sql` — Setup del schema
→ `src/redshift/01_regla1_unificacion.sql` — Regla 1 migrada ✅

## Datos de prueba
→ `data/mock/` — 19 personas ficticias, 12 escenarios, 7 CSVs
→ `data/mock/README_datos_mock.md` — Explicación del dataset

## Criterios de validación y resultados
→ `docs/tecnico/criterios_validacion.md` — 20 criterios técnicos
→ `docs/tecnico/prueba_regla1_redshift.md` — Resultados POC Regla 1

## Análisis técnico de scripts
→ `docs/tecnico/analisis_scripts.md` — Descomposición de P0019/P0020/P0021

## Parámetros y catálogos
→ `data/parametros/V_Insumo_Unificacion_Regla1.txt` — Vista insumo Regla 1
→ `data/parametros/V_Insumo_Unificacion_Regla2.txt` — Vista insumo Regla 2
→ `data/parametros/V_Insumo_Unificacion_Regla3.txt` — Vista insumo Regla 3
→ `data/parametros/Tipo_Via.txt` — Catálogo de tipos de vía

## Contexto de preventa
→ `docs/preventa/` — Entregables de preventa (arquitectura, fases, WBS, riesgos)

## Comunicaciones relevantes
→ `docs/comunicaciones/` — Transcripciones de reuniones sobre unificación
