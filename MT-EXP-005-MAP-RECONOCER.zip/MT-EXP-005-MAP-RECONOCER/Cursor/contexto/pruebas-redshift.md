---
inclusion: auto
---

# Ejecución de Pruebas en Redshift — Steering

> Cómo conectarse y ejecutar pruebas SQL en el sandbox de Redshift.
> NO divagar buscando credenciales ni workgroups. Seguir este documento.

---

## 1. Conexión rápida

| Campo | Valor |
|-------|-------|
| Cuenta AWS | `193272798722` |
| Perfil AWS CLI | `sandbox` |
| Región | `us-east-1` |
| Workgroup | `experian-sandbox-dev-redshift-workgroup` |
| Database | `dev` |
| Método | Redshift Data API (no requiere VPN ni psql) |

### Login (si la sesión expiró)

```bash
aws sso login --profile sandbox
```

### Verificar conexión

```bash
aws sts get-caller-identity --profile sandbox
```

---

## 2. Ejecutar SQL via Data API

### Helper script

Usar `ws-unificacion/data/mock/run_sql.sh`:

```bash
./ws-unificacion/data/mock/run_sql.sh "SELECT 1" "test"
```

El script:
- Ejecuta el SQL via `redshift-data execute-statement`
- Espera hasta que termine (polling cada 2s, timeout 120s)
- Muestra resultados tabulados o el error

### Ejecución directa (sin helper)

```bash
# Ejecutar
ID=$(aws redshift-data execute-statement \
  --workgroup-name experian-sandbox-dev-redshift-workgroup \
  --database dev --sql "SELECT 1" \
  --profile sandbox --region us-east-1 \
  --query 'Id' --output text)

# Esperar y ver resultado
aws redshift-data describe-statement --id "$ID" --profile sandbox --region us-east-1
aws redshift-data get-statement-result --id "$ID" --profile sandbox --region us-east-1
```

---

## 3. Schemas de prueba

| Schema | Uso |
|--------|-----|
| `bdm_datos` | Tablas permanentes (se crean con `01_schemas_roles.sql`) |
| `bdm_tempo` | Tablas staging volátiles (se limpian al final de cada prueba) |

---

## 4. Patrón de prueba

Cada prueba sigue este flujo:

1. **Crear schemas y tablas** — ejecutar `01_schemas_roles.sql`
2. **Cargar datos mock** — INSERTs de las personas relevantes
3. **Ejecutar scripts** — en orden del `deploy_order.par`
4. **Verificar resultados** — queries SELECT con CASE WHEN PASS/FAIL
5. **Limpiar** — DROP de todas las tablas y schemas

### Convención de archivos de prueba

```
ws-unificacion/data/mock/
├── validate_{componente}_{persona}.sql   ← Script autocontenido de prueba
├── run_sql.sh                            ← Helper de ejecución
├── README_datos_mock.md                  ← Diseño de datos y resultado esperado
└── *.csv                                 ← Datos mock en CSV
```

---

## 5. Limitaciones del Data API

- Máximo 100KB por statement SQL
- Si el script es muy largo, dividir en múltiples llamadas
- No soporta `\i` ni includes — cada statement es independiente
- Las tablas en `bdm_tempo` se limpian diariamente por el cliente (no confiar en persistencia)
- Timeout de 120s por statement — queries pesadas pueden fallar

---

## 6. Otras cuentas disponibles

| Cuenta | Perfil | Uso | Redshift |
|--------|--------|-----|----------|
| `193272798722` | `sandbox` | Sandbox XPM + dev Redshift | ✅ `dev-redshift-workgroup` |
| `471112921910` | `test-reconocer` | Sandbox Experian general | ❌ Sin Redshift |

> Usar siempre la cuenta `193272798722` para pruebas Redshift.
