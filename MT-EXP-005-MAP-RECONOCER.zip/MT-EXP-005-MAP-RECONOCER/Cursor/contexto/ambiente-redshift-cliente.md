---
inclusion: auto
---

# Ambiente Redshift del Cliente — Referencia de Conectividad

> Steering agnóstico de proyecto. Documenta los ambientes Redshift del cliente,
> conectividad, costos y patrones de acceso. Aplica a cualquier proyecto que
> se conecte al cluster.

---

## 1. Inventario de Ambientes

| Campo | DEV | QA | STG/DEMO |
|-------|-----|----|----------|
| Account ID | 651706752126 | 124355679563 | 311141534073 |
| CIDR/Subnet | 10.2.171.0/24 | 10.2.173.0/26 | 10.2.172.0/24 |
| DB Name | dba_batch | dba_batch | dba_batch |
| Puerto | **5440** | **5440** | **5440** |
| Workgroup | eec-aws-us-eits-procesosbatch-dev-redshift | eec-aws-us-eits-procesosbatch-qa-redshift | eec-aws-us-eits-procesosbatch-stg-redshift |
| Host | `eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com` | `eec-aws-us-eits-procesosbatch-qa-redshift.cwefyckvccgy.us-east-1.redshift.amazonaws.com` | `eec-aws-us-eits-procesosbatch-stg-redshift.cisjoykj3j5j.us-east-1.redshift.amazonaws.com` |

> **IMPORTANTE:** El puerto es **5440**, no 5439 (que es el default de Redshift).

---

## 2. Requisitos de Acceso (Zero-Trust)

| Requisito | DEV | QA | STG | PROD |
|-----------|-----|----|-----|------|
| VPN aprobada | Sí | Sí | Sí | Sí |
| IP fija estática | Sí | Sí | Sí | Sí |
| MFA | No | Sí | Sí | **Obligatorio** |
| Aprobación previa | No | Revisión técnica | Revisión técnica | Aprobación formal |
| Ventana de mantenimiento | No | No | Recomendada | **Obligatoria** |

> Sin IP fija = bloqueo inmediato de seguridad.
> Actualizaciones de firewall se aplican en ventana nocturna (solicitud hoy → efectiva mañana).

---

## 3. Verificación de Conectividad

### PowerShell
```powershell
Test-NetConnection -ComputerName "eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com" -Port 5440
# Exitoso SOLO si: TcpTestSucceeded: True
```

### psql
```bash
psql "host=eec-aws-us-eits-procesosbatch-dev-redshift.cee2enck00mg.us-east-1.redshift.amazonaws.com \
      port=5440 dbname=dba_batch user=<usuario> sslmode=require"
```

### Test básico post-conexión
```sql
SELECT current_database(), current_user, current_schema(), version();
```

---

## 4. Redshift Serverless vs Aprovisionado

El cliente usa **Redshift Serverless** en los ambientes principales. Existe también un
cluster aprovisionado para desarrollo con control de costos.

### Serverless (ambientes principales)

- Sin gestión de nodos — escala automáticamente
- Pago por RPU (Redshift Processing Units) consumidas
- Concurrency Scaling incluido
- Ideal para cargas variables

### Aprovisionado (desarrollo/sandbox)

- Nodo `ra3.xlplus` (2 vCPU, 16GB RAM)
- Costo: ~$0.85 USD/hora (~$330 USD/mes con 13h/día)
- Control automático on/off vía Lambda + EventBridge:
  - Encendido: 7:00 AM UTC
  - Apagado: 8:00 PM UTC
- Puerto: 5439 (default)

---

## 5. Schemas Estándar del Cliente

| Schema | Responsabilidad | Acceso |
|--------|----------------|--------|
| `edf_views` | Tablas XPM relationalizadas (datos originales) | Restringido |
| `bdm_datos` | Tablas permanentes, SPs, UDFs del batch | General |
| `bdm_tempo` | Tablas de staging y procesamiento volátil (limpieza diaria) | General |
| `bdm_mtdat` | Metadatos técnicos, control de ejecución, logs (`log_rs`) | Operaciones |

> Las tablas en `bdm_tempo` se limpian diariamente. No almacenar datos permanentes ahí.

---

## 6. Redshift Data API

Para ejecución programática de SQL sin conexión directa al cluster:

```python
import boto3

client = boto3.client('redshift-data', region_name='us-east-1')

response = client.execute_statement(
    WorkgroupName='eec-aws-us-eits-procesosbatch-dev-redshift',
    Database='dba_batch',
    DbUser='<usuario>',
    Sql='SELECT current_user, current_database();'
)

# Verificar estado
status = client.describe_statement(Id=response['Id'])
print(status['Status'])  # SUBMITTED → STARTED → FINISHED
```

> Data API es útil para Lambda, Step Functions y CI/CD sin exponer credenciales.

---

## 7. Conexión SSL

```bash
# Conexión con SSL obligatorio
psql "host=<endpoint> port=5440 dbname=dba_batch user=<user> \
      sslmode=require sslrootcert=redshift-ca-bundle.crt"
```

> TLS 1.2+ es obligatorio en todos los ambientes.

---

## 8. Nomenclatura Estándar del Cliente

| Tipo | Patrón | Ejemplo |
|------|--------|---------|
| Tablas permanentes | `tb_{dominio}_{entidad}` | `tb_riesgo_clientes` |
| Stored Procedures | `sp_{proceso}_{accion}` | `sp_carga_validar` |
| Tablas temporales | `PP0989_{solicitud}_{sufijo}` | `PP0989_12345_staging` |
| Archivos S3 | `davval{solicitud}-{id}-{MMAA}.{ext}` | `davval1234-001-0325.csv.gz` |

---

## Reglas de Validación para el Agente IA

1. Puerto es **5440**, no 5439
2. Siempre usar `sslmode=require` en conexiones
3. No hardcodear credenciales — usar variables de entorno o Secrets Manager
4. Tablas en `bdm_tempo` son volátiles (1 día) — no almacenar datos permanentes
5. Verificar conectividad con `Test-NetConnection` antes de ejecutar scripts
6. MFA es obligatorio para QA, STG y PROD
