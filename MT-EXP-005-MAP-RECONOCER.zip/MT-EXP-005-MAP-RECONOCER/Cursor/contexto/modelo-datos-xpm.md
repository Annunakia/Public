---
inclusion: auto
---

# Modelo de Datos XPM — Referencia para Proyectos Redshift

> Steering agnóstico de proyecto. Describe el modelo de datos XPM tal como llega
> desde AWS Glue Relationalize al schema `edf_views` en Amazon Redshift.
> Usar como referencia para cualquier proyecto que consulte, transforme o analice datos XPM.

---

## 1. Pipeline de Ingesta

```
Avro (fuente bureau)
    │
    ▼
AWS Glue Relationalize (PySpark)
    │  Desnormaliza JSON anidado en tablas planas
    │  Genera ~20 tablas con notación de puntos
    ▼
Parquet (S3 — staging)
    │
    ▼
Redshift COPY → edf_views.xpm, edf_views.xpm_*, ...
```

El proceso Relationalize transforma un JSON jerárquico (perfil XPM) en un conjunto de tablas
relacionales planas. Ver `proceso-rationalize.md` para detalles del proceso.

---

## 2. Jerarquía de Tablas (3 Niveles)

```
                        ┌─────────────────────────────┐
                        │   edf_views.xpm             │
                        │   (Nivel 0 — Raíz)          │
                        │                             │
                        │   PK: id (surrogate BIGINT) │
                        │   SK: relationalize-        │
                        │       lastupdate (INT)      │
                        └────────────┬────────────────┘
                                     │
                     FK: id + relationalizelastupdate
                                     │
        ┌────────────────────────────┼──────────────────────────────┐
        │                            │                              │
        ▼                            ▼                              ▼
  Tablas Nivel 1              Tablas Nivel 1                 Tablas Nivel 1
  (hijas directas)            (hijas directas)               (hijas directas)
  FK: id + relat.             FK: id + relat.                FK: id + relat.
  + index                     + index                        + index
        │
        │  FK: id + index + relationalizelastupdate
        ▼
  Tablas Nivel 2 (nietas — arrays anidados dentro de hijas)
```

### Catálogo Completo de Tablas

| Nivel | Tabla | Descripción | Relación con padre |
|-------|-------|-------------|-------------------|
| 0 | `xpm` | Tabla raíz — 1 registro por perfil/entidad | — |
| 1 | `xpm_personalinformation` | Información personal reportada por fuentes | 1:N con xpm |
| 1 | `xpm_location` | Datos de ubicación | 1:N con xpm |
| 1 | `xpm_bestaccounts` | Mejores cuentas (~80+ columnas) | 1:N con xpm |
| 1 | `xpm_names` | Nombres reportados por fuentes | 1:N con xpm |
| 1 | `xpm_identifications` | Documentos de identificación | 1:N con xpm |
| 1 | `xpm_chamberofcommerce` | Datos de Cámara de Comercio | 1:N con xpm |
| 1 | `xpm_counterparties` | Contrapartes (entidades reportantes) | 1:N con xpm |
| 1 | `xpm_disputes` | Reclamos y disputas | 1:N con xpm |
| 1 | `xpm_legal` | Información legal | 1:N con xpm |
| 1 | `xpm_redam_val` | Registro Deudores Alimentarios Morosos | 1:N con xpm |
| 1 | `xpm_parenteventids` | IDs de eventos padre | 1:N con xpm |
| 1 | `xpm_isactivesub` | Indicador de suscriptor activo | 1:N con xpm |
| 1 | `xpm_bestidentifications` | Mejores identificaciones consolidadas | 1:N con xpm |
| 1 | `xpm_activesubscribercodes_val` | Códigos de suscriptores activos | 1:N con xpm |
| 1 | `xpm_inactivesubscribercodes_val` | Códigos de suscriptores inactivos | 1:N con xpm |
| 2 | `xpm_location_val_contactinformations` | Datos de contacto (email, tel, dirección) | 1:N con xpm_location |
| 2 | `xpm_chamberofcommerce_val_..._associatedpersons` | Personas asociadas a registro mercantil | 1:N con xpm_chamberofcommerce |
| 2 | `xpm_counterparties_val_businesslines` | Líneas de negocio de contrapartes | 1:N con xpm_counterparties |
| 2 | `xpm_bestaccounts_val_frequentbehaviour` | Comportamiento frecuente de cuentas | 1:N con xpm_bestaccounts |

---

## 3. Reglas de JOIN (Obligatorias)

```sql
-- JOIN Nivel 0 → Nivel 1 (clave compuesta OBLIGATORIA)
SELECT x.*, ba.*
FROM edf_views.xpm x
JOIN edf_views.xpm_bestaccounts ba
  ON x.id = ba.id
 AND x.relationalizelastupdate = ba.relationalizelastupdate;

-- JOIN Nivel 1 → Nivel 2 (clave compuesta con index)
SELECT loc.*, ci.*
FROM edf_views.xpm_location loc
JOIN edf_views.xpm_location_val_contactinformations ci
  ON loc.id = ci.id
 AND loc."index" = ci."index"
 AND loc.relationalizelastupdate = ci.relationalizelastupdate;
```

| Relación | Clave compuesta | Obligatorio |
|----------|----------------|-------------|
| Nivel 0 → Nivel 1 | `id` + `relationalizelastupdate` | Sí — sin `relationalizelastupdate` se producen productos cartesianos |
| Nivel 1 → Nivel 2 | `id` + `index` + `relationalizelastupdate` | Sí — `index` discrimina múltiples registros por id |

> **REGLA CRÍTICA:** `relationalizelastupdate` es OBLIGATORIO en todos los JOINs.
> Omitirlo genera duplicados silenciosos que corrompen resultados.

---

## 4. Tabla Raíz: edf_views.xpm

Campos escalares del perfil. Columnas BIGINT que son FK a tablas hijas (ej: `bestaccounts`,
`location`, `disputes`) contienen el conteo de registros hijos, no un ID relacional.

### Campos clave de la tabla raíz

| Columna | Tipo | Descripción |
|---------|------|-------------|
| `id` | BIGINT | PK surrogate — identifica un perfil único |
| `relationalizelastupdate` | INT | Timestamp de cargue incremental — obligatorio en JOINs |
| `bestname.fullname` | VARCHAR(512) | Nombre completo consolidado |
| `bestname.firstname` | VARCHAR(256) | Primer nombre consolidado |
| `bestname.firstlastname` | VARCHAR(256) | Primer apellido consolidado |
| `bestname.secondlastname` | VARCHAR(256) | Segundo apellido consolidado |
| `bestpersonalinformation.age` | BIGINT | Edad |
| `bestpersonalinformation.gender` | BIGINT | Género (código) |
| `bestpersonalinformation.birthdate` | BIGINT | Fecha nacimiento (epoch) |
| `bestpersonalinformation.maritalstatus` | VARCHAR(64) | Estado civil |
| `bestpersonalinformation.nationalitycode` | VARCHAR(64) | Código nacionalidad |
| `pin` | BIGINT | PIN del perfil |
| `pinscore` | BIGINT | Score del PIN |
| `xpmversion` | FLOAT8 | Versión del XPM |
| `delta_operation` | VARCHAR(64) | Tipo de operación delta |
| `source_type` | VARCHAR(64) | Tipo de fuente |

### Secciones VARCHAR no normalizadas

Algunas secciones llegan como VARCHAR(16383) serializado en la tabla raíz, no como tablas hijas:

| Columna | Contenido | Estado |
|---------|-----------|--------|
| `sisben` | Datos SISBEN | No normalizado — no consultable como columnas |
| `alerts` | Alertas | No normalizado |
| `judicialinformation` | Información judicial | No normalizado |
| `bureauattributes` | Atributos del bureau | No normalizado |
| `inquiryfootprints` | Huellas de consulta | No normalizado |
| `globalindebtedness` | Endeudamiento global | No normalizado |
| `bureaumodels` | Modelos del bureau | No normalizado |

> Estas secciones requieren normalización por el equipo de ingesta para ser consultables.

---

## 5. Ejemplo Relacional: xpm → xpm_bestaccounts

```
edf_views.xpm (Nivel 0)                    edf_views.xpm_bestaccounts (Nivel 1)
┌──────────────────────────┐                ┌──────────────────────────────────┐
│ id (PK)                  │───────────────►│ id (FK)                          │
│ relationalizelastupdate  │───────────────►│ relationalizelastupdate (FK)     │
│ bestname.firstname       │                │ index                            │
│ bestname.firstlastname   │                │ bestaccounts.val.accountnumber   │
│ bestpersonalinformation. │                │ bestaccounts.val.accounttype     │
│   age                    │                │ bestaccounts.val.cardnumber      │
│ ...                      │                │ bestaccounts.val.personidnumber  │
└──────────────────────────┘                │ bestaccounts.val.counterparty... │
                                            │ bestaccounts.val.cutoffdate      │
        1 perfil                            │ ... (~80+ columnas)              │
            │                               └──────────────────────────────────┘
            │
            └──── tiene N cuentas (bestaccounts)
```

```sql
-- JOIN correcto
SELECT
    x.id,
    x."bestname.firstname",
    x."bestname.firstlastname",
    ba."bestaccounts.val.accountnumber",
    ba."bestaccounts.val.accounttype",
    ba."bestaccounts.val.cutoffdate"
FROM edf_views.xpm x
JOIN edf_views.xpm_bestaccounts ba
  ON x.id = ba.id
 AND x.relationalizelastupdate = ba.relationalizelastupdate
WHERE ba."bestaccounts.val.cutoffdate" >= 20250101;
```

### Ejemplo Nivel 2: xpm_bestaccounts → xpm_bestaccounts_val_frequentbehaviour

```sql
SELECT
    ba."bestaccounts.val.accountnumber",
    fb."bestaccounts.val.frequentbehaviour.val.rating",
    fb."bestaccounts.val.frequentbehaviour.val.debtbalance",
    fb."bestaccounts.val.frequentbehaviour.val.availablebalance"
FROM edf_views.xpm_bestaccounts ba
JOIN edf_views.xpm_bestaccounts_val_frequentbehaviour fb
  ON ba.id = fb.id
 AND ba."index" = fb."index"
 AND ba.relationalizelastupdate = fb.relationalizelastupdate;
```

---

## 6. Encoding y Distribución Recomendados

### Por tipo de dato

| Tipo | Encoding recomendado | Razón |
|------|---------------------|-------|
| BIGINT | AZ64 | Compresión nativa optimizada para enteros |
| VARCHAR corto (<256) | ZSTD | Mejor ratio para strings cortos |
| VARCHAR largo (16383) | LZO | Mejor para strings largos y repetitivos |
| VARCHAR baja cardinalidad | BYTEDICT | Pocos valores distintos (ej: accounttype) |
| BOOLEAN | RAW | Sin compresión — ya es 1 byte |
| FLOAT8 | RAW | Compresión no beneficia floats |
| INT (control) | AZ64 | Consistente con BIGINT |

### DISTKEY y SORTKEY por nivel

| Nivel | Tabla ejemplo | DISTKEY | SORTKEY | Razón |
|-------|--------------|---------|---------|-------|
| 0 (raíz) | `xpm` | `id` (DISTSTYLE KEY) | `relationalizelastupdate` | JOINs con hijas por id, filtros temporales |
| 1 (hijas) | `xpm_bestaccounts` | DISTSTYLE AUTO | — | Redshift optimiza automáticamente |
| 2 (nietas) | `xpm_location_val_contactinformations` | DISTSTYLE AUTO | — | Volumen menor, AUTO suficiente |

> Las tablas hijas usan DISTSTYLE AUTO porque Redshift las optimiza según patrones de uso.
> La tabla raíz usa DISTKEY(id) para co-localizar datos con las hijas en JOINs.

---

## 7. Volumetría Referencial

| Tabla | Nivel | Registros estimados | Relación |
|-------|-------|---------------------|----------|
| xpm | 0 | Millones | 1 por perfil |
| xpm_personalinformation | 1 | ~1:1 con xpm | 1 registro por fuente reportante |
| xpm_bestaccounts | 1 | ~5-20:1 con xpm | Múltiples cuentas por perfil |
| xpm_location | 1 | ~1-5:1 con xpm | Múltiples ubicaciones |
| xpm_location_val_contactinformations | 2 | ~2-10:1 con location | Múltiples contactos por ubicación |
| xpm_names | 1 | ~1-3:1 con xpm | Nombres reportados por distintas fuentes |
| xpm_disputes | 1 | ~0-2:1 con xpm | No todos los perfiles tienen disputas |

---

## 8. Campos de Control (presentes en TODAS las tablas)

| Campo | Tipo | Presente en | Propósito |
|-------|------|-------------|-----------|
| `id` | BIGINT | Todas | FK/PK — identifica el perfil raíz |
| `relationalizelastupdate` | INT | Todas | Timestamp de cargue — OBLIGATORIO en JOINs |
| `index` | INT | Nivel 1 y 2 | Posición en el array original del JSON |

> Estos campos NUNCA deben enmascararse, transformarse ni excluirse de las consultas.

---

## Reglas de Validación para el Agente IA

1. Todo JOIN entre tablas XPM DEBE incluir `relationalizelastupdate`
2. Columnas con puntos en el nombre DEBEN ir entre comillas dobles: `"bestname.firstname"`
3. Las fechas son BIGINT (epoch), no TIMESTAMP — usar conversión si se necesita formato legible
4. No asumir que todas las secciones están normalizadas — verificar si es VARCHAR(16383)
5. DISTKEY(id) solo en tabla raíz; DISTSTYLE AUTO en hijas
6. Usar encoding AZ64 para BIGINT, ZSTD para VARCHAR corto, LZO para VARCHAR largo
