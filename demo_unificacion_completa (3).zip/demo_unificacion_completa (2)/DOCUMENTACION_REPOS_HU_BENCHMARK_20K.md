# Documentación de repositorios — Benchmark Unificación 20K

| Campo | Valor |
|-------|-------|
| **App ID** | 31343 |
| **ID SNOW** | CHG2962599 |
| **Requiere transición** | NO |
| **Tipo** | Mejora continua – Técnico |
| **Epic** | Modernización de Reconocer Master |
| **HU / Jira** | SLCOPRBA-1147 (deploy relacionado: SLCOPRBA-1150) |
| **Proyecto Bitbucket** | [COAWSPPR](https://code.experian.local/projects/COAWSPPR) |
| **Objetivo** | Promover y ejecutar el script consolidado del benchmark 20K en QA y PDN vía pipeline Jenkins, certificando la cascada **R1 → R2 (motor batch 1×) → R3** y midiendo tiempos con datos sintéticos. |

---

## 1. Los tres repositorios — ¿qué hace cada uno?

En el estándar **DATABASE-REDSHIFT** (EITS / DevSecOps) un cambio de base se separa en tres paquetes según el tipo de artefacto. Para Unificación Reconocer Batch Redshift son:

| Repo | Sufijo | Rol en el estándar | ¿Qué contiene hoy? | ¿Se usa? |
|------|--------|--------------------|--------------------|----------|
| [`db_rcncr_btch_rdshft_strct`](https://code.experian.local/projects/COAWSPPR/repos/db_rcncr_btch_rdshft_strct/browse) | **_strct** | Tablas, catálogo y vistas `bdm_stage` | `01_tables` + `02_catalog` + `03_views` | **Sí — desplegar primero** |
| [`db_rcncr_btch_rdshft_pgm`](https://code.experian.local/projects/COAWSPPR/repos/db_rcncr_btch_rdshft_pgm/browse) | **_pgm** | Stored procedures | `sp_r1`, `sp_r2`, `sp_r3` (`NONATOMIC`) | **Sí — desplegar segundo** |
| [`db_rcncr_btch_rdshft_dt`](https://code.experian.local/projects/COAWSPPR/repos/db_rcncr_btch_rdshft_dt/browse) | **_dt** | Carga + orquestación | `…_orchestrator.sql` (TRUNCATE/load 20K + `CALL` SPs) | **Sí — desplegar tercero** |

### Orden de promoción

1. **`_strct`** → crea tablas / catálogo / vistas en `bdm_stage`
2. **`_pgm`** → crea `sp_r1`, `sp_r2`, `sp_r3`
3. **`_dt`** → limpia datos, carga 20K sintéticas, `CALL` cascada, registra timings

> El script monolítico original (`SLCOPRBA-1147-run_benchmark_20k_batch.sql`) se conserva en `_dt/SQL` como referencia; `deploy.par` apunta al **orquestador**.

---

## 2. Detalle: `db_rcncr_btch_rdshft_dt` (repo de la HU)

### Configuración Jenkins

```yaml
# .jenkins.yml
global:
  application: dba_batch
  type: struct      # pipeline DATABASE-REDSHIFT certifica ejecución + rollback
  tech: database
  language: redshift
```

### Artefactos de despliegue

| Ruta | Función |
|------|---------|
| `deploy/redshift/deploy.par` | Orden de ejecución → apunta **solo** a `SLCOPRBA-1147-run_benchmark_20k_batch.sql` (CA-00) |
| `deploy/redshift/rollback.par` | Orden de rollback → mismo nombre de script en `RevSQL/` (CA-00 / CA-03) |
| `deploy/redshift/SQL/SLCOPRBA-1147-run_benchmark_20k_batch.sql` | Script **exec** del benchmark (sin SELECT al cliente). Fuente: `Benchmark_20K/00_run_benchmark_20k_batch.sql` (variante consolidada) |
| `deploy/redshift/RevSQL/SLCOPRBA-1147-run_benchmark_20k_batch.sql` | Limpieza post-certificación: `DROP` de tablas mock, `stg_*`, auxiliares (`perf_digit`, `perf_nums`, `perf_timings`, etc.). **No** elimina el esquema `bdm_stage` |

### Qué ejecuta el script (cascada certificada)

1. **DATA_LOAD** — genera ~20.000 personas sintéticas y catálogos en `bdm_stage`
2. **R1** — Regla 1 unificación
3. **R2_ESC1_2 / R2_ESC4 / R2_ESC3_SIN_NIT** — escenarios Regla 2
4. **R2_MOTOR_BATCH_PREP → RUN → FIN** — motor de nuevas direcciones en modo **batch 1×**
5. **R3** — Regla 3 (geo mock)
6. **VALIDATION** — hito de cierre de timings (validación funcional detallada en DBeaver)

Instrumentación: tabla `bdm_stage.perf_timings` con `run_id` por ambiente.

### `run_id` por ambiente (obligatorio antes de promover)

| Ambiente | `run_id` | Referencia |
|----------|----------|------------|
| DEV | `benchmark_20k_batch_v1` | ~33 s E2E (informe local) |
| QA | `benchmark_20k_batch_qa_v1` | Evidencia CA-01 (abajo) |
| PDN | `benchmark_20k_batch_pdn_v1` | Pendiente CA-02 |

### Validación post-deploy (manual DBeaver)

```sql
SELECT step_order, step_id, label, duration_sec, status, created_at
FROM bdm_stage.perf_timings
WHERE run_id = 'benchmark_20k_batch_qa_v1'   -- o _pdn_v1 / _v1
ORDER BY step_order;
```

Criterios PASS: **10 hitos con `status = 'OK'`**, 20.000 personas, invariantes = 0.

> **Nota pipeline:** en corrida Jenkins `type: struct`, el RevSQL puede dropear `perf_timings`. Para conservar tiempos, capturar el `SELECT` en DBeaver **antes** del rollback o en una corrida manual de la variante exec.

---

## 3. Detalle: `db_rcncr_btch_rdshft_strct`

| Aspecto | Estado |
|---------|--------|
| Propósito estándar | Cambios de **estructura** Redshift del batch Unificación (tablas/vistas permanentes, alters de modelo) |
| Contenido actual | `.gitignore` + `.jenkins.yml` (placeholders `null`) |
| Relación con la HU | Ningún artefacto en `deploy/`. El benchmark no introduce DDL de negocio permanente |
| Acción requerida | **Ninguna** para CA-00…CA-04 de esta historia |

---

## 4. Detalle: `db_rcncr_btch_rdshft_pgm`

| Aspecto | Estado |
|---------|--------|
| Propósito estándar | **Programas** Redshift (procedures, functions) del batch Unificación |
| Contenido actual | `.gitignore` + `.jenkins.yml` (placeholders `null`) |
| Relación con la HU | El motor y las reglas viajan **embebidos en el SQL** del paquete `_dt`, no como objetos `CREATE PROCEDURE` |
| Acción requerida | **Ninguna** para esta historia |

---

## 5. Mapeo a criterios de aceptación

### CA-00 — Prerrequisitos

| Ítem | Estado | Evidencia / nota |
|------|--------|------------------|
| `deploy.par` → único script benchmark | Cumple | `deploy.par` = `SLCOPRBA-1147-run_benchmark_20k_batch.sql` |
| `rollback.par` definido | Cumple | Apunta al RevSQL homónimo |
| Dev exitoso `benchmark_20k_batch_v1` (~33 s) | Cumple (referencia) | `demo_unificacion_completa/INFORME_BENCHMARK_20K_BATCH.md` |
| Commits con ID sub-tarea Jira | Verificar en Bitbucket | Prefijo `SLCOPRBA-####` en mensajes |
| Grants `USAGE` + `CREATE` sobre `bdm_stage` en QA/PDN | Verificar con DBA | Bloqueante si falta |

### CA-01 — Promoción y despliegue en QA

| Ítem | Estado | Evidencia |
|------|--------|-----------|
| Script con `run_id = benchmark_20k_batch_qa_v1` | Cumple | SQL en repo `_dt` ya parametrizado a QA |
| Rama / PR / Jenkins QA | Completar enlaces en tabla §6 | Pipeline + PR según política equipo |
| Despliegue Jenkins QA OK | Cumple (funcional) | Corrida reflejada en `perf_timings` |
| 10 hitos `status = OK` | **Cumple** | Captura DBeaver (abajo) |
| Validación funcional documentada (CA-05) | Ver §7 | Incluida en este documento |

#### Evidencia CA-01 — `perf_timings` QA

Consulta ejecutada:

```sql
SELECT step_order, step_id, label, duration_sec, status, created_at
FROM bdm_stage.perf_timings
WHERE run_id = 'benchmark_20k_batch_qa_v1'
ORDER BY step_order;
```

| step_order | step_id | label (resumen) | duration_sec | status | created_at |
|------------|---------|-----------------|--------------|--------|------------|
| 1 | DATA_LOAD | Carga 20000 pers | 39 | OK | 2026-07-15 ~18:55 |
| 2 | R1 | Regla 1 | 7 | OK | … |
| 3 | R2_ESC1_2 | R2 Escenarios 1 y 2 | 10 | OK | … |
| 4 | R2_ESC4 | R2 Escenario 4 | 12 | OK | … |
| 5 | R2_ESC3_SIN_NIT *(u homólogo en UI)* | R2 Esc 3 / BIT | 8 | OK | … |
| 6 | R2_MOTOR_BATCH_PREP | Motor batch prep | 18 | OK | … |
| 7 | R2_MOTOR_BATCH_RUN | Motor batch run | 19 | OK | … |
| 8 | R2_MOTOR_BATCH_FIN | Motor batch final | 22 | OK | … |
| 9 | R3 | Regla 3 | 11 | OK | … |
| 10 | VALIDATION | Validación post-run | 7 | OK | … |

**Suma aproximada E2E QA:** ~153 s (suma de `duration_sec`). Todos los hitos **OK**.

Adjuntar al ticket: captura DBeaver de este resultado + build Jenkins QA.

### CA-02 — Promoción y despliegue en PDN

| Ítem | Estado | Acción |
|------|--------|--------|
| `run_id = benchmark_20k_batch_pdn_v1` | Pendiente | Cambiar `run_id` en SQL, commit en rama `PDN/<ID_HU>` |
| Ventana PDN acordada | Pendiente | No impactar batch productivo en `bdm_stage` |
| PR PDN + aprobadores / CAB | Pendiente | Título con ID HU; CHG2962599 |
| Jenkins PDN OK + 10 hitos OK | Pendiente | Misma query con `benchmark_20k_batch_pdn_v1` |
| Cierre sub-tarea / HU | Pendiente | Adjuntar evidencias |

### CA-03 — Rollback y contingencia

| Ítem | Estado | Nota |
|------|--------|------|
| `rollback.par` coherente con `deploy.par` | Cumple | Mismo nombre de archivo en SQL / RevSQL |
| Rollback probado en no-PDN | Verificar | Confirmar en Dev o QA que RevSQL limpia mock/staging |
| Plan de contingencia | Definir en ticket | Contacto DevSecOps EITS SP-LATAM si falla PDN |

### CA-04 — Trazabilidad

Completar la tabla de la §6 en el ticket Jira / SNOW con enlaces reales.

---

## 6. Tabla de trazabilidad (pegar en el ticket)

| Ambiente | Rama | PR | Build Jenkins | `run_id` | Resultado `perf_timings` | Evidencia |
|----------|------|----|---------------|----------|--------------------------|-----------|
| DEV | *(completar)* | *(completar)* | *(URL build)* | `benchmark_20k_batch_v1` | 10/10 OK · ~33 s | Informe DEV local |
| QA | `QA/<ID_HU>` | *(URL PR)* | *(URL build)* | `benchmark_20k_batch_qa_v1` | **10/10 OK · ~153 s** | Captura DBeaver adjunta |
| PDN | `PDN/<ID_HU>` | *(URL PR)* | *(URL build)* | `benchmark_20k_batch_pdn_v1` | Pendiente | — |

**Repos Bitbucket usados**

| Repo | URL | Rol en HU |
|------|-----|-----------|
| db_rcncr_btch_rdshft_dt | https://code.experian.local/projects/COAWSPPR/repos/db_rcncr_btch_rdshft_dt | Deploy del script |
| db_rcncr_btch_rdshft_strct | https://code.experian.local/projects/COAWSPPR/repos/db_rcncr_btch_rdshft_strct | No aplica (vacío) |
| db_rcncr_btch_rdshft_pgm | https://code.experian.local/projects/COAWSPPR/repos/db_rcncr_btch_rdshft_pgm | No aplica (vacío) |

**SNOW:** CHG2962599 · **App ID:** 31343 · **Requiere transición:** NO

---

## 7. Validación funcional documentada (CA-05 / soporte CA-01)

| Check | Resultado QA |
|-------|--------------|
| Script ejecutado completo vía pipeline / DBeaver | Sí |
| Cascada R1 → R2 (motor batch 1×) → R3 | Sí (hitos 2–9 OK) |
| Dataset sintético 20K personas | Sí (DATA_LOAD OK) |
| Todos los hitos `status = OK` | Sí (10/10) |
| Esquema | `bdm_stage` |
| Impacto en objetos productivos permanentes | No — objetos mock + staging; rollback vía RevSQL |

---

## 8. Relación con el material local de demo

| Origen local | Uso |
|--------------|-----|
| `demo_unificacion_completa/Benchmark_20K/00_run_benchmark_20k_batch.sql` | Canon DBeaver / fuente del consolidado |
| `demo_unificacion_completa/INFORME_BENCHMARK_20K_BATCH.md` | Referencia DEV (~33 s) |
| `db_rcncr_btch_rdshft_dt/deploy/redshift/SQL/...` | Artefacto que despliega Jenkins |

---

## 9. Checklist rápido para cerrar la HU

- [x] Entender rol de `_dt` / `_strct` / `_pgm`
- [x] CA-00 artefactos `deploy.par` / `rollback.par` en `_dt`
- [x] CA-01 evidencias QA (`perf_timings` 10/10 OK)
- [ ] Completar URLs de PR y Jenkins en §6
- [ ] Confirmar grants QA/PDN
- [ ] CA-02: cambiar `run_id` a `benchmark_20k_batch_pdn_v1`, ventana, PR, deploy PDN
- [ ] CA-03: evidencia de prueba de rollback en no-PDN + contacto contingencia
- [ ] Adjuntar este documento + capturas al ticket y cerrar sub-tareas

---

*Documento generado para soporte de la HU de promoción Benchmark 20K (App 31343 / CHG2962599).*
