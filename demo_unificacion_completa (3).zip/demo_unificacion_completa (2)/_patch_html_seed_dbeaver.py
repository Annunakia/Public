# -*- coding: utf-8 -*-
"""HTML = seed validado: queries DBeaver deben devolver las mismas filas (no 'MOCK UP')."""
from __future__ import annotations

import json
import re
import shutil
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
]

# Labels por pack_code (seed SP)
LABELS = {
    "RESUMEN": ("SP seed · catálogo 20001–20014", "SEED"),
    "DIR-RANK": ("SP seed · RANK-01 · CA-O04 · id 20001", "SEED"),
    "ELEG-HIJA": ("SP seed · F3-02 · CA-O05 · id 20011", "SEED"),
    "ELEG-BLOQ": ("SP seed · TEL NO VÁLIDO · id 20004", "SEED"),
    "DIR-EMPATE": ("SP seed · RANK-02 · CA-O08 · id 20010", "SEED"),
    "TEL-RANK": ("SP seed · TEL · CA-O06 · id 20004", "SEED"),
    "TEL-02": ("SP seed · TEL-02 · CA-O09 · id 20013", "SEED"),
    "CEL-02": ("SP seed · CEL-02 · CA-O11 · id 20012", "SEED"),
    "EMA-03": ("SP seed · EMA-03 · CA-O10 · id 20014", "SEED"),
    "CONSOL": ("SP seed · orden_prioridad · CA-O07 · id 20001", "SEED"),
    "FLUJO": ("SP seed · veredicto CA (validar_mock)", "SEED"),
    "VALID": ("SP seed · matriz CA-O01…CA-O12", "SEED"),
}


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


OLD_IDBLOCK_FRAGMENTS = [
    # Escaped form (as stored in HTML file)
    (
        "Fuente · ${fuente === 'MOCK' ? 'MOCK UP' : 'REAL'}",
        "Fuente · ${fuente === 'REAL' ? 'REAL' : 'SEED'}",
    ),
    (
        "Fuente · ${fuente === &#x27;MOCK&#x27; ? &#x27;MOCK UP&#x27; : &#x27;REAL&#x27;}",
        "Fuente · ${fuente === &#x27;REAL&#x27; ? &#x27;REAL&#x27; : &#x27;SEED&#x27;}",
    ),
]

# Full disclaimer replacement (escaped)
OLD_DISCLAIMERS = [
    (
        "${fuente === &#x27;MOCK&#x27; ? &#x27;MOCK UP: la tabla NO es evidencia DEV. "
        "La query explica por qué no hay caso y qué check puedes correr.&#x27; : "
        "&#x27;REAL: la query debe devolver las mismas filas/números de la tabla del ejemplo.&#x27;}",
        "${fuente === &#x27;REAL&#x27; ? &#x27;REAL (bdm_datos): la query debe devolver las mismas "
        "filas/números de la tabla.&#x27; : &#x27;SEED (bdm_stage): CALL sp_ordenamiento_ejecucion_mock(); "
        "la query debe devolver exactamente las filas de esta tabla.&#x27;}",
    ),
    (
        "${fuente === 'MOCK' ? 'MOCK UP: la tabla NO es evidencia DEV. "
        "La query explica por qué no hay caso y qué check puedes correr.' : "
        "'REAL: la query debe devolver las mismas filas/números de la tabla del ejemplo.'}",
        "${fuente === 'REAL' ? 'REAL (bdm_datos): la query debe devolver las mismas "
        "filas/números de la tabla.' : 'SEED (bdm_stage): CALL sp_ordenamiento_ejecucion_mock(); "
        "la query debe devolver exactamente las filas de esta tabla.'}",
    ),
]

# Colors: SEED uses blue/slate (not orange "mock up warning")
COLOR_PATCHES = [
    (
        "const fuenteColor = fuente === 'MOCK' ? '#9a3412' : '#166534';",
        "const fuenteColor = fuente === 'REAL' ? '#166534' : '#1e3a8a';",
    ),
    (
        "const fuenteColor = fuente === &#x27;MOCK&#x27; ? &#x27;#9a3412&#x27; : &#x27;#166534&#x27;;",
        "const fuenteColor = fuente === &#x27;REAL&#x27; ? &#x27;#166534&#x27; : &#x27;#1e3a8a&#x27;;",
    ),
    (
        "const fuenteBg = fuente === 'MOCK' ? '#fff7ed' : '#f0fdf4';",
        "const fuenteBg = fuente === 'REAL' ? '#f0fdf4' : '#eff6ff';",
    ),
    (
        "const fuenteBg = fuente === &#x27;MOCK&#x27; ? &#x27;#fff7ed&#x27; : &#x27;#f0fdf4&#x27;;",
        "const fuenteBg = fuente === &#x27;REAL&#x27; ? &#x27;#f0fdf4&#x27; : &#x27;#eff6ff&#x27;;",
    ),
    (
        "const fuenteBorder = fuente === 'MOCK' ? '#fdba74' : '#86efac';",
        "const fuenteBorder = fuente === 'REAL' ? '#86efac' : '#93c5fd';",
    ),
    (
        "const fuenteBorder = fuente === &#x27;MOCK&#x27; ? &#x27;#fdba74&#x27; : &#x27;#86efac&#x27;;",
        "const fuenteBorder = fuente === &#x27;REAL&#x27; ? &#x27;#86efac&#x27; : &#x27;#93c5fd&#x27;;",
    ),
    # fuente detection default
    (
        "(String(idEj).indexOf('MOCK') >= 0 ? 'MOCK' : 'REAL')",
        "(String(idEj).indexOf('REAL') >= 0 ? 'REAL' : 'SEED')",
    ),
    (
        "(String(idEj).indexOf(&#x27;MOCK&#x27;) &gt;= 0 ? &#x27;MOCK&#x27; : &#x27;REAL&#x27;)",
        "(String(idEj).indexOf(&#x27;REAL&#x27;) &gt;= 0 ? &#x27;REAL&#x27; : &#x27;SEED&#x27;)",
    ),
]


def patch_ui(html: str) -> str:
    for old, new in OLD_IDBLOCK_FRAGMENTS + OLD_DISCLAIMERS + COLOR_PATCHES:
        if old in html:
            html = html.replace(old, new)
            print("  UI ok:", old[:50])
        else:
            # try without worrying
            pass
    # Force any remaining MOCK UP disclaimer text
    if "MOCK UP: la tabla NO es evidencia" in html:
        html = html.replace(
            "MOCK UP: la tabla NO es evidencia DEV. La query explica por qué no hay caso y qué check puedes correr.",
            "SEED (bdm_stage): CALL sp_ordenamiento_ejecucion_mock(); la query debe devolver exactamente las filas de esta tabla.",
        )
        print("  disclaimer text replaced")
    if "Fuente · ${fuente === 'MOCK' ? 'MOCK UP' : 'REAL'}" in html:
        html = html.replace(
            "Fuente · ${fuente === 'MOCK' ? 'MOCK UP' : 'REAL'}",
            "Fuente · ${fuente === 'REAL' ? 'REAL' : 'SEED'}",
        )
    # Escaped variant of Fuente line inside template - look for MOCK UP string in source
    html = html.replace("&#x27;MOCK UP&#x27;", "&#x27;SEED&#x27;")
    html = html.replace("'MOCK UP'", "'SEED'")
    return html


def patch_data(data: dict) -> int:
    n = 0
    for row in data.get("rows") or []:
        code = row.get("_pack_code")
        # Any mock example → SEED
        if row.get("_fuente") in ("MOCK", "MOCK UP", None) and row.get("_id_buro_persona") in range(
            20001, 20015
        ):
            row["_fuente"] = "SEED"
            n += 1
        if code in LABELS:
            label, fuente = LABELS[code]
            row["_fuente"] = fuente
            row["_ejemplo_label"] = label
            if row.get("_id_buro_persona"):
                row["_id_ejemplo"] = f"SEED · id_buro_persona = {row['_id_buro_persona']}"
            n += 1
        # Fix RESUMEN tabla title
        te = row.get("_tabla_ejemplo")
        if te and isinstance(te, dict) and te.get("title") and "HTML = seed" in str(te.get("title")):
            te["title"] = "Personas del seed SP (verificable en DBeaver)"
        if te and isinstance(te, dict) and te.get("title") and "SP mock" in str(te.get("title", "")):
            te["title"] = str(te["title"]).replace("SP mock", "SEED SP").replace("mock", "seed")
    # KPIs
    k = data.setdefault("kpis", {})
    k["demo_modo_html"] = "SEED_SP"
    return n


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    assert len(positions) >= 2, path
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    n = patch_data(data)
    html = html[:start] + to_html_json(data) + html[end:]
    html = patch_ui(html)
    bak = path.with_suffix(path.suffix + ".bak_seed_dbeaver")
    if not bak.exists():
        shutil.copy2(path, bak)
    path.write_text(html, encoding="utf-8")
    # verify
    remain = html.count("MOCK UP: la tabla NO")
    print(f"OK {path.name}: data_touch={n} remain_mockup_disclaimer={remain}")


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)
        else:
            print("SKIP", p)


if __name__ == "__main__":
    main()
