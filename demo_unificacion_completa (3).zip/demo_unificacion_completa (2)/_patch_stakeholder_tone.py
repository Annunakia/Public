# -*- coding: utf-8 -*-
"""Quita meta-lenguaje de 'guión/decir' y deja el HTML listo para stakeholders."""
from __future__ import annotations

import json
import re
import shutil
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
]

GUION = [
    {
        "paso": "0",
        "titulo": "Personas de ejemplo",
        "decir": (
            "Los ejemplos usan las personas del SP mock (id_buro 20001 a 20014). "
            "Cada caso muestra la persona, la regla que aplica y el resultado verificado. "
            "Para reproducir: CALL bdm_stage.sp_ordenamiento_ejecucion_mock();"
        ),
    },
    {
        "paso": "1",
        "titulo": "Unificación y Ordenamiento",
        "decir": (
            "Unificación determina si varias direcciones son la misma (padre ganador / hija). "
            "Ordenamiento, sobre las ganadoras, define qué contacto intentar primero "
            "en cada canal: DIR, TEL, CEL y EMA, de forma independiente."
        ),
    },
    {
        "paso": "2",
        "titulo": "Solo ganadoras",
        "decir": (
            "Si ind_unificacion = 1 (hija), no hay score ni orden. "
            "Solo las RPUs ganadoras reciben score (características × beta RITM) "
            "y el mayor score del canal obtiene el lugar 1."
        ),
    },
    {
        "paso": "3",
        "titulo": "Cómo leer cada caso",
        "decir": (
            "Cada tarjeta muestra: el id_buro, la regla de negocio, "
            "los pasos del caso con su evidencia, la tabla del resultado "
            "y la conclusión. La query del botón coincide con el seed del SP."
        ),
    },
    {
        "paso": "4",
        "titulo": "Casos del recorrido",
        "decir": (
            "20001 casa vs oficina (RANK-01) → 20011 padre/hija (F3) → "
            "20010 empate → 20004 TEL válido vs no válido → 20013 TEL020 → "
            "20012 CEL default → 20014 EMA → salida orden_prioridad en 20001."
        ),
    },
    {
        "paso": "5",
        "titulo": "Estado en DEV",
        "decir": (
            "Opción A EDF, 47 betas RITM, 0 hijas mal ordenadas, "
            "fórmulas TEL/EMA/CEL alineadas a Características. "
            "El mock cubre CA-O01…CA-O12 para validar sin depender del Caso A/B histórico."
        ),
    },
    {
        "paso": "6",
        "titulo": "Cierre",
        "decir": (
            "Con el veredicto PASSED_ALL del validar_mock, el paquete mock queda listo para QA. "
            "La paridad numérica Teradata (MIG-01) se trata por separado."
        ),
    },
]


def pasos(title: str, rows: list[list[str]]) -> dict:
    return {
        "title": title,
        "headers": ["Paso", "Qué ocurre", "Evidencia"],
        "rows": rows,
    }


NARR = {
    "RESUMEN": {
        "_busca": (
            "Después de R1/R2/R3, el negocio necesita saber qué contacto intentar primero. "
            "Ordenamiento trabaja solo sobre ganadoras y rankea cada canal por separado "
            "con un score relativo (características × beta), no una probabilidad."
        ),
        "_dev": (
            "Unificación ya resolvió qué direcciones son la misma. "
            "Ordenamiento toma solo las ganadoras y define el orden de intento "
            "(por ejemplo, casa vs oficina). "
            "Los ejemplos usan el catálogo del SP: personas 20001–20014."
        ),
        "_conclusion_regla": (
            "Unificación decide quién compite; ordenamiento decide el orden de intento. "
            "El seed mock es la referencia de estos ejemplos."
        ),
        "_tabla_pasos": pasos(
            "Unificación vs Ordenamiento",
            [
                [
                    "1",
                    "Unificación responde si son la misma dirección.",
                    "Padre ganador / hija ind_unificacion=1",
                ],
                [
                    "2",
                    "Ordenamiento responde qué contacto intentar primero entre ganadoras.",
                    "Scores y lugar por canal (DIR/TEL/CEL/EMA)",
                ],
                [
                    "3",
                    "Los canales no se mezclan: el lugar 1 de TEL no compite con DIR.",
                    "mock_ord_score filtrado por canal",
                ],
            ],
        ),
    },
    "DIR-RANK": {
        "_busca": (
            "RANK-01: si una persona tiene varias direcciones ganadoras, "
            "la de mayor score DIR queda en lugar 1 y alimenta orden_prioridad."
        ),
        "_dev": (
            "Persona id_buro_persona = 20001. "
            "Entre sus direcciones ganadoras, el ranking DIR deja "
            "‘casa’ (RPU 91001) con score 850 → lugar 1, "
            "y ‘oficina’ (RPU 91002) con 700 → lugar 2. "
            "Casa es el primer contacto. "
            "TEL/EMA de la misma persona se rankean aparte y no compiten con DIR."
        ),
        "_conclusion_regla": (
            "Persona 20001: casa gana (850 / lugar 1), oficina segundo (700 / lugar 2). "
            "RANK-01 cumplido · seed del SP · CA-O04."
        ),
        "_tabla_pasos": pasos(
            "RANK-01 — persona 20001",
            [
                [
                    "1",
                    "La persona 20001 tiene dos direcciones vigentes: casa y oficina.",
                    "mock_ord_rpu WHERE id_buro_persona=20001",
                ],
                [
                    "2",
                    "Gana la dirección con mayor score DIR.",
                    "mock_ord_score canal='DIR'",
                ],
                [
                    "3",
                    "Casa=850 lugar 1; oficina=700 lugar 2 → casa es el primer contacto.",
                    "lugar ASC",
                ],
                [
                    "4",
                    "El lugar 1 queda persistido en orden_prioridad.",
                    "mock_ord_prioridad RPU 91001=1",
                ],
            ],
        ),
        "_tabla_ejemplo": {
            "title": "Persona 20001 — casa vs oficina",
            "headers": ["Etiqueta", "RPU", "Score DIR", "Lugar", "orden_prioridad", "Resultado"],
            "rows": [
                ["casa", "91001", "850.0000", "1", "1", "Primer contacto"],
                ["oficina", "91002", "700.0000", "2", "2", "Segundo intento"],
            ],
        },
    },
    "ELEG-HIJA": {
        "_busca": (
            "F3-02: si una RPU es hija de unificación (ind_unificacion=1), "
            "no recibe score ni orden_prioridad. Solo el padre ganador compite."
        ),
        "_dev": (
            "Persona id_buro_persona = 20011. "
            "RPU 91018 es el padre ganador; RPU 91019 es la hija. "
            "En score y orden_prioridad solo aparece el padre "
            "(DIR 639.7849, lugar 1, orden_prioridad=1). "
            "La hija no tiene filas: no compite; el contacto vigente es el padre."
        ),
        "_conclusion_regla": (
            "Persona 20011: padre 91018 con score y orden; hija 91019 sin score ni orden. "
            "F3-02 cumplido · CA-O05 / CA-O03."
        ),
        "_tabla_pasos": pasos(
            "F3-02 — persona 20011",
            [
                [
                    "1",
                    "La persona unificó dos direcciones: hay padre y hay hija.",
                    "mock_ord_rpu: 91018 ind NULL · 91019 ind=1",
                ],
                [
                    "2",
                    "Solo las ganadoras (ind_unificacion distinto de 1) entran al ranking.",
                    "Filtro de elegibilidad",
                ],
                [
                    "3",
                    "La hija no tiene filas de score ni de orden.",
                    "COUNT(*) hija = 0",
                ],
                [
                    "4",
                    "El padre queda en lugar 1: es el contacto a intentar.",
                    "91018 orden_prioridad=1",
                ],
            ],
        ),
        "_tabla_ejemplo": {
            "title": "Persona 20011 — padre gana / hija fuera",
            "headers": ["Rol", "RPU", "ind_unificacion", "Score DIR", "orden_prioridad", "¿Compite?"],
            "rows": [
                ["padre_ganador", "91018", "NULL", "639.7849", "1", "Sí"],
                ["hija_unif", "91019", "1", "(sin fila)", "(sin fila)", "No"],
            ],
        },
    },
    "DIR-EMPATE": {
        "_busca": (
            "RANK-02: si dos direcciones quedan con el mismo score, "
            "no se agrega un desempate de negocio nuevo; se usa ROW_NUMBER del motor. "
            "Cualquier diferencia vs baseline por empate se registra en certificación."
        ),
        "_dev": (
            "Persona id_buro_persona = 20010. "
            "Direcciones empate_a (91016) y empate_b (91017) tienen score DIR = 777.0000. "
            "Aun con score idéntico, el ranking asigna lugar 1 y lugar 2 (ROW_NUMBER). "
            "No hay criterio funcional nuevo de desempate en esta migración."
        ),
        "_conclusion_regla": (
            "Persona 20010: score empatado 777/777 → lugares 1 y 2 por ROW_NUMBER. "
            "RANK-02 · CA-O08 · sin desempate de negocio nuevo."
        ),
        "_tabla_pasos": pasos(
            "Empate — persona 20010",
            [
                [
                    "1",
                    "Dos direcciones de la misma persona con score 777.",
                    "mock_ord_score id=20010",
                ],
                [
                    "2",
                    "No se introduce un tie-break de negocio nuevo.",
                    "Doc v2.0 / baseline",
                ],
                [
                    "3",
                    "El ranking entrega lugar 1 y 2 vía ROW_NUMBER.",
                    "91016 lugar 1 · 91017 lugar 2",
                ],
                [
                    "4",
                    "Si TD y RS solo difieren por el empate, se documenta como hallazgo.",
                    "Certificación / MIG-01",
                ],
            ],
        ),
        "_tabla_ejemplo": {
            "title": "Persona 20010 — empate de score",
            "headers": ["Etiqueta", "RPU", "Score DIR", "Lugar", "Nota"],
            "rows": [
                ["empate_a", "91016", "777.0000", "1", "Mismo score — ROW_NUMBER"],
                ["empate_b", "91017", "777.0000", "2", "Mismo score — segundo"],
            ],
        },
    },
    "TEL-RANK": {
        "_busca": (
            "Canal TEL independiente de DIR: se rankea solo entre teléfonos fijos "
            "y no escribe orden_prioridad en la RPU (eso es exclusivo de DIR)."
        ),
        "_dev": (
            "Persona id_buro_persona = 20004. "
            "Teléfono válido con score 420 → lugar 1; "
            "teléfono NO VÁLIDO con score 210 → lugar 2. "
            "El primer fijo a intentar es el válido. "
            "Un DIR lugar 1 de la misma persona no se compara con el score TEL."
        ),
        "_conclusion_regla": (
            "Persona 20004: TEL válido 420/lugar 1 · NO VÁLIDO 210/lugar 2. "
            "Canal independiente de DIR · CA-O06."
        ),
        "_tabla_pasos": pasos(
            "TEL — persona 20004",
            [
                [
                    "1",
                    "La persona 20004 tiene dos fijos: uno válido y uno no válido.",
                    "mock_ord_score canal='TEL' id=20004",
                ],
                [
                    "2",
                    "El ranking es solo dentro de TEL: mayor score → lugar 1.",
                    "420 vs 210",
                ],
                [
                    "3",
                    "El válido queda en lugar 1.",
                    "tel_valida_dir",
                ],
                [
                    "4",
                    "orden_prioridad de la RPU viene de DIR, no de TEL.",
                    "Canales separados",
                ],
            ],
        ),
        "_tabla_ejemplo": {
            "title": "Persona 20004 — TEL válido vs no válido",
            "headers": ["Etiqueta", "Score TEL", "Lugar", "Resultado"],
            "rows": [
                ["tel_valida_dir", "420.0000", "1", "Primer fijo"],
                ["tel_novalida_dir", "210.0000", "2", "Menor prioridad"],
            ],
        },
    },
    "TEL-02": {
        "_busca": (
            "TEL-02: TEL020 (coincidencia geo) puede calcularse para trazabilidad, "
            "pero no entra a la sumatoria del score. "
            "Si solo cambia TEL020, el score final es el mismo."
        ),
        "_dev": (
            "Persona id_buro_persona = 20013. "
            "Contactos ‘tel_base’ y ‘tel_solo_tel020’ (diferencia solo en TEL020). "
            "Ambos quedan con score 376.5000: TEL020 está fuera de la suma, "
            "alineado al baseline Teradata."
        ),
        "_conclusion_regla": (
            "Persona 20013: mismo score 376.5 aunque solo cambie TEL020. "
            "TEL020 fuera de la suma · CA-O09."
        ),
        "_tabla_pasos": pasos(
            "TEL-02 — persona 20013",
            [
                [
                    "1",
                    "Dos contactos TEL; en uno solo varía TEL020.",
                    "mock_ord_score id=20013",
                ],
                [
                    "2",
                    "TEL020 no suma al score final.",
                    "Características / Sumatoria_Score_Tel",
                ],
                [
                    "3",
                    "Scores idénticos: 376.5 y 376.5.",
                    "Comparación de filas",
                ],
                [
                    "4",
                    "Incluir TEL020 en el ranking sería cambio de baseline, no corrección.",
                    "Alcance acordado",
                ],
            ],
        ),
        "_tabla_ejemplo": {
            "title": "Persona 20013 — TEL020 no mueve el score",
            "headers": ["Etiqueta", "Score TEL", "Lugar", "Resultado"],
            "rows": [
                ["tel_base", "376.5000", "1", "Base"],
                ["tel_solo_tel020", "376.5000", "2", "Mismo score pese a TEL020"],
            ],
        },
    },
    "CEL-02": {
        "_busca": (
            "CEL-02: el operador se toma del prefijo (LEFT celular,3). "
            "Si el prefijo no está en el catálogo, Redshift usa default 0.22 (doc v2.0)."
        ),
        "_dev": (
            "Persona id_buro_persona = 20012. "
            "Celular con prefijo 999 (fuera del catálogo). "
            "Aplica COALESCE(catálogo, 0.22) → score CEL 220.0000 lugar 1. "
            "Prefijo desconocido no cae a 0; usa el default acordado."
        ),
        "_conclusion_regla": (
            "Persona 20012: prefijo 999 sin catálogo → default 0.22 → score 220 lugar 1. "
            "CEL-02 · CA-O11."
        ),
        "_tabla_pasos": pasos(
            "CEL-02 — persona 20012",
            [
                [
                    "1",
                    "Celular con prefijo 999 no mapeado.",
                    "mock_ord_score id=20012",
                ],
                [
                    "2",
                    "LEFT(celular,3) → catálogo; si no hay fila, default 0.22.",
                    "catalogo_operador_ord_cel",
                ],
                [
                    "3",
                    "Score 220 lugar 1: se aplicó el default.",
                    "canal='CEL'",
                ],
                [
                    "4",
                    "Diferencia consciente vs TD antiguo (podía dejar 0): semántica doc v2.0.",
                    "Alcance acordado",
                ],
            ],
        ),
        "_tabla_ejemplo": {
            "title": "Persona 20012 — operador no mapeado",
            "headers": ["Etiqueta", "Prefijo", "Score CEL", "Lugar", "Resultado"],
            "rows": [
                ["cel_prefijo_999", "999", "220.0000", "1", "Default 0.22 aplicado"],
            ],
        },
    },
    "EMA-03": {
        "_busca": (
            "EMA-03: EMA003 / EMA007 / EMA018 / EMA025 pueden calcularse para trazabilidad, "
            "pero no entran a la sumatoria del score. "
            "Si solo cambian esas, el score final es idéntico."
        ),
        "_dev": (
            "Persona id_buro_persona = 20014. "
            "Emails ‘ema_base’ y ‘ema_solo_excluidas’ (solo variables fuera de suma). "
            "Ambos con score EMA = 281.7705: esas variables no mueven el ranking."
        ),
        "_conclusion_regla": (
            "Persona 20014: mismo score 281.7705 aunque solo cambien EMA003/007. "
            "Fuera de suma · CA-O10."
        ),
        "_tabla_pasos": pasos(
            "EMA-03 — persona 20014",
            [
                [
                    "1",
                    "Dos emails; el segundo solo enciende variables excluidas.",
                    "mock_ord_score id=20014 canal='EMA'",
                ],
                [
                    "2",
                    "EMA003/007/018/025 no suman al score final.",
                    "Sumatoria_Score_Email / Características",
                ],
                [
                    "3",
                    "Scores idénticos: 281.7705 = 281.7705.",
                    "Comparación de filas",
                ],
                [
                    "4",
                    "Sirven para trazabilidad, no para decidir el lugar 1.",
                    "Alcance acordado",
                ],
            ],
        ),
        "_tabla_ejemplo": {
            "title": "Persona 20014 — excluidas no mueven score",
            "headers": ["Etiqueta", "Score EMA", "Lugar", "Resultado"],
            "rows": [
                ["ema_base", "281.7705", "1", "Base"],
                ["ema_solo_excluidas", "281.7705", "2", "Mismo score pese a EMA003/007"],
            ],
        },
    },
    "CONSOL": {
        "_busca": (
            "Salida: el lugar del canal DIR de cada RPU ganadora se persiste "
            "como orden_prioridad. Las hijas no reciben fila."
        ),
        "_dev": (
            "Persona id_buro_persona = 20001 (mismo caso RANK-01). "
            "Casa quedó lugar 1 y oficina lugar 2. "
            "En orden_prioridad: RPU 91001 → 1, RPU 91002 → 2. "
            "El score decide el lugar; el lugar se materializa para el consumidor."
        ),
        "_conclusion_regla": (
            "Persona 20001: orden_prioridad casa=1 · oficina=2. "
            "Salida alineada al ranking DIR · CA-O07."
        ),
        "_tabla_pasos": pasos(
            "Salida — persona 20001",
            [
                [
                    "1",
                    "Partimos del ranking DIR (casa 1 / oficina 2).",
                    "mock_ord_score canal DIR",
                ],
                [
                    "2",
                    "Ese lugar se persiste en orden_prioridad.",
                    "mock_ord_prioridad",
                ],
                [
                    "3",
                    "91001=1 y 91002=2: mismo orden que el score.",
                    "JOIN score ↔ prioridad",
                ],
                [
                    "4",
                    "Las hijas no aparecen (ver persona 20011).",
                    "Sin fila para ind_unificacion=1",
                ],
            ],
        ),
        "_tabla_ejemplo": {
            "title": "Persona 20001 — orden_prioridad = lugar DIR",
            "headers": ["RPU", "Score DIR", "Lugar", "orden_prioridad", "¿Cuadra?"],
            "rows": [
                ["91001", "850.0000", "1", "1", "Sí"],
                ["91002", "700.0000", "2", "2", "Sí"],
            ],
        },
    },
    "ELEG-BLOQ": {
        "_busca": (
            "Datos NO VÁLIDOS / bloqueos: no deben quedar como mejor opción "
            "frente a un contacto válido del mismo canal."
        ),
        "_dev": (
            "Referencia persona 20004 (TEL): el fijo NO VÁLIDO queda en lugar 2 "
            "con score más bajo que el válido."
        ),
        "_conclusion_regla": (
            "Persona 20004: NO VÁLIDO pierde contra VÁLIDO en el mismo canal."
        ),
        "_tabla_pasos": pasos(
            "Bloqueos / NO VÁLIDO",
            [
                [
                    "1",
                    "Se identifica el contacto válido frente al no válido.",
                    "Persona 20004 TEL",
                ],
                [
                    "2",
                    "El no válido no puede quedar lugar 1 si hay uno válido mejor.",
                    "Scores 420 vs 210",
                ],
                [
                    "3",
                    "El no válido queda en lugar 2.",
                    "mock_ord_score",
                ],
            ],
        ),
    },
}


def extract_json_object(html: str, start: int) -> tuple[dict, int, int]:
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    raw = html[start:j]
    return json.loads(unescape(raw)), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def patch_ui_copy(html: str) -> str:
    replacements = [
        (
            "Guión workshop (leer en voz alta)",
            "Caso",
        ),
        (
            "Texto listo para decir en la mesa — mismo lenguaje de las transcripciones (ganadoras, catálogo betas, canales aparte).",
            "Resumen del recorrido — ganadoras, catálogo betas, canales aparte.",
        ),
        (
            "Empieza por el &lt;strong&gt;guión §0&lt;/strong&gt; (texto para decir). "
            "En cada tarjeta: persona + id → regla → qué miras → conclusión. "
            "Recorrido: 20001 → 20011 → 20010 → 20004 → 20013 → 20012 → 20014 → salida.",
            "Empieza por el &lt;strong&gt;resumen §0&lt;/strong&gt;. "
            "En cada tarjeta: persona + id → regla → evidencia → conclusión. "
            "Recorrido: 20001 → 20011 → 20010 → 20004 → 20013 → 20012 → 20014 → salida.",
        ),
        # fallback si quedó el banner viejo
        (
            "Empieza por el &lt;strong&gt;guión §0&lt;/strong&gt;; luego pestañas "
            "Fase 1 → DIR → TEL → CEL → EMA → Salida → SPs.",
            "Empieza por el &lt;strong&gt;resumen §0&lt;/strong&gt;; luego pestañas "
            "Fase 1 → DIR → TEL → CEL → EMA → Salida → SPs.",
        ),
    ]
    for old, new in replacements:
        if old in html:
            html = html.replace(old, new)
        else:
            print("WARN missing UI string:", old[:60])
    return html


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    if len(positions) < 2:
        raise SystemExit(f"{path}: expected 2 DATA blocks")

    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)

    data["guion_sesion"] = GUION
    data["generated"] = "2026-09-24"

    n = 0
    for row in data.get("rows") or []:
        code = row.get("_pack_code")
        if code not in NARR:
            continue
        for k, v in NARR[code].items():
            row[k] = v
        if "_conclusion_regla" in NARR[code]:
            row["_conclusion"] = NARR[code]["_conclusion_regla"]
        n += 1

    html = html[:start] + to_html_json(data) + html[end:]
    html = patch_ui_copy(html)

    bak = path.with_suffix(path.suffix + ".bak_stakeholder")
    if not bak.exists():
        shutil.copy2(path, bak)
    path.write_text(html, encoding="utf-8")
    print(f"OK {path}: {n} escenarios")


def main() -> None:
    for p in PATHS:
        if p.exists():
            patch_file(p)
        else:
            print("SKIP", p)


if __name__ == "__main__":
    main()
