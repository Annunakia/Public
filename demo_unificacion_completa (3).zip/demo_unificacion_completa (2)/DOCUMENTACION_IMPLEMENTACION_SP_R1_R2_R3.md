# Estado de implementación — División SQL → 3 Stored Procedures

| Campo | Valor |
|-------|-------|
| **Fecha revisión** | 2026-07-21 |
| **Fuente SQL** | `00_run_benchmark_20k_batch_exec (1).sql` (~104 KB) |
| **HU / App** | SLCOPRBA-1147 · App ID 31343 · CHG2962599 |
| **Esquema** | `bdm_stage` |
| **Estado** | **Implementado en disco** — pendiente validación DBeaver / Jenkins |

---

## 1. Resumen ejecutivo

El script monolítico del benchmark Unificación (cascada **R1 → R2 motor batch 1× → R3**) quedó **partido** en los 3 repos DATABASE-REDSHIFT:

| Repo | Rol | Estado |
|------|-----|--------|
| `db_rcncr_btch_rdshft_strct` | Tablas + catálogo + vistas | Listo |
| `db_rcncr_btch_rdshft_pgm` | **SP_R1, SP_R2, SP_R3** | Listo |
| `db_rcncr_btch_rdshft_dt` | Carga 20K + `CALL` a los 3 SPs | Listo |

**Cobertura de hitos del SQL original:** completa (DATA_LOAD y VALIDATION en DT; reglas en PGM).

---

## 2. Mapa SQL original → artefactos

### 2.1 Hitos `perf_timings` (10)

| # | step_id (origen) | Dónde quedó |
|---|------------------|-------------|
| 1 | `DATA_LOAD` | `_dt` orquestador |
| 2 | `R1` | **`sp_r1`** |
| 3 | `R2_ESC1_2` | **`sp_r2`** |
| 4 | `R2_ESC4` | **`sp_r2`** |
| 5 | `R2_ESC3_SIN_NIT` | **`sp_r2`** |
| 6 | `R2_MOTOR_BATCH_PREP` | **`sp_r2`** |
| 7 | `R2_MOTOR_BATCH_RUN` | **`sp_r2`** |
| 8 | `R2_MOTOR_BATCH_FIN` | **`sp_r2`** |
| 9 | `R3` | **`sp_r3`** |
| 10 | `VALIDATION` | `_dt` orquestador |

### 2.2 Fuentes embebidas del demo

| Fragmento original | Contenedor |
|--------------------|------------|
| `02_regla1_unificacion.sql` | `sp_r1` |
| `03_regla2_esc1_2.sql` | `sp_r2` |
| `04_regla2_esc4.sql` | `sp_r2` |
| `05_regla2_esc3_sin_nit.sql` | `sp_r2` |
| `inc_batch_motor_prep.sql` | `sp_r2` |
| `06_motor_nuevas_direcciones.sql` | `sp_r2` |
| `inc_batch_motor_finalize.sql` | `sp_r2` |
| `10_regla3_geo.sql` | `sp_r3` |
| Carga sintética 20K (`perf_*` + INSERTs) | orquestador `_dt` |
| DDL tablas / catálogo | `_strct` |

---

## 3. Inventario por repositorio

### 3.1 `db_rcncr_btch_rdshft_pgm` — Stored procedures

Ruta base: `deploy/redshift/SQL/`

| Archivo | Objeto | Tamaño approx. | Firma |
|---------|--------|----------------|-------|
| `SLCOPRBA-1147-sp_r1.sql` | `bdm_stage.sp_r1` | ~5 KB | `(p_run_id VARCHAR(64)) NONATOMIC` |
| `SLCOPRBA-1147-sp_r2.sql` | `bdm_stage.sp_r2` | ~65 KB | igual |
| `SLCOPRBA-1147-sp_r3.sql` | `bdm_stage.sp_r3` | ~14 KB | igual |

**`deploy.par`:**
```
SLCOPRBA-1147-sp_r1.sql
SLCOPRBA-1147-sp_r2.sql
SLCOPRBA-1147-sp_r3.sql
```

**Revisión técnica (2026-07-21):**

| Check | Resultado |
|-------|-----------|
| `CREATE OR REPLACE PROCEDURE` presente en los 3 | OK |
| `p_run_id` usado en timings (sin `benchmark_20k_*` hardcodeado dentro del cuerpo) | OK |
| Hitos R1 / R2×6 / R3 con BEGIN+END | OK |
| Staging volátil (`stg_*`) dentro de cada SP | OK (R1: 3 · R2: 46 · R3: 5) |
| RevSQL con `DROP PROCEDURE` | OK |

**`.jenkins.yml`:** `application: dba_batch`, `type: program`  
> Confirmar con DevSecOps si el valor exacto de `type` para paquetes PGM es `program` u otro.

### 3.2 `db_rcncr_btch_rdshft_strct` — Estructura `bdm_stage`

| Archivo | Contenido |
|---------|-----------|
| `SLCOPRBA-1147-01_bdm_stage_tables.sql` | 13 tablas (`CREATE TABLE IF NOT EXISTS`) |
| `SLCOPRBA-1147-02_bdm_stage_catalog.sql` | Seed `tipo_ubicacion_dir` + `nomenclatura` |
| `SLCOPRBA-1147-03_bdm_stage_views.sql` | 3 vistas |

**Tablas:**

1. `tipo_ubicacion_dir`
2. `nomenclatura`
3. `ubicacion_estandarizada`
4. `direccion_fisica`
5. `relacion_persona_ubicacion`
6. `ciiu_persona`
7. `reporte_relacion_persona_ubica`
8. `unificacion_direccion`
9. `diccionario_complementos`
10. `diccionario_via`
11. `relacion_ubicac_estandar_geo`
12. `bloqueo`
13. `perf_timings`

**Vistas:**

- `vw_rpu_con_direccion`
- `vw_unificacion_detalle`
- `vw_perf_timings_resumen`

### 3.3 `db_rcncr_btch_rdshft_dt` — Orquestador

| Archivo | Rol |
|---------|-----|
| `SLCOPRBA-1147-run_benchmark_20k_batch_orchestrator.sql` | **Activo en `deploy.par`** — TRUNCATE → DATA_LOAD 20K → `CALL sp_r1/r2/r3` → VALIDATION |
| `SLCOPRBA-1147-run_benchmark_20k_batch.sql` | Legado monolítico (referencia; ya no en `deploy.par`) |

**`CALL` actuales (run_id QA):**
```sql
CALL bdm_stage.sp_r1('benchmark_20k_batch_qa_v1');
CALL bdm_stage.sp_r2('benchmark_20k_batch_qa_v1');
CALL bdm_stage.sp_r3('benchmark_20k_batch_qa_v1');
```

Helpers de carga presentes en orquestador: `perf_digit`, `perf_nums`, `perf_scenario_seed`, `perf_persona`, `perf_persona_meta`.

---

## 4. Orden de despliegue / ejecución

```
1) _strct   → tablas + catálogo + vistas
2) _pgm     → CREATE PROCEDURE sp_r1, sp_r2, sp_r3
3) _dt      → carga datos + CALL cascada + timings
```

Validación post-run:

```sql
SELECT step_order, step_id, label, duration_sec, status
FROM bdm_stage.perf_timings
WHERE run_id = 'benchmark_20k_batch_qa_v1'
ORDER BY step_order;

-- Esperado: 10 filas, status = OK en todas
```

Scripts DBeaver listos en demo:

- `Benchmark_20K/00_smoke_create_sp_r1_r2_r3.sql` — solo CREATE (sin 20K)
- `Benchmark_20K/00_validate_sp_r1_r2_r3_dbeaver.sql` — STRCT + PGM + orquestador
- `Benchmark_20K/RUNBOOK_VALIDACION_SP_DBEAVER.md`

---

## 5. Diagrama lógico

```
                    ┌─────────────────────────┐
                    │  _strct (bdm_stage)     │
                    │  tablas / catálogo / VW │
                    └───────────┬─────────────┘
                                │
                    ┌───────────▼─────────────┐
                    │  _pgm                   │
                    │  sp_r1 · sp_r2 · sp_r3  │
                    └───────────┬─────────────┘
                                │ CALL
┌───────────────────────────────▼───────────────────────────────┐
│  _dt orquestador                                              │
│  DATA_LOAD 20K → CALL sp_r1 → CALL sp_r2 → CALL sp_r3 → VAL  │
│  Instrumenta: bdm_stage.perf_timings                          │
└───────────────────────────────────────────────────────────────┘
```

---

## 6. Hallazgos de la revisión (2026-07-21)

### Cumple

- Partición R1 / R2 / R3 coherente con el SQL fuente.
- Todos los `PERF:BEGIN/END` de reglas están en los SPs correctos.
- Parámetro `p_run_id` sin literales hardcodeados dentro de los cuerpos de SP.
- Orquestador invoca los 3 procedimientos en orden.
- STRCT cubre el modelo base necesario para que los SPs lean/escriban.

### Pendiente / riesgos

| Ítem | Severidad | Acción |
|------|-----------|--------|
| Validación en Redshift (DBeaver/Jenkins) aún no cerrada en este workspace | Alta | Ejecutar smoke + validate y adjuntar `perf_timings` |
| `type: program` en `_pgm/.jenkins.yml` | Media | Confirmar valor con DevSecOps EITS |
| `run_id` del orquestador fijo en `benchmark_20k_batch_qa_v1` | Media | Cambiar por ambiente (DEV/QA/PDN) antes de promover |
| SP_R2 ~65 KB / mucha lógica | Baja | Monitorear límite 2 MB de Redshift (hoy holgado); si crece, partir motor |
| Script monolítico legado sigue en `_dt/SQL` | Info | Mantener como referencia o archivar tras certificar SPs |
| Vistas STRCT son de apoyo (no estaban en el SQL original) | Info | OK si el equipo las quiere; se pueden quitar del `deploy.par` si no aplican |

---

## 7. Checklist de cierre técnico

- [x] SQL partido en 3 SPs (`sp_r1`, `sp_r2`, `sp_r3`)
- [x] Tablas/catálogo/vistas en `_strct`
- [x] Orquestador DT con `CALL`
- [x] `deploy.par` / `rollback.par` por repo
- [x] README por repo
- [ ] Smoke DBeaver: los 3 `CREATE PROCEDURE` OK
- [ ] Validate DBeaver: 10/10 hitos `OK`
- [ ] Confirmar `type` Jenkins PGM
- [ ] Commit / PR por repo con ID de sub-tarea Jira
- [ ] Promoción QA / PDN según CA de la HU

---

## 8. Rutas locales (workspace)

```
demo_unificacion_completa (2)/
├── db_rcncr_btch_rdshft_strct/deploy/redshift/...
├── db_rcncr_btch_rdshft_pgm/deploy/redshift/SQL/SLCOPRBA-1147-sp_r{1,2,3}.sql
├── db_rcncr_btch_rdshft_dt/deploy/redshift/SQL/..._orchestrator.sql
├── demo_unificacion_completa/Benchmark_20K/00_validate_sp_r1_r2_r3_dbeaver.sql
├── DOCUMENTACION_REPOS_HU_BENCHMARK_20K.md          (HU / trazabilidad)
└── DOCUMENTACION_IMPLEMENTACION_SP_R1_R2_R3.md      (este archivo)
```

---

*Documento de revisión técnica de la división a stored procedures. Complementa `DOCUMENTACION_REPOS_HU_BENCHMARK_20K.md`.*
