﻿# Ejecucion HOY en DBeaver — 4 SQL

Orden estricto:

1. `01_crear_tablas_bdm_stage.sql`  → crea tablas + catalogo
2. `02_sp_r1.sql`                   → CREATE PROCEDURE sp_r1
3. `03_sp_r2.sql`                   → CREATE PROCEDURE sp_r2
4. `04_sp_r3.sql`                   → CREATE PROCEDURE sp_r3

En cada archivo: **Alt+Shift+X** (Execute SQL Script).

Prueba rapida despues:

```sql
CALL bdm_stage.sp_r1('test_sp_hoy_v1');
-- (necesita datos en las tablas; si estan vacias, el SP corre pero no unifica)
SELECT proname FROM pg_proc p
JOIN pg_namespace n ON n.oid = p.pronamespace
WHERE n.nspname='bdm_stage' AND proname IN ('sp_r1','sp_r2','sp_r3');
```

Conexion esperada: la que envio Manuel (Redshift / dba_batch_DEV o similar).
