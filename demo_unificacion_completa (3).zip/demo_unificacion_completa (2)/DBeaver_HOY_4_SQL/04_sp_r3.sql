﻿-- ============================================================
-- SP_R3 — Regla 3
-- Archivo listo para DBeaver: Alt+Shift+X (todo el archivo)
-- Requisito: haber ejecutado 01_crear_tablas_bdm_stage.sql
-- Uso luego: CALL bdm_stage.sp_rN('tu_run_id');
-- ============================================================
-- ============================================================
-- SP_R3 — Regla 3 geo
-- Schema: bdm_stage | Pipeline: db_rcncr_btch_rdshft_pgm
-- Fuente: 00_run_benchmark_20k_batch_exec.sql
-- ============================================================
CREATE OR REPLACE PROCEDURE bdm_stage.sp_r3(p_run_id VARCHAR(64))
NONATOMIC
AS $$
BEGIN
-- HITO 9 : Regla 3
-- SOURCE: 10_regla3_geo.sql
-- ============================================================

-- PERF:BEGIN step=R3 order=9
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES (p_run_id, 9, 'R3', 'Regla 3', '10_regla3_geo.sql', GETDATE());

/* === INICIO 10_regla3_geo.sql === */
-- ============================================================
-- PASO 1: Materializar insumo de Regla 3
-- Solo registros NO unificados, tipo vía, sin modificadores
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_regla3_insumo;
CREATE TABLE bdm_stage.stg_regla3_insumo
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, tipo_via_principal, via_principal)
AS
SELECT
  rpu.cod_dw_persona_ubic,
  rpu.id_buro_persona,
  ubi.texto_ubicacion,
  df.tipo_via_principal,
  df.via_principal,
  df.via_generadora,
  df.numero_puerta,
  ubi.cod_dw_ciudad AS cod_dw_municipio,
  ubi.latitud,
  ubi.longitud,
  COALESCE(cnt.numero_entidades_reportan, 0) AS numero_entidades_reportan,
  COALESCE(MAX(rep.fecha_reporte), '1900-01-01') AS fecha_ultima_actualizacion
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
LEFT JOIN (
  SELECT cod_dw_persona_ubic, COUNT(DISTINCT id_buro_suscriptor) AS numero_entidades_reportan
  FROM bdm_stage.reporte_relacion_persona_ubica GROUP BY 1
) cnt ON rpu.cod_dw_persona_ubic = cnt.cod_dw_persona_ubic
WHERE rpu.ind_unificacion IS NULL
  -- Excluir modificadores de vía (B, C, F, BIS, etc.) y cuadrantes
  AND ubi.texto_ubicacion !~ '[0-9]{1,3}[A-Z]{1,5}| OE$| E$| NE$| SE$| O$| S$| N$| SOE$'
GROUP BY 1,2,3,4,5,6,7,8,9,10,11;


-- ============================================================
-- PASO 2: Identificar pares candidatos
-- ID_U=1: misma persona+municipio+tipo_via+via_principal+puerta, ≠ vía generadora
-- ID_U=2: misma persona+municipio+tipo_via+via_principal+via_gen, ≠ puerta (±2)
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_regla3_pares;
CREATE TABLE bdm_stage.stg_regla3_pares
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
-- Escenario 1: ≠ vía generadora
SELECT T1.*, 1 AS id_u
FROM bdm_stage.stg_regla3_insumo T1
JOIN bdm_stage.stg_regla3_insumo T2
  ON  T1.id_buro_persona     = T2.id_buro_persona
  AND T1.cod_dw_municipio    = T2.cod_dw_municipio
  AND T1.tipo_via_principal  = T2.tipo_via_principal
  AND T1.via_principal       = T2.via_principal
  AND T1.numero_puerta       = T2.numero_puerta
  AND T1.via_generadora     <> T2.via_generadora
GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12

UNION ALL

-- Escenario 2: ≠ número de puerta (±2)
SELECT T1.*, 2 AS id_u
FROM bdm_stage.stg_regla3_insumo T1
JOIN bdm_stage.stg_regla3_insumo T2
  ON  T1.id_buro_persona     = T2.id_buro_persona
  AND T1.cod_dw_municipio    = T2.cod_dw_municipio
  AND T1.tipo_via_principal  = T2.tipo_via_principal
  AND T1.via_principal       = T2.via_principal
  AND T1.via_generadora      = T2.via_generadora
  AND ABS(T1.numero_puerta - T2.numero_puerta) = 2
  AND T1.numero_puerta      <> T2.numero_puerta
GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12;


-- ============================================================
-- PASO 3: Construir diccionario de vía (frecuencias)
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_regla3_diccionario_via;
CREATE TABLE bdm_stage.stg_regla3_diccionario_via
DISTSTYLE ALL
AS
-- Via_Generadora: llave = tipo_via + via_principal + numero_puerta
SELECT
  'Via_Generadora' AS tipo,
  df.tipo_via_principal || ' ' || df.via_principal || ' ' || CAST(df.numero_puerta AS VARCHAR) AS llave,
  df.via_generadora,
  p.cod_dw_municipio,
  COUNT(rep.cod_dw_persona_ubic) AS conteo
FROM bdm_stage.direccion_fisica df
JOIN bdm_stage.ubicacion_estandarizada ue ON df.cod_dw_ubic = ue.cod_dw_ubic
JOIN bdm_stage.stg_regla3_pares p ON p.texto_ubicacion = ue.texto_ubicacion AND p.id_u = 1
JOIN bdm_stage.relacion_persona_ubicacion rpu ON df.cod_dw_ubic = rpu.cod_dw_ubic AND df.cod_dw_direccion_fisica = rpu.cod_dw_direccion_fisica
JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
GROUP BY 1,2,3,4

UNION ALL

-- Numero_Puerta: llave = tipo_via + via_principal + via_generadora
SELECT
  'Numero_Puerta' AS tipo,
  df.tipo_via_principal || ' ' || df.via_principal || ' ' || CAST(df.via_generadora AS VARCHAR) AS llave,
  df.numero_puerta AS via_generadora,
  p.cod_dw_municipio,
  COUNT(rep.cod_dw_persona_ubic) AS conteo
FROM bdm_stage.direccion_fisica df
JOIN bdm_stage.ubicacion_estandarizada ue ON df.cod_dw_ubic = ue.cod_dw_ubic
JOIN bdm_stage.stg_regla3_pares p ON p.texto_ubicacion = ue.texto_ubicacion AND p.id_u = 2
JOIN bdm_stage.relacion_persona_ubicacion rpu ON df.cod_dw_ubic = rpu.cod_dw_ubic AND df.cod_dw_direccion_fisica = rpu.cod_dw_direccion_fisica
JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
GROUP BY 1,2,3,4;


-- Persistir diccionario en bdm_stage para referencia
DELETE FROM bdm_stage.diccionario_via WHERE 1=1;
INSERT INTO bdm_stage.diccionario_via SELECT * FROM bdm_stage.stg_regla3_diccionario_via;

-- ============================================================
-- PASO 4: Calcular score unificado (combina los 3 subcasos)
-- Score = geo_component + fecha_component + entidades
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_regla3_scored;
CREATE TABLE bdm_stage.stg_regla3_scored
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  v.*,
  CASE
    -- Escenario 1: ≠ vía generadora
    WHEN v.id_u = 1 THEN
      CASE WHEN NULLIF(v.latitud, 0) IS NOT NULL AND NULLIF(v.longitud, 0) IS NOT NULL
        THEN 100000000 + COALESCE(dvv.conteo, 0) ELSE 0 END
      + CASE WHEN NULLIF(v.latitud, 0) IS NULL OR NULLIF(v.longitud, 0) IS NULL
        THEN COALESCE(CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR), '-', '') AS BIGINT), 0) ELSE 0 END
      + COALESCE(v.numero_entidades_reportan, 0)
    -- Escenario 2: ≠ número de puerta
    WHEN v.id_u = 2 THEN
      CASE WHEN NULLIF(v.latitud, 0) IS NOT NULL AND NULLIF(v.longitud, 0) IS NOT NULL
        THEN 100000000 + COALESCE(dvp.conteo, 0) ELSE 0 END
      + CASE WHEN NULLIF(v.latitud, 0) IS NULL AND NULLIF(v.longitud, 0) IS NULL
        THEN COALESCE(CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR), '-', '') AS BIGINT), 0) ELSE 0 END
      + COALESCE(v.numero_entidades_reportan, 0)
    ELSE 0
  END AS id_unificacion,

  -- Rankings por escenario
  ROW_NUMBER() OVER (PARTITION BY v.tipo_via_principal, v.via_principal, v.via_generadora,
    v.id_buro_persona, v.cod_dw_municipio
    ORDER BY CASE WHEN v.id_u=1 THEN
      CASE WHEN NULLIF(v.latitud,0) IS NOT NULL AND NULLIF(v.longitud,0) IS NOT NULL THEN 100000000+COALESCE(dvv.conteo,0) ELSE 0 END
      + CASE WHEN NULLIF(v.latitud,0) IS NULL OR NULLIF(v.longitud,0) IS NULL THEN COALESCE(CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR),'-','') AS BIGINT),0) ELSE 0 END
      + COALESCE(v.numero_entidades_reportan,0) ELSE 0 END DESC) AS id1,

  ROW_NUMBER() OVER (PARTITION BY v.tipo_via_principal, v.via_principal, v.numero_puerta,
    v.id_buro_persona, v.cod_dw_municipio
    ORDER BY CASE WHEN v.id_u=2 THEN
      CASE WHEN NULLIF(v.latitud,0) IS NOT NULL AND NULLIF(v.longitud,0) IS NOT NULL THEN 100000000+COALESCE(dvp.conteo,0) ELSE 0 END
      + CASE WHEN NULLIF(v.latitud,0) IS NULL AND NULLIF(v.longitud,0) IS NULL THEN COALESCE(CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR),'-','') AS BIGINT),0) ELSE 0 END
      + COALESCE(v.numero_entidades_reportan,0) ELSE 0 END DESC) AS id2,

  -- Detectar empates
  COUNT(*) OVER (PARTITION BY v.tipo_via_principal, v.via_principal, v.via_generadora,
    v.id_buro_persona, v.cod_dw_municipio,
    CASE WHEN v.id_u=1 THEN
      CASE WHEN NULLIF(v.latitud,0) IS NOT NULL AND NULLIF(v.longitud,0) IS NOT NULL THEN 100000000+COALESCE(dvv.conteo,0) ELSE 0 END
      + CASE WHEN NULLIF(v.latitud,0) IS NULL OR NULLIF(v.longitud,0) IS NULL THEN COALESCE(CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR),'-','') AS BIGINT),0) ELSE 0 END
      + COALESCE(v.numero_entidades_reportan,0) ELSE 0 END) AS cantidad1,

  COUNT(*) OVER (PARTITION BY v.tipo_via_principal, v.via_principal, v.numero_puerta,
    v.id_buro_persona, v.cod_dw_municipio,
    CASE WHEN v.id_u=2 THEN
      CASE WHEN NULLIF(v.latitud,0) IS NOT NULL AND NULLIF(v.longitud,0) IS NOT NULL THEN 100000000+COALESCE(dvp.conteo,0) ELSE 0 END
      + CASE WHEN NULLIF(v.latitud,0) IS NULL AND NULLIF(v.longitud,0) IS NULL THEN COALESCE(CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR),'-','') AS BIGINT),0) ELSE 0 END
      + COALESCE(v.numero_entidades_reportan,0) ELSE 0 END) AS cantidad2

FROM bdm_stage.stg_regla3_pares v
-- Diccionario vía generadora
LEFT JOIN bdm_stage.stg_regla3_diccionario_via dvv
  ON v.tipo_via_principal || ' ' || v.via_principal || ' ' || CAST(v.numero_puerta AS VARCHAR) = dvv.llave
  AND v.via_generadora = dvv.via_generadora
  AND v.cod_dw_municipio = dvv.cod_dw_municipio
  AND dvv.tipo = 'Via_Generadora'
-- Diccionario número puerta
LEFT JOIN bdm_stage.stg_regla3_diccionario_via dvp
  ON v.tipo_via_principal || ' ' || v.via_principal || ' ' || CAST(v.via_generadora AS VARCHAR) = dvp.llave
  AND v.numero_puerta = dvp.via_generadora
  AND dvp.tipo = 'Numero_Puerta';


-- ============================================================
-- PASO 5: Generar pares padre-hijo
-- Escenario 1 (ID_U=1): partición por tipo_via+via_principal+puerta
-- Escenario 2 (ID_U=2): partición por tipo_via+via_principal+via_gen
-- Empate (cantidad>1) → no unifica
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_regla3_resultado;
CREATE TABLE bdm_stage.stg_regla3_resultado
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
-- Escenario 1: ≠ vía generadora
SELECT T1.cod_dw_persona_ubic, T2.cod_dw_persona_ubic AS cod_dw_direccion_unificada
FROM bdm_stage.stg_regla3_scored T1
JOIN (
  SELECT cod_dw_persona_ubic, id_buro_persona, cod_dw_municipio, tipo_via_principal, via_principal, numero_puerta, via_generadora, id_unificacion
  FROM bdm_stage.stg_regla3_scored
  WHERE cantidad1 = 1 AND id_u = 1 AND id1 = 1
) T2
  ON  T1.id_buro_persona    = T2.id_buro_persona
  AND T1.cod_dw_municipio   = T2.cod_dw_municipio
  AND T1.tipo_via_principal  = T2.tipo_via_principal
  AND T1.via_principal       = T2.via_principal
  AND T1.numero_puerta       = T2.numero_puerta
  AND T1.via_generadora     <> T2.via_generadora
  AND T1.id_unificacion     <= T2.id_unificacion
  AND T1.cod_dw_persona_ubic <> T2.cod_dw_persona_ubic
WHERE T1.id_u = 1

UNION ALL

-- Escenario 2: ≠ número de puerta
SELECT T1.cod_dw_persona_ubic, T2.cod_dw_persona_ubic AS cod_dw_direccion_unificada
FROM bdm_stage.stg_regla3_scored T1
JOIN (
  SELECT cod_dw_persona_ubic, id_buro_persona, cod_dw_municipio, tipo_via_principal, via_principal, via_generadora, numero_puerta, id_unificacion
  FROM bdm_stage.stg_regla3_scored
  WHERE cantidad2 = 1 AND id_u = 2 AND id2 = 1
) T2
  ON  T1.id_buro_persona    = T2.id_buro_persona
  AND T1.cod_dw_municipio   = T2.cod_dw_municipio
  AND T1.tipo_via_principal  = T2.tipo_via_principal
  AND T1.via_principal       = T2.via_principal
  AND T1.via_generadora      = T2.via_generadora
  AND T1.numero_puerta      <> T2.numero_puerta
  AND T1.id_unificacion     <= T2.id_unificacion
  AND T1.cod_dw_persona_ubic <> T2.cod_dw_persona_ubic
WHERE T1.id_u = 2;


-- ============================================================
-- PASO 6: Persistir
-- ============================================================
INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  1 AS unifica_atributos,
  CURRENT_DATE AS fecha_unificacion,
  1 AS lote,
  1 AS severidad,
  LEFT(CURRENT_USER, 30) AS usuario_bd
FROM bdm_stage.stg_regla3_resultado;

UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla3_resultado
);

-- ============================================================
-- PASO 7: Estadísticas y limpieza
-- ============================================================

DROP TABLE IF EXISTS bdm_stage.stg_regla3_insumo;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_pares;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_diccionario_via;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_scored;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_resultado;
/* === FIN 10_regla3_geo.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = p_run_id AND step_id = 'R3' AND ended_at IS NULL;
-- PERF:END step=R3


END;
$$ LANGUAGE plpgsql;

