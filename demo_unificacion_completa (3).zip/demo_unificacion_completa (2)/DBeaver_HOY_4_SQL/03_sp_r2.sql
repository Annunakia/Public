﻿-- ============================================================
-- SP_R2 — Regla 2 + motor batch
-- Archivo listo para DBeaver: Alt+Shift+X (todo el archivo)
-- Requisito: haber ejecutado 01_crear_tablas_bdm_stage.sql
-- Uso luego: CALL bdm_stage.sp_rN('tu_run_id');
-- ============================================================
-- ============================================================
-- SP_R2 — Regla 2 escenarios + motor batch 1x
-- Schema: bdm_stage | Pipeline: db_rcncr_btch_rdshft_pgm
-- Fuente: 00_run_benchmark_20k_batch_exec.sql
-- ============================================================
CREATE OR REPLACE PROCEDURE bdm_stage.sp_r2(p_run_id VARCHAR(64))
NONATOMIC
AS $$
BEGIN
-- HITO 3 : R2 Escenarios 1 y 2
-- SOURCE: 03_regla2_esc1_2.sql
-- ============================================================

-- PERF:BEGIN step=R2_ESC1_2 order=3
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES (p_run_id, 3, 'R2_ESC1_2', 'R2 Escenarios 1 y 2', '03_regla2_esc1_2.sql', GETDATE());

/* === INICIO 03_regla2_esc1_2.sql === */
-- PASO 1: Materializar insumo de Regla 2
-- Solo registros NO unificados por Regla 1 (ind_unificacion IS NULL)
DROP TABLE IF EXISTS bdm_stage.stg_regla2_insumo;
CREATE TABLE bdm_stage.stg_regla2_insumo
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, texto_ubicacion)
AS
SELECT
  rpu.cod_dw_persona_ubic,
  rpu.cod_pin_persona,
  rpu.id_buro_persona,
  rpu.cod_dw_tipo_ubicacion_dir,
  rpu.cod_dw_ubic,
  ubi.texto_ubicacion,
  rpu.cod_dw_direccion_fisica,
  df.complemento,
  rpu.cod_dw_tipo_ubicacion_dir AS cod_dw_municipio,  -- TODO: confirmar campo municipio real
  COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor), 0) AS numero_entidades_reportan,
  rpu.fecha_relacion_persona_ubicaci
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi
  ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df
  ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
JOIN bdm_stage.reporte_relacion_persona_ubica rep
  ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
WHERE rpu.ind_unificacion IS NULL
GROUP BY 1,2,3,4,5,6,7,8,9,11;


-- PASO 2: Escenario 1 — Un complemento vacío, otro no
-- A tiene complemento, B no → B es hijo de A
-- A no tiene complemento, B sí → A es hijo de B
DROP TABLE IF EXISTS bdm_stage.stg_regla2_esc1_pares;
CREATE TABLE bdm_stage.stg_regla2_esc1_pares
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT cod_dw_persona_ubic, id_padre
FROM (
  -- Caso 1: B no tiene complemento → B es hijo, A es padre
  SELECT
    b.cod_dw_persona_ubic,
    a.cod_dw_persona_ubic AS id_padre,
    ROW_NUMBER() OVER (PARTITION BY b.cod_dw_persona_ubic ORDER BY a.cod_dw_persona_ubic DESC) AS rn
  FROM bdm_stage.stg_regla2_insumo a
  JOIN bdm_stage.stg_regla2_insumo b
    ON  a.id_buro_persona           = b.id_buro_persona
    AND a.texto_ubicacion            = b.texto_ubicacion
    AND a.cod_dw_tipo_ubicacion_dir  = b.cod_dw_tipo_ubicacion_dir
    AND a.cod_dw_municipio           = b.cod_dw_municipio
    AND a.cod_dw_persona_ubic       <> b.cod_dw_persona_ubic
  WHERE a.complemento IS NOT NULL
    AND b.complemento IS NULL

  UNION ALL

  -- Caso 2: A no tiene complemento → A es hijo, B es padre
  SELECT
    a.cod_dw_persona_ubic,
    b.cod_dw_persona_ubic AS id_padre,
    ROW_NUMBER() OVER (PARTITION BY a.cod_dw_persona_ubic ORDER BY b.cod_dw_persona_ubic DESC) AS rn
  FROM bdm_stage.stg_regla2_insumo a
  JOIN bdm_stage.stg_regla2_insumo b
    ON  a.id_buro_persona           = b.id_buro_persona
    AND a.texto_ubicacion            = b.texto_ubicacion
    AND a.cod_dw_tipo_ubicacion_dir  = b.cod_dw_tipo_ubicacion_dir
    AND a.cod_dw_municipio           = b.cod_dw_municipio
    AND a.cod_dw_persona_ubic       <> b.cod_dw_persona_ubic
  WHERE b.complemento IS NOT NULL
    AND a.complemento IS NULL
)
WHERE rn = 1;


-- PASO 3: Construir tabla intermedia E1 con marca de unificación
-- Hereda todos los registros del insumo, marcando hijos del Esc 1
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e1;
CREATE TABLE bdm_stage.stg_regla2_e1
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, texto_ubicacion)
AS
SELECT
  a.cod_dw_persona_ubic,
  b.id_padre,
  a.id_buro_persona,
  a.cod_dw_tipo_ubicacion_dir,
  a.cod_dw_ubic,
  a.texto_ubicacion,
  a.cod_dw_direccion_fisica,
  a.complemento,
  a.cod_dw_municipio,
  a.numero_entidades_reportan,
  a.fecha_relacion_persona_ubicaci,
  CASE WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S' ELSE 'N' END AS ind_unificacion,
  CASE WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'H1' END AS n_id,
  ROW_NUMBER() OVER (
    PARTITION BY a.id_buro_persona, a.cod_dw_ubic,
      CASE WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S' ELSE 'N' END,
      a.cod_dw_tipo_ubicacion_dir
    ORDER BY a.complemento
  ) AS row_u
FROM bdm_stage.stg_regla2_insumo a
LEFT JOIN bdm_stage.stg_regla2_esc1_pares b
  ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic;


-- PASO 4: Escenario 2 — Un complemento incluido en otro
-- Solo procesa registros con ind_unificacion='N' (no unificados por Esc 1)
-- A.COMPLEMENTO contiene B.COMPLEMENTO → B es hijo de A
DROP TABLE IF EXISTS bdm_stage.stg_regla2_esc2_pares;
CREATE TABLE bdm_stage.stg_regla2_esc2_pares
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT cod_dw_persona_ubic, id_padre
FROM (
  -- Caso 1: B contenido en A → B es hijo
  SELECT
    b.cod_dw_persona_ubic,
    a.cod_dw_persona_ubic AS id_padre,
    ROW_NUMBER() OVER (PARTITION BY b.cod_dw_persona_ubic ORDER BY b.cod_dw_persona_ubic DESC) AS rn
  FROM bdm_stage.stg_regla2_e1 a
  JOIN bdm_stage.stg_regla2_e1 b
    ON  a.id_buro_persona           = b.id_buro_persona
    AND a.texto_ubicacion            = b.texto_ubicacion
    AND a.cod_dw_tipo_ubicacion_dir  = b.cod_dw_tipo_ubicacion_dir
    AND a.cod_dw_municipio           = b.cod_dw_municipio
    AND a.cod_dw_persona_ubic       <> b.cod_dw_persona_ubic
    AND a.complemento               <> b.complemento
  WHERE a.complemento LIKE '%' || b.complemento || '%'
    AND a.ind_unificacion = 'N'

  UNION ALL

  -- Caso 2: A contenido en B → A es hijo
  SELECT
    a.cod_dw_persona_ubic,
    b.cod_dw_persona_ubic AS id_padre,
    ROW_NUMBER() OVER (PARTITION BY a.cod_dw_persona_ubic ORDER BY a.cod_dw_persona_ubic DESC) AS rn
  FROM bdm_stage.stg_regla2_e1 a
  JOIN bdm_stage.stg_regla2_e1 b
    ON  a.id_buro_persona           = b.id_buro_persona
    AND a.texto_ubicacion            = b.texto_ubicacion
    AND a.cod_dw_tipo_ubicacion_dir  = b.cod_dw_tipo_ubicacion_dir
    AND a.cod_dw_municipio           = b.cod_dw_municipio
    AND a.cod_dw_persona_ubic       <> b.cod_dw_persona_ubic
    AND a.complemento               <> b.complemento
  WHERE b.complemento LIKE '%' || a.complemento || '%'
    AND a.ind_unificacion = 'N'
)
WHERE rn = 1;


-- PASO 5: Construir tabla E2 acumulada (hereda Esc 1 + agrega Esc 2)
-- Esta tabla será input para escenarios 3-6 en el siguiente script
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e2;
CREATE TABLE bdm_stage.stg_regla2_e2
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, texto_ubicacion)
AS
SELECT
  a.cod_dw_persona_ubic,
  CASE WHEN a.id_padre IS NOT NULL THEN a.id_padre ELSE b.id_padre END AS id_padre,
  a.id_buro_persona,
  a.cod_dw_tipo_ubicacion_dir,
  a.cod_dw_ubic,
  a.texto_ubicacion,
  a.cod_dw_direccion_fisica,
  a.complemento,
  a.cod_dw_municipio,
  a.numero_entidades_reportan,
  a.fecha_relacion_persona_ubicaci,
  CASE
    WHEN a.ind_unificacion = 'S' THEN 'S'
    WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S'
    ELSE 'N'
  END AS ind_unificacion,
  CASE
    WHEN a.n_id IS NOT NULL THEN a.n_id
    WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'K2'
  END AS n_id,
  ROW_NUMBER() OVER (
    PARTITION BY a.id_buro_persona, a.cod_dw_ubic,
      CASE
        WHEN a.ind_unificacion = 'S' THEN 'S'
        WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S'
        ELSE 'N'
      END,
      a.cod_dw_tipo_ubicacion_dir
    ORDER BY a.complemento
  ) AS row_u
FROM bdm_stage.stg_regla2_e1 a
LEFT JOIN bdm_stage.stg_regla2_esc2_pares b
  ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic;


-- PASO 6: Persistir pares padre-hijo de Esc 1 y 2 en tabla de unificación
INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT
  e.cod_dw_persona_ubic,
  e.id_padre AS cod_dw_direccion_unificada,
  2 AS unifica_atributos,
  CURRENT_DATE AS fecha_unificacion,
  1 AS lote,
  1 AS severidad,
  LEFT(CURRENT_USER, 30) AS usuario_bd
FROM bdm_stage.stg_regla2_e2 e
WHERE e.ind_unificacion = 'S'
  AND e.id_padre IS NOT NULL;

-- PASO 7: Marcar hijos en relacion_persona_ubicacion
UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic
  FROM bdm_stage.stg_regla2_e2
  WHERE ind_unificacion = 'S'
    AND id_padre IS NOT NULL
);

-- PASO 8: Actualizar estadísticas

-- PASO 9: Limpiar staging de escenarios 1-2
-- NOTA: stg_regla2_e2 se mantiene como input para escenarios 3-6
DROP TABLE IF EXISTS bdm_stage.stg_regla2_insumo;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_esc1_pares;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e1;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_esc2_pares;
/* === FIN 03_regla2_esc1_2.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = p_run_id AND step_id = 'R2_ESC1_2' AND ended_at IS NULL;
-- PERF:END step=R2_ESC1_2


-- ============================================================
-- HITO 4 : R2 Escenario 4
-- SOURCE: 04_regla2_esc4.sql
-- ============================================================

-- PERF:BEGIN step=R2_ESC4 order=4
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES (p_run_id, 4, 'R2_ESC4', 'R2 Escenario 4', '04_regla2_esc4.sql', GETDATE());

/* === INICIO 04_regla2_esc4.sql === */
-- PASO 1: Filtrar no-unificados con complemento diferente
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04;
CREATE TABLE bdm_stage.stg_regla2_e04
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT A.*
FROM (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') A
JOIN (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.complemento              <> B.complemento;


-- PASO 2: Identificar nomenclaturas de cada complemento
-- NMC1 = nomenclatura al inicio del complemento (ej: "CS" de "CS 312")
-- NMC2 = nomenclatura secundaria en medio del complemento (si existe)
-- COMPLEMENTO2 = complemento sin las nomenclaturas (solo valores numéricos)
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_a;
CREATE TABLE bdm_stage.stg_regla2_e04_a
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT
  A.*,
  NMC1.nomenclatura AS nomenclatura_pri,
  NMC1.nivel_complemento AS nivel_pri,
  NMC2.nomenclatura AS nomenclatura_sec,
  NMC2.nivel_complemento AS nivel_sec,
  TRIM(REPLACE(REPLACE(A.complemento, COALESCE(NMC1.nomenclatura,''), ''), COALESCE(NMC2.nomenclatura,''), '')) AS complemento2
FROM bdm_stage.stg_regla2_e04 A
LEFT JOIN bdm_stage.nomenclatura NMC1
  ON A.complemento LIKE TRIM(NMC1.nomenclatura) || ' %'
LEFT JOIN bdm_stage.nomenclatura NMC2
  ON A.complemento LIKE '% ' || TRIM(NMC2.nomenclatura) || ' %'
  AND NMC2.nomenclatura <> COALESCE(NMC1.nomenclatura, '');


-- PASO 3: Filtrar pares donde nomenclaturas están al mismo nivel
-- Caso 1: misma nomenclatura primaria, diferente secundaria, mismo nivel secundario
-- Caso 2: diferente nomenclatura primaria, misma secundaria, mismo nivel primario
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_c;
CREATE TABLE bdm_stage.stg_regla2_e04_c
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT * FROM (
  -- Caso 1: misma nomenclatura primaria, ≠ secundaria, mismo nivel secundario
  SELECT A.*
  FROM bdm_stage.stg_regla2_e04_a A
  JOIN bdm_stage.stg_regla2_e04_a B
    ON  A.id_buro_persona          = B.id_buro_persona
    AND A.texto_ubicacion           = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
    AND A.cod_dw_municipio          = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
    AND A.complemento              <> B.complemento
    AND (A.complemento2 LIKE '%' || B.complemento2 || '%'
         OR B.complemento2 LIKE '%' || A.complemento2 || '%')
    AND A.nomenclatura_pri = B.nomenclatura_pri
    AND COALESCE(A.nomenclatura_sec, 'X') <> COALESCE(B.nomenclatura_sec, 'X')
    AND COALESCE(A.nivel_sec, 0) = COALESCE(B.nivel_sec, 0)

  UNION ALL

  -- Caso 2: ≠ nomenclatura primaria, misma secundaria, mismo nivel primario
  SELECT A.*
  FROM bdm_stage.stg_regla2_e04_a A
  JOIN bdm_stage.stg_regla2_e04_a B
    ON  A.id_buro_persona          = B.id_buro_persona
    AND A.texto_ubicacion           = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
    AND A.cod_dw_municipio          = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
    AND A.complemento              <> B.complemento
    AND (A.complemento2 LIKE '%' || B.complemento2 || '%'
         OR B.complemento2 LIKE '%' || A.complemento2 || '%')
    AND A.nomenclatura_pri <> B.nomenclatura_pri
    AND COALESCE(A.nomenclatura_sec, 'X') = COALESCE(B.nomenclatura_sec, 'X')
    AND A.nivel_pri = B.nivel_pri
) sub;


-- PASO 4: Sumar frecuencias del DICCIONARIO_COMPLEMENTOS por persona/ubicación
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_c1;
CREATE TABLE bdm_stage.stg_regla2_e04_c1
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT
  t1.cod_dw_persona_ubic,
  COALESCE(t2.conteo, 0) AS conteo
FROM bdm_stage.stg_regla2_e04_c t1
LEFT JOIN (
  SELECT t1.cod_dw_persona_ubic, SUM(dc.frecuencia) AS conteo
  FROM bdm_stage.stg_regla2_e04_c t1
  LEFT JOIN bdm_stage.diccionario_complementos dc
    ON  t1.cod_dw_ubic = dc.cod_dw_ubic
    AND t1.complemento LIKE '%' || dc.nomenclatura || '%'
    AND t1.id_buro_persona = dc.id_buro_persona
  GROUP BY 1
) t2 ON t1.cod_dw_persona_ubic = t2.cod_dw_persona_ubic;


-- PASO 5: Calcular score y detectar empates
-- Score = (frecuencia_diccionario + 10000000) + fecha_como_entero
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_d;
CREATE TABLE bdm_stage.stg_regla2_e04_d
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  u1.*,
  COUNT(*) OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id
  ) AS count_empate,
  MAX(id) OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio
  ) AS idmax,
  CASE
    WHEN COUNT(*) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id) > 1
         AND MAX(id) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio) > id
    THEN 1
    WHEN COUNT(*) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id) = 1
    THEN 1
    ELSE 0
  END AS empate
FROM (
  SELECT
    a.cod_dw_persona_ubic,
    (COALESCE(b.conteo, 0) + 10000000)
      + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0) AS id,
    a.texto_ubicacion,
    a.fecha_relacion_persona_ubicaci,
    a.numero_entidades_reportan,
    a.id_buro_persona,
    a.cod_dw_tipo_ubicacion_dir,
    a.cod_dw_municipio,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
      ORDER BY (COALESCE(b.conteo, 0) + 10000000)
        + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0)
    ) AS orden,
    a.cod_dw_ubic,
    a.complemento
  FROM bdm_stage.stg_regla2_e04_c a
  LEFT JOIN bdm_stage.stg_regla2_e04_c1 b
    ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
) u1;


-- PASO 6: Generar pares padre-hijo (mayor score = padre)
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_e;
CREATE TABLE bdm_stage.stg_regla2_e04_e
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT
  B.cod_dw_persona_ubic,
  A.cod_dw_persona_ubic AS id_padre
FROM bdm_stage.stg_regla2_e04_d A
JOIN bdm_stage.stg_regla2_e04_d B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.id > B.id
JOIN (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio,
         MAX(orden) AS max_orden
  FROM bdm_stage.stg_regla2_e04_d
  GROUP BY 1,2,3,4
) mx
  ON  A.id_buro_persona          = mx.id_buro_persona
  AND A.texto_ubicacion           = mx.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = mx.cod_dw_municipio
  AND A.orden = mx.max_orden;


-- PASO 7: Actualizar tabla E2 acumulada con pares del Escenario 4
UPDATE bdm_stage.stg_regla2_e2
SET id_padre = e.id_padre,
    ind_unificacion = 'S',
    n_id = 'B5'
FROM bdm_stage.stg_regla2_e04_e e
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = e.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.id_padre IS NULL;

-- PASO 8: Persistir pares en tabla de unificación
INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT
  e.cod_dw_persona_ubic,
  e.id_padre AS cod_dw_direccion_unificada,
  2 AS unifica_atributos,
  CURRENT_DATE AS fecha_unificacion,
  1 AS lote,
  1 AS severidad,
  LEFT(CURRENT_USER, 30) AS usuario_bd
FROM bdm_stage.stg_regla2_e04_e e;

-- PASO 9: Marcar hijos
UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e04_e
);

-- PASO 10: Estadísticas

-- PASO 11: Limpiar staging del escenario 4
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_a;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_c;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_c1;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_d;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_e;
/* === FIN 04_regla2_esc4.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = p_run_id AND step_id = 'R2_ESC4' AND ended_at IS NULL;
-- PERF:END step=R2_ESC4


-- ============================================================
-- HITO 5 : R2 Esc 3 sin NIT
-- SOURCE: 05_regla2_esc3_sin_nit.sql
-- ============================================================

-- PERF:BEGIN step=R2_ESC3_SIN_NIT order=5
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES (p_run_id, 5, 'R2_ESC3_SIN_NIT', 'R2 Esc 3 sin NIT', '05_regla2_esc3_sin_nit.sql', GETDATE());

/* === INICIO 05_regla2_esc3_sin_nit.sql === */
-- PASO 1: Filtrar no-unificados que NO son NIT
-- En datos mock, Cod_Tipo_Ident_Fte=3 es NIT. Excluimos esos.
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03;
CREATE TABLE bdm_stage.stg_regla2_e03
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT a.*
FROM bdm_stage.stg_regla2_e2 a
WHERE a.ind_unificacion = 'N'
  AND COALESCE(a.cod_dw_tipo_ubicacion_dir, 0) NOT IN (
    SELECT cod_dw_tipo_ubicacion_dir FROM bdm_stage.tipo_ubicacion_dir WHERE 1=0
  )
  -- Filtro NIT: excluir registros con tipo identificación = NIT (cod_tipo_ident_fte = 3)
  -- En Teradata se hace con LEFT JOIN V_Tipo_Identificacion WHERE NOT LIKE '%Nit%'
  -- Aquí usamos el campo cod_tipo_ident_fte directamente del insumo de R2
  -- TODO: cuando exista tabla tipo_identificacion, usar JOIN
;

-- Corrección: el filtro NIT debe venir de relacion_persona_ubicacion.cod_tipo_ident_fte
-- que ya está en stg_regla2_e2 (no se copió). Necesitamos JOINear con RPU.
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03;
CREATE TABLE bdm_stage.stg_regla2_e03
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT a.*
FROM bdm_stage.stg_regla2_e2 a
JOIN bdm_stage.relacion_persona_ubicacion rpu
  ON a.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE a.ind_unificacion = 'N'
  AND COALESCE(rpu.cod_tipo_ident_fte, 0) <> 3;  -- 3 = NIT


-- PASO 2: JOIN por misma nomenclatura, calcular score
-- Score = fecha_como_entero + (entidades + 10000000)
-- Detectar empates
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_a;
CREATE TABLE bdm_stage.stg_regla2_e03_a
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT u1.*,
  COUNT(*) OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, nomenclatura, id
  ) AS count_empate,
  MAX(id) OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, cod_dw_persona_ubic, nomenclatura
  ) AS idmax
FROM (
  SELECT
    a.cod_dw_persona_ubic,
    COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 19000101)
      + (COALESCE(a.numero_entidades_reportan, 0) + 10000000) AS id,
    a.texto_ubicacion,
    a.fecha_relacion_persona_ubicaci,
    nmc1.nomenclatura,
    a.complemento AS complemento1,
    b.complemento AS complemento2,
    a.numero_entidades_reportan,
    a.id_buro_persona,
    a.cod_dw_tipo_ubicacion_dir,
    a.cod_dw_municipio,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio, nmc1.nomenclatura
      ORDER BY COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 19000101)
        + (COALESCE(a.numero_entidades_reportan, 0) + 10000000)
    ) AS orden
  FROM bdm_stage.stg_regla2_e03 a
  JOIN bdm_stage.stg_regla2_e03 b
    ON  a.id_buro_persona          = b.id_buro_persona
    AND a.texto_ubicacion           = b.texto_ubicacion
    AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
    AND a.cod_dw_municipio          = b.cod_dw_municipio
    AND a.cod_dw_persona_ubic      <> b.cod_dw_persona_ubic
    AND a.complemento              <> b.complemento
  JOIN bdm_stage.nomenclatura nmc1
    ON a.complemento LIKE nmc1.nomenclatura || '%'
  JOIN bdm_stage.nomenclatura nmc2
    ON b.complemento LIKE nmc2.nomenclatura || '%'
  WHERE nmc1.nomenclatura = nmc2.nomenclatura
) u1;


-- PASO 3: Generar pares padre-hijo (mayor score = padre)
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_e1;
CREATE TABLE bdm_stage.stg_regla2_e03_e1
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT
  b.cod_dw_persona_ubic,
  a.cod_dw_persona_ubic AS id_padre
FROM bdm_stage.stg_regla2_e03_a a
JOIN bdm_stage.stg_regla2_e03_a b
  ON  a.id_buro_persona          = b.id_buro_persona
  AND a.texto_ubicacion           = b.texto_ubicacion
  AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
  AND a.cod_dw_municipio          = b.cod_dw_municipio
  AND a.nomenclatura              = b.nomenclatura
  AND a.cod_dw_persona_ubic      <> b.cod_dw_persona_ubic
  AND a.id > b.id
JOIN (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, nomenclatura,
         MAX(orden) AS max_orden
  FROM bdm_stage.stg_regla2_e03_a
  GROUP BY 1,2,3,4,5
) mx
  ON  a.id_buro_persona          = mx.id_buro_persona
  AND a.texto_ubicacion           = mx.texto_ubicacion
  AND a.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir
  AND a.cod_dw_municipio          = mx.cod_dw_municipio
  AND a.nomenclatura              = mx.nomenclatura
  AND a.orden = mx.max_orden;


-- PASO 4: UPDATE E2 — marcar hijos del Escenario 3 sin NIT
UPDATE bdm_stage.stg_regla2_e2
SET id_padre = stg.id_padre,
    ind_unificacion = 'S',
    n_id = 'L3'
FROM bdm_stage.stg_regla2_e03_e1 stg
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = stg.cod_dw_persona_ubic;

-- PASO 5: Persistir pares en tabla de unificación
INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT
  cod_dw_persona_ubic,
  id_padre AS cod_dw_direccion_unificada,
  2 AS unifica_atributos,
  CURRENT_DATE AS fecha_unificacion,
  1 AS lote,
  1 AS severidad,
  LEFT(CURRENT_USER, 30) AS usuario_bd
FROM bdm_stage.stg_regla2_e03_e1;

-- PASO 6: Marcar hijos
UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e03_e1
);

-- PASO 7: Estadísticas

-- PASO 8: Limpiar staging
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_a;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_e1;
/* === FIN 05_regla2_esc3_sin_nit.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = p_run_id AND step_id = 'R2_ESC3_SIN_NIT' AND ended_at IS NULL;
-- PERF:END step=R2_ESC3_SIN_NIT



-- PERF:BEGIN step=R2_MOTOR_BATCH_PREP order=6
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES (p_run_id, 6, 'R2_MOTOR_BATCH_PREP', 'Motor batch prep unificado', 'inc_batch_motor_prep.sql', GETDATE());

-- ============================================================
-- BATCH MOTOR — prep unificado (07a + 08a + 09a lógica combinada)
-- Reemplaza hitos R2_ESC3_NIT_* .. R2_ESC6_* prep en modo batch
-- ============================================================

/* SOURCE: combinación 07a + 08a + 09a */

-- --- 07a NIT prep ---
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e031;
CREATE TABLE bdm_stage.stg_regla2_e031
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT a.*
FROM bdm_stage.stg_regla2_e2 a
JOIN bdm_stage.relacion_persona_ubicacion rpu
  ON a.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE a.ind_unificacion = 'N'
  AND rpu.cod_tipo_ident_fte = 3;


DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_nit_pares;
CREATE TABLE bdm_stage.stg_regla2_e03_nit_pares
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT a.cod_dw_persona_ubic
FROM bdm_stage.stg_regla2_e031 a
JOIN bdm_stage.stg_regla2_e031 b
  ON  a.id_buro_persona          = b.id_buro_persona
  AND a.texto_ubicacion           = b.texto_ubicacion
  AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
  AND a.cod_dw_municipio          = b.cod_dw_municipio
  AND a.cod_dw_persona_ubic      <> b.cod_dw_persona_ubic
  AND a.complemento              <> b.complemento
JOIN bdm_stage.nomenclatura nmc1 ON a.complemento LIKE nmc1.nomenclatura || '%'
JOIN bdm_stage.nomenclatura nmc2 ON b.complemento LIKE nmc2.nomenclatura || '%'
WHERE nmc1.nomenclatura = nmc2.nomenclatura;

DROP TABLE IF EXISTS bdm_stage.stg_motor_input_nit;
CREATE TABLE bdm_stage.stg_motor_input_nit
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT e.cod_dw_persona_ubic, e.cod_dw_ubic, e.complemento, e.id_buro_persona,
  e.cod_dw_tipo_ubicacion_dir, rpu.cod_pin_persona, rpu.cod_dw_direccion_fisica,
  e.texto_ubicacion, e.fecha_relacion_persona_ubicaci, 'NIT' AS motor_src
FROM bdm_stage.stg_regla2_e031 e
JOIN bdm_stage.stg_regla2_e03_nit_pares p ON e.cod_dw_persona_ubic = p.cod_dw_persona_ubic
JOIN bdm_stage.relacion_persona_ubicacion rpu ON e.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

-- --- 08a Esc5 prep (sub1 motor) ---
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05;
CREATE TABLE bdm_stage.stg_regla2_e05
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') A
JOIN (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') B
  ON  A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_a;
CREATE TABLE bdm_stage.stg_regla2_e05_a
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*,
  NMC1.nomenclatura AS nomenclatura_pri, NMC1.nivel_complemento AS nivel_pri,
  NMC2.nomenclatura AS nomenclatura_sec, NMC2.nivel_complemento AS nivel_sec,
  TRIM(REPLACE(REPLACE(A.complemento, COALESCE(NMC1.nomenclatura,''), ''), COALESCE(NMC2.nomenclatura,''), '')) AS complemento2
FROM bdm_stage.stg_regla2_e05 A
LEFT JOIN bdm_stage.nomenclatura NMC1 ON A.complemento LIKE TRIM(NMC1.nomenclatura) || ' %'
LEFT JOIN bdm_stage.nomenclatura NMC2 ON A.complemento LIKE '% ' || TRIM(NMC2.nomenclatura) || ' %'
  AND NMC2.nomenclatura <> COALESCE(NMC1.nomenclatura, '');

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_c;
CREATE TABLE bdm_stage.stg_regla2_e05_c
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT * FROM (
  SELECT DISTINCT A.* FROM bdm_stage.stg_regla2_e05_a A
  JOIN bdm_stage.stg_regla2_e05_a B
    ON A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
    AND (A.complemento2 NOT LIKE '%' || B.complemento2 || '%' OR B.complemento2 NOT LIKE '%' || A.complemento2 || '%')
    AND A.nomenclatura_pri = B.nomenclatura_pri
    AND COALESCE(A.nomenclatura_sec, 'X') <> COALESCE(B.nomenclatura_sec, 'X')
    AND COALESCE(A.nivel_sec, 0) <> COALESCE(B.nivel_sec, 0)
  UNION
  SELECT DISTINCT A.* FROM bdm_stage.stg_regla2_e05_a A
  JOIN bdm_stage.stg_regla2_e05_a B
    ON A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
    AND (A.complemento2 NOT LIKE '%' || B.complemento2 || '%' OR B.complemento2 NOT LIKE '%' || A.complemento2 || '%')
    AND A.nomenclatura_pri <> B.nomenclatura_pri
    AND COALESCE(A.nomenclatura_sec, 'X') = COALESCE(B.nomenclatura_sec, 'X')
    AND A.nivel_pri <> B.nivel_pri
) sub;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub1;
CREATE TABLE bdm_stage.stg_regla2_e05_sub1
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.* FROM bdm_stage.stg_regla2_e05_c A
JOIN bdm_stage.stg_regla2_e05_c B
  ON A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
  AND TRIM(A.complemento2) <> TRIM(B.complemento2);

DROP TABLE IF EXISTS bdm_stage.stg_motor_input_esc5;
CREATE TABLE bdm_stage.stg_motor_input_esc5
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT e.cod_dw_persona_ubic, e.cod_dw_ubic, e.complemento, e.id_buro_persona,
  e.cod_dw_tipo_ubicacion_dir, rpu.cod_pin_persona, rpu.cod_dw_direccion_fisica,
  e.texto_ubicacion, e.fecha_relacion_persona_ubicaci, 'ESC5' AS motor_src
FROM bdm_stage.stg_regla2_e05_sub1 e
JOIN bdm_stage.relacion_persona_ubicacion rpu ON e.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

-- --- 09a Esc6 prep (sub1 motor) ---
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06;
CREATE TABLE bdm_stage.stg_regla2_e06
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') A
JOIN (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') B
  ON  A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_a;
CREATE TABLE bdm_stage.stg_regla2_e06_a
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*,
  NMC1.nomenclatura AS nomenclatura_pri, NMC1.nivel_complemento AS nivel_pri,
  NMC2.nomenclatura AS nomenclatura_sec, NMC2.nivel_complemento AS nivel_sec
FROM bdm_stage.stg_regla2_e06 A
LEFT JOIN bdm_stage.nomenclatura NMC1 ON A.complemento LIKE TRIM(NMC1.nomenclatura) || ' %'
LEFT JOIN bdm_stage.nomenclatura NMC2 ON A.complemento LIKE '% ' || TRIM(NMC2.nomenclatura) || ' %'
  AND NMC2.nomenclatura <> COALESCE(NMC1.nomenclatura, '');

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_c;
CREATE TABLE bdm_stage.stg_regla2_e06_c
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT * FROM (
  SELECT DISTINCT A.* FROM bdm_stage.stg_regla2_e06_a A
  JOIN bdm_stage.stg_regla2_e06_a B
    ON A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
    AND COALESCE(A.nomenclatura_pri, 'A') = COALESCE(B.nomenclatura_sec, 'B')
  UNION
  SELECT DISTINCT A.* FROM bdm_stage.stg_regla2_e06_a A
  JOIN bdm_stage.stg_regla2_e06_a B
    ON A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
    AND COALESCE(A.nomenclatura_sec, 'A') = COALESCE(B.nomenclatura_pri, 'B')
) sub;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub1;
CREATE TABLE bdm_stage.stg_regla2_e06_sub1
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.* FROM bdm_stage.stg_regla2_e06_c A
JOIN bdm_stage.stg_regla2_e06_c B
  ON A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
  AND COALESCE(A.nivel_pri, 0) <> COALESCE(B.nivel_pri, 0);

DROP TABLE IF EXISTS bdm_stage.stg_motor_input_esc6;
CREATE TABLE bdm_stage.stg_motor_input_esc6
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT e.cod_dw_persona_ubic, e.cod_dw_ubic, e.complemento, e.id_buro_persona,
  e.cod_dw_tipo_ubicacion_dir, rpu.cod_pin_persona, rpu.cod_dw_direccion_fisica,
  e.texto_ubicacion, e.fecha_relacion_persona_ubicaci, 'ESC6' AS motor_src
FROM bdm_stage.stg_regla2_e06_sub1 e
JOIN bdm_stage.relacion_persona_ubicacion rpu ON e.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

-- Unificar stg_motor_input
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
CREATE TABLE bdm_stage.stg_motor_input
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT cod_dw_persona_ubic, cod_dw_ubic, complemento, id_buro_persona,
  cod_dw_tipo_ubicacion_dir, cod_pin_persona, cod_dw_direccion_fisica,
  texto_ubicacion, fecha_relacion_persona_ubicaci
FROM bdm_stage.stg_motor_input_nit
UNION ALL
SELECT cod_dw_persona_ubic, cod_dw_ubic, complemento, id_buro_persona,
  cod_dw_tipo_ubicacion_dir, cod_pin_persona, cod_dw_direccion_fisica,
  texto_ubicacion, fecha_relacion_persona_ubicaci
FROM bdm_stage.stg_motor_input_esc5
UNION ALL
SELECT cod_dw_persona_ubic, cod_dw_ubic, complemento, id_buro_persona,
  cod_dw_tipo_ubicacion_dir, cod_pin_persona, cod_dw_direccion_fisica,
  texto_ubicacion, fecha_relacion_persona_ubicaci
FROM bdm_stage.stg_motor_input_esc6;



UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = p_run_id AND step_id = 'R2_MOTOR_BATCH_PREP' AND ended_at IS NULL;
-- PERF:END step=R2_MOTOR_BATCH_PREP


-- ============================================================
-- HITO 7 : Motor batch ejecucion unica
-- SOURCE: 06_motor_nuevas_direcciones.sql
-- ============================================================

-- PERF:BEGIN step=R2_MOTOR_BATCH_RUN order=7
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES (p_run_id, 7, 'R2_MOTOR_BATCH_RUN', 'Motor batch ejecucion unica', '06_motor_nuevas_direcciones.sql', GETDATE());

/* === INICIO 06_motor_nuevas_direcciones.sql === */
-- ============================================================
-- PASO 1: Descomponer complementos en nomenclaturas individuales
-- Cada fila = 1 nomenclatura de 1 dirección
-- JOIN con DICCIONARIO_COMPLEMENTOS por LIKE con separadores
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_descomp;
CREATE TABLE bdm_stage.stg_motor_descomp
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  sub.*,
  ROW_NUMBER() OVER (PARTITION BY sub.cod_dw_persona_ubic
    ORDER BY sub.nivel_complemento DESC) AS id_com,
  ROW_NUMBER() OVER (PARTITION BY sub.cod_dw_persona_ubic
    ORDER BY sub.nivel_complemento ASC) AS id_com1
FROM (
  SELECT
    tu.cod_dw_persona_ubic,
    tu.cod_dw_ubic,
    tu.id_buro_persona,
    tu.cod_dw_tipo_ubicacion_dir,
    dc.nomenclatura,
    dc.nomen,
    dc.valor AS valor_original,
    CASE WHEN REGEXP_COUNT(dc.valor, '^[0-9]+$') > 0 THEN CAST(dc.valor AS BIGINT) ELSE 0 END AS valor_num,
    COALESCE(nom.nivel_complemento, 99) AS nivel_complemento,
    COUNT(*) AS cantidad
  FROM bdm_stage.stg_motor_input tu
  JOIN bdm_stage.diccionario_complementos dc
    ON tu.complemento LIKE '%' || dc.nomenclatura || '%'
    AND tu.cod_dw_ubic = dc.cod_dw_ubic
    AND tu.id_buro_persona = dc.id_buro_persona
  LEFT JOIN bdm_stage.nomenclatura nom
    ON nom.nomenclatura = dc.nomen
  GROUP BY 1,2,3,4,5,6,7,8,9
) sub;


-- ============================================================
-- PASO 2: Agrupar nomenclaturas por dirección
-- NOM_AGRUP = concatenación de abreviaturas (ej: "TO|AP")
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_agrup;
CREATE TABLE bdm_stage.stg_motor_agrup
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT
  cod_dw_persona_ubic,
  LISTAGG(nomen, '|') WITHIN GROUP (ORDER BY id_com) AS nom_agrup,
  SUM(cantidad) AS cantidad
FROM bdm_stage.stg_motor_descomp
GROUP BY 1;


-- ============================================================
-- PASO 3: Calcular MDIR (jerarquía de dirección)
-- String ordenable: nivel(3 chars) + valor(6 chars) por nomenclatura
-- MDIR=1 = padre (mayor jerarquía), MDIR>1 = hijos
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_mdir;
CREATE TABLE bdm_stage.stg_motor_mdir
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  sub.cod_dw_persona_ubic,
  sub.cod_dw_ubic,
  sub.id_buro_persona,
  sub.cod_dw_tipo_ubicacion_dir,
  sub.mdir_key,
  ROW_NUMBER() OVER (
    PARTITION BY sub.cod_dw_ubic, sub.id_buro_persona, sub.cod_dw_tipo_ubicacion_dir
    ORDER BY sub.mdir_key, sub.cod_dw_persona_ubic ASC
  ) AS mdir
FROM (
  SELECT
    cod_dw_persona_ubic,
    cod_dw_ubic,
    id_buro_persona,
    cod_dw_tipo_ubicacion_dir,
    RPAD(
      LISTAGG(
        LPAD(CAST(nivel_complemento AS VARCHAR), 3, '0')
        || LPAD(CAST(CASE WHEN valor_num > 999999 THEN 999999 ELSE valor_num END AS VARCHAR), 6, '0'),
        ''
      ) WITHIN GROUP (ORDER BY id_com1),
      54, '099999999'
    ) AS mdir_key
  FROM bdm_stage.stg_motor_descomp
  GROUP BY 1,2,3,4
) sub;


-- ============================================================
-- PASO 4: Identificar padre (MDIR=1) e hijo (MDIR>1)
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_padre;
CREATE TABLE bdm_stage.stg_motor_padre
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  m.cod_dw_persona_ubic,
  m.cod_dw_ubic,
  m.id_buro_persona,
  m.cod_dw_tipo_ubicacion_dir,
  tu.complemento,
  tu.cod_pin_persona,
  tu.cod_dw_direccion_fisica,
  tu.texto_ubicacion,
  tu.fecha_relacion_persona_ubicaci,
  a.nom_agrup,
  a.cantidad
FROM bdm_stage.stg_motor_mdir m
JOIN bdm_stage.stg_motor_input tu
  ON m.cod_dw_persona_ubic = tu.cod_dw_persona_ubic
JOIN bdm_stage.stg_motor_agrup a
  ON m.cod_dw_persona_ubic = a.cod_dw_persona_ubic
WHERE m.mdir = 1;


DROP TABLE IF EXISTS bdm_stage.stg_motor_hijo;
CREATE TABLE bdm_stage.stg_motor_hijo
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  m.cod_dw_persona_ubic,
  m.cod_dw_ubic,
  m.id_buro_persona,
  m.cod_dw_tipo_ubicacion_dir,
  tu.complemento,
  m.mdir,
  a.nom_agrup,
  a.cantidad
FROM bdm_stage.stg_motor_mdir m
JOIN bdm_stage.stg_motor_input tu
  ON m.cod_dw_persona_ubic = tu.cod_dw_persona_ubic
JOIN bdm_stage.stg_motor_agrup a
  ON m.cod_dw_persona_ubic = a.cod_dw_persona_ubic
WHERE m.mdir > 1;


-- ============================================================
-- PASO 5: Nomenclaturas del hijo que NO están en el padre
-- Reemplaza cursor + columnas dinámicas C1..CN + código binario
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_diff;
CREATE TABLE bdm_stage.stg_motor_diff
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic_hijo)
AS
SELECT
  h_nom.cod_dw_persona_ubic AS cod_dw_persona_ubic_hijo,
  p.cod_dw_persona_ubic AS cod_dw_persona_ubic_padre,
  h_nom.nomenclatura,
  h_nom.nomen,
  h_nom.valor_original,
  h_nom.id_com
FROM bdm_stage.stg_motor_descomp h_nom
JOIN bdm_stage.stg_motor_hijo h
  ON h_nom.cod_dw_persona_ubic = h.cod_dw_persona_ubic
JOIN bdm_stage.stg_motor_padre p
  ON h.cod_dw_ubic = p.cod_dw_ubic
  AND h.id_buro_persona = p.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = p.cod_dw_tipo_ubicacion_dir
LEFT JOIN bdm_stage.stg_motor_descomp p_nom
  ON p.cod_dw_persona_ubic = p_nom.cod_dw_persona_ubic
  AND h_nom.nomen = p_nom.nomen
  AND TRIM(h_nom.valor_original) = TRIM(p_nom.valor_original)
WHERE p_nom.cod_dw_persona_ubic IS NULL
  AND h.complemento <> p.complemento;


-- ============================================================
-- PASO 6: Concatenar diferencias → nueva nomenclatura por par
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_codigo;
CREATE TABLE bdm_stage.stg_motor_codigo
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic_padre)
AS
SELECT
  cod_dw_persona_ubic_padre,
  cod_dw_persona_ubic_hijo,
  LISTAGG(nomenclatura, ' ') WITHIN GROUP (ORDER BY id_com) AS nueva_nomenclatura
FROM bdm_stage.stg_motor_diff
GROUP BY 1,2;


-- ============================================================
-- PASO 7: Construir nueva dirección completa
-- complemento_padre + nuevas nomenclaturas de todos los hijos
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_resultado;
CREATE TABLE bdm_stage.stg_motor_resultado
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  p.cod_dw_persona_ubic AS cod_dw_persona_ubic_padre,
  p.complemento AS complemento_padre,
  p.cod_dw_ubic,
  p.id_buro_persona,
  p.cod_dw_tipo_ubicacion_dir,
  p.cod_pin_persona,
  p.texto_ubicacion,
  p.fecha_relacion_persona_ubicaci,
  LEFT(
    TRIM(p.complemento) || ' ' || TRIM(LISTAGG(c.nueva_nomenclatura, ' ')
      WITHIN GROUP (ORDER BY h.mdir)),
    100
  ) AS nuevo_complemento,
  LISTAGG(CAST(c.cod_dw_persona_ubic_hijo AS VARCHAR), ',')
    WITHIN GROUP (ORDER BY h.mdir) AS hijos_ids
FROM bdm_stage.stg_motor_padre p
JOIN bdm_stage.stg_motor_codigo c
  ON p.cod_dw_persona_ubic = c.cod_dw_persona_ubic_padre
JOIN bdm_stage.stg_motor_hijo h
  ON c.cod_dw_persona_ubic_hijo = h.cod_dw_persona_ubic
GROUP BY 1,2,3,4,5,6,7,8;


-- ============================================================
-- PASO 8: Verificar existencia y generar IDs
-- Si la dirección combinada ya existe → reusar ID
-- Si no → MAX(id) + ROW_NUMBER() (sandbox; producción usa tabla de secuencias)
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_max_ids;
CREATE TABLE bdm_stage.stg_motor_max_ids AS
SELECT
  COALESCE((SELECT MAX(cod_dw_direccion_fisica) FROM bdm_stage.direccion_fisica), 0) AS max_df,
  COALESCE((SELECT MAX(cod_dw_persona_ubic) FROM bdm_stage.relacion_persona_ubicacion), 0) AS max_rpu;

DROP TABLE IF EXISTS bdm_stage.stg_motor_final;
CREATE TABLE bdm_stage.stg_motor_final
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  r.*,
  CASE WHEN df.cod_dw_direccion_fisica IS NOT NULL
    THEN df.cod_dw_direccion_fisica
    ELSE mx.max_df + ROW_NUMBER() OVER (
      PARTITION BY CASE WHEN df.cod_dw_direccion_fisica IS NULL THEN 1 ELSE 0 END
      ORDER BY r.cod_dw_persona_ubic_padre
    )
  END AS new_cod_dw_direccion_fisica,
  CASE WHEN df.cod_dw_direccion_fisica IS NULL THEN 1 ELSE 0 END AS es_nueva_df,
  mx.max_rpu + ROW_NUMBER() OVER (ORDER BY r.cod_dw_persona_ubic_padre) AS new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_resultado r
CROSS JOIN bdm_stage.stg_motor_max_ids mx
LEFT JOIN bdm_stage.direccion_fisica df
  ON df.cod_dw_ubic = r.cod_dw_ubic
  AND TRIM(df.complemento) = TRIM(r.nuevo_complemento);


-- ============================================================
-- PASO 9: INSERT en DIRECCION_FISICA (solo nuevas)
-- Generada_Enriquecida=1 marca que fue generada por el motor
-- ============================================================
INSERT INTO bdm_stage.direccion_fisica (
  cod_dw_direccion_fisica, complemento, cod_dw_ubic, generada_enriquecida
)
SELECT DISTINCT
  new_cod_dw_direccion_fisica,
  nuevo_complemento,
  cod_dw_ubic,
  1
FROM bdm_stage.stg_motor_final
WHERE es_nueva_df = 1;

-- ============================================================
-- PASO 10: INSERT en RELACION_PERSONA_UBICACION (nueva relación padre)
-- ============================================================
INSERT INTO bdm_stage.relacion_persona_ubicacion (
  cod_dw_persona_ubic,
  id_buro_persona,
  cod_pin_persona,
  cod_dw_ubic,
  cod_dw_direccion_fisica,
  cod_dw_tipo_ubicacion_dir,
  ind_unificacion,
  fecha_relacion_persona_ubicaci,
  lote
)
SELECT
  new_cod_dw_persona_ubic,
  id_buro_persona,
  cod_pin_persona,
  cod_dw_ubic,
  new_cod_dw_direccion_fisica,
  cod_dw_tipo_ubicacion_dir,
  NULL,
  CURRENT_DATE,
  1
FROM bdm_stage.stg_motor_final;

-- ============================================================
-- PASO 11: INSERT en UNIFICACION_DIRECCION (pares padre-hijo)
-- Cada hijo original apunta al nuevo cod_dw_persona_ubic del padre generado
-- En escenarios con motor, el padre MDIR original TAMBIÉN es hijo del nuevo padre
-- ============================================================
INSERT INTO bdm_stage.unificacion_direccion (
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  unifica_atributos,
  fecha_unificacion,
  lote,
  severidad,
  usuario_bd
)
SELECT
  h.cod_dw_persona_ubic,
  f.new_cod_dw_persona_ubic,
  2,
  CURRENT_DATE,
  1,
  1,
  LEFT(CURRENT_USER, 30)
FROM bdm_stage.stg_motor_final f
JOIN bdm_stage.stg_motor_hijo h
  ON h.cod_dw_ubic = f.cod_dw_ubic
  AND h.id_buro_persona = f.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = f.cod_dw_tipo_ubicacion_dir;

-- Padre MDIR original también es hijo del nuevo padre generado
INSERT INTO bdm_stage.unificacion_direccion (
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  unifica_atributos,
  fecha_unificacion,
  lote,
  severidad,
  usuario_bd
)
SELECT
  f.cod_dw_persona_ubic_padre,
  f.new_cod_dw_persona_ubic,
  2,
  CURRENT_DATE,
  1,
  1,
  LEFT(CURRENT_USER, 30)
FROM bdm_stage.stg_motor_final f;

-- ============================================================
-- PASO 12: UPDATE Ind_Unificacion=1 en TODAS las originales (hijos + padre MDIR)
-- ============================================================
UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_motor_hijo
  UNION ALL
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_motor_padre
);

-- ============================================================
-- PASO 13: ANALYZE en todas las tablas modificadas
-- ============================================================

-- ============================================================
-- Limpieza de tablas staging del motor
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_max_ids;
DROP TABLE IF EXISTS bdm_stage.stg_motor_descomp;
DROP TABLE IF EXISTS bdm_stage.stg_motor_agrup;
DROP TABLE IF EXISTS bdm_stage.stg_motor_mdir;
DROP TABLE IF EXISTS bdm_stage.stg_motor_diff;
DROP TABLE IF EXISTS bdm_stage.stg_motor_codigo;
DROP TABLE IF EXISTS bdm_stage.stg_motor_resultado;
-- Nota: stg_motor_input, stg_motor_final, stg_motor_padre y stg_motor_hijo
--       NO se borran aquí — los limpia el script *b que invoca al motor (07b/08b/09b)
/* === FIN 06_motor_nuevas_direcciones.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = p_run_id AND step_id = 'R2_MOTOR_BATCH_RUN' AND ended_at IS NULL;
-- PERF:END step=R2_MOTOR_BATCH_RUN



-- PERF:BEGIN step=R2_MOTOR_BATCH_FIN order=8
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES (p_run_id, 8, 'R2_MOTOR_BATCH_FIN', 'Motor batch finalize', 'inc_batch_motor_finalize.sql', GETDATE());

-- ============================================================
-- BATCH MOTOR — finalize (07b + 08b + 09b filtrado por origen)
-- Ejecutar DESPUÉS de 06_motor en modo batch
-- ============================================================

-- --- 07b NIT finalize (solo filas NIT) ---
UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'X4', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
JOIN bdm_stage.stg_motor_hijo h
  ON h.cod_dw_ubic = f.cod_dw_ubic AND h.id_buro_persona = f.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = f.cod_dw_tipo_ubicacion_dir
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = h.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N'
  AND h.cod_dw_persona_ubic IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_motor_input_nit);

UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'X4', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = f.cod_dw_persona_ubic_padre
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N'
  AND f.cod_dw_persona_ubic_padre IN (
    SELECT DISTINCT e.cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e031 e
    JOIN bdm_stage.stg_regla2_e03_nit_pares p ON e.cod_dw_persona_ubic = p.cod_dw_persona_ubic
  );

INSERT INTO bdm_stage.stg_regla2_e2 (
  cod_dw_persona_ubic, id_padre, id_buro_persona, cod_dw_tipo_ubicacion_dir,
  cod_dw_ubic, texto_ubicacion, cod_dw_direccion_fisica, complemento, ind_unificacion, n_id
)
SELECT f.new_cod_dw_persona_ubic, NULL, f.id_buro_persona, f.cod_dw_tipo_ubicacion_dir,
  f.cod_dw_ubic, f.texto_ubicacion, f.new_cod_dw_direccion_fisica, f.nuevo_complemento, 'N', NULL
FROM bdm_stage.stg_motor_final f
WHERE f.new_cod_dw_persona_ubic IN (
  SELECT DISTINCT mf.new_cod_dw_persona_ubic FROM bdm_stage.stg_motor_final mf
  JOIN bdm_stage.stg_motor_hijo h ON h.cod_dw_ubic = mf.cod_dw_ubic
    AND h.id_buro_persona = mf.id_buro_persona
  WHERE h.cod_dw_persona_ubic IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_motor_input_nit)
);

-- --- 08b Esc5 motor part (solo ESC5) ---
UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'M5', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
JOIN bdm_stage.stg_motor_hijo h
  ON h.cod_dw_ubic = f.cod_dw_ubic AND h.id_buro_persona = f.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = f.cod_dw_tipo_ubicacion_dir
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = h.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N'
  AND h.cod_dw_persona_ubic IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_motor_input_esc5);

UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'M5', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = f.cod_dw_persona_ubic_padre
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N'
  AND f.cod_dw_persona_ubic_padre IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e05_sub1);

INSERT INTO bdm_stage.stg_regla2_e2 (
  cod_dw_persona_ubic, id_padre, id_buro_persona, cod_dw_tipo_ubicacion_dir,
  cod_dw_ubic, texto_ubicacion, cod_dw_direccion_fisica, complemento, ind_unificacion, n_id
)
SELECT f.new_cod_dw_persona_ubic, NULL, f.id_buro_persona, f.cod_dw_tipo_ubicacion_dir,
  f.cod_dw_ubic, f.texto_ubicacion, f.new_cod_dw_direccion_fisica, f.nuevo_complemento, 'N', NULL
FROM bdm_stage.stg_motor_final f
WHERE EXISTS (
  SELECT 1 FROM bdm_stage.stg_motor_input_esc5 e
  WHERE e.id_buro_persona = f.id_buro_persona AND e.cod_dw_ubic = f.cod_dw_ubic
);

-- 08b subcaso 2 diccionario (igual que 08b original)
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2;
CREATE TABLE bdm_stage.stg_regla2_e05_sub2
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM bdm_stage.stg_regla2_e05_a A
JOIN bdm_stage.stg_regla2_e05_a B
  ON  A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
  AND TRIM(A.complemento2) = TRIM(B.complemento2) AND A.nivel_pri <> B.nivel_pri
WHERE A.cod_dw_persona_ubic NOT IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e05_sub1);

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_freq;
CREATE TABLE bdm_stage.stg_regla2_e05_sub2_freq
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT t1.cod_dw_persona_ubic, COALESCE(t2.conteo, 0) AS conteo
FROM bdm_stage.stg_regla2_e05_sub2 t1
LEFT JOIN (
  SELECT t1.cod_dw_persona_ubic, SUM(dc.frecuencia) AS conteo
  FROM bdm_stage.stg_regla2_e05_sub2 t1
  LEFT JOIN bdm_stage.diccionario_complementos dc
    ON t1.cod_dw_ubic = dc.cod_dw_ubic AND t1.complemento LIKE '%' || dc.nomenclatura || '%'
    AND t1.id_buro_persona = dc.id_buro_persona
  GROUP BY 1
) t2 ON t1.cod_dw_persona_ubic = t2.cod_dw_persona_ubic;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_d;
CREATE TABLE bdm_stage.stg_regla2_e05_sub2_d
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT u1.*,
  COUNT(*) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id) AS count_empate,
  MAX(id) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio) AS idmax
FROM (
  SELECT a.cod_dw_persona_ubic,
    (COALESCE(b.conteo, 0) + 10000000)
      + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0) AS id,
    a.texto_ubicacion, a.id_buro_persona, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio,
    a.cod_dw_ubic, a.complemento,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
      ORDER BY (COALESCE(b.conteo, 0) + 10000000)
        + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0)
    ) AS orden
  FROM bdm_stage.stg_regla2_e05_sub2 a
  LEFT JOIN bdm_stage.stg_regla2_e05_sub2_freq b ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
) u1;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_e;
CREATE TABLE bdm_stage.stg_regla2_e05_sub2_e
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT B.cod_dw_persona_ubic, A.cod_dw_persona_ubic AS id_padre
FROM bdm_stage.stg_regla2_e05_sub2_d A
JOIN bdm_stage.stg_regla2_e05_sub2_d B
  ON  A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.id > B.id
JOIN (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, MAX(orden) AS max_orden
  FROM bdm_stage.stg_regla2_e05_sub2_d GROUP BY 1,2,3,4
) mx ON A.id_buro_persona = mx.id_buro_persona AND A.texto_ubicacion = mx.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = mx.cod_dw_municipio
  AND A.orden = mx.max_orden;

UPDATE bdm_stage.stg_regla2_e2
SET id_padre = e.id_padre, ind_unificacion = 'S', n_id = 'D5'
FROM bdm_stage.stg_regla2_e05_sub2_e e
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = e.cod_dw_persona_ubic AND bdm_stage.stg_regla2_e2.id_padre IS NULL;

INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT e.cod_dw_persona_ubic, e.id_padre, 2, CURRENT_DATE, 1, 1, LEFT(CURRENT_USER, 30)
FROM bdm_stage.stg_regla2_e05_sub2_e e;

UPDATE bdm_stage.relacion_persona_ubicacion SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e05_sub2_e);

-- --- 09b Esc6 motor part (solo ESC6) ---
UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'M6', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
JOIN bdm_stage.stg_motor_hijo h
  ON h.cod_dw_ubic = f.cod_dw_ubic AND h.id_buro_persona = f.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = f.cod_dw_tipo_ubicacion_dir
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = h.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N'
  AND h.cod_dw_persona_ubic IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_motor_input_esc6);

UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'M6', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = f.cod_dw_persona_ubic_padre
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N'
  AND f.cod_dw_persona_ubic_padre IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e06_sub1);

INSERT INTO bdm_stage.stg_regla2_e2 (
  cod_dw_persona_ubic, id_padre, id_buro_persona, cod_dw_tipo_ubicacion_dir,
  cod_dw_ubic, texto_ubicacion, cod_dw_direccion_fisica, complemento, ind_unificacion, n_id
)
SELECT f.new_cod_dw_persona_ubic, NULL, f.id_buro_persona, f.cod_dw_tipo_ubicacion_dir,
  f.cod_dw_ubic, f.texto_ubicacion, f.new_cod_dw_direccion_fisica, f.nuevo_complemento, 'N', NULL
FROM bdm_stage.stg_motor_final f
WHERE EXISTS (
  SELECT 1 FROM bdm_stage.stg_motor_input_esc6 e
  WHERE e.id_buro_persona = f.id_buro_persona AND e.cod_dw_ubic = f.cod_dw_ubic
);

-- 09b subcaso 3 diccionario
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3;
CREATE TABLE bdm_stage.stg_regla2_e06_sub3
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM bdm_stage.stg_regla2_e06_c A
JOIN bdm_stage.stg_regla2_e06_c B
  ON  A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
  AND COALESCE(A.nivel_pri, 0) = COALESCE(B.nivel_pri, 0)
WHERE A.cod_dw_persona_ubic NOT IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e06_sub1);

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_freq;
CREATE TABLE bdm_stage.stg_regla2_e06_sub3_freq
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT t1.cod_dw_persona_ubic, COALESCE(t2.conteo, 0) AS conteo
FROM bdm_stage.stg_regla2_e06_sub3 t1
LEFT JOIN (
  SELECT t1.cod_dw_persona_ubic, SUM(dc.frecuencia) AS conteo
  FROM bdm_stage.stg_regla2_e06_sub3 t1
  LEFT JOIN bdm_stage.diccionario_complementos dc
    ON t1.cod_dw_ubic = dc.cod_dw_ubic AND t1.complemento LIKE '%' || dc.nomenclatura || '%'
    AND t1.id_buro_persona = dc.id_buro_persona
  GROUP BY 1
) t2 ON t1.cod_dw_persona_ubic = t2.cod_dw_persona_ubic;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_d;
CREATE TABLE bdm_stage.stg_regla2_e06_sub3_d
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT u1.*,
  COUNT(*) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id) AS count_empate,
  MAX(id) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio) AS idmax
FROM (
  SELECT a.cod_dw_persona_ubic,
    (COALESCE(b.conteo, 0) + 10000000)
      + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0) AS id,
    a.texto_ubicacion, a.id_buro_persona, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
      ORDER BY (COALESCE(b.conteo, 0) + 10000000)
        + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0)
    ) AS orden
  FROM bdm_stage.stg_regla2_e06_sub3 a
  LEFT JOIN bdm_stage.stg_regla2_e06_sub3_freq b ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
) u1;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_e;
CREATE TABLE bdm_stage.stg_regla2_e06_sub3_e
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT B.cod_dw_persona_ubic, A.cod_dw_persona_ubic AS id_padre
FROM bdm_stage.stg_regla2_e06_sub3_d A
JOIN bdm_stage.stg_regla2_e06_sub3_d B
  ON  A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.id > B.id
JOIN (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, MAX(orden) AS max_orden
  FROM bdm_stage.stg_regla2_e06_sub3_d GROUP BY 1,2,3,4
) mx ON A.id_buro_persona = mx.id_buro_persona AND A.texto_ubicacion = mx.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = mx.cod_dw_municipio
  AND A.orden = mx.max_orden;

UPDATE bdm_stage.stg_regla2_e2
SET id_padre = e.id_padre, ind_unificacion = 'S', n_id = 'D6'
FROM bdm_stage.stg_regla2_e06_sub3_e e
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = e.cod_dw_persona_ubic AND bdm_stage.stg_regla2_e2.id_padre IS NULL;

INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT e.cod_dw_persona_ubic, e.id_padre, 2, CURRENT_DATE, 1, 1, LEFT(CURRENT_USER, 30)
FROM bdm_stage.stg_regla2_e06_sub3_e e;

UPDATE bdm_stage.relacion_persona_ubicacion SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e06_sub3_e);


-- Limpieza batch staging
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e031;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_nit_pares;
DROP TABLE IF EXISTS bdm_stage.stg_motor_input_nit;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_a;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_c;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub1;
DROP TABLE IF EXISTS bdm_stage.stg_motor_input_esc5;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_a;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_c;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub1;
DROP TABLE IF EXISTS bdm_stage.stg_motor_input_esc6;
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
DROP TABLE IF EXISTS bdm_stage.stg_motor_final;
DROP TABLE IF EXISTS bdm_stage.stg_motor_padre;
DROP TABLE IF EXISTS bdm_stage.stg_motor_hijo;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_freq;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_d;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_e;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_freq;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_d;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_e;


UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = p_run_id AND step_id = 'R2_MOTOR_BATCH_FIN' AND ended_at IS NULL;
-- PERF:END step=R2_MOTOR_BATCH_FIN


END;
$$ LANGUAGE plpgsql;

