﻿-- ============================================================
-- SP_R1 — Regla 1
-- Archivo listo para DBeaver: Alt+Shift+X (todo el archivo)
-- Requisito: haber ejecutado 01_crear_tablas_bdm_stage.sql
-- Uso luego: CALL bdm_stage.sp_rN('tu_run_id');
-- ============================================================
-- ============================================================
-- SP_R1 — Regla 1 unificacion
-- Schema: bdm_stage | Pipeline: db_rcncr_btch_rdshft_pgm
-- Fuente: 00_run_benchmark_20k_batch_exec.sql
-- ============================================================
CREATE OR REPLACE PROCEDURE bdm_stage.sp_r1(p_run_id VARCHAR(64))
NONATOMIC
AS $$
BEGIN
-- HITO 2 : Regla 1
-- SOURCE: 02_regla1_unificacion.sql
-- ============================================================

-- PERF:BEGIN step=R1 order=2
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES (p_run_id, 2, 'R1', 'Regla 1', '02_regla1_unificacion.sql', GETDATE());

/* === INICIO 02_regla1_unificacion.sql === */
-- PASO 1: Materializar insumo en bdm_stage (staging volátil)
DROP TABLE IF EXISTS bdm_stage.stg_regla1_insumo;
CREATE TABLE bdm_stage.stg_regla1_insumo
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, texto_ubicacion)
AS
SELECT
  rpu.cod_dw_persona_ubic,
  rpu.id_buro_persona,
  ubi.texto_ubicacion,
  df.complemento,
  ubi.cod_dw_ciudad,
  rpu.cod_dw_tipo_ubicacion_dir,
  COALESCE(ciiu.cod_act_econo_ciiu_fte, '') AS cod_act_econo_ciiu_fte,
  COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor), 0) AS numero_entidades_reportan,
  tud.descripcion_tipo_ubicacion_dir AS tipo_direccion
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi
  ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df
  ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
JOIN bdm_stage.reporte_relacion_persona_ubica rep
  ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
LEFT JOIN bdm_stage.ciiu_persona ciiu
  ON rpu.id_buro_persona = ciiu.id_buro_persona
LEFT JOIN bdm_stage.tipo_ubicacion_dir tud
  ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
WHERE rpu.ind_unificacion IS NULL
GROUP BY 1,2,3,4,5,6,7,9;


-- PASO 2: Calcular score y ranking por escenario
DROP TABLE IF EXISTS bdm_stage.stg_regla1_scored;
CREATE TABLE bdm_stage.stg_regla1_scored
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, texto_ubicacion)
AS
SELECT *,
  CASE
    WHEN cod_act_econo_ciiu_fte = '10' THEN 'ESC1'
    WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN 'ESC2'
    ELSE 'ESC3'
  END AS escenario,

  CASE
    WHEN cod_act_econo_ciiu_fte = '10' THEN
      CASE WHEN tipo_direccion IN ('LAB','CRR') THEN 100000 ELSE 0 END
      + numero_entidades_reportan
    WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN
      CASE WHEN tipo_direccion IN ('RES','CRR') THEN 100000 ELSE 0 END
      + numero_entidades_reportan
    ELSE
      numero_entidades_reportan
  END AS score,

  ROW_NUMBER() OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_ciudad,
      CASE
        WHEN cod_act_econo_ciiu_fte = '10' THEN 'ESC1'
        WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN 'ESC2'
        ELSE 'ESC3'
      END
    ORDER BY
      CASE
        WHEN cod_act_econo_ciiu_fte = '10' THEN
          CASE WHEN tipo_direccion IN ('LAB','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan
        WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN
          CASE WHEN tipo_direccion IN ('RES','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan
        ELSE numero_entidades_reportan
      END DESC
  ) AS orden
FROM bdm_stage.stg_regla1_insumo;


-- PASO 3: Generar pares padre-hijo
DROP TABLE IF EXISTS bdm_stage.stg_regla1_pares;
CREATE TABLE bdm_stage.stg_regla1_pares
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT
  hijo.cod_dw_persona_ubic        AS cod_dw_persona_ubic,
  padre.cod_dw_persona_ubic       AS cod_dw_direccion_unificada
FROM bdm_stage.stg_regla1_scored padre
JOIN bdm_stage.stg_regla1_scored hijo
  ON padre.id_buro_persona = hijo.id_buro_persona
 AND padre.texto_ubicacion = hijo.texto_ubicacion
 AND padre.cod_dw_ciudad = hijo.cod_dw_ciudad
 AND padre.escenario = hijo.escenario
 AND padre.score > hijo.score
 AND padre.cod_dw_tipo_ubicacion_dir <> hijo.cod_dw_tipo_ubicacion_dir
WHERE padre.orden = 1;

-- PASO 4: Persistir resultado
INSERT INTO bdm_stage.unificacion_direccion
SELECT
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  1 AS unifica_atributos,
  CURRENT_DATE AS fecha_unificacion,
  1 AS lote,
  1 AS severidad,
  CURRENT_USER AS usuario_bd
FROM bdm_stage.stg_regla1_pares;

-- PASO 5: Marcar hijos como unificados
UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla1_pares
);

-- PASO 6: Actualizar estadísticas de tablas modificadas

-- PASO 7: Limpiar staging (bdm_stage es volátil)
DROP TABLE IF EXISTS bdm_stage.stg_regla1_insumo;
DROP TABLE IF EXISTS bdm_stage.stg_regla1_scored;
DROP TABLE IF EXISTS bdm_stage.stg_regla1_pares;
/* === FIN 02_regla1_unificacion.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = p_run_id AND step_id = 'R1' AND ended_at IS NULL;
-- PERF:END step=R1



END;
$$ LANGUAGE plpgsql;

