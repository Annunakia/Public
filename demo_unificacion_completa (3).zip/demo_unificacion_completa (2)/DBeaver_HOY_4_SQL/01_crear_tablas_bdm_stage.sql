﻿-- ============================================================
-- 01_crear_tablas_bdm_stage.sql
-- Tablas necesarias para ejecutar sp_r1 / sp_r2 / sp_r3
-- Esquema: bdm_stage | Ejecutar PRIMERO en DBeaver (Alt+Shift+X)
-- Fuente: SQL benchmark Unificacion (Cursor)
-- ============================================================

-- ============================================================
-- SLCOPRBA-1147-01_bdm_stage_tables.sql
-- STRCT: tablas base Unificacion en bdm_stage
-- Idempotente: CREATE TABLE IF NOT EXISTS
-- ============================================================

CREATE TABLE IF NOT EXISTS bdm_stage.tipo_ubicacion_dir (
  cod_dw_tipo_ubicacion_dir INTEGER ENCODE AZ64,
  descripcion_tipo_ubicacion_dir VARCHAR(20) ENCODE BYTEDICT
) DISTSTYLE ALL;

CREATE TABLE IF NOT EXISTS bdm_stage.nomenclatura (
  nomenclatura VARCHAR(10) ENCODE ZSTD,
  nivel_complemento INTEGER ENCODE AZ64
) DISTSTYLE ALL;

CREATE TABLE IF NOT EXISTS bdm_stage.ubicacion_estandarizada (
  cod_dw_ubic BIGINT ENCODE AZ64,
  texto_ubicacion VARCHAR(200) ENCODE ZSTD,
  cod_dw_ciudad INTEGER ENCODE AZ64,
  latitud DECIMAL(10,7),
  longitud DECIMAL(10,7)
) DISTSTYLE KEY DISTKEY(cod_dw_ubic) SORTKEY(cod_dw_ubic);

CREATE TABLE IF NOT EXISTS bdm_stage.direccion_fisica (
  cod_dw_direccion_fisica BIGINT ENCODE AZ64,
  complemento VARCHAR(100) ENCODE ZSTD,
  cod_dw_ubic BIGINT ENCODE AZ64,
  tipo_via_principal VARCHAR(5) ENCODE ZSTD,
  via_principal VARCHAR(10) ENCODE ZSTD,
  via_generadora VARCHAR(10) ENCODE ZSTD,
  numero_puerta VARCHAR(10) ENCODE ZSTD,
  generada_enriquecida INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(cod_dw_direccion_fisica) SORTKEY(cod_dw_direccion_fisica);

CREATE TABLE IF NOT EXISTS bdm_stage.relacion_persona_ubicacion (
  cod_dw_persona_ubic BIGINT ENCODE AZ64,
  id_buro_persona INTEGER ENCODE AZ64,
  cod_pin_persona INTEGER ENCODE AZ64,
  cod_dw_ubic BIGINT ENCODE AZ64,
  cod_dw_direccion_fisica BIGINT ENCODE AZ64,
  cod_dw_tipo_ubicacion_dir INTEGER ENCODE AZ64,
  ind_unificacion INTEGER ENCODE AZ64,
  orden_prioridad INTEGER ENCODE AZ64,
  fecha_relacion_persona_ubicaci DATE ENCODE AZ64,
  lote INTEGER ENCODE AZ64,
  cod_tipo_ident_fte INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(id_buro_persona) SORTKEY(id_buro_persona, cod_dw_persona_ubic);

CREATE TABLE IF NOT EXISTS bdm_stage.ciiu_persona (
  id_buro_persona INTEGER ENCODE AZ64,
  cod_act_econo_ciiu_fte VARCHAR(10) ENCODE BYTEDICT
) DISTSTYLE KEY DISTKEY(id_buro_persona);

CREATE TABLE IF NOT EXISTS bdm_stage.reporte_relacion_persona_ubica (
  cod_dw_persona_ubic BIGINT ENCODE AZ64,
  id_buro_suscriptor INTEGER ENCODE AZ64,
  fecha_reporte DATE ENCODE AZ64,
  lote INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic) SORTKEY(cod_dw_persona_ubic);

CREATE TABLE IF NOT EXISTS bdm_stage.unificacion_direccion (
  cod_dw_persona_ubic BIGINT ENCODE AZ64,
  cod_dw_direccion_unificada BIGINT ENCODE AZ64,
  unifica_atributos INTEGER ENCODE AZ64,
  fecha_unificacion DATE ENCODE AZ64,
  lote INTEGER ENCODE AZ64,
  severidad INTEGER ENCODE AZ64,
  usuario_bd VARCHAR(100) ENCODE ZSTD
) DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic) SORTKEY(cod_dw_persona_ubic);

CREATE TABLE IF NOT EXISTS bdm_stage.diccionario_complementos (
  cod_dw_ubic BIGINT ENCODE AZ64,
  id_buro_persona INTEGER ENCODE AZ64,
  nomenclatura VARCHAR(50) ENCODE ZSTD,
  nomen VARCHAR(10) ENCODE ZSTD,
  valor VARCHAR(50) ENCODE ZSTD,
  frecuencia INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(cod_dw_ubic) SORTKEY(cod_dw_ubic, id_buro_persona);

CREATE TABLE IF NOT EXISTS bdm_stage.diccionario_via (
  tipo VARCHAR(20) ENCODE ZSTD,
  llave VARCHAR(100) ENCODE ZSTD,
  via_generadora VARCHAR(10) ENCODE ZSTD,
  cod_dw_municipio INTEGER ENCODE AZ64,
  conteo INTEGER ENCODE AZ64
) DISTSTYLE ALL;

CREATE TABLE IF NOT EXISTS bdm_stage.relacion_ubicac_estandar_geo (
  cod_dw_ubic BIGINT ENCODE AZ64,
  latitud DECIMAL(10,7),
  longitud DECIMAL(10,7)
) DISTSTYLE ALL;

CREATE TABLE IF NOT EXISTS bdm_stage.bloqueo (
  id_buro_persona INTEGER ENCODE AZ64
) DISTSTYLE ALL;

-- Instrumentacion de corridas (compartida por DT / SPs)
CREATE TABLE IF NOT EXISTS bdm_stage.perf_timings (
  run_id          VARCHAR(64),
  step_order      INT,
  step_id         VARCHAR(64),
  label           VARCHAR(256),
  script_source   VARCHAR(256),
  started_at      TIMESTAMP,
  ended_at        TIMESTAMP,
  duration_sec    BIGINT,
  status          VARCHAR(16)
) DISTSTYLE ALL;


-- Catalogo minimo (tipos ubicacion + nomenclatura)
-- ============================================================
-- SLCOPRBA-1147-02_bdm_stage_catalog.sql
-- STRCT: catalogos base (seed) en bdm_stage
-- ============================================================

DELETE FROM bdm_stage.tipo_ubicacion_dir;
INSERT INTO bdm_stage.tipo_ubicacion_dir VALUES
(1, 'RES'), (2, 'LAB'), (3, 'CRR'), (4, 'JUD'), (5, 'CCL');

DELETE FROM bdm_stage.nomenclatura;
INSERT INTO bdm_stage.nomenclatura VALUES
('BR',1),('UR',1),('CJ',1),('UN',1),
('ED',2),('ZN',2),('SEC',2),
('MZ',3),('ET',3),
('TO',4),('BQ',4),
('PI',5),('CS',5),('IN',5),('BL',5),
('LC',6),('OF',6),('PL',6),
('AP',7),('GJ',7),('DP',7),('ST',7);

