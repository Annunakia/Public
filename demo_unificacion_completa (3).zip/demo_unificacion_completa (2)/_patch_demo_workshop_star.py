# -*- coding: utf-8 -*-
"""
Demo (texto + mock SPs) | Workshop (queries/casos) | SPs (STAR individual).
"""
from __future__ import annotations

import json
import re
import shutil
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
]

DEMO_PRESENTACION = [
    {
        "titulo": "Qué es esta Demo",
        "texto": (
            "Esta pestaña es la demo de Ordenamiento: cuenta la historia completa en texto, "
            "con los mismos ejemplos del seed mock (personas 20001–20014) que puedes verificar en DBeaver. "
            "No reemplaza al Workshop: ahí están las queries y el detalle por canal. "
            "Los SPs (pestaña SPs) explican cada procedimiento con metodología STAR."
        ),
    },
    {
        "titulo": "Qué debe cubrir la Demo",
        "texto": (
            "1) Qué problema resuelve Ordenamiento (orden de intento de contacto). "
            "2) Precondición: Unificación ya corrió; solo ganadoras. "
            "3) Cuatro canales aparte: DIR, TEL, CEL, EMA. "
            "4) Insumo → score (características × betas RITM) → orden_prioridad. "
            "5) Recorrido con personas del seed. "
            "6) Cómo reproducir: CALL sp_ordenamiento_ejecucion_mock() y las queries del Workshop."
        ),
    },
    {
        "titulo": "Qué busca el Ordenamiento",
        "texto": (
            "Después de Unificación, una persona puede tener varias calles, fijos, celulares o emails vigentes. "
            "Ordenamiento responde: ¿con cuál empiezo y en qué orden intento los demás? "
            "No redefine padre/hija; solo ordena contactos útiles por canal."
        ),
    },
    {
        "titulo": "Solo ganadoras y canales aparte",
        "texto": (
            "Si la RPU es hija (ind_unificacion = 1), no recibe score ni orden. "
            "TEL/CEL/EMA solo entran si la persona tiene al menos una DIR ganadora. "
            "DIR, TEL, CEL y EMA se rankean por separado: el lugar 1 de un canal no compite con otro."
        ),
    },
    {
        "titulo": "Recorrido demo con el seed (lo que muestras)",
        "texto": (
            "20001 — casa (850, lugar 1) vs oficina (700, lugar 2): ¿qué calle primero? "
            "20011 — padre con score/orden; hija sin filas: solo ganadoras. "
            "20010 — empate 777/777 → lugares 1 y 2 por ROW_NUMBER. "
            "20004 — TEL válido 420 vs no válido 210. "
            "20013 — TEL020 no mueve el score (ambos 376.5). "
            "20012 — CEL prefijo 999 → default 0.22 → score 220. "
            "20014 — EMA003/007 no mueven (ambos 281.7705). "
            "Salida 20001 — orden_prioridad = lugar DIR (1 y 2)."
        ),
    },
    {
        "titulo": "SPs mock de la Demo (cómo se reproduce)",
        "texto": (
            "sp_ordenamiento_cargar_seed_mock — carga personas 20001–20014, scores y orden en bdm_stage.mock_ord_*. "
            "sp_ordenamiento_validar_mock — corre CA-O01…CA-O12 y deja el veredicto en mock_ord_ca_result. "
            "sp_ordenamiento_ejecucion_mock — orquesta seed + validación (un solo CALL para la demo). "
            "En DBeaver: CALL bdm_stage.sp_ordenamiento_ejecucion_mock(); luego las queries del Workshop "
            "deben devolver exactamente las filas del ejemplo."
        ),
    },
    {
        "titulo": "Dónde sigue cada cosa",
        "texto": (
            "Demo (esta pestaña): historia y recorrido. "
            "Workshop: insumos, DIR, TEL, CEL, EMA, salida — con queries copiables. "
            "SPs: cada procedimiento (EDF y mock) en formato STAR — objetivo, ejemplo y por qué el resultado."
        ),
    },
]

# STAR por SP (incl. mock)
STAR = {
    "SP-00": {
        "objetivo": "Dejar creadas las tablas donde viven score, orden_prioridad y betas.",
        "situacion": "Sin tablas de producto no hay dónde persistir el ranking acordado en mesa.",
        "accion": "DDL en _strct: score_ordenamiento, rpu_orden_prioridad, beta_ordenamiento (DISTKEY id_buro_persona).",
        "ejemplo": "Tras el deploy, existen las tres tablas en bdm_datos listas para escribir.",
        "resultado": "El pipeline puede guardar scores y el orden de intento sin inventar estructuras en cada corrida.",
        "por_que": "Separar estructura (strct) de lógica (pgm) es el estándar de despliegue; el score necesita un destino estable.",
    },
    "SP-01": {
        "objetivo": "Tener catálogos de apoyo (operador celular, etc.) para traducir datos a pesos.",
        "situacion": "CEL necesita saber qué vale un prefijo; si no hay mapeo, la mesa acordó default 0.22.",
        "accion": "Cargar catalogo_operador_ord_cel y catálogos auxiliares usados en scoring.",
        "ejemplo": "Prefijo 310 → valor de catálogo; prefijo 999 (seed 20012) → COALESCE → 0.22 → score 220.",
        "resultado": "El scoring CEL aplica pesos conocidos o el default, sin caer a 0 por prefijo desconocido.",
        "por_que": "El default 0.22 es semántica doc v2.0 / acuerdo de mesa (CEL-02), no un error de datos.",
    },
    "SP-02": {
        "objetivo": "Traducir contactType XPM al canal de negocio (DIR/TEL/CEL/EMA).",
        "situacion": "El productor trae tipos numéricos; el ranking piensa en canales.",
        "accion": "Vista v_xpm_contacto_canal: 1/2/3/7/8→DIR, 4/5/8→TEL, 9→CEL, 10→EMA.",
        "ejemplo": "Type 10 sin @ no llega como email usable; type 9 alimenta CEL.",
        "resultado": "Cada contacto queda etiquetado al canal correcto antes del insumo/scoring.",
        "por_que": "Sin este mapa, el insumo no sabría en qué ranking debe competir el dato.",
    },
    "SP-03": {
        "objetivo": "Exponer solo ganadoras post-unificación como base del insumo.",
        "situacion": "Unificación ya marcó hijas; ordenamiento no debe puntuarlas.",
        "accion": "Vistas post-unificación: ind_unificacion; hijas (1) fuera; insumos por canal sin copia permanente.",
        "ejemplo": "Seed 20011: padre 91018 entra; hija 91019 no aparece en score ni orden.",
        "resultado": "La elegibilidad ‘solo ganadoras’ queda fijada antes de puntuar.",
        "por_que": "Es la regla de oro de la mesa: la hija ya no es contacto vigente.",
    },
    "SP-04": {
        "objetivo": "Armar en la corrida la lista de candidatos (insumo) por canal.",
        "situacion": "Hay que materializar quién entra hoy, sin dejar copia permanente de XPM.",
        "accion": "sp_preparar_insumos_edf: CTAS stg_rpu / stg_persona_dir_ganadora / stg_insumo_* (email sin @ fuera).",
        "ejemplo": "Tras preparar, existen bandejas DIR/TEL/CEL/EMA listas; staging se borra al final.",
        "resultado": "El scoring recibe filas elegibles y válidas; el insumo responde ¿quién entra?",
        "por_que": "Sin este paso el ranking no refleja unificación ni filtros de calidad del dato.",
    },
    "SP-05": {
        "objetivo": "Decidir qué dirección (calle) intentar primero por persona.",
        "situacion": "Varias RPUs ganadoras compiten en DIR.",
        "accion": "Score DIR = Σ (categoría/max × beta); ROW_NUMBER → lugar 1, 2, 3…",
        "ejemplo": "Seed 20001: casa 850 lugar 1; oficina 700 lugar 2.",
        "resultado": "Queda un ranking DIR verificable; el lugar 1 es el primer contacto de calle.",
        "por_que": "Mayor score = mejor contactabilidad relativa según catálogo RITM; canales no se mezclan.",
    },
    "SP-06": {
        "objetivo": "Decidir qué teléfono fijo intentar primero (independiente de DIR).",
        "situacion": "Hay fijos válidos y no válidos; TEL020 no debe mover el score final.",
        "accion": "Scoring TEL con TEL020 fuera de la sumatoria (TEL-02).",
        "ejemplo": "Seed 20004: válido 420/1 vs no válido 210/2. Seed 20013: ambos 376.5 pese a TEL020.",
        "resultado": "Ranking TEL aparte; reglas de suma alineadas al baseline.",
        "por_que": "TEL020 es trazabilidad, no criterio de ranking (acuerdo / Características).",
    },
    "SP-07": {
        "objetivo": "Decidir qué celular intentar primero, con operador por prefijo.",
        "situacion": "Prefijos conocidos vs desconocidos (CEL-02).",
        "accion": "LEFT(celular,3) → catálogo; sin mapeo → 0.22; score CEL y lugar.",
        "ejemplo": "Seed 20012: prefijo 999 → score 220 lugar 1.",
        "resultado": "CEL tiene ranking propio; default acordado cuando no hay operador.",
        "por_que": "Evita dejar el contacto en 0 por un prefijo nuevo; semántica v2.0.",
    },
    "SP-08": {
        "objetivo": "Decidir qué email intentar primero.",
        "situacion": "Algunas variables EMA son solo trazabilidad (EMA-03).",
        "accion": "Scoring EMA sin sumar EMA003/007/018/025.",
        "ejemplo": "Seed 20014: ema_base y ema_solo_excluidas → mismo score 281.7705.",
        "resultado": "El ranking EMA no se mueve por variables fuera de suma.",
        "por_que": "Misma lógica que Sumatoria_Score_Email del baseline.",
    },
    "SP-09": {
        "objetivo": "Persistir el orden de intento de calle en orden_prioridad.",
        "situacion": "El consumidor necesita un orden guardado por RPU ganadora.",
        "accion": "Consolidar mejor lugar DIR → rpu_orden_prioridad; hijas sin fila.",
        "ejemplo": "Seed 20001: 91001→1, 91002→2 (igual que el ranking DIR).",
        "resultado": "orden_prioridad queda alineado al lugar DIR de ganadoras.",
        "por_que": "Es la salida de negocio del canal dirección; TEL/CEL/EMA no escriben aquí.",
    },
    "SP-10": {
        "objetivo": "Limpiar staging al terminar la corrida.",
        "situacion": "stg_* son temporales de una ejecución.",
        "accion": "DROP de tablas stg_* en bdm_tempo.",
        "ejemplo": "Después del orquestador, no deben quedar stg_insumo_*.",
        "resultado": "La siguiente corrida parte limpia; no hay copia residual.",
        "por_que": "Acuerdo: sin copia permanente del productor entre corridas.",
    },
    "SP-11": {
        "objetivo": "Correr el pipeline completo Opción A en el orden correcto.",
        "situacion": "Hay que encadenar insumos → 4 scorings → consolidar → drop.",
        "accion": "sp_ordenamiento_ejecucion_edf(TRUE/FALSE) orquesta los CALL.",
        "ejemplo": "CALL bdm_datos.sp_ordenamiento_ejecucion_edf(TRUE); produce scores + orden y limpia staging.",
        "resultado": "Una ejecución consistente con el flujo Control-M / mesa.",
        "por_que": "Evita correr scoring sin insumo o dejar staging huérfano.",
    },
    "SP-12": {
        "objetivo": "Tener el runbook de _dt que dispara la ejecución en Jenkins/Control-M.",
        "situacion": "El job post-unificación debe invocar un solo artefacto claro.",
        "accion": "Script run_ordenamiento_ejecucion_edf.sql con el CALL al orquestador.",
        "ejemplo": "Job DEV/QA apunta a ese SQL tras unificación OK.",
        "resultado": "Despliegue y operación alineados al repo _dt.",
        "por_que": "Separa orquestación operativa de la lógica de los SPs en _pgm.",
    },
    "SP-13": {
        "objetivo": "Validar conteos/gates de calidad de la corrida real (hijas, volúmenes).",
        "situacion": "Hay que demostrar que ninguna hija quedó con orden y que hay scores por canal.",
        "accion": "Script de validación de conteos sobre score_ordenamiento / orden_prioridad.",
        "ejemplo": "Gate: rpu_hijas_con_orden_incorrecto = 0; scores DIR/TEL/EMA > 0.",
        "resultado": "Evidencia de corrida sana en productor.",
        "por_que": "Cierra el ciclo de aceptación sin mezclar con el seed mock.",
    },
    # Mock SPs
    "SP-M01": {
        "objetivo": "Cargar el seed demo (20001–20014) en bdm_stage.mock_ord_*.",
        "situacion": "La demo necesita los mismos ejemplos del HTML, verificables sin Caso A/B histórico.",
        "accion": "sp_ordenamiento_cargar_seed_mock inserta RPUs, scores, prioridad y catálogo de escenarios.",
        "ejemplo": "Tras el CALL, 20001 tiene casa/oficina 850/700; 20011 padre/hija; etc.",
        "resultado": "El seed queda listo para consultas del Workshop y para validar_mock.",
        "por_que": "HTML = seed: la demo muestra exactamente lo que DBeaver debe devolver.",
    },
    "SP-M02": {
        "objetivo": "Validar criterios CA-O01…CA-O12 sobre el seed mock.",
        "situacion": "Hay que demostrar que el seed cumple la matriz de aceptación mock.",
        "accion": "sp_ordenamiento_validar_mock escribe mock_ord_ca_result con PASSED/FAILED por criterio.",
        "ejemplo": "Veredicto esperado: PASSED_ALL (o detalle por CA-Oxx).",
        "resultado": "Evidencia de que los ejemplos de la demo cubren los criterios mock.",
        "por_que": "Separa la prueba del seed de la corrida EDF real.",
    },
    "SP-M03": {
        "objetivo": "Orquestar la demo mock en un solo paso (seed + validación).",
        "situacion": "Para la demo/Workshop se necesita un CALL corto y repetible.",
        "accion": "sp_ordenamiento_ejecucion_mock = cargar_seed_mock + validar_mock.",
        "ejemplo": "CALL bdm_stage.sp_ordenamiento_ejecucion_mock(); luego SELECT del caso 20001.",
        "resultado": "Ambiente demo listo; queries del Workshop cuadran con las tablas del HTML.",
        "por_que": "Un solo comando reduce fricción en la mesa y evita seed a medias.",
    },
}

MOCK_SP_ENTRIES = [
    {
        "id": "SP-M01",
        "fase": "Demo · Mock",
        "grupo": "Mock",
        "archivo": "sp_ordenamiento_cargar_seed_mock.sql",
        "repo": "_pgm",
        "rol": "Cargar seed demo 20001–20014",
        "pregunta": "¿Cómo dejo listos los ejemplos de la Demo?",
        "entra": "— (reemplaza mock_ord_*)",
        "sale": "mock_ord_rpu, mock_ord_score, mock_ord_prioridad, mock_ord_escenario",
        "logica": "INSERT seed alineado al HTML.",
        "pasos": [
            "Limpiar tablas mock_ord_*",
            "Insertar escenarios CA-O01…CA-O12",
            "Insertar RPUs / scores / orden_prioridad",
        ],
        "ejemplo": "20001 casa/oficina; 20011 padre/hija; 20004 TEL; …",
        "query": "CALL bdm_stage.sp_ordenamiento_cargar_seed_mock();\nSELECT * FROM bdm_stage.mock_ord_escenario WHERE es_html_ejemplo=1 ORDER BY 1;",
        "fuente": "SEED",
    },
    {
        "id": "SP-M02",
        "fase": "Demo · Mock",
        "grupo": "Mock",
        "archivo": "sp_ordenamiento_validar_mock.sql",
        "repo": "_pgm",
        "rol": "Validar criterios CA sobre el seed",
        "pregunta": "¿El seed cumple CA-O01…CA-O12?",
        "entra": "mock_ord_*",
        "sale": "mock_ord_ca_result",
        "logica": "Evalúa cada criterio y deja estado PASSED/FAILED.",
        "pasos": [
            "Leer seed",
            "Evaluar CA-O01…CA-O12",
            "Escribir veredicto",
        ],
        "ejemplo": "SELECT criterio_ca, estado, detalle FROM bdm_stage.mock_ord_ca_result ORDER BY 1;",
        "query": "CALL bdm_stage.sp_ordenamiento_validar_mock();\nSELECT criterio_ca, estado, detalle FROM bdm_stage.mock_ord_ca_result ORDER BY 1;",
        "fuente": "SEED",
    },
    {
        "id": "SP-M03",
        "fase": "Demo · Mock",
        "grupo": "Mock",
        "archivo": "sp_ordenamiento_ejecucion_mock.sql",
        "repo": "_pgm",
        "rol": "Orquestar demo mock (seed + validación)",
        "pregunta": "¿Cómo preparo la Demo/Workshop en un solo CALL?",
        "entra": "—",
        "sale": "seed + veredicto CA",
        "logica": "CALL cargar_seed_mock; CALL validar_mock;",
        "pasos": [
            "Cargar seed",
            "Validar CA",
        ],
        "ejemplo": "CALL bdm_stage.sp_ordenamiento_ejecucion_mock(); — punto de entrada de la Demo.",
        "query": "CALL bdm_stage.sp_ordenamiento_ejecucion_mock();\nSELECT id_buro_persona, canal, score, lugar FROM bdm_stage.mock_ord_score WHERE id_buro_persona=20001 ORDER BY canal, lugar;",
        "fuente": "SEED",
    },
]


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def patch_data(data: dict) -> None:
    data["presentacion"] = DEMO_PRESENTACION
    data["generated"] = "2026-09-25"
    data["guion_sesion"] = []

    # Enrich SPs with STAR + ensure mock entries
    sps = list(data.get("sps_detalle") or [])
    by_id = {s.get("id"): s for s in sps}
    # Fix SP-13 if it was wrongly labeled as mock seed
    if "SP-13" in by_id:
        by_id["SP-13"]["rol"] = "Validar conteos / gates de la corrida real"
        by_id["SP-13"]["pregunta"] = "¿La corrida real quedó sana (hijas, volúmenes)?"
        by_id["SP-13"]["archivo"] = "validacion_ordenamiento_conteos.sql"
        by_id["SP-13"]["fuente"] = "REAL"

    for mid, entry in ((e["id"], e) for e in MOCK_SP_ENTRIES):
        if mid not in by_id:
            sps.append(entry)
            by_id[mid] = entry
        else:
            by_id[mid].update(entry)

    for sp in sps:
        sid = sp.get("id")
        if sid in STAR:
            s = STAR[sid]
            sp["objetivo"] = s["objetivo"]
            sp["situacion"] = s["situacion"]
            sp["accion"] = s["accion"]
            sp["resultado"] = s["resultado"]
            sp["por_que"] = s["por_que"]
            sp["ejemplo"] = s["ejemplo"]
            # keep explicacion as short bridge
            sp["explicacion"] = (
                f"Objetivo: {s['objetivo']} Ejemplo: {s['ejemplo']} "
                f"Resultado: {s['resultado']} ¿Por qué?: {s['por_que']}"
            )
    data["sps_detalle"] = sps


def patch_ui(html: str) -> str:
    # Title home
    html = html.replace(
        "Ordenamiento — qué busca (presentación)",
        "Demo — Ordenamiento (recorrido completo)",
        1,
    )
    html = html.replace(
        "Qué busca el Ordenamiento&lt;/div&gt;",
        "Demo — historia y recorrido&lt;/div&gt;",
        1,
    )
    html = html.replace(
        "Presentación general. El detalle de cómo se implementa está en la pestaña &lt;strong&gt;SPs&lt;/strong&gt;; "
        "los ejemplos por canal están en DIR / TEL / CEL / EMA.",
        "Esta es la &lt;strong&gt;Demo&lt;/strong&gt;: texto del recorrido y SPs mock. "
        "Las queries viven en &lt;strong&gt;Workshop&lt;/strong&gt;. "
        "Cada SP en formato STAR está en &lt;strong&gt;SPs&lt;/strong&gt;.",
        1,
    )

    # Replace FRAMES with 3 tabs + WORKSHOP_STEPS
    old_frames = """const FRAMES = [
  { id: &#x27;home&#x27;, label: &#x27;Qué es&#x27;, el: &#x27;frame-home&#x27;, progress: 0 },
  { id: &#x27;fase1&#x27;, label: &#x27;1 Insumos&#x27;, el: &#x27;frame-fase1&#x27;, progress: 14 },
  { id: &#x27;dir&#x27;, label: &#x27;2a DIR&#x27;, el: &#x27;frame-dir&#x27;, progress: 28 },
  { id: &#x27;tel&#x27;, label: &#x27;2b TEL&#x27;, el: &#x27;frame-tel&#x27;, progress: 42 },
  { id: &#x27;cel&#x27;, label: &#x27;2c CEL&#x27;, el: &#x27;frame-cel&#x27;, progress: 56 },
  { id: &#x27;ema&#x27;, label: &#x27;2d EMA&#x27;, el: &#x27;frame-ema&#x27;, progress: 70 },
  { id: &#x27;salida&#x27;, label: &#x27;3-4 Salida&#x27;, el: &#x27;frame-salida&#x27;, progress: 84 },
  { id: &#x27;sps&#x27;, label: &#x27;SPs&#x27;, el: &#x27;frame-sps&#x27;, progress: 100 },
];"""

    new_frames = """const FRAMES = [
  { id: &#x27;demo&#x27;, label: &#x27;Demo&#x27;, el: &#x27;frame-home&#x27;, progress: 0 },
  { id: &#x27;workshop&#x27;, label: &#x27;Workshop&#x27;, el: &#x27;frame-workshop&#x27;, progress: 50 },
  { id: &#x27;sps&#x27;, label: &#x27;SPs&#x27;, el: &#x27;frame-sps&#x27;, progress: 100 },
];
const WORKSHOP_STEPS = [
  { label: &#x27;Insumos&#x27;, el: &#x27;frame-fase1&#x27;, ruleIdx: 1 },
  { label: &#x27;DIR&#x27;, el: &#x27;frame-dir&#x27;, ruleIdx: 2 },
  { label: &#x27;TEL&#x27;, el: &#x27;frame-tel&#x27;, ruleIdx: 3 },
  { label: &#x27;CEL&#x27;, el: &#x27;frame-cel&#x27;, ruleIdx: 4 },
  { label: &#x27;EMA&#x27;, el: &#x27;frame-ema&#x27;, ruleIdx: 5 },
  { label: &#x27;Salida&#x27;, el: &#x27;frame-salida&#x27;, ruleIdx: 6 },
];
let workshopStep = 0;"""

    if old_frames in html:
        html = html.replace(old_frames, new_frames, 1)
        print("  FRAMES ok")
    else:
        print("  WARN FRAMES")

    # Insert workshop frame HTML before frame-fase1
    workshop_html = """
    &lt;div class=&quot;frame frame-off&quot; id=&quot;frame-workshop&quot;&gt;
      &lt;div class=&quot;frame-fit&quot;&gt;
      &lt;div class=&quot;frame-title&quot;&gt;Workshop — queries y casos por canal&lt;/div&gt;
      &lt;div class=&quot;frame-sub&quot;&gt;Elige un bloque. Cada tarjeta trae regla, ejemplo seed y query para DBeaver.&lt;/div&gt;
      &lt;div class=&quot;ws-subnav&quot; id=&quot;wsSubnav&quot;&gt;&lt;/div&gt;
      &lt;div class=&quot;presentacion-block&quot; style=&quot;margin-top:0.75rem&quot;&gt;
        &lt;h4&gt;Cómo usar el Workshop&lt;/h4&gt;
        &lt;p&gt;1) En DBeaver: &lt;code&gt;CALL bdm_stage.sp_ordenamiento_ejecucion_mock();&lt;/code&gt;
        2) Entra a Insumos / DIR / TEL / CEL / EMA / Salida.
        3) Abre &lt;strong&gt;Ver query&lt;/strong&gt; y compara con la tabla del ejemplo (HTML = seed).&lt;/p&gt;
      &lt;/div&gt;
      &lt;/div&gt;
    &lt;/div&gt;
"""
    marker = '&lt;div class=&quot;frame frame-off&quot; id=&quot;frame-fase1&quot;&gt;'
    if "id=&quot;frame-workshop&quot;" not in html and marker in html:
        # only insert in ORD half: last occurrence
        idx = html.rfind(marker)
        html = html[:idx] + workshop_html + html[idx:]
        print("  workshop frame ok")
    else:
        print("  WARN workshop frame")

    # CSS
    css = """
.ws-subnav { display:flex; flex-wrap:wrap; gap:0.4rem; margin:0.5rem 0 0.75rem; }
.ws-subnav button {
  border:1px solid #cbd5e1; background:#fff; border-radius:8px;
  padding:0.4rem 0.75rem; font-size:0.82rem; font-weight:600; cursor:pointer; color:#0f172a;
}
.ws-subnav button.active { background:#1e3a8a; color:#fff; border-color:#1e3a8a; }
.ws-subnav button:hover { border-color:#1e3a8a; }
.star-grid { display:grid; grid-template-columns:1fr 1fr; gap:0.45rem; margin:0.4rem 0; }
.star-box {
  background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px;
  padding:0.45rem 0.6rem; font-size:0.78rem; line-height:1.4; color:#334155;
}
.star-box b { display:block; color:#0f172a; font-size:0.72rem; letter-spacing:0.03em;
  text-transform:uppercase; margin-bottom:0.2rem; }
.star-box.resultado { background:#ecfdf5; border-color:#86efac; grid-column:1 / -1; }
.star-box.porque { background:#eff6ff; border-color:#93c5fd; grid-column:1 / -1; }
@media (max-width: 800px) { .star-grid { grid-template-columns:1fr; } }
"""
    if ".ws-subnav" not in html:
        idx = html.rfind("</style>")
        if idx > 0:
            html = html[:idx] + css + html[idx:]
            print("  CSS ok")

    # Patch showFrame for workshop
    old_show = """function showFrame(idx) {
  currentFrame = idx;
  const f = FRAMES[idx];
  document.getElementById(&#x27;progressBar&#x27;).style.width = f.progress + &#x27;%&#x27;;
  document.querySelectorAll(&#x27;.step-btn&#x27;).forEach((b,i) =&gt; b.classList.toggle(&#x27;active&#x27;, i===idx));
  document.querySelectorAll(&#x27;.frame&#x27;).forEach(fr =&gt; {
    const on = fr.id === f.el;
    fr.classList.toggle(&#x27;frame-on&#x27;, on);
    fr.classList.toggle(&#x27;frame-off&#x27;, !on);
  });
  if (idx &gt;= 1 &amp;&amp; idx &lt;= 6) showRuleScenario(idx, scenarioPos[idx], false);
  if (idx === 7) showSpDetail(spPos, false);
  requestAnimationFrame(() =&gt; requestAnimationFrame(fitRuleStage));
}"""

    new_show = """function showWorkshopStep(stepIdx) {
  workshopStep = Math.max(0, Math.min(stepIdx, WORKSHOP_STEPS.length - 1));
  const ws = WORKSHOP_STEPS[workshopStep];
  document.querySelectorAll(&#x27;.frame&#x27;).forEach(fr =&gt; {
    const on = fr.id === ws.el;
    fr.classList.toggle(&#x27;frame-on&#x27;, on);
    fr.classList.toggle(&#x27;frame-off&#x27;, !on);
  });
  document.querySelectorAll(&#x27;.ws-subnav button&#x27;).forEach((b,i) =&gt; b.classList.toggle(&#x27;active&#x27;, i===workshopStep));
  // keep Demo/Workshop/SPs nav highlighting Workshop
  document.querySelectorAll(&#x27;.step-btn&#x27;).forEach((b,i) =&gt; b.classList.toggle(&#x27;active&#x27;, FRAMES[i] &amp;&amp; FRAMES[i].id===&#x27;workshop&#x27;));
  document.getElementById(&#x27;progressBar&#x27;).style.width = (20 + workshopStep * 12) + &#x27;%&#x27;;
  showRuleScenario(ws.ruleIdx, scenarioPos[ws.ruleIdx] || 0, false);
  // inject subnav into active workshop child if missing
  const fr = document.getElementById(ws.el);
  let bar = fr.querySelector(&#x27;.ws-subnav&#x27;);
  if (!bar) {
    bar = document.createElement(&#x27;div&#x27;);
    bar.className = &#x27;ws-subnav&#x27;;
    const fit = fr.querySelector(&#x27;.frame-fit&#x27;) || fr;
    fit.insertBefore(bar, fit.firstChild);
  }
  bar.innerHTML = WORKSHOP_STEPS.map((s,i) =&gt;
    `&lt;button type=&quot;button&quot; class=&quot;${i===workshopStep?&#x27;active&#x27;:&#x27;&#x27;}&quot; data-ws=&quot;${i}&quot;&gt;${esc(s.label)}&lt;/button&gt;`).join(&#x27;&#x27;);
  bar.querySelectorAll(&#x27;button&#x27;).forEach(btn =&gt; {
    btn.onclick = () =&gt; showWorkshopStep(+btn.dataset.ws);
  });
  requestAnimationFrame(() =&gt; requestAnimationFrame(fitRuleStage));
}

function renderWsLanding() {
  const el = document.getElementById(&#x27;wsSubnav&#x27;);
  if (!el) return;
  el.innerHTML = WORKSHOP_STEPS.map((s,i) =&gt;
    `&lt;button type=&quot;button&quot; data-ws=&quot;${i}&quot;&gt;${esc(s.label)}&lt;/button&gt;`).join(&#x27;&#x27;);
  el.querySelectorAll(&#x27;button&#x27;).forEach(btn =&gt; {
    btn.onclick = () =&gt; showWorkshopStep(+btn.dataset.ws);
  });
}

function showFrame(idx) {
  currentFrame = idx;
  const f = FRAMES[idx];
  document.getElementById(&#x27;progressBar&#x27;).style.width = f.progress + &#x27;%&#x27;;
  document.querySelectorAll(&#x27;.step-btn&#x27;).forEach((b,i) =&gt; b.classList.toggle(&#x27;active&#x27;, i===idx));
  if (f.id === &#x27;workshop&#x27;) {
    // landing first time; if already in a step keep it
    document.querySelectorAll(&#x27;.frame&#x27;).forEach(fr =&gt; {
      const on = fr.id === &#x27;frame-workshop&#x27;;
      fr.classList.toggle(&#x27;frame-on&#x27;, on);
      fr.classList.toggle(&#x27;frame-off&#x27;, !on);
    });
    renderWsLanding();
    return;
  }
  document.querySelectorAll(&#x27;.frame&#x27;).forEach(fr =&gt; {
    const on = fr.id === f.el;
    fr.classList.toggle(&#x27;frame-on&#x27;, on);
    fr.classList.toggle(&#x27;frame-off&#x27;, !on);
  });
  if (f.id === &#x27;sps&#x27;) showSpDetail(spPos, false);
  requestAnimationFrame(() =&gt; requestAnimationFrame(fitRuleStage));
}"""

    if old_show in html:
        html = html.replace(old_show, new_show, 1)
        print("  showFrame ok")
    else:
        print("  WARN showFrame")

    # Fix zoomToFrame / rules cards that used old frame indexes — update renderHome rules to open workshop steps
    # Patch renderSpCard for STAR (last occurrence)
    old_sp_tail = """  const explicacion = sp.explicacion
    ? `&lt;div class=&quot;sp-explicacion&quot;&gt;&lt;strong&gt;Cómo lo hace&lt;/strong&gt;&lt;br/&gt;${esc(sp.explicacion)}&lt;/div&gt;`
    : &#x27;&#x27;;
  return `&lt;div class=&quot;scenario-item sp-detail-card&quot;&gt;
    &lt;div class=&quot;esc-pill paso&quot;&gt;&lt;span class=&quot;esc-code&quot;&gt;${esc(sp.id)}&lt;/span&gt;&lt;span class=&quot;esc-kind&quot;&gt;${esc(sp.fase || sp.grupo)}&lt;/span&gt;&lt;/div&gt;
    &lt;div class=&quot;scenario-body&quot;&gt;
      &lt;div class=&quot;scenario-head&quot;&gt;
        &lt;div class=&quot;scenario-head-main&quot;&gt;
          &lt;span class=&quot;badge ok&quot;&gt;${esc(sp.repo)}&lt;/span&gt;
          &lt;div class=&quot;scenario-head-text&quot;&gt;&lt;h4&gt;&lt;code&gt;${esc(sp.archivo)}&lt;/code&gt;&lt;/h4&gt;&lt;/div&gt;
        &lt;/div&gt;
        &lt;button type=&quot;button&quot; class=&quot;btn btn-query btn-head-query btn-sp-query&quot;&gt;Ver query&lt;/button&gt;
      &lt;/div&gt;
      &lt;p style=&quot;margin:0.35rem 0&quot;&gt;&lt;strong&gt;${esc(sp.rol)}&lt;/strong&gt;&lt;/p&gt;
      ${pregunta}
      ${explicacion}
      &lt;dl&gt;
        &lt;dt&gt;Entra&lt;/dt&gt;&lt;dd&gt;${esc(sp.entra)}&lt;/dd&gt;
        &lt;dt&gt;Sale&lt;/dt&gt;&lt;dd&gt;${esc(sp.sale)}&lt;/dd&gt;
        &lt;dt&gt;Lógica&lt;/dt&gt;&lt;dd&gt;${esc(sp.logica)}&lt;/dd&gt;
      &lt;/dl&gt;
      ${pasosBlock}
      ${ejemplo}
      &lt;pre class=&quot;sp-query-pre&quot;&gt;${esc(sp.query)}&lt;/pre&gt;
    &lt;/div&gt;
  &lt;/div&gt;`;
}"""

    new_sp_tail = """  const star = (sp.objetivo || sp.situacion) ? `
    &lt;div class=&quot;star-grid&quot;&gt;
      &lt;div class=&quot;star-box&quot;&gt;&lt;b&gt;Situación&lt;/b&gt;${esc(sp.situacion || &#x27;&#x27;)}&lt;/div&gt;
      &lt;div class=&quot;star-box&quot;&gt;&lt;b&gt;Objetivo (Tarea)&lt;/b&gt;${esc(sp.objetivo || sp.pregunta || &#x27;&#x27;)}&lt;/div&gt;
      &lt;div class=&quot;star-box&quot;&gt;&lt;b&gt;Acción&lt;/b&gt;${esc(sp.accion || sp.logica || &#x27;&#x27;)}&lt;/div&gt;
      &lt;div class=&quot;star-box&quot;&gt;&lt;b&gt;Ejemplo&lt;/b&gt;${esc(sp.ejemplo || &#x27;&#x27;)}&lt;/div&gt;
      &lt;div class=&quot;star-box resultado&quot;&gt;&lt;b&gt;Resultado&lt;/b&gt;${esc(sp.resultado || &#x27;&#x27;)}&lt;/div&gt;
      &lt;div class=&quot;star-box porque&quot;&gt;&lt;b&gt;Por qué ese resultado&lt;/b&gt;${esc(sp.por_que || &#x27;&#x27;)}&lt;/div&gt;
    &lt;/div&gt;` : &#x27;&#x27;;
  return `&lt;div class=&quot;scenario-item sp-detail-card&quot;&gt;
    &lt;div class=&quot;esc-pill paso&quot;&gt;&lt;span class=&quot;esc-code&quot;&gt;${esc(sp.id)}&lt;/span&gt;&lt;span class=&quot;esc-kind&quot;&gt;${esc(sp.fase || sp.grupo)}&lt;/span&gt;&lt;/div&gt;
    &lt;div class=&quot;scenario-body&quot;&gt;
      &lt;div class=&quot;scenario-head&quot;&gt;
        &lt;div class=&quot;scenario-head-main&quot;&gt;
          &lt;span class=&quot;badge ok&quot;&gt;${esc(sp.repo)}&lt;/span&gt;
          &lt;div class=&quot;scenario-head-text&quot;&gt;&lt;h4&gt;&lt;code&gt;${esc(sp.archivo)}&lt;/code&gt;&lt;/h4&gt;&lt;/div&gt;
        &lt;/div&gt;
        &lt;button type=&quot;button&quot; class=&quot;btn btn-query btn-head-query btn-sp-query&quot;&gt;Ver query&lt;/button&gt;
      &lt;/div&gt;
      &lt;p style=&quot;margin:0.35rem 0&quot;&gt;&lt;strong&gt;${esc(sp.rol)}&lt;/strong&gt;&lt;/p&gt;
      ${pregunta}
      ${star}
      &lt;dl&gt;
        &lt;dt&gt;Entra&lt;/dt&gt;&lt;dd&gt;${esc(sp.entra)}&lt;/dd&gt;
        &lt;dt&gt;Sale&lt;/dt&gt;&lt;dd&gt;${esc(sp.sale)}&lt;/dd&gt;
        &lt;dt&gt;Lógica corta&lt;/dt&gt;&lt;dd&gt;${esc(sp.logica)}&lt;/dd&gt;
      &lt;/dl&gt;
      ${pasosBlock}
      &lt;pre class=&quot;sp-query-pre&quot;&gt;${esc(sp.query)}&lt;/pre&gt;
    &lt;/div&gt;
  &lt;/div&gt;`;
}"""

    if old_sp_tail in html:
        idx = html.rfind(old_sp_tail)
        html = html[:idx] + new_sp_tail + html[idx + len(old_sp_tail) :]
        print("  STAR renderSpCard ok")
    else:
        print("  WARN STAR renderSpCard")

    # Update renderHome rules map to open workshop
    html = html.replace(
        "c.onclick = () =&gt; { scenarioPos[+c.dataset.frame] = 0; showFrame(+c.dataset.frame); };",
        "c.onclick = () =&gt; { const i=+c.dataset.frame; if (i&gt;=1 &amp;&amp; i&lt;=6) { scenarioPos[i]=0; showFrame(1); showWorkshopStep(i-1); } else if (i===7) showFrame(2); else showFrame(0); };",
    )

    # frame-sps subtitle
    html = html.replace(
        "Cómo se implementa lo de la presentación: cada SP explica su parte del flujo",
        "Cada SP en metodología STAR: Situación · Objetivo · Acción · Ejemplo · Resultado · Por qué",
        1,
    )

    # banner
    html = html.replace(
        "Qué busca: ordenar contactos vigentes por canal. Cómo: pestaña SPs. "
        "Ejemplos: DIR/TEL/CEL/EMA con seed. Opción A · solo ganadoras · betas RITM.",
        "Demo = historia + seed mock. Workshop = queries por canal. SPs = STAR (objetivo, ejemplo, por qué). "
        "Opción A · solo ganadoras · betas RITM.",
    )

    # Fix idx===7 references for sps if any remain in showFrame already replaced
    # init: ensure WORKSHOP doesn't break initRuleFrames
    return html


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    assert len(positions) >= 2
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    patch_data(data)
    html = html[:start] + to_html_json(data) + html[end:]
    html = patch_ui(html)
    bak = path.with_suffix(path.suffix + ".bak_demo_ws")
    if not bak.exists():
        shutil.copy2(path, bak)
    path.write_text(html, encoding="utf-8")
    print("OK", path.name, "sps", len(data["sps_detalle"]))


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)
        else:
            print("SKIP", p)


if __name__ == "__main__":
    main()
