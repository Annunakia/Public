# -*- coding: utf-8 -*-
"""
Quita el 'resumen' confuso.
Home = presentación en texto de qué busca Ordenamiento.
SPs = cómo se hace cada parte.
Fase 1 = solo insumos (sin RESUMEN/FLUJO/queries sin sentido).
"""
from __future__ import annotations

import json
import re
import shutil
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
]

# Filas a eliminar del carrusel (confundían con "resumen" + queries raras)
DROP_PACKS = {
    "RESUMEN",
    "FLUJO",
    "ALCANCE",
    "SP-PREP",
    "SP-ORQ",
    "BITBUCKET",
    "VALID",
}

PRESENTACION = [
    {
        "titulo": "Qué busca el Ordenamiento",
        "texto": (
            "Después de Unificación, una persona puede seguir teniendo varias direcciones, "
            "teléfonos, celulares o emails vigentes. El Ordenamiento responde una sola pregunta "
            "de negocio: si hay que contactar a esa persona, ¿con qué dato se empieza y en qué orden "
            "se intentan los demás? No redefine quién es padre o hija; eso ya lo resolvió Unificación. "
            "Solo ordena contactos útiles para el intento."
        ),
    },
    {
        "titulo": "Regla de entrada: solo ganadoras",
        "texto": (
            "Solo compiten las direcciones ganadoras (las que Unificación dejó vigentes). "
            "Si una RPU quedó como hija (ind_unificacion = 1), no recibe score ni orden: "
            "ya no es un contacto a intentar. TEL, CEL y EMA también exigen que la persona "
            "tenga al menos una dirección ganadora. Sin eso, el dato no entra."
        ),
    },
    {
        "titulo": "Cuatro canales, cada uno aparte",
        "texto": (
            "Se rankean por separado: DIR (calle), TEL (fijo), CEL (celular) y EMA (email). "
            "El lugar 1 de un canal no se compara con el de otro. "
            "Así, la mejor calle y el mejor fijo pueden ser lugar 1 a la vez: son respuestas "
            "a preguntas distintas (¿qué dirección? ¿qué teléfono?)."
        ),
    },
    {
        "titulo": "Cómo se decide el orden (idea general)",
        "texto": (
            "Cada contacto se convierte en un score: se toman características del dato, "
            "se ponderan con los pesos del catálogo RITM (47 betas acordados en mesa) "
            "y se suman. El mayor score del canal obtiene el lugar 1; el siguiente el lugar 2, "
            "y así. Algunas variables se calculan para trazabilidad pero no entran a la suma "
            "(por ejemplo TEL020 o ciertos EMA): no deben mover el ranking."
        ),
    },
    {
        "titulo": "Del insumo al resultado",
        "texto": (
            "Primero se arma el insumo: ¿quién entra y a qué canal? "
            "(ganadoras, contactType, datos válidos). "
            "Después corre el scoring por canal. "
            "Al final, el lugar de DIR se guarda como orden_prioridad para que el consumidor "
            "sepa el orden de intento. El staging vive solo la corrida y se limpia al terminar."
        ),
    },
    {
        "titulo": "Qué ver en las demás pestañas",
        "texto": (
            "Insumos: quién entra (contactType, ganadoras, betas). "
            "DIR / TEL / CEL / EMA: casos concretos con el seed verificable en DBeaver. "
            "Salida: cómo queda orden_prioridad. "
            "SPs: el cómo técnico — cada procedimiento explica qué parte del acuerdo de negocio implementa, "
            "qué entra, qué sale y en qué orden corre."
        ),
    },
]

# Explicaciones largas por id de SP (cómo implementa el qué)
SP_EXPLICACION = {
    "SP-00": (
        "Crea el lugar donde vive el resultado del ordenamiento: tablas de score, "
        "orden_prioridad y betas. Sin este DDL no hay dónde guardar el ranking que la mesa acordó."
    ),
    "SP-01": (
        "Carga catálogos de apoyo (operador celular, etc.). "
        "Así el scoring de CEL puede traducir un prefijo a un peso; si no hay mapeo, usa el default 0.22 acordado."
    ),
    "SP-02": (
        "Traduce el contactType de XPM al canal de negocio (DIR/TEL/CEL/EMA). "
        "Es el puente entre ‘qué tipo de dato llegó’ y ‘en qué ranking compite’."
    ),
    "SP-03": (
        "Expone solo ganadoras post-unificación y las vistas de insumo por canal, "
        "sin copiar de forma permanente el productor. Aquí se concreta ‘hijas fuera’."
    ),
    "SP-04": (
        "Es el paso ‘armar candidatos’ de la corrida: una lectura del datashare, "
        "marca ganadoras/hijas, filtra emails sin @ y deja bandejas stg_insumo_* listas para puntuar. "
        "Si este SP no corre, el scoring no tiene insumo confiable."
    ),
    "SP-05": (
        "Aplica la fórmula de score DIR (características × betas) y asigna lugar 1, 2, 3… "
        "entre direcciones ganadoras de la misma persona. Responde: ¿qué calle intento primero?"
    ),
    "SP-06": (
        "Puntúa teléfonos fijos de forma independiente de DIR. "
        "Incluye la regla de que TEL020 no sume al score final (baseline acordado)."
    ),
    "SP-07": (
        "Puntúa celulares: operador por prefijo y default 0.22 si no está en catálogo. "
        "Ranking aparte de DIR/TEL/EMA."
    ),
    "SP-08": (
        "Puntúa emails. Variables EMA003/007/018/025 pueden calcularse pero no mueven la sumatoria, "
        "como en el baseline Teradata/doc v2.0."
    ),
    "SP-09": (
        "Toma el mejor lugar DIR de cada RPU ganadora y lo persiste en orden_prioridad. "
        "Es la salida que consume el negocio para el orden de intento en calle."
    ),
    "SP-10": (
        "Borra el staging temporal al terminar. El insumo no debe quedar como copia permanente entre corridas."
    ),
    "SP-11": (
        "Orquestador Opción A: preparar insumos → scoring ×4 → consolidar → drop, en ese orden. "
        "Es la secuencia Control-M / ejecución full que la mesa validó."
    ),
    "SP-12": (
        "Carga el catálogo de 47 betas RITM5226589. Redshift no inventa pesos: los aplica en el scoring."
    ),
    "SP-13": (
        "Suite seed/mock para verificar en DBeaver los mismos ejemplos del HTML (personas 20001–20014) "
        "sin depender del Caso A/B histórico en el datashare."
    ),
}


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def patch_data(data: dict) -> None:
    data["presentacion"] = PRESENTACION
    data["guion_sesion"] = []  # ya no se usa
    data["generated"] = "2026-09-25"

    before = len(data.get("rows") or [])
    data["rows"] = [r for r in (data.get("rows") or []) if r.get("_pack_code") not in DROP_PACKS]
    print(f"  rows {before} -> {len(data['rows'])}")

    # Sin query en filas de Fase 1 conceptuales si quedara alguna rara — mantener queries de casos seed
    for row in data["rows"]:
        if row.get("_pack_code") in ("INSUMO-CT", "BETAS"):
            # queries de mapa/conteo ok; ok leave
            pass

    for sp in data.get("sps_detalle") or []:
        sid = sp.get("id")
        if sid in SP_EXPLICACION:
            sp["explicacion"] = SP_EXPLICACION[sid]
        # tono más claro en rol/pregunta si vienen cortos
        if sid == "SP-04":
            sp["pregunta"] = "¿Cómo se arma la lista de quién entra a puntuar?"
            sp["rol"] = "Preparar insumos de la corrida (armar candidatos)"
        if sid == "SP-11":
            sp["pregunta"] = "¿En qué orden corre todo el ordenamiento?"
            sp["rol"] = "Orquestar: insumos → scores → orden → limpiar"
        if sid == "SP-13":
            sp["pregunta"] = "¿Cómo verifico en DBeaver los ejemplos del HTML?"
            sp["rol"] = "Seed mock alineado al HTML (20001–20014)"


def patch_ui(html: str) -> str:
    # --- Home section 0: presentation instead of guion ---
    old_sec = (
        "&lt;div class=&quot;drill-section-title&quot;&gt;0 · Resumen del recorrido&lt;/div&gt;\n"
        "        &lt;p class=&quot;drill-section-note&quot;&gt;Resumen del recorrido — ganadoras, catálogo betas, canales aparte.&lt;/p&gt;\n"
        "        &lt;div class=&quot;guion-grid&quot; id=&quot;guionGrid&quot;&gt;&lt;/div&gt;"
    )
    new_sec = (
        "&lt;div class=&quot;drill-section-title&quot;&gt;Qué busca el Ordenamiento&lt;/div&gt;\n"
        "        &lt;p class=&quot;drill-section-note&quot;&gt;"
        "Presentación general. El detalle de cómo se implementa está en la pestaña &lt;strong&gt;SPs&lt;/strong&gt;; "
        "los ejemplos por canal están en DIR / TEL / CEL / EMA.&lt;/p&gt;\n"
        "        &lt;div class=&quot;presentacion-wrap&quot; id=&quot;presentacionWrap&quot;&gt;&lt;/div&gt;"
    )
    if old_sec in html:
        html = html.replace(old_sec, new_sec)
        print("  section0 replaced")
    else:
        # fallback looser
        html2, n = re.subn(
            r"&lt;div class=&quot;drill-section-title&quot;&gt;0 · Resumen del recorrido&lt;/div&gt;"
            r".*?id=&quot;guionGrid&quot;&gt;&lt;/div&gt;",
            new_sec,
            html,
            count=1,
            flags=re.S,
        )
        if n:
            html = html2
            print("  section0 regex ok")
        else:
            print("  WARN section0 not found")

    # frame title
    html = html.replace(
        "Cómo explicarlo — alineado a Mesa / Sesión Alineación",
        "Ordenamiento — qué busca (presentación)",
        1,
    )
    html = html.replace(
        "8 · Resumen DEV",
        "8 · Números en DEV",
        1,
    )

    # FRAMES home label
    html = html.replace(
        "{ id: &#x27;home&#x27;, label: &#x27;Drill-down&#x27;, el: &#x27;frame-home&#x27;, progress: 0 }",
        "{ id: &#x27;home&#x27;, label: &#x27;Qué es&#x27;, el: &#x27;frame-home&#x27;, progress: 0 }",
        1,
    )

    # RULE_FRAMES: Fase 1 solo insumos
    old_rf = (
        "{ regla: &#x27;PUNTO DE PARTIDA&#x27;, nav: &#x27;nav-fase1&#x27;, stage: &#x27;stage-fase1&#x27;, "
        "extra: [&#x27;ALCANCE&#x27;, &#x27;FASE 1&#x27;, &#x27;ARQUITECTURA SP&#x27;, &#x27;REPOS&#x27;] }"
    )
    new_rf = (
        "{ regla: &#x27;FASE 1&#x27;, nav: &#x27;nav-fase1&#x27;, stage: &#x27;stage-fase1&#x27; }"
    )
    if old_rf in html:
        html = html.replace(old_rf, new_rf, 1)
        print("  RULE_FRAMES ok")
    else:
        print("  WARN RULE_FRAMES")

    # CSS for presentacion
    css = """
.presentacion-wrap { display: flex; flex-direction: column; gap: 0.75rem; margin-top: 0.5rem; }
.presentacion-block {
  background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px;
  padding: 0.85rem 1rem;
}
.presentacion-block h4 {
  margin: 0 0 0.4rem; font-size: 0.95rem; color: #0f172a; font-weight: 700;
}
.presentacion-block p {
  margin: 0; font-size: 0.88rem; line-height: 1.55; color: #334155;
}
.sp-explicacion {
  background: #eff6ff; border: 1px solid #93c5fd; border-radius: 8px;
  padding: 0.55rem 0.75rem; margin: 0.35rem 0 0.5rem;
  font-size: 0.84rem; line-height: 1.5; color: #1e3a8a;
}
"""
    if ".presentacion-wrap" not in html:
        # insert before last </style> in ord half — find style after frame-home ord
        idx = html.rfind("</style>")
        if idx > 0:
            html = html[:idx] + css + html[idx:]
            print("  CSS ok")

    # renderGuion -> renderPresentacion
    old_guion_fn = """function renderGuion() {
  const items = DATA.guion_sesion || [];
  document.getElementById(&#x27;guionGrid&#x27;).innerHTML = items.map(g =&gt; `
    &lt;div class=&quot;guion-card&quot;&gt;
      &lt;div class=&quot;paso&quot;&gt;PASO ${esc(g.paso)}&lt;/div&gt;
      &lt;h4&gt;${esc(g.titulo)}&lt;/h4&gt;
      &lt;p&gt;${esc(g.decir)}&lt;/p&gt;
    &lt;/div&gt;`).join(&#x27;&#x27;);
}"""
    new_pres_fn = """function renderPresentacion() {
  const items = DATA.presentacion || [];
  const el = document.getElementById(&#x27;presentacionWrap&#x27;);
  if (!el) return;
  el.innerHTML = items.map(b =&gt; `
    &lt;div class=&quot;presentacion-block&quot;&gt;
      &lt;h4&gt;${esc(b.titulo)}&lt;/h4&gt;
      &lt;p&gt;${esc(b.texto)}&lt;/p&gt;
    &lt;/div&gt;`).join(&#x27;&#x27;);
}"""
    if old_guion_fn in html:
        html = html.replace(old_guion_fn, new_pres_fn, 1)
        print("  renderPresentacion ok")
    else:
        print("  WARN renderGuion fn")

    html = html.replace("renderGuion();", "renderPresentacion();")
    # banner
    html = html.replace(
        "Empieza por el &lt;strong&gt;resumen §0&lt;/strong&gt;.",
        "Empieza por la &lt;strong&gt;presentación&lt;/strong&gt; (qué busca).",
    )
    html = html.replace(
        "Lenguaje de mesa: Unificación primero · solo ganadoras · armar insumos · "
        "4 canales aparte · betas = catálogo RITM · Opción A EDF.",
        "Qué busca: ordenar contactos vigentes por canal. Cómo: pestaña SPs. "
        "Ejemplos: DIR/TEL/CEL/EMA con seed. Opción A · solo ganadoras · betas RITM.",
    )

    # renderSpCard: add explicacion block
    old_sp = """  const ejemplo = sp.ejemplo
    ? `&lt;div class=&quot;scenario-section conclusion-box&quot;&gt;&lt;span class=&quot;sec-label&quot;&gt;Ejemplo&lt;/span&gt;&lt;p&gt;${esc(sp.ejemplo)}&lt;/p&gt;&lt;/div&gt;`
    : &#x27;&#x27;;
  return `&lt;div class=&quot;scenario-item sp-detail-card&quot;&gt;
    &lt;div class=&quot;esc-pill paso&quot;&gt;&lt;span class=&quot;esc-code&quot;&gt;${esc(sp.id)}&lt;/span&gt;&lt;span class=&quot;esc-kind&quot;&gt;${esc(sp.fase || sp.grupo)}&lt;/span&gt;&lt;/div&gt;
    &lt;div class=&quot;scenario-body&quot;&gt;
      &lt;div class=&quot;scenario-head&quot;&gt;
        &lt;div class=&quot;scenario-head-main&quot;&gt;
          &lt;span class=&quot;badge ok&quot;&gt;${esc(sp.repo)}&lt;/span&gt;
          &lt;div class=&quot;scenario-head-text&quot;&gt;&lt;h4&gt;&lt;code&gt;${esc(sp.archivo)}&lt;/code&gt;&lt;/h4&gt;&lt;/div&gt;
        &lt;/div&gt;
        &lt;button type=&quot;button&quot; class=&quot;btn btn-query btn-head-query btn-sp-query&quot;&gt;Ver query&lt;/button&gt;
      &lt;/div&gt;
      &lt;p style=&quot;margin:0.35rem 0&quot;&gt;&lt;strong&gt;${esc(sp.rol)}&lt;/strong&gt;&lt;/p&gt;
      ${pregunta}
      &lt;dl&gt;"""

    new_sp = """  const ejemplo = sp.ejemplo
    ? `&lt;div class=&quot;scenario-section conclusion-box&quot;&gt;&lt;span class=&quot;sec-label&quot;&gt;Ejemplo&lt;/span&gt;&lt;p&gt;${esc(sp.ejemplo)}&lt;/p&gt;&lt;/div&gt;`
    : &#x27;&#x27;;
  const explicacion = sp.explicacion
    ? `&lt;div class=&quot;sp-explicacion&quot;&gt;&lt;strong&gt;Cómo lo hace&lt;/strong&gt;&lt;br/&gt;${esc(sp.explicacion)}&lt;/div&gt;`
    : &#x27;&#x27;;
  return `&lt;div class=&quot;scenario-item sp-detail-card&quot;&gt;
    &lt;div class=&quot;esc-pill paso&quot;&gt;&lt;span class=&quot;esc-code&quot;&gt;${esc(sp.id)}&lt;/span&gt;&lt;span class=&quot;esc-kind&quot;&gt;${esc(sp.fase || sp.grupo)}&lt;/span&gt;&lt;/div&gt;
    &lt;div class=&quot;scenario-body&quot;&gt;
      &lt;div class=&quot;scenario-head&quot;&gt;
        &lt;div class=&quot;scenario-head-main&quot;&gt;
          &lt;span class=&quot;badge ok&quot;&gt;${esc(sp.repo)}&lt;/span&gt;
          &lt;div class=&quot;scenario-head-text&quot;&gt;&lt;h4&gt;&lt;code&gt;${esc(sp.archivo)}&lt;/code&gt;&lt;/h4&gt;&lt;/div&gt;
        &lt;/div&gt;
        &lt;button type=&quot;button&quot; class=&quot;btn btn-query btn-head-query btn-sp-query&quot;&gt;Ver query&lt;/button&gt;
      &lt;/div&gt;
      &lt;p style=&quot;margin:0.35rem 0&quot;&gt;&lt;strong&gt;${esc(sp.rol)}&lt;/strong&gt;&lt;/p&gt;
      ${pregunta}
      ${explicacion}
      &lt;dl&gt;"""

    # Only replace the LAST occurrence (ord block)
    if old_sp in html:
        idx = html.rfind(old_sp)
        html = html[:idx] + new_sp + html[idx + len(old_sp) :]
        print("  renderSpCard ok")
    else:
        print("  WARN renderSpCard")

    # frame-sps subtitle
    html = html.replace(
        "Pregunta de negocio + id_buro=2848501447849812647 · _strct · _pgm · _dt",
        "Cómo se implementa lo de la presentación: cada SP explica su parte del flujo",
        1,
    )

    return html


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    assert len(positions) >= 2

    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    patch_data(data)
    html = html[:start] + to_html_json(data) + html[end:]
    html = patch_ui(html)

    bak = path.with_suffix(path.suffix + ".bak_presentacion")
    if not bak.exists():
        shutil.copy2(path, bak)
    path.write_text(html, encoding="utf-8")
    print("OK", path.name)


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)
        else:
            print("SKIP", p)


if __name__ == "__main__":
    main()
