# -*- coding: utf-8 -*-
"""Workshop: scroll vertical + arreglar font-size corrupto 611rem."""
from __future__ import annotations

from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

SCROLL_CSS = """
/* Workshop: scroll para ver conclusiones largas */
.scenario-stage {
  overflow-x: hidden !important;
  overflow-y: auto !important;
  min-height: 0 !important;
  align-items: stretch !important;
  display: block !important;
  -webkit-overflow-scrolling: touch;
  padding-bottom: 1rem;
}
.scenario-stage .scenario-item {
  width: 100% !important;
  max-width: 100% !important;
  transform: none !important;
  height: auto !important;
}
.frame-fit.rule-frame {
  overflow: hidden;
  min-height: 0;
}
.frame-fit.rule-frame > .ws-subnav {
  flex-shrink: 0;
  position: sticky;
  top: 0;
  z-index: 5;
  background: var(--white);
  padding: 0.35rem 0.45rem 0.45rem;
  border-bottom: 1px solid var(--line);
  margin: 0 0 0.25rem;
}
.rule-layout {
  overflow: hidden;
  min-height: 0;
}
#frame-workshop .frame-fit {
  overflow-x: hidden;
  overflow-y: auto;
}
.sp-inline-card .porque,
.conclusion-box p,
.scenario-section p {
  overflow-wrap: anywhere;
  word-break: break-word;
}
"""

# fitRuleStage: no escalar; dejar scroll
FIT_OLD = """function fitRuleStage() {
  const fr = document.querySelector(&#x27;.frame.frame-on&#x27;);
  if (!fr || fr.id === &#x27;frame-sps&#x27; || !fr.querySelector(&#x27;.rule-layout&#x27;)) return;
  const stage = fr.querySelector(&#x27;.scenario-stage&#x27;);
  const item = stage?.querySelector(&#x27;.scenario-item&#x27;);
  if (!stage || !item) return;
  item.style.transform = &#x27;&#x27;;
  item.style.width = &#x27;&#x27;;
  const sh = stage.clientHeight, sw = stage.clientWidth;
  if (sh &lt; 20 || sw &lt; 20) return;
  const scale = Math.min(1, sw / Math.max(item.scrollWidth,1), sh / Math.max(item.scrollHeight,1));
  const s = Math.max(0.72, scale);
  if (s &lt; 0.992) {
    item.style.transform = `scale(${s})`;
    item.style.transformOrigin = &#x27;top left&#x27;;
    item.style.width = `${100/s}%`;
  }
}"""

FIT_NEW = """function fitRuleStage() {
  const fr = document.querySelector(&#x27;.frame.frame-on&#x27;);
  if (!fr || !fr.querySelector(&#x27;.rule-layout&#x27;)) return;
  const stage = fr.querySelector(&#x27;.scenario-stage&#x27;);
  const item = stage?.querySelector(&#x27;.scenario-item&#x27;);
  if (!stage || !item) return;
  /* Sin scale: el stage hace scroll-y para ver todo el texto */
  item.style.transform = &#x27;&#x27;;
  item.style.width = &#x27;&#x27;;
  item.style.transformOrigin = &#x27;&#x27;;
}"""


def patch(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    n = 0

    # Fix corrupted font sizes (both unif + ord srcdocs)
    for old, new in [
        (
            "font-size: 611.8280rem; font-weight: 600; color: var(--text); margin-top: 0.15rem; line-height: 1.4;",
            "font-size: 0.76rem; font-weight: 600; color: var(--text); margin-top: 0.15rem; line-height: 1.4;",
        ),
        (
            "font-size: 611.8280rem; color: var(--text); line-height: 1.5; margin: 0;",
            "font-size: 0.82rem; color: var(--text); line-height: 1.5; margin: 0;",
        ),
    ]:
        c = html.count(old)
        if c:
            html = html.replace(old, new)
            n += c
            print(f"  fixed font-size x{c}")

    # Inject scroll CSS into ord iframe style (before </style>)
    marker = "/* Workshop: scroll para ver conclusiones largas */"
    oi = html.find("Mapa Ordenamiento")
    if oi >= 0:
        style_end = html.find("&lt;/style&gt;", oi)
        if style_end > 0:
            if marker in html[oi:style_end]:
                prev = html.rfind(marker, oi, style_end)
                html = html[:prev] + html[style_end:]
                style_end = html.find("&lt;/style&gt;", oi)
            if '"' in SCROLL_CSS:
                # only check raw double quotes that would break srcdoc
                raise SystemExit("SCROLL_CSS has double quotes")
            html = html[:style_end] + SCROLL_CSS + html[style_end:]
            print("  scroll CSS in iframe ok")
        else:
            print("  WARN no style end")
    else:
        print("  WARN no ord iframe")

    # Also inject into unif iframe for same scroll behavior
    ui = html.find("Mapa Unificación")
    if ui >= 0:
        style_end = html.find("&lt;/style&gt;", ui)
        if style_end > 0 and marker not in html[ui:style_end]:
            html = html[:style_end] + SCROLL_CSS + html[style_end:]
            print("  scroll CSS in unif ok")

    # Replace fitRuleStage in ord (last) and ideally both
    if FIT_OLD in html:
        html = html.replace(FIT_OLD, FIT_NEW)
        print("  fitRuleStage disabled scale x", html.count(FIT_NEW))
    elif "Sin scale: el stage hace scroll-y" in html:
        print("  fitRuleStage already patched")
    else:
        # try replacing last occurrence of scale logic more loosely
        print("  WARN fitRuleStage exact block not found — trying loose")
        loose = "const scale = Math.min(1, sw / Math.max(item.scrollWidth,1), sh / Math.max(item.scrollHeight,1));"
        if loose in html:
            # replace entire function bodies that contain scale — both
            import re

            pat = re.compile(
                r"function fitRuleStage\(\) \{.*?\n\}",
                re.S,
            )
            html2, cnt = pat.subn(FIT_NEW.replace("&#x27;", "'").replace("&lt;", "<"), html)
            # Wait - FIT_NEW uses entities for the file. Keep entities version.
            html2, cnt = pat.subn(FIT_NEW, html)
            if cnt:
                html = html2
                print(f"  fitRuleStage replaced via regex x{cnt}")
            else:
                print("  FAIL fitRuleStage")
        else:
            print("  FAIL no scale in fitRuleStage")

    path.write_text(html, encoding="utf-8")
    chunk = html[html.find("Mapa Ordenamiento") : html.find('"></iframe>', html.find("Mapa Ordenamiento"))]
    print(
        "OK",
        path.name,
        "scroll CSS",
        marker in chunk,
        "no 611rem",
        "611.8280rem" not in html,
        "fit noop",
        "Sin scale" in chunk,
    )


def main():
    for p in PATHS:
        if p.exists():
            patch(p)


if __name__ == "__main__":
    main()
