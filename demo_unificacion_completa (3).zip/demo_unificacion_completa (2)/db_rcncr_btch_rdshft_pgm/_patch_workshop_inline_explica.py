# -*- coding: utf-8 -*-
"""
Workshop sin diccionario: cada vez que aparece un concepto, se explica en la misma frase.
Reglas por fase 1 / 2a–2d / 3 / 4 con ejemplo al lado.
"""
from __future__ import annotations

import json
import re
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

PRESENTACION = [
    {
        "titulo": "Qué estamos resolviendo",
        "lead": (
            "Después de unificar, una persona puede tener varias casas, oficinas, fijos, "
            "celulares o correos. El ordenamiento solo responde: ¿cuál intento primero?"
        ),
        "bullets": [
            "Abajo van las reglas por fase.",
            "En cada fase: a la izquierda la regla (explicada en la misma frase) y a la derecha el ejemplo.",
        ],
    },
    {
        "titulo": "Reglas de negocio por fase (con ejemplo al lado)",
        "lead": (
            "Cada regla se dice en lenguaje de mesa: si hay una palabra ‘técnica’, "
            "en la misma frase se dice qué quiere decir. El ejemplo va pegado a la derecha."
        ),
        "layout": "fases_lado_a_lado",
        "fases": [
            {
                "fase": "0 → 1",
                "nombre": "¿Quién entra a ordenar?",
                "pregunta": "¿Qué contactos pasan a comparar y cuáles se quedan fuera?",
                "reglas": [
                    {
                        "titulo": "Solo el domicilio que sí usamos",
                        "texto": (
                            "Entra la dirección ganadora, es decir el domicilio vigente después de unificar "
                            "(la casa u oficina que sí vamos a contactar). "
                            "No entra la dirección hija, es decir la que ya quedó absorbida y ya no usamos."
                        ),
                    },
                    {
                        "titulo": "Cada cosa se ordena solo con las de su tipo",
                        "texto": (
                            "Las direcciones se ordenan entre direcciones (bandeja DIR). "
                            "Los fijos entre fijos (TEL). Los celulares entre celulares (CEL). "
                            "Los correos entre correos (EMA). Un fijo no compite contra un email."
                        ),
                    },
                    {
                        "titulo": "Correo sin @ no entra",
                        "texto": (
                            "Si el correo no tiene arroba, no es usable: no pasa a ordenar con los demás emails."
                        ),
                    },
                    {
                        "titulo": "Fijo, celular o correo solo si ya hay un domicilio que sí usamos",
                        "texto": (
                            "«Necesita dirección ganadora» quiere decir: ese teléfono o correo solo entra "
                            "si la persona ya tiene al menos un domicilio vigente (uno que sí contactamos). "
                            "Si no tiene ninguno, no ordenamos ni intentamos ese fijo/celular/correo."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo al lado",
                    "caso": "Persona 20011 (padre e hija) y chequeos de quién entra",
                    "pasos": [
                        "Padre 91018 = domicilio que sí usamos → SÍ entra a ordenar direcciones.",
                        "Hija 91019 = domicilio ya absorbido → NO recibe puntaje ni orden de intento.",
                        "Un mail sin @ → NO entra con los correos.",
                        "Un celular de alguien sin ningún domicilio vigente → NO entra con los celulares.",
                    ],
                    "tabla": {
                        "headers": ["Contacto", "¿Entra?", "Por qué (en simple)"],
                        "rows": [
                            ["Padre (domicilio que sí usamos)", "Sí", "Vigente tras unificar"],
                            ["Hija (domicilio absorbido)", "No", "Ya no lo contactamos"],
                            ["mail_sin_arroba.com", "No", "Sin @"],
                            ["Celular sin domicilio vigente", "No", "No hay domicilio que sí usamos"],
                        ],
                    },
                },
            },
            {
                "fase": "2a",
                "nombre": "Ordenar direcciones (casa / oficina)",
                "pregunta": "¿Intento primero la casa o la oficina?",
                "reglas": [
                    {
                        "titulo": "Compiten solo domicilios que sí usamos",
                        "texto": (
                            "Casa y oficina, si las dos son vigentes (direcciones ganadoras), "
                            "se comparan entre sí en la bandeja de direcciones."
                        ),
                    },
                    {
                        "titulo": "Gana el mayor puntaje",
                        "texto": (
                            "El score (puntaje) se arma sumando señales, es decir datos que aportan "
                            "(historial, tipo de dirección, etc.), cada una multiplicada por su peso "
                            "del catálogo acordado. Más puntaje = se intenta antes (lugar 1, luego 2…)."
                        ),
                    },
                    {
                        "titulo": "Ese orden es el que después sale a campo",
                        "texto": (
                            "El lugar 1 de direcciones será el 1º intento en calle "
                            "(cuando guardemos el orden de intento)."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo al lado — persona 20001",
                    "caso": "Casa 91001 y oficina 91002 (las dos vigentes)",
                    "pasos": [
                        "Las dos entran porque son domicilios que sí usamos.",
                        "Calculamos puntaje: casa 850, oficina 700.",
                        "Casa queda 1º; oficina 2º.",
                        "En campo: primero casa, después oficina.",
                    ],
                    "tabla": {
                        "headers": ["Dirección", "¿La usamos?", "Puntaje", "Orden de intento"],
                        "rows": [
                            ["Casa 91001", "Sí (vigente)", "850", "1º"],
                            ["Oficina 91002", "Sí (vigente)", "700", "2º"],
                        ],
                    },
                },
            },
            {
                "fase": "2b",
                "nombre": "Ordenar teléfonos fijos",
                "pregunta": "¿Cuál fijo intento primero?",
                "reglas": [
                    {
                        "titulo": "Solo fijos contra fijos",
                        "texto": (
                            "Un fijo no se compara con la casa ni con el celular: "
                            "solo se ordena dentro de la bandeja de fijos."
                        ),
                    },
                    {
                        "titulo": "El fijo válido va primero",
                        "texto": (
                            "Si uno está marcado como válido (usable) y el otro no, "
                            "el válido queda de primeras; el no válido no manda."
                        ),
                    },
                    {
                        "titulo": "La señal de geo no cambia quién gana",
                        "texto": (
                            "Hay un dato de cercanía/geo que se puede calcular para seguimiento, "
                            "pero no suma al puntaje. Por eso dos fijos pueden quedar iguales "
                            "aunque ese dato sea distinto."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo al lado — persona 20004 / 20013",
                    "caso": "Dos fijos: uno válido y uno no",
                    "pasos": [
                        "20004: válido puntaje 420 → 1º; no válido 210 → 2º.",
                        "20013: aunque la geo cambie, ambos quedan 376.5 (ese dato no suma al puntaje).",
                    ],
                    "tabla": {
                        "headers": ["Caso", "Fijo", "Resultado"],
                        "rows": [
                            ["20004", "Válido (usable)", "420 → 1º"],
                            ["20004", "No válido", "210 → 2º"],
                            ["20013", "Ambos (geo distinta)", "376.5 y 376.5 (iguales)"],
                        ],
                    },
                },
            },
            {
                "fase": "2c",
                "nombre": "Ordenar celulares",
                "pregunta": "¿Cómo sé el operador y qué pasa si no está en la tabla?",
                "reglas": [
                    {
                        "titulo": "Miramos los 3 primeros dígitos",
                        "texto": (
                            "El prefijo (ej. 310) se busca en la tabla de operadores del catálogo: "
                            "ahí vemos si es Claro, Movistar, etc."
                        ),
                    },
                    {
                        "titulo": "Si está en la tabla, usamos ese peso",
                        "texto": (
                            "El peso es cuánto aporta ese operador al puntaje del celular. "
                            "No se inventa en la corrida: sale de la tabla acordada."
                        ),
                    },
                    {
                        "titulo": "Si no está, usamos el valor por defecto 0.22",
                        "texto": (
                            "Ejemplo prefijo 999: no asumimos Claro ni Movistar. "
                            "Aplicamos el default acordado para que el celular sí entre al orden "
                            "y no quede en cero."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo al lado — persona 20012",
                    "caso": "Celular con prefijo 999 (no está en la tabla de operadores)",
                    "pasos": [
                        "Tomamos los 3 primeros dígitos: 999.",
                        "Buscamos 999 en la tabla: no está.",
                        "Aplicamos el valor por defecto 0.22 → puntaje de ejemplo 220 → 1º.",
                        "El celular sí se ordena; no queda en blanco.",
                    ],
                    "tabla": {
                        "headers": ["Prefijo (3 dígitos)", "¿Está en la tabla?", "Qué hacemos", "Efecto"],
                        "rows": [
                            ["310", "Sí", "Usamos el peso del operador", "Suma al puntaje del celular"],
                            ["999", "No", "Valor por defecto 0.22", "Puntaje 220; no queda en cero"],
                        ],
                    },
                },
            },
            {
                "fase": "2d",
                "nombre": "Ordenar correos",
                "pregunta": "¿Qué correos compiten y qué datos no mueven el orden?",
                "reglas": [
                    {
                        "titulo": "Solo correos con @ y con domicilio que sí usamos",
                        "texto": (
                            "Sin arroba no entra. Y la persona debe tener al menos un domicilio vigente; "
                            "si no, ese correo tampoco entra a ordenar."
                        ),
                    },
                    {
                        "titulo": "Algunos datos se calculan pero no suman al puntaje",
                        "texto": (
                            "Ciertas variables del email se pueden guardar para seguimiento, "
                            "pero no cambian quién va primero. Si solo cambian esas, el puntaje del correo no se mueve."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo al lado — persona 20014",
                    "caso": "Correo ‘base’ vs correo solo con variables que no suman",
                    "pasos": [
                        "Ambos tienen @ y la persona tiene domicilio vigente → entran.",
                        "Las variables que no suman se calculan, pero no aportan al puntaje.",
                        "Quedan con el mismo puntaje 281.7705 → el orden no cambia por ellas.",
                    ],
                    "tabla": {
                        "headers": ["Variante", "¿Esas variables suman?", "Puntaje"],
                        "rows": [
                            ["Correo base", "No (no suman)", "281.7705"],
                            ["Solo variables de seguimiento", "No suman", "281.7705 (igual)"],
                        ],
                    },
                },
            },
            {
                "fase": "3",
                "nombre": "Guardar el orden para intentar en campo",
                "pregunta": "¿Qué queda escrito como 1º y 2º intento en calle?",
                "reglas": [
                    {
                        "titulo": "Solo las direcciones escriben ese orden de calle",
                        "texto": (
                            "El lugar 1 y 2 de las direcciones se guarda como orden de intento "
                            "(1º, 2º en campo). Los rankings de fijo, celular y correo son aparte: "
                            "no escriben ese orden de calle."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo al lado — persona 20001",
                    "caso": "Mismos 91001 / 91002 de la fase 2a",
                    "pasos": [
                        "En direcciones ya quedó casa 1º y oficina 2º.",
                        "Se guarda: 91001 → intento 1; 91002 → intento 2.",
                        "Eso es lo que sale a operación en calle.",
                    ],
                    "tabla": {
                        "headers": ["Dirección", "Lugar al ordenar direcciones", "Orden guardado en calle"],
                        "rows": [
                            ["Casa 91001", "1", "1"],
                            ["Oficina 91002", "2", "2"],
                        ],
                    },
                },
            },
            {
                "fase": "4",
                "nombre": "Limpiar y validar la corrida",
                "pregunta": "¿Quedó bien y sin basura temporal?",
                "reglas": [
                    {
                        "titulo": "Se borran temporales; el orden guardado se queda",
                        "texto": (
                            "Al cerrar se limpian tablas temporales de la corrida. "
                            "El orden de intento en calle (1º, 2º) ya guardado se conserva."
                        ),
                    },
                    {
                        "titulo": "Chequeo de aceptación",
                        "texto": (
                            "Ninguna dirección hija (domicilio absorbido) debe haber quedado mal ordenada. "
                            "Los volúmenes de puntaje de direcciones, fijos y correos deben tener sentido en la corrida real."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo al lado — cierre",
                    "caso": "Después de correr todo el pipeline",
                    "pasos": [
                        "No deben quedar tablas temporales de la corrida.",
                        "Ningún domicilio absorbido debe haber quedado mal ordenado.",
                        "La siguiente corrida parte limpia; el orden casa/oficina de 20001 sigue.",
                    ],
                    "tabla": {
                        "headers": ["Chequeo", "Esperado"],
                        "rows": [
                            ["Tablas temporales de la corrida", "No quedan"],
                            ["Domicilios absorbidos mal ordenados", "0"],
                            ["Orden casa/oficina 20001", "Se conserva 1 / 2"],
                        ],
                    },
                },
            },
        ],
    },
    {
        "titulo": "Siguiente",
        "lead": "Demo = mismos casos paso a paso. SPs = detalle técnico de archivos.",
        "bullets": [
            "Workshop = reglas por fase con el ejemplo al lado (este tab).",
            "Demo = recorrido guiado.",
            "SPs = catálogo técnico aparte.",
        ],
    },
]

# Reuse renderer from prior patch (fases_lado_a_lado only; no glosario needed but keep harmless)
RENDER_PRES = r"""function renderPresentacion() {
  const items = DATA.presentacion || [];
  const el = document.getElementById('presentacionWrap');
  if (!el) return;
  const tbl = (tabla) => {
    if (!tabla || !tabla.headers) return '';
    const head = tabla.headers.map(h => `<th>${esc(h)}</th>`).join('');
    const body = (tabla.rows || []).map(r =>
      `<tr>${r.map(c => `<td>${esc(String(c ?? ''))}</td>`).join('')}</tr>`
    ).join('');
    return `<div class="demo-tabla-wrap"><table class="demo-tabla"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
  };
  const fasesLado = (b) => {
    const bloques = (b.fases || []).map(f => {
      const reglas = (f.reglas || []).map(r => `
        <div class="demo-regla-item">
          <strong>${esc(r.titulo || '')}</strong>
          <p>${esc(r.texto || '')}</p>
        </div>`).join('');
      const ej = f.ejemplo || {};
      const pasos = (ej.pasos || []).map((p, i) =>
        `<li><span class="hist-n">${i + 1}</span> ${esc(p)}</li>`
      ).join('');
      return `
      <section class="demo-fase-duo">
        <header class="demo-fase-duo-h">
          <span class="demo-fase-pill">Fase ${esc(String(f.fase))}</span>
          <div>
            <h5>${esc(f.nombre || '')}</h5>
            <p class="demo-fase-q">${esc(f.pregunta || '')}</p>
          </div>
        </header>
        <div class="demo-fase-duo-grid">
          <div class="demo-fase-col demo-fase-col-regla">
            <div class="demo-col-label">Reglas (qué acordamos)</div>
            ${reglas}
          </div>
          <div class="demo-fase-col demo-fase-col-ej">
            <div class="demo-col-label">${esc(ej.titulo || 'Ejemplo')}</div>
            ${ej.caso ? `<p class="demo-ej-caso"><b>Caso:</b> ${esc(ej.caso)}</p>` : ''}
            <ol class="demo-historia">${pasos}</ol>
            ${tbl(ej.tabla)}
          </div>
        </div>
      </section>`;
    }).join('');
    return `${b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : ''}${bloques}`;
  };
  el.innerHTML = items.map(b => {
    const lead = b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : '';
    const bullets = (b.bullets && b.bullets.length)
      ? `<ul class="demo-chips">${b.bullets.map(x => `<li>${esc(x)}</li>`).join('')}</ul>`
      : '';
    let body = `${lead}${bullets}`;
    if (b.layout === 'fases_lado_a_lado') body = fasesLado(b);
    return `<section class="demo-section">
      <h4>${esc(b.titulo)}</h4>
      ${body}
    </section>`;
  }).join('');
}"""


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def esc_js(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#x27;")
    )


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    data["presentacion"] = PRESENTACION
    html = html[:start] + to_html_json(data) + html[end:]

    pat = re.compile(r"function renderPresentacion\(\) \{\n.*?\n\}", re.S)
    ms = list(pat.finditer(html))
    if not ms:
        raise SystemExit("renderPresentacion not found")
    m = ms[-1]
    html = html[: m.start()] + esc_js(RENDER_PRES) + html[m.end() :]
    print("  renderPresentacion ok")

    path.write_text(html, encoding="utf-8")
    print("OK", path.name, "blocks", len(PRESENTACION), "fases", len(PRESENTACION[1]["fases"]))


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
