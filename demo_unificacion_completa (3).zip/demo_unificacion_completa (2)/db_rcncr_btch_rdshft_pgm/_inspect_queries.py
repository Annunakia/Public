# -*- coding: utf-8 -*-
import json, re, sys
from html import unescape
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
p = Path(
    r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
    r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
)
t = unescape(p.read_text(encoding="utf-8"))


def extract_obj(s, start):
    depth = 0
    in_q = False
    esc = False
    j = start
    while j < len(s):
        ch = s[j]
        if in_q:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_q = False
        else:
            if ch == '"':
                in_q = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return json.loads(s[start : j + 1])
        j += 1


d = extract_obj(t, list(re.finditer(r"const DATA = (\{)", t))[1].start(1))
qk = "Query validación (copiar en dba_rncr_batch)"
print("=== row queries ===")
for r in d.get("rows") or []:
    q = r.get(qk) or r.get("query") or ""
    print("\n##", r.get("_pack_code"), r.get("_titulo_corto"))
    print(q[:500] if q else "(no query)")

print("\n=== SP queries sample ===")
for s in d.get("sps_detalle") or []:
    if s.get("id") in ("SP-05", "SP-06", "SP-07", "SP-08", "SP-M01"):
        print("\n##", s["id"])
        print((s.get("query") or "")[:400])
