# -*- coding: utf-8 -*-
"""
Workshop:
- Fase 0 = tabla de insumos PRIMERO (explicada + ejemplos)
- Una sola vista de fases (sin arquitectura / SPs)
- TODAS las reglas (criterios de aceptación) cada una con ejemplo
- Sin «Opción A»; sin nombres de SP
"""
from __future__ import annotations

import json
import re
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

PRESENTACION = [
    {
        "titulo": "Qué es el ordenamiento",
        "lead": (
            "Después de unificar, una persona puede tener varias casas, oficinas, fijos, "
            "celulares o correos. El ordenamiento responde: ¿cuál intento primero? "
            "No vuelve a unificar: parte de lo ya unificado."
        ),
        "bullets": [
            "Abajo: Fase 0 (tabla de insumos) — quién entra.",
            "Luego: una sola línea de fases.",
            "Después: todas las reglas (criterios de aceptación), cada una con su ejemplo.",
            "Al final: valores de la corrida.",
        ],
    },
    {
        "titulo": "Fase 0 · Tabla de insumos (quién entra)",
        "lead": (
            "Antes de puntuar, armamos las bandejas del día: qué domicilios, fijos, celulares "
            "y correos SÍ pasan a ordenar. Eso es la tabla de insumos. "
            "Si no está en el insumo, no compite."
        ),
        "layout": "fases_lado_a_lado",
        "fases": [
            {
                "fase": "0",
                "nombre": "Qué es el insumo",
                "pregunta": "¿Qué lista se arma antes de ordenar?",
                "reglas": [
                    {
                        "titulo": "En simple",
                        "texto": (
                            "El insumo es la lista de contactos elegibles por tipo: "
                            "direcciones por un lado, fijos por otro, celulares por otro, correos por otro. "
                            "Se arma leyendo el resultado de unificación y el origen de contactos, "
                            "sin volver a unificar."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo de lectura",
                    "caso": "Cuatro bandejas",
                    "pasos": [
                        "Bandeja direcciones: solo domicilios vigentes (los que sí usamos).",
                        "Bandeja fijos: solo si la persona ya tiene un domicilio vigente.",
                        "Bandeja celulares: igual, pide domicilio vigente.",
                        "Bandeja correos: con @ y con domicilio vigente.",
                    ],
                    "tabla": {
                        "headers": ["Bandeja", "Qué lleva", "Qué no lleva"],
                        "rows": [
                            ["Direcciones", "Domicilios vigentes", "Domicilios absorbidos (hijas)"],
                            ["Fijos", "Fijos de personas con domicilio vigente", "Fijos sin domicilio vigente"],
                            ["Celulares", "Celulares con domicilio vigente", "Celulares sin domicilio vigente"],
                            ["Correos", "Correos con @ y domicilio vigente", "Sin @ o sin domicilio vigente"],
                        ],
                    },
                },
            },
            {
                "fase": "0",
                "nombre": "Regla de insumo — solo domicilio vigente",
                "pregunta": "¿Entra un domicilio absorbido?",
                "reglas": [
                    {
                        "titulo": "Criterio de aceptación",
                        "texto": (
                            "Entra la dirección ganadora, es decir el domicilio vigente "
                            "(el que sí contactamos). No entra la hija, es decir el domicilio ya absorbido."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo · persona 20011",
                    "caso": "Padre 91018 / hija 91019",
                    "pasos": [
                        "Padre vigente → sí va al insumo de direcciones.",
                        "Hija absorbida → no va al insumo; no habrá puntaje ni orden.",
                    ],
                    "tabla": {
                        "headers": ["Domicilio", "¿En insumo?", "Resultado"],
                        "rows": [
                            ["Padre 91018", "Sí", "Luego puntúa y ordena"],
                            ["Hija 91019", "No", "Sin puntaje / sin orden"],
                        ],
                    },
                },
            },
            {
                "fase": "0",
                "nombre": "Regla de insumo — correo sin @ no entra",
                "pregunta": "¿Pasa un mail inválido?",
                "reglas": [
                    {
                        "titulo": "Criterio de aceptación",
                        "texto": (
                            "Si el correo no tiene arroba, no es usable: no entra a la bandeja de correos."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo",
                    "caso": "Dos correos",
                    "pasos": [
                        "user@empresa.co → sí puede entrar (si hay domicilio vigente).",
                        "mail_sin_arroba.com → no entra al insumo.",
                    ],
                    "tabla": {
                        "headers": ["Correo", "¿En insumo?"],
                        "rows": [
                            ["user@empresa.co", "Sí (con domicilio vigente)"],
                            ["mail_sin_arroba.com", "No"],
                        ],
                    },
                },
            },
            {
                "fase": "0",
                "nombre": "Regla de insumo — teléfono/correo piden domicilio vigente",
                "pregunta": "¿Ordeno un celular sin casa vigente?",
                "reglas": [
                    {
                        "titulo": "Criterio de aceptación",
                        "texto": (
                            "Fijo, celular o correo solo entran al insumo si la persona "
                            "ya tiene al menos un domicilio vigente (uno que sí usamos). "
                            "Sin ese domicilio, no se puntúan ni se intentan."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo",
                    "caso": "Con y sin domicilio vigente",
                    "pasos": [
                        "Persona con casa vigente + celular → celular sí entra al insumo.",
                        "Persona solo con domicilio absorbido + celular → celular no entra.",
                    ],
                    "tabla": {
                        "headers": ["Situación", "¿Celular en insumo?"],
                        "rows": [
                            ["Hay domicilio vigente", "Sí"],
                            ["Solo domicilio absorbido", "No"],
                        ],
                    },
                },
            },
            {
                "fase": "0",
                "nombre": "Regla de insumo — cada tipo a su bandeja",
                "pregunta": "¿Un fijo compite con un email?",
                "reglas": [
                    {
                        "titulo": "Criterio de aceptación",
                        "texto": (
                            "Casa/oficina van a direcciones. Fijos a fijos. Celulares a celulares. "
                            "Correos a correos. No se mezclan en el insumo ni después."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo · persona 20001",
                    "caso": "Casa y oficina",
                    "pasos": [
                        "Casa y oficina → ambas a bandeja de direcciones.",
                        "Un fijo de esa persona (si hubiera) iría a bandeja de fijos, no contra la casa.",
                    ],
                    "tabla": {
                        "headers": ["Contacto", "Bandeja de insumo"],
                        "rows": [
                            ["Casa", "Direcciones"],
                            ["Oficina", "Direcciones"],
                            ["Fijo (si hubiera)", "Fijos"],
                        ],
                    },
                },
            },
        ],
    },
    {
        "titulo": "Las fases (una sola vista)",
        "lead": "Después del insumo (fase 0), el recorrido es este. Sin detalle técnico de archivos.",
        "layout": "fase_arquitectura",
        "fases": [
            {
                "fase": "0",
                "nombre": "Insumos",
                "pregunta": "¿Quién entra a ordenar?",
                "hecho": "Se arman las bandejas: vigentes sí, absorbidos no, @ obligatorio en correo, teléfono/correo piden domicilio vigente.",
                "arco": "Salida: listas por tipo listas para puntuar.",
            },
            {
                "fase": "2a",
                "nombre": "Ordenar direcciones",
                "pregunta": "¿Casa o oficina primero?",
                "hecho": "Mayor puntaje → lugar 1, 2… Solo domicilios del insumo.",
                "arco": "Ejemplos: 20001 casa/oficina · 20011 hija fuera · 20010 empate.",
            },
            {
                "fase": "2b",
                "nombre": "Ordenar fijos",
                "pregunta": "¿Cuál fijo primero?",
                "hecho": "Solo fijos del insumo; el válido prioriza; la geo no mueve el puntaje.",
                "arco": "Ejemplo aceptación: válido vs no válido.",
            },
            {
                "fase": "2c",
                "nombre": "Ordenar celulares",
                "pregunta": "¿Operador del prefijo?",
                "hecho": "Prefijo en catálogo → ese peso; si no está → valor por defecto 0.22.",
                "arco": "Ejemplo: prefijo 999 → default.",
            },
            {
                "fase": "2d",
                "nombre": "Ordenar correos",
                "pregunta": "¿Qué mueve el orden del mail?",
                "hecho": "Solo correos del insumo; algunas variables se calculan pero no suman al puntaje.",
                "arco": "Ejemplo: mismo puntaje si solo cambian variables que no suman.",
            },
            {
                "fase": "3",
                "nombre": "Guardar orden en calle",
                "pregunta": "¿Qué queda para campo?",
                "hecho": "Solo direcciones escriben 1º, 2º… de intento.",
                "arco": "Ejemplo 20001: casa→1, oficina→2.",
            },
            {
                "fase": "4",
                "nombre": "Limpiar y validar",
                "pregunta": "¿Corrida sana?",
                "hecho": "Se limpian temporales; el orden se conserva; absorbidos mal ordenados = 0.",
                "arco": "Gate de aceptación de la corrida real.",
            },
        ],
    },
    {
        "titulo": "Todas las reglas (cada una con ejemplo)",
        "lead": (
            "Criterios de aceptación del ordenamiento. "
            "Izquierda = regla. Derecha = ejemplo que la demuestra."
        ),
        "layout": "fases_lado_a_lado",
        "fases": [
            # ---- 2a DIR ----
            {
                "fase": "2a",
                "nombre": "Regla — mayor puntaje de dirección gana",
                "pregunta": "¿Casa o oficina primero?",
                "reglas": [
                    {
                        "titulo": "Criterio de aceptación",
                        "texto": (
                            "Entre domicilios vigentes del insumo, gana el mayor puntaje "
                            "(datos que aportan × pesos del catálogo). Lugar 1 = primer intento."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo · 20001",
                    "caso": "Casa 91001 vs oficina 91002",
                    "pasos": [
                        "Casa puntaje 850 → 1º.",
                        "Oficina puntaje 700 → 2º.",
                    ],
                    "tabla": {
                        "headers": ["Dirección", "Puntaje", "Orden"],
                        "rows": [
                            ["Casa", "850", "1º"],
                            ["Oficina", "700", "2º"],
                        ],
                    },
                },
            },
            {
                "fase": "2a",
                "nombre": "Regla — domicilio absorbido no ordena",
                "pregunta": "¿La hija recibe orden?",
                "reglas": [
                    {
                        "titulo": "Criterio de aceptación",
                        "texto": (
                            "El domicilio absorbido (hija) no está en el insumo: "
                            "no recibe puntaje ni orden de intento."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo · 20011",
                    "caso": "Padre / hija",
                    "pasos": [
                        "Padre 91018 → puntaje y orden 1.",
                        "Hija 91019 → sin puntaje / sin orden.",
                    ],
                    "tabla": {
                        "headers": ["Rol", "Puntaje", "Orden"],
                        "rows": [
                            ["Padre", "639.7849", "1"],
                            ["Hija", "—", "—"],
                        ],
                    },
                },
            },
            {
                "fase": "2a",
                "nombre": "Regla — empate de puntaje sin regla nueva",
                "pregunta": "¿Qué pasa si empatan?",
                "reglas": [
                    {
                        "titulo": "Criterio de aceptación",
                        "texto": (
                            "Si dos domicilios vigentes empatan en puntaje, "
                            "no inventamos desempate de negocio: quedan 1º y 2º por orden técnico."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo · 20010",
                    "caso": "91016 y 91017",
                    "pasos": [
                        "Ambos puntaje 777.",
                        "Lugares 1 y 2.",
                    ],
                    "tabla": {
                        "headers": ["RPU", "Puntaje", "Lugar"],
                        "rows": [
                            ["91016", "777", "1"],
                            ["91017", "777", "2"],
                        ],
                    },
                },
            },
            # ---- 2b TEL ----
            {
                "fase": "2b",
                "nombre": "Regla — fijo válido prioriza",
                "pregunta": "¿Cuál fijo primero?",
                "reglas": [
                    {
                        "titulo": "Criterio de aceptación",
                        "texto": (
                            "En la bandeja de fijos (solo los del insumo), "
                            "el fijo válido (usable) queda de primeras frente al no válido."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo · 20004",
                    "caso": "Válido vs no válido",
                    "pasos": [
                        "Válido puntaje 420 → 1º.",
                        "No válido 210 → 2º.",
                    ],
                    "tabla": {
                        "headers": ["Fijo", "Puntaje", "Orden"],
                        "rows": [
                            ["Válido", "420", "1º"],
                            ["No válido", "210", "2º"],
                        ],
                    },
                },
            },
            {
                "fase": "2b",
                "nombre": "Regla — geo no mueve el puntaje del fijo",
                "pregunta": "¿La cercanía cambia quién gana?",
                "reglas": [
                    {
                        "titulo": "Criterio de aceptación",
                        "texto": (
                            "El dato de geo/cercanía se puede calcular para seguimiento, "
                            "pero no suma al puntaje. Dos fijos pueden quedar iguales aunque la geo sea distinta."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo · 20013",
                    "caso": "Misma base, geo distinta",
                    "pasos": [
                        "Ambos quedan 376.5.",
                        "La geo no cambió el orden por puntaje.",
                    ],
                    "tabla": {
                        "headers": ["Fijo", "Puntaje"],
                        "rows": [
                            ["Base", "376.5"],
                            ["Solo geo distinta", "376.5"],
                        ],
                    },
                },
            },
            # ---- 2c CEL ----
            {
                "fase": "2c",
                "nombre": "Regla — prefijo del celular → peso del catálogo",
                "pregunta": "¿Cómo sé el operador?",
                "reglas": [
                    {
                        "titulo": "Criterio de aceptación",
                        "texto": (
                            "Se toman los 3 primeros dígitos (prefijo) y se buscan en el catálogo. "
                            "Si está, se usa ese peso. Los pesos no se inventan en la corrida."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo",
                    "caso": "Prefijo 310",
                    "pasos": [
                        "310 está en la tabla → se usa el peso de ese operador.",
                        "Ese peso aporta al puntaje del celular.",
                    ],
                    "tabla": {
                        "headers": ["Prefijo", "¿En catálogo?", "Acción"],
                        "rows": [
                            ["310", "Sí", "Usar peso del operador"],
                        ],
                    },
                },
            },
            {
                "fase": "2c",
                "nombre": "Regla — prefijo desconocido → valor por defecto",
                "pregunta": "¿Y si el prefijo no está?",
                "reglas": [
                    {
                        "titulo": "Criterio de aceptación",
                        "texto": (
                            "Si el prefijo no está en el catálogo, se aplica el valor por defecto 0.22. "
                            "No se adivina Claro/Movistar; el celular no queda en cero."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo · 20012",
                    "caso": "Prefijo 999",
                    "pasos": [
                        "999 no está en la tabla.",
                        "Default 0.22 → puntaje de ejemplo 220 → 1º.",
                    ],
                    "tabla": {
                        "headers": ["Prefijo", "Acción", "Puntaje ej."],
                        "rows": [
                            ["999", "Default 0.22", "220"],
                        ],
                    },
                },
            },
            # ---- 2d EMA ----
            {
                "fase": "2d",
                "nombre": "Regla — variables de email que no suman",
                "pregunta": "¿Cualquier dato del mail mueve el orden?",
                "reglas": [
                    {
                        "titulo": "Criterio de aceptación",
                        "texto": (
                            "Algunas variables del correo se calculan para seguimiento "
                            "pero no suman al puntaje. Si solo ellas cambian, el orden del mail no se mueve."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo · 20014",
                    "caso": "Base vs solo variables que no suman",
                    "pasos": [
                        "Ambos puntaje 281.7705.",
                        "El orden no cambió por esas variables.",
                    ],
                    "tabla": {
                        "headers": ["Variante", "Puntaje"],
                        "rows": [
                            ["Correo base", "281.7705"],
                            ["Solo vars. de seguimiento", "281.7705"],
                        ],
                    },
                },
            },
            # ---- 3 ----
            {
                "fase": "3",
                "nombre": "Regla — solo direcciones escriben el orden de calle",
                "pregunta": "¿Qué se guarda para campo?",
                "reglas": [
                    {
                        "titulo": "Criterio de aceptación",
                        "texto": (
                            "El lugar 1/2 de direcciones se guarda como orden de intento (1º, 2º…). "
                            "Fijos, celulares y correos no escriben ese orden de calle."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo · 20001",
                    "caso": "Tras ordenar direcciones",
                    "pasos": [
                        "Casa lugar 1 → orden de calle 1.",
                        "Oficina lugar 2 → orden de calle 2.",
                    ],
                    "tabla": {
                        "headers": ["Dirección", "Lugar", "Orden guardado"],
                        "rows": [
                            ["Casa 91001", "1", "1"],
                            ["Oficina 91002", "2", "2"],
                        ],
                    },
                },
            },
            # ---- 4 ----
            {
                "fase": "4",
                "nombre": "Regla — limpiar temporales y gate",
                "pregunta": "¿Corrida aceptada?",
                "reglas": [
                    {
                        "titulo": "Criterio de aceptación",
                        "texto": (
                            "Al cerrar se borran temporales de la corrida; el orden guardado se conserva. "
                            "Ningún domicilio absorbido debe quedar mal ordenado (debe ser 0)."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo de cierre",
                    "caso": "Después de la corrida",
                    "pasos": [
                        "Temporales de la corrida: no quedan.",
                        "Absorbidos mal ordenados: 0.",
                        "Orden 20001 casa/oficina: se conserva 1 / 2.",
                    ],
                    "tabla": {
                        "headers": ["Chequeo", "Esperado"],
                        "rows": [
                            ["Temporales", "No quedan"],
                            ["Absorbidos mal ordenados", "0"],
                            ["Orden 20001", "1 y 2 se conservan"],
                        ],
                    },
                },
            },
        ],
    },
    {
        "titulo": "Valores que tenemos (corrida real)",
        "lead": "Magnitudes para cerrar la mesa.",
        "layout": "valores",
        "valores": [
            {"label": "Personas", "valor": "407.351", "nota": "Universo"},
            {"label": "Domicilios vigentes", "valor": "518.718", "nota": "Los que sí usamos"},
            {"label": "Domicilios absorbidos", "valor": "72.448", "nota": "Fuera del insumo"},
            {"label": "Con orden de calle", "valor": "410.100", "nota": "1º, 2º… guardados"},
            {"label": "Pesos del catálogo", "valor": "47", "nota": "Acordados"},
            {"label": "Puntajes calculados", "valor": "1.227.894", "nota": "Corrida DEV"},
            {"label": "Absorbidos mal ordenados", "valor": "0", "nota": "Gate"},
        ],
    },
]

# Reuse renderer from prior patches
RENDER_PRES = r"""function renderPresentacion() {
  const items = DATA.presentacion || [];
  const el = document.getElementById('presentacionWrap');
  if (!el) return;
  const tbl = (tabla) => {
    if (!tabla || !tabla.headers) return '';
    const head = tabla.headers.map(h => `<th>${esc(h)}</th>`).join('');
    const body = (tabla.rows || []).map(r =>
      `<tr>${r.map(c => `<td>${esc(String(c ?? ''))}</td>`).join('')}</tr>`
    ).join('');
    return `<div class="demo-tabla-wrap"><table class="demo-tabla"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
  };
  const mapaArq = (fases) => {
    if (!fases || !fases.length) return '';
    return `<div class="demo-fase-mapa demo-fase-arq">${fases.map((f, i) => `
      <article class="demo-fase-card">
        <div class="demo-fase-num">Fase ${esc(String(f.fase))}</div>
        <h5>${esc(f.nombre || '')}</h5>
        <p class="demo-fase-q">${esc(f.pregunta || '')}</p>
        <p class="demo-fase-h"><b>Negocio:</b> ${esc(f.hecho || '')}</p>
        <p class="demo-fase-h"><b>Ejemplo / salida:</b> ${esc(f.arco || '')}</p>
      </article>${i < fases.length - 1 ? '<div class="demo-fase-arrow" aria-hidden="true">→</div>' : ''}`).join('')}</div>`;
  };
  const fasesLado = (b) => {
    const bloques = (b.fases || []).map(f => {
      const reglas = (f.reglas || []).map(r => `
        <div class="demo-regla-item">
          <strong>${esc(r.titulo || '')}</strong>
          <p>${esc(r.texto || '')}</p>
        </div>`).join('');
      const ej = f.ejemplo || {};
      const pasos = (ej.pasos || []).map((p, i) =>
        `<li><span class="hist-n">${i + 1}</span> ${esc(p)}</li>`
      ).join('');
      return `
      <section class="demo-fase-duo">
        <header class="demo-fase-duo-h">
          <span class="demo-fase-pill">Fase ${esc(String(f.fase))}</span>
          <div>
            <h5>${esc(f.nombre || '')}</h5>
            <p class="demo-fase-q">${esc(f.pregunta || '')}</p>
          </div>
        </header>
        <div class="demo-fase-duo-grid">
          <div class="demo-fase-col demo-fase-col-regla">
            <div class="demo-col-label">Regla</div>
            ${reglas}
          </div>
          <div class="demo-fase-col demo-fase-col-ej">
            <div class="demo-col-label">${esc(ej.titulo || 'Ejemplo')}</div>
            ${ej.caso ? `<p class="demo-ej-caso"><b>Caso:</b> ${esc(ej.caso)}</p>` : ''}
            <ol class="demo-historia">${pasos}</ol>
            ${tbl(ej.tabla)}
          </div>
        </div>
      </section>`;
    }).join('');
    return `${b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : ''}${bloques}`;
  };
  const valores = (b) => {
    const cards = (b.valores || []).map(v => `
      <article class="demo-valor-card">
        <small>${esc(v.label || '')}</small>
        <b>${esc(v.valor || '')}</b>
        <span>${esc(v.nota || '')}</span>
      </article>`).join('');
    return `${b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : ''}
      <div class="demo-valores-grid">${cards}</div>`;
  };
  el.innerHTML = items.map(b => {
    const lead = b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : '';
    const bullets = (b.bullets && b.bullets.length)
      ? `<ul class="demo-chips">${b.bullets.map(x => `<li>${esc(x)}</li>`).join('')}</ul>`
      : '';
    let body = `${lead}${bullets}`;
    if (b.layout === 'fase_arquitectura' || b.layout === 'fase_mapa') body = `${lead}${mapaArq(b.fases)}`;
    else if (b.layout === 'fases_lado_a_lado') body = fasesLado(b);
    else if (b.layout === 'valores') body = valores(b);
    return `<section class="demo-section">
      <h4>${esc(b.titulo)}</h4>
      ${body}
    </section>`;
  }).join('');
}"""

CSS_HIDE = """
/* Workshop: solo presentación (sin arquitectura SP / alcance / banner) */
#frame-home .doc-banner,
#frame-home #docBanner,
#frame-home .frame-fit > .drill-section:not(.demo-hero),
#frame-home #scopeGrid,
#frame-home #fasesTable,
#frame-home #archFlow,
#frame-home .scope-grid,
#frame-home .arch-flow,
#frame-home .fases-table,
#frame-home .kpi-row,
#frame-home .rules-map,
#frame-home #rulesMap,
#frame-home .glossary,
#frame-home #glossary {
  display: none !important;
  height: 0 !important;
  max-height: 0 !important;
  overflow: hidden !important;
  margin: 0 !important;
  padding: 0 !important;
  border: none !important;
  visibility: hidden !important;
}
#frame-home .demo-hero { display: block !important; visibility: visible !important; }
#frame-home .presentacion-wrap { display: block !important; max-width: 1100px; }
"""

CSS_EXTRA = """
.demo-fase-duo {
  margin: 1rem 0 1.25rem; border: 1px solid #e2e8f0; border-radius: 14px;
  background: #fff; overflow: hidden;
}
.demo-fase-duo-h {
  display: flex; gap: 0.75rem; align-items: flex-start;
  padding: 0.75rem 0.9rem; background: #f1f5f9; border-bottom: 1px solid #e2e8f0;
}
.demo-fase-duo-h h5 { margin: 0 0 0.2rem; font-size: 0.95rem; color: #0f172a; }
.demo-fase-pill {
  flex: 0 0 auto; background: #1d6fdc; color: #fff; font-size: 0.72rem; font-weight: 800;
  border-radius: 999px; padding: 0.28rem 0.6rem; white-space: nowrap;
}
.demo-fase-duo-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0; }
@media (max-width: 820px) { .demo-fase-duo-grid { grid-template-columns: 1fr; } }
.demo-fase-col { padding: 0.75rem 0.9rem; }
.demo-fase-col-regla { border-right: 1px solid #e2e8f0; background: #fafbfc; }
@media (max-width: 820px) {
  .demo-fase-col-regla { border-right: none; border-bottom: 1px solid #e2e8f0; }
}
.demo-col-label {
  font-size: 0.7rem; font-weight: 800; letter-spacing: 0.04em; text-transform: uppercase;
  color: #64748b; margin-bottom: 0.55rem;
}
.demo-regla-item {
  margin: 0 0 0.55rem; padding: 0.5rem 0.6rem;
  background: #fff; border: 1px solid #e2e8f0; border-radius: 10px;
}
.demo-regla-item strong { display: block; font-size: 0.82rem; color: #0f172a; margin-bottom: 0.2rem; }
.demo-regla-item p { margin: 0; font-size: 0.78rem; line-height: 1.4; color: #334155; }
.demo-ej-caso { margin: 0 0 0.5rem; font-size: 0.8rem; color: #0f172a; }
.demo-historia {
  margin: 0.25rem 0 0.65rem; padding: 0; list-style: none;
  display: flex; flex-direction: column; gap: 0.4rem;
}
.demo-historia li {
  display: flex; gap: 0.5rem; align-items: flex-start;
  background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px;
  padding: 0.45rem 0.6rem; font-size: 0.78rem; line-height: 1.4; color: #0f172a;
}
.demo-historia .hist-n {
  flex: 0 0 1.25rem; height: 1.25rem; border-radius: 50%;
  background: #1d6fdc; color: #fff; font-size: 0.68rem; font-weight: 800;
  display: inline-flex; align-items: center; justify-content: center;
}
.demo-valores-grid {
  display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
  gap: 0.65rem; margin-top: 0.55rem;
}
.demo-valor-card {
  background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px;
  padding: 0.7rem 0.8rem; display: flex; flex-direction: column; gap: 0.2rem;
}
.demo-valor-card small { font-size: 0.72rem; color: #64748b; font-weight: 700; }
.demo-valor-card b { font-size: 1.15rem; color: #0f172a; }
.demo-valor-card span { font-size: 0.72rem; color: #475569; line-height: 1.35; }
.demo-fase-arq { flex-wrap: wrap; }
"""


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def esc_js(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#x27;")
    )


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    data["presentacion"] = PRESENTACION
    html = html[:start] + to_html_json(data) + html[end:]

    pat = re.compile(r"function renderPresentacion\(\) \{\n.*?\n\}", re.S)
    ms = list(pat.finditer(html))
    if not ms:
        raise SystemExit("renderPresentacion not found")
    m = ms[-1]
    html = html[: m.start()] + esc_js(RENDER_PRES) + html[m.end() :]
    print("  renderPresentacion ok")

    # Clear doc banner (was injecting SPs / Opción A)
    mapa = html.find("Mapa Ordenamiento")
    banner = re.search(r"function renderDocBanner\(\) \{\n.*?\n\}", html[mapa:], re.S)
    if banner:
        a, b = mapa + banner.start(), mapa + banner.end()
        html = (
            html[:a]
            + esc_js(
                "function renderDocBanner() {\n"
                "  const el = document.getElementById('docBanner');\n"
                "  if (el) { el.innerHTML = ''; el.style.display = 'none'; }\n"
                "}"
            )
            + html[b:]
        )
        print("  renderDocBanner cleared")

    # Also noop renderScope / renderFases / renderArch if they fill hidden sections
    for fn in ("renderScope", "renderFases", "renderArch"):
        mfn = re.search(rf"function {fn}\(\) \{{\n.*?\n\}}", html[mapa:], re.S)
        if mfn:
            # leave functions but don't care - CSS hides
            pass

    reps = [
        (
            "Ordenamiento post-unificación: ¿cuál intento primero? Opción A = solo domicilios vigentes + pesos del catálogo acordado",
            "Fase 0 insumos primero · luego fases · cada regla con ejemplo · valores al final",
        ),
        (
            "Después de unificar: ¿cuál intento primero? Solo domicilios vigentes, con el catálogo acordado.",
            "Fase 0 insumos primero · luego fases · cada regla con ejemplo · valores al final",
        ),
        (
            "Historias de negocio: quién entra, cuál primero, Claro vs Movistar, orden en calle.",
            "Insumos (fase 0) → fases → todas las reglas con ejemplo → valores.",
        ),
        (
            "Qué es el ordenamiento (con ejemplos) → fases → personas 20001 / 20011 / 20010 → valores.",
            "Insumos (fase 0) → fases → todas las reglas con ejemplo → valores.",
        ),
        (
            "3 · Arquitectura datasharing (sin copia XPM — modelo de contactos/ubicaciones de origen Experian)",
            "3 · (oculto en Workshop — ver presentación)",
        ),
    ]
    for a, b in reps:
        if a in html:
            html = html.replace(a, b, 1)
            print("  text ok")

    oi = html.find("Mapa Ordenamiento")
    se = html.find("&lt;/style&gt;", oi)
    markers = [
        "/* Workshop: solo presentación",
        "/* Workshop: fases + ejemplo",
        "/* Workshop: glosario",
        "/* Workshop reglas",
    ]
    if se > 0:
        for marker in markers:
            if marker in html[oi:se]:
                prev = html.rfind(marker, oi, se)
                html = html[:prev] + html[se:]
                se = html.find("&lt;/style&gt;", oi)
        html = html[:se] + CSS_HIDE + CSS_EXTRA + html[se:]
        print("  CSS ok")

    path.write_text(html, encoding="utf-8")
    n_reglas = sum(len(b.get("fases") or []) for b in PRESENTACION if b.get("layout") == "fases_lado_a_lado")
    print("OK", path.name, "bloques regla+ej", n_reglas)


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
