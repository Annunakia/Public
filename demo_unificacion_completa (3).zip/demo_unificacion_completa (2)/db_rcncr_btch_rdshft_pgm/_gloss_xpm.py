# -*- coding: utf-8 -*-
"""Agrega significado de XPM entre parentesis en Ordenamiento."""
from __future__ import annotations

import json
import re
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

# Glosa corta y estable para mesa
GLOSS = "modelo de contactos/ubicaciones de origen Experian"

# Reemplazos solo dentro del iframe Ordenamiento (evitar tocar Unificacion salvo e2e breve)
UI_REPLACES = [
    (
        "3 · Arquitectura datasharing (sin copia XPM)",
        f"3 · Arquitectura datasharing (sin copia XPM — {GLOSS})",
    ),
    (
        "Lenguaje de mesa: solo ganadoras · tipo de contacto → canal · email sin @ no entra · betas del catálogo",
        f"Lenguaje de mesa: solo ganadoras · tipo de contacto XPM ({GLOSS}) → canal · email sin @ no entra · betas del catálogo",
    ),
    (
        "tag: &#x27;Ganadoras · XPM&#x27;",
        f"tag: &#x27;Ganadoras · XPM ({GLOSS})&#x27;",
    ),
    (
        "4 · Insumo — contactType → canal (quién entra)",
        f"4 · Insumo — contactType XPM ({GLOSS}) → canal (quién entra)",
    ),
]

# Evitar doble glosa
ALREADY = f"XPM — {GLOSS}"


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def gloss_xpm(text: str) -> str:
    if not isinstance(text, str) or "XPM" not in text:
        return text
    if GLOSS in text or "modelo de contactos" in text:
        return text
    # Primera aparición de XPM → XPM (glosa)
    return text.replace("XPM", f"XPM ({GLOSS})", 1)


def walk_gloss(obj):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, str):
                obj[k] = gloss_xpm(v)
            else:
                walk_gloss(v)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            if isinstance(v, str):
                obj[i] = gloss_xpm(v)
            else:
                walk_gloss(v)


def patch_data(data: dict) -> None:
    # presentacion, rows, fases_doc, sps
    for key in ("presentacion", "rows", "fases_doc", "sps_detalle", "alcance"):
        if key in data:
            walk_gloss(data[key])
    # encabezados de tablas que digan Tipo XPM
    for r in data.get("rows") or []:
        for tk in ("_tabla_ejemplo", "_tabla_pasos"):
            tbl = r.get(tk)
            if not isinstance(tbl, dict):
                continue
            headers = tbl.get("headers") or []
            tbl["headers"] = [
                h.replace("Tipo XPM", f"Tipo XPM ({GLOSS})")
                if isinstance(h, str) and "Tipo XPM" in h and GLOSS not in h
                else h
                for h in headers
            ]
            for row in tbl.get("rows") or []:
                for j, cell in enumerate(row):
                    if isinstance(cell, str) and "XPM" in cell and GLOSS not in cell:
                        row[j] = gloss_xpm(cell)


def patch_ord_ui(html: str) -> str:
    a = html.find("Mapa Ordenamiento")
    if a < 0:
        return html
    end = html.find('"></iframe>', a)
    chunk = html[a:end]
    n = 0
    for old, new in UI_REPLACES:
        if old in chunk and ALREADY not in chunk[chunk.find(old) : chunk.find(old) + len(old) + 80]:
            chunk = chunk.replace(old, new)
            n += 1
    # e2e shell outside iframe: brief gloss on first XPM in ordenamiento section
    html = html[:a] + chunk + html[end:]
    # Panel E2E title
    e2e_old = "<h2>2. Data Sharing (sin copiar XPM)</h2>"
    e2e_new = f"<h2>2. Data Sharing (sin copiar XPM — {GLOSS})</h2>"
    if e2e_old in html and e2e_new not in html:
        html = html.replace(e2e_old, e2e_new, 1)
        n += 1
    print(f"  UI gloss replaces: {n}")
    return html


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    patch_data(data)
    html = html[:start] + to_html_json(data) + html[end:]
    html = patch_ord_ui(html)
    path.write_text(html, encoding="utf-8")
    # verify
    a = html.find("Mapa Ordenamiento")
    chunk = html[a : html.find('"></iframe>', a)]
    print("OK", path.name, "gloss present:", GLOSS in chunk)


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
