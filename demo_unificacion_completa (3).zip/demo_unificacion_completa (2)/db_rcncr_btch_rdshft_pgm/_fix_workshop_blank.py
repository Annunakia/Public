# -*- coding: utf-8 -*-
"""Fix Workshop blank: null-safe renderHome, re-render presentacion, remove leftover matrix."""
from __future__ import annotations

import re
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]


def esc_js(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#x27;")
    )


NEW_RENDER_HOME = esc_js(
    r"""function renderHome() {
  const k = DATA.kpis || {};
  const kpiEl = document.getElementById('kpiRow');
  if (kpiEl) {
    kpiEl.innerHTML = `
    <div class="kpi"><small>Personas</small><b>${fmt(k.personas)}</b><span>universo</span></div>
    <div class="kpi"><small>Vigentes</small><b>${fmt(k.rpu_ganadoras)}</b><span>domicilios</span></div>
    <div class="kpi"><small>orden_prioridad</small><b>${fmt(k.rpu_con_orden)}</b><span>RPUs</span></div>
    <div class="kpi"><small>Absorbidos</small><b>${fmt(k.rpu_hijas)}</b><span>fuera</span></div>
  `;
  }
  try { renderDocBanner(); } catch (e) {}
  try { renderPresentacion(); } catch (e) { console.error('presentacion', e); }
  const safe = (fn) => { try { fn(); } catch (e) {} };
  safe(renderScope);
  safe(renderFases);
  safe(renderArchFlow);
  safe(renderContactTypes);
  safe(renderFormulas);
  safe(renderSpsCatalog);
  safe(renderReposDeploy);
  safe(renderArtefactos);
  safe(renderGlossary);
  safe(renderMetricToggle);
  safe(renderCascade);
  safe(renderDrillMatrix);
}"""
)

SHOW_FRAME_OLD = """function showFrame(idx) {
  currentFrame = idx;
  const f = FRAMES[idx];
  document.getElementById(&#x27;progressBar&#x27;).style.width = f.progress + &#x27;%&#x27;;
  document.querySelectorAll(&#x27;.step-btn&#x27;).forEach((b,i) =&gt; b.classList.toggle(&#x27;active&#x27;, i===idx));
  if (f.id === &#x27;demo&#x27;) {
    renderWsLanding();
    showWorkshopStep(workshopStep || 0);
    return;
  }
  document.querySelectorAll(&#x27;.frame&#x27;).forEach(fr =&gt; {
    const on = fr.id === f.el;
    fr.classList.toggle(&#x27;frame-on&#x27;, on);
    fr.classList.toggle(&#x27;frame-off&#x27;, !on);
  });
  if (f.id === &#x27;sps&#x27;) showSpDetail(spPos, false);
  requestAnimationFrame(() =&gt; requestAnimationFrame(fitRuleStage));
}"""

SHOW_FRAME_NEW = """function showFrame(idx) {
  currentFrame = idx;
  const f = FRAMES[idx];
  const bar = document.getElementById(&#x27;progressBar&#x27;);
  if (bar) bar.style.width = f.progress + &#x27;%&#x27;;
  document.querySelectorAll(&#x27;.step-btn&#x27;).forEach((b,i) =&gt; b.classList.toggle(&#x27;active&#x27;, i===idx));
  if (f.id === &#x27;demo&#x27;) {
    renderWsLanding();
    showWorkshopStep(workshopStep || 0);
    return;
  }
  document.querySelectorAll(&#x27;.frame&#x27;).forEach(fr =&gt; {
    const on = fr.id === f.el;
    fr.classList.toggle(&#x27;frame-on&#x27;, on);
    fr.classList.toggle(&#x27;frame-off&#x27;, !on);
  });
  if (f.id === &#x27;workshop&#x27;) {
    try { renderPresentacion(); } catch (e) { console.error(e); }
  }
  if (f.id === &#x27;sps&#x27;) showSpDetail(spPos, false);
  requestAnimationFrame(() =&gt; requestAnimationFrame(fitRuleStage));
}"""

CSS_FIX = """
/* Workshop visible: presentación siempre a la vista */
#frame-home.frame-on,
#frame-home.frame-on .frame-fit,
#frame-home.frame-on .demo-hero,
#frame-home.frame-on #presentacionWrap,
#frame-home.frame-on .presentacion-wrap {
  display: block !important;
  visibility: visible !important;
  opacity: 1 !important;
  height: auto !important;
  max-height: none !important;
  overflow: visible !important;
}
#frame-home .frame-fit {
  overflow-y: auto !important;
  min-height: 70vh;
}
#frame-home .presentacion-wrap,
#frame-home #presentacionWrap {
  min-height: 200px;
  padding-bottom: 2rem;
}
#frame-home .demo-section {
  display: block !important;
  visibility: visible !important;
  margin: 0.75rem 0 1.25rem;
}
#frame-home .frame-fit > .drill-section:not(.demo-hero) {
  display: none !important;
}
"""


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    mapa = html.find("Mapa Ordenamiento")
    if mapa < 0:
        raise SystemExit("Mapa not found")

    # Replace renderHome in ordenamiento block
    m = re.search(r"function renderHome\(\) \{\n.*?\n\}", html[mapa:], re.S)
    if not m:
        raise SystemExit("renderHome not found")
    a, b = mapa + m.start(), mapa + m.end()
    html = html[:a] + NEW_RENDER_HOME + html[b:]
    print("  renderHome null-safe ok")

    if SHOW_FRAME_OLD in html:
        html = html.replace(SHOW_FRAME_OLD, SHOW_FRAME_NEW, 1)
        print("  showFrame workshop re-render ok")
    else:
        # force near mapa
        m2 = re.search(r"function showFrame\(idx\) \{\n.*?\n\}", html[mapa:], re.S)
        if m2:
            a2, b2 = mapa + m2.start(), mapa + m2.end()
            html = html[:a2] + SHOW_FRAME_NEW + html[b2:]
            print("  showFrame forced ok")
        else:
            print("  WARN showFrame")

    # Strip leftover matrix section in frame-home
    fh = html.find('id=&quot;frame-home&quot;', mapa)
    fw = html.find('id=&quot;frame-workshop&quot;', fh)
    block = html[fh:fw]
    new_block = re.sub(
        r"&lt;section class=&quot;drill-section drill-section-matrix&quot;&gt;.*?&lt;/section&gt;",
        "",
        block,
        flags=re.S,
    )
    new_block = re.sub(
        r"&lt;section class=&quot;drill-section&quot;&gt;.*?&lt;/section&gt;",
        "",
        new_block,
        flags=re.S,
    )
    if new_block != block:
        html = html[:fh] + new_block + html[fw:]
        print("  leftover sections stripped")
    else:
        print("  no leftover sections")

    # Ensure presentacionWrap has a placeholder visible before JS
    if 'id=&quot;presentacionWrap&quot;&gt;&lt;/div&gt;' in html[mapa:]:
        html = html.replace(
            'id=&quot;presentacionWrap&quot;&gt;&lt;/div&gt;',
            'id=&quot;presentacionWrap&quot;&gt;'
            '&lt;p class=&quot;demo-lead&quot;&gt;Cargando Workshop…&lt;/p&gt;'
            "&lt;/div&gt;",
            1,
        )
        print("  placeholder ok")

    # Soften previous aggressive visibility:hidden on broad list - inject CSS_FIX
    se = html.find("&lt;/style&gt;", mapa)
    marker = "/* Workshop visible: presentación siempre a la vista */"
    if se > 0:
        if marker in html[mapa:se]:
            prev = html.rfind(marker, mapa, se)
            html = html[:prev] + html[se:]
            se = html.find("&lt;/style&gt;", mapa)
        html = html[:se] + CSS_FIX + html[se:]
        print("  CSS fix ok")

    # Null-safe getElementById patterns in renderScope/Fases within mapa - quick patch
    for old, new in [
        (
            "document.getElementById(&#x27;scopeGrid&#x27;).innerHTML",
            "const _sg = document.getElementById(&#x27;scopeGrid&#x27;); if (!_sg) return; _sg.innerHTML",
        ),
        (
            "document.getElementById(&#x27;fasesTable&#x27;).innerHTML",
            "const _ft = document.getElementById(&#x27;fasesTable&#x27;); if (!_ft) return; _ft.innerHTML",
        ),
        (
            "document.getElementById(&#x27;archFlow&#x27;).innerHTML",
            "const _af = document.getElementById(&#x27;archFlow&#x27;); if (!_af) return; _af.innerHTML",
        ),
        (
            "document.getElementById(&#x27;glossary&#x27;).innerHTML",
            "const _gl = document.getElementById(&#x27;glossary&#x27;); if (!_gl) return; _gl.innerHTML",
        ),
        (
            "document.getElementById(&#x27;drillMatrix&#x27;).innerHTML",
            "const _dm = document.getElementById(&#x27;drillMatrix&#x27;); if (!_dm) return; _dm.innerHTML",
        ),
    ]:
        # only replace in ordenamiento section once each
        idx = html.find(old, mapa)
        if idx > 0:
            html = html[:idx] + new + html[idx + len(old) :]
            print("  nullsafe", new.split("=")[0][-6:])

    path.write_text(html, encoding="utf-8")
    print("OK", path.name)


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
