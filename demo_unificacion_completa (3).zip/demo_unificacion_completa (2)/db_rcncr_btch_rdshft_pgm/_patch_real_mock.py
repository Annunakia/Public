# -*- coding: utf-8 -*-
"""Tag every ord scenario REAL (DEV IDs + query) or MOCK (smoke + query)."""
import json
import re
import shutil
from html import unescape
from pathlib import Path

PATHS = [
    Path(r"C:\Users\C32525E\Downloads\RECONOCER_TODO_EN_UNO_WORKSHOP.html"),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\repos\db_rcncr_btch_rdshft_dt"
        r"\docs\RECONOCER_TODO_EN_UNO.html"
    ),
]

A = {
    "id": 3228096126421495389,
    "pin": 98746,
    "padre": 2,
    "hija": 3,
    "dir": 639.7849,
    "tel": 376.5281,
    "ema": 281.7705,
}
B = {
    "id": 2848501447849812647,
    "pin": 165259,
    "rpu1": 166366,
    "s1": 611.8280,
    "rpu2": 166369,
    "s2": 599.7849,
    "hija1": 166367,
    "hija2": 166368,
}

# Smoke mock personas (seed lab — no son buro DEV)
MOCK = {
    "dir": 20001,
    "tel": 20004,
    "cel": 20006,
    "ema": 20008,
}


def extract_escaped_json(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def dump_escaped(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":")).replace('"', "&quot;")


def mark_real(row, id_buro, label, query, pin=None):
    row["_fuente"] = "REAL"
    row["_id_buro_persona"] = id_buro
    row["_id_ejemplo"] = f"id_buro_persona = {id_buro}"
    row["_ejemplo_label"] = label
    if pin is not None:
        row["_cod_pin"] = pin
    row["Query validación (copiar en dba_rncr_batch)"] = query
    row["_show_query"] = True


def mark_mock(row, smoke_id, label, query):
    row["_fuente"] = "MOCK"
    row["_id_buro_persona"] = smoke_id
    row["_id_ejemplo"] = f"MOCK smoke persona = {smoke_id}"
    row["_ejemplo_label"] = label
    row["Query validación (copiar en dba_rncr_batch)"] = query
    row["_show_query"] = True
    # clear real-looking id fields that could confuse
    row.pop("_cod_pin", None)


def q_scores(pid, canal=None):
    extra = f"\n  AND canal = '{canal}'" if canal else ""
    return (
        "SELECT canal, cod_dw_persona_ubic AS rpu, cod_pin_persona, score, lugar\n"
        "FROM bdm_datos.score_ordenamiento\n"
        f"WHERE id_buro_persona = {pid}{extra}\n"
        "ORDER BY canal, lugar;"
    )


def q_orden(pid):
    return (
        "SELECT cod_dw_persona_ubic AS rpu, id_buro_persona, orden_prioridad, fecha_actualizacion\n"
        "FROM bdm_datos.rpu_orden_prioridad\n"
        f"WHERE id_buro_persona = {pid}\n"
        "ORDER BY orden_prioridad;"
    )


def q_mock_smoke(persona):
    return (
        "-- MOCK: datos de laboratorio (smoke), no id_buro DEV\n"
        "SELECT canal, cod_dw_persona_ubic AS rpu, score, lugar\n"
        "FROM bdm_stage.score_ordenamiento_smoke  -- o tabla smoke de tu corrida lab\n"
        f"WHERE id_persona_smoke = {persona}\n"
        "ORDER BY canal, lugar;\n"
        "-- Si no tienes smoke cargado, este escenario es solo pedagógico:\n"
        f"-- persona mock {persona} (casa vs oficina / canal demo)."
    )


def patch_ord_data(data: dict) -> None:
    k = data.setdefault("kpis", {})
    k["demo_id_buro_persona"] = B["id"]
    k["pid"] = A["id"]
    k["pid_rank"] = B["id"]
    k["cod_pin"] = A["pin"]
    k["demo_verificado"] = "2026-09-23"

    for row in data.get("rows") or []:
        code = row.get("Escenario") or row.get("_esc_codigo") or ""
        titulo = row.get("_titulo_corto") or row.get("Subescenario") or ""

        if code == "ORD-DIR-RANK" or "RANK-01" in titulo:
            mark_real(
                row,
                B["id"],
                "REAL DEV · Caso B · RANK-01 (2 DIR)",
                q_scores(B["id"], "DIR"),
                B["pin"],
            )
            row["_busca"] = (
                "Varias direcciones ganadoras por persona; mayor score → lugar 1 → orden_prioridad. "
                f"Dato REAL: id_buro_persona = {B['id']} · pin {B['pin']}."
            )
            row["_dev"] = (
                f"REAL: {B['id']} → RPU {B['rpu1']} score {B['s1']} lugar 1; "
                f"RPU {B['rpu2']} score {B['s2']} lugar 2; "
                f"hijas {B['hija1']}/{B['hija2']} sin score."
            )
            row["_conclusion_regla"] = row["_dev"]
            row["_tabla_ejemplo"] = {
                "title": f"REAL · RANK-01 · id_buro_persona = {B['id']} (pin {B['pin']})",
                "headers": ["RPU", "Score DIR", "lugar", "orden_prioridad", "Fuente"],
                "rows": [
                    [str(B["rpu1"]), f"{B['s1']:.4f}", "1", "1", "REAL DEV"],
                    [str(B["rpu2"]), f"{B['s2']:.4f}", "2", "2", "REAL DEV"],
                    [str(B["hija1"]), "—", "—", "NULL", "REAL · excluida R2"],
                ],
            }

        elif code == "ORD-F3-HIJA" or "F3-02" in titulo:
            mark_real(
                row,
                A["id"],
                "REAL DEV · Caso A · hija 3 → padre 2",
                (
                    "SELECT 'scores_hija' AS chk, COUNT(*)::BIGINT AS n\n"
                    "FROM bdm_datos.score_ordenamiento WHERE cod_dw_persona_ubic = 3\n"
                    "UNION ALL\n"
                    "SELECT 'orden_hija', COUNT(*)::BIGINT\n"
                    "FROM bdm_datos.rpu_orden_prioridad WHERE cod_dw_persona_ubic = 3;\n"
                    "-- Dueño del padre:\n"
                    + q_scores(A["id"])
                ),
                A["pin"],
            )
            row["_tabla_ejemplo"] = {
                "title": f"REAL · F3-02 · id_buro_persona = {A['id']}",
                "headers": ["Campo", "Hija RPU 3", "Padre RPU 2", "Fuente"],
                "rows": [
                    ["ind_unificacion", "1", "NULL", "REAL"],
                    ["score DIR", "— (0 filas)", f"{A['dir']:.4f}", "REAL"],
                    ["orden_prioridad", "NULL / 0 filas", "1", "REAL"],
                ],
            }
            row["_dev"] = (
                f"REAL: {A['id']} pin {A['pin']} — padre RPU {A['padre']} DIR={A['dir']}; "
                f"hija {A['hija']} sin score ni orden."
            )
            row["_conclusion_regla"] = row["_dev"]

        elif code == "ORD-SALIDA":
            mark_real(
                row,
                B["id"],
                "REAL DEV · Caso B · rpu_orden_prioridad",
                q_orden(B["id"]),
                B["pin"],
            )
            row["_tabla_ejemplo"] = {
                "title": f"REAL · orden_prioridad · id_buro = {B['id']}",
                "headers": ["rpu", "Score DIR", "lugar", "orden_prioridad", "Fuente"],
                "rows": [
                    [str(B["rpu1"]), f"{B['s1']:.4f}", "1", "1", "REAL"],
                    [str(B["rpu2"]), f"{B['s2']:.4f}", "2", "2", "REAL"],
                ],
            }

        elif code == "ORD-RESUMEN":
            mark_real(
                row,
                B["id"],
                "REAL DEV · Caso B (referencia)",
                (
                    "SELECT unifica_atributos, COUNT(*) AS n\n"
                    "FROM bdm_datos.unificacion_direccion GROUP BY 1 ORDER BY 1;\n"
                    "-- Luego Caso B:\n"
                    + q_scores(B["id"], "DIR")
                ),
                B["pin"],
            )
            if isinstance(row.get("_tabla_ejemplo"), dict):
                row["_tabla_ejemplo"]["title"] = (
                    f"REAL · id_buro_persona = {B['id']} (2 ganadoras + hija)"
                )

        elif code == "ORD-TEL-RANK":
            mark_real(
                row,
                A["id"],
                "REAL DEV · Caso A · TEL/EMA independientes de DIR",
                q_scores(A["id"]),
                A["pin"],
            )
            row["_tabla_ejemplo"] = {
                "title": f"REAL · canales · id_buro_persona = {A['id']} (pin {A['pin']})",
                "headers": ["Canal", "RPU", "Score", "lugar", "¿Mezcla con otros canales?"],
                "rows": [
                    ["DIR", str(A["padre"]), f"{A['dir']:.4f}", "1", "No — ranking propio"],
                    ["TEL", str(A["padre"]), f"{A['tel']:.4f}", "1", "No — ranking propio"],
                    ["EMA", str(A["padre"]), f"{A['ema']:.4f}", "1", "No — ranking propio"],
                ],
            }
            row["_dev"] = (
                f"REAL: misma persona {A['id']} tiene DIR/TEL/EMA con lugar 1 en RPU {A['padre']}; "
                "los scores no se comparan entre canales."
            )
            row["_conclusion_regla"] = row["_dev"]

        elif code == "ORD-DIR-EMP" or "RANK-02" in titulo:
            mark_mock(
                row,
                MOCK["dir"],
                "MOCK · no hay empate DIR verificado en DEV para Caso A/B",
                (
                    "-- Buscar empates REALES en DEV (si aparecen, úsalos; si n=0 → no hay caso):\n"
                    "SELECT id_buro_persona, score, COUNT(*) AS n\n"
                    "FROM bdm_datos.score_ordenamiento\n"
                    "WHERE canal = 'DIR'\n"
                    "GROUP BY 1, 2\n"
                    "HAVING COUNT(*) > 1\n"
                    "LIMIT 20;\n"
                    "-- MOCK pedagógico (smoke):\n"
                    f"-- persona {MOCK['dir']}: dos calles con el mismo score → ROW_NUMBER no determinístico."
                ),
            )
            row["_tabla_ejemplo"] = {
                "title": "MOCK · RANK-02 — empate de score (sin ID DEV confirmado)",
                "headers": ["Fuente", "Dirección A", "Dirección B", "Score", "Qué hace Redshift"],
                "rows": [
                    [
                        "MOCK",
                        f"smoke {MOCK['dir']} calle A",
                        f"smoke {MOCK['dir']} calle B",
                        "igual",
                        "ROW_NUMBER — orden no garantizado",
                    ],
                    [
                        "REAL check",
                        "query empates DIR",
                        "—",
                        "—",
                        "Si la query de arriba da 0 filas, no hay caso real hoy",
                    ],
                ],
            }
            row["_dev"] = (
                "MOCK: Caso A/B no muestran empate DIR. Usa la query de búsqueda; "
                "si no hay filas, el escenario queda solo documental."
            )
            row["_conclusion_regla"] = row["_dev"]

        elif code == "ORD-TEL-02" or "TEL-02" in titulo:
            mark_mock(
                row,
                MOCK["tel"],
                "MOCK · TEL020 fuera del SUM (regla doc; sin persona DEV aislada)",
                (
                    "-- REAL (estructura): betas TEL cargados\n"
                    "SELECT codigo_variable, valor_beta\n"
                    "FROM bdm_datos.beta_ordenamiento\n"
                    "WHERE canal = 'TEL' AND codigo_variable ILIKE '%TEL020%';\n"
                    "-- MOCK smoke (si tienes lab):\n"
                    f"-- persona {MOCK['tel']}: cambiar solo TEL020 no debe mover el score."
                ),
            )
            row["_dev"] = "MOCK pedagógico + check REAL de beta TEL020 en catálogo."
            row["_conclusion_regla"] = row["_dev"]

        elif code == "ORD-CEL-02" or "CEL-02" in titulo:
            mark_mock(
                row,
                MOCK["cel"],
                "MOCK · default operador 0.22 (catálogo; Caso A/B casi sin CEL)",
                (
                    "-- REAL: catálogo operador / default\n"
                    "SELECT * FROM bdm_datos.catalogo_operador_celular LIMIT 20;\n"
                    "-- REAL: ¿hay CEL para Caso A/B?\n"
                    f"SELECT canal, rpu, score, lugar FROM (\n"
                    f"  SELECT canal, cod_dw_persona_ubic AS rpu, score, lugar\n"
                    f"  FROM bdm_datos.score_ordenamiento\n"
                    f"  WHERE id_buro_persona IN ({A['id']}, {B['id']}) AND canal = 'CEL'\n"
                    f") q;\n"
                    f"-- MOCK smoke persona {MOCK['cel']}: prefijo 310 vs 320 · sin mapeo → 0.22."
                ),
            )
            row["_tabla_ejemplo"] = {
                "title": "MOCK · CEL-02 — default sin operador (smoke)",
                "headers": ["Prefijo", "Operador", "Fuente", "Nota"],
                "rows": [
                    ["310", "CLARO", "MOCK smoke " + str(MOCK["cel"]), "Catálogo"],
                    ["999", "Sin mapeo", "MOCK", "Default 0.22"],
                    ["Caso A/B", "—", "REAL check query", "Puede devolver 0 filas CEL"],
                ],
            }
            row["_dev"] = (
                "MOCK para el ejemplo de prefijos. Query REAL comprueba si A/B tienen CEL "
                "(en DEV el canal CEL es muy chico: ~258 scores)."
            )
            row["_conclusion_regla"] = row["_dev"]

        elif code == "ORD-EMA-03" or "EMA-03" in titulo:
            mark_mock(
                row,
                MOCK["ema"],
                "MOCK · EMA003/007 fuera del SUM (regla doc)",
                (
                    "-- REAL: variables EMA excluidas del SUM\n"
                    "SELECT codigo_variable, valor_beta\n"
                    "FROM bdm_datos.beta_ordenamiento\n"
                    "WHERE canal = 'EMA'\n"
                    "  AND (codigo_variable ILIKE '%EMA003%' OR codigo_variable ILIKE '%EMA007%'\n"
                    "       OR codigo_variable ILIKE '%EMA018%' OR codigo_variable ILIKE '%EMA025%');\n"
                    f"-- MOCK smoke persona {MOCK['ema']}: gmail vs corporativo.\n"
                    "-- Score REAL Caso A (EMA):\n"
                    + q_scores(A["id"], "EMA")
                ),
            )
            row["_dev"] = (
                f"MOCK para el aislamiento EMA003/007. Score EMA REAL Caso A = {A['ema']} "
                f"(id_buro {A['id']})."
            )
            row["_conclusion_regla"] = row["_dev"]

        elif code in ("ORD-FLUJO", "ORD-SP-ORQ"):
            mark_real(
                row,
                A["id"],
                "REAL · orquestación DEV (luego valida Caso A/B)",
                (
                    "-- Ejecutar solo si tienes permiso de corrida:\n"
                    "CALL bdm_datos.sp_ordenamiento_ejecucion_edf(TRUE);\n"
                    "-- Validar personas REAL:\n"
                    + q_scores(A["id"])
                    + "\n"
                    + q_scores(B["id"], "DIR")
                ),
                A["pin"],
            )

        elif code in ("ORD-F1-RPU", "ORD-F1-BETA", "ORD-VAL", "ORD-SP-PREP", "ORD-ALCANCE", "ORD-F1-CT", "ORD-F3-BLOQ", "ORD-BITBUCKET"):
            # keep existing aggregate queries; tag REAL if query hits bdm_datos
            q = row.get("Query validación (copiar en dba_rncr_batch)") or ""
            if "bdm_datos" in q or "bdm_tempo" in q or q.startswith("CALL") or "sql/" in q:
                row["_fuente"] = "REAL"
                row["_ejemplo_label"] = row.get("_ejemplo_label") or "REAL · conteo / catálogo DEV"
                if not row.get("_id_ejemplo"):
                    row["_id_ejemplo"] = f"Conteo DEV (no persona) · ref Caso A {A['id']}"
                row["_show_query"] = True
            else:
                # ensure a real aggregate query
                mark_real(
                    row,
                    A["id"],
                    "REAL · gate / catálogo DEV",
                    (
                        "SELECT canal, COUNT(*) AS n, MIN(score) AS mn, MAX(score) AS mx\n"
                        "FROM bdm_datos.score_ordenamiento\n"
                        "GROUP BY 1 ORDER BY 1;"
                    ),
                    A["pin"],
                )

        else:
            if not row.get("_fuente"):
                row["_fuente"] = "REAL" if row.get("_show_query") else "MOCK"
                if row["_fuente"] == "MOCK" and not row.get("_id_ejemplo"):
                    mark_mock(
                        row,
                        MOCK["dir"],
                        "MOCK · sin caso persona DEV ligado a este bloque",
                        q_mock_smoke(MOCK["dir"]),
                    )

    for sp in data.get("sps_detalle") or []:
        arch = (sp.get("archivo") or "").lower()
        sid = sp.get("id") or ""
        if "scoring_dir" in arch or sid == "SP-05":
            sp["fuente"] = "REAL"
            sp["id_buro_persona"] = B["id"]
            sp["ejemplo"] = (
                f"REAL Caso B {B['id']}: RPU {B['rpu1']}={B['s1']} lugar 1; "
                f"{B['rpu2']}={B['s2']} lugar 2."
            )
            sp["query"] = q_scores(B["id"], "DIR")
        elif "scoring_tel" in arch or sid == "SP-06":
            sp["fuente"] = "REAL+MOCK"
            sp["id_buro_persona"] = A["id"]
            sp["ejemplo"] = (
                f"REAL Caso A {A['id']} TEL={A['tel']} lugar 1. "
                f"MOCK smoke {MOCK['tel']}: VALIDA vs NO VALIDA."
            )
            sp["query"] = (
                q_scores(A["id"], "TEL")
                + f"\n-- MOCK smoke persona {MOCK['tel']} (si tienes lab)."
            )
        elif "scoring_cel" in arch or sid == "SP-07":
            sp["fuente"] = "MOCK"
            sp["id_buro_persona"] = MOCK["cel"]
            sp["ejemplo"] = (
                f"MOCK smoke {MOCK['cel']}: prefijo 310 vs 320. "
                f"Check REAL CEL en A/B puede ser 0 filas."
            )
            sp["query"] = (
                f"SELECT COUNT(*) AS cel_ab FROM bdm_datos.score_ordenamiento\n"
                f"WHERE canal='CEL' AND id_buro_persona IN ({A['id']}, {B['id']});\n"
                f"-- MOCK: persona smoke {MOCK['cel']}"
            )
        elif "scoring_ema" in arch or sid == "SP-08":
            sp["fuente"] = "REAL+MOCK"
            sp["id_buro_persona"] = A["id"]
            sp["ejemplo"] = (
                f"REAL Caso A {A['id']} EMA={A['ema']}. "
                f"MOCK smoke {MOCK['ema']}: gmail vs corporativo."
            )
            sp["query"] = q_scores(A["id"], "EMA")
        elif "consolidacion" in arch or sid == "SP-09":
            sp["fuente"] = "REAL"
            sp["id_buro_persona"] = B["id"]
            sp["ejemplo"] = f"REAL Caso B {B['id']}: orden 1={B['rpu1']}, orden 2={B['rpu2']}."
            sp["query"] = q_orden(B["id"])
        else:
            sp.setdefault("fuente", "REAL")


# Patch renderScenarioCard to show REAL/MOCK badge — operate on unescaped then re-escape per file style
CHIP_SNIPPET_MARK = "const idEj = row._id_ejemplo"


def ensure_fuente_in_render(html: str) -> str:
    """Inject fuente badge into renderScenarioCard if not present."""
    marker = "ID del ejemplo"
    if "REAL / MOCK" in html or "_fuente" in html and "Fuente de datos" in html:
        # still upgrade chip block
        pass

    # Unescape-replace approach for the idBlock construction
    old = (
        "const idLabel = row._ejemplo_label || 'Ejemplo DEV';\n"
        "  const idBlock = idEj ? `<div class=\"scenario-section\" style=\"background:#eff6ff;border:1px solid #93c5fd;border-radius:8px;padding:0.55rem 0.75rem;margin:0.35rem 0 0.55rem;\"><span class=\"sec-label\" style=\"color:#1d4ed8;\">ID del ejemplo</span><p style=\"margin:0.15rem 0 0;font-family:ui-monospace,Consolas,monospace;font-size:0.92rem;font-weight:700;color:#1e3a8a;\"><code>${esc(idEj)}</code></p><p style=\"margin:0.2rem 0 0;font-size:0.78rem;color:#334155;\">${esc(idLabel)} · siempre visible en este escenario</p></div>` : '';"
    )
    new = (
        "const idLabel = row._ejemplo_label || 'Ejemplo DEV';\n"
        "  const fuente = (row._fuente || (String(idEj).indexOf('MOCK') >= 0 ? 'MOCK' : 'REAL')).toUpperCase();\n"
        "  const fuenteColor = fuente === 'MOCK' ? '#9a3412' : '#166534';\n"
        "  const fuenteBg = fuente === 'MOCK' ? '#fff7ed' : '#f0fdf4';\n"
        "  const fuenteBorder = fuente === 'MOCK' ? '#fdba74' : '#86efac';\n"
        "  const idBlock = idEj ? `<div class=\"scenario-section\" style=\"background:${fuenteBg};border:1px solid ${fuenteBorder};border-radius:8px;padding:0.55rem 0.75rem;margin:0.35rem 0 0.55rem;\"><span class=\"sec-label\" style=\"color:${fuenteColor};\">Fuente de datos · ${fuente}</span><p style=\"margin:0.15rem 0 0;font-family:ui-monospace,Consolas,monospace;font-size:0.92rem;font-weight:700;color:#1e3a8a;\"><code>${esc(idEj)}</code></p><p style=\"margin:0.2rem 0 0;font-size:0.78rem;color:#334155;\">${esc(idLabel)}</p><p style=\"margin:0.25rem 0 0;font-size:0.72rem;color:#64748b;\">${fuente === 'MOCK' ? 'No hay caso DEV confirmado → usa la query MOCK / búsqueda del botón Ver query.' : 'Query del botón Ver query → filas reales en dba_rncr_batch.'}</p></div>` : '';"
    )

    def esc_js(s: str, use_hex: bool) -> str:
        out = (
            s.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
        )
        if use_hex:
            out = out.replace("'", "&#x27;")
        return out

    if old in html:
        html = html.replace(old, new)
    old_esc = esc_js(old, use_hex=True)
    new_esc = esc_js(new, use_hex=True)
    if old_esc in html:
        html = html.replace(old_esc, new_esc)
    old_esc2 = esc_js(old, use_hex=False)
    new_esc2 = esc_js(new, use_hex=False)
    if old_esc2 in html:
        html = html.replace(old_esc2, new_esc2)

    # If chip still old style without fuente, try broader replace on "ID del ejemplo"
    if "Fuente de datos" not in html and "ID del ejemplo" in html:
        html = html.replace(
            ">ID del ejemplo</span>",
            ">Fuente de datos · (ver _fuente)</span>",
        )
    return html


def patch_sp_card_if_needed(html: str) -> str:
    # Soft: ensure frame-sub smoke texts mention MOCK
    repls = [
        (
            f"Ejemplo: persona {MOCK['tel']} VALIDA vs NO VALIDA · TEL020 no suma al score",
            f"MOCK smoke {MOCK['tel']} · TEL020 · check REAL betas TEL en bdm_datos",
        ),
        (
            f"Ejemplo: persona {MOCK['cel']} prefijo 310 vs 320 · sin operador → 0.22",
            f"MOCK smoke {MOCK['cel']} · default 0.22 · check REAL CEL Caso A/B (puede ser 0)",
        ),
        (
            f"Ejemplo: persona {MOCK['ema']} gmail vs corporativo · EMA003/007 no suman",
            f"MOCK smoke {MOCK['ema']} · EMA003/007 · REAL Caso A EMA={A['ema']}",
        ),
    ]
    for a, b in repls:
        html = html.replace(a, b)
    return html


def patch_file(path: Path) -> None:
    if not path.exists():
        print("SKIP", path)
        return
    bak = path.with_suffix(path.suffix + ".bak_real_mock")
    if not bak.exists():
        shutil.copy2(path, bak)
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    if len(positions) < 2:
        print("WARN DATA blocks", len(positions), path)
        return
    start = positions[1]
    while start < len(html) and html[start] in " \t\n\r":
        start += 1
    data, s0, s1 = extract_escaped_json(html, start)
    patch_ord_data(data)
    html = html[:s0] + dump_escaped(data) + html[s1:]
    html = ensure_fuente_in_render(html)
    html = patch_sp_card_if_needed(html)

    # Banner clarity
    html = html.replace(
        "Workshop · IDs reales DEV (2026-09-23) · dba_rncr_batch",
        "Workshop · REAL = IDs DEV · MOCK = smoke (si no hay caso) · 2026-09-23 · dba_rncr_batch",
    )
    path.write_text(html, encoding="utf-8")

    t2 = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", t2)]
    start = positions[1]
    while start < len(t2) and t2[start] in " \t\n\r":
        start += 1
    d2, _, _ = extract_escaped_json(t2, start)
    fuentes = {}
    missing = []
    for row in d2.get("rows") or []:
        f = row.get("_fuente", "?")
        fuentes[f] = fuentes.get(f, 0) + 1
        q = row.get("Query validación (copiar en dba_rncr_batch)") or ""
        if not q:
            missing.append(row.get("Escenario") or row.get("_esc_codigo"))
        if not row.get("_show_query"):
            row["_show_query"] = True
    if missing:
        print("  WARN missing query:", missing)
    print(path.name, "fuentes", fuentes, "chip", "Fuente de datos" in t2)


def main():
    for p in PATHS:
        print("===", p)
        patch_file(p)


if __name__ == "__main__":
    main()
