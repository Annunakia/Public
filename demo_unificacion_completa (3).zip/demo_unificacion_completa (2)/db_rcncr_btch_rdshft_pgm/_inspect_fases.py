# -*- coding: utf-8 -*-
import json, re, sys
from html import unescape
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
p = Path(
    r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
    r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
)
t = unescape(p.read_text(encoding="utf-8"))


def extract_obj(s, start):
    depth = 0
    in_q = False
    esc = False
    j = start
    while j < len(s):
        ch = s[j]
        if in_q:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_q = False
        else:
            if ch == '"':
                in_q = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return json.loads(s[start : j + 1])
        j += 1


datas = list(re.finditer(r"const DATA = (\{)", t))
d = extract_obj(t, datas[1].start(1))

print("=== keys ===")
for k in d:
    if "fase" in k.lower() or "guion" in k.lower() or "workshop" in k.lower() or "row" in k.lower():
        v = d[k]
        print(k, type(v).__name__, len(v) if isinstance(v, list) else "")

print("\n=== fases_doc ===")
for f in d.get("fases_doc") or []:
    print(f)

print("\n=== alcance ===")
for a in (d.get("alcance") or [])[:8]:
    print(a.get("id"), a.get("titulo"), a.get("estado"))

print("\n=== presentacion ===")
for b in d.get("presentacion") or []:
    print("-", b.get("titulo"), "layout", b.get("layout"), "casos", len(b.get("casos") or []), "sps", len(b.get("sps_mock") or []))

print("\n=== rows packs ===")
for r in d.get("rows") or []:
    print(
        r.get("_pack_code"),
        "|",
        (r.get("_titulo_corto") or r.get("Subescenario") or "")[:50],
        "| fase?",
        r.get("fase") or r.get("_fase") or r.get("Fase"),
    )

print("\n=== WORKSHOP_STEPS / guion ===")
# from outer t
for m in re.finditer(r"const WORKSHOP_STEPS = (\[[\s\S]*?\]);", t):
    labs = re.findall(r"label:\s*'([^']+)'", m.group(1))
    print("WORKSHOP_STEPS", labs)

guion = d.get("guion_sesion") or d.get("guion") or []
if isinstance(guion, list):
    for g in guion[:12]:
        print("guion", g if not isinstance(g, dict) else {k: g.get(k) for k in list(g)[:6]})
