# -*- coding: utf-8 -*-
"""Fix ORD-DIR-RANK to always show real id_buro_persona (Caso B) + sync copies."""
import json
import re
import shutil
from html import unescape
from pathlib import Path

PATHS = [
    Path(r"C:\Users\C32525E\Downloads\RECONOCER_TODO_EN_UNO_WORKSHOP.html"),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\repos\db_rcncr_btch_rdshft_dt"
        r"\docs\RECONOCER_TODO_EN_UNO.html"
    ),
]

CASO_A = {
    "id": 3228096126421495389,
    "pin": 98746,
    "padre": 2,
    "hija": 3,
    "dir_score": 639.7849,
}
CASO_B = {
    "id": 2848501447849812647,
    "pin": 165259,
    "rpu1": 166366,
    "score1": 611.8280,
    "rpu2": 166369,
    "score2": 599.7849,
    "hija": 166367,
}


def extract_escaped_json(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    raw = html[start:j]
    return json.loads(unescape(raw)), start, j


def dump_escaped(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":")).replace('"', "&quot;")


def patch_ord_data(data: dict) -> None:
    k = data.setdefault("kpis", {})
    k["pid_rank"] = CASO_B["id"]
    k["pid"] = CASO_A["id"]
    k["cod_pin"] = CASO_A["pin"]
    k["demo_id_buro_persona"] = CASO_B["id"]
    k["demo_caso"] = "B"
    k["demo_verificado"] = "2026-09-23"

    dir_min = k.get("canales", {}).get("DIR", {}).get("min", 453.5484)
    dir_max = k.get("canales", {}).get("DIR", {}).get("max", 796.9892)
    dir_n = k.get("canales", {}).get("DIR", {}).get("scores", 410455)
    concl = (
        f"DEV: {dir_n:,} scores DIR · rango {dir_min} – {dir_max}. "
        f"Ejemplo RANK-01: id_buro_persona={CASO_B['id']} "
        f"(RPU {CASO_B['rpu1']}={CASO_B['score1']} lugar 1 · "
        f"RPU {CASO_B['rpu2']}={CASO_B['score2']} lugar 2)."
    ).replace(",", ".")

    id_chip = f"id_buro_persona = {CASO_B['id']}"
    id_chip_a = f"id_buro_persona = {CASO_A['id']}"

    for row in data.get("rows") or []:
        code = row.get("Escenario") or row.get("_esc_codigo") or ""
        titulo = row.get("_titulo_corto") or row.get("Subescenario") or ""

        if code == "ORD-DIR-RANK" or "RANK-01" in titulo:
            row["_id_buro_persona"] = CASO_B["id"]
            row["_id_ejemplo"] = id_chip
            row["_ejemplo_label"] = "Caso B · 2 DIR ordenadas (DEV)"
            row["_cod_pin"] = CASO_B["pin"]
            row["_busca"] = (
                "Varias direcciones ganadoras por persona; mayor score → lugar 1 → orden_prioridad. "
                f"Ejemplo fijado: {id_chip} · pin {CASO_B['pin']}."
            )
            row["Qué encontramos DEV"] = concl
            row["Ejemplo verificable (reporte + ID + query)"] = (
                f"{id_chip} · RPU {CASO_B['rpu1']} score {CASO_B['score1']} lugar 1; "
                f"RPU {CASO_B['rpu2']} score {CASO_B['score2']} lugar 2; "
                f"hija {CASO_B['hija']} excluida."
            )
            row["_conclusion"] = concl
            row["_conclusion_regla"] = concl
            row["_dev"] = (
                f"Persona real DEV {id_chip}. "
                f"DIR {CASO_B['rpu1']} → {CASO_B['score1']} (lugar 1); "
                f"{CASO_B['rpu2']} → {CASO_B['score2']} (lugar 2). "
                f"Hija {CASO_B['hija']} sin score (F3-02)."
            )
            row["Query validación (copiar en dba_rncr_batch)"] = (
                "SELECT canal, cod_dw_persona_ubic AS rpu, score, lugar\n"
                "FROM bdm_datos.score_ordenamiento\n"
                f"WHERE id_buro_persona = {CASO_B['id']}\n"
                "ORDER BY canal, lugar;"
            )
            row["_show_query"] = True
            row["_tabla_ejemplo"] = {
                "title": (
                    f"Caso RANK-01 — {id_chip} (pin {CASO_B['pin']})"
                ),
                "headers": [
                    "RPU / Dirección",
                    "Score DIR",
                    "lugar",
                    "orden_prioridad",
                    "Por qué",
                ],
                "rows": [
                    [
                        f"{CASO_B['rpu1']} (ganadora)",
                        str(CASO_B["score1"]),
                        "1",
                        "1",
                        "Mayor score → primer contacto",
                    ],
                    [
                        f"{CASO_B['rpu2']} (ganadora / padre R2)",
                        str(CASO_B["score2"]),
                        "2",
                        "2",
                        "Vigente pero menos prioritaria",
                    ],
                    [
                        f"{CASO_B['hija']} (hija R2)",
                        "—",
                        "—",
                        "NULL",
                        "Excluida por unificación",
                    ],
                ],
            }
            row["_tabla_pasos"] = {
                "title": "Cómo se calcula el score DIR (resumen)",
                "headers": ["Paso", "Ejemplo", "Efecto en ranking"],
                "rows": [
                    [
                        "Agregar reportes",
                        "12 meses, sector financiero, tipo RES",
                        "Métricas CO00DIR*",
                    ],
                    [
                        "Categorizar",
                        "Valor → bin 1..4",
                        "Comparación con umbrales fijos",
                    ],
                    [
                        "Ponderar",
                        "(cat/max) × Beta RITM",
                        "Suma = score (cientos en DEV)",
                    ],
                    [
                        "Rankear",
                        f"ROW_NUMBER por {id_chip}",
                        "lugar 1 = máximo score",
                    ],
                ],
            }

        elif code == "ORD-RESUMEN":
            row["_id_buro_persona"] = CASO_B["id"]
            row["_id_ejemplo"] = id_chip
            row["_ejemplo_label"] = "Caso B · referencia RANK"
            if isinstance(row.get("_tabla_ejemplo"), dict):
                row["_tabla_ejemplo"] = {
                    "title": (
                        f"Ejemplo real DEV — {id_chip} (2 ganadoras + 1 hija)"
                    ),
                    "headers": [
                        "RPU",
                        "Rol",
                        "ind_unificacion",
                        "¿Entra a ordenamiento?",
                        "Por qué",
                    ],
                    "rows": [
                        [
                            str(CASO_B["rpu1"]),
                            "Ganadora lugar 1",
                            "NULL",
                            "Sí ✓",
                            f"Score DIR {CASO_B['score1']}",
                        ],
                        [
                            str(CASO_B["rpu2"]),
                            "Ganadora lugar 2 / padre R2",
                            "NULL",
                            "Sí ✓",
                            f"Score DIR {CASO_B['score2']}",
                        ],
                        [
                            str(CASO_B["hija"]),
                            "Hija R2",
                            "1",
                            "No ✗",
                            "Absorbida; solo trazabilidad",
                        ],
                    ],
                }

        elif code == "ORD-F3-HIJA" or "F3-02" in titulo:
            row["_id_buro_persona"] = CASO_A["id"]
            row["_id_ejemplo"] = id_chip_a
            row["_ejemplo_label"] = "Caso A · hija 3 → padre 2"
            row["_tabla_ejemplo"] = {
                "title": f"Caso F3-02 — {id_chip_a} (hija {CASO_A['hija']} → padre {CASO_A['padre']})",
                "headers": ["Campo", "Valor hija", "Valor padre ganador", "Regla"],
                "rows": [
                    ["ind_unificacion", "1", "NULL", "Hija marcada en unificación"],
                    [
                        "score_ordenamiento",
                        "— (no existe)",
                        str(CASO_A["dir_score"]),
                        "Solo ganadoras reciben score",
                    ],
                    ["orden_prioridad", "NULL", "1", "Prioridad solo en vigentes"],
                    [
                        "unificacion_direccion",
                        f"Apunta al padre {CASO_A['padre']}",
                        "—",
                        "Trazabilidad; ordenamiento no la borra",
                    ],
                ],
            }
            row["_dev"] = (
                f"{id_chip_a} · pin {CASO_A['pin']}: hija RPU {CASO_A['hija']} sin score; "
                f"padre RPU {CASO_A['padre']} DIR={CASO_A['dir_score']} lugar 1."
            )
            row["_conclusion_regla"] = row.get("_dev", "")
            row["Query validación (copiar en dba_rncr_batch)"] = (
                "SELECT canal, cod_dw_persona_ubic AS rpu, score, lugar\n"
                "FROM bdm_datos.score_ordenamiento\n"
                f"WHERE id_buro_persona = {CASO_A['id']}\n"
                "ORDER BY canal, lugar;"
            )
            row["_show_query"] = True

        elif code == "ORD-SALIDA":
            row["_id_buro_persona"] = CASO_B["id"]
            row["_id_ejemplo"] = id_chip
            row["_ejemplo_label"] = "Caso B · orden_prioridad"
            row["_tabla_ejemplo"] = {
                "title": f"Salida real — {id_chip}",
                "headers": [
                    "cod_dw_persona_ubic",
                    "Score DIR",
                    "lugar",
                    "orden_prioridad",
                ],
                "rows": [
                    [str(CASO_B["rpu1"]), str(CASO_B["score1"]), "1", "1"],
                    [str(CASO_B["rpu2"]), str(CASO_B["score2"]), "2", "2"],
                ],
            }

        elif code == "ORD-TEL-RANK":
            row["_id_buro_persona"] = CASO_B["id"]
            row["_id_ejemplo"] = id_chip
            row["_ejemplo_label"] = "Caso B · canales independientes"

        elif code == "ORD-DIR-EMP" or "RANK-02" in titulo:
            row["_id_buro_persona"] = CASO_B["id"]
            row["_id_ejemplo"] = id_chip
            row["_ejemplo_label"] = "Mismo id_buro; empate es caso documental"

    for sp in data.get("sps_detalle") or []:
        arch = (sp.get("archivo") or sp.get("id") or "").lower()
        if "scoring_dir" in arch or sp.get("id") == "SP-05":
            sp["ejemplo"] = (
                f"Caso B {id_chip}: RPU {CASO_B['rpu1']} score {CASO_B['score1']} → lugar 1; "
                f"RPU {CASO_B['rpu2']} score {CASO_B['score2']} → lugar 2. "
                f"Caso A {id_chip_a}: solo RPU {CASO_A['padre']} DIR={CASO_A['dir_score']}."
            )
            sp["id_buro_persona"] = CASO_B["id"]


RENDER_OLD = """function renderScenarioCard(row, idx) {
  const bc = badgeClass(row.Estado);
  const titulo = row._titulo_corto || row.Subescenario || row.Escenario;
  const busca = row._busca || '';
  const dev = row._dev || '';
  const conclusion = row._conclusion_regla || '';
  const q = row['Query validación (copiar en dba_rncr_batch)'] || '';
  const headQueryBtn = q && row._show_query ? `<button type="button" class="btn btn-query btn-head-query btn-card-query" data-idx="${idx}">Ver query</button>` : '';
  const tblPasos = wrapTblBlock(row._tabla_pasos, 'full');
  const tblEj = wrapTblBlock(row._tabla_ejemplo, 'ej-full');
  const buscaBlock = busca ? `<div class="scenario-section"><span class="sec-label">Regla de negocio</span><p class="busca-line">${esc(busca)}</p></div>` : '';
  const devBlock = dev ? `<div class="scenario-section dev-narrative"><span class="sec-label">Qué encontramos en DEV</span><p>${esc(dev)}</p></div>` : '';
  const conclBlock = conclusion ? `<div class="scenario-section conclusion-box"><span class="sec-label">Conclusión</span><p>${esc(conclusion)}</p></div>` : '';
  const accion = row['Acción / revisión'];
  const accionBlock = accion ? `<div class="scenario-section"><span class="sec-label">Siguiente paso</span><p>${esc(accion)}</p></div>` : '';
  return `<div class="scenario-item">
    <div class="esc-pill paso"><span class="esc-code">${esc(escCodigo(row))}</span><span class="esc-kind">Escenario</span></div>
    <div class="scenario-body">
      <div class="scenario-head">
        <div class="scenario-head-main">
          <span class="badge ${bc}">${esc(row.Estado||'—')}</span>
          <div class="scenario-head-text"><h4>${esc(titulo)}</h4></div>
        </div>
        ${headQueryBtn}
      </div>
      ${buscaBlock}${tblPasos}${tblEj}${devBlock}${conclBlock}${accionBlock}
    </div>
  </div>`;
}"""

RENDER_NEW = """function renderScenarioCard(row, idx) {
  const bc = badgeClass(row.Estado);
  const titulo = row._titulo_corto || row.Subescenario || row.Escenario;
  const busca = row._busca || '';
  const dev = row._dev || '';
  const conclusion = row._conclusion_regla || '';
  const q = row['Query validación (copiar en dba_rncr_batch)'] || '';
  const headQueryBtn = q && row._show_query ? `<button type="button" class="btn btn-query btn-head-query btn-card-query" data-idx="${idx}">Ver query</button>` : '';
  const tblPasos = wrapTblBlock(row._tabla_pasos, 'full');
  const tblEj = wrapTblBlock(row._tabla_ejemplo, 'ej-full');
  const idEj = row._id_ejemplo || (row._id_buro_persona != null ? ('id_buro_persona = ' + row._id_buro_persona) : (DATA.kpis && DATA.kpis.demo_id_buro_persona ? ('id_buro_persona = ' + DATA.kpis.demo_id_buro_persona) : ''));
  const idLabel = row._ejemplo_label || 'Ejemplo DEV';
  const idBlock = idEj ? `<div class="scenario-section" style="background:#eff6ff;border:1px solid #93c5fd;border-radius:8px;padding:0.55rem 0.75rem;margin:0.35rem 0 0.55rem;"><span class="sec-label" style="color:#1d4ed8;">ID del ejemplo</span><p style="margin:0.15rem 0 0;font-family:ui-monospace,Consolas,monospace;font-size:0.92rem;font-weight:700;color:#1e3a8a;"><code>${esc(idEj)}</code></p><p style="margin:0.2rem 0 0;font-size:0.78rem;color:#334155;">${esc(idLabel)} · siempre visible en este escenario</p></div>` : '';
  const buscaBlock = busca ? `<div class="scenario-section"><span class="sec-label">Regla de negocio</span><p class="busca-line">${esc(busca)}</p></div>` : '';
  const devBlock = dev ? `<div class="scenario-section dev-narrative"><span class="sec-label">Qué encontramos en DEV</span><p>${esc(dev)}</p></div>` : '';
  const conclBlock = conclusion ? `<div class="scenario-section conclusion-box"><span class="sec-label">Conclusión</span><p>${esc(conclusion)}</p></div>` : '';
  const accion = row['Acción / revisión'];
  const accionBlock = accion ? `<div class="scenario-section"><span class="sec-label">Siguiente paso</span><p>${esc(accion)}</p></div>` : '';
  return `<div class="scenario-item">
    <div class="esc-pill paso"><span class="esc-code">${esc(escCodigo(row))}</span><span class="esc-kind">Escenario</span></div>
    <div class="scenario-body">
      <div class="scenario-head">
        <div class="scenario-head-main">
          <span class="badge ${bc}">${esc(row.Estado||'—')}</span>
          <div class="scenario-head-text"><h4>${esc(titulo)}</h4></div>
        </div>
        ${headQueryBtn}
      </div>
      ${idBlock}${buscaBlock}${tblPasos}${tblEj}${devBlock}${conclBlock}${accionBlock}
    </div>
  </div>`;
}"""


def patch_ui_strings(html: str) -> str:
    repls = [
        (
            "Ejemplo: persona 20001 casa vs oficina · 20002 una sola calle · 20003 tres calles",
            f"Ejemplo fijado: id_buro_persona={CASO_B['id']} · RPU {CASO_B['rpu1']}/{CASO_B['rpu2']} lugares 1/2",
        ),
        (
            "Persona 20001: casa vs oficina. 20003: tres calles → lugar 1/2/3.",
            f"Caso B {CASO_B['id']}: RPU {CASO_B['rpu1']} lugar 1 · {CASO_B['rpu2']} lugar 2.",
        ),
        (
            "¿Demo mesa: smoke 20001–20009 + KPIs DEV (1,22M scores · 0 hijas) con este HTML?",
            f"¿Demo mesa: Caso B {CASO_B['id']} (RANK-01) + Caso A {CASO_A['id']} (F3-02) + KPIs DEV?",
        ),
        (
            "Pregunta de negocio + ejemplo smoke · _strct · _pgm · _dt",
            f"Pregunta de negocio + id_buro={CASO_B['id']} · _strct · _pgm · _dt",
        ),
        (
            "409,014 scores DIR · rango 0.6113–0.843.",
            f"410.455 scores DIR · rango 453.5484 – 796.9892 · id={CASO_B['id']}.",
        ),
        (
            "DEV: 409,014 scores DIR · rango 0.6113–0.843.",
            f"DEV: 410.455 scores DIR · rango 453.5484 – 796.9892 · id={CASO_B['id']}.",
        ),
        (
            "0.84",
            str(CASO_B["score1"]),
        ),
        (
            "0.71",
            str(CASO_B["score2"]),
        ),
    ]
    for a, b in repls:
        # only replace escaped variants in HTML entities context
        html = html.replace(a, b)
        html = html.replace(a.replace("·", "·"), b)
        # HTML-escaped inside script templates use &#x27; etc — plain text above covers frame-sub
        html = html.replace(
            a.replace("=", "=&#x27;" ) if False else a,
            b,
        )
    # escaped versions in DATA already handled by JSON patch; also fix common HTML entities forms
    for a, b in [
        (
            "Ejemplo: persona 20001 casa vs oficina · 20002 una sola calle · 20003 tres calles",
            f"Ejemplo fijado: id_buro_persona={CASO_B['id']} · RPU {CASO_B['rpu1']}/{CASO_B['rpu2']} lugares 1/2",
        ),
    ]:
        html = html.replace(
            a.replace(" ", " ").replace("·", "&middot;") if False else a,
            b,
        )
    return html


def patch_render_functions(html: str) -> str:
    # Work on both raw and HTML-escaped forms of the function
    if RENDER_OLD in html:
        html = html.replace(RENDER_OLD, RENDER_NEW)
    old_esc = (
        RENDER_OLD.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )
    new_esc = (
        RENDER_NEW.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )
    if old_esc in html:
        html = html.replace(old_esc, new_esc)
    else:
        # try entity form used in file (escaped < as &lt; but quotes as &quot;)
        # The workshop file embeds JS inside HTML as text with &lt; &gt; &quot;
        marker = "function renderScenarioCard(row, idx)"
        # find in escaped content
        idx = 0
        count = 0
        while True:
            i = html.find(marker, idx)
            if i < 0:
                break
            count += 1
            # determine if escaped
            window = html[i : i + 80]
            is_escaped = "&lt;" in html[i : i + 400] or "&#x27;" in html[i : i + 200]
            # find end of function: next "function showRuleScenario"
            end_marker = "function showRuleScenario"
            j = html.find(end_marker, i)
            if j < 0:
                break
            old_block = html[i:j]
            if is_escaped or "&lt;" in old_block[:200]:
                # build escaped new from RENDER_NEW with same escaping style as surrounding
                # Detect style: &#x27; vs '
                use_hex = "&#x27;" in old_block
                nb = RENDER_NEW
                if use_hex:
                    nb = (
                        nb.replace("&", "&amp;")
                        .replace("<", "&lt;")
                        .replace(">", "&gt;")
                        .replace('"', "&quot;")
                        .replace("'", "&#x27;")
                    )
                else:
                    nb = (
                        nb.replace("&", "&amp;")
                        .replace("<", "&lt;")
                        .replace(">", "&gt;")
                        .replace('"', "&quot;")
                    )
                # keep trailing whitespace before showRuleScenario
                trail = ""
                k = j - 1
                while k >= i and html[k] in " \t\n\r":
                    trail = html[k] + trail
                    k -= 1
                # old_block may include trailing newlines before showRuleScenario
                # Replace only up to last non-ws of function
                html = html[:i] + nb + trail + html[j:]
                idx = i + len(nb) + len(trail) + 10
            else:
                html = html[:i] + RENDER_NEW + html[j:]
                idx = i + len(RENDER_NEW) + 10
            # only patch ord copy (second) preferentially — patch all occurrences
        print(f"  renderScenarioCard occurrences touched: {count}")
    return html


def patch_file(path: Path) -> None:
    if not path.exists():
        print("SKIP missing", path)
        return
    bak = path.with_suffix(path.suffix + ".bak_id_ejemplo")
    if not bak.exists():
        shutil.copy2(path, bak)
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    if len(positions) < 2:
        print("WARN expected 2 DATA blocks in", path, "got", len(positions))
        return

    # Patch ordenamiento DATA (index 1)
    start = positions[1]
    while start < len(html) and html[start] in " \t\n\r":
        start += 1
    data, s0, s1 = extract_escaped_json(html, start)
    patch_ord_data(data)
    new_json = dump_escaped(data)
    html = html[:s0] + new_json + html[s1:]

    html = patch_ui_strings(html)
    html = patch_render_functions(html)

    # Strengthen banner line for Caso B as RANK example
    old_b = "Caso B (2 DIR ordenadas):"
    new_b = "Caso B (RANK-01 · ID que muestra 2a DIR):"
    html = html.replace(old_b, new_b)

    path.write_text(html, encoding="utf-8")
    # verify
    t = path.read_text(encoding="utf-8")
    ok_rank = "2848501447849812647" in t and "611.828" in t
    ok_render = "_id_ejemplo" in t and "ID del ejemplo" in t
    print(
        f"OK {path.name}: rank_id={ok_rank} render_chip={ok_render} size={path.stat().st_size}"
    )


def main():
    for p in PATHS:
        print("===", p)
        patch_file(p)


if __name__ == "__main__":
    main()
