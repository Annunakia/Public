# -*- coding: utf-8 -*-
"""
Workshop = lenguaje funcional (ex-Demo).
Demo = recorrido por fases (ex-Workshop), sin SPs inline.
SPs = pestaña aparte.
Mapa de fases + arquitectura unidos en Workshop.
"""
from __future__ import annotations

import json
import re
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

PRESENTACION = [
    {
        "titulo": "Qué hace el ordenamiento (en simple)",
        "lead": "Después de unificar, una persona puede tener varias direcciones, fijos, celulares o correos. El ordenamiento responde: ¿cuál intento primero?",
        "bullets": [
            "No mezcla canales: un teléfono no compite con un email.",
            "Solo mira contactos que sí sirven (elegibles).",
            "Al final, para calle, deja un orden de intento en la dirección.",
        ],
    },
    {
        "titulo": "Mapa de fases + cómo corre (arquitectura)",
        "lead": "Mismo recorrido de negocio y de sistema: de la unificación al orden guardado.",
        "layout": "fase_arquitectura",
        "fases": [
            {
                "fase": "0",
                "nombre": "Ya unificado",
                "pregunta": "¿Qué dirección sigue vigente?",
                "hecho": "Quedan ganadoras; las hijas ya no se usan para contactar.",
                "arco": "Lee el resultado de unificación (sin volver a unificar).",
            },
            {
                "fase": "1",
                "nombre": "¿Quién entra?",
                "pregunta": "¿Qué teléfonos / mails / calles pasan al ranking?",
                "hecho": "Solo ganadoras + tipos válidos. Email sin @ no entra. TEL/CEL necesitan DIR ganadora.",
                "arco": "Arma bandejas por canal (DIR, TEL, CEL, EMA) desde el origen XPM vía datasharing.",
            },
            {
                "fase": "2",
                "nombre": "¿Cuál primero?",
                "pregunta": "¿Casa o oficina? ¿Fijo válido o no? ¿Claro o Movistar?",
                "hecho": "Cada canal ordena por suyo: mayor score → lugar 1.",
                "arco": "Aplica pesos del catálogo (betas) y deja lugar 1, 2, 3… por canal.",
            },
            {
                "fase": "3",
                "nombre": "Guardar orden de calle",
                "pregunta": "¿Qué queda escrito para intentar en campo?",
                "hecho": "El lugar de la dirección se guarda como orden de prioridad.",
                "arco": "Persiste solo el orden DIR; TEL/CEL/EMA no escriben ese campo.",
            },
            {
                "fase": "4",
                "nombre": "Limpiar temporales",
                "pregunta": "¿Queda basura de la corrida?",
                "hecho": "Se borran tablas temporales; el orden guardado se conserva.",
                "arco": "Cierra la corrida sin copia permanente del origen.",
            },
        ],
    },
    {
        "titulo": "Historia 1 — Casa o oficina",
        "lead": "Mira esta persona: tiene casa y oficina, las dos vigentes.",
        "layout": "historia",
        "pasos": [
            "Abrimos sus dos direcciones: casa y oficina.",
            "Como las dos son ganadoras, las dos compiten en el canal de dirección.",
            "Miramos el historial y los pesos del catálogo (qué tanto ‘pesa’ cada señal).",
            "La casa sale con mejor score → lugar 1. La oficina queda en lugar 2.",
            "Conclusión: en calle intentamos primero la casa; después la oficina.",
        ],
        "tabla": {
            "headers": ["Qué tiene", "¿Compite?", "Score", "Orden de intento"],
            "rows": [
                ["Casa", "Sí (ganadora)", "850", "1º"],
                ["Oficina", "Sí (ganadora)", "700", "2º"],
            ],
        },
    },
    {
        "titulo": "Historia 2 — Dirección hija (ya no vigente)",
        "lead": "Mira esta persona: unificación dejó un padre y una hija.",
        "layout": "historia",
        "pasos": [
            "El padre es la dirección vigente (ganadora).",
            "La hija quedó marcada como absorbida: ya no es el contacto a usar.",
            "Por eso la hija no entra al ranking: no recibe score ni orden.",
            "Conclusión: solo el padre queda de primeras; la hija no se intenta.",
        ],
        "tabla": {
            "headers": ["Rol", "¿Entra al orden?", "Por qué"],
            "rows": [
                ["Padre (ganadora)", "Sí", "Es la dirección vigente"],
                ["Hija", "No", "Ya fue absorbida en unificación"],
            ],
        },
    },
    {
        "titulo": "Historia 3 — Fijo válido vs no válido",
        "lead": "Mira esta persona: tiene dos fijos en el canal TEL.",
        "layout": "historia",
        "pasos": [
            "Uno está marcado como válido; el otro como no válido.",
            "En TEL solo se ordenan fijos entre sí (no contra emails ni celdas).",
            "El válido concentra mejor señal → queda de primeras.",
            "El no válido puede aparecer después, pero no gana el primer intento.",
            "Conclusión: primero el fijo usable; el sucio no manda.",
        ],
        "tabla": {
            "headers": ["Teléfono", "Estado", "¿Primero?"],
            "rows": [
                ["Fijo A", "Válido", "Sí (lugar 1)"],
                ["Fijo B", "No válido", "No (lugar 2)"],
            ],
        },
    },
    {
        "titulo": "Historia 4 — ¿Claro o Movistar? (prefijo del celular)",
        "lead": "Mira esta persona: tiene un celular. ¿Cómo sabemos el operador?",
        "layout": "historia",
        "pasos": [
            "Tomamos los primeros 3 dígitos del número (el prefijo).",
            "Ese prefijo lo buscamos en una tabla de operadores (catálogo).",
            "Si el prefijo es 310 y en la tabla dice Claro, usamos el peso de Claro.",
            "Si el prefijo es 999 y NO está en la tabla, no inventamos operador: usamos el valor por defecto acordado (0.22).",
            "Con ese peso se arma el score del celular y queda el orden en CEL.",
            "Conclusión: no adivinamos el operador; lo leemos de la tabla, o aplicamos el default.",
        ],
        "tabla": {
            "headers": ["Prefijo", "¿Está en la tabla?", "Qué hacemos", "Efecto"],
            "rows": [
                ["310", "Sí → Claro", "Usamos el peso de Claro", "Entra al score CEL"],
                ["999", "No", "Default 0.22", "Score de ejemplo 220; no queda en cero"],
            ],
        },
    },
    {
        "titulo": "Historia 5 — ¿Qué teléfonos sí entran y cuáles no?",
        "lead": "Reglas de elegibilidad en lenguaje de mesa.",
        "layout": "historia",
        "pasos": [
            "Sí entra a DIR: dirección ganadora (casa/oficina/correspondencia según tipo).",
            "Sí entra a TEL/CEL: solo si la persona ya tiene al menos una dirección ganadora.",
            "Sí entra a EMA: correo con @.",
            "No entra: hija unificada; email sin @; tipo fuera del mapa; TEL/CEL sin DIR ganadora.",
            "Conclusión: el ranking solo ve contactos útiles y vigentes.",
        ],
        "tabla": {
            "headers": ["Contacto", "¿Entra?", "Motivo"],
            "rows": [
                ["Casa ganadora", "Sí", "DIR vigente"],
                ["Hija unificada", "No", "Ya no es vigente"],
                ["Fijo con DIR ganadora", "Sí", "TEL elegible"],
                ["Celular sin DIR ganadora", "No", "Falta ancla de dirección"],
                ["mail_sin_arroba.com", "No", "Email inválido"],
                ["user@empresa.co", "Sí", "EMA con @"],
            ],
        },
    },
    {
        "titulo": "Historia 6 — Orden en calle",
        "lead": "Cuando ya sabemos el lugar de cada dirección…",
        "layout": "historia",
        "pasos": [
            "El lugar 1 de dirección se convierte en el primer intento en campo.",
            "El lugar 2 queda como segundo intento.",
            "TEL, CEL y EMA tienen su propio ranking, pero no escriben el orden de calle.",
            "Al cerrar la corrida se limpian temporales; el orden guardado se queda.",
            "Conclusión: lo que sale a operación es el orden de direcciones vigentes.",
        ],
        "tabla": {
            "headers": ["Dirección", "Lugar", "Orden de intento"],
            "rows": [
                ["Casa", "1", "1"],
                ["Oficina", "2", "2"],
            ],
        },
    },
    {
        "titulo": "Siguiente",
        "lead": "En Demo recorres los mismos ejemplos paso a paso. En SPs está el detalle técnico de archivos.",
        "bullets": [
            "Workshop = lenguaje de negocio (este tab).",
            "Demo = casos guiados por fase.",
            "SPs = catálogo técnico aparte.",
        ],
    },
]

# Narrativas funcionales para Demo (sin SP)
DEV_FUNC = {
    "INSUMO-CT": (
        "Mira el mapa de tipos: casa/oficina van a dirección; fijos a TEL; celular a CEL; correo a EMA. "
        "El email sin @ no entra. Así solo llegan al ranking los contactos que sí sirven por canal."
    ),
    "RPU-STG": (
        "Mira esta persona con padre e hija. La hija ya no es vigente: no la usamos para contactar. "
        "Solo el padre entra al orden."
    ),
    "BETAS": (
        "Los pesos no se inventan en la corrida: viven en un catálogo acordado. "
        "Ese catálogo es el que mueve el score (qué tanto cuenta cada señal)."
    ),
    "DIR-RANK": (
        "Mira esta persona con casa y oficina. Las dos compiten. "
        "Casa saca mejor score → la intentamos primero; oficina después."
    ),
    "ELEG-HIJA": (
        "Misma idea: la hija unificada no compite. Queda fuera del ranking y del orden de calle."
    ),
    "ELEG-BLOQ": (
        "Mira dos fijos: uno válido y uno no válido. El válido queda de primeras; el otro no manda."
    ),
    "DIR-EMPATE": (
        "Si dos direcciones empatan en score, no inventamos una regla nueva de desempate de negocio: "
        "quedan lugar 1 y 2 por orden técnico."
    ),
    "TEL-RANK": (
        "En TEL solo se ordenan fijos entre sí. El válido gana el primer intento."
    ),
    "TEL-02": (
        "Hay una señal de geo que se puede calcular para trazabilidad, pero no mueve el score. "
        "Por eso dos fijos pueden quedar iguales aunque esa señal cambie."
    ),
    "CEL-02": (
        "Mira este celular con prefijo 999. Buscamos 999 en la tabla de operadores: no está. "
        "Entonces no asumimos Claro ni Movistar: usamos el default 0.22 y el celular sí entra al ranking (no queda en cero)."
    ),
    "EMA-03": (
        "En email hay variables que se calculan para seguimiento pero no suman al score. "
        "Si solo cambian esas, el orden del correo no se mueve."
    ),
    "CONSOL": (
        "Cuando ya tenemos lugar 1 y 2 en dirección, eso se guarda como orden de intento en calle. "
        "TEL/CEL/EMA no escriben ese orden."
    ),
    "DROP": (
        "Al terminar, limpiamos lo temporal de la corrida. El orden de calle ya guardado se conserva."
    ),
}

CONCL_FUNC = {
    "INSUMO-CT": (
        "Se estableció qué tipos entran a cada canal. "
        "Por ello solo llegan al ranking los contactos elegibles (y el email sin @ queda fuera)."
    ),
    "RPU-STG": (
        "Se estableció que la hija no es contacto vigente. Por ello solo el padre ordena."
    ),
    "BETAS": (
        "Se estableció usar el catálogo de pesos. Por ello el score refleja esos pesos, no valores inventados en la corrida."
    ),
    "DIR-RANK": (
        "Se estableció que gana el mayor score de dirección. Por ello la casa queda de primeras frente a la oficina."
    ),
    "ELEG-HIJA": (
        "Se estableció excluir hijas. Por ello no reciben score ni orden de intento."
    ),
    "ELEG-BLOQ": (
        "Se estableció priorizar el contacto válido. Por ello el fijo válido queda de primeras."
    ),
    "DIR-EMPATE": (
        "Se estableció no crear desempate de negocio nuevo. Por ello el empate se resuelve solo con orden técnico."
    ),
    "TEL-RANK": (
        "Se estableció ordenar TEL aparte y priorizar válido. Por ello el fijo usable queda de primeras."
    ),
    "TEL-02": (
        "Se estableció que la señal geo no suma al score. Por ello el ranking TEL no se mueve solo por esa señal."
    ),
    "CEL-02": (
        "Se estableció leer el operador en la tabla de prefijos y, si no está, usar default 0.22. "
        "Por ello el 999 no queda en cero y sí puede ordenarse."
    ),
    "EMA-03": (
        "Se estableció dejar fuera de suma ciertas variables de email. Por ello no cambian quién va primero."
    ),
    "CONSOL": (
        "Se estableció guardar el lugar DIR como orden de calle. Por ello el 1º de dirección es el 1º intento en campo."
    ),
    "DROP": (
        "Se estableció limpiar temporales al cerrar. Por ello no queda basura y el orden guardado sigue."
    ),
}


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def esc_js(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#x27;")
    )


RENDER_PRES = r"""function renderPresentacion() {
  const items = DATA.presentacion || [];
  const el = document.getElementById('presentacionWrap');
  if (!el) return;
  const tbl = (tabla) => {
    if (!tabla || !tabla.headers) return '';
    const head = tabla.headers.map(h => `<th>${esc(h)}</th>`).join('');
    const body = (tabla.rows || []).map(r =>
      `<tr>${r.map(c => `<td>${esc(String(c ?? ''))}</td>`).join('')}</tr>`
    ).join('');
    return `<div class="demo-tabla-wrap"><table class="demo-tabla"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
  };
  const mapaArq = (fases) => {
    if (!fases || !fases.length) return '';
    return `<div class="demo-fase-mapa demo-fase-arq">${fases.map((f, i) => `
      <article class="demo-fase-card">
        <div class="demo-fase-num">Fase ${esc(String(f.fase))}</div>
        <h5>${esc(f.nombre || '')}</h5>
        <p class="demo-fase-q">${esc(f.pregunta || '')}</p>
        <p class="demo-fase-h"><b>Negocio:</b> ${esc(f.hecho || '')}</p>
        <p class="demo-fase-h"><b>Cómo corre:</b> ${esc(f.arco || '')}</p>
      </article>${i < fases.length - 1 ? '<div class="demo-fase-arrow" aria-hidden="true">→</div>' : ''}`).join('')}</div>`;
  };
  const historia = (b) => {
    const pasos = (b.pasos || []).map((p, i) => `<li><span class="hist-n">${i + 1}</span> ${esc(p)}</li>`).join('');
    return `${b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : ''}
      <ol class="demo-historia">${pasos}</ol>
      ${tbl(b.tabla)}`;
  };
  el.innerHTML = items.map(b => {
    const lead = b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : '';
    const bullets = (b.bullets && b.bullets.length)
      ? `<ul class="demo-chips">${b.bullets.map(x => `<li>${esc(x)}</li>`).join('')}</ul>`
      : '';
    let body = `${lead}${bullets}`;
    if (b.layout === 'fase_arquitectura') body = `${lead}${mapaArq(b.fases)}`;
    else if (b.layout === 'historia') body = historia(b);
    else if (b.layout === 'fase_mapa') body = `${lead}${mapaArq(b.fases)}`;
    return `<section class="demo-section">
      <h4>${esc(b.titulo)}</h4>
      ${body}
    </section>`;
  }).join('');
}"""

CSS_EXTRA = """
/* Historias funcionales Workshop */
.demo-historia {
  margin: 0.35rem 0 0.75rem; padding: 0; list-style: none;
  display: flex; flex-direction: column; gap: 0.45rem;
}
.demo-historia li {
  display: flex; gap: 0.55rem; align-items: flex-start;
  background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px;
  padding: 0.55rem 0.7rem; font-size: 0.84rem; line-height: 1.45; color: #0f172a;
}
.demo-historia .hist-n {
  flex: 0 0 1.35rem; height: 1.35rem; border-radius: 50%;
  background: #1d6fdc; color: #fff; font-size: 0.72rem; font-weight: 800;
  display: inline-flex; align-items: center; justify-content: center;
}
.demo-fase-arq .demo-fase-card { flex: 1 1 150px; }
#frame-sps { display: flex !important; }
#frame-sps.frame-off { display: none !important; }
"""


def patch_data(data: dict) -> None:
    data["presentacion"] = PRESENTACION
    for r in data.get("rows") or []:
        code = r.get("_pack_code")
        if code in DEV_FUNC:
            r["_dev"] = DEV_FUNC[code]
        if code in CONCL_FUNC:
            r["_conclusion"] = CONCL_FUNC[code]
            r["_conclusion_regla"] = CONCL_FUNC[code]
        # quitar SPs del recorrido Demo (van a pestaña SPs)
        if "_sps_relacionados" in r:
            r["_sps_relacionados"] = []
        # limpiar menciones SP en textos
        for k in ("_busca", "_ejemplo_label", "Subescenario", "_titulo_corto"):
            if isinstance(r.get(k), str) and "SP-" in r[k]:
                r[k] = re.sub(r"\s*SP-[A-Z0-9]+\s*", " ", r[k]).strip()


def patch_ui(html: str) -> str:
    # Unhide sps in ord css
    html = html.replace(
        "#frame-sps { display: none !important; }",
        "/* frame-sps visible como pestaña SPs */",
    )
    html = html.replace(
        "#frame-sps { display:none !important; }",
        "/* frame-sps visible */",
    )

    # FRAMES: Workshop | Demo | SPs
    old_f = """const FRAMES = [
  { id: &#x27;demo&#x27;, label: &#x27;Demo&#x27;, el: &#x27;frame-home&#x27;, progress: 0 },
  { id: &#x27;workshop&#x27;, label: &#x27;Workshop&#x27;, el: &#x27;frame-workshop&#x27;, progress: 55 },
];"""
    new_f = """const FRAMES = [
  { id: &#x27;workshop&#x27;, label: &#x27;Workshop&#x27;, el: &#x27;frame-home&#x27;, progress: 0 },
  { id: &#x27;demo&#x27;, label: &#x27;Demo&#x27;, el: &#x27;frame-workshop&#x27;, progress: 50 },
  { id: &#x27;sps&#x27;, label: &#x27;SPs&#x27;, el: &#x27;frame-sps&#x27;, progress: 100 },
];"""
    # also handle recorrido id leftover
    old_f2 = """const FRAMES = [
  { id: &#x27;demo&#x27;, label: &#x27;Demo&#x27;, el: &#x27;frame-home&#x27;, progress: 0 },
  { id: &#x27;recorrido&#x27;, label: &#x27;Recorrido&#x27;, el: &#x27;frame-workshop&#x27;, progress: 55 },
];"""
    if old_f in html:
        html = html.replace(old_f, new_f, 1)
        print("  FRAMES 3 tabs ok")
    elif old_f2 in html:
        html = html.replace(old_f2, new_f, 1)
        print("  FRAMES 3 tabs ok (from recorrido)")
    elif "label: &#x27;SPs&#x27;, el: &#x27;frame-sps&#x27;" in html.split("Mapa Ordenamiento")[-1][:2500]:
        print("  FRAMES already 3")
    else:
        # force replace last FRAMES block start
        idx = html.rfind("const FRAMES = [")
        if idx > 0:
            end = html.find("];", idx) + 2
            html = html[:idx] + new_f + html[end:]
            print("  FRAMES forced replace")
        else:
            print("  WARN FRAMES")

    # Titles
    reps = [
        (
            "Demo funcional — Ordenamiento",
            "Workshop — lenguaje funcional",
        ),
        (
            "Vista por fases: mapa Fase 0→1→2→3→4, casos y SPs mock.",
            "Historias de negocio: quién entra, cuál primero, Claro vs Movistar, orden en calle.",
        ),
        (
            "Workshop — por fases (1 Insumos · 2 canales · 3 Guardar · 4 Limpiar)",
            "Demo — recorrido por fases (mismos ejemplos, paso a paso)",
        ),
        (
            "Primero abrimos el bloque; aquí vemos la tabla del caso y el SP que lo hace; con eso ya nos aseguramos del resultado.",
            "Primero abrimos el caso; aquí vemos qué tiene la persona y por qué queda de primeras; con eso ya nos aseguramos del resultado.",
        ),
        (
            "Cómo va el Workshop",
            "Cómo va la Demo",
        ),
        (
            "Catálogo SP — una fase / un archivo",
            "SPs — detalle técnico por archivo",
        ),
        (
            "Demo funcional",
            "Workshop funcional",
        ),
    ]
    for a, b in reps:
        if a in html:
            html = html.replace(a, b, 1)

    # showFrame: workshop=home, demo=phases, sps=catalog
    old_show = """function showFrame(idx) {
  currentFrame = idx;
  const f = FRAMES[idx];
  document.getElementById(&#x27;progressBar&#x27;).style.width = f.progress + &#x27;%&#x27;;
  document.querySelectorAll(&#x27;.step-btn&#x27;).forEach((b,i) =&gt; b.classList.toggle(&#x27;active&#x27;, i===idx));
  if (f.id === &#x27;workshop&#x27;) {
    renderWsLanding();
    showWorkshopStep(workshopStep || 0);
    return;
  }
  document.querySelectorAll(&#x27;.frame&#x27;).forEach(fr =&gt; {
    const on = fr.id === f.el;
    fr.classList.toggle(&#x27;frame-on&#x27;, on);
    fr.classList.toggle(&#x27;frame-off&#x27;, !on);
  });
  // SPs integrados en Workshop
  requestAnimationFrame(() =&gt; requestAnimationFrame(fitRuleStage));
}"""
    new_show = """function showFrame(idx) {
  currentFrame = idx;
  const f = FRAMES[idx];
  document.getElementById(&#x27;progressBar&#x27;).style.width = f.progress + &#x27;%&#x27;;
  document.querySelectorAll(&#x27;.step-btn&#x27;).forEach((b,i) =&gt; b.classList.toggle(&#x27;active&#x27;, i===idx));
  if (f.id === &#x27;demo&#x27;) {
    renderWsLanding();
    showWorkshopStep(workshopStep || 0);
    return;
  }
  document.querySelectorAll(&#x27;.frame&#x27;).forEach(fr =&gt; {
    const on = fr.id === f.el;
    fr.classList.toggle(&#x27;frame-on&#x27;, on);
    fr.classList.toggle(&#x27;frame-off&#x27;, !on);
  });
  if (f.id === &#x27;sps&#x27;) showSpDetail(spPos, false);
  requestAnimationFrame(() =&gt; requestAnimationFrame(fitRuleStage));
}"""
    if old_show in html:
        html = html.replace(old_show, new_show, 1)
        print("  showFrame ok")
    else:
        print("  WARN showFrame")

    # step highlight for demo tab when inside phases
    html = html.replace(
        "FRAMES[i].id===&#x27;workshop&#x27;",
        "FRAMES[i].id===&#x27;demo&#x27;",
    )

    # Hide duplicate drill sections on home (alcance/fases/arch) — keep only workshop hero
    # already CSS hides non-demo-hero; ensure arquitectura+fases stay hidden
    # Change class: keep presentacion only

    # renderPresentacion
    pat = re.compile(r"function renderPresentacion\(\) \{\n.*?\n\}", re.S)
    ms = list(pat.finditer(html))
    if ms:
        m = ms[-1]
        html = html[: m.start()] + esc_js(RENDER_PRES) + html[m.end() :]
        print("  renderPresentacion ok")
    else:
        print("  WARN renderPresentacion")

    # Strip spsBlock from card return (keep variable empty-safe)
    html = html.replace(
        "${idBlock}${buscaBlock}${tblPasos}${tblEj}${devBlock}${spsBlock}${conclBlock}${accionBlock}",
        "${idBlock}${buscaBlock}${tblPasos}${tblEj}${devBlock}${conclBlock}${accionBlock}",
    )
    # rename sec-label Recorrido/Workshop in cards to Demo narrativa
    html = html.replace(
        "&lt;span class=&quot;sec-label&quot;&gt;Workshop&lt;/span&gt;",
        "&lt;span class=&quot;sec-label&quot;&gt;Qué vemos&lt;/span&gt;",
    )

    # CSS historias + sps visible
    if '"' in CSS_EXTRA:
        raise SystemExit("bad quotes")
    oi = html.find("Mapa Ordenamiento")
    se = html.find("&lt;/style&gt;", oi)
    marker = "/* Historias funcionales Workshop */"
    if se > 0:
        if marker in html[oi:se]:
            prev = html.rfind(marker, oi, se)
            html = html[:prev] + html[se:]
            se = html.find("&lt;/style&gt;", oi)
        html = html[:se] + CSS_EXTRA + html[se:]
        print("  CSS ok")

    # Landing copy in frame-workshop presentacion-block
    html = html.replace(
        "Primero abrimos el seed mock ya materializado",
        "Primero abrimos el caso de la persona",
        1,
    )
    return html


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    patch_data(data)
    html = html[:start] + to_html_json(data) + html[end:]
    html = patch_ui(html)
    path.write_text(html, encoding="utf-8")
    chunk = html[html.find("Mapa Ordenamiento") : html.find('"></iframe>', html.find("Mapa Ordenamiento"))]
    print(
        "OK",
        path.name,
        "Workshop tab",
        "label: &#x27;Workshop&#x27;, el: &#x27;frame-home&#x27;" in chunk,
        "SPs tab",
        "frame-sps" in chunk and "label: &#x27;SPs&#x27;" in chunk,
        "historia",
        "Historia 4" in unescape(chunk),
    )


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
