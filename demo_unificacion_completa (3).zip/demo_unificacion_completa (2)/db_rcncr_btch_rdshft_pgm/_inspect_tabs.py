# -*- coding: utf-8 -*-
import json, re, sys
from html import unescape
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
p = Path(
    r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
    r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
)
t = unescape(p.read_text(encoding="utf-8"))


def extract_obj(s, start):
    depth = 0
    in_q = False
    esc = False
    j = start
    while j < len(s):
        ch = s[j]
        if in_q:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_q = False
        else:
            if ch == '"':
                in_q = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return json.loads(s[start : j + 1])
        j += 1


d = extract_obj(t, list(re.finditer(r"const DATA = (\{)", t))[1].start(1))
print("FRAMES labels from html:")
print(re.findall(r"label: '([^']+)'", t.split("const FRAMES")[-1][:400]))
print("\npresentacion titles:")
for b in d.get("presentacion") or []:
    print("-", b.get("titulo"), b.get("layout"))
print("\narch keys", [k for k in d if "arch" in k.lower() or "fase" in k.lower()][:15])
