# -*- coding: utf-8 -*-
"""Conclusiones detalladas por SP (preguntas de persona normal)."""
from __future__ import annotations

import json
import re
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

# Conclusión larga por SP: responde qué es válido / no válido / 999 / por qué, etc.
SP_CONCL = {
    "SP-00": (
        "Pregunta normal: ¿dónde queda guardado el orden y el score? "
        "Se estableció que score, orden_prioridad y betas viven en tablas fijas de producto. "
        "Por ello, antes de puntuar, esas tablas ya existen: no se inventa el destino en cada corrida."
    ),
    "SP-01": (
        "Pregunta normal: ¿qué es el 999 del celular y por qué no ‘rompe’ el ranking? "
        "999 en el seed es un prefijo que no está en el catálogo de operadores (no es Claro/Movistar). "
        "Se estableció (CEL-02) que, si el prefijo no mapea, se usa el default 0.22 del catálogo — no un error. "
        "Por ello ese celular queda con score 220 (100×0.22) y puede competir; no cae a 0. "
        "¿Qué es válido aquí? Tener un peso (catálogo o default). ¿Qué no es válido? Tratar el prefijo desconocido como fallo."
    ),
    "SP-02": (
        "Pregunta normal: ¿este dato es casa, fijo, celular o email? "
        "Se estableció el mapa contactType XPM → canal: 1/2/3/7/8=DIR, 4/5/8=TEL, 9=CEL, 10=EMA. "
        "Por ello cada contacto entra solo a su ranking y no se mezcla (un fijo no compite con un email). "
        "¿Qué es válido? Type con canal claro (y email con @). ¿Qué no es válido? Email sin @ o type fuera de mapa."
    ),
    "SP-03": (
        "Pregunta normal: ¿esta dirección todavía ‘cuenta’ para llamar? "
        "Se estableció (F3-02 / post-unificación) que solo ganadoras compiten; hija (ind_unificacion=1) no. "
        "Por ello el padre recibe score/orden y la hija no aparece: no es contacto vigente. "
        "¿Qué es válido? RPU ganadora. ¿Qué no es válido? Usar la hija como si fuera la dirección a intentar."
    ),
    "SP-04": (
        "Pregunta normal: ¿quién entra hoy a puntuar y quién se queda fuera? "
        "Se estableció armar el insumo por canal solo con ganadoras + contactType válido; email sin @ fuera; "
        "TEL/CEL/EMA requieren al menos una DIR ganadora. "
        "Por ello el scoring recibe una lista limpia: lo no elegible no compite. "
        "¿Qué es válido? Contacto elegible en su canal. ¿Qué no es válido? Hija, email sin @, o canal sin DIR ganadora."
    ),
    "SP-05": (
        "Pregunta normal: ¿llamo primero a la casa o a la oficina? "
        "Se estableció que en DIR gana el mayor score (categoría/máximo × beta del catálogo RITM) → lugar 1. "
        "Por ello, en el ejemplo 20001, casa (850) quedó de primeras y oficina (700) de segundas. "
        "¿Qué es válido? Direcciones ganadoras que compiten entre sí. ¿Qué no es válido? Meter una hija al ranking o mezclar con TEL/CEL/EMA. "
        "Si empatan en score, no hay desempate de negocio nuevo: solo orden técnico."
    ),
    "SP-06": (
        "Pregunta normal: ¿cuál fijo intento primero, y qué pasa si uno ‘está malo’? "
        "Se estableció que TEL es independiente de DIR y que un fijo válido tiene prioridad frente a uno no válido. "
        "Por ello en 20004 el válido (420) queda de primeras y el no válido (210) de segundas. "
        "Además TEL020 (geo) puede calcularse para trazabilidad pero no suma (TEL-02): por ello en 20013 ambos scores quedan iguales. "
        "¿Qué es válido? Fijo usable del canal TEL. ¿Qué no es válido? Tratar TEL020 como si moviera el ranking, o mezclar TEL con DIR."
    ),
    "SP-07": (
        "Pregunta normal: ¿qué es el 999 y por qué el score da 220? "
        "999 = primeros 3 dígitos del celular cuando ese prefijo no está en el catálogo de operadores. "
        "Se estableció (CEL-02) el default 0.22 → aporte 100×0.22 = 22 en la métrica de operador → score 220 en el seed. "
        "Por ello ese celular no queda en cero: entra al ranking CEL con lugar 1 en el ejemplo 20012. "
        "¿Qué es válido? Prefijo en catálogo (ej. 310) o default 0.22. ¿Qué no es válido? Asumir que ‘sin operador’ = inválido o score 0."
    ),
    "SP-08": (
        "Pregunta normal: ¿si cambio variables ‘raras’ del email, cambia quién va primero? "
        "Se estableció (EMA-03) que EMA003/007/018/025 pueden calcularse para trazabilidad pero no entran a la sumatoria. "
        "Por ello en 20014 el email base y el que solo cambia esas variables quedan con el mismo score: el orden no se mueve. "
        "¿Qué es válido? Variables que sí suman al score EMA. ¿Qué no es válido? Esperar que las excluidas cambien el ranking."
    ),
    "SP-09": (
        "Pregunta normal: ¿qué se guarda al final para ‘llamar en calle’? "
        "Se estableció que solo DIR escribe orden_prioridad (= lugar DIR de cada RPU ganadora). "
        "Por ello el lugar 1 de dirección queda de primeras en el orden de intento; hijas no reciben fila. "
        "¿Qué es válido? Persistir orden de ganadoras. ¿Qué no es válido? Esperar que TEL/CEL/EMA escriban orden_prioridad en el RPU."
    ),
    "SP-10": (
        "Pregunta normal: ¿después de la corrida queda basura temporal? "
        "Se estableció limpiar staging (DROP stg_*) al cerrar; la salida de negocio se conserva. "
        "Por ello la siguiente corrida parte limpia y orden_prioridad sigue disponible. "
        "¿Qué es válido? Borrar stg_*. ¿Qué no es válido? Borrar también rpu_orden_prioridad / scores de producto."
    ),
    "SP-11": (
        "Pregunta normal: ¿en qué orden debo correr todo para que tenga sentido? "
        "Se estableció el pipeline: preparar → DIR → TEL → CEL → EMA → consolidar → drop. "
        "Por ello no se puntúa sin insumo ni se deja staging huérfano. "
        "¿Qué es válido? Un CALL orquestado (TRUE). ¿Qué no es válido? Correr scoring suelto antes de preparar o saltarse la limpieza."
    ),
    "SP-12": (
        "Pregunta normal: ¿qué dispara operaciones / Control-M? "
        "Se estableció un runbook en _dt con el CALL al orquestador, separado de la lógica en _pgm. "
        "Por ello el job apunta a un script estable tras unificación OK. "
        "¿Qué es válido? Ejecutar el run cuando unificacion_direccion ya está poblada. ¿Qué no es válido? Disparar ordenamiento sin esa precondición."
    ),
    "SP-13": (
        "Pregunta normal: ¿cómo sé que la corrida real quedó bien? "
        "Se estableció el gate: 0 hijas con orden incorrecto y volúmenes de score coherentes. "
        "Por ello la aceptación mira conteos reales, no el seed mock. "
        "¿Qué es válido? Gate en 0 hijas mal ordenadas. ¿Qué no es válido? Dar por cerrada una corrida con hijas puntuadas."
    ),
    "SP-M01": (
        "Pregunta normal: ¿de dónde salen los ejemplos 20001–20014 de la Demo? "
        "Se estableció un seed mock alineado al HTML (casa/oficina, hija, 999, TEL020, etc.). "
        "Por ello lo que se ve en Workshop es lo mismo que debe devolver la consulta. "
        "¿Qué es válido? Usar el seed para explicar reglas. ¿Qué no es válido? Mezclar seed mock con gates de la corrida EDF real."
    ),
    "SP-M02": (
        "Pregunta normal: ¿estos ejemplos cumplen los criterios de aceptación mock? "
        "Se estableció validar CA-O01…CA-O12 sobre el seed (válido vs no válido, TEL020, default 0.22, etc.). "
        "Por ello cada caso de la Demo tiene un PASSED/FAILED verificable. "
        "¿Qué es válido? Criterio PASSED en el seed. ¿Qué no es válido? Dar por bueno un caso FAILED o inventar números fuera del seed."
    ),
    "SP-M03": (
        "Pregunta normal: ¿cómo dejo lista la Demo en un solo paso? "
        "Se estableció un orquestador mock: cargar seed + validar criterios. "
        "Por ello un CALL prepara el ambiente y las queries del Workshop cuadran. "
        "¿Qué es válido? CALL ejecucion_mock antes de la mesa. ¿Qué no es válido? Explicar casos sin haber materializado el seed."
    ),
}

# También enriquecer por_que corto (para STAR) apuntando a la conclusión
SP_POR_QUE = {sid: ("Ver conclusión detallada: responde qué es válido / no válido y por qué ese orden.") for sid in SP_CONCL}


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def esc_js(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#x27;")
    )


def patch_data(data: dict) -> None:
    sps = data.get("sps_detalle") or []
    by_id = {}
    for sp in sps:
        sid = sp.get("id")
        if sid in SP_CONCL:
            sp["conclusion"] = SP_CONCL[sid]
            # resultado = cierre corto; por_que = ancla; explicacion = full
            sp["resultado"] = SP_CONCL[sid]
            sp["por_que"] = SP_CONCL[sid]
            sp["explicacion"] = (
                f"Pregunta: {sp.get('pregunta') or ''}. "
                f"Objetivo: {sp.get('objetivo') or ''}. "
                f"Conclusión: {SP_CONCL[sid]}"
            )
            by_id[sid] = sp
    data["sps_detalle"] = sps

    # refrescar inline sps en rows
    for row in data.get("rows") or []:
        linked = row.get("_sps_relacionados") or []
        if not linked:
            continue
        new_linked = []
        for item in linked:
            sid = item.get("id")
            sp = by_id.get(sid)
            if not sp:
                new_linked.append(item)
                continue
            new_linked.append(
                {
                    "id": sid,
                    "archivo": sp.get("archivo"),
                    "objetivo": sp.get("objetivo") or sp.get("pregunta") or sp.get("rol"),
                    "accion": sp.get("accion") or sp.get("logica"),
                    "resultado": sp.get("resultado") or sp.get("ejemplo"),
                    "por_que": sp.get("por_que") or "",
                    "conclusion": sp.get("conclusion") or sp.get("por_que") or "",
                }
            )
        row["_sps_relacionados"] = new_linked
    print(f"  SPs with conclusion: {len(by_id)}")


RENDER_SP_PATCH_NEEDLE = "&lt;div class=&quot;star-box porque&quot;&gt;&lt;b&gt;Por qué ese resultado&lt;/b&gt;${esc(sp.por_que || &#x27;&#x27;)}&lt;/div&gt;"
RENDER_SP_PATCH_ADD = """&lt;div class=&quot;star-box porque&quot;&gt;&lt;b&gt;Por qué ese resultado&lt;/b&gt;${esc(sp.por_que || &#x27;&#x27;)}&lt;/div&gt;
    &lt;/div&gt;` : &#x27;&#x27;;
  const conclSp = (sp.conclusion || sp.resultado)
    ? `&lt;div class=&quot;scenario-section conclusion-box&quot;&gt;&lt;span class=&quot;sec-label&quot;&gt;Conclusión (preguntas de negocio)&lt;/span&gt;&lt;p&gt;${esc(sp.conclusion || sp.resultado)}&lt;/p&gt;&lt;/div&gt;`
    : &#x27;&#x27;;
  const _starEnd = true; const star = (sp.objetivo || sp.situacion) ? `
    &lt;div class=&quot;star-grid&quot;&gt;
      &lt;div class=&quot;star-box&quot;&gt;&lt;b&gt;Situación&lt;/b&gt;${esc(sp.situacion || &#x27;&#x27;)}&lt;/div&gt;
      &lt;div class=&quot;star-box&quot;&gt;&lt;b&gt;Objetivo (Tarea)&lt;/b&gt;${esc(sp.objetivo || sp.pregunta || &#x27;&#x27;)}&lt;/div&gt;
      &lt;div class=&quot;star-box&quot;&gt;&lt;b&gt;Acción&lt;/b&gt;${esc(sp.accion || sp.logica || &#x27;&#x27;)}&lt;/div&gt;
      &lt;div class=&quot;star-box&quot;&gt;&lt;b&gt;Ejemplo&lt;/b&gt;${esc(sp.ejemplo || &#x27;&#x27;)}&lt;/div&gt;
      &lt;div class=&quot;star-box resultado&quot;&gt;&lt;b&gt;Resultado&lt;/b&gt;${esc(sp.resultado || &#x27;&#x27;)}&lt;/div&gt;
      &lt;div class=&quot;star-box porque&quot;&gt;&lt;b&gt;Por qué ese resultado&lt;/b&gt;${esc(sp.por_que || &#x27;&#x27;)}&lt;/div&gt;"""


def patch_render_sp(html: str) -> str:
    """Insert conclusion block after STAR in last renderSpCard (ord)."""
    # Simpler approach: after ${star} in return template of last renderSpCard
    needle = "${pregunta}\n      ${star}\n      &lt;dl&gt;"
    repl = "${pregunta}\n      ${star}\n      ${sp.conclusion ? `&lt;div class=&quot;scenario-section conclusion-box&quot;&gt;&lt;span class=&quot;sec-label&quot;&gt;Conclusión (preguntas de negocio)&lt;/span&gt;&lt;p&gt;${esc(sp.conclusion)}&lt;/p&gt;&lt;/div&gt;` : &#x27;&#x27;}\n      &lt;dl&gt;"
    idx = html.rfind(needle)
    if idx > 0:
        html = html[:idx] + repl + html[idx + len(needle) :]
        print("  renderSpCard conclusion ok")
    else:
        # try alternate spacing
        needle2 = "${pregunta}\n      ${star}\n"
        idx2 = html.rfind(needle2)
        if idx2 > 0 and "Conclusión (preguntas de negocio)" not in html[idx2 : idx2 + 400]:
            insert = (
                "${pregunta}\n      ${star}\n"
                "      ${sp.conclusion ? `&lt;div class=&quot;scenario-section conclusion-box&quot;&gt;"
                "&lt;span class=&quot;sec-label&quot;&gt;Conclusión (preguntas de negocio)&lt;/span&gt;"
                "&lt;p&gt;${esc(sp.conclusion)}&lt;/p&gt;&lt;/div&gt;` : &#x27;&#x27;}\n"
            )
            html = html[:idx2] + insert + html[idx2 + len(needle2) :]
            print("  renderSpCard conclusion ok (alt)")
        else:
            print("  WARN renderSpCard")

    # inline SP cards: show conclusion instead of short por_que when present
    old_inline = "${s.por_que ? `&lt;p class=&quot;porque&quot;&gt;&lt;b&gt;Por qué&lt;/b&gt; ${esc(s.por_que)}&lt;/p&gt;` : &#x27;&#x27;}"
    new_inline = (
        "${(s.conclusion || s.por_que) ? `&lt;p class=&quot;porque&quot;&gt;&lt;b&gt;Conclusión&lt;/b&gt; "
        "${esc(s.conclusion || s.por_que)}&lt;/p&gt;` : &#x27;&#x27;}"
    )
    if old_inline in html:
        html = html.replace(old_inline, new_inline)
        print("  inline SP conclusion ok")
    return html


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    patch_data(data)
    html = html[:start] + to_html_json(data) + html[end:]
    html = patch_render_sp(html)
    path.write_text(html, encoding="utf-8")
    sp7 = next(s for s in data["sps_detalle"] if s["id"] == "SP-07")
    print("OK", path.name)
    print("  SP-07 concl:", sp7["conclusion"][:140], "...")


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
