# -*- coding: utf-8 -*-
"""Define claramente 'dirección ganadora' y 'necesita dirección ganadora'."""
from __future__ import annotations

import json
import re
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

DEF_GANADORA = (
    "Dirección ganadora = la dirección vigente de la persona después de unificar. "
    "Es la que sí usamos para contactar (casa, oficina, etc.). "
    "La hija es la que ya quedó absorbida: no es vigente."
)

DEF_NECESITA = (
    "«Necesita dirección ganadora» (fijo o celular) significa: "
    "ese teléfono solo entra a ordenar si la persona ya tiene al menos una dirección vigente. "
    "Si la persona no tiene dirección ganadora (solo hijas o ninguna), "
    "el fijo/celular no se puntúa ni se intenta: falta el ancla de domicilio."
)

GLOSSARY_OLD = (
    "&lt;div class=&quot;glossary-card&quot;&gt;&lt;h4&gt;Ganadora&lt;/h4&gt;"
    "&lt;p&gt;RPU con ind_unificacion ≠ 1. Las &lt;strong&gt;${fmt(k.rpu_hijas)}&lt;/strong&gt; "
    "hijas no compiten (mesa: unificación alimenta DIR).&lt;/p&gt;&lt;/div&gt;"
)

GLOSSARY_NEW = (
    "&lt;div class=&quot;glossary-card&quot;&gt;&lt;h4&gt;Dirección ganadora&lt;/h4&gt;"
    "&lt;p&gt;La dirección &lt;strong&gt;vigente&lt;/strong&gt; tras unificar "
    "(la que sí usamos para contactar). Las hijas ya quedaron absorbidas: no son vigentes. "
    "Hay ${fmt(k.rpu_hijas)} hijas fuera.&lt;/p&gt;&lt;/div&gt;"
    "&lt;div class=&quot;glossary-card&quot;&gt;&lt;h4&gt;«Necesita dirección ganadora»&lt;/h4&gt;"
    "&lt;p&gt;Regla de fijo/celular: el teléfono &lt;strong&gt;solo entra&lt;/strong&gt; "
    "si esa persona ya tiene al menos una dirección vigente. "
    "Sin domicilio ancla, no se ordena ni se intenta ese TEL/CEL.&lt;/p&gt;&lt;/div&gt;"
)


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def patch_data(data: dict) -> None:
    for b in data.get("presentacion") or []:
        titulo = (b.get("titulo") or "").lower()
        if "teléfonos" in titulo or "telefonos" in titulo or "quién entra" in titulo:
            b["lead"] = (
                "Qué significa «necesita dirección ganadora» y quién sí entra."
            )
            b["bullets"] = [
                DEF_GANADORA,
                DEF_NECESITA,
                "Sí entra a DIR: dirección ganadora (casa/oficina/correspondencia según tipo).",
                "Sí entra a TEL/CEL: solo si la persona ya tiene ≥1 dirección ganadora.",
                "No entra: hija unificada; email sin @; TEL/CEL de persona sin dirección vigente.",
            ]
            if isinstance(b.get("tabla"), list) and b["tabla"]:
                # keep header, replace body examples
                hdr = b["tabla"][0] if b["tabla"] else ["Caso", "¿Entra?", "Por qué"]
                b["tabla"] = [
                    hdr if isinstance(hdr, list) else ["Caso", "¿Entra?", "Por qué"],
                    [
                        "Casa ganadora",
                        "Sí",
                        "Es dirección vigente → canal DIR",
                    ],
                    [
                        "Fijo de persona con casa ganadora",
                        "Sí",
                        "Tiene ancla de domicilio → TEL elegible",
                    ],
                    [
                        "Celular de persona solo con hija",
                        "No",
                        "No hay dirección ganadora → no ordenamos CEL",
                    ],
                    [
                        "Fijo de persona sin ninguna dirección vigente",
                        "No",
                        "«Necesita dirección ganadora» = falta el ancla",
                    ],
                ]
            print("  presentacion historia elegibilidad ok")

        if "hija" in titulo and "vigente" in titulo:
            pasos = b.get("pasos") or []
            # clarify ganadora in pasos if present
            for p in pasos:
                if isinstance(p, dict) and "padre" in str(p).lower():
                    p["hecho"] = (
                        "El padre es la dirección ganadora = vigente (la que sí contactamos)."
                    )

    # Row texts that mention the rule
    for row in data.get("rows") or []:
        pack = row.get("_pack_code")
        if pack in ("TEL-RANK", "TEL-02", "CEL-02", "INSUMO-CT", "RPU-STG", "ELEG-BLOQ"):
            # strengthen conclusion / busca with clear definition
            if pack == "RPU-STG":
                row["_busca"] = (
                    "¿Esta dirección es vigente (ganadora) o ya quedó absorbida (hija)? "
                    "Solo las vigentes entran a ordenar. "
                    + DEF_GANADORA
                )
                row["_conclusion"] = (
                    "Se estableció: dirección ganadora = domicilio vigente tras unificar. "
                    "Las hijas no son contacto a usar; no reciben score ni orden."
                )
            if pack in ("TEL-RANK", "TEL-02", "CEL-02", "ELEG-BLOQ"):
                prev = row.get("_conclusion") or ""
                if "Necesita dirección ganadora" not in prev and "ancla" not in prev.lower():
                    row["_conclusion"] = (
                        DEF_NECESITA + " " + prev
                    ).strip()
                busca = row.get("_busca") or ""
                if "dirección ganadora" not in busca.lower():
                    row["_busca"] = (busca + " " + DEF_NECESITA).strip()

        # strip technical ind_unificacion from visible if still in _dev for stakeholders - keep technical in SPs
        for k in ("_dev", "_conclusion", "_busca"):
            v = row.get(k)
            if isinstance(v, str) and "ind_unificacion" in v:
                row[k] = v.replace(
                    "ind_unificacion distinto de 1",
                    "no marcada como hija",
                ).replace(
                    "ind_unificacion ≠ 1",
                    "no marcada como hija",
                ).replace(
                    "ind_unificacion != 1",
                    "no marcada como hija",
                )


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    patch_data(data)
    html = html[:start] + to_html_json(data) + html[end:]

    if GLOSSARY_OLD in html:
        html = html.replace(GLOSSARY_OLD, GLOSSARY_NEW, 1)
        print("  glossary ok")
    elif "«Necesita dirección ganadora»" in html:
        print("  glossary already has definition")
    else:
        # softer match
        m = re.search(
            r"&lt;div class=&quot;glossary-card&quot;&gt;&lt;h4&gt;Ganadora&lt;/h4&gt;"
            r".*?&lt;/div&gt;",
            html,
        )
        if m:
            html = html[: m.start()] + GLOSSARY_NEW + html[m.end() :]
            print("  glossary regex ok")
        else:
            print("  WARN glossary not found")

    path.write_text(html, encoding="utf-8")
    print("OK", path.name)


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
