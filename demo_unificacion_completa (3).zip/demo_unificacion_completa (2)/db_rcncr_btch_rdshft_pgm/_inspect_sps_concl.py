# -*- coding: utf-8 -*-
import json, re, sys
from html import unescape
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
p = Path(
    r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
    r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
)
t = unescape(p.read_text(encoding="utf-8"))


def extract_obj(s, start):
    depth = 0
    in_q = False
    esc = False
    j = start
    while j < len(s):
        ch = s[j]
        if in_q:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_q = False
        else:
            if ch == '"':
                in_q = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return json.loads(s[start : j + 1])
        j += 1


d = extract_obj(t, list(re.finditer(r"const DATA = (\{)", t))[1].start(1))
print("=== sps_detalle fields ===")
for s in d.get("sps_detalle") or []:
    print("\n##", s.get("id"), s.get("archivo"))
    for k in ("fase", "pregunta", "objetivo", "accion", "resultado", "por_que", "ejemplo", "explicacion", "rol", "logica"):
        if s.get(k):
            v = str(s[k])
            print(f"  {k}: {v[:200]}")

print("\n=== inline sps sample from rows ===")
for r in d.get("rows") or []:
    sps = r.get("_sps_relacionados") or []
    if sps:
        print(r.get("_pack_code"), [x.get("id") for x in sps])
        print("  sample por_que:", (sps[0].get("por_que") or "")[:120])
