-- Orquestador ordenamiento EDF — staging temporal + scoring + limpieza
CREATE OR REPLACE PROCEDURE bdm_datos.sp_ordenamiento_ejecucion_edf(
  p_preparar_insumos BOOLEAN
)
LANGUAGE plpgsql
AS $$
BEGIN
  IF COALESCE(p_preparar_insumos, TRUE) THEN
    CALL bdm_datos.sp_ordenamiento_preparar_insumos_edf();
  END IF;

  CALL bdm_datos.sp_ordenamiento_scoring_dir_edf();
  CALL bdm_datos.sp_ordenamiento_scoring_tel_edf();
  CALL bdm_datos.sp_ordenamiento_scoring_cel_edf();
  CALL bdm_datos.sp_ordenamiento_scoring_ema_edf();
  CALL bdm_datos.sp_ordenamiento_consolidacion_edf();
  CALL bdm_datos.sp_ordenamiento_drop_staging_edf();
END;
$$;
