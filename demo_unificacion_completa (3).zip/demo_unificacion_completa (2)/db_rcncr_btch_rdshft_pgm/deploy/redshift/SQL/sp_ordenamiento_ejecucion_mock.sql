-- ============================================================
-- sp_ordenamiento_ejecucion_mock.sql
-- Orquestador Modo B MOCK (no llama SPs _edf)
-- ============================================================

CREATE OR REPLACE PROCEDURE bdm_stage.sp_ordenamiento_ejecucion_mock()
LANGUAGE plpgsql
AS $$
BEGIN
  CALL bdm_stage.sp_ordenamiento_cargar_seed_mock();
  CALL bdm_stage.sp_ordenamiento_validar_mock();
END;
$$;
