-- Orquestador Regla 1
-- Escenario: CALL escenarios R1 en orden
-- Fuente: edf_views → bdm_tempo.v_xpm_* | Salida: bdm_datos.unificacion_direccion
-- Generado: tools/gen_unificacion_sps_por_escenario.py

CREATE OR REPLACE PROCEDURE bdm_datos.sp_unificacion_regla1()
LANGUAGE plpgsql
AS $$
BEGIN

  CALL bdm_datos.sp_unificacion_r1_preparar_insumo();
  CALL bdm_datos.sp_unificacion_r1_esc1_ciiu10();
  CALL bdm_datos.sp_unificacion_r1_esc2_ciiu81_90();
  CALL bdm_datos.sp_unificacion_r1_esc3_otros_ciiu();
  DROP TABLE IF EXISTS bdm_tempo.stg_regla1_insumo;

END;
$$;
