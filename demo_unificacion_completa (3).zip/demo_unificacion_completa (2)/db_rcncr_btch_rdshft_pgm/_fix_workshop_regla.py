# -*- coding: utf-8 -*-
"""
1) Restaura RULE_FRAMES.regla a las claves de DATA.rows (_regla).
2) Quita de Demo los casos EMA 20014 y Salida 20001.
"""
from __future__ import annotations

import json
import re
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

OLD_RF = """const RULE_FRAMES = [
  null,
  { regla: &#x27;FASE 1 · Insumos&#x27;, nav: &#x27;nav-fase1&#x27;, stage: &#x27;stage-fase1&#x27; },
  { regla: &#x27;FASE 2 · DIR&#x27;, nav: &#x27;nav-dir&#x27;, stage: &#x27;stage-dir&#x27; },
  { regla: &#x27;FASE 2 · TEL&#x27;, nav: &#x27;nav-tel&#x27;, stage: &#x27;stage-tel&#x27; },
  { regla: &#x27;FASE 2 · CEL&#x27;, nav: &#x27;nav-cel&#x27;, stage: &#x27;stage-cel&#x27; },
  { regla: &#x27;FASE 2 · EMA&#x27;, nav: &#x27;nav-ema&#x27;, stage: &#x27;stage-ema&#x27; },
  { regla: &#x27;FASE 3–4 · Salida&#x27;, nav: &#x27;nav-salida&#x27;, stage: &#x27;stage-salida&#x27; },
];"""

NEW_RF = """const RULE_FRAMES = [
  null,
  { regla: &#x27;FASE 1&#x27;, nav: &#x27;nav-fase1&#x27;, stage: &#x27;stage-fase1&#x27; },
  { regla: &#x27;CANAL DIR&#x27;, nav: &#x27;nav-dir&#x27;, stage: &#x27;stage-dir&#x27; },
  { regla: &#x27;CANAL TEL&#x27;, nav: &#x27;nav-tel&#x27;, stage: &#x27;stage-tel&#x27; },
  { regla: &#x27;CANAL CEL&#x27;, nav: &#x27;nav-cel&#x27;, stage: &#x27;stage-cel&#x27; },
  { regla: &#x27;CANAL EMA&#x27;, nav: &#x27;nav-ema&#x27;, stage: &#x27;stage-ema&#x27; },
  { regla: &#x27;CONSOLIDACIÓN&#x27;, nav: &#x27;nav-salida&#x27;, stage: &#x27;stage-salida&#x27; },
];"""

DROP_Q = ("variables excluidas", "orden de intento en calle")
DROP_PAIR = {("20014", "EMA"), ("20001", "Salida"), ("20001", "SALIDA")}


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def should_drop(c: dict) -> bool:
    cid = str(c.get("id") or "")
    canal = str(c.get("canal") or "")
    if (cid, canal) in DROP_PAIR:
        return True
    q = (c.get("pregunta") or "").lower()
    return any(x in q for x in DROP_Q)


def patch_data(data: dict) -> None:
    pres = data.get("presentacion") or []
    kept = []
    removed = 0
    for b in pres:
        if isinstance(b.get("casos"), list):
            before = len(b["casos"])
            b["casos"] = [c for c in b["casos"] if not should_drop(c)]
            removed += before - len(b["casos"])
            if b.get("layout") == "fase_casos" and not b["casos"]:
                continue
        # también quitar Fase 3–4 del mapa si no hay casos de salida
        if b.get("layout") == "fase_mapa" and isinstance(b.get("fases"), list):
            b["fases"] = [f for f in b["fases"] if str(f.get("fase")) not in ("3–4", "3-4")]
        kept.append(b)
    data["presentacion"] = kept
    print(f"  demo casos removed ~{removed}")


def patch_show_workshop(html: str) -> str:
    """Al abrir Workshop, entrar directo a Fase 1 (con contenido), no solo landing vacía."""
    old = """  if (f.id === &#x27;workshop&#x27;) {
    // landing first time; if already in a step keep it
    document.querySelectorAll(&#x27;.frame&#x27;).forEach(fr =&gt; {
      const on = fr.id === &#x27;frame-workshop&#x27;;
      fr.classList.toggle(&#x27;frame-on&#x27;, on);
      fr.classList.toggle(&#x27;frame-off&#x27;, !on);
    });
    renderWsLanding();
    return;
  }"""
    new = """  if (f.id === &#x27;workshop&#x27;) {
    renderWsLanding();
    showWorkshopStep(workshopStep || 0);
    return;
  }"""
    if old in html:
        html = html.replace(old, new, 1)
        print("  showFrame workshop -> Fase 1 ok")
    elif "showWorkshopStep(workshopStep" in html:
        print("  showFrame already jumps to step")
    else:
        print("  WARN showFrame workshop block")
    return html


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    # RULE_FRAMES (último = ord)
    if OLD_RF in html:
        idx = html.rfind(OLD_RF)
        html = html[:idx] + NEW_RF + html[idx + len(OLD_RF) :]
        print("  RULE_FRAMES restored to row keys")
    elif "regla: &#x27;CANAL DIR&#x27;" in html.split("Mapa Ordenamiento")[-1]:
        print("  RULE_FRAMES already matched")
    else:
        print("  WARN RULE_FRAMES")

    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    patch_data(data)
    html = html[:start] + to_html_json(data) + html[end:]
    html = patch_show_workshop(html)
    path.write_text(html, encoding="utf-8")

    # verify
    t = unescape(path.read_text(encoding="utf-8"))
    last_rf = t.split("const RULE_FRAMES")[-1][:600]
    print("  reglas:", re.findall(r"regla: '([^']+)'", last_rf))
    print("OK", path.name)


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
