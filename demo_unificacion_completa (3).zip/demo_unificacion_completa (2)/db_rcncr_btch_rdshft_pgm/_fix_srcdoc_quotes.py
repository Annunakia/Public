# -*- coding: utf-8 -*-
"""Arregla CSS del iframe: comillas dobles rompían el atributo srcdoc."""
from __future__ import annotations

from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

MARKER = "/* === Demo visual (iframe Ordenamiento) === */"

# CSS sin comillas dobles (srcdoc="..." las interpreta como fin de atributo)
CSS_SAFE = r"""
/* === Demo visual (iframe Ordenamiento) === */
.presentacion-wrap {
  display: flex; flex-direction: column; gap: 1.1rem;
  margin: 0.5rem 0 1.25rem; max-width: 920px;
}
.demo-section {
  background: #fff;
  border: 1px solid #d5dde6;
  border-radius: 14px;
  padding: 1rem 1.15rem 1.1rem;
  box-shadow: 0 4px 18px rgba(26,35,50,.06);
}
.demo-section h4 {
  margin: 0 0 0.35rem;
  font-size: 1.02rem;
  font-weight: 800;
  color: #0f172a;
  letter-spacing: -0.01em;
}
.demo-lead {
  margin: 0 0 0.7rem;
  font-size: 0.88rem;
  color: #64748b;
  line-height: 1.45;
  max-width: 62ch;
}
.demo-chips {
  list-style: none; margin: 0; padding: 0;
  display: flex; flex-direction: column; gap: 0.4rem;
}
.demo-chips li {
  position: relative;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  padding: 0.5rem 0.75rem 0.5rem 2rem;
  font-size: 0.84rem;
  color: #1e293b;
  line-height: 1.4;
}
.demo-chips li::before {
  content: '';
  position: absolute; left: 0.75rem; top: 0.72rem;
  width: 0.45rem; height: 0.45rem; border-radius: 50%;
  background: #1d6fdc;
}
.demo-casos {
  display: flex; flex-direction: column; gap: 0.85rem; margin-top: 0.25rem;
}
.demo-caso {
  border: 1px solid #93c5fd;
  background: linear-gradient(180deg, #eff6ff 0%, #ffffff 42%);
  border-radius: 14px;
  padding: 0.85rem 1rem;
  display: flex; flex-direction: column; gap: 0.55rem;
  box-shadow: 0 2px 10px rgba(29,111,220,.08);
}
.demo-caso header {
  display: flex; gap: 0.45rem; align-items: center; flex-wrap: wrap;
}
.demo-id {
  font-family: Consolas, ui-monospace, monospace;
  font-size: 0.78rem; font-weight: 800;
  color: #1e3a8a; background: #dbeafe;
  padding: 0.18rem 0.55rem; border-radius: 999px;
  border: 1px solid #bfdbfe;
}
.demo-canal {
  font-size: 0.68rem; font-weight: 800;
  letter-spacing: 0.06em; text-transform: uppercase;
  color: #fff; background: #1d6fdc;
  padding: 0.16rem 0.5rem; border-radius: 999px;
}
.demo-q {
  margin: 0;
  font-size: 0.92rem; font-weight: 750; color: #0f172a; line-height: 1.35;
  background: #fff7ed; border: 1px solid #fdba74;
  border-radius: 10px; padding: 0.55rem 0.7rem;
}
.demo-tabla-wrap {
  overflow: auto;
  border: 1px solid #cbd5e1;
  border-radius: 10px;
  background: #fff;
}
.demo-tabla {
  width: 100%; border-collapse: collapse; font-size: 0.8rem;
}
.demo-tabla th {
  background: #1e3a8a; color: #fff; font-weight: 700;
  text-align: left; padding: 0.45rem 0.6rem;
  white-space: nowrap; border-bottom: 0;
}
.demo-tabla td {
  padding: 0.42rem 0.6rem;
  border-bottom: 1px solid #e2e8f0;
  color: #0f172a;
  font-variant-numeric: tabular-nums;
}
.demo-tabla tbody tr:nth-child(even) td { background: #f8fafc; }
.demo-tabla tbody tr:last-child td { border-bottom: 0; }
.demo-r {
  margin: 0;
  font-size: 0.82rem; font-weight: 600; color: #14532d;
  background: #f0fdf4; border: 1px solid #86efac;
  border-radius: 10px; padding: 0.5rem 0.7rem; line-height: 1.4;
}
#frame-home .demo-hero {
  background: transparent; border: 0; box-shadow: none; padding: 0.15rem 0 0.5rem;
}
#frame-home .demo-hero .drill-section-title {
  font-size: 1.15rem; font-weight: 800; color: #0f172a; margin-bottom: 0.15rem;
}
#frame-home .demo-hero .drill-section-note {
  color: #64748b; margin-bottom: 0.35rem;
}
.sp-inline-grid { display: grid; grid-template-columns: 1fr; gap: 0.5rem; margin-top: 0.35rem; }
.sp-inline-card {
  border: 1px solid #c7d2fe; background: #f5f3ff; border-radius: 10px;
  padding: 0.55rem 0.7rem; font-size: 0.78rem; line-height: 1.4; color: #312e81;
}
.sp-inline-card header { display: flex; gap: 0.5rem; flex-wrap: wrap; margin-bottom: 0.3rem; align-items: baseline; }
.sp-inline-card header code { font-weight: 700; color: #1e3a8a; }
.sp-inline-card header span { color: #64748b; font-size: 0.72rem; }
.sp-inline-card p { margin: 0.15rem 0; }
.sp-inline-card b { color: #0f172a; }
.sp-inline-card .porque { color: #1e40af; }
#frame-sps { display: none !important; }
"""


def patch(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    oi = html.find("Mapa Ordenamiento")
    if oi < 0:
        print("FAIL no ord", path)
        return
    style_end = html.find("&lt;/style&gt;", oi)
    if style_end < 0:
        print("FAIL no style end", path)
        return

    if MARKER in html[oi:style_end]:
        prev = html.rfind(MARKER, oi, style_end)
        html = html[:prev] + html[style_end:]
        style_end = html.find("&lt;/style&gt;", oi)
        print("  removed broken CSS block")

    # sanity: CSS_SAFE must not contain raw "
    if '"' in CSS_SAFE:
        raise SystemExit("CSS_SAFE still has double quotes")

    html = html[:style_end] + CSS_SAFE + html[style_end:]
    path.write_text(html, encoding="utf-8")

    # verify srcdoc closes properly: after ord iframe start, find "></iframe>
    t = path.read_text(encoding="utf-8")
    a = t.find('iframe title="Mapa Ordenamiento"')
    # from srcdoc=" to closing
    sd = t.find('srcdoc="', a)
    # walk until "></iframe> — but content may have &quot; only
    end = t.find('"></iframe>', sd)
    chunk = t[sd:end]
    # raw " should only be the opening of srcdoc="
    raw = chunk.count('"')
    print("OK", path.name, "srcdoc raw quotes (expect 1):", raw)
    print("  marker present:", MARKER in chunk)
    print("  content single-quoted:", "content: ''" in chunk)
    print("  iframe end found:", end > 0)
    # body of ordenamiento should still be inside srcdoc
    print("  has Ordenamiento h1 in srcdoc:", "Ordenamiento&lt;/h1&gt;" in chunk or "&lt;h1&gt;Ordenamiento" in chunk)


def main():
    for p in PATHS:
        if p.exists():
            patch(p)


if __name__ == "__main__":
    main()
