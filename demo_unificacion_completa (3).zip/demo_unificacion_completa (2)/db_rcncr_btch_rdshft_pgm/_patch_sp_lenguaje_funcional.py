# -*- coding: utf-8 -*-
"""
Reemplaza nombres SP-* por lenguaje funcional:
'tenemos un proceso que hace X, Y y Z'.
En Demo/Workshop no aparecen codigos SP; en pestaña SPs se mantienen.
"""
from __future__ import annotations

import json
import re
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

# Qué hace cada SP en lenguaje de mesa (sin código)
SP_FUNC = {
    "SP-00": {
        "titulo": "Proceso que prepara las tablas de salida",
        "hace": (
            "Tenemos un proceso que deja listas las tablas donde viven el score, "
            "el orden de intento y el catálogo de pesos. Así la corrida ya tiene dónde guardar."
        ),
    },
    "SP-01": {
        "titulo": "Proceso del catálogo de operadores y pesos",
        "hace": (
            "Tenemos un proceso (y una tabla) que guarda operadores de celular y otros catálogos. "
            "Cuando llega un prefijo, ahí miramos si es Claro, Movistar, etc.; si no está, usamos el default."
        ),
    },
    "SP-02": {
        "titulo": "Proceso que traduce el tipo de contacto al canal",
        "hace": (
            "Tenemos un proceso que mira el tipo de contacto del origen y dice: "
            "esto va a dirección, esto a fijo, esto a celular o esto a email. "
            "Así un fijo no se mezcla con un correo en el ranking."
        ),
    },
    "SP-03": {
        "titulo": "Proceso que deja solo direcciones vigentes",
        "hace": (
            "Tenemos un proceso que, después de unificar, deja pasar solo las direcciones ganadoras. "
            "Las hijas (ya absorbidas) no entran a ordenar."
        ),
    },
    "SP-04": {
        "titulo": "Proceso que arma la lista de quién entra hoy",
        "hace": (
            "Tenemos un proceso que arma las bandejas del día: qué casas, fijos, celdas y correos "
            "sí van a puntuar. Email sin @ no entra; TEL/CEL piden tener dirección ganadora."
        ),
    },
    "SP-05": {
        "titulo": "Proceso que ordena direcciones (casa vs oficina)",
        "hace": (
            "Tenemos un proceso que mira las direcciones de una persona, calcula un score con el catálogo "
            "y deja lugar 1, 2, 3… Así sabemos si intentamos primero la casa o la oficina."
        ),
    },
    "SP-06": {
        "titulo": "Proceso que ordena teléfonos fijos",
        "hace": (
            "Tenemos un proceso que ordena solo fijos entre sí: el válido queda de primeras frente al no válido. "
            "Una señal de geo se puede calcular para seguimiento, pero no mueve ese ranking."
        ),
    },
    "SP-07": {
        "titulo": "Proceso que ordena celulares (Claro / Movistar / default)",
        "hace": (
            "Tenemos un proceso que toma el prefijo del celular, lo busca en la tabla de operadores "
            "y con ese peso arma el score. Si el prefijo no está (ej. 999), usa el default acordado; no deja el celular en cero."
        ),
    },
    "SP-08": {
        "titulo": "Proceso que ordena emails",
        "hace": (
            "Tenemos un proceso que ordena correos entre sí. Algunas variables se calculan para seguimiento "
            "pero no suman al score: por eso no cambian quién va primero si solo ellas cambian."
        ),
    },
    "SP-09": {
        "titulo": "Proceso que guarda el orden de intento en calle",
        "hace": (
            "Tenemos un proceso que toma el lugar de la dirección y lo guarda como orden de prioridad. "
            "Eso es lo que sale a campo: 1º, 2º… Solo dirección escribe ese orden; fijo/celular/email no."
        ),
    },
    "SP-10": {
        "titulo": "Proceso que limpia lo temporal de la corrida",
        "hace": (
            "Tenemos un proceso que, al cerrar, borra las tablas temporales de la corrida. "
            "El orden ya guardado se conserva; no queda basura para la siguiente ejecución."
        ),
    },
    "SP-11": {
        "titulo": "Proceso que orquesta toda la corrida",
        "hace": (
            "Tenemos un proceso que dispara el recorrido completo en orden: "
            "armar quién entra → ordenar canales → guardar orden de calle → limpiar temporales."
        ),
    },
    "SP-12": {
        "titulo": "Proceso operativo que dispara la corrida",
        "hace": (
            "Tenemos un proceso/runbook de operación que es el botón de arranque de la corrida "
            "(después de que la unificación ya quedó lista)."
        ),
    },
    "SP-13": {
        "titulo": "Proceso que valida si la corrida quedó sana",
        "hace": (
            "Tenemos un proceso de control que revisa conteos: por ejemplo, que ninguna hija "
            "haya quedado mal ordenada y que los volúmenes tengan sentido."
        ),
    },
    "SP-M01": {
        "titulo": "Proceso que carga los ejemplos de la mesa",
        "hace": (
            "Tenemos un proceso que deja listos los ejemplos de personas de la Demo/Workshop "
            "(casa vs oficina, hija, prefijo 999, etc.) para poder mostrarlos en la mesa."
        ),
    },
    "SP-M02": {
        "titulo": "Proceso que valida los ejemplos de la mesa",
        "hace": (
            "Tenemos un proceso que revisa que esos ejemplos cumplan las reglas acordadas "
            "(válido vs no válido, default de operador, etc.)."
        ),
    },
    "SP-M03": {
        "titulo": "Proceso que prepara la mesa en un solo paso",
        "hace": (
            "Tenemos un proceso que, de un solo golpe, carga los ejemplos y los valida. "
            "Así la mesa parte con los casos listos."
        ),
    },
}


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def esc_js(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#x27;")
    )


def strip_sp_codes(text: str) -> str:
    if not isinstance(text, str):
        return text
    t = text
    # replace SP-xx with functional phrase if known
    for sid, meta in SP_FUNC.items():
        if sid in t:
            t = t.replace(sid, meta["titulo"])
    # leftover codes
    t = re.sub(r"\bSP-[A-Z0-9]+\b", "proceso de ordenamiento", t)
    t = re.sub(r"\bsp_[a-z0-9_]+\.sql\b", "proceso de ordenamiento", t, flags=re.I)
    t = re.sub(r"\s{2,}", " ", t).strip()
    return t


def patch_data(data: dict) -> None:
    # Enrich sps_detalle with functional fields (for SPs tab STAR)
    for sp in data.get("sps_detalle") or []:
        sid = sp.get("id")
        meta = SP_FUNC.get(sid)
        if not meta:
            continue
        sp["titulo_funcional"] = meta["titulo"]
        sp["hace_funcional"] = meta["hace"]
        # Keep id for SPs tab, but put functional text in resultado/por_que display helpers
        sp["rol"] = meta["titulo"]
        if not (sp.get("conclusion") or "").startswith("Pregunta normal"):
            sp["conclusion"] = meta["hace"]
        # Don't wipe technical conclusion if already detailed; prepend functional
        if sp.get("conclusion") and meta["hace"] not in sp["conclusion"]:
            sp["conclusion"] = meta["hace"] + " " + sp["conclusion"]

    # Rows: rebuild _sps_relacionados as functional "procesos" (no SP-id in UI)
    for row in data.get("rows") or []:
        # Prefer pack mapping from existing linked ids or PACK
        linked = row.get("_sps_relacionados") or []
        ids = [x.get("id") for x in linked if x.get("id")]
        # if empty, leave empty (Demo sin bloque técnico) OR add functional procesos from pack
        # User wants functional explanation of what the process does - show as "procesos" block
        pack = row.get("_pack_code")
        pack_sps = {
            "INSUMO-CT": ["SP-02", "SP-04"],
            "RPU-STG": ["SP-03", "SP-04"],
            "BETAS": ["SP-01"],
            "DIR-RANK": ["SP-05"],
            "ELEG-HIJA": ["SP-03", "SP-05"],
            "ELEG-BLOQ": ["SP-06"],
            "DIR-EMPATE": ["SP-05"],
            "TEL-RANK": ["SP-06"],
            "TEL-02": ["SP-06"],
            "CEL-02": ["SP-07", "SP-01"],
            "EMA-03": ["SP-08"],
            "CONSOL": ["SP-09"],
            "DROP": ["SP-10"],
        }
        ids = pack_sps.get(pack) or ids
        procesos = []
        for sid in ids:
            meta = SP_FUNC.get(sid)
            if not meta:
                continue
            procesos.append(
                {
                    "titulo": meta["titulo"],
                    "hace": meta["hace"],
                    # keep id only for internal; UI won't show it
                    "id": "",
                    "archivo": "",
                    "objetivo": meta["titulo"],
                    "accion": meta["hace"],
                    "resultado": meta["hace"],
                    "por_que": meta["hace"],
                    "conclusion": meta["hace"],
                }
            )
        row["_sps_relacionados"] = procesos
        row["_procesos_funcionales"] = procesos

        for k in (
            "_dev",
            "_conclusion",
            "_conclusion_regla",
            "_busca",
            "_titulo_corto",
            "Subescenario",
            "_ejemplo_label",
        ):
            if isinstance(row.get(k), str):
                row[k] = strip_sp_codes(row[k])

    # presentacion: strip any SP mentions
    for b in data.get("presentacion") or []:
        for k, v in list(b.items()):
            if isinstance(v, str):
                b[k] = strip_sp_codes(v)
            elif isinstance(v, list):
                b[k] = [strip_sp_codes(x) if isinstance(x, str) else x for x in v]


# Inline card: show "Proceso" without SP code
INLINE_OLD = """  const spsRel = (row._sps_relacionados || []);
  const spsBlock = spsRel.length ? `&lt;div class=&quot;scenario-section sp-inline&quot;&gt;
    &lt;span class=&quot;sec-label&quot;&gt;SP que lo hace&lt;/span&gt;
    &lt;div class=&quot;sp-inline-grid&quot;&gt;${spsRel.map(s =&gt; `
      &lt;article class=&quot;sp-inline-card&quot;&gt;
        &lt;header&gt;&lt;code&gt;${esc(s.id)}&lt;/code&gt; &lt;span&gt;${esc(s.archivo || &#x27;&#x27;)}&lt;/span&gt;&lt;/header&gt;
        &lt;p&gt;&lt;b&gt;Objetivo&lt;/b&gt; ${esc(s.objetivo || &#x27;&#x27;)}&lt;/p&gt;
        &lt;p&gt;&lt;b&gt;Acción&lt;/b&gt; ${esc(s.accion || &#x27;&#x27;)}&lt;/p&gt;
        &lt;p&gt;&lt;b&gt;Resultado&lt;/b&gt; ${esc(s.resultado || &#x27;&#x27;)}&lt;/p&gt;
        ${(s.conclusion || s.por_que) ? `&lt;p class=&quot;porque&quot;&gt;&lt;b&gt;Conclusión&lt;/b&gt; ${esc(s.conclusion || s.por_que)}&lt;/p&gt;` : &#x27;&#x27;}
      &lt;/article&gt;`).join(&#x27;&#x27;)}&lt;/div&gt;
  &lt;/div&gt;` : &#x27;&#x27;;"""

INLINE_NEW = """  const spsRel = (row._procesos_funcionales || row._sps_relacionados || []);
  const spsBlock = spsRel.length ? `&lt;div class=&quot;scenario-section sp-inline&quot;&gt;
    &lt;span class=&quot;sec-label&quot;&gt;Qué proceso lo hace (en simple)&lt;/span&gt;
    &lt;div class=&quot;sp-inline-grid&quot;&gt;${spsRel.map(s =&gt; `
      &lt;article class=&quot;sp-inline-card&quot;&gt;
        &lt;header&gt;&lt;strong&gt;${esc(s.titulo || s.objetivo || &#x27;Proceso&#x27;)}&lt;/strong&gt;&lt;/header&gt;
        &lt;p&gt;${esc(s.hace || s.conclusion || s.por_que || s.accion || &#x27;&#x27;)}&lt;/p&gt;
      &lt;/article&gt;`).join(&#x27;&#x27;)}&lt;/div&gt;
  &lt;/div&gt;` : &#x27;&#x27;;"""


def patch_render_sp_nav(html: str) -> str:
    """In SPs tab nav, show functional title; keep id small."""
    old = "${esc((s.fase ? s.fase + &#x27; · &#x27; : &#x27;&#x27;) + (s.rol || s.archivo.replace(&#x27;sp_&#x27;,&#x27;&#x27;).replace(&#x27;.sql&#x27;,&#x27;&#x27;)))}"
    new = "${esc(s.titulo_funcional || s.rol || (s.fase ? s.fase + &#x27; · &#x27; : &#x27;&#x27;) + (s.archivo || &#x27;&#x27;))}"
    if old in html:
        html = html.replace(old, new)
        print("  SP nav functional titles ok")
    # In renderSpCard, show functional blurb under pregunta
    needle = "${pregunta}\n      ${star}"
    inject = (
        "${pregunta}\n"
        "      ${sp.hace_funcional ? `&lt;div class=&quot;scenario-section&quot;&gt;"
        "&lt;span class=&quot;sec-label&quot;&gt;En simple&lt;/span&gt;"
        "&lt;p&gt;${esc(sp.hace_funcional)}&lt;/p&gt;&lt;/div&gt;` : &#x27;&#x27;}\n"
        "      ${star}"
    )
    if needle in html and "hace_funcional" not in html[html.rfind("function renderSpCard") : html.rfind("function renderSpCard") + 2500]:
        idx = html.rfind(needle)
        if idx > 0:
            html = html[:idx] + inject + html[idx + len(needle) :]
            print("  renderSpCard En simple ok")
    return html


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    patch_data(data)
    html = html[:start] + to_html_json(data) + html[end:]

    # Restore spsBlock in card template if it was removed
    ret = "${idBlock}${buscaBlock}${tblPasos}${tblEj}${devBlock}${conclBlock}${accionBlock}"
    ret_with = "${idBlock}${buscaBlock}${tblPasos}${tblEj}${devBlock}${spsBlock}${conclBlock}${accionBlock}"
    if ret in html and "spsBlock}${conclBlock}" not in html:
        html = html.replace(ret, ret_with, 1)
        print("  restored spsBlock in card")

    if INLINE_OLD in html:
        html = html.replace(INLINE_OLD, INLINE_NEW, 1)
        print("  inline procesos funcionales ok")
    elif "Qué proceso lo hace" in html:
        print("  inline already functional")
    else:
        # try shorter replace of label only
        html = html.replace(
            "&lt;span class=&quot;sec-label&quot;&gt;SP que lo hace&lt;/span&gt;",
            "&lt;span class=&quot;sec-label&quot;&gt;Qué proceso lo hace (en simple)&lt;/span&gt;",
        )
        html = html.replace(
            "&lt;header&gt;&lt;code&gt;${esc(s.id)}&lt;/code&gt; &lt;span&gt;${esc(s.archivo || &#x27;&#x27;)}&lt;/span&gt;&lt;/header&gt;",
            "&lt;header&gt;&lt;strong&gt;${esc(s.titulo || s.objetivo || &#x27;Proceso&#x27;)}&lt;/strong&gt;&lt;/header&gt;",
        )
        print("  inline partial functional")

    html = patch_render_sp_nav(html)
    path.write_text(html, encoding="utf-8")
    sample = next(
        (r for r in data["rows"] if r.get("_pack_code") == "CEL-02"),
        None,
    )
    print("OK", path.name)
    if sample and sample.get("_procesos_funcionales"):
        print("  CEL-02:", sample["_procesos_funcionales"][0]["titulo"][:60])


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
