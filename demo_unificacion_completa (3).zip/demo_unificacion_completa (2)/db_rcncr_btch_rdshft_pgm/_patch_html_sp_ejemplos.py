# -*- coding: utf-8 -*-
"""HTML: cada escenario = mismo id/query que sp_ordenamiento_cargar_seed_mock."""
import json
import re
import shutil
from html import unescape
from pathlib import Path

PATHS = [
    Path(r"C:\Users\C32525E\Downloads\RECONOCER_TODO_EN_UNO_WORKSHOP.html"),
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

# Mapa escenario HTML → persona del SP mock (cargar_seed_mock)
SP_MAP = {
    "ORD-DIR-RANK": 20001,
    "ORD-SALIDA": 20001,
    "ORD-RESUMEN": 20001,
    "ORD-DIR-EMP": 20010,
    "ORD-F3-HIJA": 20011,
    "ORD-TEL-RANK": 20004,
    "ORD-TEL-02": 20013,
    "ORD-CEL-02": 20012,
    "ORD-EMA-03": 20014,
}

CALL_MOCK = (
    "-- Primero carga el mismo seed del SP:\n"
    "CALL bdm_stage.sp_ordenamiento_ejecucion_mock();\n"
    "-- (equivale a cargar_seed_mock + validar_mock)\n"
)


def extract(html, start):
    j, depth, in_q = start, 0, False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        if not in_q:
            if html[j] == "{":
                depth += 1
            elif html[j] == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def dump(obj):
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":")).replace('"', "&quot;")


def q_dir(pid):
    return (
        CALL_MOCK
        + f"-- Ejemplo SP mock · id_buro_persona = {pid} (mismo seed del HTML)\n"
        "SELECT r.etiqueta, s.cod_dw_persona_ubic AS rpu, s.score, s.lugar, p.orden_prioridad\n"
        "FROM bdm_stage.mock_ord_score s\n"
        "JOIN bdm_stage.mock_ord_rpu r ON r.cod_dw_persona_ubic = s.cod_dw_persona_ubic\n"
        "LEFT JOIN bdm_stage.mock_ord_prioridad p ON p.cod_dw_persona_ubic = s.cod_dw_persona_ubic\n"
        f"WHERE s.id_buro_persona = {pid} AND s.canal = 'DIR'\n"
        "ORDER BY s.lugar;\n"
    )


def q_canal(pid, canal):
    return (
        CALL_MOCK
        + f"-- Ejemplo SP mock · id_buro_persona = {pid} · canal {canal}\n"
        "SELECT r.etiqueta, s.cod_dw_persona_ubic AS rpu, s.score, s.lugar, s.nota\n"
        "FROM bdm_stage.mock_ord_score s\n"
        "JOIN bdm_stage.mock_ord_rpu r ON r.cod_dw_persona_ubic = s.cod_dw_persona_ubic\n"
        f"WHERE s.id_buro_persona = {pid} AND s.canal = '{canal}'\n"
        "ORDER BY s.lugar;\n"
    )


def q_hija():
    return (
        CALL_MOCK
        + "-- Ejemplo SP mock · F3-02 · id_buro = 20011 (padre 91018 / hija 91019)\n"
        "SELECT 'scores_hija_91019' AS chk, COUNT(*)::BIGINT AS n\n"
        "FROM bdm_stage.mock_ord_score WHERE cod_dw_persona_ubic = 91019\n"
        "UNION ALL\n"
        "SELECT 'orden_hija_91019', COUNT(*)::BIGINT\n"
        "FROM bdm_stage.mock_ord_prioridad WHERE cod_dw_persona_ubic = 91019;\n"
        "-- Padre (debe tener scores):\n"
        "SELECT canal, score, lugar FROM bdm_stage.mock_ord_score\n"
        "WHERE id_buro_persona = 20011 ORDER BY canal, lugar;\n"
    )


def q_catalogo():
    return (
        CALL_MOCK
        + "-- Catálogo de ejemplos del SP (mismas personas del HTML)\n"
        "SELECT id_buro_persona, cod_escenario, criterio_ca, descripcion\n"
        "FROM bdm_stage.mock_ord_escenario\n"
        "WHERE es_html_ejemplo = 1\n"
        "ORDER BY id_buro_persona, cod_escenario;\n"
    )


def q_ca_result():
    return (
        CALL_MOCK
        + "-- Veredicto CA del SP validar_mock (mismo que entrega QA)\n"
        "SELECT criterio_ca, estado, detalle\n"
        "FROM bdm_stage.mock_ord_ca_result\n"
        "ORDER BY criterio_ca;\n"
    )


def set_mock(row, pid, label, query, table=None):
    row["_fuente"] = "MOCK"
    row["_id_buro_persona"] = pid
    row["_id_ejemplo"] = f"SP mock · id_buro_persona = {pid}"
    row["_ejemplo_label"] = label
    row["_show_query"] = True
    row["Query validación (copiar en dba_rncr_batch)"] = query.strip() + "\n"
    if table:
        row["_tabla_ejemplo"] = table


def patch(data):
    k = data.setdefault("kpis", {})
    k["demo_modo_html"] = "MOCK_SP"
    k["demo_id_buro_persona"] = 20001
    k["mock_sp"] = "bdm_stage.sp_ordenamiento_ejecucion_mock"
    k["mock_personas"] = "20001-20014"

    for row in data.get("rows") or []:
        code = row.get("Escenario") or ""

        if code == "ORD-DIR-RANK":
            set_mock(
                row,
                20001,
                "SP cargar_seed_mock · RANK-01 · CA-O04",
                q_dir(20001),
                {
                    "title": "SP mock · 20001 (casa/oficina) — mismo seed del SP",
                    "headers": ["Etiqueta", "RPU", "Score", "lugar", "orden_prioridad"],
                    "rows": [
                        ["casa", "91001", "850.0000", "1", "1"],
                        ["oficina", "91002", "700.0000", "2", "2"],
                    ],
                },
            )
            row["_busca"] = (
                "Mayor score → lugar 1. Ejemplo HTML = persona 20001 del "
                "CALL bdm_stage.sp_ordenamiento_cargar_seed_mock()."
            )
            row["_dev"] = "SP mock: 20001 casa=850 lugar1 · oficina=700 lugar2."
            row["_conclusion_regla"] = row["_dev"]

        elif code == "ORD-SALIDA":
            set_mock(
                row,
                20001,
                "SP mock · orden_prioridad · CA-O07",
                CALL_MOCK
                + "-- Salida SP mock · 20001\n"
                "SELECT p.cod_dw_persona_ubic AS rpu, p.orden_prioridad, s.score, s.lugar\n"
                "FROM bdm_stage.mock_ord_prioridad p\n"
                "JOIN bdm_stage.mock_ord_score s\n"
                "  ON s.cod_dw_persona_ubic = p.cod_dw_persona_ubic AND s.canal = 'DIR'\n"
                "WHERE p.id_buro_persona = 20001\n"
                "ORDER BY p.orden_prioridad;\n",
                {
                    "title": "SP mock · salida 20001",
                    "headers": ["RPU", "Score", "lugar", "orden_prioridad"],
                    "rows": [
                        ["91001", "850.0000", "1", "1"],
                        ["91002", "700.0000", "2", "2"],
                    ],
                },
            )

        elif code == "ORD-RESUMEN":
            set_mock(
                row,
                20001,
                "SP mock · catálogo 20001–20014",
                q_catalogo(),
                {
                    "title": "Personas del SP mock (HTML = seed)",
                    "headers": ["id_buro", "Escenario", "CA", "En SP"],
                    "rows": [
                        ["20001", "RANK-01 / SALIDA", "CA-O04/O07", "sí"],
                        ["20003", "3 DIR", "CA-O12", "sí"],
                        ["20004", "TEL", "CA-O06", "sí"],
                        ["20010", "Empate", "CA-O08", "sí"],
                        ["20011", "F3-02 hija", "CA-O05", "sí"],
                        ["20012", "CEL-02", "CA-O11", "sí"],
                        ["20013", "TEL-02", "CA-O09", "sí"],
                        ["20014", "EMA-03", "CA-O10", "sí"],
                    ],
                },
            )

        elif code == "ORD-DIR-EMP":
            set_mock(
                row,
                20010,
                "SP mock · RANK-02 empate · CA-O08",
                q_dir(20010),
                {
                    "title": "SP mock · 20010 empate score 777",
                    "headers": ["Etiqueta", "RPU", "Score", "lugar"],
                    "rows": [
                        ["empate_a", "91016", "777.0000", "1"],
                        ["empate_b", "91017", "777.0000", "2"],
                    ],
                },
            )

        elif code == "ORD-F3-HIJA":
            set_mock(
                row,
                20011,
                "SP mock · F3-02 · CA-O05",
                q_hija(),
                {
                    "title": "SP mock · 20011 padre 91018 / hija 91019",
                    "headers": ["Campo", "Hija 91019", "Padre 91018"],
                    "rows": [
                        ["score", "0 filas", "639.7849 DIR"],
                        ["orden_prioridad", "0 filas", "1"],
                        ["ind_unificacion", "1", "NULL"],
                    ],
                },
            )

        elif code == "ORD-TEL-RANK":
            set_mock(
                row,
                20004,
                "SP mock · TEL · CA-O06",
                q_canal(20004, "TEL"),
                {
                    "title": "SP mock · 20004 TEL",
                    "headers": ["Contacto", "Score", "lugar"],
                    "rows": [
                        ["tel_valida_dir", "420.0000", "1"],
                        ["tel_novalida_dir", "210.0000", "2"],
                    ],
                },
            )

        elif code == "ORD-TEL-02":
            set_mock(
                row,
                20013,
                "SP mock · TEL-02 · CA-O09",
                q_canal(20013, "TEL"),
                {
                    "title": "SP mock · 20013 (TEL020 no mueve score)",
                    "headers": ["Contacto", "Score", "lugar"],
                    "rows": [
                        ["tel_base", "376.5000", "1"],
                        ["tel_solo_tel020", "376.5000", "2"],
                    ],
                },
            )

        elif code == "ORD-CEL-02":
            set_mock(
                row,
                20012,
                "SP mock · CEL-02 · CA-O11",
                q_canal(20012, "CEL"),
                {
                    "title": "SP mock · 20012 default 0.22 → score 220",
                    "headers": ["Contacto", "Score", "lugar"],
                    "rows": [["cel_prefijo_999", "220.0000", "1"]],
                },
            )

        elif code == "ORD-EMA-03":
            set_mock(
                row,
                20014,
                "SP mock · EMA-03 · CA-O10",
                q_canal(20014, "EMA"),
                {
                    "title": "SP mock · 20014 (EMA003/007 no mueven)",
                    "headers": ["Contacto", "Score", "lugar"],
                    "rows": [
                        ["ema_base", "281.7705", "1"],
                        ["ema_solo_excluidas", "281.7705", "2"],
                    ],
                },
            )

        elif code in ("ORD-VAL", "ORD-SP-ORQ", "ORD-FLUJO"):
            set_mock(
                row,
                20001,
                "SP mock · orquestador / matriz CA",
                q_ca_result(),
            )
            row["_dev"] = (
                "Correr CALL bdm_stage.sp_ordenamiento_ejecucion_mock(); "
                "veredicto esperado PASSED_ALL (CA-O01…CA-O12)."
            )
            row["_conclusion_regla"] = row["_dev"]

        elif code in (
            "ORD-ALCANCE",
            "ORD-F1-CT",
            "ORD-F1-RPU",
            "ORD-F1-BETA",
            "ORD-F3-BLOQ",
            "ORD-SP-PREP",
            "ORD-BITBUCKET",
        ):
            # Gates de catálogo / volumen — query = SP mock CA + betas
            row["_fuente"] = "MOCK"
            row["_id_ejemplo"] = "SP mock · CA + betas (seed 20001–20014)"
            row["_ejemplo_label"] = "Validar con el mismo SP mock del HTML"
            row["_show_query"] = True
            row["Query validación (copiar en dba_rncr_batch)"] = (
                q_ca_result()
                + "-- Betas (compartidos REAL/MOCK):\n"
                "SELECT canal, COUNT(*) AS n FROM bdm_datos.beta_ordenamiento "
                "GROUP BY 1 ORDER BY 1;\n"
            )


def main():
    for path in PATHS:
        if not path.exists():
            print("SKIP", path)
            continue
        bak = path.with_suffix(path.suffix + ".bak_sp_ej")
        if not bak.exists():
            shutil.copy2(path, bak)
        html = path.read_text(encoding="utf-8")
        positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
        start = positions[1]
        while start < len(html) and html[start] in " \t\n\r":
            start += 1
        data, s0, s1 = extract(html, start)
        patch(data)
        html = html[:s0] + dump(data) + html[s1:]
        for a, b in [
            (
                "Workshop · ejemplos HTML = MOCK 20001–20014 · gates volumen = REAL DEV",
                "Workshop · ejemplos HTML = SP mock (20001–20014) · CALL sp_ordenamiento_ejecucion_mock",
            ),
            (
                "Workshop · REAL = IDs DEV · MOCK = smoke (si no hay caso) · 2026-09-23 · dba_rncr_batch",
                "Workshop · ejemplos = SP mock 20001–20014 · CALL sp_ordenamiento_ejecucion_mock · dba_rncr_batch",
            ),
            (
                "Workshop · IDs reales DEV (2026-09-23) · dba_rncr_batch",
                "Workshop · ejemplos SP mock 20001–20014 · CALL sp_ordenamiento_ejecucion_mock",
            ),
        ]:
            html = html.replace(a, b)
        # banner Caso A/B → nota SP mock primario
        if "Caso A (par HTML Regla 2):" in html and "SP mock primario" not in html:
            html = html.replace(
                '<div style="font-weight:700;font-size:1rem;color:#1e3a8a;margin-bottom:0.35rem;">',
                '<div style="font-weight:700;font-size:1rem;color:#1e3a8a;margin-bottom:0.35rem;">'
                "Ordenamiento HTML = SP mock "
                "<code>bdm_stage.sp_ordenamiento_ejecucion_mock</code> "
                "(personas 20001–20014). "
                "</div><div style=\"font-weight:700;font-size:0.95rem;color:#1e3a8a;margin-bottom:0.35rem;\">",
                1,
            )
        path.write_text(html, encoding="utf-8")
        print("OK", path.name)


if __name__ == "__main__":
    main()
