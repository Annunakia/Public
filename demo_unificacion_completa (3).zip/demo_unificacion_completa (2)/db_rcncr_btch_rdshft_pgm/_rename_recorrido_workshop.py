# -*- coding: utf-8 -*-
"""Renombra Recorrido → Workshop en el iframe Ordenamiento."""
from __future__ import annotations

import json
import re
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def rename_in_text(s: str) -> str:
    if not isinstance(s, str):
        return s
    return (
        s.replace("Recorrido", "Workshop")
        .replace("recorrido", "workshop")
    )


def patch_data(data: dict) -> None:
    def walk(obj):
        if isinstance(obj, dict):
            for k, v in obj.items():
                if isinstance(v, str):
                    obj[k] = rename_in_text(v)
                else:
                    walk(v)
        elif isinstance(obj, list):
            for i, v in enumerate(obj):
                if isinstance(v, str):
                    obj[i] = rename_in_text(v)
                else:
                    walk(v)

    walk(data.get("presentacion"))


def patch_ord_ui(html: str) -> str:
    # Solo dentro del iframe Ordenamiento
    a = html.find('iframe title="Mapa Ordenamiento"')
    if a < 0:
        print("  FAIL no ord iframe")
        return html
    end = html.find('"></iframe>', a)
    if end < 0:
        print("  FAIL no iframe end")
        return html
    chunk = html[a:end]
    reps = [
        (
            "{ id: &#x27;recorrido&#x27;, label: &#x27;Recorrido&#x27;, el: &#x27;frame-workshop&#x27;, progress: 55 }",
            "{ id: &#x27;workshop&#x27;, label: &#x27;Workshop&#x27;, el: &#x27;frame-workshop&#x27;, progress: 55 }",
        ),
        (
            "Recorrido — por fases (1 Insumos · 2 canales · 3–4 Salida)",
            "Workshop — por fases (1 Insumos · 2 canales · 3–4 Salida)",
        ),
        ("Cómo va el Recorrido", "Cómo va el Workshop"),
        (
            "Recorrido: 20001 → 20011 → 20010 → 20004 → 20013 → 20012 → 20014 → salida.",
            "Workshop: 20001 → 20011 → 20010 → 20004 → 20013 → 20012 → 20014 → salida.",
        ),
        (
            "&lt;span class=&quot;sec-label&quot;&gt;Recorrido&lt;/span&gt;",
            "&lt;span class=&quot;sec-label&quot;&gt;Workshop&lt;/span&gt;",
        ),
        ("// SPs integrados en Recorrido", "// SPs integrados en Workshop"),
        ("/* SP inline in Recorrido */", "/* SP inline in Workshop */"),
    ]
    n = 0
    for old, new in reps:
        if old in chunk:
            chunk = chunk.replace(old, new)
            n += 1
    # Keep id checks working if any leftover recorrido id
    chunk = chunk.replace(
        "FRAMES[i].id===&#x27;recorrido&#x27; || FRAMES[i].id===&#x27;workshop&#x27;",
        "FRAMES[i].id===&#x27;workshop&#x27;",
    )
    chunk = chunk.replace(
        "(f.id === &#x27;recorrido&#x27; || f.id === &#x27;workshop&#x27;)",
        "f.id === &#x27;workshop&#x27;",
    )
    html = html[:a] + chunk + html[end:]
    print(f"  UI replacements applied: {n}")
    return html


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    assert len(positions) >= 2
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    patch_data(data)
    html = html[:start] + to_html_json(data) + html[end:]
    html = patch_ord_ui(html)
    path.write_text(html, encoding="utf-8")
    # verify
    a = html.find("Mapa Ordenamiento")
    e = html.find('"></iframe>', a)
    chunk = html[a:e]
    print(
        "OK",
        path.name,
        "label Workshop",
        "label: &#x27;Workshop&#x27;" in chunk,
        "no label Recorrido",
        "label: &#x27;Recorrido&#x27;" not in chunk,
    )


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
