# -*- coding: utf-8 -*-
"""Align queries to example tables: REAL → same rows; MOCK → why no DEV case."""
import json
import re
import shutil
from html import unescape
from pathlib import Path

PATHS = [
    Path(r"C:\Users\C32525E\Downloads\RECONOCER_TODO_EN_UNO_WORKSHOP.html"),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\repos\db_rcncr_btch_rdshft_dt"
        r"\docs\RECONOCER_TODO_EN_UNO.html"
    ),
]

A = {
    "id": 3228096126421495389,
    "pin": 98746,
    "padre": 2,
    "hija": 3,
    "dir": 639.7849,
    "tel": 376.5281,
    "ema": 281.7705,
}
B = {
    "id": 2848501447849812647,
    "pin": 165259,
    "rpu1": 166366,
    "s1": 611.8280,
    "rpu2": 166369,
    "s2": 599.7849,
    "hija1": 166367,
    "hija2": 166368,
}


def extract_escaped_json(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def dump_escaped(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":")).replace('"', "&quot;")


def set_q(row, q, show=True):
    row["Query validación (copiar en dba_rncr_batch)"] = q.strip() + "\n"
    row["_show_query"] = show


def patch_rows(data: dict) -> None:
    for row in data.get("rows") or []:
        code = row.get("Escenario") or row.get("_esc_codigo") or ""

        if code == "ORD-DIR-RANK":
            row["_fuente"] = "REAL"
            row["_id_ejemplo"] = f"id_buro_persona = {B['id']}"
            row["_ejemplo_label"] = "REAL · lo que ves en la tabla = resultado de esta query"
            set_q(
                row,
                f"""-- REAL · mismo ejemplo de la tabla RANK-01
-- Esperado: RPU {B['rpu1']} score {B['s1']:.4f} lugar 1
--           RPU {B['rpu2']} score {B['s2']:.4f} lugar 2
--           hijas {B['hija1']}/{B['hija2']} NO aparecen
SELECT canal,
       cod_dw_persona_ubic AS rpu,
       cod_pin_persona,
       score,
       lugar
FROM bdm_datos.score_ordenamiento
WHERE id_buro_persona = {B['id']}
  AND canal = 'DIR'
ORDER BY lugar;

-- orden_prioridad (mismas RPUs 1 y 2)
SELECT cod_dw_persona_ubic AS rpu, orden_prioridad
FROM bdm_datos.rpu_orden_prioridad
WHERE id_buro_persona = {B['id']}
ORDER BY orden_prioridad;

-- Confirmación hija excluida (debe ser 0)
SELECT COUNT(*) AS hija_con_score
FROM bdm_datos.score_ordenamiento
WHERE cod_dw_persona_ubic = {B['hija1']};""",
            )

        elif code == "ORD-RESUMEN":
            row["_fuente"] = "REAL"
            row["_id_ejemplo"] = f"id_buro_persona = {B['id']}"
            row["_ejemplo_label"] = "REAL · tabla = ganadoras/hija Caso B"
            set_q(
                row,
                f"""-- REAL · mismo ejemplo de la tabla (Caso B)
-- 1) Unificación hijas → padre {B['rpu2']}
SELECT cod_dw_persona_ubic AS hija,
       cod_dw_direccion_unificada AS padre,
       unifica_atributos AS regla
FROM bdm_datos.unificacion_direccion
WHERE cod_dw_direccion_unificada = {B['rpu2']}
ORDER BY hija;
-- Esperado: {B['hija1']} y {B['hija2']} → padre {B['rpu2']} · regla 2

-- 2) Scores DIR de la persona (mismas filas de la tabla)
SELECT cod_dw_persona_ubic AS rpu, score, lugar
FROM bdm_datos.score_ordenamiento
WHERE id_buro_persona = {B['id']}
  AND canal = 'DIR'
ORDER BY lugar;
-- Esperado: {B['rpu1']}={B['s1']:.4f} lugar1 · {B['rpu2']}={B['s2']:.4f} lugar2""",
            )

        elif code == "ORD-F3-HIJA":
            row["_fuente"] = "REAL"
            row["_id_ejemplo"] = f"id_buro_persona = {A['id']}"
            row["_ejemplo_label"] = "REAL · tabla hija3/padre2 = esta query"
            set_q(
                row,
                f"""-- REAL · mismo ejemplo F3-02 de la tabla
-- Par unificación hija {A['hija']} → padre {A['padre']}
SELECT cod_dw_persona_ubic AS hija_rpu,
       cod_dw_direccion_unificada AS padre_rpu,
       unifica_atributos AS regla
FROM bdm_datos.unificacion_direccion
WHERE cod_dw_persona_ubic = {A['hija']}
  AND cod_dw_direccion_unificada = {A['padre']};
-- Esperado: 1 fila · regla = 2

-- Hija SIN score ni orden (columnas de la tabla → 0)
SELECT 'scores_hija' AS chk, COUNT(*)::BIGINT AS n
FROM bdm_datos.score_ordenamiento
WHERE cod_dw_persona_ubic = {A['hija']}
UNION ALL
SELECT 'orden_hija', COUNT(*)::BIGINT
FROM bdm_datos.rpu_orden_prioridad
WHERE cod_dw_persona_ubic = {A['hija']};
-- Esperado: 0 y 0

-- Padre CON score (columna padre de la tabla)
SELECT canal, cod_dw_persona_ubic AS rpu, score, lugar
FROM bdm_datos.score_ordenamiento
WHERE id_buro_persona = {A['id']}
ORDER BY canal, lugar;
-- Esperado DIR RPU {A['padre']} score {A['dir']:.4f} lugar 1
--          TEL {A['tel']:.4f} · EMA {A['ema']:.4f}""",
            )

        elif code == "ORD-TEL-RANK":
            row["_fuente"] = "REAL"
            row["_id_ejemplo"] = f"id_buro_persona = {A['id']}"
            row["_ejemplo_label"] = "REAL · filas DIR/TEL/EMA de la tabla"
            set_q(
                row,
                f"""-- REAL · mismo ejemplo de la tabla (canales independientes)
SELECT canal,
       cod_dw_persona_ubic AS rpu,
       cod_pin_persona,
       score,
       lugar
FROM bdm_datos.score_ordenamiento
WHERE id_buro_persona = {A['id']}
ORDER BY canal, lugar;
-- Esperado (igual que la tabla):
--   DIR  RPU {A['padre']}  {A['dir']:.4f}  lugar 1
--   TEL  RPU {A['padre']}  {A['tel']:.4f}  lugar 1
--   EMA  RPU {A['padre']}  {A['ema']:.4f}  lugar 1
-- Los scores NO se comparan entre canales.""",
            )

        elif code == "ORD-SALIDA":
            row["_fuente"] = "REAL"
            row["_id_ejemplo"] = f"id_buro_persona = {B['id']}"
            row["_ejemplo_label"] = "REAL · mismas RPUs/orden de la tabla"
            set_q(
                row,
                f"""-- REAL · mismo ejemplo de la tabla de salida
SELECT o.cod_dw_persona_ubic AS rpu,
       o.orden_prioridad,
       s.score AS score_dir,
       s.lugar
FROM bdm_datos.rpu_orden_prioridad o
LEFT JOIN bdm_datos.score_ordenamiento s
  ON s.cod_dw_persona_ubic = o.cod_dw_persona_ubic
 AND s.id_buro_persona = o.id_buro_persona
 AND s.canal = 'DIR'
WHERE o.id_buro_persona = {B['id']}
ORDER BY o.orden_prioridad;
-- Esperado:
--   {B['rpu1']}  orden 1  score {B['s1']:.4f}  lugar 1
--   {B['rpu2']}  orden 2  score {B['s2']:.4f}  lugar 2""",
            )

        elif code == "ORD-DIR-EMP":
            row["_fuente"] = "MOCK"
            row["_id_ejemplo"] = "MOCK UP · sin id_buro DEV para empate"
            row["_ejemplo_label"] = (
                "MOCK UP · la tabla es pedagógica; no hay persona DEV con empate DIR confirmado"
            )
            row["_tabla_ejemplo"] = {
                "title": "MOCK UP · RANK-02 empate (NO es dato DEV)",
                "headers": ["Qué muestra", "Valor", "¿Es real?", "Nota"],
                "rows": [
                    [
                        "Persona ejemplo",
                        "smoke 20001 (lab)",
                        "NO — MOCK UP",
                        "No existe como id_buro en bdm_datos",
                    ],
                    [
                        "Dos DIR mismo score",
                        "empate → ROW_NUMBER",
                        "NO — MOCK UP",
                        "Regla documental; sin caso A/B",
                    ],
                    [
                        "Cómo validar si aparece",
                        "query de búsqueda abajo",
                        "check REAL",
                        "Si n=0 → sigues sin caso",
                    ],
                ],
            }
            set_q(
                row,
                f"""-- ============================================================
-- MOCK UP · RANK-02 (empate DIR)
-- ¿Por qué no tengo caso para evaluarlo?
--   · Caso A ({A['id']}) solo tiene 1 DIR (RPU {A['padre']}) → no puede empatar.
--   · Caso B ({B['id']}) tiene 2 DIR con scores DISTINTOS
--     ({B['s1']:.4f} vs {B['s2']:.4f}) → no es empate.
--   · No hay id_buro DEV fijado con dos DIR y el mismo score.
-- Por eso la tabla del HTML es MOCK UP (pedagógica), no evidencia.
-- ============================================================

-- Check REAL: ¿existe ALGÚN empate DIR hoy en DEV?
SELECT id_buro_persona, score, COUNT(*) AS n_dirs_mismo_score
FROM bdm_datos.score_ordenamiento
WHERE canal = 'DIR'
GROUP BY 1, 2
HAVING COUNT(*) > 1
LIMIT 20;
-- Si esta query devuelve 0 filas → confirmas que no hay caso evaluable.
-- Si aparece alguna fila → ese id_buro SÍ sería un caso REAL (reemplaza el MOCK).""",
            )

        elif code == "ORD-TEL-02":
            row["_fuente"] = "MOCK"
            row["_id_ejemplo"] = "MOCK UP · sin persona DEV de aislamiento TEL020"
            row["_ejemplo_label"] = (
                "MOCK UP · la tabla es regla de código; no hay id_buro con A/B antes-después"
            )
            row["_tabla_ejemplo"] = {
                "title": "MOCK UP · TEL-02 (aislamiento TEL020) — NO es corrida persona DEV",
                "headers": ["Variable", "¿En catálogo?", "¿Suma al score?", "Fuente"],
                "rows": [
                    ["TEL010", "Sí", "Sí", "regla SP"],
                    ["TEL020", "Sí", "No ✗ (excluida)", "MOCK UP · regla doc/código"],
                    ["Resto TEL*", "Sí", "Sí", "regla SP"],
                ],
            }
            set_q(
                row,
                f"""-- ============================================================
-- MOCK UP · TEL-02
-- ¿Por qué no tengo caso persona para evaluarlo?
--   · Hace falta una persona con DOS corridas (TEL020 on/off) y score idéntico.
--   · Caso A/B no están instrumentados para ese A/B test en DEV.
--   · Lo que SÍ puedes verificar es la estructura (beta / exclusión en SP).
-- ============================================================

-- Check REAL de catálogo (no demuestra el aislamiento persona a persona):
SELECT codigo_variable, valor_beta
FROM bdm_datos.beta_ordenamiento
WHERE canal = 'TEL'
  AND codigo_variable ILIKE '%TEL020%';
-- Esto NO reemplaza un caso persona; solo confirma que la variable existe en betas.
-- Score TEL de referencia (Caso A) — es REAL pero NO prueba TEL-02:
--   id_buro {A['id']} TEL={A['tel']:.4f} (una sola foto, sin contrafactual).""",
            )

        elif code == "ORD-CEL-02":
            row["_fuente"] = "MOCK"
            row["_id_ejemplo"] = "MOCK UP · sin CEL evaluable en Caso A/B"
            row["_ejemplo_label"] = (
                "MOCK UP · prefijos smoke; Caso A/B no sirven para CEL-02"
            )
            row["_tabla_ejemplo"] = {
                "title": "MOCK UP · CEL-02 default operador — NO es id_buro DEV",
                "headers": ["Prefijo", "Operador", "¿Es real?", "Nota"],
                "rows": [
                    ["310", "CLARO (ej.)", "MOCK UP", "smoke 20006"],
                    ["999", "Sin mapeo → 0.22", "MOCK UP", "regla default"],
                    [
                        "Caso A / Caso B",
                        "CEL",
                        "check abajo",
                        "En DEV canal CEL es mínimo (~258); A/B suelen dar 0",
                    ],
                ],
            }
            set_q(
                row,
                f"""-- ============================================================
-- MOCK UP · CEL-02
-- ¿Por qué no tengo caso para evaluarlo con el ejemplo del HTML?
--   · El ejemplo de prefijos (310 vs 999) es smoke lab, no id_buro.
--   · Caso A ({A['id']}) y Caso B ({B['id']}) casi no tienen filas CEL
--     (cobertura CEL en DEV ~258 scores vs ~410k DIR).
-- ============================================================

-- Check REAL: ¿A/B tienen CEL? (si n=0 → confirmas que no hay caso)
SELECT id_buro_persona, cod_dw_persona_ubic AS rpu, score, lugar
FROM bdm_datos.score_ordenamiento
WHERE canal = 'CEL'
  AND id_buro_persona IN ({A['id']}, {B['id']});
-- Esperado típico: 0 filas → no puedes evaluar CEL-02 con estos IDs.
-- Cobertura global CEL (contexto):
SELECT COUNT(*) AS n_cel FROM bdm_datos.score_ordenamiento WHERE canal = 'CEL';""",
            )

        elif code == "ORD-EMA-03":
            row["_fuente"] = "MOCK"
            row["_id_ejemplo"] = "MOCK UP · sin contrafactual EMA003/007 en DEV"
            row["_ejemplo_label"] = (
                "MOCK UP · exclusión por código; Caso A muestra EMA real pero no prueba 003/007"
            )
            row["_tabla_ejemplo"] = {
                "title": "MOCK UP · EMA-03 variables fuera del SUM — regla, no A/B test",
                "headers": ["Variable", "¿Suma?", "¿Es evidencia persona?", "Nota"],
                "rows": [
                    ["EMA003", "No ✗", "NO — MOCK UP", "excluida en SP"],
                    ["EMA007", "No ✗", "NO — MOCK UP", "excluida en SP"],
                    ["EMA018 / EMA025", "No ✗", "NO — MOCK UP", "hardcoded 0"],
                    [
                        f"EMA Caso A ({A['id']})",
                        f"{A['ema']:.4f}",
                        "REAL score",
                        "Foto actual; NO demuestra aislamiento 003/007",
                    ],
                ],
            }
            set_q(
                row,
                f"""-- ============================================================
-- MOCK UP · EMA-03
-- ¿Por qué no tengo caso para evaluarlo como en la tabla de exclusión?
--   · Haría falta cambiar solo EMA003/007 y ver que el score NO se mueve.
--   · Ese contrafactual no está cargado como persona DEV de prueba.
--   · Caso A SÍ tiene score EMA REAL, pero es una sola foto (no prueba la exclusión).
-- ============================================================

-- Check REAL de betas (estructura; no es el A/B test de persona):
SELECT codigo_variable, valor_beta
FROM bdm_datos.beta_ordenamiento
WHERE canal = 'EMA'
  AND (
    codigo_variable ILIKE '%EMA003%'
    OR codigo_variable ILIKE '%EMA007%'
    OR codigo_variable ILIKE '%EMA018%'
    OR codigo_variable ILIKE '%EMA025%'
  );

-- Score EMA REAL Caso A (referencia; NO demuestra EMA-03):
SELECT canal, cod_dw_persona_ubic AS rpu, score, lugar
FROM bdm_datos.score_ordenamiento
WHERE id_buro_persona = {A['id']}
  AND canal = 'EMA';
-- Esperado: RPU {A['padre']} score {A['ema']:.4f} lugar 1""",
            )

        elif code in ("ORD-FLUJO", "ORD-SP-ORQ"):
            row["_fuente"] = "REAL"
            row["_id_ejemplo"] = f"id_buro_persona = {A['id']} (y Caso B {B['id']})"
            row["_ejemplo_label"] = "REAL · tras el CALL, valida los mismos IDs del ejemplo"
            set_q(
                row,
                f"""-- REAL · validar los ejemplos del HTML (no hace falta re-ejecutar el CALL)
-- Caso A (tabla F3 / TEL):
SELECT canal, cod_dw_persona_ubic AS rpu, score, lugar
FROM bdm_datos.score_ordenamiento
WHERE id_buro_persona = {A['id']}
ORDER BY canal, lugar;

-- Caso B (tabla RANK-01 / salida):
SELECT canal, cod_dw_persona_ubic AS rpu, score, lugar
FROM bdm_datos.score_ordenamiento
WHERE id_buro_persona = {B['id']}
  AND canal = 'DIR'
ORDER BY lugar;

-- Solo si tienes permiso de corrida (opcional):
-- CALL bdm_datos.sp_ordenamiento_ejecucion_edf(TRUE);""",
            )

        elif code == "ORD-VAL":
            row["_fuente"] = "REAL"
            row["_id_ejemplo"] = f"Gates con IDs REAL · A={A['id']} · B={B['id']}"
            row["_ejemplo_label"] = "REAL · cada check apunta al ejemplo correspondiente"
            set_q(
                row,
                f"""-- REAL · matriz del HTML con los mismos IDs de ejemplo
-- F3-02 (Caso A hija sin score):
SELECT COUNT(*) AS scores_hija_3
FROM bdm_datos.score_ordenamiento WHERE cod_dw_persona_ubic = {A['hija']};
-- Esperado: 0

-- RANK-01 (Caso B dos DIR):
SELECT rpu, score, lugar FROM (
  SELECT cod_dw_persona_ubic AS rpu, score, lugar
  FROM bdm_datos.score_ordenamiento
  WHERE id_buro_persona = {B['id']} AND canal = 'DIR'
) q ORDER BY lugar;
-- Esperado: {B['rpu1']} lugar1 · {B['rpu2']} lugar2

-- TEL-02 / EMA-03 / CEL-02: ver escenarios MOCK UP (no hay persona A/B test).""",
            )

        elif code == "ORD-F1-BETA":
            row["_fuente"] = "REAL"
            row["_id_ejemplo"] = "REAL · catálogo beta_ordenamiento (47)"
            row["_ejemplo_label"] = "REAL · conteo por canal = lo que dice el ejemplo de betas"
            set_q(
                row,
                """-- REAL · mismo catálogo del ejemplo de betas
SELECT canal, COUNT(*) AS n_betas
FROM bdm_datos.beta_ordenamiento
GROUP BY 1
ORDER BY 1;
-- Esperado: 4 canales · total 47 filas
SELECT COUNT(*) AS total_betas FROM bdm_datos.beta_ordenamiento;""",
            )

        elif code == "ORD-F1-RPU":
            row["_fuente"] = "REAL"
            row["_id_ejemplo"] = f"REAL · elegibilidad + Caso A hija {A['hija']}"
            row["_ejemplo_label"] = "REAL · conteos + ejemplo hija excluida"
            set_q(
                row,
                f"""-- REAL · ganadoras vs hijas (regla de la tabla)
SELECT
  SUM(CASE WHEN COALESCE(ind_unificacion,0) <> 1 THEN 1 ELSE 0 END) AS ganadoras,
  SUM(CASE WHEN ind_unificacion = 1 THEN 1 ELSE 0 END) AS hijas
FROM bdm_datos.unificacion_direccion;
-- Nota: unificacion_direccion guarda pares; para staging post-unif usa stg si existe.

-- Ejemplo REAL de la tabla (hija no puntúa):
SELECT COUNT(*) AS scores_hija
FROM bdm_datos.score_ordenamiento
WHERE cod_dw_persona_ubic = {A['hija']};
-- Esperado: 0  (id_buro dueño del padre = {A['id']})""",
            )

        elif code in ("ORD-ALCANCE", "ORD-F1-CT", "ORD-F3-BLOQ", "ORD-BITBUCKET", "ORD-SP-PREP"):
            # Conceptual / gates — keep REAL aggregate but label clearly
            row["_fuente"] = "REAL"
            if not (row.get("_id_ejemplo") or "").startswith("REAL"):
                row["_id_ejemplo"] = f"REAL · gate DEV (ref. ejemplos A={A['id']} B={B['id']})"
            row["_ejemplo_label"] = (
                row.get("_ejemplo_label")
                or "REAL · conteo/catálogo DEV (no es una sola persona de la tabla conceptual)"
            )
            if code == "ORD-SP-PREP":
                set_q(
                    row,
                    f"""-- REAL · insumos (si staging vive) + ejemplos persona
SELECT COUNT(*) AS n FROM bdm_tempo.stg_insumo_direccion;
-- Si staging ya se dropeó, valida resultado final:
SELECT canal, COUNT(*) FROM bdm_datos.score_ordenamiento GROUP BY 1 ORDER BY 1;
-- Persona del ejemplo RANK:
SELECT COUNT(*) AS n_dir_caso_b
FROM bdm_datos.score_ordenamiento
WHERE id_buro_persona = {B['id']} AND canal = 'DIR';
-- Esperado: 2""",
                )
            elif not (row.get("Query validación (copiar en dba_rncr_batch)") or "").strip():
                set_q(
                    row,
                    """-- REAL · volumen por canal (contexto del mapa)
SELECT canal, COUNT(*) AS n, MIN(score) AS mn, MAX(score) AS mx
FROM bdm_datos.score_ordenamiento
GROUP BY 1 ORDER BY 1;""",
                )


def patch_render_chip(html: str) -> str:
    """Clarify REAL vs MOCK UP in the visible chip."""
    # Update the helper text inside idBlock if present
    old_bits = [
        (
            "${fuente === 'MOCK' ? 'No hay caso DEV confirmado → usa la query MOCK / búsqueda del botón Ver query.' : 'Query del botón Ver query → filas reales en dba_rncr_batch.'}",
            "${fuente === 'MOCK' ? 'MOCK UP: la tabla NO es evidencia DEV. La query explica por qué no hay caso y qué check puedes correr.' : 'REAL: la query debe devolver las mismas filas/números de la tabla del ejemplo.'}",
        ),
        (
            "Fuente de datos · ${fuente}",
            "Fuente · ${fuente === 'MOCK' ? 'MOCK UP' : 'REAL'}",
        ),
    ]
    for a, b in old_bits:
        html = html.replace(a, b)
        # escaped forms
        ae = (
            a.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
            .replace("'", "&#x27;")
        )
        be = (
            b.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
            .replace("'", "&#x27;")
        )
        html = html.replace(ae, be)
    return html


def patch_file(path: Path) -> None:
    if not path.exists():
        print("SKIP", path)
        return
    bak = path.with_suffix(path.suffix + ".bak_query_align")
    if not bak.exists():
        shutil.copy2(path, bak)
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    start = positions[1]
    while start < len(html) and html[start] in " \t\n\r":
        start += 1
    data, s0, s1 = extract_escaped_json(html, start)
    patch_rows(data)
    html = html[:s0] + dump_escaped(data) + html[s1:]
    html = patch_render_chip(html)
    path.write_text(html, encoding="utf-8")

    # verify key scenarios
    t2 = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", t2)]
    start = positions[1]
    while start < len(t2) and t2[start] in " \t\n\r":
        start += 1
    d2, _, _ = extract_escaped_json(t2, start)
    for code in ("ORD-DIR-RANK", "ORD-DIR-EMP", "ORD-TEL-02", "ORD-CEL-02", "ORD-EMA-03"):
        row = next(r for r in d2["rows"] if r.get("Escenario") == code)
        q = row["Query validación (copiar en dba_rncr_batch)"]
        print(
            path.name,
            code,
            row["_fuente"],
            "¿Por qué" in q or "Esperado" in q,
            "MOCK UP" in (row.get("_id_ejemplo") or "") or row["_fuente"] == "REAL",
        )


def main():
    for p in PATHS:
        print("===", p.name)
        patch_file(p)


if __name__ == "__main__":
    main()
