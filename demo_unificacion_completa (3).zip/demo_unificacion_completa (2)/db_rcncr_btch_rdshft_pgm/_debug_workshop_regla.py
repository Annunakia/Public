# -*- coding: utf-8 -*-
import json, re, sys
from html import unescape
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
p = Path(
    r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
    r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
)
t = unescape(p.read_text(encoding="utf-8"))


def extract_obj(s, start):
    depth = 0
    in_q = False
    esc = False
    j = start
    while j < len(s):
        ch = s[j]
        if in_q:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_q = False
        else:
            if ch == '"':
                in_q = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return json.loads(s[start : j + 1])
        j += 1


d = extract_obj(t, list(re.finditer(r"const DATA = (\{)", t))[1].start(1))
regs = {}
for r in d.get("rows") or []:
    k = r.get("_regla")
    regs.setdefault(k, []).append(r.get("_pack_code") or r.get("Escenario"))
print("row _regla values:")
for k, v in regs.items():
    print(repr(k), "->", v)

# RULE_FRAMES from script
rf = re.findall(r"regla: '([^']+)'", t.split("Mapa Ordenamiento")[1] if "Mapa Ordenamiento" in t else t)
# unescape already done - look in second half
parts = t.split("const RULE_FRAMES")
print("\nRULE_FRAMES blocks", len(parts) - 1)
last = parts[-1][:800]
print(last[:500])
print("\nreglas in last RULE_FRAMES:", re.findall(r"regla: '([^']+)'", last))
