# -*- coding: utf-8 -*-
"""Conclusiones con fundamento: se establecio / por ello (sin personas)."""
from __future__ import annotations

import json
import re
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

# Conclusiones Workshop por _pack_code
CONCL = {
    "INSUMO-CT": (
        "Se estableció el mapa contactType → canal (DIR/TEL/CEL/EMA) a partir del modelo XPM. "
        "Por ello cada contacto entra solo a su canal y no se mezcla con otro."
    ),
    "RPU-STG": (
        "Se estableció (regla F3-02 / post-unificación) que solo las RPUs ganadoras compiten; "
        "las hijas (ind_unificacion=1) quedan fuera. "
        "Por ello el padre recibe score y lugar, y la hija no aparece en el ranking."
    ),
    "BETAS": (
        "Se estableció Opción A con el catálogo de pesos RITM5226589 (47 betas). "
        "Por ello el score se arma con esos coeficientes y no con betas recalculados en la corrida."
    ),
    "DIR-RANK": (
        "Se estableció que, dentro de DIR, gana el mayor score "
        "(categoría/máximo × beta del catálogo RITM) y eso define el lugar. "
        "Por ello casa (score 850) quedó de primeras y oficina (700) de segundas."
    ),
    "ELEG-HIJA": (
        "Se estableció que la hija unificada no es contacto vigente para ordenamiento. "
        "Por ello no recibe score ni orden_prioridad, y el padre queda de primeras entre las ganadoras."
    ),
    "ELEG-BLOQ": (
        "Se estableció que un dato no válido / bloqueado no puede quedar como mejor opción "
        "frente a uno válido del mismo canal. "
        "Por ello el contacto válido queda de primeras."
    ),
    "DIR-EMPATE": (
        "Se estableció que, si dos DIR empatan en score, no se agrega un desempate de negocio nuevo; "
        "solo aplica el orden técnico (ROW_NUMBER). "
        "Por ello ambos reciben lugar 1 y 2 sin una regla extra de preferencia."
    ),
    "TEL-RANK": (
        "Se estableció que TEL es independiente de DIR y que, en el mismo canal, "
        "el fijo válido tiene prioridad sobre el no válido. "
        "Por ello el teléfono válido quedó de primeras en el ranking TEL."
    ),
    "TEL-02": (
        "Se estableció (criterio TEL-02, alineado a la fórmula documentada) que TEL020 "
        "puede calcularse para trazabilidad pero no entra a la sumatoria del score. "
        "Por ello ambos teléfonos quedan con el mismo score y el ranking no se mueve por geo."
    ),
    "CEL-02": (
        "Se estableció (criterio CEL-02) que el operador sale del prefijo y, "
        "si no está en el catálogo, aplica el default 0.22. "
        "Por ello el celular con prefijo 999 queda con score 220 y lugar 1."
    ),
    "EMA-03": (
        "Se estableció (criterio EMA-03) que variables como EMA003/007/018/025 "
        "pueden calcularse para trazabilidad pero no entran a la sumatoria. "
        "Por ello no mueven el score de email y el orden relativo no cambia."
    ),
    "CONSOL": (
        "Se estableció que solo el canal DIR escribe la salida de negocio: "
        "orden_prioridad = lugar DIR de cada RPU ganadora. "
        "Por ello el lugar 1 de dirección queda de primeras en el orden de intento en calle."
    ),
    "DROP": (
        "Se estableció que al cerrar la corrida se limpia el staging (DROP stg_*) "
        "y la salida de negocio se conserva. "
        "Por ello las tablas temporales no quedan, y orden_prioridad sigue disponible."
    ),
}

# Demo: resultado por (id, canal) o pregunta clave
DEMO_RES = {
    ("20011", "DIR"): (
        "Se estableció que la hija unificada no compite (F3-02). "
        "Por ello solo el padre tiene score y queda de primeras; la hija no entra al orden."
    ),
    ("Insumo", "Fase 1"): (
        "Se estableció el mapa contactType XPM → canal y el filtro de solo ganadoras. "
        "Por ello cada tipo entra a su canal correcto y las hijas no compiten."
    ),
    ("20001", "DIR"): (
        "Se estableció que el mayor score DIR (pesos del catálogo RITM) define el lugar. "
        "Por ello casa quedó de primeras (850) y oficina de segundas (700)."
    ),
    ("20010", "DIR"): (
        "Se estableció que ante empate de score no hay desempate de negocio nuevo. "
        "Por ello ambos reciben lugares 1 y 2 solo por orden técnico."
    ),
    ("20004", "TEL"): (
        "Se estableció que en TEL el contacto válido tiene prioridad sobre el no válido. "
        "Por ello el fijo válido quedó de primeras."
    ),
    ("20013", "TEL"): (
        "Se estableció que TEL020 no entra a la sumatoria del score. "
        "Por ello ambos quedan con el mismo score y el ranking no cambia."
    ),
    ("20012", "CEL"): (
        "Se estableció el default de operador 0.22 cuando el prefijo no está en catálogo. "
        "Por ello ese celular queda con score 220 y de primeras en CEL."
    ),
    ("20001", "Guardar"): (
        "Se estableció que orden_prioridad copia el lugar DIR de las ganadoras. "
        "Por ello el RPU de lugar 1 queda de primeras en el orden de intento en calle."
    ),
    ("DROP", "Limpiar"): (
        "Se estableció la limpieza de staging al cerrar la corrida. "
        "Por ello stg_* se eliminan y la salida orden_prioridad se conserva."
    ),
}


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def patch_data(data: dict) -> None:
    n = 0
    for r in data.get("rows") or []:
        code = r.get("_pack_code")
        if code in CONCL:
            txt = CONCL[code]
            r["_conclusion"] = txt
            r["_conclusion_regla"] = txt
            n += 1
    for b in data.get("presentacion") or []:
        for c in b.get("casos") or []:
            key = (str(c.get("id") or ""), str(c.get("canal") or ""))
            if key in DEMO_RES:
                c["resultado"] = DEMO_RES[key]
                n += 1
            else:
                # fallback by pregunta
                q = (c.get("pregunta") or "").lower()
                for (i, can), txt in DEMO_RES.items():
                    if i.lower() in q or (can.lower() in q and i in str(c.get("id"))):
                        pass
    print(f"  conclusions updated: {n}")


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    patch_data(data)
    html = html[:start] + to_html_json(data) + html[end:]
    path.write_text(html, encoding="utf-8")
    # sample
    sample = next(r for r in data["rows"] if r.get("_pack_code") == "DIR-RANK")
    print("OK", path.name)
    print("  DIR-RANK:", sample["_conclusion"][:120], "...")


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
