# -*- coding: utf-8 -*-
"""Separa Fase 3 (guardar) y Fase 4 (limpiar) en Workshop."""
from __future__ import annotations

import copy
import json
import re
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

FRAME_FASE4 = """&lt;div class=&quot;frame frame-off&quot; id=&quot;frame-fase4&quot;&gt;
      &lt;div class=&quot;frame-fit rule-frame&quot;&gt;
      &lt;div class=&quot;frame-title&quot;&gt;Fase 4 — Limpiar staging&lt;/div&gt;
      &lt;div class=&quot;frame-sub&quot;&gt;DROP stg_* · la siguiente corrida parte limpia&lt;/div&gt;
      &lt;div class=&quot;rule-layout&quot;&gt;
        &lt;aside class=&quot;scenario-nav&quot; id=&quot;nav-fase4&quot;&gt;&lt;/aside&gt;
        &lt;div class=&quot;scenario-stage&quot; id=&quot;stage-fase4&quot;&gt;&lt;/div&gt;
      &lt;/div&gt;
      &lt;/div&gt;
    &lt;/div&gt;
"""

OLD_WS = """const WORKSHOP_STEPS = [
  { label: &#x27;Fase 1 · Insumos&#x27;, el: &#x27;frame-fase1&#x27;, ruleIdx: 1 },
  { label: &#x27;Fase 2 · DIR&#x27;, el: &#x27;frame-dir&#x27;, ruleIdx: 2 },
  { label: &#x27;Fase 2 · TEL&#x27;, el: &#x27;frame-tel&#x27;, ruleIdx: 3 },
  { label: &#x27;Fase 2 · CEL&#x27;, el: &#x27;frame-cel&#x27;, ruleIdx: 4 },
  { label: &#x27;Fase 2 · EMA&#x27;, el: &#x27;frame-ema&#x27;, ruleIdx: 5 },
  { label: &#x27;Fase 3–4 · Salida&#x27;, el: &#x27;frame-salida&#x27;, ruleIdx: 6 },
];"""

NEW_WS = """const WORKSHOP_STEPS = [
  { label: &#x27;Fase 1 · Insumos&#x27;, el: &#x27;frame-fase1&#x27;, ruleIdx: 1 },
  { label: &#x27;Fase 2 · DIR&#x27;, el: &#x27;frame-dir&#x27;, ruleIdx: 2 },
  { label: &#x27;Fase 2 · TEL&#x27;, el: &#x27;frame-tel&#x27;, ruleIdx: 3 },
  { label: &#x27;Fase 2 · CEL&#x27;, el: &#x27;frame-cel&#x27;, ruleIdx: 4 },
  { label: &#x27;Fase 2 · EMA&#x27;, el: &#x27;frame-ema&#x27;, ruleIdx: 5 },
  { label: &#x27;Fase 3 · Guardar&#x27;, el: &#x27;frame-salida&#x27;, ruleIdx: 6 },
  { label: &#x27;Fase 4 · Limpiar&#x27;, el: &#x27;frame-fase4&#x27;, ruleIdx: 7 },
];"""

OLD_RF = """const RULE_FRAMES = [
  null,
  { regla: &#x27;FASE 1&#x27;, nav: &#x27;nav-fase1&#x27;, stage: &#x27;stage-fase1&#x27; },
  { regla: &#x27;CANAL DIR&#x27;, nav: &#x27;nav-dir&#x27;, stage: &#x27;stage-dir&#x27; },
  { regla: &#x27;CANAL TEL&#x27;, nav: &#x27;nav-tel&#x27;, stage: &#x27;stage-tel&#x27; },
  { regla: &#x27;CANAL CEL&#x27;, nav: &#x27;nav-cel&#x27;, stage: &#x27;stage-cel&#x27; },
  { regla: &#x27;CANAL EMA&#x27;, nav: &#x27;nav-ema&#x27;, stage: &#x27;stage-ema&#x27; },
  { regla: &#x27;CONSOLIDACIÓN&#x27;, nav: &#x27;nav-salida&#x27;, stage: &#x27;stage-salida&#x27; },
];"""

NEW_RF = """const RULE_FRAMES = [
  null,
  { regla: &#x27;FASE 1&#x27;, nav: &#x27;nav-fase1&#x27;, stage: &#x27;stage-fase1&#x27; },
  { regla: &#x27;CANAL DIR&#x27;, nav: &#x27;nav-dir&#x27;, stage: &#x27;stage-dir&#x27; },
  { regla: &#x27;CANAL TEL&#x27;, nav: &#x27;nav-tel&#x27;, stage: &#x27;stage-tel&#x27; },
  { regla: &#x27;CANAL CEL&#x27;, nav: &#x27;nav-cel&#x27;, stage: &#x27;stage-cel&#x27; },
  { regla: &#x27;CANAL EMA&#x27;, nav: &#x27;nav-ema&#x27;, stage: &#x27;stage-ema&#x27; },
  { regla: &#x27;CONSOLIDACIÓN&#x27;, nav: &#x27;nav-salida&#x27;, stage: &#x27;stage-salida&#x27; },
  { regla: &#x27;LIMPIEZA&#x27;, nav: &#x27;nav-fase4&#x27;, stage: &#x27;stage-fase4&#x27; },
];"""


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def sp_brief(sps_by, sid: str) -> dict | None:
    sp = sps_by.get(sid)
    if not sp:
        return None
    return {
        "id": sid,
        "archivo": sp.get("archivo"),
        "objetivo": sp.get("objetivo") or sp.get("pregunta") or sp.get("rol"),
        "accion": sp.get("accion") or sp.get("logica"),
        "resultado": sp.get("resultado") or sp.get("ejemplo"),
        "por_que": sp.get("por_que") or "",
    }


def patch_data(data: dict) -> None:
    sps_by = {s.get("id"): s for s in (data.get("sps_detalle") or [])}
    rows = data.get("rows") or []
    consol = next((r for r in rows if r.get("_pack_code") == "CONSOL"), None)
    if not consol:
        print("  WARN no CONSOL row")
        return

    # Fase 3 = guardar
    consol["_regla"] = "CONSOLIDACIÓN"
    consol["_pack_code"] = "CONSOL"
    consol["_titulo_corto"] = "Fase 3 — Guardar orden_prioridad"
    consol["Subescenario"] = consol["_titulo_corto"]
    consol["_esc_codigo"] = "ORD-F3"
    consol["Escenario"] = "ORD-F3"
    consol["_busca"] = (
        "Fase 3: el lugar DIR de cada RPU ganadora se persiste como orden_prioridad. Las hijas no reciben fila."
    )
    consol["_dev"] = (
        "Primero abrimos la consolidación de 20001. Aquí vemos orden_prioridad casa=1 y oficina=2, "
        "igual que el lugar DIR. Con eso ya nos aseguramos de que el orden quedó guardado."
    )
    consol["_conclusion"] = "Fase 3: orden_prioridad = lugar DIR en ganadoras."
    consol["_conclusion_regla"] = consol["_conclusion"]
    consol["_ejemplo_label"] = "Fase 3 · orden_prioridad"
    sp09 = sp_brief(sps_by, "SP-09")
    consol["_sps_relacionados"] = [sp09] if sp09 else []
    consol["_tabla_pasos"] = {
        "title": "Fase 3 — Guardar · persona 20001",
        "headers": ["Paso", "Qué abrimos", "Qué vemos / nos aseguramos"],
        "rows": [
            ["1", "Partimos del ranking DIR (casa 1 / oficina 2).", "mock_ord_score canal DIR"],
            ["2", "Ese lugar se persiste en orden_prioridad.", "mock_ord_prioridad / rpu_orden_prioridad"],
            ["3", "91001=1 y 91002=2: mismo orden que el score.", "JOIN score ↔ prioridad"],
            ["4", "Las hijas no aparecen (persona 20011).", "Sin fila para ind_unificacion=1"],
        ],
    }

    # Fase 4 = limpiar (nueva fila si no existe)
    if not any(r.get("_pack_code") == "DROP" for r in rows):
        drop = copy.deepcopy(consol)
        drop["_pack_code"] = "DROP"
        drop["_regla"] = "LIMPIEZA"
        drop["_titulo_corto"] = "Fase 4 — Limpiar staging"
        drop["Subescenario"] = drop["_titulo_corto"]
        drop["_esc_codigo"] = "ORD-F4"
        drop["Escenario"] = "ORD-F4"
        drop["_busca"] = (
            "Fase 4: al terminar la corrida se hace DROP de stg_* en bdm_tempo. La siguiente corrida parte limpia."
        )
        drop["_dev"] = (
            "Primero abrimos el cierre de staging. Aquí vemos que no deben quedar tablas stg_* de la corrida. "
            "Con eso ya nos aseguramos de que la limpieza (Fase 4) quedó hecha."
        )
        drop["_conclusion"] = "Fase 4: staging temporal eliminado; siguiente corrida recrea stg_*."
        drop["_conclusion_regla"] = drop["_conclusion"]
        drop["_ejemplo_label"] = "Fase 4 · DROP stg_*"
        drop["_id_ejemplo"] = "Evidencia · staging post-corrida"
        drop["_show_query"] = True
        sp10 = sp_brief(sps_by, "SP-10")
        drop["_sps_relacionados"] = [sp10] if sp10 else []
        drop["_tabla_ejemplo"] = {
            "title": "Tabla del caso · DROP",
            "headers": ["Objeto", "Acción", "Resultado"],
            "rows": [
                ["bdm_tempo.stg_insumo_*", "DROP", "No queda"],
                ["bdm_tempo.stg_score_*", "DROP", "No queda"],
                ["bdm_datos.rpu_orden_prioridad", "Se conserva", "Salida de Fase 3"],
            ],
        }
        drop["_tabla_pasos"] = {
            "title": "Fase 4 — Limpiar",
            "headers": ["Paso", "Qué abrimos", "Qué vemos / nos aseguramos"],
            "rows": [
                ["1", "Revisamos tablas temporales de la corrida.", "pg_tables / stg_%"],
                ["2", "Ejecutamos drop_staging.", "SP-10"],
                ["3", "Confirmamos que stg_* ya no están.", "COUNT = 0"],
                ["4", "La salida de negocio (orden_prioridad) se conserva.", "bdm_datos intacto"],
            ],
        }
        # insert after CONSOL
        idx = rows.index(consol)
        rows.insert(idx + 1, drop)
        print("  added DROP row (Fase 4)")
    else:
        print("  DROP row already present")

    data["rows"] = rows

    # fases_doc: split 3–4 if present
    fases = data.get("fases_doc") or []
    new_fases = []
    for f in fases:
        if str(f.get("fase")) in ("3–4", "3-4"):
            new_fases.append(
                {
                    "fase": "3",
                    "nombre": "Guardar orden",
                    "requiere": "Qué queda en el RPU",
                    "implementado": "consolidacion → orden_prioridad",
                    "estado": "ok",
                    "nota": "Gate: 0 hijas con orden",
                }
            )
            new_fases.append(
                {
                    "fase": "4",
                    "nombre": "Limpiar staging",
                    "requiere": "Queda basura en tempo",
                    "implementado": "drop stg_*",
                    "estado": "ok",
                    "nota": "Siguiente corrida recrea staging",
                }
            )
        else:
            new_fases.append(f)
    # ensure 3 and 4 exist
    have = {str(f.get("fase")) for f in new_fases}
    if "3" not in have:
        new_fases.append(
            {
                "fase": "3",
                "nombre": "Guardar orden",
                "requiere": "Qué queda en el RPU",
                "implementado": "consolidacion → orden_prioridad",
                "estado": "ok",
                "nota": "",
            }
        )
    if "4" not in have:
        new_fases.append(
            {
                "fase": "4",
                "nombre": "Limpiar staging",
                "requiere": "Queda basura en tempo",
                "implementado": "drop stg_*",
                "estado": "ok",
                "nota": "",
            }
        )
    data["fases_doc"] = new_fases

    # presentacion mapa: split 3–4
    for b in data.get("presentacion") or []:
        if b.get("layout") == "fase_mapa" and isinstance(b.get("fases"), list):
            fases_ui = []
            for f in b["fases"]:
                if str(f.get("fase")) in ("3–4", "3-4"):
                    fases_ui.append(
                        {
                            "fase": "3",
                            "nombre": "Guardar orden",
                            "pregunta": "Qué queda en el RPU",
                            "hecho": "consolidacion → orden_prioridad",
                        }
                    )
                    fases_ui.append(
                        {
                            "fase": "4",
                            "nombre": "Limpiar staging",
                            "pregunta": "Queda basura en tempo",
                            "hecho": "DROP stg_* al cerrar la corrida",
                        }
                    )
                else:
                    fases_ui.append(f)
            # add 3/4 if missing after previous drop
            have_f = {str(x.get("fase")) for x in fases_ui}
            if "3" not in have_f:
                fases_ui.append(
                    {
                        "fase": "3",
                        "nombre": "Guardar orden",
                        "pregunta": "Qué queda en el RPU",
                        "hecho": "consolidacion → orden_prioridad",
                    }
                )
            if "4" not in have_f:
                fases_ui.append(
                    {
                        "fase": "4",
                        "nombre": "Limpiar staging",
                        "pregunta": "Queda basura en tempo",
                        "hecho": "DROP stg_* al cerrar la corrida",
                    }
                )
            b["fases"] = fases_ui
        # text mentions
        for k in ("lead", "titulo"):
            if isinstance(b.get(k), str):
                b[k] = (
                    b[k]
                    .replace("Fase 0→1→2→3–4", "Fase 0→1→2→3→4")
                    .replace("0 → 1 → 2 → 3–4", "0 → 1 → 2 → 3 → 4")
                    .replace("3–4 Salida", "3 Guardar · 4 Limpiar")
                )
        if isinstance(b.get("bullets"), list):
            b["bullets"] = [
                x.replace("Fase 3–4 · Salida", "Fase 3 Guardar · Fase 4 Limpiar")
                .replace("3–4 Salida", "3 Guardar · 4 Limpiar")
                if isinstance(x, str)
                else x
                for x in b["bullets"]
            ]


def patch_ui(html: str) -> str:
    # Insert frame-fase4 after frame-salida block if missing
    if 'id=&quot;frame-fase4&quot;' not in html and 'id="frame-fase4"' not in html:
        # find end of frame-salida (escaped)
        marker = 'id=&quot;frame-salida&quot;'
        i = html.find(marker)
        if i < 0:
            print("  WARN no frame-salida")
        else:
            # find closing of that frame: next frame or sps after salida
            # structure: ... </div></div> then next frame
            # look for frame-sps after salida
            sps = html.find('id=&quot;frame-sps&quot;', i)
            if sps < 0:
                # insert before script / after salida's closing - find "Catálogo SP" frame
                sps = html.find("Catálogo SP", i)
            # better: after frame-salida's outer close — search for pattern ending salida stage
            end_pat = 'id=&quot;stage-salida&quot;&gt;&lt;/div&gt;'
            j = html.find(end_pat, i)
            if j > 0:
                # skip to close rule-layout, frame-fit, frame
                # after stage-salida: </div></div></div></div>
                close = "&lt;/div&gt;\n      &lt;/div&gt;\n    &lt;/div&gt;"
                k = html.find(close, j)
                if k > 0:
                    insert_at = k + len(close)
                    html = html[:insert_at] + "\n" + FRAME_FASE4 + html[insert_at:]
                    print("  frame-fase4 inserted")
                else:
                    print("  WARN close frame-salida")
            else:
                print("  WARN stage-salida")
    else:
        print("  frame-fase4 already")

    # Update salida title
    html = html.replace(
        "Fase 3–4 — Guardar orden y limpiar",
        "Fase 3 — Guardar orden_prioridad",
        1,
    )
    html = html.replace(
        "lugar → orden_prioridad · hijas = NULL · DROP stg_*",
        "lugar → orden_prioridad · hijas = NULL",
        1,
    )
    html = html.replace(
        "Workshop — por fases (1 Insumos · 2 canales · 3–4 Salida)",
        "Workshop — por fases (1 Insumos · 2 canales · 3 Guardar · 4 Limpiar)",
        1,
    )

    if OLD_WS in html:
        html = html.replace(OLD_WS, NEW_WS, 1)
        print("  WORKSHOP_STEPS split ok")
    elif "Fase 4 · Limpiar" in html:
        print("  WORKSHOP_STEPS already split")
    else:
        print("  WARN WORKSHOP_STEPS")

    if OLD_RF in html:
        idx = html.rfind(OLD_RF)
        html = html[:idx] + NEW_RF + html[idx + len(OLD_RF) :]
        print("  RULE_FRAMES + LIMPIEZA ok")
    elif "regla: &#x27;LIMPIEZA&#x27;" in html:
        print("  RULE_FRAMES already has LIMPIEZA")
    else:
        print("  WARN RULE_FRAMES")

    # scenarioPos add 7
    html = html.replace(
        "const scenarioPos = { 1:0, 2:0, 3:0, 4:0, 5:0, 6:0 };",
        "const scenarioPos = { 1:0, 2:0, 3:0, 4:0, 5:0, 6:0, 7:0 };",
        1,
    )

    # progress bar spacing for 7 steps
    html = html.replace(
        "(20 + workshopStep * 12) + &#x27;%&#x27;",
        "(15 + workshopStep * 11) + &#x27;%&#x27;",
        1,
    )

    # KPI cascade card text if present
    html = html.replace(
        "{ title: &#x27;3–4 · Guardar y limpiar&#x27;, tag: &#x27;orden_prioridad&#x27;, desc: &#x27;lugar 1 → orden 1. Hijas NULL. Luego DROP stg_*.&#x27;, dev: `${fmt(k.rpu_con_orden)} RPUs`, frame: 6 },",
        "{ title: &#x27;3 · Guardar&#x27;, tag: &#x27;orden_prioridad&#x27;, desc: &#x27;lugar 1 → orden 1. Hijas NULL.&#x27;, dev: `${fmt(k.rpu_con_orden)} RPUs`, frame: 6 },\n    { title: &#x27;4 · Limpiar&#x27;, tag: &#x27;DROP stg_*&#x27;, desc: &#x27;Staging temporal eliminado al cerrar.&#x27;, dev: `bdm_tempo`, frame: 7 },",
        1,
    )
    return html


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    patch_data(data)
    html = html[:start] + to_html_json(data) + html[end:]
    html = patch_ui(html)
    path.write_text(html, encoding="utf-8")

    t = unescape(path.read_text(encoding="utf-8"))
    labs = re.findall(r"label: '([^']+)'", t.split("const WORKSHOP_STEPS")[-1][:900])
    packs = [r.get("_pack_code") for r in data["rows"] if r.get("_regla") in ("CONSOLIDACIÓN", "LIMPIEZA")]
    print("OK", path.name, "steps", labs[-7:], "packs", packs)
    a = html.find('iframe title="Mapa Ordenamiento"')
    sd = html.find('srcdoc="', a)
    end_i = html.find('"></iframe>', sd)
    print("  srcdoc quotes", html[sd:end_i].count('"'), "frame-fase4", "frame-fase4" in html[sd:end_i])


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
