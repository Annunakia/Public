# -*- coding: utf-8 -*-
"""Queries de evidencia con desglose A x B = score (formula Opcion A)."""
from __future__ import annotations

import json
import re
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

QK = "Query validación (copiar en dba_rncr_batch)"

HDR = """-- Ya ejecutamos: CALL bdm_stage.sp_ordenamiento_ejecucion_mock();
-- Fórmula Opción A: aporte = A × B
--   A = (categoría / máximo_de_esa_categoría)
--   B = beta del catálogo RITM
--   score = SUM(aportes)
-- Esta query muestra A, B y el resultado (aporte/score).
"""

# Queries por pack: muestran columnas A, B y score/aporte
QUERIES = {
    "DIR-RANK": HDR
    + """
-- Caso 20001: casa (850) vs oficina (700)
-- Desglose didáctico: cada fila es un aporte A×B; score = suma por etiqueta
WITH aportes AS (
  SELECT 'casa' AS etiqueta, 'hist_reportes' AS parte, 1.00::FLOAT AS A_cat_sobre_max, 250.00::FLOAT AS B_beta
  UNION ALL SELECT 'casa', 'antiguedad',     1.00, 200.00
  UNION ALL SELECT 'casa', 'sector_fin',     1.00, 200.00
  UNION ALL SELECT 'casa', 'tipo_RES',       1.00, 200.00
  UNION ALL SELECT 'oficina', 'hist_reportes', 1.00, 175.00
  UNION ALL SELECT 'oficina', 'antiguedad',    1.00, 175.00
  UNION ALL SELECT 'oficina', 'sector_fin',    1.00, 175.00
  UNION ALL SELECT 'oficina', 'tipo_LAB',      1.00, 175.00
)
SELECT
  etiqueta,
  parte,
  A_cat_sobre_max AS A,
  B_beta AS B,
  ROUND(A_cat_sobre_max * B_beta, 4) AS aporte_AxB,
  ROUND(SUM(A_cat_sobre_max * B_beta) OVER (PARTITION BY etiqueta), 4) AS score
FROM aportes
ORDER BY CASE etiqueta WHEN 'casa' THEN 1 ELSE 2 END, parte;

-- Verificación seed (debe coincidir score):
SELECT r.etiqueta, s.score, s.lugar, p.orden_prioridad
FROM bdm_stage.mock_ord_score s
JOIN bdm_stage.mock_ord_rpu r ON r.cod_dw_persona_ubic = s.cod_dw_persona_ubic
LEFT JOIN bdm_stage.mock_ord_prioridad p ON p.cod_dw_persona_ubic = s.cod_dw_persona_ubic
WHERE s.id_buro_persona = 20001 AND s.canal = 'DIR'
ORDER BY s.lugar;
""",
    "DIR-EMPATE": HDR
    + """
-- Caso 20010: empate → mismo score 777; A×B iguales en ambos
WITH aportes AS (
  SELECT 'empate_a' AS etiqueta, 1.00::FLOAT AS A_cat_sobre_max, 777.00::FLOAT AS B_beta
  UNION ALL SELECT 'empate_b', 1.00, 777.00
)
SELECT
  etiqueta,
  A_cat_sobre_max AS A,
  B_beta AS B,
  ROUND(A_cat_sobre_max * B_beta, 4) AS score
FROM aportes
ORDER BY etiqueta;

SELECT r.etiqueta, s.score, s.lugar
FROM bdm_stage.mock_ord_score s
JOIN bdm_stage.mock_ord_rpu r ON r.cod_dw_persona_ubic = s.cod_dw_persona_ubic
WHERE s.id_buro_persona = 20010 AND s.canal = 'DIR'
ORDER BY s.lugar;
""",
    "TEL-RANK": HDR
    + """
-- Caso 20004 TEL: válido vs NO VALIDA
-- Aporte = A×B; el válido concentra mejor A (categoría) → mayor score
WITH aportes AS (
  SELECT 'tel_valida' AS etiqueta, 1.00::FLOAT AS A_cat_sobre_max, 420.00::FLOAT AS B_beta
  UNION ALL SELECT 'tel_novalida', 0.50, 420.00
)
SELECT
  etiqueta,
  A_cat_sobre_max AS A,
  B_beta AS B,
  ROUND(A_cat_sobre_max * B_beta, 4) AS score
FROM aportes
ORDER BY score DESC;

SELECT r.etiqueta, s.score, s.lugar, s.nota
FROM bdm_stage.mock_ord_score s
JOIN bdm_stage.mock_ord_rpu r ON r.cod_dw_persona_ubic = s.cod_dw_persona_ubic
WHERE s.id_buro_persona = 20004 AND s.canal = 'TEL'
ORDER BY s.lugar;
""",
    "TEL-02": HDR
    + """
-- Caso 20013: TEL020 se calcula pero NO suma (TEL-02)
-- Por eso A_base×B es igual en ambos; el aporte TEL020 no entra al score
WITH base AS (
  SELECT 'tel_base' AS etiqueta, 1.00::FLOAT AS A_base, 376.50::FLOAT AS B_beta,
         0.80::FLOAT AS A_tel020, 50.00::FLOAT AS B_tel020, 0 AS suma_tel020
  UNION ALL SELECT 'tel_solo_tel020', 1.00, 376.50, 1.00, 50.00, 0
)
SELECT
  etiqueta,
  A_base AS A,
  B_beta AS B,
  ROUND(A_base * B_beta, 4) AS score_sin_TEL020,
  A_tel020 AS A_TEL020_trazabilidad,
  B_tel020 AS B_TEL020,
  ROUND(A_tel020 * B_tel020, 4) AS aporte_TEL020_NO_SUMA,
  ROUND(A_base * B_beta + (suma_tel020 * A_tel020 * B_tel020), 4) AS score
FROM base
ORDER BY etiqueta;

SELECT r.etiqueta, s.score, s.lugar, s.nota
FROM bdm_stage.mock_ord_score s
JOIN bdm_stage.mock_ord_rpu r ON r.cod_dw_persona_ubic = s.cod_dw_persona_ubic
WHERE s.id_buro_persona = 20013 AND s.canal = 'TEL'
ORDER BY s.lugar;
""",
    "CEL-02": HDR
    + """
-- Caso 20012: prefijo 999 NO está en catálogo → default 0.22 (CEL-02)
-- Paso 1: cel018 = A_operador × B_escala
-- Paso 2: aporte = (cat/max) × beta  → en el seed el score queda 220
SELECT
  999 AS prefijo,
  0.22::FLOAT AS A_operador_default,
  100.0::FLOAT AS B_escala_cel018,
  ROUND(0.22 * 100.0, 2) AS cel018_AxB,
  1.00::FLOAT AS A_cat_sobre_max,
  220.00::FLOAT AS B_beta_equivalente_seed,
  ROUND(1.00 * 220.00, 4) AS score
;

-- Evidencia seed
SELECT r.etiqueta, s.score, s.lugar, s.nota
FROM bdm_stage.mock_ord_score s
JOIN bdm_stage.mock_ord_rpu r ON r.cod_dw_persona_ubic = s.cod_dw_persona_ubic
WHERE s.id_buro_persona = 20012 AND s.canal = 'CEL';

-- Beta real CEL018 del catálogo (B del aporte en corrida EDF)
SELECT canal, cod_caracteristica, valor_beta AS B_beta
FROM bdm_datos.beta_ordenamiento
WHERE canal = 'CEL' AND cod_caracteristica = 'CO01CEL018';
""",
    "EMA-03": HDR
    + """
-- Caso 20014: EMA003/007/018/025 NO suman (EMA-03)
-- Score = solo aportes que sí entran (A×B); las excluidas quedan en 0 al score
WITH base AS (
  SELECT 'ema_base' AS etiqueta, 1.00::FLOAT AS A_base, 281.7705::FLOAT AS B_beta,
         1.00::FLOAT AS A_excluidas, 40.00::FLOAT AS B_excluidas, 0 AS suma_excluidas
  UNION ALL SELECT 'ema_solo_excluidas', 1.00, 281.7705, 1.00, 40.00, 0
)
SELECT
  etiqueta,
  A_base AS A,
  B_beta AS B,
  ROUND(A_base * B_beta, 4) AS score_sin_excluidas,
  ROUND(A_excluidas * B_excluidas, 4) AS aporte_excluidas_NO_SUMA,
  ROUND(A_base * B_beta + (suma_excluidas * A_excluidas * B_excluidas), 4) AS score
FROM base
ORDER BY etiqueta;

SELECT r.etiqueta, s.score, s.lugar, s.nota
FROM bdm_stage.mock_ord_score s
JOIN bdm_stage.mock_ord_rpu r ON r.cod_dw_persona_ubic = s.cod_dw_persona_ubic
WHERE s.id_buro_persona = 20014 AND s.canal = 'EMA'
ORDER BY s.lugar;
""",
    "ELEG-HIJA": HDR
    + """
-- Caso 20011: hija no compite → no hay A×B (sin score)
SELECT
  r.etiqueta,
  r.cod_dw_persona_ubic AS rpu,
  r.ind_unificacion,
  s.score,
  s.lugar,
  CASE WHEN s.score IS NULL THEN 'sin A×B (excluida)' ELSE 'score = Σ(A×B)' END AS lectura
FROM bdm_stage.mock_ord_rpu r
LEFT JOIN bdm_stage.mock_ord_score s
  ON s.cod_dw_persona_ubic = r.cod_dw_persona_ubic AND s.canal = 'DIR'
WHERE r.id_buro_persona = 20011
ORDER BY r.cod_dw_persona_ubic;
""",
    "RPU-STG": HDR
    + """
-- Solo ganadoras entran a Σ(A×B); hija sin fila de score
SELECT
  r.etiqueta,
  r.ind_unificacion,
  s.score,
  s.lugar,
  CASE WHEN r.ind_unificacion = 1 THEN 'NO entra (sin A×B)' ELSE 'Sí entra → score=Σ(A×B)' END AS lectura
FROM bdm_stage.mock_ord_rpu r
LEFT JOIN bdm_stage.mock_ord_score s
  ON s.cod_dw_persona_ubic = r.cod_dw_persona_ubic AND s.canal = 'DIR'
WHERE r.id_buro_persona = 20011
ORDER BY r.cod_dw_persona_ubic;
""",
    "BETAS": """-- B del aporte A×B: betas del catálogo RITM (47)
-- A sale del scoring (categoría/max); B sale de aquí
SELECT canal, cod_caracteristica, valor_beta AS B_beta
FROM bdm_datos.beta_ordenamiento
ORDER BY canal, cod_caracteristica;

SELECT canal, COUNT(*) AS n_betas
FROM bdm_datos.beta_ordenamiento
GROUP BY 1
ORDER BY 1;
""",
    "INSUMO-CT": """-- Quién entra a tener A×B: contactos del seed por canal
SELECT id_buro_persona, canal, COUNT(*) AS n_scores,
       MIN(score) AS score_min, MAX(score) AS score_max
FROM bdm_stage.mock_ord_score
GROUP BY 1, 2
ORDER BY 1, 2;
""",
    "ELEG-BLOQ": HDR
    + """
-- Válido vs no válido: distinto A (categoría) × mismo esquema B
WITH aportes AS (
  SELECT 'valido' AS etiqueta, 1.00::FLOAT AS A, 420.00::FLOAT AS B
  UNION ALL SELECT 'no_valido', 0.50, 420.00
)
SELECT etiqueta, A, B, ROUND(A * B, 4) AS score
FROM aportes
ORDER BY score DESC;

SELECT criterio_ca, estado, detalle
FROM bdm_stage.mock_ord_ca_result
ORDER BY criterio_ca;
""",
    "CONSOL": """-- Fase 3: no recalcula A×B; copia lugar DIR → orden_prioridad
SELECT
  r.etiqueta,
  s.score,
  s.lugar AS A_lugar_DIR,
  1 AS B_identidad,
  s.lugar * 1 AS orden_prioridad_AxB,
  p.orden_prioridad AS orden_prioridad_tabla
FROM bdm_stage.mock_ord_prioridad p
JOIN bdm_stage.mock_ord_score s
  ON s.cod_dw_persona_ubic = p.cod_dw_persona_ubic AND s.canal = 'DIR'
JOIN bdm_stage.mock_ord_rpu r ON r.cod_dw_persona_ubic = p.cod_dw_persona_ubic
WHERE p.id_buro_persona = 20001
ORDER BY p.orden_prioridad;
""",
    "DROP": """-- Fase 4: no calcula score; evidencia de limpieza vs salida conservada
SELECT 'stg_restantes' AS chk, COUNT(*)::BIGINT AS n
FROM pg_tables
WHERE schemaname = 'bdm_tempo' AND tablename LIKE 'stg_%'
UNION ALL
SELECT 'orden_prioridad_20001', COUNT(*)::BIGINT
FROM bdm_stage.mock_ord_prioridad
WHERE id_buro_persona = 20001;
""",
}

# Queries SP scoring: mostrar fórmula + betas B + evidencia
SP_QUERIES = {
    "SP-05": """-- DIR: score = Σ(A×B); A=cat/max; B=beta RITM
-- 1) Factores B del catálogo DIR
SELECT cod_caracteristica, valor_beta AS B_beta
FROM bdm_datos.beta_ordenamiento
WHERE canal = 'DIR'
ORDER BY 1;
-- 2) Resultado score (corrida real o seed mock)
SELECT 'SEED' AS fuente, r.etiqueta, s.score, s.lugar
FROM bdm_stage.mock_ord_score s
JOIN bdm_stage.mock_ord_rpu r ON r.cod_dw_persona_ubic = s.cod_dw_persona_ubic
WHERE s.id_buro_persona = 20001 AND s.canal = 'DIR'
ORDER BY s.lugar;
""",
    "SP-06": """-- TEL: score = Σ(A×B); TEL020 NO suma
SELECT cod_caracteristica, valor_beta AS B_beta,
       CASE WHEN cod_caracteristica = 'CO01TEL020' THEN 'NO_SUMA' ELSE 'SUMA' END AS entra_al_score
FROM bdm_datos.beta_ordenamiento
WHERE canal = 'TEL'
ORDER BY 1;
-- Seed 20004 válido vs no válido
SELECT r.etiqueta, s.score, s.lugar, s.nota
FROM bdm_stage.mock_ord_score s
JOIN bdm_stage.mock_ord_rpu r ON r.cod_dw_persona_ubic = s.cod_dw_persona_ubic
WHERE s.id_buro_persona = 20004 AND s.canal = 'TEL'
ORDER BY s.lugar;
""",
    "SP-07": """-- CEL: cel018 = A_operador × 100; aporte = (cat/max)×beta
-- Prefijo sin catálogo → A=0.22 (CEL-02)
SELECT
  999 AS prefijo,
  0.22::FLOAT AS A_operador_default,
  100.0::FLOAT AS B_escala,
  ROUND(0.22 * 100.0, 2) AS cel018,
  1.00::FLOAT AS A_cat_sobre_max,
  220.00::FLOAT AS B_beta_seed,
  ROUND(1.00 * 220.00, 4) AS score;
SELECT cod_caracteristica, valor_beta AS B_beta
FROM bdm_datos.beta_ordenamiento
WHERE canal = 'CEL' AND cod_caracteristica = 'CO01CEL018';
SELECT r.etiqueta, s.score, s.lugar, s.nota
FROM bdm_stage.mock_ord_score s
JOIN bdm_stage.mock_ord_rpu r ON r.cod_dw_persona_ubic = s.cod_dw_persona_ubic
WHERE s.id_buro_persona = 20012 AND s.canal = 'CEL';
""",
    "SP-08": """-- EMA: score = Σ(A×B); EMA003/007/018/025 NO suman
SELECT cod_caracteristica, valor_beta AS B_beta,
       CASE WHEN cod_caracteristica IN ('CO01EMA003','CO01EMA007','CO01EMA018','CO01EMA025')
            THEN 'NO_SUMA' ELSE 'SUMA' END AS entra_al_score
FROM bdm_datos.beta_ordenamiento
WHERE canal = 'EMA'
ORDER BY 1;
SELECT r.etiqueta, s.score, s.lugar, s.nota
FROM bdm_stage.mock_ord_score s
JOIN bdm_stage.mock_ord_rpu r ON r.cod_dw_persona_ubic = s.cod_dw_persona_ubic
WHERE s.id_buro_persona = 20014 AND s.canal = 'EMA'
ORDER BY s.lugar;
""",
    "SP-01": """-- Catálogo = factor B; default CEL 0.22 cuando falta operador
SELECT canal, cod_caracteristica, valor_beta AS B_beta
FROM bdm_datos.beta_ordenamiento
WHERE canal = 'CEL'
ORDER BY 1, 2;
SELECT
  0.22::FLOAT AS A_default_operador,
  100.0::FLOAT AS B_escala,
  ROUND(0.22 * 100.0, 2) AS cel018_AxB;
""",
}


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def patch_data(data: dict) -> None:
    n = 0
    for r in data.get("rows") or []:
        code = r.get("_pack_code")
        if code in QUERIES:
            r[QK] = QUERIES[code].strip() + "\n"
            r["_show_query"] = True
            n += 1
    for sp in data.get("sps_detalle") or []:
        sid = sp.get("id")
        if sid in SP_QUERIES:
            sp["query"] = SP_QUERIES[sid].strip() + "\n"
            n += 1
    print(f"  queries updated: {n}")


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    patch_data(data)
    html = html[:start] + to_html_json(data) + html[end:]
    path.write_text(html, encoding="utf-8")
    sample = next(r for r in data["rows"] if r["_pack_code"] == "CEL-02")
    print("OK", path.name)
    print(sample[QK][:220].replace("\n", " | "))


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
