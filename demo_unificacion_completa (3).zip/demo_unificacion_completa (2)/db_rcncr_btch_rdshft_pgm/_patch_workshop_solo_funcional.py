# -*- coding: utf-8 -*-
"""
Workshop limpio:
- Sin decir «Opción A»: se explica esa idea en palabras + ejemplo.
- «Qué es ordenamiento»: cada idea con su ejemplo.
- Valores de corrida se mantienen.
- Oculta alcance, fases técnicas, arquitectura, banner SPs, etc. en frame-home.
"""
from __future__ import annotations

import json
import re
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

PRESENTACION = [
    {
        "titulo": "1 · Qué es el ordenamiento",
        "lead": (
            "Después de unificar, una persona puede tener varias casas, oficinas, fijos, "
            "celulares o correos. El ordenamiento solo responde: ¿cuál intento primero? "
            "Cada idea abajo trae su ejemplo al lado."
        ),
        "layout": "fases_lado_a_lado",
        "fases": [
            {
                "fase": "Idea 1",
                "nombre": "No vuelve a unificar",
                "pregunta": "¿Qué hace y qué no hace?",
                "reglas": [
                    {
                        "titulo": "En simple",
                        "texto": (
                            "El ordenamiento no mezcla de nuevo personas ni domicilios. "
                            "Parte de lo que ya quedó después de unificar: "
                            "qué domicilio sigue vigente (el que sí usamos) y cuál ya quedó absorbido "
                            "(el que ya no contactamos)."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo",
                    "caso": "Persona 20011",
                    "pasos": [
                        "Unificación ya dejó un padre (vigente) y una hija (absorbida).",
                        "El ordenamiento no ‘arregla’ eso otra vez: solo mira el padre para ordenar.",
                        "La hija no entra: no recibe puntaje ni orden de intento.",
                    ],
                    "tabla": {
                        "headers": ["Domicilio", "¿Lo usamos?", "¿Entra a ordenar?"],
                        "rows": [
                            ["Padre 91018", "Sí (vigente)", "Sí"],
                            ["Hija 91019", "No (absorbido)", "No"],
                        ],
                    },
                },
            },
            {
                "fase": "Idea 2",
                "nombre": "Ordena por tipo (no mezcla)",
                "pregunta": "¿Casa contra teléfono? No.",
                "reglas": [
                    {
                        "titulo": "En simple",
                        "texto": (
                            "Las direcciones se ordenan solo entre direcciones. "
                            "Los fijos entre fijos. Los celulares entre celulares. "
                            "Los correos entre correos. Un fijo nunca compite contra un email."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo",
                    "caso": "Persona 20001",
                    "pasos": [
                        "Tiene casa y oficina → se comparan entre sí (¿casa o oficina primero?).",
                        "Si también tuviera un fijo, ese fijo se ordenaría aparte, no contra la casa.",
                    ],
                    "tabla": {
                        "headers": ["Qué compara", "¿Contra qué?", "Resultado del ejemplo"],
                        "rows": [
                            ["Casa vs oficina", "Solo direcciones", "Casa 1º · Oficina 2º"],
                            ["Un fijo (si hubiera)", "Solo otros fijos", "No compite con la casa"],
                        ],
                    },
                },
            },
            {
                "fase": "Idea 3",
                "nombre": "Dentro del tipo, gana el mayor puntaje",
                "pregunta": "¿Cómo elige el 1º y el 2º?",
                "reglas": [
                    {
                        "titulo": "En simple",
                        "texto": (
                            "Se arma un puntaje sumando datos que aportan "
                            "(por ejemplo historial o si el fijo es válido), "
                            "cada uno multiplicado por el peso del catálogo acordado. "
                            "Más puntaje = se intenta antes (lugar 1, luego 2…)."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo",
                    "caso": "Persona 20001 · casa vs oficina",
                    "pasos": [
                        "Casa obtiene puntaje 850 → 1º.",
                        "Oficina obtiene puntaje 700 → 2º.",
                        "En campo: primero casa, después oficina.",
                    ],
                    "tabla": {
                        "headers": ["Dirección", "Puntaje", "Orden de intento"],
                        "rows": [
                            ["Casa 91001", "850", "1º"],
                            ["Oficina 91002", "700", "2º"],
                        ],
                    },
                },
            },
            {
                "fase": "Idea 4",
                "nombre": "Solo ordena domicilios que sí usamos",
                "pregunta": "¿Entran los absorbidos?",
                "reglas": [
                    {
                        "titulo": "En simple",
                        "texto": (
                            "Solo entran los domicilios vigentes (dirección ganadora = el que sí contactamos). "
                            "El absorbido (hija) no se puntúa ni se intenta."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo",
                    "caso": "Persona 20011 otra vez",
                    "pasos": [
                        "Padre vigente → sí ordena.",
                        "Hija absorbida → no aparece en puntaje ni en orden de calle.",
                    ],
                    "tabla": {
                        "headers": ["Rol", "Puntaje", "Orden"],
                        "rows": [
                            ["Padre 91018", "639.7849", "1"],
                            ["Hija 91019", "—", "—"],
                        ],
                    },
                },
            },
            {
                "fase": "Idea 5",
                "nombre": "Teléfono o correo solo si ya hay un domicilio que sí usamos",
                "pregunta": "¿Puedo ordenar un celular sin casa vigente?",
                "reglas": [
                    {
                        "titulo": "En simple",
                        "texto": (
                            "Un fijo, celular o correo solo entra a ordenar si esa persona "
                            "ya tiene al menos un domicilio vigente (uno que sí usamos). "
                            "Si no tiene ninguno, ese teléfono o correo no se puntúa ni se intenta."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo",
                    "caso": "Chequeo de entrada",
                    "pasos": [
                        "Persona con casa vigente + celular → el celular sí puede ordenarse.",
                        "Persona solo con domicilio absorbido + celular → el celular no entra.",
                        "Correo sin @ → no entra (no es usable).",
                    ],
                    "tabla": {
                        "headers": ["Situación", "¿Entra?"],
                        "rows": [
                            ["Celular con domicilio vigente", "Sí"],
                            ["Celular sin domicilio vigente", "No"],
                            ["mail_sin_arroba.com", "No"],
                        ],
                    },
                },
            },
            {
                "fase": "Idea 6",
                "nombre": "Los pesos no se inventan en la corrida",
                "pregunta": "¿De dónde sale cuánto ‘vale’ cada dato?",
                "reglas": [
                    {
                        "titulo": "En simple",
                        "texto": (
                            "Los pesos viven en un catálogo ya acordado. "
                            "La corrida los lee y arma el puntaje; no inventa coeficientes nuevos."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo",
                    "caso": "Celular y catálogo de operadores",
                    "pasos": [
                        "Prefijo 310 está en la tabla → usamos el peso de ese operador.",
                        "Prefijo 999 no está → usamos el valor por defecto acordado (0.22), "
                        "no adivinamos Claro ni Movistar.",
                    ],
                    "tabla": {
                        "headers": ["Prefijo", "¿En catálogo?", "Qué hacemos"],
                        "rows": [
                            ["310", "Sí", "Peso del operador"],
                            ["999", "No", "Valor por defecto 0.22"],
                        ],
                    },
                },
            },
            {
                "fase": "Idea 7",
                "nombre": "Al final guarda el orden para calle",
                "pregunta": "¿Qué sale a campo?",
                "reglas": [
                    {
                        "titulo": "En simple",
                        "texto": (
                            "El 1º y 2º de las direcciones se guardan como orden de intento en calle. "
                            "Los rankings de fijo, celular o correo son aparte: no escriben ese orden de calle."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo",
                    "caso": "Persona 20001",
                    "pasos": [
                        "Casa quedó 1º y oficina 2º al ordenar direcciones.",
                        "Se guarda: 91001 → intento 1; 91002 → intento 2.",
                        "Eso es lo que sale a operación.",
                    ],
                    "tabla": {
                        "headers": ["Dirección", "Lugar", "Orden guardado"],
                        "rows": [
                            ["Casa 91001", "1", "1"],
                            ["Oficina 91002", "2", "2"],
                        ],
                    },
                },
            },
            {
                "fase": "Idea 8",
                "nombre": "Cómo lo hacemos (acuerdo de mesa, en palabras)",
                "pregunta": "¿Cuál fue el acuerdo sin usar nombres raros?",
                "reglas": [
                    {
                        "titulo": "En simple",
                        "texto": (
                            "Ya terminó la unificación. Ordenamos solo domicilios vigentes "
                            "(los que sí usamos), con los pesos del catálogo acordado, "
                            "leyendo directo el resultado unificado: sin otra malla intermedia."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo de lectura",
                    "caso": "Misma lógica en los tres ejemplos del Workshop",
                    "pasos": [
                        "20001: dos vigentes → se ordenan por puntaje (casa luego oficina).",
                        "20011: vigente sí / absorbido no.",
                        "20010: dos vigentes empatan en puntaje → lugares 1 y 2 sin regla nueva de desempate.",
                    ],
                    "tabla": {
                        "headers": ["Persona", "Qué demuestra"],
                        "rows": [
                            ["20001", "Cuál domicilio primero"],
                            ["20011", "Quién entra y quién no"],
                            ["20010", "Empate de puntaje"],
                        ],
                    },
                },
            },
        ],
    },
    {
        "titulo": "2 · En qué fases se divide",
        "lead": "El mismo recorrido, de punta a punta.",
        "layout": "fase_arquitectura",
        "fases": [
            {
                "fase": "0",
                "nombre": "Ya unificado",
                "pregunta": "¿Qué domicilio sigue vigente?",
                "hecho": "Quedan los que sí usamos; los absorbidos no se contactan.",
                "arco": "Solo se lee el resultado de unificación.",
            },
            {
                "fase": "1",
                "nombre": "¿Quién entra?",
                "pregunta": "¿Qué contactos pasan a comparar?",
                "hecho": "Vigentes sí; absorbidos no; correo sin @ no; teléfono/correo piden domicilio vigente.",
                "arco": "Arma las listas por tipo.",
            },
            {
                "fase": "2",
                "nombre": "¿Cuál primero?",
                "pregunta": "¿Casa o oficina? ¿Qué fijo / celular / correo?",
                "hecho": "Dentro de cada tipo, mayor puntaje → lugar 1, 2, 3…",
                "arco": "2a direcciones · 2b fijos · 2c celulares · 2d correos.",
            },
            {
                "fase": "3",
                "nombre": "Guardar orden en calle",
                "pregunta": "¿Qué queda escrito para campo?",
                "hecho": "Solo las direcciones escriben 1º, 2º… de intento.",
                "arco": "Persiste el orden de calle.",
            },
            {
                "fase": "4",
                "nombre": "Limpiar y validar",
                "pregunta": "¿Corrida sana?",
                "hecho": "Se borran temporales; el orden se conserva; absorbidos mal ordenados = 0.",
                "arco": "Cierra la corrida.",
            },
        ],
    },
    {
        "titulo": "3 · Ejemplos del Workshop (solo estos tres)",
        "lead": "20001 → 20011 → 20010. Después de eso, no seguimos con más personas aquí.",
        "layout": "fases_lado_a_lado",
        "fases": [
            {
                "fase": "20001",
                "nombre": "Casa o oficina",
                "pregunta": "¿Cuál intento primero?",
                "reglas": [
                    {
                        "titulo": "En simple",
                        "texto": (
                            "Dos domicilios vigentes. Gana el de mayor puntaje. "
                            "Ese orden se guarda para calle."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Valores",
                    "caso": "Casa 91001 · Oficina 91002",
                    "pasos": [
                        "Casa 850 → 1º.",
                        "Oficina 700 → 2º.",
                    ],
                    "tabla": {
                        "headers": ["Dirección", "Puntaje", "Orden"],
                        "rows": [
                            ["Casa", "850", "1º"],
                            ["Oficina", "700", "2º"],
                        ],
                    },
                },
            },
            {
                "fase": "20011",
                "nombre": "Padre e hija",
                "pregunta": "¿Quién entra?",
                "reglas": [
                    {
                        "titulo": "En simple",
                        "texto": (
                            "Padre = domicilio que sí usamos. "
                            "Hija = absorbido: no puntúa ni se intenta."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Valores",
                    "caso": "Padre 91018 · Hija 91019",
                    "pasos": [
                        "Padre sí entra.",
                        "Hija no aparece en puntaje ni orden.",
                    ],
                    "tabla": {
                        "headers": ["Rol", "¿Entra?", "Puntaje / orden"],
                        "rows": [
                            ["Padre", "Sí", "639.7849 / 1"],
                            ["Hija", "No", "— / —"],
                        ],
                    },
                },
            },
            {
                "fase": "20010",
                "nombre": "Empate de puntaje",
                "pregunta": "¿Qué pasa si empatan?",
                "reglas": [
                    {
                        "titulo": "En simple",
                        "texto": (
                            "Dos vigentes con el mismo puntaje. "
                            "No inventamos regla nueva de desempate: quedan 1º y 2º por orden técnico."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Valores",
                    "caso": "91016 y 91017",
                    "pasos": [
                        "Ambos puntaje 777.",
                        "Lugares 1 y 2.",
                    ],
                    "tabla": {
                        "headers": ["RPU", "Puntaje", "Lugar"],
                        "rows": [
                            ["91016", "777", "1"],
                            ["91017", "777", "2"],
                        ],
                    },
                },
            },
        ],
    },
    {
        "titulo": "4 · Valores que tenemos (corrida real)",
        "lead": "Magnitudes de la corrida, para cerrar la mesa (sin más casos).",
        "layout": "valores",
        "valores": [
            {"label": "Personas", "valor": "407.351", "nota": "Universo de personas"},
            {
                "label": "Domicilios que sí usamos",
                "valor": "518.718",
                "nota": "Vigentes tras unificar",
            },
            {
                "label": "Domicilios absorbidos",
                "valor": "72.448",
                "nota": "No entran a ordenar",
            },
            {
                "label": "Domicilios con orden de calle",
                "valor": "410.100",
                "nota": "Ya tienen 1º, 2º…",
            },
            {
                "label": "Pesos del catálogo",
                "valor": "47",
                "nota": "Coeficientes acordados",
            },
            {
                "label": "Puntajes calculados",
                "valor": "1.227.894",
                "nota": "En la corrida DEV",
            },
            {
                "label": "Absorbidos mal ordenados",
                "valor": "0",
                "nota": "Debe ser cero",
            },
        ],
    },
]

RENDER_PRES = r"""function renderPresentacion() {
  const items = DATA.presentacion || [];
  const el = document.getElementById('presentacionWrap');
  if (!el) return;
  const tbl = (tabla) => {
    if (!tabla || !tabla.headers) return '';
    const head = tabla.headers.map(h => `<th>${esc(h)}</th>`).join('');
    const body = (tabla.rows || []).map(r =>
      `<tr>${r.map(c => `<td>${esc(String(c ?? ''))}</td>`).join('')}</tr>`
    ).join('');
    return `<div class="demo-tabla-wrap"><table class="demo-tabla"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
  };
  const mapaArq = (fases) => {
    if (!fases || !fases.length) return '';
    return `<div class="demo-fase-mapa demo-fase-arq">${fases.map((f, i) => `
      <article class="demo-fase-card">
        <div class="demo-fase-num">Fase ${esc(String(f.fase))}</div>
        <h5>${esc(f.nombre || '')}</h5>
        <p class="demo-fase-q">${esc(f.pregunta || '')}</p>
        <p class="demo-fase-h"><b>Negocio:</b> ${esc(f.hecho || '')}</p>
        <p class="demo-fase-h"><b>Cómo corre:</b> ${esc(f.arco || '')}</p>
      </article>${i < fases.length - 1 ? '<div class="demo-fase-arrow" aria-hidden="true">→</div>' : ''}`).join('')}</div>`;
  };
  const fasesLado = (b) => {
    const bloques = (b.fases || []).map(f => {
      const reglas = (f.reglas || []).map(r => `
        <div class="demo-regla-item">
          <strong>${esc(r.titulo || '')}</strong>
          <p>${esc(r.texto || '')}</p>
        </div>`).join('');
      const ej = f.ejemplo || {};
      const pasos = (ej.pasos || []).map((p, i) =>
        `<li><span class="hist-n">${i + 1}</span> ${esc(p)}</li>`
      ).join('');
      return `
      <section class="demo-fase-duo">
        <header class="demo-fase-duo-h">
          <span class="demo-fase-pill">${esc(String(f.fase))}</span>
          <div>
            <h5>${esc(f.nombre || '')}</h5>
            <p class="demo-fase-q">${esc(f.pregunta || '')}</p>
          </div>
        </header>
        <div class="demo-fase-duo-grid">
          <div class="demo-fase-col demo-fase-col-regla">
            <div class="demo-col-label">Idea</div>
            ${reglas}
          </div>
          <div class="demo-fase-col demo-fase-col-ej">
            <div class="demo-col-label">${esc(ej.titulo || 'Ejemplo')}</div>
            ${ej.caso ? `<p class="demo-ej-caso"><b>Caso:</b> ${esc(ej.caso)}</p>` : ''}
            <ol class="demo-historia">${pasos}</ol>
            ${tbl(ej.tabla)}
          </div>
        </div>
      </section>`;
    }).join('');
    return `${b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : ''}${bloques}`;
  };
  const valores = (b) => {
    const cards = (b.valores || []).map(v => `
      <article class="demo-valor-card">
        <small>${esc(v.label || '')}</small>
        <b>${esc(v.valor || '')}</b>
        <span>${esc(v.nota || '')}</span>
      </article>`).join('');
    return `${b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : ''}
      <div class="demo-valores-grid">${cards}</div>`;
  };
  el.innerHTML = items.map(b => {
    const lead = b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : '';
    const bullets = (b.bullets && b.bullets.length)
      ? `<ul class="demo-chips">${b.bullets.map(x => `<li>${esc(x)}</li>`).join('')}</ul>`
      : '';
    let body = `${lead}${bullets}`;
    if (b.layout === 'fase_arquitectura' || b.layout === 'fase_mapa') body = `${lead}${mapaArq(b.fases)}`;
    else if (b.layout === 'fases_lado_a_lado') body = fasesLado(b);
    else if (b.layout === 'valores') body = valores(b);
    return `<section class="demo-section">
      <h4>${esc(b.titulo)}</h4>
      ${body}
    </section>`;
  }).join('');
}"""

CSS_HIDE = """
/* Workshop: solo presentación funcional (sin SPs / alcance / arquitectura) */
#frame-home .doc-banner,
#frame-home #docBanner,
#frame-home .frame-fit > .drill-section:not(.demo-hero),
#frame-home #scopeGrid,
#frame-home #fasesTable,
#frame-home #archFlow,
#frame-home .scope-grid,
#frame-home .arch-flow,
#frame-home .fases-table,
#frame-home .kpi-row,
#frame-home .rules-map,
#frame-home #rulesMap,
#frame-home .glossary,
#frame-home #glossary {
  display: none !important;
  height: 0 !important;
  overflow: hidden !important;
  margin: 0 !important;
  padding: 0 !important;
  border: none !important;
}
#frame-home .demo-hero { display: block !important; }
#frame-home .presentacion-wrap { display: block !important; max-width: 1100px; }
"""

CSS_EXTRA = """
.demo-fase-duo {
  margin: 1rem 0 1.25rem; border: 1px solid #e2e8f0; border-radius: 14px;
  background: #fff; overflow: hidden;
}
.demo-fase-duo-h {
  display: flex; gap: 0.75rem; align-items: flex-start;
  padding: 0.75rem 0.9rem; background: #f1f5f9; border-bottom: 1px solid #e2e8f0;
}
.demo-fase-duo-h h5 { margin: 0 0 0.2rem; font-size: 0.95rem; color: #0f172a; }
.demo-fase-pill {
  flex: 0 0 auto; background: #1d6fdc; color: #fff; font-size: 0.72rem; font-weight: 800;
  border-radius: 999px; padding: 0.28rem 0.6rem; white-space: nowrap;
}
.demo-fase-duo-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0; }
@media (max-width: 820px) { .demo-fase-duo-grid { grid-template-columns: 1fr; } }
.demo-fase-col { padding: 0.75rem 0.9rem; }
.demo-fase-col-regla { border-right: 1px solid #e2e8f0; background: #fafbfc; }
@media (max-width: 820px) {
  .demo-fase-col-regla { border-right: none; border-bottom: 1px solid #e2e8f0; }
}
.demo-col-label {
  font-size: 0.7rem; font-weight: 800; letter-spacing: 0.04em; text-transform: uppercase;
  color: #64748b; margin-bottom: 0.55rem;
}
.demo-regla-item {
  margin: 0 0 0.55rem; padding: 0.5rem 0.6rem;
  background: #fff; border: 1px solid #e2e8f0; border-radius: 10px;
}
.demo-regla-item strong { display: block; font-size: 0.82rem; color: #0f172a; margin-bottom: 0.2rem; }
.demo-regla-item p { margin: 0; font-size: 0.78rem; line-height: 1.4; color: #334155; }
.demo-ej-caso { margin: 0 0 0.5rem; font-size: 0.8rem; color: #0f172a; }
.demo-historia {
  margin: 0.25rem 0 0.65rem; padding: 0; list-style: none;
  display: flex; flex-direction: column; gap: 0.4rem;
}
.demo-historia li {
  display: flex; gap: 0.5rem; align-items: flex-start;
  background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px;
  padding: 0.45rem 0.6rem; font-size: 0.78rem; line-height: 1.4; color: #0f172a;
}
.demo-historia .hist-n {
  flex: 0 0 1.25rem; height: 1.25rem; border-radius: 50%;
  background: #1d6fdc; color: #fff; font-size: 0.68rem; font-weight: 800;
  display: inline-flex; align-items: center; justify-content: center;
}
.demo-valores-grid {
  display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
  gap: 0.65rem; margin-top: 0.55rem;
}
.demo-valor-card {
  background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px;
  padding: 0.7rem 0.8rem; display: flex; flex-direction: column; gap: 0.2rem;
}
.demo-valor-card small { font-size: 0.72rem; color: #64748b; font-weight: 700; }
.demo-valor-card b { font-size: 1.15rem; color: #0f172a; }
.demo-valor-card span { font-size: 0.72rem; color: #475569; line-height: 1.35; }
"""


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def esc_js(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#x27;")
    )


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    data["presentacion"] = PRESENTACION
    html = html[:start] + to_html_json(data) + html[end:]

    pat = re.compile(r"function renderPresentacion\(\) \{\n.*?\n\}", re.S)
    ms = list(pat.finditer(html))
    if not ms:
        raise SystemExit("renderPresentacion not found")
    m = ms[-1]
    html = html[: m.start()] + esc_js(RENDER_PRES) + html[m.end() :]
    print("  renderPresentacion ok")

    # Clean Workshop chrome copy (no Opción A, no SPs)
    reps = [
        (
            "Ordenamiento post-unificación: ¿cuál intento primero? Opción A = solo domicilios vigentes + pesos del catálogo acordado",
            "Después de unificar: ¿cuál intento primero? Solo domicilios vigentes, con el catálogo acordado.",
        ),
        (
            "Historias de negocio: quién entra, cuál primero, Claro vs Movistar, orden en calle.",
            "Qué es el ordenamiento (con ejemplos) → fases → personas 20001 / 20011 / 20010 → valores.",
        ),
        (
            "Workshop funcional",
            "Workshop — ordenamiento en lenguaje de mesa",
        ),
        (
            "Workshop (qué es → fases → ejemplos → valores) · Demo paso a paso · SPs técnicos. Opción A = ordenar solo domicilios vigentes con el catálogo acordado.",
            "Workshop: qué es (con ejemplos) → fases → 20001 / 20011 / 20010 → valores. Demo = mismo recorrido paso a paso.",
        ),
        (
            "Primero: qué es el ordenamiento y la Opción A (en palabras). Luego las fases. Después los ejemplos 20001 → 20011 → 20010. Al final los valores de la corrida. Workshop: 20001 → 20011 → 20010 → salida.",
            "Primero qué es el ordenamiento (cada idea con ejemplo). Luego las fases. Después 20001 → 20011 → 20010. Al final los valores. Workshop: 20001 → 20011 → 20010 → salida.",
        ),
        (
            "Mapa de reunión Opción A. No es la F1 Teradata incremental (esa no corre aquí).",
            "Fases del ordenamiento en lenguaje de mesa.",
        ),
        (
            "&lt;div class=&quot;glossary-card&quot;&gt;&lt;h4&gt;Opción A (en palabras)&lt;/h4&gt;&lt;p&gt;Acuerdo de mesa: ya unificado, ordenamos solo domicilios que sí usamos (vigentes), con los pesos del catálogo acordado, sin otra malla intermedia.&lt;/p&gt;&lt;/div&gt;",
            "",
        ),
    ]
    for a, b in reps:
        if a in html:
            html = html.replace(a, b, 1)
            print("  text ok")

    # Neutralize renderDocBanner so it doesn't inject SPs into Workshop
    old_banner_fn = re.search(
        r"function renderDocBanner\(\) \{\n.*?\n\}",
        html[html.find("Mapa Ordenamiento") :],
        re.S,
    )
    if old_banner_fn:
        abs_start = html.find("Mapa Ordenamiento") + old_banner_fn.start()
        abs_end = html.find("Mapa Ordenamiento") + old_banner_fn.end()
        new_fn = esc_js(
            "function renderDocBanner() {\n"
            "  const el = document.getElementById('docBanner');\n"
            "  if (el) el.innerHTML = '';\n"
            "}"
        )
        html = html[:abs_start] + new_fn + html[abs_end:]
        print("  renderDocBanner cleared")

    oi = html.find("Mapa Ordenamiento")
    se = html.find("&lt;/style&gt;", oi)
    markers = [
        "/* Workshop: solo presentación funcional",
        "/* Workshop: fases + ejemplo al lado + valores */",
        "/* Workshop: glosario + fase con ejemplo al lado */",
    ]
    if se > 0:
        for marker in markers:
            if marker in html[oi:se]:
                prev = html.rfind(marker, oi, se)
                html = html[:prev] + html[se:]
                se = html.find("&lt;/style&gt;", oi)
        html = html[:se] + CSS_HIDE + CSS_EXTRA + html[se:]
        print("  CSS ok")

    path.write_text(html, encoding="utf-8")
    print("OK", path.name)


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
