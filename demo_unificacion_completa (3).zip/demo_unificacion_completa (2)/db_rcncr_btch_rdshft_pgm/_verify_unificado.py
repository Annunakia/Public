# -*- coding: utf-8 -*-
import sys, re, json
from html import unescape
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

p = Path(r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html")
raw = p.read_text(encoding="utf-8")
t = unescape(raw)

# second const DATA (ordenamiento)
datas = list(re.finditer(r"const DATA = (\{)", t))
print("DATA starts", len(datas))

def extract_obj(s, start_brace):
    depth = 0
    in_q = False
    esc = False
    j = start_brace
    while j < len(s):
        ch = s[j]
        if in_q:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_q = False
        else:
            if ch == '"':
                in_q = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return json.loads(s[start_brace : j + 1])
        j += 1
    raise ValueError("unbalanced")

# find second DATA - ordenamiento has demo_modo_html SEED_SP
for i, m in enumerate(datas):
    d = extract_obj(t, m.start(1))
    print(f"DATA[{i}] keys head", list(d.keys())[:8], "presentacion" in d, "rows" in d)
    if "presentacion" in d:
        pres = d["presentacion"]
        print("  presentacion len", len(pres))
        for b in pres:
            print("   -", b.get("titulo"), "casos", len(b.get("casos") or []), "bullets", len(b.get("bullets") or []))
        if any(b.get("casos") for b in pres):
            c = next(b for b in pres if b.get("casos"))["casos"][0]
            print("  first caso", c.get("id"), c.get("canal"), "tabla headers", (c.get("tabla") or {}).get("headers"))
        rows = d.get("rows") or []
        with_sps = [r for r in rows if r.get("_sps_relacionados")]
        with_tbl = [r for r in rows if r.get("_tabla_ejemplo")]
        print("  rows", len(rows), "with sps", len(with_sps), "with tabla", len(with_tbl))
        if with_sps:
            print("  sample sps", with_sps[0].get("_pack_code"), [x["id"] for x in with_sps[0]["_sps_relacionados"]])

# check renderScenario spsRel
print("spsRel in render", "spsRel" in t or "_sps_relacionados" in t)
print("tabla_ejemplo render", "_tabla_ejemplo" in t)
