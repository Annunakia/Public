# -*- coding: utf-8 -*-
"""
Workshop mejorado:
1) Glosario en lenguaje simple (ganadora, ancla, señal, etc.)
2) Reglas de negocio agrupadas por fase 1 / 2a / 2b / 2c / 2d / 3 / 4
3) Ejemplo AL LADO de cada fase (no lejos)
"""
from __future__ import annotations

import json
import re
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

PRESENTACION = [
    {
        "titulo": "Qué estamos resolviendo",
        "lead": (
            "Después de unificar, una persona puede tener varias casas, oficinas, fijos, "
            "celulares o correos. El ordenamiento solo responde: ¿cuál intento primero?"
        ),
        "bullets": [
            "Abajo: diccionario de palabras (para que nadie se pierda).",
            "Luego: reglas por fase, cada una con su ejemplo al lado.",
        ],
    },
    {
        "titulo": "Diccionario — qué significa cada palabra",
        "lead": "Si una frase suena rara, búscala aquí. Todo en lenguaje de mesa.",
        "layout": "glosario",
        "terminos": [
            {
                "termino": "Dirección",
                "es_decir": (
                    "El domicilio físico de la persona: casa, oficina, correspondencia. "
                    "No es el teléfono ni el correo."
                ),
            },
            {
                "termino": "Dirección ganadora",
                "es_decir": (
                    "La dirección que SÍ usamos para contactar después de unificar. "
                    "Es la vigente. Ejemplo: quedó la casa de la Calle 10; esa es la ganadora."
                ),
            },
            {
                "termino": "Dirección hija",
                "es_decir": (
                    "Una dirección que ya NO usamos: unificación la absorbió dentro de otra. "
                    "Ejemplo: una dirección vieja que quedó ‘dentro’ del padre. No se intenta ni se puntúa."
                ),
            },
            {
                "termino": "«Necesita dirección ganadora» (antes se decía «ancla»)",
                "es_decir": (
                    "Quiere decir: el fijo, el celular o el correo solo entran a ordenar "
                    "si esa persona ya tiene al menos un domicilio que sí usamos (una ganadora). "
                    "Si la persona no tiene ningún domicilio vigente, no ordenamos sus teléfonos ni correos: "
                    "no hay dónde ‘amarrar’ el contacto."
                ),
            },
            {
                "termino": "Canal (DIR / TEL / CEL / EMA)",
                "es_decir": (
                    "La bandeja donde se ordenan solo cosas del mismo tipo. "
                    "DIR = direcciones entre sí. TEL = fijos entre sí. CEL = celulares entre sí. EMA = correos entre sí. "
                    "Un fijo nunca compite contra un email."
                ),
            },
            {
                "termino": "Score (puntaje)",
                "es_decir": (
                    "El número que usamos para decidir quién va primero dentro de un canal. "
                    "Más alto = se intenta antes (lugar 1, luego 2…)."
                ),
            },
            {
                "termino": "Señal",
                "es_decir": (
                    "Un dato que aporta al puntaje: por ejemplo si el fijo es válido, "
                    "si el celular es Claro, o cuánto ‘pesa’ el historial de una dirección. "
                    "No es el orden final: es lo que alimenta el score."
                ),
            },
            {
                "termino": "Peso / beta / catálogo",
                "es_decir": (
                    "Cuánto vale cada señal. Eso no se inventa en la corrida: vive en una tabla acordada. "
                    "Ejemplo: el peso de Claro vs el de Movistar."
                ),
            },
            {
                "termino": "Prefijo del celular",
                "es_decir": (
                    "Los 3 primeros dígitos del número (ej. 310). Con eso miramos en la tabla "
                    "si es Claro, Movistar, etc. Si el prefijo no está (ej. 999), usamos un valor por defecto."
                ),
            },
            {
                "termino": "Orden de calle / orden de intento",
                "es_decir": (
                    "Lo que sale a campo: 1º intento, 2º intento… Solo se guarda desde las direcciones. "
                    "Los rankings de fijo/celular/correo no escriben ese orden de calle."
                ),
            },
            {
                "termino": "Lugar 1 / lugar 2",
                "es_decir": (
                    "Posición dentro del ranking del canal. Lugar 1 = el que intentamos primero en ese canal."
                ),
            },
        ],
    },
    {
        "titulo": "Reglas de negocio por fase (con ejemplo al lado)",
        "lead": (
            "Misma regla que aceptamos en criterios y que comprueba la ejecución. "
            "Izquierda = qué dice la regla. Derecha = ejemplo concreto."
        ),
        "layout": "fases_lado_a_lado",
        "fases": [
            {
                "fase": "0 → 1",
                "nombre": "¿Quién entra? (armar candidatos)",
                "pregunta": "¿Qué contactos pasan al ranking y cuáles se quedan fuera?",
                "reglas": [
                    {
                        "titulo": "Solo dirección ganadora",
                        "texto": (
                            "Entra la dirección vigente (la que sí contactamos). "
                            "No entra la hija (ya absorbida)."
                        ),
                    },
                    {
                        "titulo": "Cada tipo a su canal",
                        "texto": (
                            "Casa/oficina → bandeja DIR. Fijo → TEL. Celular → CEL. Correo → EMA. "
                            "No se mezclan."
                        ),
                    },
                    {
                        "titulo": "Email sin @ no entra",
                        "texto": "Si no tiene arroba, no es correo usable: no llega a EMA.",
                    },
                    {
                        "titulo": "Teléfono/correo exige domicilio vigente",
                        "texto": (
                            "Fijo, celular o email solo entran si la persona ya tiene "
                            "al menos una dirección ganadora. Si no, no se puntúan ni se intentan."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo al lado",
                    "caso": "Persona 20011 (padre e hija) + chequeo de email",
                    "pasos": [
                        "Padre 91018 = dirección ganadora → SÍ entra a DIR.",
                        "Hija 91019 = absorbida → NO aparece en score ni en orden.",
                        "Un mail sin @ → NO entra a EMA.",
                        "Un celular de alguien sin domicilio vigente → NO entra a CEL.",
                    ],
                    "tabla": {
                        "headers": ["Contacto", "¿Entra?", "Por qué (en simple)"],
                        "rows": [
                            ["Padre (ganadora)", "Sí", "Domicilio que sí usamos"],
                            ["Hija", "No", "Ya no es vigente"],
                            ["mail_sin_arroba.com", "No", "Sin @"],
                            ["Celular sin domicilio vigente", "No", "Falta dirección que sí usamos"],
                        ],
                    },
                },
            },
            {
                "fase": "2a",
                "nombre": "Ordenar direcciones (DIR)",
                "pregunta": "¿Casa o oficina primero?",
                "reglas": [
                    {
                        "titulo": "Compiten solo direcciones ganadoras entre sí",
                        "texto": "Casa vs oficina, ambas vigentes, en la bandeja DIR.",
                    },
                    {
                        "titulo": "Score = señales × pesos del catálogo",
                        "texto": (
                            "Cada señal (historial, tipo, etc.) aporta al puntaje según el catálogo. "
                            "Mayor score → lugar 1."
                        ),
                    },
                    {
                        "titulo": "Ese lugar es el que después sale a calle",
                        "texto": "El 1º de DIR será el 1º intento en campo (fase 3).",
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo al lado — persona 20001",
                    "caso": "Tiene casa 91001 y oficina 91002 (las dos ganadoras)",
                    "pasos": [
                        "Las dos entran a DIR (regla fase 1).",
                        "Calculamos score: casa 850, oficina 700.",
                        "Casa → lugar 1. Oficina → lugar 2.",
                        "En calle: primero casa, después oficina.",
                    ],
                    "tabla": {
                        "headers": ["Dirección", "¿Ganadora?", "Score", "Orden"],
                        "rows": [
                            ["Casa 91001", "Sí", "850", "1º"],
                            ["Oficina 91002", "Sí", "700", "2º"],
                        ],
                    },
                },
            },
            {
                "fase": "2b",
                "nombre": "Ordenar fijos (TEL)",
                "pregunta": "¿Cuál fijo intento primero?",
                "reglas": [
                    {
                        "titulo": "Solo fijos entre sí",
                        "texto": "Un fijo no compite con la casa ni con el celular.",
                    },
                    {
                        "titulo": "Válido prioriza sobre no válido",
                        "texto": "El fijo usable queda de primeras; el ‘sucio’ no manda.",
                    },
                    {
                        "titulo": "Señal de geo: se calcula, no mueve el ranking",
                        "texto": (
                            "Puede quedar registrada para seguimiento, pero no suma al score. "
                            "Por eso dos fijos pueden empatar aunque la geo sea distinta."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo al lado — persona 20004 / 20013",
                    "caso": "Dos fijos: uno válido y uno no",
                    "pasos": [
                        "20004: válido score 420 → lugar 1; no válido 210 → lugar 2.",
                        "20013: aunque la geo cambie, ambos quedan 376.5 (geo no suma).",
                    ],
                    "tabla": {
                        "headers": ["Caso", "Fijo", "Resultado"],
                        "rows": [
                            ["20004", "Válido", "420 → 1º"],
                            ["20004", "No válido", "210 → 2º"],
                            ["20013", "Ambos (geo distinta)", "376.5 / 376.5 (empate)"],
                        ],
                    },
                },
            },
            {
                "fase": "2c",
                "nombre": "Ordenar celulares (CEL)",
                "pregunta": "¿Cómo sé si es Claro, Movistar… y qué pasa si no sé?",
                "reglas": [
                    {
                        "titulo": "Miramos el prefijo (3 primeros dígitos)",
                        "texto": "Ese prefijo se busca en la tabla de operadores del catálogo.",
                    },
                    {
                        "titulo": "Si está en la tabla → usamos ese peso",
                        "texto": "Ej. 310 mapea a Claro (o el operador que diga el catálogo).",
                    },
                    {
                        "titulo": "Si NO está → valor por defecto 0.22",
                        "texto": (
                            "No inventamos Claro ni Movistar. No dejamos el celular en cero: "
                            "aplica el default acordado y sí puede ordenarse."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo al lado — persona 20012",
                    "caso": "Celular con prefijo 999 (no está en el catálogo)",
                    "pasos": [
                        "Tomamos prefijo 999.",
                        "Buscamos 999 en la tabla: no está.",
                        "Aplicamos default 0.22 → score de ejemplo 220 → lugar 1.",
                        "El celular entra al ranking; no ‘rompe’ ni queda en blanco.",
                    ],
                    "tabla": {
                        "headers": ["Prefijo", "¿En tabla?", "Qué hacemos", "Efecto"],
                        "rows": [
                            ["310", "Sí", "Peso del operador", "Suma al score CEL"],
                            ["999", "No", "Default 0.22", "Score 220; no queda en cero"],
                        ],
                    },
                },
            },
            {
                "fase": "2d",
                "nombre": "Ordenar emails (EMA)",
                "pregunta": "¿Qué correos compiten y qué señales no mueven el orden?",
                "reglas": [
                    {
                        "titulo": "Solo correos con @ y con domicilio vigente",
                        "texto": "Sin @ no entra. Sin dirección ganadora de la persona, tampoco.",
                    },
                    {
                        "titulo": "Algunas variables se calculan pero no suman",
                        "texto": (
                            "Se guardan para seguimiento; no cambian quién va primero. "
                            "Si solo cambian esas, el score del mail no se mueve."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo al lado — persona 20014",
                    "caso": "Email ‘base’ vs email solo con variables excluidas",
                    "pasos": [
                        "Ambos tienen @ y la persona tiene domicilio vigente → entran.",
                        "Las variables excluidas se calculan pero no suman.",
                        "Quedan con el mismo score 281.7705 → el orden no cambia por ellas.",
                    ],
                    "tabla": {
                        "headers": ["Variante", "¿Sumán excluidas?", "Score"],
                        "rows": [
                            ["ema_base", "No aplica / no suman", "281.7705"],
                            ["ema_solo_excluidas", "No suman", "281.7705 (igual)"],
                        ],
                    },
                },
            },
            {
                "fase": "3",
                "nombre": "Guardar el orden de calle",
                "pregunta": "¿Qué queda escrito para intentar en campo?",
                "reglas": [
                    {
                        "titulo": "Solo la dirección escribe el orden de intento",
                        "texto": (
                            "El lugar 1/2 de DIR se copia como orden de prioridad (1º, 2º…). "
                            "TEL, CEL y EMA tienen su ranking, pero no escriben ese campo de calle."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo al lado — persona 20001",
                    "caso": "Mismos 91001 / 91002 de la fase 2a",
                    "pasos": [
                        "DIR ya dejó casa lugar 1 y oficina lugar 2.",
                        "Se guarda: 91001 → orden 1; 91002 → orden 2.",
                        "Eso es lo que sale a operación en calle.",
                    ],
                    "tabla": {
                        "headers": ["Dirección", "Lugar DIR", "Orden guardado en calle"],
                        "rows": [
                            ["Casa 91001", "1", "1"],
                            ["Oficina 91002", "2", "2"],
                        ],
                    },
                },
            },
            {
                "fase": "4",
                "nombre": "Limpiar y validar la corrida",
                "pregunta": "¿Quedó sana y sin basura temporal?",
                "reglas": [
                    {
                        "titulo": "Borrar temporales; conservar el orden",
                        "texto": "Se limpian tablas temporales de la corrida. El orden de calle ya guardado se queda.",
                    },
                    {
                        "titulo": "Gate de aceptación",
                        "texto": (
                            "0 direcciones hija con orden incorrecto; "
                            "volúmenes de score DIR/TEL/EMA con sentido (> 0 en corrida real)."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Ejemplo al lado — cierre",
                    "caso": "Después del orquestador",
                    "pasos": [
                        "No deben quedar tablas temporales stg_insumo_*.",
                        "Ninguna hija debe haber quedado mal ordenada.",
                        "La siguiente corrida parte limpia; el orden de 20001 sigue.",
                    ],
                    "tabla": {
                        "headers": ["Chequeo", "Esperado"],
                        "rows": [
                            ["Temporales stg_*", "No quedan"],
                            ["Hijas con orden incorrecto", "0"],
                            ["Orden casa/oficina 20001", "Se conserva 1 / 2"],
                        ],
                    },
                },
            },
        ],
    },
    {
        "titulo": "Cómo leer esto en la mesa",
        "lead": "Orden de la conversación (ya cubierto arriba, fase por fase).",
        "bullets": [
            "Primero el diccionario (ganadora, domicilio vigente, score, canal…).",
            "Luego fase 1 → 2a → 2b → 2c → 2d → 3 → 4, siempre con el ejemplo pegado a la derecha.",
            "Demo = mismos casos paso a paso. SPs = detalle técnico de archivos.",
        ],
    },
]

RENDER_PRES = r"""function renderPresentacion() {
  const items = DATA.presentacion || [];
  const el = document.getElementById('presentacionWrap');
  if (!el) return;
  const tbl = (tabla) => {
    if (!tabla || !tabla.headers) return '';
    const head = tabla.headers.map(h => `<th>${esc(h)}</th>`).join('');
    const body = (tabla.rows || []).map(r =>
      `<tr>${r.map(c => `<td>${esc(String(c ?? ''))}</td>`).join('')}</tr>`
    ).join('');
    return `<div class="demo-tabla-wrap"><table class="demo-tabla"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
  };
  const glosario = (b) => {
    const cards = (b.terminos || []).map(t => `
      <article class="demo-gloss-card">
        <h5>${esc(t.termino || '')}</h5>
        <p><b>Es decir:</b> ${esc(t.es_decir || '')}</p>
      </article>`).join('');
    return `${b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : ''}
      <div class="demo-gloss-grid">${cards}</div>`;
  };
  const fasesLado = (b) => {
    const bloques = (b.fases || []).map(f => {
      const reglas = (f.reglas || []).map(r => `
        <div class="demo-regla-item">
          <strong>${esc(r.titulo || '')}</strong>
          <p>${esc(r.texto || '')}</p>
        </div>`).join('');
      const ej = f.ejemplo || {};
      const pasos = (ej.pasos || []).map((p, i) =>
        `<li><span class="hist-n">${i + 1}</span> ${esc(p)}</li>`
      ).join('');
      return `
      <section class="demo-fase-duo">
        <header class="demo-fase-duo-h">
          <span class="demo-fase-pill">Fase ${esc(String(f.fase))}</span>
          <div>
            <h5>${esc(f.nombre || '')}</h5>
            <p class="demo-fase-q">${esc(f.pregunta || '')}</p>
          </div>
        </header>
        <div class="demo-fase-duo-grid">
          <div class="demo-fase-col demo-fase-col-regla">
            <div class="demo-col-label">Reglas (qué acordamos)</div>
            ${reglas}
          </div>
          <div class="demo-fase-col demo-fase-col-ej">
            <div class="demo-col-label">${esc(ej.titulo || 'Ejemplo')}</div>
            ${ej.caso ? `<p class="demo-ej-caso"><b>Caso:</b> ${esc(ej.caso)}</p>` : ''}
            <ol class="demo-historia">${pasos}</ol>
            ${tbl(ej.tabla)}
          </div>
        </div>
      </section>`;
    }).join('');
    return `${b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : ''}${bloques}`;
  };
  el.innerHTML = items.map(b => {
    const lead = b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : '';
    const bullets = (b.bullets && b.bullets.length)
      ? `<ul class="demo-chips">${b.bullets.map(x => `<li>${esc(x)}</li>`).join('')}</ul>`
      : '';
    let body = `${lead}${bullets}`;
    if (b.layout === 'glosario') body = glosario(b);
    else if (b.layout === 'fases_lado_a_lado') body = fasesLado(b);
    return `<section class="demo-section">
      <h4>${esc(b.titulo)}</h4>
      ${body}
    </section>`;
  }).join('');
}"""

CSS_EXTRA = """
/* Workshop: glosario + fase con ejemplo al lado */
.demo-gloss-grid {
  display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 0.65rem; margin-top: 0.55rem;
}
.demo-gloss-card {
  background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px;
  padding: 0.7rem 0.8rem;
}
.demo-gloss-card h5 {
  margin: 0 0 0.35rem; font-size: 0.86rem; color: #0f172a; font-weight: 800;
}
.demo-gloss-card p {
  margin: 0; font-size: 0.78rem; line-height: 1.45; color: #334155;
}
.demo-fase-duo {
  margin: 1rem 0 1.25rem; border: 1px solid #e2e8f0; border-radius: 14px;
  background: #fff; overflow: hidden;
}
.demo-fase-duo-h {
  display: flex; gap: 0.75rem; align-items: flex-start;
  padding: 0.75rem 0.9rem; background: #f1f5f9; border-bottom: 1px solid #e2e8f0;
}
.demo-fase-duo-h h5 { margin: 0 0 0.2rem; font-size: 0.95rem; color: #0f172a; }
.demo-fase-pill {
  flex: 0 0 auto; background: #1d6fdc; color: #fff; font-size: 0.72rem; font-weight: 800;
  border-radius: 999px; padding: 0.28rem 0.6rem; white-space: nowrap;
}
.demo-fase-duo-grid {
  display: grid; grid-template-columns: 1fr 1fr; gap: 0;
}
@media (max-width: 820px) {
  .demo-fase-duo-grid { grid-template-columns: 1fr; }
}
.demo-fase-col { padding: 0.75rem 0.9rem; }
.demo-fase-col-regla { border-right: 1px solid #e2e8f0; background: #fafbfc; }
@media (max-width: 820px) {
  .demo-fase-col-regla { border-right: none; border-bottom: 1px solid #e2e8f0; }
}
.demo-fase-col-ej { background: #fff; }
.demo-col-label {
  font-size: 0.7rem; font-weight: 800; letter-spacing: 0.04em; text-transform: uppercase;
  color: #64748b; margin-bottom: 0.55rem;
}
.demo-regla-item {
  margin: 0 0 0.55rem; padding: 0.5rem 0.6rem;
  background: #fff; border: 1px solid #e2e8f0; border-radius: 10px;
}
.demo-regla-item strong { display: block; font-size: 0.82rem; color: #0f172a; margin-bottom: 0.2rem; }
.demo-regla-item p { margin: 0; font-size: 0.78rem; line-height: 1.4; color: #334155; }
.demo-ej-caso { margin: 0 0 0.5rem; font-size: 0.8rem; color: #0f172a; }
.demo-historia {
  margin: 0.25rem 0 0.65rem; padding: 0; list-style: none;
  display: flex; flex-direction: column; gap: 0.4rem;
}
.demo-historia li {
  display: flex; gap: 0.5rem; align-items: flex-start;
  background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px;
  padding: 0.45rem 0.6rem; font-size: 0.78rem; line-height: 1.4; color: #0f172a;
}
.demo-historia .hist-n {
  flex: 0 0 1.25rem; height: 1.25rem; border-radius: 50%;
  background: #1d6fdc; color: #fff; font-size: 0.68rem; font-weight: 800;
  display: inline-flex; align-items: center; justify-content: center;
}
.presentacion-wrap { max-width: 1100px; }
"""


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def esc_js(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#x27;")
    )


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    data["presentacion"] = PRESENTACION
    html = html[:start] + to_html_json(data) + html[end:]

    pat = re.compile(r"function renderPresentacion\(\) \{\n.*?\n\}", re.S)
    ms = list(pat.finditer(html))
    if not ms:
        raise SystemExit("renderPresentacion not found")
    m = ms[-1]
    html = html[: m.start()] + esc_js(RENDER_PRES) + html[m.end() :]
    print("  renderPresentacion ok")

    oi = html.find("Mapa Ordenamiento")
    se = html.find("&lt;/style&gt;", oi)
    markers = [
        "/* Workshop: glosario + fase con ejemplo al lado */",
        "/* Workshop reglas + ejemplo detallado */",
        "/* Historias funcionales Workshop */",
    ]
    if se > 0:
        for marker in markers:
            zone = html[oi:se]
            if marker in zone:
                prev = html.rfind(marker, oi, se)
                html = html[:prev] + html[se:]
                se = html.find("&lt;/style&gt;", oi)
        html = html[:se] + CSS_EXTRA + html[se:]
        print("  CSS ok")

    # Soft-replace leftover jargon in Demo landing subtitle if still "ancla"
    html = html.replace(
        "Falta ancla de dirección",
        "Falta domicilio vigente (dirección ganadora)",
    )
    html = html.replace(
        "ancla de domicilio",
        "domicilio vigente (dirección ganadora)",
    )
    html = html.replace(
        "Falta ancla",
        "Falta domicilio vigente",
    )

    path.write_text(html, encoding="utf-8")
    print("OK", path.name, "fases", len(PRESENTACION[2]["fases"]), "terminos", len(PRESENTACION[1]["terminos"]))


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
