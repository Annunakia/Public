# -*- coding: utf-8 -*-
from pathlib import Path

base_dt = Path(
    r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)\db_rcncr_btch_rdshft_dt"
)
base_pgm = Path(
    r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)\db_rcncr_btch_rdshft_pgm"
)
base_strct = Path(
    r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)\db_rcncr_btch_rdshft_strct"
)

strct_ddl = """-- ============================================================
-- 05_ddl_ordenamiento_mock.sql
-- Tablas lab bdm_stage.mock_ord_* (suite QA Modo B)
-- ============================================================

CREATE SCHEMA IF NOT EXISTS bdm_stage;

CREATE TABLE IF NOT EXISTS bdm_stage.mock_ord_escenario (
  id_buro_persona   BIGINT       NOT NULL,
  cod_escenario     VARCHAR(32)  NOT NULL,
  criterio_ca       VARCHAR(16)  NOT NULL,
  descripcion       VARCHAR(256),
  es_html_ejemplo   SMALLINT     DEFAULT 1
);

CREATE TABLE IF NOT EXISTS bdm_stage.mock_ord_rpu (
  id_buro_persona      BIGINT   NOT NULL,
  cod_pin_persona      BIGINT,
  cod_dw_persona_ubic  BIGINT   NOT NULL,
  ind_unificacion      INTEGER,
  etiqueta             VARCHAR(64)
);

CREATE TABLE IF NOT EXISTS bdm_stage.mock_ord_score (
  id_buro_persona      BIGINT         NOT NULL,
  cod_dw_persona_ubic  BIGINT         NOT NULL,
  cod_pin_persona      BIGINT,
  canal                VARCHAR(10)    NOT NULL,
  score                DECIMAL(18,4)  NOT NULL,
  lugar                INTEGER        NOT NULL,
  nota                 VARCHAR(128)
);

CREATE TABLE IF NOT EXISTS bdm_stage.mock_ord_prioridad (
  id_buro_persona      BIGINT   NOT NULL,
  cod_dw_persona_ubic  BIGINT   NOT NULL,
  orden_prioridad      INTEGER  NOT NULL
);

CREATE TABLE IF NOT EXISTS bdm_stage.mock_ord_ca_result (
  criterio_ca   VARCHAR(16)  NOT NULL,
  estado        VARCHAR(16)  NOT NULL,
  detalle       VARCHAR(512),
  fecha_check   TIMESTAMP    DEFAULT GETDATE()
);
"""
(base_strct / "deploy/redshift/SQL/05_ddl_ordenamiento_mock.sql").write_text(
    strct_ddl, encoding="utf-8"
)

seed = (
    base_dt / "docs/sql_qa_ordenamiento_mock/02_seed_escenarios_mock.sql"
).read_text(encoding="utf-8")
seed_body = seed.split("SELECT 'SEED_MOCK_ORD_OK'")[0]
idx = seed_body.find("TRUNCATE")
seed_body = seed_body[idx:].strip()

sp_cargar = f"""-- ============================================================
-- sp_ordenamiento_cargar_seed_mock.sql
-- Carga personas MOCK 20001-20014 (HTML / CA-O01..CA-O12)
-- Schema: bdm_stage
-- ============================================================

CREATE OR REPLACE PROCEDURE bdm_stage.sp_ordenamiento_cargar_seed_mock()
LANGUAGE plpgsql
AS $$
BEGIN
{seed_body}
END;
$$;
"""
(base_pgm / "deploy/redshift/SQL/sp_ordenamiento_cargar_seed_mock.sql").write_text(
    sp_cargar, encoding="utf-8"
)

val = (
    base_dt / "docs/sql_qa_ordenamiento_mock/03_validar_criterios_mock.sql"
).read_text(encoding="utf-8")
val_body = val.split("-- Resumen para HU")[0]
idx = val_body.find("TRUNCATE")
val_body = val_body[idx:].strip()

sp_validar = f"""-- ============================================================
-- sp_ordenamiento_validar_mock.sql
-- Ejecuta matriz CA-O01..CA-O12 → bdm_stage.mock_ord_ca_result
-- ============================================================

CREATE OR REPLACE PROCEDURE bdm_stage.sp_ordenamiento_validar_mock()
LANGUAGE plpgsql
AS $$
BEGIN
{val_body}
END;
$$;
"""
(base_pgm / "deploy/redshift/SQL/sp_ordenamiento_validar_mock.sql").write_text(
    sp_validar, encoding="utf-8"
)

sp_orq = """-- ============================================================
-- sp_ordenamiento_ejecucion_mock.sql
-- Orquestador Modo B MOCK (no llama SPs _edf)
-- ============================================================

CREATE OR REPLACE PROCEDURE bdm_stage.sp_ordenamiento_ejecucion_mock()
LANGUAGE plpgsql
AS $$
BEGIN
  CALL bdm_stage.sp_ordenamiento_cargar_seed_mock();
  CALL bdm_stage.sp_ordenamiento_validar_mock();
END;
$$;
"""
(base_pgm / "deploy/redshift/SQL/sp_ordenamiento_ejecucion_mock.sql").write_text(
    sp_orq, encoding="utf-8"
)

run_dt = """-- ============================================================
-- run_ordenamiento_ejecucion_mock.sql
-- Modo B: CALL mock + lectura veredicto CA
-- Pre: STRCT 05_ddl + PGM SPs mock + betas 47 en bdm_datos
-- ============================================================

CALL bdm_stage.sp_ordenamiento_ejecucion_mock();

SELECT criterio_ca, estado, detalle
FROM bdm_stage.mock_ord_ca_result
ORDER BY criterio_ca;

SELECT
  CASE WHEN SUM(CASE WHEN estado = 'FAILED' THEN 1 ELSE 0 END) = 0
       THEN 'PASSED_ALL' ELSE 'FAILED_SOME' END AS veredicto_mock,
  SUM(CASE WHEN estado = 'PASSED' THEN 1 ELSE 0 END) AS passed,
  SUM(CASE WHEN estado = 'FAILED' THEN 1 ELSE 0 END) AS failed
FROM bdm_stage.mock_ord_ca_result;
"""
(base_dt / "deploy/redshift/SQL/run_ordenamiento_ejecucion_mock.sql").write_text(
    run_dt, encoding="utf-8"
)

# deploy.par — avoid duplicates
def ensure_lines(path: Path, extras: list[str]) -> None:
    text = path.read_text(encoding="utf-8").replace("\r\n", "\n")
    lines = [ln for ln in text.split("\n") if ln.strip() != ""]
    for e in extras:
        if e not in lines:
            lines.append(e)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


ensure_lines(
    base_strct / "deploy/redshift/deploy.par",
    ["05_ddl_ordenamiento_mock.sql"],
)
ensure_lines(
    base_pgm / "deploy/redshift/deploy.par",
    [
        "sp_ordenamiento_cargar_seed_mock.sql",
        "sp_ordenamiento_validar_mock.sql",
        "sp_ordenamiento_ejecucion_mock.sql",
    ],
)
ensure_lines(
    base_dt / "deploy/redshift/deploy.par",
    [
        "run_ordenamiento_ejecucion_mock.sql",
        "validacion_ordenamiento_criterios_aceptacion.sql",
    ],
)

runbook = """-- ============================================================
-- 00_RUNBOOK_ORDENAMIENTO_MOCK.sql
-- Post-deploy: CALL bdm_stage.sp_ordenamiento_ejecucion_mock();
-- Alternativa scripts: 01_ddl → 02_seed → 03_validar
-- ============================================================

CALL bdm_stage.sp_ordenamiento_ejecucion_mock();

SELECT criterio_ca, estado, detalle
FROM bdm_stage.mock_ord_ca_result
ORDER BY criterio_ca;

SELECT
  CASE WHEN SUM(CASE WHEN estado = 'FAILED' THEN 1 ELSE 0 END) = 0
       THEN 'PASSED_ALL' ELSE 'FAILED_SOME' END AS veredicto_mock
FROM bdm_stage.mock_ord_ca_result;
"""
(
    base_dt / "docs/sql_qa_ordenamiento_mock/00_RUNBOOK_ORDENAMIENTO_MOCK.sql"
).write_text(runbook, encoding="utf-8")

# touch ENTREGA note about SPs
entrega = base_dt / "docs/ENTREGA_QA_ORDENAMIENTO.md"
t = entrega.read_text(encoding="utf-8")
old = "| Scripts | `docs/sql_qa_ordenamiento_mock/` personas **20001–20014** |"
# already updated earlier - add SP line if missing
if "sp_ordenamiento_ejecucion_mock" not in t:
    t = t.replace(
        "| **Insumo** | Post-unificación + `edf_views` / `v_xpm_*` | `docs/sql_qa_ordenamiento_mock/` personas **20001–20014** |",
        "| **Insumo** | Post-unificación + `edf_views` / `v_xpm_*` | `bdm_stage.mock_ord_*` personas **20001–20014** |\n"
        "| **SPs mock** | — | `bdm_stage.sp_ordenamiento_ejecucion_mock` (+ cargar_seed + validar) |",
    )
    # fix duplicate SPs row if we created double - read current file structure
    entrega.write_text(t, encoding="utf-8")

print("OK files generated")
for p in [
    base_strct / "deploy/redshift/SQL/05_ddl_ordenamiento_mock.sql",
    base_pgm / "deploy/redshift/SQL/sp_ordenamiento_cargar_seed_mock.sql",
    base_pgm / "deploy/redshift/SQL/sp_ordenamiento_validar_mock.sql",
    base_pgm / "deploy/redshift/SQL/sp_ordenamiento_ejecucion_mock.sql",
    base_dt / "deploy/redshift/SQL/run_ordenamiento_ejecucion_mock.sql",
]:
    print(p.name, p.stat().st_size)
