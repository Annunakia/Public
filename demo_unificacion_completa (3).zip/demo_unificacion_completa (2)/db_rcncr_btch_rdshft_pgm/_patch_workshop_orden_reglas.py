# -*- coding: utf-8 -*-
"""
Workshop orden: 1) todas las reglas de negocio → 2) ejemplo muy detallado → 3) historias.
Reglas sacadas de criterios de aceptación y de la ejecución de los procesos (SPs).
"""
from __future__ import annotations

import json
import re
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

# ---------------------------------------------------------------------------
# Reglas = criterios de aceptación + lo que demuestran las ejecuciones
# ---------------------------------------------------------------------------
PRESENTACION = [
    {
        "titulo": "1 · Qué hace el ordenamiento",
        "lead": (
            "Después de unificar, una persona puede tener varias direcciones, fijos, "
            "celulares o correos. El ordenamiento responde: ¿cuál intento primero?"
        ),
        "bullets": [
            "Primero acordamos las reglas de negocio (abajo).",
            "Luego vemos un ejemplo muy detallado de punta a punta.",
            "Al final, historias cortas refuerzan cada regla.",
        ],
    },
    {
        "titulo": "2 · Todas las reglas de negocio que estamos mirando",
        "lead": (
            "Estas reglas salen de los criterios de aceptación y de lo que comprueba "
            "cada proceso al ejecutarse. Sin esto no hay ranking válido."
        ),
        "layout": "reglas",
        "grupos": [
            {
                "grupo": "A · Quién entra (elegibilidad)",
                "lead": "Antes de puntuar: ¿este contacto sirve o se queda fuera?",
                "tabla": {
                    "headers": ["Regla", "Qué significa", "Cómo se acepta / ejemplo"],
                    "rows": [
                        [
                            "Solo dirección ganadora",
                            "Ganadora = domicilio vigente tras unificar. La hija ya quedó absorbida: no es vigente.",
                            "Padre entra a score/orden; hija no aparece (ej. persona 20011).",
                        ],
                        [
                            "Canales no se mezclan",
                            "Dirección, fijo, celular y email se ordenan cada uno en su canal.",
                            "Un fijo no compite con un correo; cada ranking es aparte.",
                        ],
                        [
                            "Tipo de contacto → canal",
                            "El origen dice el tipo; nosotros lo traducimos a DIR / TEL / CEL / EMA.",
                            "Casa/oficina → DIR; fijo → TEL; celular → CEL; correo → EMA. Tipo 8 puede alimentar DIR y TEL.",
                        ],
                        [
                            "Email sin @ no entra",
                            "Sin arroba no es correo usable.",
                            "Type 10 sin @ no llega a la bandeja EMA.",
                        ],
                        [
                            "TEL/CEL/EMA necesitan dirección ganadora",
                            "El teléfono o correo solo entra si la persona ya tiene ≥1 domicilio vigente (ancla).",
                            "Sin DIR ganadora: ese TEL/CEL/EMA no se puntúa ni se intenta.",
                        ],
                    ],
                },
            },
            {
                "grupo": "B · Cómo se ordena (score y lugar)",
                "lead": "Dentro de cada canal: ¿quién queda de primeras?",
                "tabla": {
                    "headers": ["Regla", "Qué significa", "Cómo se acepta / ejemplo"],
                    "rows": [
                        [
                            "Score = señal × peso del catálogo",
                            "Cada señal aporta (categoría/máximo) × beta. Mayor score → lugar 1, 2, 3…",
                            "Casa 850 lugar 1; oficina 700 lugar 2 (persona 20001).",
                        ],
                        [
                            "Pesos viven en catálogo (no se inventan)",
                            "Claro/Movistar y demás betas salen de la tabla acordada (RITM).",
                            "Prefijo 310 → operador del catálogo; no se adivina en la corrida.",
                        ],
                        [
                            "Prefijo desconocido → default",
                            "Si el prefijo del celular no está en la tabla, usamos 0.22. No dejamos el celular en cero.",
                            "Prefijo 999 → default → score 220 lugar 1 (persona 20012).",
                        ],
                        [
                            "Fijo válido prioriza sobre no válido",
                            "En TEL solo compiten fijos entre sí; el válido gana el primer intento.",
                            "Válido 420/1 vs no válido 210/2 (persona 20004).",
                        ],
                        [
                            "Algunas señales se calculan pero no suman",
                            "Geo en TEL y ciertas variables de email: trazabilidad, no mueven el ranking.",
                            "Dos fijos pueden quedar 376.5 pese a geo distinta; emails base vs ‘solo excluidas’ mismo score 281.7705.",
                        ],
                    ],
                },
            },
            {
                "grupo": "C · Qué se guarda y cómo cierra la corrida",
                "lead": "Salida a operación y limpieza.",
                "tabla": {
                    "headers": ["Regla", "Qué significa", "Cómo se acepta / ejemplo"],
                    "rows": [
                        [
                            "Solo DIR escribe el orden de calle",
                            "El lugar de la dirección se guarda como orden de intento (1º, 2º…). TEL/CEL/EMA no escriben ese campo.",
                            "Persona 20001: casa→orden 1, oficina→orden 2 (igual que el ranking DIR).",
                        ],
                        [
                            "Pipeline fijo",
                            "Orden de la corrida: armar quién entra → ordenar DIR → TEL → CEL → EMA → guardar orden → limpiar temporales.",
                            "No se puntúa sin bandejas; no se deja basura temporal al cerrar.",
                        ],
                        [
                            "Limpiar temporales; conservar salida",
                            "Al cerrar se borran tablas temporales; el orden guardado se queda.",
                            "Tras la corrida no deben quedar stg_insumo_*.",
                        ],
                        [
                            "Gate de aceptación real",
                            "0 hijas con orden incorrecto; volúmenes de score DIR/TEL/EMA > 0.",
                            "La aceptación mira conteos reales, no solo el seed de mesa.",
                        ],
                    ],
                },
            },
        ],
    },
    {
        "titulo": "3 · Ejemplo muy detallado (persona 20001 — casa y oficina)",
        "lead": (
            "Recorremos una persona de punta a punta aplicando las reglas de arriba. "
            "Al lado, casos hermanos muestran la misma regla en otro canal."
        ),
        "layout": "ejemplo_detalle",
        "pasos": [
            "Contexto: la persona 20001 ya pasó unificación. Tiene dos direcciones vigentes: casa (91001) y oficina (91002). Las dos son ganadoras (ninguna es hija).",
            "Regla A — ¿quién entra? Las dos entran al canal DIR porque son ganadoras. Si hubiera una hija (como en 20011), esa no entraría: no score, no orden.",
            "Regla A — canales: casa y oficina solo compiten en DIR. Sus fijos (si los tuviera) irían a TEL; no contra la casa.",
            "Regla A — ancla: si esta persona no tuviera ninguna DIR ganadora, sus TEL/CEL/EMA no entrarían. Aquí sí tiene ancla → los demás canales podrían armarse.",
            "Regla B — score: cada dirección suma (señal × beta del catálogo). Casa obtiene 850; oficina 700.",
            "Regla B — lugar: mayor score gana. Casa → lugar 1; oficina → lugar 2. En calle intentamos primero la casa.",
            "Regla C — guardar: solo DIR escribe orden de prioridad. Queda 91001→1 y 91002→2. TEL/CEL/EMA no tocan ese campo.",
            "Caso hermano TEL (20004): dos fijos; válido 420 lugar 1 vs no válido 210 lugar 2. Misma idea de ‘cuál primero’, otro canal.",
            "Caso hermano CEL (20012): prefijo 999 no está en catálogo → default 0.22 → score 220. No inventamos Claro/Movistar; no dejamos el celular en cero.",
            "Caso hermano EMA (20014): variables ‘excluidas’ se calculan pero no suman → mismo score 281.7705. No cambian quién va primero.",
            "Cierre: se limpian temporales; el orden 1 y 2 de la casa/oficina se conserva para campo.",
            "Conclusión del ejemplo: las reglas A (quién entra) + B (cómo ordena) + C (qué se guarda) se aplican en cadena; el score solo es el medio para fijar el orden de intento.",
        ],
        "tablas": [
            {
                "titulo": "Paso a paso — persona 20001 (DIR)",
                "headers": ["Paso", "Qué miramos", "Resultado"],
                "rows": [
                    ["1. Vigencia", "¿Ganadora o hija?", "Casa y oficina = ganadoras → entran"],
                    ["2. Canal", "¿DIR / TEL / CEL / EMA?", "Ambas van solo a DIR"],
                    ["3. Score", "Señal × beta catálogo", "Casa 850 · Oficina 700"],
                    ["4. Lugar", "Mayor score primero", "Casa 1º · Oficina 2º"],
                    ["5. Guardar", "Orden de calle (= lugar DIR)", "91001→1 · 91002→2"],
                    ["6. Limpiar", "Temporales de la corrida", "Se borran; orden se conserva"],
                ],
            },
            {
                "titulo": "Misma lógica en otros canales (casos de aceptación)",
                "headers": ["Persona", "Canal", "Regla que demuestra", "Resultado aceptado"],
                "rows": [
                    ["20011", "DIR", "Solo ganadoras", "Padre sí; hija fuera"],
                    ["20004", "TEL", "Válido > no válido", "420/1 vs 210/2"],
                    ["20012", "CEL", "Default si prefijo no está", "999 → score 220"],
                    ["20014", "EMA", "Excluidas no suman", "Mismo score 281.7705"],
                    ["20013", "TEL", "Geo no mueve score", "Ambos 376.5"],
                ],
            },
        ],
    },
    {
        "titulo": "4 · Historias cortas (refuerzo)",
        "lead": "Con las reglas ya claras, cada historia es un zoom a una sola regla.",
        "bullets": [
            "Historia 1 — Casa o oficina (score DIR).",
            "Historia 2 — Dirección hija (solo ganadoras).",
            "Historia 3 — Fijo válido vs no válido.",
            "Historia 4 — Claro / Movistar / default 999.",
            "Historia 5 — Quién sí entra (ancla DIR, email con @).",
            "Historia 6 — Orden en calle (solo DIR guarda).",
        ],
    },
    {
        "titulo": "Historia 1 — Casa o oficina",
        "lead": "Regla B: mayor score DIR → primer intento.",
        "layout": "historia",
        "pasos": [
            "Abrimos casa y oficina: las dos son ganadoras → las dos compiten en DIR.",
            "Aplicamos pesos del catálogo: casa 850, oficina 700.",
            "Casa lugar 1; oficina lugar 2.",
            "Conclusión: en calle intentamos primero la casa.",
        ],
        "tabla": {
            "headers": ["Qué tiene", "¿Compite?", "Score", "Orden"],
            "rows": [
                ["Casa", "Sí (ganadora)", "850", "1º"],
                ["Oficina", "Sí (ganadora)", "700", "2º"],
            ],
        },
    },
    {
        "titulo": "Historia 2 — Dirección hija (ya no vigente)",
        "lead": "Regla A: solo dirección ganadora.",
        "layout": "historia",
        "pasos": [
            "Padre = dirección vigente (ganadora).",
            "Hija = absorbida; ya no es el contacto a usar.",
            "La hija no recibe score ni orden.",
            "Conclusión: solo el padre se intenta.",
        ],
        "tabla": {
            "headers": ["Rol", "¿Entra?", "Por qué"],
            "rows": [
                ["Padre (ganadora)", "Sí", "Domicilio vigente"],
                ["Hija", "No", "Ya absorbida en unificación"],
            ],
        },
    },
    {
        "titulo": "Historia 3 — Fijo válido vs no válido",
        "lead": "Regla B en TEL: válido prioriza.",
        "layout": "historia",
        "pasos": [
            "Dos fijos en el mismo canal TEL (no contra emails).",
            "El válido concentra mejor señal → lugar 1.",
            "El no válido queda después.",
            "Conclusión: primero el fijo usable.",
        ],
        "tabla": {
            "headers": ["Teléfono", "Estado", "¿Primero?"],
            "rows": [
                ["Fijo A", "Válido", "Sí (lugar 1)"],
                ["Fijo B", "No válido", "No (lugar 2)"],
            ],
        },
    },
    {
        "titulo": "Historia 4 — ¿Claro o Movistar? (prefijo)",
        "lead": "Regla B: catálogo de operadores + default.",
        "layout": "historia",
        "pasos": [
            "Tomamos los 3 primeros dígitos (prefijo).",
            "Si está en la tabla (ej. 310 → Claro), usamos ese peso.",
            "Si no está (ej. 999), default 0.22: no inventamos operador; no dejamos score en cero.",
            "Conclusión: leemos el catálogo; si falta, aplicamos el default acordado.",
        ],
        "tabla": {
            "headers": ["Prefijo", "¿En tabla?", "Qué hacemos", "Efecto"],
            "rows": [
                ["310", "Sí → Claro", "Peso de Claro", "Entra al score CEL"],
                ["999", "No", "Default 0.22", "Score ej. 220; no queda en cero"],
            ],
        },
    },
    {
        "titulo": "Historia 5 — ¿Quién sí entra?",
        "lead": "Regla A completa: ganadora, canal, @, ancla de domicilio.",
        "layout": "historia",
        "pasos": [
            "DIR: solo ganadoras.",
            "TEL/CEL/EMA: solo si hay ≥1 DIR ganadora.",
            "EMA: correo con @.",
            "No entra: hija; email sin @; TEL/CEL sin ancla.",
        ],
        "tabla": {
            "headers": ["Contacto", "¿Entra?", "Motivo"],
            "rows": [
                ["Casa ganadora", "Sí", "DIR vigente"],
                ["Hija unificada", "No", "No vigente"],
                ["Fijo con DIR ganadora", "Sí", "Tiene ancla"],
                ["Celular sin DIR ganadora", "No", "Falta ancla"],
                ["mail_sin_arroba.com", "No", "Sin @"],
                ["user@empresa.co", "Sí", "EMA con @ + ancla"],
            ],
        },
    },
    {
        "titulo": "Historia 6 — Orden en calle",
        "lead": "Regla C: solo DIR escribe el orden de intento.",
        "layout": "historia",
        "pasos": [
            "Lugar 1 DIR → primer intento en campo.",
            "Lugar 2 DIR → segundo intento.",
            "TEL/CEL/EMA tienen ranking propio pero no escriben orden de calle.",
            "Al cerrar se limpian temporales; el orden guardado se queda.",
        ],
        "tabla": {
            "headers": ["Dirección", "Lugar DIR", "Orden de intento"],
            "rows": [
                ["Casa", "1", "1"],
                ["Oficina", "2", "2"],
            ],
        },
    },
    {
        "titulo": "5 · Mapa de fases (cómo corre)",
        "lead": "Las mismas reglas, en el orden de la corrida.",
        "layout": "fase_arquitectura",
        "fases": [
            {
                "fase": "0",
                "nombre": "Ya unificado",
                "pregunta": "¿Qué dirección sigue vigente?",
                "hecho": "Quedan ganadoras; las hijas no se usan para contactar.",
                "arco": "Lee el resultado de unificación (sin volver a unificar).",
            },
            {
                "fase": "1",
                "nombre": "¿Quién entra?",
                "pregunta": "¿Qué contactos pasan al ranking?",
                "hecho": "Reglas A: ganadoras, mapa de tipos, @, ancla DIR.",
                "arco": "Arma bandejas DIR/TEL/CEL/EMA.",
            },
            {
                "fase": "2",
                "nombre": "¿Cuál primero?",
                "pregunta": "¿Casa o oficina? ¿Fijo válido? ¿Operador?",
                "hecho": "Reglas B: score × catálogo; default; válido; excluidas no suman.",
                "arco": "Ordena cada canal → lugar 1, 2, 3…",
            },
            {
                "fase": "3",
                "nombre": "Guardar orden de calle",
                "pregunta": "¿Qué queda para campo?",
                "hecho": "Regla C: solo DIR escribe orden de prioridad.",
                "arco": "Persiste 1º, 2º… en la dirección.",
            },
            {
                "fase": "4",
                "nombre": "Limpiar + gate",
                "pregunta": "¿Corrida sana y sin basura?",
                "hecho": "Drop temporales; 0 hijas mal ordenadas; volúmenes > 0.",
                "arco": "Cierra la corrida lista para la siguiente.",
            },
        ],
    },
    {
        "titulo": "Siguiente",
        "lead": "Demo = mismos casos paso a paso. SPs = detalle técnico de archivos.",
        "bullets": [
            "Workshop = reglas + ejemplo + historias (este tab).",
            "Demo = recorrido por fase.",
            "SPs = catálogo técnico aparte.",
        ],
    },
]

RENDER_PRES = r"""function renderPresentacion() {
  const items = DATA.presentacion || [];
  const el = document.getElementById('presentacionWrap');
  if (!el) return;
  const tbl = (tabla) => {
    if (!tabla || !tabla.headers) return '';
    const head = tabla.headers.map(h => `<th>${esc(h)}</th>`).join('');
    const body = (tabla.rows || []).map(r =>
      `<tr>${r.map(c => `<td>${esc(String(c ?? ''))}</td>`).join('')}</tr>`
    ).join('');
    return `<div class="demo-tabla-wrap"><table class="demo-tabla"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
  };
  const mapaArq = (fases) => {
    if (!fases || !fases.length) return '';
    return `<div class="demo-fase-mapa demo-fase-arq">${fases.map((f, i) => `
      <article class="demo-fase-card">
        <div class="demo-fase-num">Fase ${esc(String(f.fase))}</div>
        <h5>${esc(f.nombre || '')}</h5>
        <p class="demo-fase-q">${esc(f.pregunta || '')}</p>
        <p class="demo-fase-h"><b>Negocio:</b> ${esc(f.hecho || '')}</p>
        <p class="demo-fase-h"><b>Cómo corre:</b> ${esc(f.arco || '')}</p>
      </article>${i < fases.length - 1 ? '<div class="demo-fase-arrow" aria-hidden="true">→</div>' : ''}`).join('')}</div>`;
  };
  const historia = (b) => {
    const pasos = (b.pasos || []).map((p, i) => {
      const txt = (typeof p === 'string') ? p : (p.hecho || p.texto || '');
      return `<li><span class="hist-n">${i + 1}</span> ${esc(txt)}</li>`;
    }).join('');
    return `${b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : ''}
      <ol class="demo-historia">${pasos}</ol>
      ${tbl(b.tabla)}`;
  };
  const reglas = (b) => {
    const grupos = (b.grupos || []).map(g => `
      <div class="demo-regla-grupo">
        <h5>${esc(g.grupo || '')}</h5>
        ${g.lead ? `<p class="demo-lead">${esc(g.lead)}</p>` : ''}
        ${tbl(g.tabla)}
      </div>`).join('');
    return `${b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : ''}${grupos}`;
  };
  const ejemploDetalle = (b) => {
    const pasos = (b.pasos || []).map((p, i) =>
      `<li><span class="hist-n">${i + 1}</span> ${esc(p)}</li>`
    ).join('');
    const tabs = (b.tablas || []).map(t => `
      <div class="demo-regla-grupo">
        <h5>${esc(t.titulo || '')}</h5>
        ${tbl(t)}
      </div>`).join('');
    return `${b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : ''}
      <ol class="demo-historia">${pasos}</ol>
      ${tabs}`;
  };
  el.innerHTML = items.map(b => {
    const lead = b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : '';
    const bullets = (b.bullets && b.bullets.length)
      ? `<ul class="demo-chips">${b.bullets.map(x => `<li>${esc(x)}</li>`).join('')}</ul>`
      : '';
    let body = `${lead}${bullets}`;
    if (b.layout === 'fase_arquitectura' || b.layout === 'fase_mapa') body = `${lead}${mapaArq(b.fases)}`;
    else if (b.layout === 'historia') body = historia(b);
    else if (b.layout === 'reglas') body = reglas(b);
    else if (b.layout === 'ejemplo_detalle') body = ejemploDetalle(b);
    return `<section class="demo-section">
      <h4>${esc(b.titulo)}</h4>
      ${body}
    </section>`;
  }).join('');
}"""

CSS_EXTRA = """
/* Workshop reglas + ejemplo detallado */
.demo-regla-grupo {
  margin: 0.85rem 0 1.1rem; padding: 0.75rem 0.85rem;
  background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px;
}
.demo-regla-grupo h5 {
  margin: 0 0 0.35rem; font-size: 0.92rem; color: #0f172a; font-weight: 800;
}
.demo-regla-grupo .demo-lead { margin: 0 0 0.55rem; font-size: 0.8rem; color: #475569; }
.demo-regla-grupo .demo-tabla-wrap { margin-top: 0.35rem; }
.demo-historia {
  margin: 0.35rem 0 0.75rem; padding: 0; list-style: none;
  display: flex; flex-direction: column; gap: 0.45rem;
}
.demo-historia li {
  display: flex; gap: 0.55rem; align-items: flex-start;
  background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px;
  padding: 0.55rem 0.7rem; font-size: 0.84rem; line-height: 1.45; color: #0f172a;
}
.demo-historia .hist-n {
  flex: 0 0 1.35rem; height: 1.35rem; border-radius: 50%;
  background: #1d6fdc; color: #fff; font-size: 0.72rem; font-weight: 800;
  display: inline-flex; align-items: center; justify-content: center;
}
"""


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def esc_js(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#x27;")
    )


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    data["presentacion"] = PRESENTACION
    html = html[:start] + to_html_json(data) + html[end:]

    pat = re.compile(r"function renderPresentacion\(\) \{\n.*?\n\}", re.S)
    ms = list(pat.finditer(html))
    if ms:
        m = ms[-1]
        html = html[: m.start()] + esc_js(RENDER_PRES) + html[m.end() :]
        print("  renderPresentacion ok")
    else:
        print("  WARN renderPresentacion")

    oi = html.find("Mapa Ordenamiento")
    se = html.find("&lt;/style&gt;", oi)
    marker = "/* Workshop reglas + ejemplo detallado */"
    if se > 0:
        if marker in html[oi:se]:
            prev = html.rfind(marker, oi, se)
            html = html[:prev] + html[se:]
            se = html.find("&lt;/style&gt;", oi)
        # also strip old historias CSS block if duplicate
        old_m = "/* Historias funcionales Workshop */"
        if old_m in html[oi:se]:
            prev = html.rfind(old_m, oi, se)
            # find end of that injected block roughly before next comment or style end
            html = html[:prev] + html[se:]
            se = html.find("&lt;/style&gt;", oi)
        html = html[:se] + CSS_EXTRA + html[se:]
        print("  CSS ok")

    path.write_text(html, encoding="utf-8")
    print("OK", path.name, "blocks", len(PRESENTACION))


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
