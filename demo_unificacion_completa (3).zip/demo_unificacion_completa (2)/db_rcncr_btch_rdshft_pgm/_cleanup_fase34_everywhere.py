# -*- coding: utf-8 -*-
"""Limpia restos de '3–4' y asegura Demo con secciones Fase 3 y Fase 4."""
from __future__ import annotations

import json
import re
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

REPLACES = [
    (
        "Vista por fases: mapa Fase 0→1→2→3–4, casos y SPs mock.",
        "Vista por fases: mapa Fase 0→1→2→3→4, casos y SPs mock.",
    ),
    (
        "Workshop — por fases (1 Insumos · 2 canales · 3–4 Salida)",
        "Workshop — por fases (1 Insumos · 2 canales · 3 Guardar · 4 Limpiar)",
    ),
    (
        "Fase 3–4 — Guardar orden y limpiar",
        "Fase 3 — Guardar orden_prioridad",
    ),
    (
        "lugar → orden_prioridad · hijas = NULL · DROP stg_*",
        "lugar → orden_prioridad · hijas = NULL",
    ),
    (
        "{ label: &#x27;Fase 3–4 · Salida&#x27;, el: &#x27;frame-salida&#x27;, ruleIdx: 6 },",
        "{ label: &#x27;Fase 3 · Guardar&#x27;, el: &#x27;frame-salida&#x27;, ruleIdx: 6 },\n  { label: &#x27;Fase 4 · Limpiar&#x27;, el: &#x27;frame-fase4&#x27;, ruleIdx: 7 },",
    ),
    (
        "{ title: &#x27;3–4 · Guardar y limpiar&#x27;, tag: &#x27;orden_prioridad&#x27;, desc: &#x27;lugar 1 → orden 1. Hijas NULL. Luego DROP stg_*.&#x27;, dev: `${fmt(k.rpu_con_orden)} RPUs`, frame: 6 },",
        "{ title: &#x27;3 · Guardar&#x27;, tag: &#x27;orden_prioridad&#x27;, desc: &#x27;lugar 1 → orden 1. Hijas NULL.&#x27;, dev: `${fmt(k.rpu_con_orden)} RPUs`, frame: 6 },\n    { title: &#x27;4 · Limpiar&#x27;, tag: &#x27;DROP stg_*&#x27;, desc: &#x27;Staging temporal eliminado al cerrar.&#x27;, dev: `bdm_tempo`, frame: 7 },",
    ),
    ("0 → 1 → 2 → 3–4", "0 → 1 → 2 → 3 → 4"),
    ("Fase 0→1→2→3–4", "Fase 0→1→2→3→4"),
    ("3–4 Salida", "3 Guardar · 4 Limpiar"),
    ("Fase 3–4 · Salida", "Fase 3 Guardar · Fase 4 Limpiar"),
]


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


CASO_F3 = {
    "id": "20001",
    "canal": "Guardar",
    "fase": "3",
    "pregunta": "Orden de intento en calle",
    "resultado": "orden_prioridad = lugar DIR en ganadoras.",
    "tabla": {
        "headers": ["RPU", "Etiqueta", "Lugar", "orden_prioridad"],
        "rows": [
            ["91001", "casa", "1", "1"],
            ["91002", "oficina", "2", "2"],
        ],
    },
}

CASO_F4 = {
    "id": "DROP",
    "canal": "Limpiar",
    "fase": "4",
    "pregunta": "Queda basura en tempo",
    "resultado": "stg_* eliminados; orden_prioridad se conserva.",
    "tabla": {
        "headers": ["Objeto", "Acción", "Resultado"],
        "rows": [
            ["bdm_tempo.stg_*", "DROP", "No queda"],
            ["bdm_datos.rpu_orden_prioridad", "Se conserva", "Salida Fase 3"],
        ],
    },
}


def patch_presentacion(data: dict) -> None:
    pres = data.get("presentacion") or []
    # clean strings
    for b in pres:
        for k, v in list(b.items()):
            if isinstance(v, str):
                b[k] = (
                    v.replace("3–4", "3 → 4")
                    .replace("3-4", "3 → 4")
                    .replace("Fase 0→1→2→3 → 4", "Fase 0→1→2→3→4")
                )
            elif isinstance(v, list) and k == "bullets":
                b[k] = [
                    x.replace("3–4", "3 y 4").replace("Fase 3–4", "Fase 3 y 4")
                    if isinstance(x, str)
                    else x
                    for x in v
                ]
        if b.get("layout") == "fase_mapa" and isinstance(b.get("fases"), list):
            fases = []
            for f in b["fases"]:
                fs = str(f.get("fase"))
                if fs in ("3–4", "3-4", "3 → 4"):
                    fases.append(
                        {
                            "fase": "3",
                            "nombre": "Guardar orden",
                            "pregunta": "Qué queda en el RPU",
                            "hecho": "consolidacion → orden_prioridad",
                        }
                    )
                    fases.append(
                        {
                            "fase": "4",
                            "nombre": "Limpiar staging",
                            "pregunta": "Queda basura en tempo",
                            "hecho": "DROP stg_* al cerrar",
                        }
                    )
                else:
                    fases.append(f)
            have = {str(x.get("fase")) for x in fases}
            if "3" not in have:
                fases.append(
                    {
                        "fase": "3",
                        "nombre": "Guardar orden",
                        "pregunta": "Qué queda en el RPU",
                        "hecho": "consolidacion → orden_prioridad",
                    }
                )
            if "4" not in have:
                fases.append(
                    {
                        "fase": "4",
                        "nombre": "Limpiar staging",
                        "pregunta": "Queda basura en tempo",
                        "hecho": "DROP stg_* al cerrar",
                    }
                )
            b["fases"] = fases

    # ensure Demo sections for fase 3 and 4
    titles = {b.get("titulo") for b in pres}
    if not any(str(b.get("fase")) == "3" for b in pres if b.get("layout") == "fase_casos"):
        # insert before cierre
        block3 = {
            "titulo": "Fase 3 — Guardar orden",
            "lead": "Qué queda en el RPU",
            "bullets": ["consolidacion → orden_prioridad", "Hijas sin fila"],
            "layout": "fase_casos",
            "fase": "3",
            "casos": [CASO_F3],
        }
        block4 = {
            "titulo": "Fase 4 — Limpiar staging",
            "lead": "Queda basura en tempo",
            "bullets": ["DROP stg_*", "La salida de negocio se conserva"],
            "layout": "fase_casos",
            "fase": "4",
            "casos": [CASO_F4],
        }
        out = []
        inserted = False
        for b in pres:
            if not inserted and (
                "Cierre" in str(b.get("titulo") or "")
                or b.get("layout") == "sps_final"
            ):
                out.append(block3)
                out.append(block4)
                inserted = True
            out.append(b)
        if not inserted:
            out.extend([block3, block4])
        data["presentacion"] = out
        print("  demo fase 3/4 sections added")
    else:
        # refresh casos if empty
        for b in pres:
            if b.get("layout") == "fase_casos" and str(b.get("fase")) == "3" and not b.get("casos"):
                b["casos"] = [CASO_F3]
            if b.get("layout") == "fase_casos" and str(b.get("fase")) == "4" and not b.get("casos"):
                b["casos"] = [CASO_F4]
        data["presentacion"] = pres

    # fases_doc
    fases = data.get("fases_doc") or []
    cleaned = []
    for f in fases:
        if str(f.get("fase")) in ("3–4", "3-4"):
            cleaned.append(
                {
                    "fase": "3",
                    "nombre": "Guardar orden",
                    "requiere": "Qué queda en el RPU",
                    "implementado": "consolidacion → orden_prioridad",
                    "estado": "ok",
                    "nota": "Gate: 0 hijas con orden",
                }
            )
            cleaned.append(
                {
                    "fase": "4",
                    "nombre": "Limpiar staging",
                    "requiere": "Queda basura en tempo",
                    "implementado": "drop stg_*",
                    "estado": "ok",
                    "nota": "Siguiente corrida recrea staging",
                }
            )
        else:
            cleaned.append(f)
    have = {str(f.get("fase")) for f in cleaned}
    if "3" not in have:
        cleaned.append(
            {
                "fase": "3",
                "nombre": "Guardar orden",
                "requiere": "Qué queda en el RPU",
                "implementado": "consolidacion → orden_prioridad",
                "estado": "ok",
                "nota": "",
            }
        )
    if "4" not in have:
        cleaned.append(
            {
                "fase": "4",
                "nombre": "Limpiar staging",
                "requiere": "Queda basura en tempo",
                "implementado": "drop stg_*",
                "estado": "ok",
                "nota": "",
            }
        )
    data["fases_doc"] = cleaned


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    n = 0
    for old, new in REPLACES:
        c = html.count(old)
        if c:
            html = html.replace(old, new)
            n += c
    print(f"  string replaces: {n}")

    # ensure RULE_FRAMES has LIMPIEZA
    if "regla: &#x27;LIMPIEZA&#x27;" not in html.split("Mapa Ordenamiento")[-1]:
        old_rf_end = "{ regla: &#x27;CONSOLIDACIÓN&#x27;, nav: &#x27;nav-salida&#x27;, stage: &#x27;stage-salida&#x27; },\n];"
        new_rf_end = (
            "{ regla: &#x27;CONSOLIDACIÓN&#x27;, nav: &#x27;nav-salida&#x27;, stage: &#x27;stage-salida&#x27; },\n"
            "  { regla: &#x27;LIMPIEZA&#x27;, nav: &#x27;nav-fase4&#x27;, stage: &#x27;stage-fase4&#x27; },\n];"
        )
        if old_rf_end in html:
            idx = html.rfind(old_rf_end)
            html = html[:idx] + new_rf_end + html[idx + len(old_rf_end) :]
            print("  RULE_FRAMES LIMPIEZA added")

    if "frame-fase4" not in html:
        print("  WARN missing frame-fase4 — re-run split script")

    if "scenarioPos = { 1:0, 2:0, 3:0, 4:0, 5:0, 6:0 };" in html:
        html = html.replace(
            "const scenarioPos = { 1:0, 2:0, 3:0, 4:0, 5:0, 6:0 };",
            "const scenarioPos = { 1:0, 2:0, 3:0, 4:0, 5:0, 6:0, 7:0 };",
            1,
        )

    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    patch_presentacion(data)
    # ensure DROP row
    rows = data.get("rows") or []
    if not any(r.get("_pack_code") == "DROP" for r in rows):
        print("  WARN no DROP row in data")
    html = html[:start] + to_html_json(data) + html[end:]
    path.write_text(html, encoding="utf-8")

    # leftover check in ord iframe
    a = html.find("Mapa Ordenamiento")
    chunk = html[a : html.find('"></iframe>', a)]
    left = []
    for pat in ("3–4", "3-4", "Guardar y limpiar"):
        if pat in chunk:
            left.append(pat)
    print("OK", path.name, "leftover", left or "none", "Fase 4 Limpiar", "Fase 4 · Limpiar" in chunk or "Fase 4" in unescape(chunk))


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
