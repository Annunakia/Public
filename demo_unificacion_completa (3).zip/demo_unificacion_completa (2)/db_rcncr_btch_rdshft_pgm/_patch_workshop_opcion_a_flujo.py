# -*- coding: utf-8 -*-
"""
Workshop:
1) Qué es ordenamiento
2) En qué fases se divide
3) Ejemplos (solo 20001 → 20011 → 20010)
4) Valores / números
Explica Opción A en palabras. Quita TEL/CEL/EMA del recorrido Workshop.
Cada concepto se explica en la misma frase (sin diccionario).
"""
from __future__ import annotations

import json
import re
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

PRESENTACION = [
    {
        "titulo": "1 · Qué es el ordenamiento",
        "lead": (
            "Después de unificar personas y domicilios, una misma persona puede quedar "
            "con varias casas, oficinas, fijos, celulares o correos. "
            "El ordenamiento responde una sola pregunta de negocio: ¿cuál intento primero?"
        ),
        "bullets": [
            (
                "No vuelve a unificar: parte de lo que ya quedó después de unificar "
                "(qué domicilio sigue vigente y cuáles ya no)."
            ),
            (
                "Ordena por tipo: las direcciones entre sí, los fijos entre sí, "
                "los celulares entre sí, los correos entre sí. Un fijo no compite contra un email."
            ),
            (
                "Al final deja escrito el orden de intento en calle (1º, 2º…) "
                "para los domicilios que sí usamos."
            ),
        ],
    },
    {
        "titulo": "Qué es la «Opción A» (en palabras)",
        "lead": (
            "En la mesa se acordó una forma de hacerlo. Esa forma se llamó Opción A. "
            "En simple significa esto:"
        ),
        "bullets": [
            (
                "Ya terminó la unificación: no volvemos a mezclar personas ni domicilios."
            ),
            (
                "Solo miramos domicilios que sí usamos (dirección ganadora = domicilio vigente). "
                "Los absorbidos (hijas) no entran a ordenar."
            ),
            (
                "El puntaje se arma con los pesos del catálogo que ya acordamos "
                "(no se inventan pesos en la corrida)."
            ),
            (
                "Se ordenan cuatro tipos de contacto por separado: "
                "dirección, fijo, celular y correo."
            ),
            (
                "No pasamos por otra malla intermedia: leemos el resultado unificado "
                "y ordenamos directo."
            ),
        ],
    },
    {
        "titulo": "2 · En qué fases se divide",
        "lead": "El recorrido de negocio es el mismo de punta a punta.",
        "layout": "fase_arquitectura",
        "fases": [
            {
                "fase": "0",
                "nombre": "Ya unificado",
                "pregunta": "¿Qué domicilio sigue vigente?",
                "hecho": (
                    "Quedan los domicilios que sí usamos; los absorbidos ya no se contactan."
                ),
                "arco": "Solo leemos el resultado de unificación.",
            },
            {
                "fase": "1",
                "nombre": "¿Quién entra?",
                "pregunta": "¿Qué contactos pasan a comparar?",
                "hecho": (
                    "Entra el domicilio vigente. Correo sin @ no entra. "
                    "Fijo/celular/correo solo si la persona ya tiene un domicilio que sí usamos."
                ),
                "arco": "Arma las listas por tipo (dirección, fijo, celular, correo).",
            },
            {
                "fase": "2",
                "nombre": "¿Cuál primero?",
                "pregunta": "¿Casa o oficina? ¿Qué fijo? ¿Qué celular? ¿Qué correo?",
                "hecho": (
                    "Dentro de cada tipo, gana el mayor puntaje "
                    "(datos que aportan × pesos del catálogo) → lugar 1, 2, 3…"
                ),
                "arco": "2a direcciones · 2b fijos · 2c celulares · 2d correos.",
            },
            {
                "fase": "3",
                "nombre": "Guardar orden en calle",
                "pregunta": "¿Qué queda escrito para intentar en campo?",
                "hecho": (
                    "El 1º y 2º de las direcciones se guardan como orden de intento. "
                    "Fijo/celular/correo no escriben ese orden de calle."
                ),
                "arco": "Persiste 1º, 2º… en el domicilio.",
            },
            {
                "fase": "4",
                "nombre": "Limpiar y validar",
                "pregunta": "¿Corrida sana y sin basura?",
                "hecho": (
                    "Se borran temporales; el orden guardado se conserva. "
                    "Chequeo: ningún domicilio absorbido mal ordenado."
                ),
                "arco": "Cierra la corrida lista para la siguiente.",
            },
        ],
    },
    {
        "titulo": "3 · Ejemplos (solo estos tres)",
        "lead": (
            "En este Workshop miramos tres personas. "
            "Después del 20010 no seguimos con más casos aquí."
        ),
        "layout": "fases_lado_a_lado",
        "fases": [
            {
                "fase": "ej. 20001",
                "nombre": "Casa o oficina — ¿cuál primero?",
                "pregunta": "Misma persona, dos domicilios vigentes.",
                "reglas": [
                    {
                        "titulo": "Qué miramos",
                        "texto": (
                            "Las dos son direcciones ganadoras, es decir domicilios que sí usamos "
                            "después de unificar. Compiten solo entre direcciones."
                        ),
                    },
                    {
                        "titulo": "Cómo se decide",
                        "texto": (
                            "Se calcula un puntaje (score) con datos que aportan × pesos del catálogo. "
                            "Mayor puntaje = se intenta antes."
                        ),
                    },
                    {
                        "titulo": "Qué queda",
                        "texto": (
                            "Casa lugar 1 y oficina lugar 2. Ese mismo orden se guarda para calle "
                            "(1º intento, 2º intento)."
                        ),
                    },
                ],
                "ejemplo": {
                    "titulo": "Valores del ejemplo",
                    "caso": "Persona 20001 · casa 91001 · oficina 91002",
                    "pasos": [
                        "Casa puntaje 850 → 1º.",
                        "Oficina puntaje 700 → 2º.",
                        "En campo: primero casa, después oficina.",
                    ],
                    "tabla": {
                        "headers": ["Dirección", "¿La usamos?", "Puntaje", "Orden"],
                        "rows": [
                            ["Casa 91001", "Sí (vigente)", "850", "1º"],
                            ["Oficina 91002", "Sí (vigente)", "700", "2º"],
                        ],
                    },
                },
            },
            {
                "fase": "ej. 20011",
                "nombre": "Padre e hija — ¿quién entra?",
                "pregunta": "Un domicilio vigente y uno ya absorbido.",
                "reglas": [
                    {
                        "titulo": "Qué miramos",
                        "texto": (
                            "El padre es el domicilio que sí usamos. "
                            "La hija es el domicilio absorbido: ya no lo contactamos."
                        ),
                    },
                    {
                        "titulo": "Cómo se decide",
                        "texto": (
                            "Solo el vigente entra a puntuar y a ordenar. "
                            "La hija no recibe puntaje ni orden de intento."
                        ),
                    },
                    {
                        "titulo": "Qué queda",
                        "texto": "Solo el padre queda de primeras; la hija no se intenta.",
                    },
                ],
                "ejemplo": {
                    "titulo": "Valores del ejemplo",
                    "caso": "Persona 20011 · padre 91018 · hija 91019",
                    "pasos": [
                        "Padre 91018 → sí entra (puntaje y orden).",
                        "Hija 91019 → no aparece en puntaje ni en orden.",
                    ],
                    "tabla": {
                        "headers": ["Rol", "RPU", "¿Entra?", "Puntaje / orden"],
                        "rows": [
                            ["Padre (vigente)", "91018", "Sí", "639.7849 / 1"],
                            ["Hija (absorbida)", "91019", "No", "— / —"],
                        ],
                    },
                },
            },
            {
                "fase": "ej. 20010",
                "nombre": "Empate de puntaje — ¿qué pasa?",
                "pregunta": "Dos domicilios vigentes con el mismo puntaje.",
                "reglas": [
                    {
                        "titulo": "Qué miramos",
                        "texto": (
                            "Los dos domicilios sí se usan (vigentes) y sacan el mismo puntaje."
                        ),
                    },
                    {
                        "titulo": "Cómo se decide",
                        "texto": (
                            "No inventamos una regla nueva de negocio para desempatar: "
                            "quedan lugar 1 y 2 por el orden técnico de la corrida."
                        ),
                    },
                    {
                        "titulo": "Qué queda",
                        "texto": "Ambos con puntaje 777; uno en 1º y el otro en 2º.",
                    },
                ],
                "ejemplo": {
                    "titulo": "Valores del ejemplo",
                    "caso": "Persona 20010 · 91016 y 91017",
                    "pasos": [
                        "Mismo puntaje 777 en ambos.",
                        "Lugares 1 y 2 sin regla de negocio extra de desempate.",
                    ],
                    "tabla": {
                        "headers": ["Etiqueta", "RPU", "Puntaje", "Lugar"],
                        "rows": [
                            ["empate_a", "91016", "777", "1"],
                            ["empate_b", "91017", "777", "2"],
                        ],
                    },
                },
            },
        ],
    },
    {
        "titulo": "4 · Valores que tenemos (corrida real)",
        "lead": (
            "Después de los ejemplos, estos son los números de la corrida "
            "(para cerrar la mesa con magnitudes, no con más casos)."
        ),
        "layout": "valores",
        "valores": [
            {"label": "Personas", "valor": "407.351", "nota": "Universo de personas"},
            {
                "label": "Domicilios que sí usamos",
                "valor": "518.718",
                "nota": "Direcciones ganadoras (vigentes)",
            },
            {
                "label": "Domicilios absorbidos",
                "valor": "72.448",
                "nota": "Hijas: no entran a ordenar",
            },
            {
                "label": "Domicilios con orden de calle",
                "valor": "410.100",
                "nota": "Ya tienen 1º, 2º… guardado",
            },
            {
                "label": "Pesos del catálogo",
                "valor": "47",
                "nota": "Coeficientes acordados para el puntaje",
            },
            {
                "label": "Puntajes calculados",
                "valor": "1.227.894",
                "nota": "Scores en la corrida DEV",
            },
            {
                "label": "Absorbidos mal ordenados",
                "valor": "0",
                "nota": "Chequeo de aceptación: debe ser cero",
            },
        ],
    },
    {
        "titulo": "Siguiente",
        "lead": (
            "En Demo recorres los mismos tres ejemplos paso a paso. "
            "En SPs está el detalle técnico de archivos."
        ),
        "bullets": [
            "Workshop = qué es → fases → ejemplos 20001 / 20011 / 20010 → valores.",
            "Recorrido de personas en este tab: 20001 → 20011 → 20010 → salida.",
            "TEL / CEL / EMA (20004, 20013, 20012, 20014) no van en este Workshop.",
        ],
    },
]

RENDER_PRES = r"""function renderPresentacion() {
  const items = DATA.presentacion || [];
  const el = document.getElementById('presentacionWrap');
  if (!el) return;
  const tbl = (tabla) => {
    if (!tabla || !tabla.headers) return '';
    const head = tabla.headers.map(h => `<th>${esc(h)}</th>`).join('');
    const body = (tabla.rows || []).map(r =>
      `<tr>${r.map(c => `<td>${esc(String(c ?? ''))}</td>`).join('')}</tr>`
    ).join('');
    return `<div class="demo-tabla-wrap"><table class="demo-tabla"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
  };
  const mapaArq = (fases) => {
    if (!fases || !fases.length) return '';
    return `<div class="demo-fase-mapa demo-fase-arq">${fases.map((f, i) => `
      <article class="demo-fase-card">
        <div class="demo-fase-num">Fase ${esc(String(f.fase))}</div>
        <h5>${esc(f.nombre || '')}</h5>
        <p class="demo-fase-q">${esc(f.pregunta || '')}</p>
        <p class="demo-fase-h"><b>Negocio:</b> ${esc(f.hecho || '')}</p>
        <p class="demo-fase-h"><b>Cómo corre:</b> ${esc(f.arco || '')}</p>
      </article>${i < fases.length - 1 ? '<div class="demo-fase-arrow" aria-hidden="true">→</div>' : ''}`).join('')}</div>`;
  };
  const fasesLado = (b) => {
    const bloques = (b.fases || []).map(f => {
      const reglas = (f.reglas || []).map(r => `
        <div class="demo-regla-item">
          <strong>${esc(r.titulo || '')}</strong>
          <p>${esc(r.texto || '')}</p>
        </div>`).join('');
      const ej = f.ejemplo || {};
      const pasos = (ej.pasos || []).map((p, i) =>
        `<li><span class="hist-n">${i + 1}</span> ${esc(p)}</li>`
      ).join('');
      return `
      <section class="demo-fase-duo">
        <header class="demo-fase-duo-h">
          <span class="demo-fase-pill">${esc(String(f.fase))}</span>
          <div>
            <h5>${esc(f.nombre || '')}</h5>
            <p class="demo-fase-q">${esc(f.pregunta || '')}</p>
          </div>
        </header>
        <div class="demo-fase-duo-grid">
          <div class="demo-fase-col demo-fase-col-regla">
            <div class="demo-col-label">En simple</div>
            ${reglas}
          </div>
          <div class="demo-fase-col demo-fase-col-ej">
            <div class="demo-col-label">${esc(ej.titulo || 'Ejemplo')}</div>
            ${ej.caso ? `<p class="demo-ej-caso"><b>Caso:</b> ${esc(ej.caso)}</p>` : ''}
            <ol class="demo-historia">${pasos}</ol>
            ${tbl(ej.tabla)}
          </div>
        </div>
      </section>`;
    }).join('');
    return `${b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : ''}${bloques}`;
  };
  const valores = (b) => {
    const cards = (b.valores || []).map(v => `
      <article class="demo-valor-card">
        <small>${esc(v.label || '')}</small>
        <b>${esc(v.valor || '')}</b>
        <span>${esc(v.nota || '')}</span>
      </article>`).join('');
    return `${b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : ''}
      <div class="demo-valores-grid">${cards}</div>`;
  };
  el.innerHTML = items.map(b => {
    const lead = b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : '';
    const bullets = (b.bullets && b.bullets.length)
      ? `<ul class="demo-chips">${b.bullets.map(x => `<li>${esc(x)}</li>`).join('')}</ul>`
      : '';
    let body = `${lead}${bullets}`;
    if (b.layout === 'fase_arquitectura' || b.layout === 'fase_mapa') body = `${lead}${mapaArq(b.fases)}`;
    else if (b.layout === 'fases_lado_a_lado') body = fasesLado(b);
    else if (b.layout === 'valores') body = valores(b);
    return `<section class="demo-section">
      <h4>${esc(b.titulo)}</h4>
      ${body}
    </section>`;
  }).join('');
}"""

CSS_EXTRA = """
/* Workshop: fases + ejemplo al lado + valores */
.demo-fase-duo {
  margin: 1rem 0 1.25rem; border: 1px solid #e2e8f0; border-radius: 14px;
  background: #fff; overflow: hidden;
}
.demo-fase-duo-h {
  display: flex; gap: 0.75rem; align-items: flex-start;
  padding: 0.75rem 0.9rem; background: #f1f5f9; border-bottom: 1px solid #e2e8f0;
}
.demo-fase-duo-h h5 { margin: 0 0 0.2rem; font-size: 0.95rem; color: #0f172a; }
.demo-fase-pill {
  flex: 0 0 auto; background: #1d6fdc; color: #fff; font-size: 0.72rem; font-weight: 800;
  border-radius: 999px; padding: 0.28rem 0.6rem; white-space: nowrap;
}
.demo-fase-duo-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0; }
@media (max-width: 820px) { .demo-fase-duo-grid { grid-template-columns: 1fr; } }
.demo-fase-col { padding: 0.75rem 0.9rem; }
.demo-fase-col-regla { border-right: 1px solid #e2e8f0; background: #fafbfc; }
@media (max-width: 820px) {
  .demo-fase-col-regla { border-right: none; border-bottom: 1px solid #e2e8f0; }
}
.demo-col-label {
  font-size: 0.7rem; font-weight: 800; letter-spacing: 0.04em; text-transform: uppercase;
  color: #64748b; margin-bottom: 0.55rem;
}
.demo-regla-item {
  margin: 0 0 0.55rem; padding: 0.5rem 0.6rem;
  background: #fff; border: 1px solid #e2e8f0; border-radius: 10px;
}
.demo-regla-item strong { display: block; font-size: 0.82rem; color: #0f172a; margin-bottom: 0.2rem; }
.demo-regla-item p { margin: 0; font-size: 0.78rem; line-height: 1.4; color: #334155; }
.demo-ej-caso { margin: 0 0 0.5rem; font-size: 0.8rem; color: #0f172a; }
.demo-historia {
  margin: 0.25rem 0 0.65rem; padding: 0; list-style: none;
  display: flex; flex-direction: column; gap: 0.4rem;
}
.demo-historia li {
  display: flex; gap: 0.5rem; align-items: flex-start;
  background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px;
  padding: 0.45rem 0.6rem; font-size: 0.78rem; line-height: 1.4; color: #0f172a;
}
.demo-historia .hist-n {
  flex: 0 0 1.25rem; height: 1.25rem; border-radius: 50%;
  background: #1d6fdc; color: #fff; font-size: 0.68rem; font-weight: 800;
  display: inline-flex; align-items: center; justify-content: center;
}
.demo-valores-grid {
  display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
  gap: 0.65rem; margin-top: 0.55rem;
}
.demo-valor-card {
  background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px;
  padding: 0.7rem 0.8rem; display: flex; flex-direction: column; gap: 0.2rem;
}
.demo-valor-card small { font-size: 0.72rem; color: #64748b; font-weight: 700; }
.demo-valor-card b { font-size: 1.15rem; color: #0f172a; }
.demo-valor-card span { font-size: 0.72rem; color: #475569; line-height: 1.35; }
.presentacion-wrap { max-width: 1100px; }
"""

# Demo tab (frame-workshop): solo insumos + DIR + guardar + limpiar
WORKSHOP_STEPS_NEW = """const WORKSHOP_STEPS = [
  { label: &#x27;Fase 1 · Quién entra&#x27;, el: &#x27;frame-fase1&#x27;, ruleIdx: 1 },
  { label: &#x27;Fase 2 · Direcciones&#x27;, el: &#x27;frame-dir&#x27;, ruleIdx: 2 },
  { label: &#x27;Fase 3 · Guardar&#x27;, el: &#x27;frame-salida&#x27;, ruleIdx: 6 },
  { label: &#x27;Fase 4 · Limpiar&#x27;, el: &#x27;frame-fase4&#x27;, ruleIdx: 7 },
];"""

BANNER_OLD = (
    "Empieza por la &lt;strong&gt;presentación&lt;/strong&gt; (qué busca). "
    "En cada tarjeta: persona + id → regla → evidencia → conclusión. "
    "Workshop: 20001 → 20011 → 20010 → 20004 → 20013 → 20012 → 20014 → salida."
)
BANNER_NEW = (
    "Primero: qué es el ordenamiento y la Opción A (en palabras). "
    "Luego las fases. Después los ejemplos 20001 → 20011 → 20010. "
    "Al final los valores de la corrida. "
    "Workshop: 20001 → 20011 → 20010 → salida."
)

SUB_OLD = (
    "Opción A · post-unificación · betas catálogo RITM · 4 canales · edf_views"
)
SUB_NEW = (
    "Ordenamiento post-unificación: ¿cuál intento primero? "
    "Opción A = solo domicilios vigentes + pesos del catálogo acordado"
)

DOC_LINE_OLD = (
    "Demo funcional · Workshop con detalle · SPs en STAR. "
    "Opción A · solo ganadoras · betas RITM."
)
DOC_LINE_NEW = (
    "Workshop (qué es → fases → ejemplos → valores) · Demo paso a paso · SPs técnicos. "
    "Opción A = ordenar solo domicilios vigentes con el catálogo acordado."
)

GLOSS_OPCION_OLD = (
    "&lt;div class=&quot;glossary-card&quot;&gt;&lt;h4&gt;Opción A&lt;/h4&gt;"
    "&lt;p&gt;Acuerdo sesión: scoring directo post-unificación desde "
    "&lt;strong&gt;edf_views&lt;/strong&gt;. Sin malla 242.&lt;/p&gt;&lt;/div&gt;"
)
GLOSS_OPCION_NEW = (
    "&lt;div class=&quot;glossary-card&quot;&gt;&lt;h4&gt;Opción A (en palabras)&lt;/h4&gt;"
    "&lt;p&gt;Acuerdo de mesa: ya unificado, ordenamos solo domicilios que sí usamos "
    "(vigentes), con los pesos del catálogo acordado, sin otra malla intermedia.&lt;/p&gt;&lt;/div&gt;"
)


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def esc_js(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#x27;")
    )


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    data["presentacion"] = PRESENTACION
    html = html[:start] + to_html_json(data) + html[end:]

    pat = re.compile(r"function renderPresentacion\(\) \{\n.*?\n\}", re.S)
    ms = list(pat.finditer(html))
    if not ms:
        raise SystemExit("renderPresentacion not found")
    m = ms[-1]
    html = html[: m.start()] + esc_js(RENDER_PRES) + html[m.end() :]
    print("  renderPresentacion ok")

    # WORKSHOP_STEPS: drop TEL/CEL/EMA
    m = re.search(
        r"const WORKSHOP_STEPS = \[\n(?:.*?\n)*?\];",
        html,
    )
    if m:
        html = html[: m.start()] + WORKSHOP_STEPS_NEW + html[m.end() :]
        print("  WORKSHOP_STEPS trimmed ok")
    else:
        print("  WARN WORKSHOP_STEPS")

    for old, new, name in [
        (BANNER_OLD, BANNER_NEW, "banner"),
        (SUB_OLD, SUB_NEW, "subtitle"),
        (DOC_LINE_OLD, DOC_LINE_NEW, "doc line"),
        (GLOSS_OPCION_OLD, GLOSS_OPCION_NEW, "gloss opcion A"),
    ]:
        if old in html:
            html = html.replace(old, new, 1)
            print(" ", name, "ok")
        else:
            print(" ", name, "skip")

    # Soft replace remaining workshop chain mentions
    html = html.replace(
        "Workshop: 20001 → 20011 → 20010 → 20004 → 20013 → 20012 → 20014 → salida.",
        "Workshop: 20001 → 20011 → 20010 → salida.",
    )

    oi = html.find("Mapa Ordenamiento")
    se = html.find("&lt;/style&gt;", oi)
    markers = [
        "/* Workshop: fases + ejemplo al lado + valores */",
        "/* Workshop: glosario + fase con ejemplo al lado */",
        "/* Workshop reglas + ejemplo detallado */",
    ]
    if se > 0:
        for marker in markers:
            if marker in html[oi:se]:
                prev = html.rfind(marker, oi, se)
                html = html[:prev] + html[se:]
                se = html.find("&lt;/style&gt;", oi)
        html = html[:se] + CSS_EXTRA + html[se:]
        print("  CSS ok")

    path.write_text(html, encoding="utf-8")
    print("OK", path.name)


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
