# -*- coding: utf-8 -*-
import json, re, sys
from html import unescape
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
p = Path(r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html")
t = unescape(p.read_text(encoding="utf-8"))

def extract_obj(s, start):
    depth = 0; in_q = False; esc = False; j = start
    while j < len(s):
        ch = s[j]
        if in_q:
            if esc: esc = False
            elif ch == "\\": esc = True
            elif ch == '"': in_q = False
        else:
            if ch == '"': in_q = True
            elif ch == "{": depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return json.loads(s[start:j+1])
        j += 1

datas = list(re.finditer(r"const DATA = (\{)", t))
d = extract_obj(t, datas[1].start(1))
pres = d.get("presentacion") or []
print("=== presentacion blocks ===")
for i, b in enumerate(pres):
    print(i, b.get("titulo"), "keys", list(b.keys()))
    if b.get("bullets"):
        for x in b["bullets"]:
            print("  -", x[:100])
    if b.get("casos"):
        print("  casos", len(b["casos"]), [c.get("id")+"/"+c.get("canal") for c in b["casos"]])

print("\n=== sps_detalle ids ===")
for s in (d.get("sps_detalle") or [])[:20]:
    print(s.get("id"), s.get("archivo"), (s.get("objetivo") or s.get("rol") or "")[:60])

print("\n=== mock related keys ===")
for k in d:
    if "mock" in k.lower() or "sp" in k.lower() or "seed" in k.lower():
        v = d[k]
        print(k, type(v).__name__, str(v)[:120] if not isinstance(v, (list, dict)) else (len(v) if isinstance(v, list) else list(v.keys())[:8]))
