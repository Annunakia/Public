# -*- coding: utf-8 -*-
"""Demo: columna de SPs mock al frente de la lista final (Siguiente paso)."""
from __future__ import annotations

import json
import re
import shutil
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

MOCK_SPS = [
    {
        "id": "SP-M01",
        "archivo": "sp_ordenamiento_cargar_seed_mock.sql",
        "rol": "Carga seed 20001–20014 en bdm_stage.mock_ord_*.",
    },
    {
        "id": "SP-M02",
        "archivo": "sp_ordenamiento_validar_mock.sql",
        "rol": "Valida CA-O01…CA-O12 sobre el seed.",
    },
    {
        "id": "SP-M03",
        "archivo": "sp_ordenamiento_ejecucion_mock.sql",
        "rol": "Orquesta la demo mock (seed + validación).",
    },
]

SIGUIENTE = {
    "titulo": "Siguiente paso",
    "lead": "A la izquierda los SPs mock de la demo; a la derecha el recorrido en Recorrido.",
    "layout": "sps_final",
    "sps_mock": MOCK_SPS,
    "bullets": [
        "Un solo paso: Insumos → DIR → TEL → CEL → EMA → Salida.",
        "En cada bloque: qué abrimos, qué vemos, tabla y SP que lo hace.",
        "La evidencia de esta Demo sale de CALL bdm_stage.sp_ordenamiento_ejecucion_mock.",
    ],
}

RENDER_PRES = r"""function renderPresentacion() {
  const items = DATA.presentacion || [];
  const el = document.getElementById('presentacionWrap');
  if (!el) return;
  const tbl = (tabla) => {
    if (!tabla || !tabla.headers) return '';
    const head = tabla.headers.map(h => `<th>${esc(h)}</th>`).join('');
    const body = (tabla.rows || []).map(r =>
      `<tr>${r.map(c => `<td>${esc(String(c ?? ''))}</td>`).join('')}</tr>`
    ).join('');
    return `<div class="demo-tabla-wrap"><table class="demo-tabla"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
  };
  const spsCol = (list) => {
    if (!list || !list.length) return '';
    return `<aside class="demo-sps-col">
      <div class="demo-sps-title">SPs mock de la Demo</div>
      <ul class="demo-sps-list">${list.map(s => `
        <li>
          <header><code>${esc(s.id)}</code></header>
          <div class="demo-sps-file">${esc(s.archivo || '')}</div>
          <p>${esc(s.rol || s.objetivo || '')}</p>
        </li>`).join('')}</ul>
    </aside>`;
  };
  el.innerHTML = items.map(b => {
    const lead = b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : '';
    const bullets = (b.bullets && b.bullets.length)
      ? `<ul class="demo-chips">${b.bullets.map(x => `<li>${esc(x)}</li>`).join('')}</ul>`
      : '';
    const casos = (b.casos && b.casos.length)
      ? `<div class="demo-casos">${b.casos.map(c => `
          <article class="demo-caso">
            <header>
              <span class="demo-id">${esc(c.id)}</span>
              <span class="demo-canal">${esc(c.canal)}</span>
            </header>
            <p class="demo-q">${esc(c.pregunta)}</p>
            ${tbl(c.tabla)}
            <p class="demo-r">${esc(c.resultado)}</p>
          </article>`).join('')}</div>`
      : '';
    let body = `${lead}${bullets}${casos}`;
    if (b.layout === 'sps_final') {
      body = `<div class="demo-final-grid">${spsCol(b.sps_mock)}<div class="demo-final-main">${lead}${bullets}</div></div>`;
    }
    return `<section class="demo-section">
      <h4>${esc(b.titulo)}</h4>
      ${body}
    </section>`;
  }).join('');
}"""

# CSS sin comillas dobles (srcdoc)
CSS_EXTRA = r"""
/* Demo final: SPs mock + lista */
.demo-final-grid {
  display: grid;
  grid-template-columns: minmax(220px, 0.95fr) minmax(0, 1.35fr);
  gap: 0.85rem;
  align-items: start;
  margin-top: 0.35rem;
}
.demo-sps-col {
  border: 1px solid #c7d2fe;
  background: linear-gradient(180deg, #eef2ff 0%, #fff 55%);
  border-radius: 12px;
  padding: 0.7rem 0.75rem;
}
.demo-sps-title {
  font-size: 0.72rem;
  font-weight: 800;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: #3730a3;
  margin-bottom: 0.5rem;
}
.demo-sps-list {
  list-style: none; margin: 0; padding: 0;
  display: flex; flex-direction: column; gap: 0.45rem;
}
.demo-sps-list li {
  background: #fff;
  border: 1px solid #e0e7ff;
  border-radius: 10px;
  padding: 0.45rem 0.55rem;
}
.demo-sps-list li header code {
  font-size: 0.78rem; font-weight: 800; color: #1e3a8a;
}
.demo-sps-file {
  font-family: Consolas, ui-monospace, monospace;
  font-size: 0.68rem; color: #64748b;
  margin: 0.15rem 0 0.25rem; word-break: break-all;
}
.demo-sps-list li p {
  margin: 0; font-size: 0.76rem; color: #312e81; line-height: 1.35;
}
.demo-final-main .demo-lead { margin-top: 0; }
@media (max-width: 820px) {
  .demo-final-grid { grid-template-columns: 1fr; }
}
"""

MARKER_CSS = "/* Demo final: SPs mock + lista */"


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def esc_js(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#x27;")
    )


def patch_data(data: dict) -> None:
    pres = data.get("presentacion") or []
    # enrich sps from sps_detalle if present
    by_id = {s.get("id"): s for s in (data.get("sps_detalle") or [])}
    sps = []
    for m in MOCK_SPS:
        sp = by_id.get(m["id"]) or {}
        sps.append(
            {
                "id": m["id"],
                "archivo": sp.get("archivo") or m["archivo"],
                "rol": sp.get("objetivo") or sp.get("rol") or m["rol"],
            }
        )
    block = dict(SIGUIENTE)
    block["sps_mock"] = sps
    replaced = False
    for i, b in enumerate(pres):
        if b.get("titulo") == "Siguiente paso" or b.get("layout") == "sps_final":
            pres[i] = block
            replaced = True
            break
    if not replaced:
        pres.append(block)
    data["presentacion"] = pres


def patch_ui(html: str) -> str:
    # replace last renderPresentacion
    pat = re.compile(r"function renderPresentacion\(\) \{\n.*?\n\}", re.S)
    ms = list(pat.finditer(html))
    if not ms:
        print("  WARN renderPresentacion")
    else:
        m = ms[-1]
        html = html[: m.start()] + esc_js(RENDER_PRES) + html[m.end() :]
        print("  renderPresentacion ok")

    # CSS inside ord iframe style (before escaped </style>)
    oi = html.find("Mapa Ordenamiento")
    style_end = html.find("&lt;/style&gt;", oi) if oi >= 0 else -1
    if style_end < 0:
        print("  WARN no iframe style")
        return html
    if MARKER_CSS in html[oi:style_end]:
        prev = html.rfind(MARKER_CSS, oi, style_end)
        html = html[:prev] + html[style_end:]
        style_end = html.find("&lt;/style&gt;", oi)
        print("  refreshed final-grid CSS")
    if '"' in CSS_EXTRA:
        raise SystemExit("CSS has double quotes — would break srcdoc")
    html = html[:style_end] + CSS_EXTRA + html[style_end:]
    print("  CSS ok")
    return html


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    assert len(positions) >= 2
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    patch_data(data)
    html = html[:start] + to_html_json(data) + html[end:]
    html = patch_ui(html)
    bak = path.with_suffix(path.suffix + ".bak_sps_col")
    if not bak.exists():
        shutil.copy2(path, bak)
    path.write_text(html, encoding="utf-8")
    # verify srcdoc
    a = html.find('iframe title="Mapa Ordenamiento"')
    sd = html.find('srcdoc="', a)
    end_i = html.find('"></iframe>', sd)
    chunk = html[sd:end_i]
    print("OK", path.name, "srcdoc quotes", chunk.count('"'), "sps_final", "sps_final" in chunk)


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
