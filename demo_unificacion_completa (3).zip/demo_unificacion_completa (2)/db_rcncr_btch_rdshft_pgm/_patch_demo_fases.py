# -*- coding: utf-8 -*-
"""Demo y Recorrido orientados a fases visibles (0, 1, 2, 3–4)."""
from __future__ import annotations

import json
import re
import shutil
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

MOCK_SPS = [
    {
        "id": "SP-M01",
        "archivo": "sp_ordenamiento_cargar_seed_mock.sql",
        "rol": "Carga seed 20001–20014 en bdm_stage.mock_ord_*.",
    },
    {
        "id": "SP-M02",
        "archivo": "sp_ordenamiento_validar_mock.sql",
        "rol": "Valida CA-O01…CA-O12 sobre el seed.",
    },
    {
        "id": "SP-M03",
        "archivo": "sp_ordenamiento_ejecucion_mock.sql",
        "rol": "Orquesta la demo mock (seed + validación).",
    },
]

# Casos por fase (reutiliza tablas seed)
CASOS = {
    "20011": {
        "id": "20011",
        "canal": "DIR",
        "fase": "0",
        "pregunta": "La hija unificada compite",
        "resultado": "No. Solo el padre tiene score y orden.",
        "tabla": {
            "headers": ["Rol", "RPU", "ind_unificacion", "Score", "orden"],
            "rows": [
                ["padre", "91018", "—", "639.7849", "1"],
                ["hija", "91019", "1", "—", "—"],
            ],
        },
    },
    "insumo": {
        "id": "Insumo",
        "canal": "Fase 1",
        "fase": "1",
        "pregunta": "Qué contactos entran a puntuar",
        "resultado": "Solo ganadoras + tipo XPM válido por canal.",
        "tabla": {
            "headers": ["Tipo XPM", "Canal", "Entra", "Condición"],
            "rows": [
                ["1,2,3,7,8", "DIR", "Sí", "RPU ganadora"],
                ["4,5,8", "TEL", "Sí", "Con DIR ganadora"],
                ["9", "CEL", "Sí", "Con DIR ganadora"],
                ["10", "EMA", "Sí", "Con @"],
            ],
        },
    },
    "20001": {
        "id": "20001",
        "canal": "DIR",
        "fase": "2",
        "pregunta": "Casa o oficina primero",
        "resultado": "Casa es el primer contacto; oficina el segundo.",
        "tabla": {
            "headers": ["Etiqueta", "RPU", "Score", "Lugar", "orden_prioridad"],
            "rows": [
                ["casa", "91001", "850.0000", "1", "1"],
                ["oficina", "91002", "700.0000", "2", "2"],
            ],
        },
    },
    "20010": {
        "id": "20010",
        "canal": "DIR",
        "fase": "2",
        "pregunta": "Empate de score",
        "resultado": "Mismo score 777; lugares 1 y 2 sin desempate nuevo.",
        "tabla": {
            "headers": ["Etiqueta", "RPU", "Score", "Lugar"],
            "rows": [
                ["empate_a", "91016", "777.0000", "1"],
                ["empate_b", "91017", "777.0000", "2"],
            ],
        },
    },
    "20004": {
        "id": "20004",
        "canal": "TEL",
        "fase": "2",
        "pregunta": "Qué fijo primero",
        "resultado": "Válido primero; no válido después.",
        "tabla": {
            "headers": ["Etiqueta", "Score", "Lugar"],
            "rows": [
                ["tel_valida", "420.0000", "1"],
                ["tel_novalida", "210.0000", "2"],
            ],
        },
    },
    "20013": {
        "id": "20013",
        "canal": "TEL",
        "fase": "2",
        "pregunta": "TEL020 mueve el ranking",
        "resultado": "No. Ambos quedan con el mismo score.",
        "tabla": {
            "headers": ["Etiqueta", "Score", "Lugar"],
            "rows": [
                ["tel_base", "376.5000", "1"],
                ["tel_solo_tel020", "376.5000", "2"],
            ],
        },
    },
    "20012": {
        "id": "20012",
        "canal": "CEL",
        "fase": "2",
        "pregunta": "Operador no mapeado",
        "resultado": "Aplica default 0.22 → score 220.",
        "tabla": {
            "headers": ["Etiqueta", "Prefijo", "Score", "Lugar"],
            "rows": [["cel_prefijo_999", "999", "220.0000", "1"]],
        },
    },
    "20014": {
        "id": "20014",
        "canal": "EMA",
        "fase": "2",
        "pregunta": "Variables excluidas",
        "resultado": "No mueven el score de email.",
        "tabla": {
            "headers": ["Etiqueta", "Score", "Lugar"],
            "rows": [
                ["ema_base", "281.7705", "1"],
                ["ema_solo_excluidas", "281.7705", "2"],
            ],
        },
    },
    "salida": {
        "id": "20001",
        "canal": "Salida",
        "fase": "3–4",
        "pregunta": "Orden de intento en calle",
        "resultado": "orden_prioridad = lugar DIR. Luego se limpia staging.",
        "tabla": {
            "headers": ["RPU", "Etiqueta", "Lugar", "orden_prioridad"],
            "rows": [
                ["91001", "casa", "1", "1"],
                ["91002", "oficina", "2", "2"],
            ],
        },
    },
}

FASES_UI = [
    {
        "fase": "0",
        "nombre": "Precondición",
        "pregunta": "Quién es dirección vigente",
        "hecho": "Unificación ya corrió; hijas (ind=1) fuera.",
        "casos_keys": ["20011"],
    },
    {
        "fase": "1",
        "nombre": "Armar candidatos",
        "pregunta": "Qué contactos entran hoy",
        "hecho": "Vistas + preparar_insumos · solo ganadoras + XPM.",
        "casos_keys": ["insumo"],
    },
    {
        "fase": "2",
        "nombre": "Scoring × 4 canales",
        "pregunta": "Cuál intento primero por canal",
        "hecho": "DIR / TEL / CEL / EMA · pesos RITM · lugar 1, 2, 3…",
        "casos_keys": ["20001", "20010", "20004", "20013", "20012", "20014"],
    },
    {
        "fase": "3–4",
        "nombre": "Guardar y limpiar",
        "pregunta": "Qué queda en el RPU",
        "hecho": "consolidacion → orden_prioridad · drop staging.",
        "casos_keys": ["salida"],
    },
]


def build_presentacion(data: dict) -> list:
    by_id = {s.get("id"): s for s in (data.get("sps_detalle") or [])}
    sps = []
    for m in MOCK_SPS:
        sp = by_id.get(m["id"]) or {}
        sps.append(
            {
                "id": m["id"],
                "archivo": sp.get("archivo") or m["archivo"],
                "rol": sp.get("objetivo") or sp.get("rol") or m["rol"],
            }
        )

    # Preferir nombres de fases_doc si existen
    doc = {str(f.get("fase")): f for f in (data.get("fases_doc") or [])}
    fases = []
    for f in FASES_UI:
        d = doc.get(f["fase"]) or {}
        casos = [CASOS[k] for k in f["casos_keys"] if k in CASOS]
        fases.append(
            {
                "fase": f["fase"],
                "nombre": d.get("nombre") or f["nombre"],
                "pregunta": d.get("requiere") or f["pregunta"],
                "hecho": d.get("implementado") or f["hecho"],
                "nota": d.get("nota") or "",
                "casos": casos,
            }
        )

    return [
        {
            "titulo": "Ordenamiento por fases",
            "lead": "La Demo sigue el mismo orden de corrida: Fase 0 → 1 → 2 → 3–4.",
            "bullets": [
                "Unificación ya dejó padre e hija.",
                "Cada fase responde una pregunta de negocio.",
                "Los casos abajo están agrupados por fase.",
            ],
        },
        {
            "titulo": "Mapa de fases",
            "lead": "Cuatro bloques. En Recorrido se profundiza el mismo orden.",
            "layout": "fase_mapa",
            "fases": [
                {
                    "fase": x["fase"],
                    "nombre": x["nombre"],
                    "pregunta": x["pregunta"],
                    "hecho": x["hecho"],
                }
                for x in fases
            ],
        },
        *[
            {
                "titulo": f"Fase {x['fase']} — {x['nombre']}",
                "lead": x["pregunta"],
                "bullets": [x["hecho"]] + ([x["nota"]] if x.get("nota") else []),
                "layout": "fase_casos",
                "fase": x["fase"],
                "casos": x["casos"],
            }
            for x in fases
        ],
        {
            "titulo": "Cierre · SPs mock y siguiente paso",
            "lead": "A la izquierda los SPs mock; a la derecha el puente a Recorrido.",
            "layout": "sps_final",
            "sps_mock": sps,
            "bullets": [
                "Recorrido = mismas fases: Fase 1 Insumos → Fase 2 canales → Fase 3–4 Salida.",
                "En cada bloque: tabla del caso + SP que lo hace.",
                "Evidencia Demo: CALL bdm_stage.sp_ordenamiento_ejecucion_mock.",
            ],
        },
    ]


RENDER_PRES = r"""function renderPresentacion() {
  const items = DATA.presentacion || [];
  const el = document.getElementById('presentacionWrap');
  if (!el) return;
  const tbl = (tabla) => {
    if (!tabla || !tabla.headers) return '';
    const head = tabla.headers.map(h => `<th>${esc(h)}</th>`).join('');
    const body = (tabla.rows || []).map(r =>
      `<tr>${r.map(c => `<td>${esc(String(c ?? ''))}</td>`).join('')}</tr>`
    ).join('');
    return `<div class="demo-tabla-wrap"><table class="demo-tabla"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
  };
  const casoCard = (c) => `<article class="demo-caso">
    <header>
      <span class="demo-id">${esc(c.id)}</span>
      <span class="demo-canal">${esc(c.canal)}</span>
      ${c.fase ? `<span class="demo-fase-pill">Fase ${esc(String(c.fase))}</span>` : ''}
    </header>
    <p class="demo-q">${esc(c.pregunta)}</p>
    ${tbl(c.tabla)}
    <p class="demo-r">${esc(c.resultado)}</p>
  </article>`;
  const spsCol = (list) => {
    if (!list || !list.length) return '';
    return `<aside class="demo-sps-col">
      <div class="demo-sps-title">SPs mock de la Demo</div>
      <ul class="demo-sps-list">${list.map(s => `
        <li>
          <header><code>${esc(s.id)}</code></header>
          <div class="demo-sps-file">${esc(s.archivo || '')}</div>
          <p>${esc(s.rol || s.objetivo || '')}</p>
        </li>`).join('')}</ul>
    </aside>`;
  };
  const mapa = (fases) => {
    if (!fases || !fases.length) return '';
    return `<div class="demo-fase-mapa">${fases.map((f, i) => `
      <article class="demo-fase-card">
        <div class="demo-fase-num">Fase ${esc(String(f.fase))}</div>
        <h5>${esc(f.nombre || '')}</h5>
        <p class="demo-fase-q">${esc(f.pregunta || '')}</p>
        <p class="demo-fase-h">${esc(f.hecho || '')}</p>
      </article>${i < fases.length - 1 ? '<div class="demo-fase-arrow" aria-hidden="true">→</div>' : ''}`).join('')}</div>`;
  };
  el.innerHTML = items.map(b => {
    const lead = b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : '';
    const bullets = (b.bullets && b.bullets.length)
      ? `<ul class="demo-chips">${b.bullets.map(x => `<li>${esc(x)}</li>`).join('')}</ul>`
      : '';
    const casos = (b.casos && b.casos.length)
      ? `<div class="demo-casos">${b.casos.map(casoCard).join('')}</div>`
      : '';
    let body = `${lead}${bullets}${casos}`;
    if (b.layout === 'fase_mapa') {
      body = `${lead}${mapa(b.fases)}`;
    } else if (b.layout === 'fase_casos') {
      body = `<div class="demo-fase-head"><span class="demo-fase-num">Fase ${esc(String(b.fase || ''))}</span>${lead}</div>${bullets}${casos}`;
    } else if (b.layout === 'sps_final') {
      body = `<div class="demo-final-grid">${spsCol(b.sps_mock)}<div class="demo-final-main">${lead}${bullets}</div></div>`;
    }
    return `<section class="demo-section${b.layout === 'fase_casos' ? ' demo-section-fase' : ''}">
      <h4>${esc(b.titulo)}</h4>
      ${body}
    </section>`;
  }).join('');
}"""

CSS_EXTRA = r"""
/* Fases Demo */
.demo-fase-mapa {
  display: flex; flex-wrap: wrap; gap: 0.45rem; align-items: stretch;
  margin-top: 0.35rem;
}
.demo-fase-card {
  flex: 1 1 140px;
  min-width: 140px;
  border: 1px solid #93c5fd;
  background: linear-gradient(180deg, #eff6ff 0%, #fff 50%);
  border-radius: 12px;
  padding: 0.65rem 0.7rem;
  box-shadow: 0 2px 8px rgba(29,111,220,.07);
}
.demo-fase-num {
  display: inline-block;
  font-size: 0.68rem; font-weight: 800;
  letter-spacing: 0.04em; text-transform: uppercase;
  color: #fff; background: #1d6fdc;
  padding: 0.16rem 0.5rem; border-radius: 999px;
  margin-bottom: 0.35rem;
}
.demo-fase-card h5 {
  margin: 0 0 0.3rem; font-size: 0.88rem; font-weight: 800; color: #0f172a;
}
.demo-fase-q {
  margin: 0 0 0.35rem; font-size: 0.78rem; font-weight: 650; color: #9a3412;
  background: #fff7ed; border: 1px solid #fed7aa; border-radius: 8px; padding: 0.35rem 0.45rem;
}
.demo-fase-h {
  margin: 0; font-size: 0.74rem; color: #334155; line-height: 1.35;
}
.demo-fase-arrow {
  display: flex; align-items: center; justify-content: center;
  font-size: 1.1rem; font-weight: 800; color: #1d6fdc; padding: 0 0.1rem;
}
.demo-fase-head {
  display: flex; flex-direction: column; gap: 0.35rem; margin-bottom: 0.35rem;
}
.demo-fase-pill {
  font-size: 0.65rem; font-weight: 800; letter-spacing: 0.04em;
  text-transform: uppercase; color: #1e3a8a; background: #dbeafe;
  border: 1px solid #bfdbfe; padding: 0.12rem 0.4rem; border-radius: 999px;
}
.demo-section-fase {
  border-left: 4px solid #1d6fdc;
}
@media (max-width: 820px) {
  .demo-fase-arrow { display: none; }
}
"""


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def esc_js(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#x27;")
    )


def patch_data(data: dict) -> None:
    data["presentacion"] = build_presentacion(data)
    data["generated"] = "2026-09-25"


def patch_ui(html: str) -> str:
    # WORKSHOP_STEPS labels con fases
    old_ws = """const WORKSHOP_STEPS = [
  { label: &#x27;Insumos&#x27;, el: &#x27;frame-fase1&#x27;, ruleIdx: 1 },
  { label: &#x27;DIR&#x27;, el: &#x27;frame-dir&#x27;, ruleIdx: 2 },
  { label: &#x27;TEL&#x27;, el: &#x27;frame-tel&#x27;, ruleIdx: 3 },
  { label: &#x27;CEL&#x27;, el: &#x27;frame-cel&#x27;, ruleIdx: 4 },
  { label: &#x27;EMA&#x27;, el: &#x27;frame-ema&#x27;, ruleIdx: 5 },
  { label: &#x27;Salida&#x27;, el: &#x27;frame-salida&#x27;, ruleIdx: 6 },
];"""
    new_ws = """const WORKSHOP_STEPS = [
  { label: &#x27;Fase 1 · Insumos&#x27;, el: &#x27;frame-fase1&#x27;, ruleIdx: 1 },
  { label: &#x27;Fase 2 · DIR&#x27;, el: &#x27;frame-dir&#x27;, ruleIdx: 2 },
  { label: &#x27;Fase 2 · TEL&#x27;, el: &#x27;frame-tel&#x27;, ruleIdx: 3 },
  { label: &#x27;Fase 2 · CEL&#x27;, el: &#x27;frame-cel&#x27;, ruleIdx: 4 },
  { label: &#x27;Fase 2 · EMA&#x27;, el: &#x27;frame-ema&#x27;, ruleIdx: 5 },
  { label: &#x27;Fase 3–4 · Salida&#x27;, el: &#x27;frame-salida&#x27;, ruleIdx: 6 },
];"""
    if old_ws in html:
        html = html.replace(old_ws, new_ws, 1)
        print("  WORKSHOP_STEPS fases ok")
    elif "Fase 1 · Insumos" in html:
        print("  WORKSHOP_STEPS already")
    else:
        print("  WARN WORKSHOP_STEPS")

    old_rf = """const RULE_FRAMES = [
  null,
  { regla: &#x27;FASE 1&#x27;, nav: &#x27;nav-fase1&#x27;, stage: &#x27;stage-fase1&#x27; },
  { regla: &#x27;CANAL DIR&#x27;, nav: &#x27;nav-dir&#x27;, stage: &#x27;stage-dir&#x27; },
  { regla: &#x27;CANAL TEL&#x27;, nav: &#x27;nav-tel&#x27;, stage: &#x27;stage-tel&#x27; },
  { regla: &#x27;CANAL CEL&#x27;, nav: &#x27;nav-cel&#x27;, stage: &#x27;stage-cel&#x27; },
  { regla: &#x27;CANAL EMA&#x27;, nav: &#x27;nav-ema&#x27;, stage: &#x27;stage-ema&#x27; },
  { regla: &#x27;CONSOLIDACIÓN&#x27;, nav: &#x27;nav-salida&#x27;, stage: &#x27;stage-salida&#x27; },
];"""
    new_rf = """const RULE_FRAMES = [
  null,
  { regla: &#x27;FASE 1 · Insumos&#x27;, nav: &#x27;nav-fase1&#x27;, stage: &#x27;stage-fase1&#x27; },
  { regla: &#x27;FASE 2 · DIR&#x27;, nav: &#x27;nav-dir&#x27;, stage: &#x27;stage-dir&#x27; },
  { regla: &#x27;FASE 2 · TEL&#x27;, nav: &#x27;nav-tel&#x27;, stage: &#x27;stage-tel&#x27; },
  { regla: &#x27;FASE 2 · CEL&#x27;, nav: &#x27;nav-cel&#x27;, stage: &#x27;stage-cel&#x27; },
  { regla: &#x27;FASE 2 · EMA&#x27;, nav: &#x27;nav-ema&#x27;, stage: &#x27;stage-ema&#x27; },
  { regla: &#x27;FASE 3–4 · Salida&#x27;, nav: &#x27;nav-salida&#x27;, stage: &#x27;stage-salida&#x27; },
];"""
    # only last RULE_FRAMES (ord)
    if old_rf in html:
        # replace last occurrence
        idx = html.rfind(old_rf)
        html = html[:idx] + new_rf + html[idx + len(old_rf) :]
        print("  RULE_FRAMES fases ok")
    elif "FASE 2 · DIR" in html:
        print("  RULE_FRAMES already")
    else:
        print("  WARN RULE_FRAMES")

    # Landing recorrido
    html = html.replace(
        "Recorrido — caso, SP y evidencia en un solo paso",
        "Recorrido — por fases (1 Insumos · 2 canales · 3–4 Salida)",
        1,
    )
    html = html.replace(
        "Vista funcional: reglas y casos en cuadros con tablas.",
        "Vista por fases: mapa Fase 0→1→2→3–4, casos y SPs mock.",
        1,
    )

    # renderPresentacion
    pat = re.compile(r"function renderPresentacion\(\) \{\n.*?\n\}", re.S)
    ms = list(pat.finditer(html))
    if ms:
        m = ms[-1]
        html = html[: m.start()] + esc_js(RENDER_PRES) + html[m.end() :]
        print("  renderPresentacion ok")
    else:
        print("  WARN renderPresentacion")

    # CSS in iframe
    if '"' in CSS_EXTRA:
        raise SystemExit("CSS has double quotes")
    oi = html.find("Mapa Ordenamiento")
    style_end = html.find("&lt;/style&gt;", oi) if oi >= 0 else -1
    marker = "/* Fases Demo */"
    if style_end > 0:
        if marker in html[oi:style_end]:
            prev = html.rfind(marker, oi, style_end)
            html = html[:prev] + html[style_end:]
            style_end = html.find("&lt;/style&gt;", oi)
        html = html[:style_end] + CSS_EXTRA + html[style_end:]
        print("  CSS fases ok")
    else:
        print("  WARN CSS")
    return html


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    assert len(positions) >= 2
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    patch_data(data)
    html = html[:start] + to_html_json(data) + html[end:]
    html = patch_ui(html)
    bak = path.with_suffix(path.suffix + ".bak_fases")
    if not bak.exists():
        shutil.copy2(path, bak)
    path.write_text(html, encoding="utf-8")
    a = html.find('iframe title="Mapa Ordenamiento"')
    sd = html.find('srcdoc="', a)
    end_i = html.find('"></iframe>', sd)
    chunk = html[sd:end_i]
    print(
        "OK",
        path.name,
        "quotes",
        chunk.count('"'),
        "fase_mapa",
        "fase_mapa" in chunk,
        "Fase 1 · Insumos",
        "Fase 1 · Insumos" in chunk,
    )


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
