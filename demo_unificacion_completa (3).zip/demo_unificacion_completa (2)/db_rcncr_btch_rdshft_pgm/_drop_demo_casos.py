# -*- coding: utf-8 -*-
"""Quita de Demo los casos 20014 EMA y 20001 Salida."""
from __future__ import annotations

import json
import re
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]

DROP = {
    ("20014", "EMA"),
    ("20001", "Salida"),
    ("20001", "SALIDA"),
}


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def should_drop(c: dict) -> bool:
    cid = str(c.get("id") or "")
    canal = str(c.get("canal") or "")
    if (cid, canal) in DROP:
        return True
    # también por pregunta típica
    q = (c.get("pregunta") or "").lower()
    if "variables excluidas" in q:
        return True
    if "orden de intento en calle" in q:
        return True
    return False


def patch_data(data: dict) -> None:
    pres = data.get("presentacion") or []
    kept = []
    removed = 0
    for b in pres:
        casos = b.get("casos")
        if isinstance(casos, list):
            before = len(casos)
            b["casos"] = [c for c in casos if not should_drop(c)]
            removed += before - len(b["casos"])
            # si quedó sección de fase vacía de casos y es fase 3-4, quitar bloque entero
            if b.get("layout") == "fase_casos" and not b["casos"]:
                removed += 1
                continue
        # mapa de fases: quitar tarjeta 3-4 si ya no hay casos de salida
        if b.get("layout") == "fase_mapa" and isinstance(b.get("fases"), list):
            # mantener mapa completo (sigue siendo el flujo); no tocar
            pass
        kept.append(b)
    data["presentacion"] = kept
    print(f"  removed items ~{removed}, blocks left {len(kept)}")


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    assert len(positions) >= 2
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    patch_data(data)
    html = html[:start] + to_html_json(data) + html[end:]
    path.write_text(html, encoding="utf-8")
    print("OK", path.name)


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
