# -*- coding: utf-8 -*-
"""HTML ordenamiento: ejemplos oficiales = personas MOCK 20001-20014."""
import json
import re
import shutil
from html import unescape
from pathlib import Path

PATHS = [
    Path(r"C:\Users\C32525E\Downloads\RECONOCER_TODO_EN_UNO_WORKSHOP.html"),
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
]


def extract(html, start):
    j, depth, in_q = start, 0, False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        if not in_q:
            if html[j] == "{":
                depth += 1
            elif html[j] == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def dump(obj):
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":")).replace('"', "&quot;")


def set_mock(row, pid, label, query, table=None):
    row["_fuente"] = "MOCK"
    row["_id_buro_persona"] = pid
    row["_id_ejemplo"] = f"MOCK id_buro_persona = {pid}"
    row["_ejemplo_label"] = label
    row["Query validación (copiar en dba_rncr_batch)"] = query.strip() + "\n"
    row["_show_query"] = True
    if table:
        row["_tabla_ejemplo"] = table


def patch(data):
    for row in data.get("rows") or []:
        code = row.get("Escenario") or ""

        if code == "ORD-DIR-RANK":
            set_mock(
                row,
                20001,
                "MOCK seed · RANK-01 (HTML oficial) · CA-O04",
                """-- MOCK · HTML RANK-01 · persona 20001
-- Requiere seed: docs/sql_qa_ordenamiento_mock/02_seed_escenarios_mock.sql
SELECT r.etiqueta, s.cod_dw_persona_ubic AS rpu, s.score, s.lugar, p.orden_prioridad
FROM bdm_stage.mock_ord_score s
JOIN bdm_stage.mock_ord_rpu r ON r.cod_dw_persona_ubic = s.cod_dw_persona_ubic
LEFT JOIN bdm_stage.mock_ord_prioridad p ON p.cod_dw_persona_ubic = s.cod_dw_persona_ubic
WHERE s.id_buro_persona = 20001 AND s.canal = 'DIR'
ORDER BY s.lugar;
-- Esperado: casa 91001 score 850 lugar 1 · oficina 91002 score 700 lugar 2""",
                {
                    "title": "MOCK · RANK-01 · id_buro = 20001 (seed QA)",
                    "headers": ["Etiqueta", "RPU", "Score DIR", "lugar", "orden_prioridad"],
                    "rows": [
                        ["casa", "91001", "850.0000", "1", "1"],
                        ["oficina", "91002", "700.0000", "2", "2"],
                    ],
                },
            )
            row["_busca"] = (
                "Mayor score → lugar 1 → orden_prioridad. "
                "Ejemplo HTML = MOCK persona 20001 (suite sql_qa_ordenamiento_mock)."
            )
            row["_dev"] = "MOCK seed: 20001 casa=850 lugar1 · oficina=700 lugar2 (CA-O04)."
            row["_conclusion_regla"] = row["_dev"]

        elif code == "ORD-F3-HIJA":
            set_mock(
                row,
                20011,
                "MOCK seed · F3-02 padre/hija · CA-O05/CA-O03",
                """-- MOCK · HTML F3-02 · persona 20011
SELECT 'scores_hija' AS chk, COUNT(*)::BIGINT AS n
FROM bdm_stage.mock_ord_score WHERE cod_dw_persona_ubic = 91019
UNION ALL
SELECT 'orden_hija', COUNT(*)::BIGINT
FROM bdm_stage.mock_ord_prioridad WHERE cod_dw_persona_ubic = 91019;
-- Esperado: 0 y 0
SELECT canal, score, lugar FROM bdm_stage.mock_ord_score
WHERE id_buro_persona = 20011 ORDER BY canal;
-- Esperado: solo padre 91018""",
                {
                    "title": "MOCK · F3-02 · id_buro = 20011",
                    "headers": ["Campo", "Hija 91019", "Padre 91018", "Fuente"],
                    "rows": [
                        ["ind_unificacion", "1", "NULL", "MOCK seed"],
                        ["score DIR", "— (0 filas)", "639.7849", "MOCK seed"],
                        ["orden_prioridad", "NULL", "1", "MOCK seed"],
                    ],
                },
            )

        elif code == "ORD-DIR-EMP":
            set_mock(
                row,
                20010,
                "MOCK seed · RANK-02 empate · CA-O08",
                """-- MOCK · HTML empate · persona 20010
SELECT etiqueta, rpu, score, lugar FROM (
  SELECT r.etiqueta, s.cod_dw_persona_ubic AS rpu, s.score, s.lugar
  FROM bdm_stage.mock_ord_score s
  JOIN bdm_stage.mock_ord_rpu r ON r.cod_dw_persona_ubic = s.cod_dw_persona_ubic
  WHERE s.id_buro_persona = 20010 AND s.canal = 'DIR'
) q ORDER BY lugar;
-- Esperado: 2 filas · mismo score 777.0000""",
                {
                    "title": "MOCK · RANK-02 empate · id_buro = 20010",
                    "headers": ["Etiqueta", "RPU", "Score", "lugar", "Fuente"],
                    "rows": [
                        ["empate_a", "91016", "777.0000", "1", "MOCK seed"],
                        ["empate_b", "91017", "777.0000", "2", "MOCK seed"],
                    ],
                },
            )

        elif code == "ORD-TEL-RANK":
            set_mock(
                row,
                20004,
                "MOCK seed · TEL ranking · CA-O06",
                """-- MOCK · HTML TEL · persona 20004
SELECT r.etiqueta, s.score, s.lugar
FROM bdm_stage.mock_ord_score s
JOIN bdm_stage.mock_ord_rpu r ON r.cod_dw_persona_ubic = s.cod_dw_persona_ubic
WHERE s.id_buro_persona = 20004 AND s.canal = 'TEL'
ORDER BY s.lugar;""",
                {
                    "title": "MOCK · TEL · id_buro = 20004",
                    "headers": ["Contacto", "Score TEL", "lugar", "Fuente"],
                    "rows": [
                        ["VALIDA", "420.0000", "1", "MOCK"],
                        ["NO VALIDA", "210.0000", "2", "MOCK"],
                    ],
                },
            )

        elif code == "ORD-TEL-02":
            set_mock(
                row,
                20013,
                "MOCK seed · TEL-02 aislamiento · CA-O09",
                """-- MOCK · HTML TEL-02 · persona 20013
SELECT r.etiqueta, s.score, s.lugar
FROM bdm_stage.mock_ord_score s
JOIN bdm_stage.mock_ord_rpu r ON r.cod_dw_persona_ubic = s.cod_dw_persona_ubic
WHERE s.id_buro_persona = 20013 AND s.canal = 'TEL'
ORDER BY s.lugar;
-- Esperado: ambos score 376.5000 (TEL020 no mueve)""",
                {
                    "title": "MOCK · TEL-02 · id_buro = 20013",
                    "headers": ["Contacto", "Score", "¿TEL020 cambia score?", "Fuente"],
                    "rows": [
                        ["tel_base", "376.5000", "No", "MOCK"],
                        ["tel_solo_tel020", "376.5000", "No — mismo score", "MOCK"],
                    ],
                },
            )

        elif code == "ORD-CEL-02":
            set_mock(
                row,
                20012,
                "MOCK seed · CEL-02 default · CA-O11",
                """-- MOCK · HTML CEL-02 · persona 20012
SELECT score, lugar, nota FROM bdm_stage.mock_ord_score
WHERE id_buro_persona = 20012 AND canal = 'CEL';
-- Esperado: score 220.0000 (default 0.22)""",
                {
                    "title": "MOCK · CEL-02 · id_buro = 20012",
                    "headers": ["Prefijo", "Score CEL", "Regla", "Fuente"],
                    "rows": [["999", "220.0000", "default 0.22", "MOCK seed"]],
                },
            )

        elif code == "ORD-EMA-03":
            set_mock(
                row,
                20014,
                "MOCK seed · EMA-03 · CA-O10",
                """-- MOCK · HTML EMA-03 · persona 20014
SELECT r.etiqueta, s.score, s.lugar
FROM bdm_stage.mock_ord_score s
JOIN bdm_stage.mock_ord_rpu r ON r.cod_dw_persona_ubic = s.cod_dw_persona_ubic
WHERE s.id_buro_persona = 20014 AND s.canal = 'EMA'
ORDER BY s.lugar;
-- Esperado: ambos 281.7705""",
                {
                    "title": "MOCK · EMA-03 · id_buro = 20014",
                    "headers": ["Contacto", "Score EMA", "¿003/007 mueven?", "Fuente"],
                    "rows": [
                        ["ema_base", "281.7705", "No", "MOCK"],
                        ["ema_solo_excluidas", "281.7705", "No — mismo score", "MOCK"],
                    ],
                },
            )

        elif code == "ORD-SALIDA":
            set_mock(
                row,
                20001,
                "MOCK seed · orden_prioridad · CA-O07",
                """-- MOCK · HTML salida · persona 20001
SELECT p.cod_dw_persona_ubic AS rpu, p.orden_prioridad, s.score, s.lugar
FROM bdm_stage.mock_ord_prioridad p
JOIN bdm_stage.mock_ord_score s
  ON s.cod_dw_persona_ubic = p.cod_dw_persona_ubic AND s.canal = 'DIR'
WHERE p.id_buro_persona = 20001
ORDER BY p.orden_prioridad;""",
                {
                    "title": "MOCK · salida · id_buro = 20001",
                    "headers": ["RPU", "Score DIR", "lugar", "orden_prioridad"],
                    "rows": [
                        ["91001", "850.0000", "1", "1"],
                        ["91002", "700.0000", "2", "2"],
                    ],
                },
            )

        elif code == "ORD-RESUMEN":
            set_mock(
                row,
                20001,
                "MOCK seed · referencia HTML (suite 20001–20014)",
                """-- MOCK · catálogo de escenarios del HTML
SELECT id_buro_persona, cod_escenario, criterio_ca, descripcion
FROM bdm_stage.mock_ord_escenario
ORDER BY id_buro_persona, cod_escenario;""",
            )
            if isinstance(row.get("_tabla_ejemplo"), dict):
                row["_tabla_ejemplo"] = {
                    "title": "MOCK · personas del HTML (seed QA)",
                    "headers": ["id_buro", "Escenario", "Criterio", "Qué prueba"],
                    "rows": [
                        ["20001", "RANK-01", "CA-O04", "2 DIR scores distintos"],
                        ["20010", "RANK-02", "CA-O08", "Empate"],
                        ["20011", "F3-02", "CA-O05", "Hija sin score"],
                        ["20013/14/12", "TEL/EMA/CEL", "CA-O09/10/11", "Fórmulas"],
                    ],
                }

    k = data.setdefault("kpis", {})
    k["demo_modo_html"] = "MOCK"
    k["demo_id_buro_persona"] = 20001
    k["mock_suite"] = "sql_qa_ordenamiento_mock"
    k["mock_personas"] = "20001-20014"


def main():
    for path in PATHS:
        if not path.exists():
            print("SKIP", path)
            continue
        bak = path.with_suffix(path.suffix + ".bak_mock_html")
        if not bak.exists():
            shutil.copy2(path, bak)
        html = path.read_text(encoding="utf-8")
        positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
        start = positions[1]
        while start < len(html) and html[start] in " \t\n\r":
            start += 1
        data, s0, s1 = extract(html, start)
        patch(data)
        html = html[:s0] + dump(data) + html[s1:]
        # banner note
        html = html.replace(
            "Workshop · REAL = IDs DEV · MOCK = smoke (si no hay caso)",
            "Workshop · ejemplos HTML = MOCK 20001–20014 · gates volumen = REAL DEV",
        )
        path.write_text(html, encoding="utf-8")
        print("OK", path.name)


if __name__ == "__main__":
    main()
