# -*- coding: utf-8 -*-
import json, re, sys
from html import unescape
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
p = Path(
    r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
    r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
)
t = unescape(p.read_text(encoding="utf-8"))


def extract_obj(s, start):
    depth = 0
    in_q = False
    esc = False
    j = start
    while j < len(s):
        ch = s[j]
        if in_q:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_q = False
        else:
            if ch == '"':
                in_q = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return json.loads(s[start : j + 1])
        j += 1


d = extract_obj(t, list(re.finditer(r"const DATA = (\{)", t))[1].start(1))
print("=== CONSOLIDACIÓN / salida rows ===")
for r in d.get("rows") or []:
    if r.get("_regla") in ("CONSOLIDACIÓN", "FASE 3", "FASE 4") or "CONSOL" in str(
        r.get("_pack_code")
    ):
        print(
            "pack",
            r.get("_pack_code"),
            "regla",
            r.get("_regla"),
            "titulo",
            (r.get("_titulo_corto") or r.get("Subescenario") or "")[:60],
        )
        print("  keys sample", [k for k in r.keys() if k.startswith("_")][:20])

print("\n=== sps related to consolidacion/drop ===")
for s in d.get("sps_detalle") or []:
    fase = str(s.get("fase") or s.get("grupo") or "")
    arch = str(s.get("archivo") or "")
    if any(x in arch.lower() or x in fase.lower() for x in ("consol", "drop", "fase 3", "fase 4", "limpi")):
        print(s.get("id"), fase, arch, (s.get("objetivo") or "")[:50])

print("\n=== frame-salida in html ===")
m = re.search(r'id="frame-salida".{0,800}', t)
print(m.group(0)[:500] if m else "none")
print("WORKSHOP_STEPS", re.findall(r"label: '([^']+)'", t.split("const WORKSHOP_STEPS")[-1][:800]))
