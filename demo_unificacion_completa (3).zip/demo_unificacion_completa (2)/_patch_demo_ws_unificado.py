# -*- coding: utf-8 -*-
"""
Demo visual con cuadros/tablas.
Workshop + SPs unidos en un solo paso (Recorrido).
"""
from __future__ import annotations

import json
import re
import shutil
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
]

PRESENTACION = [
    {
        "titulo": "Qué resuelve",
        "lead": "Ordenar con qué contacto empezar cuando una persona tiene varios datos vigentes.",
        "bullets": [
            "Unificación ya definió padre e hija.",
            "Ordenamiento decide el orden de intento por canal.",
            "DIR, TEL, CEL y EMA se ordenan por separado.",
        ],
    },
    {
        "titulo": "Reglas de negocio",
        "lead": "Lo que fija el resultado del ranking.",
        "bullets": [
            "Solo ganadoras: la hija unificada no compite.",
            "TEL, CEL y EMA requieren al menos una DIR ganadora.",
            "Mayor score del canal → lugar 1 (pesos del catálogo RITM).",
        ],
    },
    {
        "titulo": "Flujo funcional",
        "lead": "De la elegibilidad al orden de contacto.",
        "bullets": [
            "Entran solo contactos elegibles y válidos.",
            "Cada canal genera su ranking (lugar 1, 2, 3…).",
            "En calle, ese lugar queda como orden de prioridad de intento.",
        ],
    },
    {
        "titulo": "Casos de la Demo",
        "lead": "Cada cuadro es un caso: pregunta, tabla del resultado y lectura.",
        "casos": [
            {
                "id": "20001",
                "canal": "DIR",
                "pregunta": "Casa o oficina primero",
                "resultado": "Casa es el primer contacto; oficina el segundo.",
                "tabla": {
                    "headers": ["Etiqueta", "RPU", "Score", "Lugar", "orden_prioridad"],
                    "rows": [
                        ["casa", "91001", "850.0000", "1", "1"],
                        ["oficina", "91002", "700.0000", "2", "2"],
                    ],
                },
            },
            {
                "id": "20011",
                "canal": "DIR",
                "pregunta": "La hija unificada compite",
                "resultado": "No. Solo el padre tiene score y orden.",
                "tabla": {
                    "headers": ["Rol", "RPU", "ind_unificacion", "Score", "orden"],
                    "rows": [
                        ["padre", "91018", "—", "639.7849", "1"],
                        ["hija", "91019", "1", "—", "—"],
                    ],
                },
            },
            {
                "id": "20010",
                "canal": "DIR",
                "pregunta": "Empate de score",
                "resultado": "Mismo score 777; lugares 1 y 2 sin desempate de negocio nuevo.",
                "tabla": {
                    "headers": ["Etiqueta", "RPU", "Score", "Lugar"],
                    "rows": [
                        ["empate_a", "91016", "777.0000", "1"],
                        ["empate_b", "91017", "777.0000", "2"],
                    ],
                },
            },
            {
                "id": "20004",
                "canal": "TEL",
                "pregunta": "Qué fijo primero",
                "resultado": "Válido primero; no válido después.",
                "tabla": {
                    "headers": ["Etiqueta", "Score", "Lugar"],
                    "rows": [
                        ["tel_valida", "420.0000", "1"],
                        ["tel_novalida", "210.0000", "2"],
                    ],
                },
            },
            {
                "id": "20013",
                "canal": "TEL",
                "pregunta": "TEL020 mueve el ranking",
                "resultado": "No. Ambos quedan con el mismo score.",
                "tabla": {
                    "headers": ["Etiqueta", "Score", "Lugar"],
                    "rows": [
                        ["tel_base", "376.5000", "1"],
                        ["tel_solo_tel020", "376.5000", "2"],
                    ],
                },
            },
            {
                "id": "20012",
                "canal": "CEL",
                "pregunta": "Operador no mapeado",
                "resultado": "Aplica default 0.22 → score 220.",
                "tabla": {
                    "headers": ["Etiqueta", "Prefijo", "Score", "Lugar"],
                    "rows": [["cel_prefijo_999", "999", "220.0000", "1"]],
                },
            },
            {
                "id": "20014",
                "canal": "EMA",
                "pregunta": "Variables excluidas",
                "resultado": "No mueven el score de email.",
                "tabla": {
                    "headers": ["Etiqueta", "Score", "Lugar"],
                    "rows": [
                        ["ema_base", "281.7705", "1"],
                        ["ema_solo_excluidas", "281.7705", "2"],
                    ],
                },
            },
            {
                "id": "20001",
                "canal": "Salida",
                "pregunta": "Orden de intento en calle",
                "resultado": "orden_prioridad = lugar DIR.",
                "tabla": {
                    "headers": ["RPU", "Etiqueta", "Lugar", "orden_prioridad"],
                    "rows": [
                        ["91001", "casa", "1", "1"],
                        ["91002", "oficina", "2", "2"],
                    ],
                },
            },
        ],
    },
    {
        "titulo": "Siguiente paso",
        "lead": "En Recorrido está el detalle unido: caso + SP + consulta de evidencia.",
        "bullets": [
            "Un solo paso: Insumos → DIR → TEL → CEL → EMA → Salida.",
            "En cada bloque: qué abrimos, qué vemos, tabla y SP que lo hace.",
        ],
    },
]

# Map workshop pack → SP ids to show inline
PACK_SPS = {
    "INSUMO-CT": ["SP-02", "SP-04", "SP-M03"],
    "RPU-STG": ["SP-03", "SP-04", "SP-M01"],
    "BETAS": ["SP-12", "SP-01"],
    "DIR-RANK": ["SP-05", "SP-M03"],
    "ELEG-HIJA": ["SP-03", "SP-05"],
    "ELEG-BLOQ": ["SP-06"],
    "DIR-EMPATE": ["SP-05"],
    "TEL-RANK": ["SP-06"],
    "TEL-02": ["SP-06"],
    "CEL-02": ["SP-07"],
    "EMA-03": ["SP-08"],
    "CONSOL": ["SP-09", "SP-11"],
}

# Example tables for workshop rows (same seed)
PACK_TABLA = {
    "DIR-RANK": {
        "headers": ["Etiqueta", "RPU", "Score", "Lugar", "orden_prioridad"],
        "rows": [
            ["casa", "91001", "850.0000", "1", "1"],
            ["oficina", "91002", "700.0000", "2", "2"],
        ],
    },
    "ELEG-HIJA": {
        "headers": ["Rol", "RPU", "ind_unif", "Score", "orden"],
        "rows": [
            ["padre", "91018", "—", "639.7849", "1"],
            ["hija", "91019", "1", "—", "—"],
        ],
    },
    "DIR-EMPATE": {
        "headers": ["Etiqueta", "RPU", "Score", "Lugar"],
        "rows": [
            ["empate_a", "91016", "777.0000", "1"],
            ["empate_b", "91017", "777.0000", "2"],
        ],
    },
    "TEL-RANK": {
        "headers": ["Etiqueta", "Score", "Lugar"],
        "rows": [
            ["tel_valida", "420.0000", "1"],
            ["tel_novalida", "210.0000", "2"],
        ],
    },
    "TEL-02": {
        "headers": ["Etiqueta", "Score", "Lugar"],
        "rows": [
            ["tel_base", "376.5000", "1"],
            ["tel_solo_tel020", "376.5000", "2"],
        ],
    },
    "CEL-02": {
        "headers": ["Etiqueta", "Prefijo", "Score", "Lugar"],
        "rows": [["cel_prefijo_999", "999", "220.0000", "1"]],
    },
    "EMA-03": {
        "headers": ["Etiqueta", "Score", "Lugar"],
        "rows": [
            ["ema_base", "281.7705", "1"],
            ["ema_solo_excluidas", "281.7705", "2"],
        ],
    },
    "CONSOL": {
        "headers": ["RPU", "Etiqueta", "Lugar DIR", "orden_prioridad"],
        "rows": [
            ["91001", "casa", "1", "1"],
            ["91002", "oficina", "2", "2"],
        ],
    },
    "INSUMO-CT": {
        "headers": ["Tipo XPM", "Canal", "¿Entra?", "Condición"],
        "rows": [
            ["1,2,3,7,8", "DIR", "Sí", "RPU ganadora"],
            ["4,5,8", "TEL", "Sí", "Con DIR ganadora"],
            ["9", "CEL", "Sí", "Con DIR ganadora"],
            ["10", "EMA", "Sí", "Con @"],
        ],
    },
    "RPU-STG": {
        "headers": ["Rol", "RPU", "ind_unif", "Score", "orden"],
        "rows": [
            ["padre", "91018", "—", "639.7849", "1"],
            ["hija", "91019", "1", "—", "—"],
        ],
    },
    "BETAS": {
        "headers": ["Quién", "Qué hace", "Estado"],
        "rows": [
            ["Catálogo RITM", "Define 47 pesos", "Cargado"],
            ["Scoring", "Aplica betas en la suma", "OK"],
        ],
    },
    "ELEG-BLOQ": {
        "headers": ["Etiqueta", "Score", "Lugar"],
        "rows": [
            ["tel_valida", "420.0000", "1"],
            ["tel_novalida", "210.0000", "2"],
        ],
    },
}


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def esc_js(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#x27;")
    )


RENDER_PRES = r"""function renderPresentacion() {
  const items = DATA.presentacion || [];
  const el = document.getElementById('presentacionWrap');
  if (!el) return;
  const tbl = (tabla) => {
    if (!tabla || !tabla.headers) return '';
    const head = tabla.headers.map(h => `<th>${esc(h)}</th>`).join('');
    const body = (tabla.rows || []).map(r =>
      `<tr>${r.map(c => `<td>${esc(String(c ?? ''))}</td>`).join('')}</tr>`
    ).join('');
    return `<div class="demo-tabla-wrap"><table class="demo-tabla"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
  };
  el.innerHTML = items.map(b => {
    const lead = b.lead ? `<p class="demo-lead">${esc(b.lead)}</p>` : '';
    const bullets = (b.bullets && b.bullets.length)
      ? `<ul class="demo-chips">${b.bullets.map(x => `<li>${esc(x)}</li>`).join('')}</ul>`
      : '';
    const casos = (b.casos && b.casos.length)
      ? `<div class="demo-casos">${b.casos.map(c => `
          <article class="demo-caso">
            <header>
              <span class="demo-id">${esc(c.id)}</span>
              <span class="demo-canal">${esc(c.canal)}</span>
            </header>
            <p class="demo-q">${esc(c.pregunta)}</p>
            ${tbl(c.tabla)}
            <p class="demo-r">${esc(c.resultado)}</p>
          </article>`).join('')}</div>`
      : '';
    return `<section class="demo-section">
      <h4>${esc(b.titulo)}</h4>
      ${lead}${bullets}${casos}
    </section>`;
  }).join('');
}"""


def patch_data(data: dict) -> None:
    data["presentacion"] = PRESENTACION
    data["generated"] = "2026-09-25"
    sps_by = {s.get("id"): s for s in (data.get("sps_detalle") or [])}
    for row in data.get("rows") or []:
        code = row.get("_pack_code")
        if code in PACK_TABLA:
            row["_tabla_ejemplo"] = {
                "title": f"Tabla del caso · {code}",
                **PACK_TABLA[code],
            }
        ids = PACK_SPS.get(code) or []
        linked = []
        for sid in ids:
            sp = sps_by.get(sid)
            if not sp:
                continue
            linked.append(
                {
                    "id": sid,
                    "archivo": sp.get("archivo"),
                    "objetivo": sp.get("objetivo") or sp.get("pregunta") or sp.get("rol"),
                    "accion": sp.get("accion") or sp.get("logica"),
                    "resultado": sp.get("resultado") or sp.get("ejemplo"),
                    "por_que": sp.get("por_que") or "",
                }
            )
        if linked:
            row["_sps_relacionados"] = linked
        # Soft titles without ugly ¿?
        titles = {
            "INSUMO-CT": "Insumo — tipo de contacto al canal",
            "RPU-STG": "Insumo — solo ganadoras",
            "BETAS": "Insumo — catálogo de pesos (betas)",
            "DIR-RANK": "DIR — ranking de direcciones",
            "ELEG-HIJA": "DIR — hija excluida",
            "ELEG-BLOQ": "DIR — dato no válido",
            "DIR-EMPATE": "DIR — empate de score",
            "TEL-RANK": "TEL — ranking de fijo",
            "TEL-02": "TEL — TEL020 fuera de suma",
            "CEL-02": "CEL — operador por defecto",
            "EMA-03": "EMA — variables fuera de suma",
            "CONSOL": "Salida — orden_prioridad",
        }
        if code in titles:
            row["_titulo_corto"] = titles[code]
            row["Subescenario"] = titles[code]


def patch_ui(html: str) -> str:
    # 2 tabs only
    old_f = """const FRAMES = [
  { id: &#x27;demo&#x27;, label: &#x27;Demo&#x27;, el: &#x27;frame-home&#x27;, progress: 0 },
  { id: &#x27;workshop&#x27;, label: &#x27;Workshop&#x27;, el: &#x27;frame-workshop&#x27;, progress: 50 },
  { id: &#x27;sps&#x27;, label: &#x27;SPs&#x27;, el: &#x27;frame-sps&#x27;, progress: 100 },
];"""
    new_f = """const FRAMES = [
  { id: &#x27;demo&#x27;, label: &#x27;Demo&#x27;, el: &#x27;frame-home&#x27;, progress: 0 },
  { id: &#x27;recorrido&#x27;, label: &#x27;Recorrido&#x27;, el: &#x27;frame-workshop&#x27;, progress: 55 },
];"""
    if old_f in html:
        html = html.replace(old_f, new_f, 1)
        print("  FRAMES 2 tabs")
    else:
        print("  WARN FRAMES")

    # showFrame: remove sps branch; workshop id may be recorrido
    html = html.replace(
        "if (f.id === &#x27;sps&#x27;) showSpDetail(spPos, false);",
        "// SPs integrados en Recorrido",
    )
    html = html.replace(
        "FRAMES[i] &amp;&amp; FRAMES[i].id===&#x27;workshop&#x27;",
        "FRAMES[i] &amp;&amp; (FRAMES[i].id===&#x27;recorrido&#x27; || FRAMES[i].id===&#x27;workshop&#x27;)",
    )
    html = html.replace(
        "f.id === &#x27;workshop&#x27;",
        "(f.id === &#x27;recorrido&#x27; || f.id === &#x27;workshop&#x27;)",
    )

    # Landing text
    html = html.replace(
        "Workshop — evidencia por canal",
        "Recorrido — caso, SP y evidencia en un solo paso",
        1,
    )
    html = html.replace(
        "Primero abrimos cada bloque; aquí vemos el caso y la evidencia; con eso ya nos aseguramos del resultado.",
        "Primero abrimos el bloque; aquí vemos la tabla del caso y el SP que lo hace; con eso ya nos aseguramos del resultado.",
        1,
    )
    html = html.replace("Recorrido del Workshop", "Cómo va el Recorrido", 1)
    html = html.replace(
        "En Recorrido está el detalle unido: caso + SP + consulta de evidencia.",
        "El detalle unido está en la pestaña Recorrido.",
    )

    # Demo note
    html = html.replace(
        "Vista &lt;strong&gt;funcional&lt;/strong&gt; para la mesa: qué resuelve, reglas y casos. "
        "Sin pasos técnicos de ejecución.",
        "Vista funcional: reglas y casos en cuadros con tablas.",
        1,
    )

    # Replace renderPresentacion (last)
    pat = re.compile(r"function renderPresentacion\(\) \{\n.*?\n\}", re.S)
    ms = list(pat.finditer(html))
    if ms:
        m = ms[-1]
        html = html[: m.start()] + esc_js(RENDER_PRES) + html[m.end() :]
        print("  renderPresentacion ok")
    else:
        print("  WARN renderPresentacion")

    # Enhance renderScenarioCard to show _sps_relacionados and prefer _tabla_ejemplo
    # Find last renderScenarioCard return section - inject SP blocks before conclusion
    needle = "const conclBlock = conclusion ? `&lt;div class=&quot;scenario-section conclusion-box&quot;&gt;"
    inject_before = """const spsRel = (row._sps_relacionados || []);
  const spsBlock = spsRel.length ? `&lt;div class=&quot;scenario-section sp-inline&quot;&gt;
    &lt;span class=&quot;sec-label&quot;&gt;SP que lo hace&lt;/span&gt;
    &lt;div class=&quot;sp-inline-grid&quot;&gt;${spsRel.map(s =&gt; `
      &lt;article class=&quot;sp-inline-card&quot;&gt;
        &lt;header&gt;&lt;code&gt;${esc(s.id)}&lt;/code&gt; &lt;span&gt;${esc(s.archivo || &#x27;&#x27;)}&lt;/span&gt;&lt;/header&gt;
        &lt;p&gt;&lt;b&gt;Objetivo&lt;/b&gt; ${esc(s.objetivo || &#x27;&#x27;)}&lt;/p&gt;
        &lt;p&gt;&lt;b&gt;Acción&lt;/b&gt; ${esc(s.accion || &#x27;&#x27;)}&lt;/p&gt;
        &lt;p&gt;&lt;b&gt;Resultado&lt;/b&gt; ${esc(s.resultado || &#x27;&#x27;)}&lt;/p&gt;
        ${s.por_que ? `&lt;p class=&quot;porque&quot;&gt;&lt;b&gt;Por qué&lt;/b&gt; ${esc(s.por_que)}&lt;/p&gt;` : &#x27;&#x27;}
      &lt;/article&gt;`).join(&#x27;&#x27;)}&lt;/div&gt;
  &lt;/div&gt;` : &#x27;&#x27;;
  """
    # Only in ord renderScenarioCard (last conclBlock)
    idx = html.rfind(needle)
    if idx > 0 and "sp-inline-grid" not in html[idx - 500 : idx + 50]:
        html = html[:idx] + inject_before + html[idx:]
        # Add spsBlock into return template
        ret_needle = "${idBlock}${buscaBlock}${tblPasos}${tblEj}${devBlock}${conclBlock}${accionBlock}"
        ret_new = "${idBlock}${buscaBlock}${tblPasos}${tblEj}${devBlock}${spsBlock}${conclBlock}${accionBlock}"
        # last occurrence in ord
        ridx = html.rfind(ret_needle)
        if ridx > 0:
            html = html[:ridx] + ret_new + html[ridx + len(ret_needle) :]
            print("  sps inline in card ok")
        else:
            print("  WARN ret template")
    else:
        print("  WARN inject sps / already")

    # Hide frame-sps from being reachable; optional hide step
    css = """
/* Demo visual */
.presentacion-wrap { display:flex; flex-direction:column; gap:1rem; margin-top:0.6rem; max-width:980px; }
.demo-section {
  background:#fff; border:1px solid #e2e8f0; border-radius:14px;
  padding:1rem 1.15rem; box-shadow:0 1px 3px rgba(15,23,42,.05);
}
.demo-section h4 { margin:0 0 .4rem; font-size:1.05rem; font-weight:750; color:#0f172a; }
.demo-lead { margin:0 0 .65rem; font-size:.92rem; color:#64748b; line-height:1.45; max-width:60ch; }
.demo-chips { list-style:none; margin:0; padding:0; display:flex; flex-wrap:wrap; gap:.45rem; }
.demo-chips li {
  background:#f1f5f9; border:1px solid #e2e8f0; border-radius:999px;
  padding:.35rem .7rem; font-size:.8rem; color:#1e293b; line-height:1.3;
}
.demo-casos { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:.75rem; margin-top:.35rem; }
.demo-caso {
  border:1px solid #bfdbfe; background:linear-gradient(180deg,#f8fbff,#fff);
  border-radius:12px; padding:.75rem .85rem; display:flex; flex-direction:column; gap:.4rem;
}
.demo-caso header { display:flex; gap:.4rem; align-items:center; }
.demo-id {
  font-family:ui-monospace,Consolas,monospace; font-size:.75rem; font-weight:700;
  color:#1e3a8a; background:#dbeafe; padding:.15rem .45rem; border-radius:999px;
}
.demo-canal {
  font-size:.68rem; font-weight:700; letter-spacing:.04em; text-transform:uppercase; color:#64748b;
}
.demo-q {
  margin:0; font-size:.86rem; font-weight:700; color:#0f172a; line-height:1.3;
  background:#fff7ed; border:1px solid #fed7aa; border-radius:8px; padding:.4rem .55rem;
}
.demo-tabla-wrap { overflow:auto; border:1px solid #e2e8f0; border-radius:8px; }
.demo-tabla { width:100%; border-collapse:collapse; font-size:.74rem; }
.demo-tabla th {
  background:#eff6ff; color:#1e3a8a; font-weight:700; text-align:left;
  padding:.35rem .45rem; border-bottom:1px solid #bfdbfe; white-space:nowrap;
}
.demo-tabla td {
  padding:.32rem .45rem; border-bottom:1px solid #f1f5f9; color:#0f172a;
  font-variant-numeric:tabular-nums;
}
.demo-tabla tr:last-child td { border-bottom:0; }
.demo-r {
  margin:0; font-size:.78rem; color:#166534; background:#f0fdf4;
  border:1px solid #bbf7d0; border-radius:8px; padding:.4rem .55rem; line-height:1.35;
}
@media (max-width:820px){ .demo-casos { grid-template-columns:1fr; } }

/* SP inline in Recorrido */
.sp-inline-grid { display:grid; grid-template-columns:1fr; gap:.5rem; margin-top:.35rem; }
.sp-inline-card {
  border:1px solid #c7d2fe; background:#f5f3ff; border-radius:10px; padding:.55rem .7rem;
  font-size:.78rem; line-height:1.4; color:#312e81;
}
.sp-inline-card header { display:flex; gap:.5rem; flex-wrap:wrap; margin-bottom:.3rem; align-items:baseline; }
.sp-inline-card header code { font-weight:700; color:#1e3a8a; }
.sp-inline-card header span { color:#64748b; font-size:.72rem; }
.sp-inline-card p { margin:.15rem 0; }
.sp-inline-card b { color:#0f172a; }
.sp-inline-card .porque { color:#1e40af; }

#frame-sps { display:none !important; }
#frame-home .frame-fit > .drill-section:not(.demo-hero),
#frame-home .doc-banner,
#frame-home .rules-map { display:none !important; }
"""
    if ".demo-chips" not in html:
        idx = html.rfind("</style>")
        html = html[:idx] + css + html[idx:]
        print("  CSS ok")

    # Fix onclick that referenced showFrame(2) for sps
    html = html.replace(
        "else if (i===7) showFrame(2); else showFrame(0);",
        "else showFrame(1);",
    )

    return html


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    assert len(positions) >= 2
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    patch_data(data)
    html = html[:start] + to_html_json(data) + html[end:]
    html = patch_ui(html)
    bak = path.with_suffix(path.suffix + ".bak_unificado")
    if not bak.exists():
        shutil.copy2(path, bak)
    path.write_text(html, encoding="utf-8")
    print("OK", path.name)


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
