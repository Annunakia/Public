# -*- coding: utf-8 -*-
"""Demo: solo funcional, sin DBeaver; formato visual (cards/bullets)."""
from __future__ import annotations

import json
import re
import shutil
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
]

# Formato: titulo + lead corto + bullets opcional + casos opcional
PRESENTACION = [
    {
        "titulo": "Qué resuelve",
        "lead": "Ordenar con qué contacto empezar cuando una persona tiene varios datos vigentes.",
        "bullets": [
            "Unificación ya dijo qué direcciones son la misma (padre / hija).",
            "Ordenamiento responde: ¿cuál calle, fijo, celular o email intento primero?",
            "No mezcla canales: DIR, TEL, CEL y EMA se ordenan por separado.",
        ],
    },
    {
        "titulo": "Reglas de negocio",
        "lead": "Lo acordado en mesa, en tres frases.",
        "bullets": [
            "Solo ganadoras: la hija de unificación no compite.",
            "TEL, CEL y EMA solo si la persona tiene al menos una dirección ganadora.",
            "El score usa pesos del catálogo (betas RITM); gana el mayor score → lugar 1.",
        ],
    },
    {
        "titulo": "Flujo funcional",
        "lead": "De la persona al orden de contacto.",
        "bullets": [
            "1. Entran solo contactos elegibles (ganadoras y datos válidos).",
            "2. Cada canal obtiene su propio ranking (lugar 1, 2, 3…).",
            "3. En dirección, ese orden queda como orden de prioridad de intento.",
        ],
    },
    {
        "titulo": "Casos de la Demo",
        "lead": "Mismos ejemplos del seed funcional — lo que cuentas en la mesa.",
        "casos": [
            {
                "id": "20001",
                "canal": "DIR",
                "pregunta": "¿Casa o oficina primero?",
                "resultado": "Casa gana (850 → lugar 1); oficina segundo (700 → lugar 2).",
            },
            {
                "id": "20011",
                "canal": "DIR",
                "pregunta": "¿La hija unificada compite?",
                "resultado": "No. Solo el padre tiene score y orden; la hija queda fuera.",
            },
            {
                "id": "20010",
                "canal": "DIR",
                "pregunta": "¿Qué pasa si empatan en score?",
                "resultado": "Mismo score 777; se asignan lugar 1 y 2 sin inventar un desempate de negocio.",
            },
            {
                "id": "20004",
                "canal": "TEL",
                "pregunta": "¿Qué fijo intento primero?",
                "resultado": "Válido primero (420); no válido después (210).",
            },
            {
                "id": "20013",
                "canal": "TEL",
                "pregunta": "¿Una variable de trazabilidad mueve el ranking?",
                "resultado": "No. TEL020 no cambia el score (ambos 376.5).",
            },
            {
                "id": "20012",
                "canal": "CEL",
                "pregunta": "¿Y si el operador no está en catálogo?",
                "resultado": "Aplica el valor por defecto acordado (0.22) → score 220.",
            },
            {
                "id": "20014",
                "canal": "EMA",
                "pregunta": "¿Variables excluidas mueven el email?",
                "resultado": "No. Mismo score 281.7705 aunque solo cambien esas variables.",
            },
            {
                "id": "20001",
                "canal": "Salida",
                "pregunta": "¿Qué queda guardado para contactar?",
                "resultado": "orden_prioridad = lugar DIR: casa 1, oficina 2.",
            },
        ],
    },
    {
        "titulo": "Qué ver en las otras pestañas",
        "lead": "La Demo cuenta la historia; el detalle vive aparte.",
        "bullets": [
            "Workshop — casos por canal con el detalle operativo.",
            "SPs — cada procedimiento: objetivo, ejemplo y por qué el resultado.",
        ],
    },
]


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    assert len(positions) >= 2
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)
    data["presentacion"] = PRESENTACION
    data["generated"] = "2026-09-25"
    html = html[:start] + to_html_json(data) + html[end:]

    # Note under Demo title
    html = html.replace(
        "Esta es la &lt;strong&gt;Demo&lt;/strong&gt;: texto del recorrido y SPs mock. "
        "Las queries viven en &lt;strong&gt;Workshop&lt;/strong&gt;. "
        "Cada SP en formato STAR está en &lt;strong&gt;SPs&lt;/strong&gt;.",
        "Vista &lt;strong&gt;funcional&lt;/strong&gt; para la mesa: qué resuelve, reglas y casos. "
        "Sin pasos técnicos de ejecución.",
        1,
    )
    html = html.replace(
        "Demo — historia y recorrido",
        "Demo funcional",
        1,
    )
    # Marcar sección demo y ocultar el resto técnico del frame-home (ord)
    html = html.replace(
        '&lt;div class=&quot;drill-section-title&quot;&gt;Demo funcional&lt;/div&gt;',
        '&lt;div class=&quot;drill-section-title&quot;&gt;Demo funcional&lt;/div&gt;',
        1,
    )
    # Add demo-hero class on the section that contains presentacionWrap (ord only, last occurrence)
    marker = (
        '&lt;section class=&quot;drill-section&quot;&gt;\n'
        '        &lt;div class=&quot;drill-section-title&quot;&gt;Demo funcional&lt;/div&gt;'
    )
    repl = (
        '&lt;section class=&quot;drill-section demo-hero&quot;&gt;\n'
        '        &lt;div class=&quot;drill-section-title&quot;&gt;Demo funcional&lt;/div&gt;'
    )
    if marker in html:
        idx = html.rfind(marker)
        html = html[:idx] + repl + html[idx + len(marker) :]
        print("  demo-hero ok")
    else:
        print("  WARN demo-hero marker")
    html = html.replace(
        "Demo — Ordenamiento (recorrido completo)",
        "Demo funcional — Ordenamiento",
        1,
    )

    # Replace renderPresentacion
    old_fn = """function renderPresentacion() {
  const items = DATA.presentacion || [];
  const el = document.getElementById(&#x27;presentacionWrap&#x27;);
  if (!el) return;
  el.innerHTML = items.map(b =&gt; `
    &lt;div class=&quot;presentacion-block&quot;&gt;
      &lt;h4&gt;${esc(b.titulo)}&lt;/h4&gt;
      &lt;p&gt;${esc(b.texto)}&lt;/p&gt;
    &lt;/div&gt;`).join(&#x27;&#x27;);
}"""

    new_fn = """function renderPresentacion() {
  const items = DATA.presentacion || [];
  const el = document.getElementById(&#x27;presentacionWrap&#x27;);
  if (!el) return;
  el.innerHTML = items.map(b =&gt; {
    const lead = b.lead ? `&lt;p class=&quot;demo-lead&quot;&gt;${esc(b.lead)}&lt;/p&gt;` : (b.texto ? `&lt;p class=&quot;demo-lead&quot;&gt;${esc(b.texto)}&lt;/p&gt;` : &#x27;&#x27;);
    const bullets = (b.bullets &amp;&amp; b.bullets.length)
      ? `&lt;ul class=&quot;demo-bullets&quot;&gt;${b.bullets.map(x =&gt; `&lt;li&gt;${esc(x)}&lt;/li&gt;`).join(&#x27;&#x27;)}&lt;/ul&gt;`
      : &#x27;&#x27;;
    const casos = (b.casos &amp;&amp; b.casos.length)
      ? `&lt;div class=&quot;demo-casos&quot;&gt;${b.casos.map(c =&gt; `
          &lt;article class=&quot;demo-caso&quot;&gt;
            &lt;header&gt;&lt;span class=&quot;demo-id&quot;&gt;${esc(c.id)}&lt;/span&gt;&lt;span class=&quot;demo-canal&quot;&gt;${esc(c.canal)}&lt;/span&gt;&lt;/header&gt;
            &lt;p class=&quot;demo-q&quot;&gt;${esc(c.pregunta)}&lt;/p&gt;
            &lt;p class=&quot;demo-r&quot;&gt;${esc(c.resultado)}&lt;/p&gt;
          &lt;/article&gt;`).join(&#x27;&#x27;)}&lt;/div&gt;`
      : &#x27;&#x27;;
    return `&lt;section class=&quot;presentacion-block demo-section&quot;&gt;
      &lt;h4&gt;${esc(b.titulo)}&lt;/h4&gt;
      ${lead}${bullets}${casos}
    &lt;/section&gt;`;
  }).join(&#x27;&#x27;);
}"""

    if old_fn in html:
        html = html.replace(old_fn, new_fn, 1)
        print("  renderPresentacion ok")
    else:
        print("  WARN renderPresentacion")

    # CSS upgrade for demo
    css = """
.presentacion-wrap { display: flex; flex-direction: column; gap: 0.85rem; margin-top: 0.55rem; max-width: 920px; }
.demo-section {
  background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);
  border: 1px solid #e2e8f0; border-radius: 12px;
  padding: 0.9rem 1.1rem; box-shadow: 0 1px 0 rgba(15,23,42,0.03);
}
.demo-section h4 {
  margin: 0 0 0.35rem; font-size: 1.02rem; font-weight: 750; color: #0f172a;
  letter-spacing: -0.01em;
}
.demo-lead {
  margin: 0 0 0.55rem; font-size: 0.92rem; line-height: 1.45; color: #475569; max-width: 62ch;
}
.demo-bullets {
  margin: 0; padding: 0 0 0 1.1rem; display: grid; gap: 0.35rem;
}
.demo-bullets li {
  font-size: 0.88rem; line-height: 1.4; color: #1e293b; padding-left: 0.15rem;
}
.demo-casos {
  display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 0.55rem; margin-top: 0.35rem;
}
.demo-caso {
  border: 1px solid #dbeafe; background: #f8fbff; border-radius: 10px;
  padding: 0.65rem 0.75rem; min-height: 6.5rem;
}
.demo-caso header { display: flex; gap: 0.4rem; align-items: center; margin-bottom: 0.35rem; }
.demo-id {
  font-family: ui-monospace, Consolas, monospace; font-size: 0.78rem; font-weight: 700;
  color: #1e3a8a; background: #dbeafe; padding: 0.1rem 0.4rem; border-radius: 999px;
}
.demo-canal {
  font-size: 0.68rem; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase;
  color: #64748b;
}
.demo-q { margin: 0 0 0.3rem; font-size: 0.84rem; font-weight: 650; color: #0f172a; line-height: 1.3; }
.demo-r { margin: 0; font-size: 0.8rem; color: #334155; line-height: 1.35; }
@media (max-width: 820px) { .demo-casos { grid-template-columns: 1fr; } }
/* Demo = solo historia funcional; el resto del home queda fuera de esta pestaña */
#frame-home .frame-fit > .drill-section:not(.demo-hero) { display: none !important; }
#frame-home .frame-fit > .doc-banner { display: none !important; }
#frame-home .kpi-row { display: none !important; }
#frame-home .rules-map { display: none !important; }
"""
    # replace old presentacion-wrap css block if present, else append
    if ".demo-casos" not in html:
        # remove thin old presentacion rules to avoid conflict - append new
        idx = html.rfind("</style>")
        if idx > 0:
            html = html[:idx] + css + html[idx:]
            print("  CSS ok")

    # Soften banner - no DBeaver
    html = html.replace(
        "Demo = historia + seed mock. Workshop = queries por canal. SPs = STAR (objetivo, ejemplo, por qué). "
        "Opción A · solo ganadoras · betas RITM.",
        "Demo funcional · Workshop con detalle · SPs en STAR. Opción A · solo ganadoras · betas RITM.",
    )

    bak = path.with_suffix(path.suffix + ".bak_demo_func")
    if not bak.exists():
        shutil.copy2(path, bak)
    path.write_text(html, encoding="utf-8")
    print("OK", path.name)


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
