# Verificación global — Unificación vs Ordenamiento

| Campo | Valor |
|-------|-------|
| **Fecha** | 2026-09-23 (re-verificado con VPN) |
| **Alcance** | Repos `_dt` / `_strct` / `_pgm` + demo local + remoto Bitbucket |
| **Pull remoto** | **OK** — `git fetch` exitoso en los 3 repos |

---

## 1. Pull de ramas — resultado (recheck VPN)

| Repo | Rama local | `origin/master` | Fetch | Nota |
|------|------------|-----------------|-------|------|
| `db_rcncr_btch_rdshft_dt` | `master` @ `f2ddec9` | `c25d2f5` (Basic EITS) | OK | Local **ahead 11** vs master remoto (master remoto fue force-update) |
| `db_rcncr_btch_rdshft_strct` | `master` @ `c246a7e` | igual | OK | Al día con master; `deploy/` local sin push |
| `db_rcncr_btch_rdshft_pgm` | `master` @ `231052b` | igual | OK | Al día con master; `deploy/` local sin push |

### Ramas remotas relevantes (todas existen)

| Rama | En `_dt` | En `_strct` | En `_pgm` | Contenido |
|------|:--------:|:-----------:|:---------:|-----------|
| `feature/ordenamiento` | sí | sí | sí | **Unificación + Ordenamiento** juntos |
| `feature/unificacion-edf-views` | sí | sí | sí | Solo unificación (vistas EDF) |
| `feature/SLCOPRBA-1285/1286/1287-…` | 1286 | 1285 | 1287 | Paquete unificación EDF por repo |
| `qa/SLCOPRBA-1220` | sí | sí | sí | QA |
| `qa/SLCOPRBA-1284` | sí | sí | sí | QA unificación (deploy solo unif.) |
| `feature/SLCOPRBA-1220-pp9999-sandbox` | sí | sí | sí | Sandbox mock PP9999 |

### Cambios locales sin subir (workspace)

| Repo | Qué hay local sin commit/push |
|------|-------------------------------|
| `_dt` | orquestador `sp_r*` + README; **divergente** del master remoto |
| `_strct` | tablas/catálogo/vistas SLCOPRBA-1147 (más simple que remoto EDF) |
| `_pgm` | `sp_r1/r2/r3` monolíticos por regla (remoto ya tiene SPs **más granulares**) |

---

## 2. Unificación — ¿qué está listo?

### Hecho (evidencia)

| Ítem | Estado | Evidencia |
|------|--------|-----------|
| Cascada R1 → R2 (motor batch) → R3 en SQL | Hecho | Script/SPs |
| 3 SPs en `bdm_stage` (`sp_r1`, `sp_r2`, `sp_r3`) | Hecho en DEV | `pg_proc` 3 filas |
| Tablas / catálogo base en `bdm_stage` | Hecho / ya existían | DBeaver DEV |
| `CALL` cascada OK | Hecho | `perf_timings` hitos OK |
| Benchmark 20K con casos R1/R2/R3/control | Diseñado | SDD + informe |
| Paquete Jenkins local (`deploy.par`) | Armado local | `_strct` → `_pgm` → `_dt` |
| Evidencia QA benchmark monolítico | Parcial | corrida `benchmark_20k_batch_qa_v1` |

### Falta / riesgo — Unificación

| # | Gap | Prioridad |
|---|-----|-----------|
| U1 | **Subir a Bitbucket** `_strct` / `_pgm` / orquestador `_dt` (hoy solo local) | Alta |
| U2 | **Pull + alinear** con ramas remotas (posible trabajo paralelo ya en Bitbucket) | Alta |
| U3 | Promoción formal QA/PDN Jenkins + trazabilidad HU (PR, builds, SNOW) | Alta |
| U4 | Confirmar `type: program` en `_pgm/.jenkins.yml` con DevSecOps | Media |
| U5 | Bug trazabilidad: R3 inserta `unifica_atributos = 1` (debería ser `3`) | Media |
| U6 | Dataset 20K sintético: validar que la corrida DEV con SPs usó datos sintéticos o datos reales de `procesosbatch` | Media |
| U7 | Grants / owner: sin `ANALYZE` (workaround); ideal pedir grants o owner de tablas | Baja |
| U8 | Commits con ID sub-tarea Jira (sin huérfanos) | Alta al promover |

**Veredicto Unificación:** funcionalmente **avanzada en DEV** (objetos + CALL OK). **No cerrada** a nivel pipeline/Bitbucket/promoción.

---

## 3. Ordenamiento — ¿qué falta?

Ordenamiento es la **etapa siguiente** a Unificación:

```
… → Geo → Unificación (R1→R2→R3) → Ordenamiento → Score contactabilidad
```

### En Bitbucket (rama `feature/ordenamiento`) — SÍ hay código

| Repo | Artefactos remotos |
|------|--------------------|
| `_strct` | `01_ddl_ordenamiento.sql`, catálogos, vistas insumo/contacto EDF |
| `_pgm` | `sp_ordenamiento_preparar_insumos`, `scoring_dir/tel/cel/ema`, `consolidacion`, `ejecucion`, `drop_staging` |
| `_dt` | `run_ordenamiento_ejecucion_edf.sql` + validaciones (+ también unificación en el mismo `deploy.par`) |

### En tu `master` local / trabajo de julio — NO

| Ítem | Estado local |
|------|--------------|
| SQL/SPs ordenamiento en tu checkout `master` | No |
| Docs reqs | Solo `REQUERIMIENTOS_ORDENAMIENTO.md` en demo |

### En ramas QA recientes (`qa/SLCOPRBA-1284`, unificacion-edf)

`deploy.par` apunta **solo unificación** (ordenamiento **fuera** del paquete QA actual), coherente con lo que dijo el equipo.

**Veredicto Ordenamiento:** **implementado en remoto** (`feature/ordenamiento`), **no está en tu master local**. Para trabajarlo: `git checkout feature/ordenamiento` (o la rama QA que indiquen). No mezclar con el paquete simple `sp_r1/r2/r3` de julio sin alinear.

---

## 4. Mapa global (pipeline Reconocer)

| Etapa | Este workspace | Qué falta |
|-------|----------------|-----------|
| XPM / Estandarización | Fuera | — |
| Geo | Doc local | No código batch aquí |
| **Unificación** | SPs + demo + benchmark | Push/PR/QA-PDN + fix R3 atributo |
| **Ordenamiento** | Solo reqs | Spec + SQL/SPs + deploy |
| Score contactabilidad | Fuera | Contrato post-ordenamiento |

---

## 5. Checklist inmediato (tú)

1. [ ] Conectar **VPN** y `git pull` en `_dt`, `_strct`, `_pgm`
2. [ ] Comparar remoto vs local (¿ya hay unificación más nueva en Bitbucket?)
3. [ ] Decidir: mergear tu paquete SP o adoptar el remoto
4. [ ] Commit/PR unificación (sin ordenamiento en `deploy.par` si así lo acordaron)
5. [ ] Cerrar evidencia HU unificación (Jenkins + `perf_timings`)
6. [ ] Ordenamiento: pedir HLD/Kidar; no mezclar en el mismo deploy hasta cerrar unificación

---

## 6. Mensaje corto (estado)

Pull OK con VPN. En remoto ya hay mucho más: unificación EDF (SPs granulares, ramas 1284–1287) y rama `feature/ordenamiento` con DDL + scoring dir/tel/cel/ema. Tu master local aún tiene el paquete simple de julio (`sp_r1/r2/r3`) sin subir; no es el código actual del equipo. Siguiente: checkout de la rama que indiquen (p. ej. `feature/ordenamiento` o `qa/SLCOPRBA-1284`) y no seguir sobre el master viejo.

---

*Generado 2026-09-23 — recheck con VPN OK.*
