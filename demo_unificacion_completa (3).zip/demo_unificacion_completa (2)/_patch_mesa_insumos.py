# -*- coding: utf-8 -*-
"""HTML #ord: lenguaje mesa de trabajo + insumos (Fase 1) bien explicados."""
from __future__ import annotations

import json
import re
import shutil
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
]

GUION = [
    {
        "paso": "0",
        "titulo": "Acuerdo de la mesa",
        "decir": (
            "Opción A: primero unificación, después ordenamiento. "
            "Solo entran ganadoras. Cuatro canales aparte (calle, fijo, celular, email). "
            "Los pesos vienen del catálogo RITM (47 betas). "
            "No es malla 242 ni incremental en este alcance."
        ),
    },
    {
        "paso": "1",
        "titulo": "Dos preguntas distintas",
        "decir": (
            "Unificación: ¿estas direcciones son la misma? "
            "Ordenamiento: si hay varias vigentes, ¿cuál contacto intento primero? "
            "Una no reemplaza a la otra."
        ),
    },
    {
        "paso": "2",
        "titulo": "Antes de puntuar: el insumo",
        "decir": (
            "El insumo responde ¿quién entra? "
            "Se arma la lista de candidatos: RPUs ganadoras, contactType → canal, "
            "y se descartan hijas, emails sin @ y tipos que no aplican. "
            "Sin ese paso no hay ranking confiable."
        ),
    },
    {
        "paso": "3",
        "titulo": "Cómo se puntúa",
        "decir": (
            "Cada característica se convierte en un valor, se multiplica por su beta del catálogo "
            "y se suma. Gana el mayor score → lugar 1. "
            "DIR, TEL, CEL y EMA no se mezclan entre sí."
        ),
    },
    {
        "paso": "4",
        "titulo": "Recorrido de ejemplos",
        "decir": (
            "Seed 20001 casa vs oficina → 20011 padre/hija → 20010 empate → "
            "20004 TEL → 20013 TEL020 → 20012 CEL → 20014 EMA → salida orden_prioridad."
        ),
    },
    {
        "paso": "5",
        "titulo": "Qué ya cerró la mesa",
        "decir": (
            "Fórmulas TEL/EMA/CEL, betas RITM, 0 hijas mal ordenadas, Opción A en DEV. "
            "Queda fuera por ahora: paridad numérica Teradata (MIG-01), incremental y malla 242."
        ),
    },
    {
        "paso": "6",
        "titulo": "Cómo verificar",
        "decir": (
            "En DBeaver: CALL bdm_stage.sp_ordenamiento_ejecucion_mock(); "
            "luego la query de cada tarjeta. Debe devolver las mismas filas del seed."
        ),
    },
]


def pasos(title: str, rows: list[list[str]]) -> dict:
    return {
        "title": title,
        "headers": ["Paso", "Qué ocurre", "Evidencia"],
        "rows": rows,
    }


def q_seed(body: str) -> str:
    return (
        "-- Seed validado (mismas filas del HTML):\n"
        "CALL bdm_stage.sp_ordenamiento_ejecucion_mock();\n"
        + body
    )


NARR = {
    "RESUMEN": {
        "_titulo_corto": "Unificación primero, luego ordenamiento",
        "Subescenario": "Unificación primero, luego ordenamiento",
        "_busca": (
            "Acuerdo de mesa: Unificación decide quién es la misma dirección (padre/hija). "
            "Ordenamiento, solo sobre ganadoras, decide qué contacto intentar primero "
            "por canal (DIR, TEL, CEL, EMA), con pesos del catálogo RITM."
        ),
        "_dev": (
            "En la mesa se acordó Opción A: post-unificación desde edf_views, sin malla 242. "
            "Unificación ya dejó ganadoras e hijas. Ordenamiento toma solo ganadoras "
            "y arma un ranking por canal. Los ejemplos del recorrido usan el seed 20001–20014."
        ),
        "_conclusion_regla": (
            "Unificación = quién compite. Ordenamiento = en qué orden intento el contacto. "
            "Canales aparte · solo ganadoras · betas del catálogo."
        ),
        "_tabla_pasos": pasos(
            "Lo que acordó la mesa (en orden)",
            [
                [
                    "1",
                    "Corre Unificación (R1/R2/R3) y quedan padres ganadores e hijas.",
                    "unificacion_direccion",
                ],
                [
                    "2",
                    "Se arma el insumo: ¿quién entra a puntuar?",
                    "preparar_insumos / stg_*",
                ],
                [
                    "3",
                    "Se puntúa cada canal por separado (DIR, TEL, CEL, EMA).",
                    "score_ordenamiento",
                ],
                [
                    "4",
                    "Se guarda el orden de intento (lugar → orden_prioridad).",
                    "rpu_orden_prioridad",
                ],
            ],
        ),
    },
    "FLUJO": {
        "_titulo_corto": "De la unificación al orden de contacto",
        "Subescenario": "De la unificación al orden de contacto",
        "_busca": (
            "Pipeline Opción A: unificación previa → armar insumos → puntuar 4 canales → "
            "guardar orden_prioridad → limpiar staging. Equivale al flujo Control-M acordado."
        ),
        "_dev": (
            "Primero tiene que existir unificación. "
            "Después el SP de insumos arma la ‘mesa de candidatos’. "
            "Solo entonces corren DIR, TEL, CEL y EMA. "
            "Al final se persiste el orden y se borran las tablas temporales."
        ),
        "_conclusion_regla": (
            "Sin insumos no hay ranking. Sin unificación previa, el insumo no sabe quién es ganadora."
        ),
        "_tabla_pasos": pasos(
            "Pipeline en lenguaje de mesa",
            [
                [
                    "1",
                    "Unificación ya corrió (padres e hijas definidos).",
                    "Precondición",
                ],
                [
                    "2",
                    "Insumo: se arma quién entra (ganadoras + contactos válidos).",
                    "sp_preparar_insumos_edf ~78s",
                ],
                [
                    "3",
                    "Se puntúa calle, fijo, celular y email por separado.",
                    "scoring ×4",
                ],
                [
                    "4",
                    "Se guarda el orden de intento en la RPU.",
                    "orden_prioridad",
                ],
                [
                    "5",
                    "Se limpia el staging (vive solo esa corrida).",
                    "DROP stg_*",
                ],
            ],
        ),
    },
    "INSUMO-CT": {
        "_titulo_corto": "¿Quién entra? — del tipo de contacto al canal",
        "Subescenario": "¿Quién entra? — del tipo de contacto al canal",
        "_busca": (
            "Pregunta de mesa: ¿este dato entra a ordenamiento y a qué canal? "
            "Cada contactType de XPM se traduce a DIR, TEL, CEL o EMA. "
            "Si el tipo no aplica, o el dato no es válido (ej. email sin @), no entra."
        ),
        "_dev": (
            "Antes de hablar de scores, la mesa pregunta ¿quién entra? "
            "La dirección física (tipos 1,2,3,7,8) alimenta el canal DIR. "
            "El fijo (4,5,8) va a TEL; el celular (9) a CEL; el email (10) a EMA. "
            "TEL, CEL y EMA solo entran si la persona ya tiene al menos una dirección ganadora. "
            "Ejemplo claro: un email sin @ se marca NO VÁLIDO y no compite."
        ),
        "_conclusion_regla": (
            "contactType define el canal. Sin dirección ganadora, TEL/CEL/EMA no entran. "
            "Dato inválido (sin @, etc.) tampoco."
        ),
        "_tabla_pasos": pasos(
            "Cómo leer el insumo de contactos",
            [
                [
                    "1",
                    "Se mira el tipo de contacto que viene de XPM.",
                    "contactType",
                ],
                [
                    "2",
                    "Se traduce a un canal: calle / fijo / celular / email.",
                    "DIR · TEL · CEL · EMA",
                ],
                [
                    "3",
                    "Si es TEL/CEL/EMA, se exige que la persona tenga DIR ganadora.",
                    "stg_persona_dir_ganadora",
                ],
                [
                    "4",
                    "Si el dato no es usable (ej. email sin @), queda fuera.",
                    "Filtro en preparar insumos",
                ],
            ],
        ),
        "_tabla_ejemplo": {
            "title": "contactType → canal (quién entra)",
            "headers": [
                "Tipo XPM",
                "Canal",
                "¿Entra?",
                "Condición de mesa",
            ],
            "rows": [
                ["1, 2, 3, 7, 8", "DIR (calle)", "Sí", "Solo si la RPU es ganadora"],
                ["4, 5, 8", "TEL (fijo)", "Sí", "Persona con al menos una DIR ganadora"],
                ["9", "CEL (celular)", "Sí", "Celular usable + DIR ganadora"],
                ["10", "EMA (email)", "Sí", "Debe traer @; si no, no entra"],
                ["Otros", "—", "No", "Fuera del modelo de ordenamiento"],
            ],
        },
        "_ejemplo_label": "Insumo · mapa contactType → canal",
        "_id_ejemplo": "SEED · mapa de entrada (Fase 1)",
        "_fuente": "SEED",
        "Query validación (copiar en dba_rncr_batch)": q_seed(
            "-- Personas del seed y sus canales con score\n"
            "SELECT id_buro_persona, canal, COUNT(*) AS n_scores\n"
            "FROM bdm_stage.mock_ord_score\n"
            "GROUP BY 1, 2\n"
            "ORDER BY 1, 2;\n"
        ),
        "Qué espera (negocio)": (
            "Cada tipo de contacto entra a un canal; TEL/CEL/EMA solo con DIR ganadora."
        ),
        "Qué encontramos DEV": (
            "Mapa contactType aplicado en preparar_insumos; email sin @ no entra."
        ),
    },
    "RPU-STG": {
        "_titulo_corto": "Solo ganadoras — qué direcciones pasan al ranking",
        "Subescenario": "Solo ganadoras — qué direcciones pasan al ranking",
        "_busca": (
            "Pregunta de mesa: ¿esta dirección compite o ya quedó absorbida? "
            "El insumo de RPU marca ganadoras (ind_unificacion distinto de 1) e hijas (1). "
            "Solo las ganadoras reciben score y orden."
        ),
        "_dev": (
            "Aquí se concreta la regla de oro de la mesa: solo ganadoras. "
            "Después de Unificación, cada RPU queda como padre vigente o como hija. "
            "El staging (stg_rpu_post_unificacion) lee esa marca. "
            "Si es hija (ind_unificacion = 1), no entra al ranking. "
            "Ejemplo seed: persona 20011 — el padre 91018 sí puntúa; la hija 91019 no aparece."
        ),
        "_conclusion_regla": (
            "Hija absorbida = no score, no orden. Padre / RPU vigente = sí compite. "
            "Eso se decide en el insumo, antes del scoring."
        ),
        "_tabla_pasos": pasos(
            "Cómo se arma el insumo de direcciones",
            [
                [
                    "1",
                    "Se leen las RPUs y se cruzan con el resultado de Unificación.",
                    "stg_rpu_post_unificacion",
                ],
                [
                    "2",
                    "Se marca si la RPU es hija (ind_unificacion = 1) o ganadora.",
                    "Join unificacion_direccion",
                ],
                [
                    "3",
                    "Se arma la lista de personas que sí tienen dirección ganadora.",
                    "stg_persona_dir_ganadora",
                ],
                [
                    "4",
                    "Solo esa lista alimenta DIR y habilita TEL/CEL/EMA.",
                    "Filtro de elegibilidad",
                ],
            ],
        ),
        "_tabla_ejemplo": {
            "title": "Elegibilidad en el insumo (ejemplo 20011)",
            "headers": [
                "Caso",
                "ind_unificacion",
                "¿Entra al ranking?",
                "Lectura de mesa",
            ],
            "rows": [
                ["Padre / ganadora", "NULL o 0", "Sí", "Dirección vigente — sí se puntúa"],
                ["Hija absorbida", "1", "No", "Ya no es contacto a intentar"],
                ["Sin unificar", "NULL", "Sí", "Nunca fue hija — compite normal"],
                ["Seed 20011 padre 91018", "NULL", "Sí", "Tiene score y orden_prioridad"],
                ["Seed 20011 hija 91019", "1", "No", "0 filas en score y en orden"],
            ],
        },
        "_ejemplo_label": "Insumo RPU · solo ganadoras · seed 20011",
        "_id_ejemplo": "SEED · id_buro_persona = 20011",
        "_id_buro_persona": 20011,
        "_fuente": "SEED",
        "Query validación (copiar en dba_rncr_batch)": q_seed(
            "-- Padre vs hija en el seed (F3-02)\n"
            "SELECT r.etiqueta, r.cod_dw_persona_ubic AS rpu, r.ind_unificacion,\n"
            "       s.score, s.lugar, p.orden_prioridad\n"
            "FROM bdm_stage.mock_ord_rpu r\n"
            "LEFT JOIN bdm_stage.mock_ord_score s\n"
            "  ON s.cod_dw_persona_ubic = r.cod_dw_persona_ubic AND s.canal = 'DIR'\n"
            "LEFT JOIN bdm_stage.mock_ord_prioridad p\n"
            "  ON p.cod_dw_persona_ubic = r.cod_dw_persona_ubic\n"
            "WHERE r.id_buro_persona = 20011\n"
            "ORDER BY r.cod_dw_persona_ubic;\n"
        ),
        "Qué espera (negocio)": (
            "Solo RPUs ganadoras entran; hijas ind_unificacion=1 quedan fuera."
        ),
        "Qué encontramos DEV": (
            "Seed 20011: padre con score/orden; hija sin filas."
        ),
    },
    "BETAS": {
        "_titulo_corto": "Los pesos del ranking (catálogo betas RITM)",
        "Subescenario": "Los pesos del ranking (catálogo betas RITM)",
        "_busca": (
            "Pregunta de mesa: ¿de dónde salen los pesos del score? "
            "De un catálogo acordado (RITM5226589, 47 coeficientes). "
            "Redshift no inventa ni recalibra: solo aplica el beta en la fórmula."
        ),
        "_dev": (
            "En la sesión se fijó: betas = catálogo RITM, no un modelo nuevo en Redshift. "
            "Hay 47 coeficientes cargados en bdm_datos.beta_ordenamiento. "
            "Cada característica del score se multiplica por su beta. "
            "Si mañana Experian cambia un peso en el catálogo, el ranking cambia sin tocar la fórmula. "
            "Paridad con Teradata solo tiene sentido si ambas plataformas usan el mismo catálogo."
        ),
        "_conclusion_regla": (
            "Experian define los pesos; Redshift los aplica. "
            "47 betas RITM en DEV · no se recalibra en el SP."
        ),
        "_tabla_pasos": pasos(
            "Cómo entran los betas al score",
            [
                [
                    "1",
                    "Negocio/Experian publica el catálogo de coeficientes.",
                    "RITM5226589",
                ],
                [
                    "2",
                    "Se cargan en Redshift (tabla de betas).",
                    "bdm_datos.beta_ordenamiento · 47 filas",
                ],
                [
                    "3",
                    "Al puntuar, cada característica hace JOIN a su beta.",
                    "SPs scoring DIR/TEL/CEL/EMA",
                ],
                [
                    "4",
                    "Score = suma (categoría/máximo × beta). Mayor score → lugar 1.",
                    "Fórmula Opción A",
                ],
            ],
        ),
        "_tabla_ejemplo": {
            "title": "Roles sobre el catálogo de betas",
            "headers": ["Quién", "Qué hace", "Qué no hace", "Estado"],
            "rows": [
                [
                    "Experian / negocio",
                    "Define y vigila los coeficientes",
                    "No corre el SP de scoring",
                    "Catálogo RITM",
                ],
                [
                    "Redshift (SPs)",
                    "Aplica el beta en la suma del score",
                    "No recalibra ni inventa pesos",
                    "47 betas en DEV",
                ],
                [
                    "Mesa de trabajo",
                    "Acuerda usar este catálogo (Opción A)",
                    "No pide malla 242 en este alcance",
                    "Acordado",
                ],
            ],
        },
        "_ejemplo_label": "Insumo · catálogo betas RITM (47)",
        "_id_ejemplo": "SEED / DEV · 47 betas RITM5226589",
        "_fuente": "SEED",
        "Query validación (copiar en dba_rncr_batch)": (
            "-- Catálogo de pesos (DEV real)\n"
            "SELECT canal, COUNT(*) AS n_betas\n"
            "FROM bdm_datos.beta_ordenamiento\n"
            "GROUP BY 1\n"
            "ORDER BY 1;\n"
            "-- Total esperado: 47\n"
            "SELECT COUNT(*) AS total_betas FROM bdm_datos.beta_ordenamiento;\n"
        ),
        "Qué espera (negocio)": (
            "Pesos del catálogo RITM; Redshift solo aplica, no recalibra."
        ),
        "Qué encontramos DEV": (
            "47 betas RITM5226589 en bdm_datos.beta_ordenamiento."
        ),
    },
    "SP-PREP": {
        "_titulo_corto": "El insumo en simple — armar candidatos antes de puntuar",
        "Subescenario": "El insumo en simple — armar candidatos antes de puntuar",
        "_busca": (
            "El SP de preparar insumos es el paso ‘¿quién entra?’. "
            "Lee una vez el datashare, arma tablas temporales (stg_*) con ganadoras y contactos "
            "listos por canal, y no deja copia permanente de XPM."
        ),
        "_dev": (
            "En lenguaje de mesa: antes de puntuar hay que armar la lista de candidatos. "
            "Eso es el insumo. "
            "1) Se marcan RPUs ganadoras vs hijas. "
            "2) Se filtran personas con dirección ganadora. "
            "3) Se separan contactos DIR / TEL / CEL / EMA. "
            "4) Quedan cuatro ‘bandejas’ listas para el scoring. "
            "Al terminar la corrida se borran (staging de una sola ejecución). "
            "Si este paso falla o se salta, el ranking no refleja el acuerdo de la mesa."
        ),
        "_conclusion_regla": (
            "Insumo = lista de quién compite, por canal. "
            "Vive solo la corrida · alimenta el scoring · no redefine Unificación."
        ),
        "_tabla_pasos": pasos(
            "Qué hace preparar_insumos (sin jerga)",
            [
                [
                    "1",
                    "Trae las direcciones y marca ganadora / hija.",
                    "stg_rpu_post_unificacion",
                ],
                [
                    "2",
                    "Arma la lista de personas que sí tienen calle ganadora.",
                    "stg_persona_dir_ganadora",
                ],
                [
                    "3",
                    "Separa contactos por canal (calle, fijo, celular, email).",
                    "stg_contacto_* / stg_insumo_*",
                ],
                [
                    "4",
                    "Deja cada bandeja lista para su SP de scoring.",
                    "Entrada a DIR/TEL/CEL/EMA",
                ],
                [
                    "5",
                    "Al final del pipeline se borran las tablas temporales.",
                    "sp_drop_staging_edf",
                ],
            ],
        ),
        "_tabla_ejemplo": {
            "title": "Insumo → qué sale para cada canal",
            "headers": ["Bandeja", "Pregunta que responde", "Quién entra", "Siguiente paso"],
            "rows": [
                [
                    "DIR",
                    "¿Qué calle intento primero?",
                    "RPUs ganadoras con dirección",
                    "scoring_dir",
                ],
                [
                    "TEL",
                    "¿Qué fijo intento primero?",
                    "Fijos de personas con DIR ganadora",
                    "scoring_tel",
                ],
                [
                    "CEL",
                    "¿Qué celular intento primero?",
                    "Celulares de personas con DIR ganadora",
                    "scoring_cel",
                ],
                [
                    "EMA",
                    "¿Qué email intento primero?",
                    "Emails con @ de personas con DIR ganadora",
                    "scoring_ema",
                ],
            ],
        },
        "_ejemplo_label": "Insumo · sp_ordenamiento_preparar_insumos_edf",
        "_id_ejemplo": "SEED · cascada insumo → score",
        "_fuente": "SEED",
        "Query validación (copiar en dba_rncr_batch)": q_seed(
            "-- El seed ya materializa el resultado del insumo+scoring\n"
            "SELECT 'rpu' AS capa, COUNT(*)::BIGINT AS n FROM bdm_stage.mock_ord_rpu\n"
            "UNION ALL\n"
            "SELECT 'score', COUNT(*)::BIGINT FROM bdm_stage.mock_ord_score\n"
            "UNION ALL\n"
            "SELECT 'prioridad', COUNT(*)::BIGINT FROM bdm_stage.mock_ord_prioridad;\n"
            "-- Catálogo de escenarios del seed (mismos ids del HTML)\n"
            "SELECT id_buro_persona, cod_escenario, descripcion\n"
            "FROM bdm_stage.mock_ord_escenario\n"
            "WHERE es_html_ejemplo = 1\n"
            "ORDER BY 1, 2;\n"
        ),
        "Qué espera (negocio)": (
            "Una lectura → candidatos por canal listos para puntuar; sin copia permanente."
        ),
        "Qué encontramos DEV": (
            "preparar_insumos_edf ~78s en corrida full; staging se limpia al final."
        ),
    },
}


UI_REPLACEMENTS = [
    (
        "Fase 1 — Armar candidatos (qué entra)",
        "Fase 1 — Insumos: ¿quién entra a puntuar?",
    ),
    (
        "Solo ganadoras · contactType → canal · ejemplo: email sin @ no entra",
        "Lenguaje de mesa: solo ganadoras · tipo de contacto → canal · email sin @ no entra · betas del catálogo",
    ),
    (
        "5 · contactType → canal",
        "5 · Insumo — contactType → canal (quién entra)",
    ),
    (
        "9 · Cascada — insumo → score → orden_prioridad",
        "9 · Cascada — primero el insumo, luego el score, luego el orden",
    ),
    (
        "Cada caja es un paso del pipeline. Clic para ubicar en la matriz.",
        "Primero se arma quién entra (insumo), después se puntúa, al final se guarda el orden de intento.",
    ),
    (
        "Ejemplo fijado: id_buro_persona=2848501447849812647 · RPU 166366/166369 lugares 1/2",
        "Seed 20001 casa vs oficina · también 20011 hija fuera · 20010 empate",
    ),
    (
        "¿Quién entra? Solo ganadoras. Email sin @ fuera. Ejemplo: hijas no compiten.",
        "Insumo: ¿quién entra? Solo ganadoras. contactType→canal. Email sin @ fuera. Hijas no compiten.",
    ),
]


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def patch_glossary_insumo(html: str) -> str:
    """Asegura tarjeta de glosario 'Insumo' en renderGlossary del bloque ord."""
    needle = (
        "&lt;div class=&quot;glossary-card&quot;&gt;&lt;h4&gt;Ganadora&lt;/h4&gt;"
    )
    insert = (
        "&lt;div class=&quot;glossary-card&quot;&gt;&lt;h4&gt;Insumo&lt;/h4&gt;"
        "&lt;p&gt;Paso &lt;strong&gt;¿quién entra?&lt;/strong&gt;: arma ganadoras y contactos "
        "por canal (DIR/TEL/CEL/EMA) antes de puntuar. Sin insumo no hay ranking.&lt;/p&gt;&lt;/div&gt;\n    "
        + needle
    )
    # Solo en bloque ord: buscar la segunda ocurrencia de Ganadora glossary si hay dos
    if "Insumo&lt;/h4&gt;" in html or "<h4>Insumo</h4>" in html:
        print("  glossary Insumo already present")
        return html
    # Prefer replace near Opción A / Ganadora in ord section (after line ~3130)
    idx = html.rfind(needle)
    if idx >= 0:
        html = html[:idx] + insert + html[idx + len(needle) :]
        print("  glossary Insumo inserted")
    else:
        print("  WARN glossary needle not found")
    return html


def patch_banner(html: str) -> str:
    old = (
        "Unificación primero · solo ganadoras · 4 canales · betas = catálogo RITM · Opción A EDF."
    )
    new = (
        "Lenguaje de mesa: Unificación primero · solo ganadoras · armar insumos · "
        "4 canales aparte · betas = catálogo RITM · Opción A EDF."
    )
    if old in html:
        html = html.replace(old, new)
        print("  banner ok")
    return html


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    assert len(positions) >= 2, path

    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)

    data["guion_sesion"] = GUION
    data["generated"] = "2026-09-25"

    # contact_types: lenguaje mesa
    data["contact_types"] = [
        {
            "types": "1, 2, 3, 7, 8",
            "canal": "DIR — calle",
            "unificacion": "Define si hay padre/hija",
            "ordenamiento": "Solo ganadoras entran al ranking de calle",
        },
        {
            "types": "4, 5, 8",
            "canal": "TEL — fijo",
            "unificacion": "Type 8 también es token de dirección",
            "ordenamiento": "Entra solo si la persona ya tiene DIR ganadora",
        },
        {
            "types": "9",
            "canal": "CEL — celular",
            "unificacion": "—",
            "ordenamiento": "Prefijo 3 dígitos → operador; sin catálogo → 0.22",
        },
        {
            "types": "10",
            "canal": "EMA — email",
            "unificacion": "—",
            "ordenamiento": "Debe traer @; si no, no entra al insumo",
        },
    ]

    n = 0
    for row in data.get("rows") or []:
        code = row.get("_pack_code")
        if code not in NARR:
            continue
        for k, v in NARR[code].items():
            row[k] = v
        if "_conclusion_regla" in NARR[code]:
            row["_conclusion"] = NARR[code]["_conclusion_regla"]
        n += 1

    html = html[:start] + to_html_json(data) + html[end:]

    for old, new in UI_REPLACEMENTS:
        if old in html:
            html = html.replace(old, new)
            print("  UI ok", len(old))
        else:
            print("  WARN UI missing", len(old))

    html = patch_banner(html)
    html = patch_glossary_insumo(html)

    bak = path.with_suffix(path.suffix + ".bak_mesa_insumos")
    if not bak.exists():
        shutil.copy2(path, bak)
    path.write_text(html, encoding="utf-8")
    print(f"OK {path.name}: {n} escenarios")


def main() -> None:
    for p in PATHS:
        if p.exists():
            patch_file(p)
        else:
            print("SKIP", p)


if __name__ == "__main__":
    main()
