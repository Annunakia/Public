# Guion Demo v3 — Unificación Completa (R1 + R2 + R3)

> **Versión:** 3 — guía en vivo con narración **funcional** (negocio) + validación técnica por paso  
> **Basado en:** `GUION_DEMO_VIDEO_v2.md` (v2 intacto como referencia)  
> **Duración estimada:** 35-45 minutos  
> **Herramienta:** DBeaver conectado a Redshift  
> **Esquema:** `bdm_stage`  
> **Regla:** cada `.sql` se ejecuta **completo** (Run Script). No seleccionar rangos de líneas.

### Cómo leer cada paso

| Sección | Para qué sirve |
|---------|----------------|
| **Qué significa** | Explicación de negocio — **léela o parafrasea en la demo** |
| **Guía en vivo** | Regla · Escenario · subcaso · criterio |
| **Antes de ejecutar** | Frase de apertura del paso |
| **Al mostrar resultados** | Qué decir fila a fila al ejecutar las consultas |
| **Ejecutar** | Script a correr |
| **Consultas** | SQL sin cambios — evidencia en pantalla |
| **Resultado esperado** | Tabla compacta de validación |
| **Si falla** | Señal rápida de problema |

Los criterios completos (R1-01…R3-06, G-01…) están en **Anexo A** al final.

**Diagrama previo:** `mapa_unificacion_demo.drawio`

### Consultas ancladas en DBeaver (reutilizar toda la demo)

Deja **dos pestañas fijas** en DBeaver y vuelve a ellas en cada paso:

| ID | Nombre en DBeaver | Para qué |
|----|-------------------|----------|
| **A** | `DEMO — Insumo vigente` | Ver direcciones sin unificar (persona, calle, complemento, CIIU) |
| **B** | `DEMO — Diccionario complementos` | Ver **historial de frecuencias** que desempata R2 y alimenta el motor |
| **C** | `DEMO — Regla 3 detalle` | Variables completas R3 (PASO 15): geo, fecha, dicc. vía, umbral |

En los pasos siguientes se indica: *"Abrir consulta anclada A / B / C"*.

### Glosario funcional (usar en la narración)

| Término técnico | Qué decir en la demo |
|-----------------|----------------------|
| **PADRE / vigente** | La dirección **oficial** — la que el sistema conserva para contacto y ordenamiento |
| **HIJO / absorbida** | La dirección **redundante** — no se borra, pero deja de competir; queda en trazabilidad |
| **Complemento** | El detalle extra de la dirección: apartamento, torre, local, oficina, edificio… |
| **Tipo de uso** | Cómo se usa esa dirección: residencia, laboral, correspondencia… |
| **Motor** | Cuando no basta elegir una fuente, el sistema **arma una dirección nueva** combinando ambas |
| **Diccionario** | Cuando hay empate, gana la nomenclatura **más reportada históricamente** |
| **NIT** | Número de Identificación Tributaria (`cod_tipo_ident_fte = 3`) — empresa; en Esc 3 **combina** locales con motor |
| **Sin NIT** | Persona natural — en Esc 3 **elige una** dirección por mayor respaldo de fuentes |
| **Ordenamiento** | Paso posterior donde solo entran las direcciones **vigentes** |

---

## Progreso global

- [ ] PASO 01 — Setup
- [ ] PASO 02 — Regla 1
- [ ] PASO 03 — R2 Esc 1 y 2
- [ ] PASO 04 — R2 Esc 4
- [ ] PASO 05 — R2 Esc 3 sin NIT
- [ ] PASO 06 — R2 Esc 3 NIT (prepara)
- [ ] PASO 07 — Motor (NIT)
- [ ] PASO 08 — R2 Esc 3 NIT (cierra)
- [ ] PASO 09 — R2 Esc 5 (prepara)
- [ ] PASO 10 — Motor (Esc 5)
- [ ] PASO 11 — R2 Esc 5 (cierra)
- [ ] PASO 12 — R2 Esc 6 (prepara)
- [ ] PASO 13 — Motor (Esc 6)
- [ ] PASO 14 — R2 Esc 6 (cierra)
- [ ] PASO 15 — Regla 3
- [ ] PASO 16 — Resumen final
- [ ] PASO 17 — Limpieza

---

## Contexto (2 min — antes del PASO 01)

### Frase de apertura

> "Reconocer determina la mejor forma de contactar a una persona. Unificación elimina direcciones redundantes aplicando 3 reglas en cascada: R1 por tipo de uso, R2 por complementos, R3 por geolocalización. Al final **solo las vigentes** pasan a ordenamiento; las absorbidas quedan en trazabilidad."

### Flujo

```
XPM → bdm_stage → R1 → R2 (+ motor ×3) → R3 → Ordenamiento (solo vigentes)
```

### Leyenda rápida de complementos

| Sigla | Significado |
|-------|-------------|
| AP | Apartamento |
| LC | Local comercial |
| TO | Torre |
| OF | Oficina |
| CS | Casa |
| PI | Piso |
| ED | Edificio |

### Nomenclatura escenario / subcaso

En la narración, nombra siempre: **Regla X · Escenario Y · subcaso Z** (si aplica).

| Regla | Escenario | Subcaso | Persona(s) | Mecanismo |
|-------|-----------|---------|------------|-----------|
| **R1** | Esc 1 | CIIU asalariado (10) | 1001, 1004* | Preferencia LAB/CRR + entidades |
| R1 | Esc 2 | CIIU sin actividad (81) | 1002 | Preferencia RES/CRR |
| R1 | Esc 3 | Otro CIIU (55) | 1003 | Mayor entidades |
| R1 | — | Hija previa | 1005 | No re-procesa absorbida |
| **R2** | Esc 1 | Vacío vs informado | 2001 | Regla directa |
| R2 | Esc 2 | Inclusión / más completo | 2002 | Regla directa |
| R2 | Esc 3 | Sin NIT | 2003 | Mayor entidades |
| R2 | Esc 3 | NIT → motor | 2004 | Motor combina |
| R2 | Esc 4 | Diccionario mismo nivel | 2005 | Frecuencia |
| R2 | Esc 4 | Empate persistente | 2010* | Sin unificación (R2-14) |
| R2 | Esc 5 | Sub 1 — distinto nivel → motor | 2006 | Motor combina |
| R2 | Esc 5 | Sub 2 — mismo valor → diccionario | 2008 | Frecuencia |
| R2 | Esc 6 | Sub 1 — cruzadas → motor | 2007 | Motor combina |
| R2 | Esc 6 | Sub 3 — cruzadas mismo nivel → dicc. | 2009 | Frecuencia |
| **R3** | Esc 1 | Sub 1 — solo una con geo | 3001 | Geo gana |
| R3 | Esc 1 | Sub 3 — ambas con geo → dicc. vía | 3003 | Diccionario vía |
| R3 | Esc 2 | Sub 2 — sin geo → fecha | 3002 | Fecha + entidades |
| R3 | Esc 2 | Fuera de umbral (dif > ±2) | 3004* | Sin unificación (R3-06) |

\* Casos negativos (no unifica o no entra).

**Plantilla verbal (funcional):** *"Regla [1|2|3], Escenario [N], subcaso [N] si aplica: [persona] — [qué conflicto tienen las fuentes] → [cuál queda oficial y por qué]."*

**Plantilla verbal (técnica, solo si preguntan):** *"HIJO absorbida → PADRE vigente en `unificacion_direccion`."*

### R2 Escenario 3 — sin NIT vs con NIT (leer antes del PASO 05)

**Cuándo aplica Escenario 3:** misma persona, misma puerta, **misma nomenclatura** de complemento (AP, LC, CS…) pero **distinto valor** (`105` vs `404`, `101` vs `205`). No es Esc 1 (vacío) ni Esc 2 (inclusión).

**Pregunta de negocio:** ¿elijo una dirección o las combino? → depende del **tipo de identificación**.

#### ¿Qué es NIT?

**NIT** = Número de Identificación Tributaria → en el demo, **`cod_tipo_ident_fte = 3`** en `relacion_persona_ubicacion`.

| Persona | `cod_tipo_ident_fte` | Tipo |
|---------|----------------------|------|
| **2003** | 1 (u otro ≠ 3) | Persona natural → **sin NIT** |
| **2004** | **3** | Empresa → **con NIT** |

#### Escenario 3 **sin NIT** (PASO 05 · persona 2003)

**Situación:** persona natural con `AP 105` vs `AP 404` en el mismo edificio.

**Lógica:** no puede quedar oficial que habita el 105 **y** el 404. **Se elige una** — no se fusionan.

**Criterio:** gana la que **más entidades (suscriptores) reportan** (`reporte_relacion_persona_ubica`). En el demo: **AP 404** (6 entidades) vs AP 105 (2).

**No usa** diccionario de complementos → **2003 no aparece** en consulta anclada B.

**Frase demo:**  
> *"Persona natural con dos apartamentos distintos: no los combinamos; gana el que más fuentes confirman."*

#### Escenario 3 **con NIT** (PASO 06–08 · persona 2004)

**Situación:** empresa con `LC 101` y `LC 205` en la misma sede.

**Lógica:** la empresa **puede ocupar ambos locales**. No se descarta uno → el **motor combina** y crea **`LC 101 LC 205`** (dirección enriquecida).

**Sí usa** diccionario (consulta anclada B, persona 2004) para descomponer tokens al armar la dirección.

**Frase demo:**  
> *"Empresa con NIT: dos locales en la misma dirección no compiten — se fusionan en una sola dirección oficial."*

#### Resumen comparativo

| | **Esc 3 sin NIT (2003)** | **Esc 3 con NIT (2004)** |
|--|--------------------------|---------------------------|
| **Quién** | Persona natural | Empresa |
| **Ejemplo** | AP 105 vs AP 404 | LC 101 vs LC 205 |
| **Pregunta** | ¿Cuál apartamento es correcto? | ¿Cómo reflejo **ambos** locales? |
| **Resultado** | **Elige una** (más entidades) | **Combina** (motor) |
| **Diccionario** | No | Sí (motor) |
| **Script** | `05_regla2_esc3_sin_nit.sql` | `07a` → `06` motor → `07b` |

---

## PASO 01 — Cargar datos

**Checklist:** - [ ] `01_demo_setup.sql` - [ ] Consultas OK

### Guía en vivo

| | |
|--|--|
| **Tipo** | Setup — sin reglas aún |
| **Qué hace** | Crea tablas y carga 19 personas / 38 direcciones |
| **Criterio** | Dataset demo listo para cascada |

**Qué significa:**  
Cargamos un escenario de prueba donde cada persona tiene **dos direcciones diseñadas** para activar Regla 1, 2 o 3. Nada se unifica todavía — solo preparamos el tablero.

**Antes de ejecutar:**  
> "Cargamos el escenario completo: personas con duplicados de dirección preparados para demostrar cómo R1, R2 y R3 resuelven cada tipo de conflicto."

**Al mostrar el SQL:**  
- ~37 filas visibles (1005 muestra 1: la RES ya viene absorbida de un proceso anterior)  
- Catálogos de tipos de uso y nomenclaturas de complemento  
- Señalar: *"Cada fila es una relación persona–dirección que las fuentes reportaron."*

**Anclar en DBeaver:** guarda las dos consultas de abajo como pestañas permanentes (**A** y **B**). Las usarás en casi todos los pasos.

### Ejecutar en DBeaver

`01_demo_setup.sql`

### CONSULTA ANCLADA A — Insumo vigente (`DEMO — Insumo vigente`)

**Qué es:** snapshot del **insumo** — relaciones persona–dirección que aún no fueron absorbidas (`ind_unificacion IS NULL`).

**Para qué sirve en la demo:** ver el **conflicto** antes de cada regla (misma persona, misma calle, distinto tipo de uso o complemento). Re-ejecutar después de cada paso para ver cómo cambia el universo vigente.

```sql
-- CONSULTA ANCLADA A — Insumo vigente
SELECT rpu.id_buro_persona AS persona,
  ubi.texto_ubicacion AS direccion,
  tud.descripcion_tipo_ubicacion_dir AS tipo_uso,
  df.complemento,
  ciiu.cod_act_econo_ciiu_fte AS ciiu
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona
WHERE rpu.ind_unificacion IS NULL
ORDER BY rpu.id_buro_persona, rpu.cod_dw_persona_ubic;
```

**Al mostrar — decir:** *"Este es nuestro tablero de juego: cada fila es una dirección que compite. A medida que corran R1, R2 y R3, algunas desaparecerán de aquí porque quedarán absorbidas."*

---

### CONSULTA ANCLADA B — Diccionario de complementos (`DEMO — Diccionario complementos`)

**Qué es:** el **historial agregado** de cómo las fuentes han reportado complementos por persona y ubicación. No son las direcciones del insumo — es la **memoria estadística** del buró.

**Columnas (importante — no hay columna `complemento`):**

| Columna | Significado |
|---------|-------------|
| `persona` | Persona dueña del historial |
| `cod_dw_ubic` | Ubicación a la que aplica |
| `nomenclatura` | Texto de referencia en el join (ej. `CS 5`, `TO 5`) |
| `sigla` (`nomen`) | Abreviatura: CS, PI, TO, LC, OF… |
| `valor` | Número del complemento |
| `frecuencia` | **Cuántas veces** se reportó esa nomenclatura+valor |

**Dónde entra en la lógica (por eso la anclamos desde el PASO 01):**

| Script | Uso del diccionario |
|--------|---------------------|
| `04_regla2_esc4.sql` | **Esc 4** — desempate Casa vs Piso (2005, 2010) |
| `08b_regla2_esc5_finaliza.sql` | **Esc 5 sub 2** — Torre vs Piso mismo valor (2008) |
| `09b_regla2_esc6_finaliza.sql` | **Esc 6 sub 3** — complementos cruzados (2009) |
| `06_motor_nuevas_direcciones.sql` | **Motor** — descompone complementos, ordena jerarquía y arma la dirección enriquecida (2004, 2006, 2007) |

**Personas del demo en esta tabla:** 2004, 2005, 2006, 2007, 2008, 2009, 2010.

**Personas que NO están (y por qué):**

| Persona | Escenario | Mecanismo | Por qué no hay filas en el diccionario |
|---------|-----------|-----------|----------------------------------------|
| **2001** | R2 Esc 1 | Regla directa | Vacío vs informado — no hace falta historial |
| **2002** | R2 Esc 2 | Regla directa | Inclusión — el más completo gana por lógica textual |
| **2003** | R2 Esc 3 **sin NIT** | **Mayor entidades** | Mismo AP, distinto número → gana quien tiene **más suscriptores reportando** (`reporte_relacion_persona_ubica`), no el diccionario |

Para **2003** la evidencia está en la **consulta anclada A** (complementos AP 105 vs AP 404) y en el conteo de entidades del PASO 05 — no en la anclada B.

```sql
-- CONSULTA ANCLADA B — Diccionario de complementos (historial R2 + motor)
SELECT
  id_buro_persona AS persona,
  cod_dw_ubic,
  nomenclatura,
  nomen AS sigla,
  valor,
  frecuencia
FROM bdm_stage.diccionario_complementos
-- WHERE id_buro_persona = 2005   ← descomentar para filtrar una persona
ORDER BY persona, frecuencia DESC;
```

**Al mostrar (vista completa, sin filtro) — decir:**  
> "Este diccionario es el árbitro cuando dos fuentes dicen lo mismo numéricamente pero con distinta nomenclatura, o cuando el motor necesita saber qué tokens componen un complemento y con qué peso histórico. Lo veremos en acción desde Regla 2 Escenario 4."

**Filtros rápidos por paso** (descomentar `WHERE` en la anclada B):

| Paso | Persona | Qué mirar |
|------|---------|-----------|
| 04 | 2005 | CS freq **10** > PI freq **4** → gana Casa |
| 04 | 2010 | CS **10** = PI **10** → empate, no unifica |
| 11 | 2008 | TO **15** > PI **6** → gana Torre |
| 14 | 2009 | LC **20** + OF **8** → gana LC 10 OF 200 |
| 07 / 10 / 13 | 2004 / 2006 / 2007 | tokens que el motor combina |

---

### Consultas de catálogo (opcional, una sola vez)

```sql
SELECT * FROM bdm_stage.tipo_ubicacion_dir;
SELECT * FROM bdm_stage.nomenclatura ORDER BY nivel_complemento, nomenclatura;
```

### Resultado esperado

- 19 personas · 38 registros en total · ~37 visibles con filtro NULL en **anclada A**  
- **Anclada B:** ~15 filas (7 personas con historial de complementos)  
- Tipos uso: RES, LAB, CRR, JUD, CCL  

**Si falla:** COUNT ≠ 38 en `relacion_persona_ubicacion` → re-ejecutar setup completo.

---

## PASO 02 — Regla 1: Tipo de uso + CIIU

**Checklist:** - [ ] `02_regla1_unificacion.sql` - [ ] Consultas OK

### Guía en vivo

| | |
|--|--|
| **Regla** | R1 — misma puerta, distinto **tipo de uso** |
| **Escenarios** | **Esc 1** (CIIU 10) · **Esc 2** (CIIU 81) · **Esc 3** (otro CIIU) · casos especiales |
| **Personas** | 1001 (Esc 1) · 1002 (Esc 2) · 1003 (Esc 3) · 1004 (empate) · 1005 (hija previa) |
| **Criterio clave** | R1-01, R1-02, R1-03 · empate R1-08 · hija previa R1-06 |

**Qué significa:**  
La misma persona tiene la **misma dirección física** registrada como residencia, laboral o correspondencia. Regla 1 responde: *¿cuál uso es el más relevante para contactarla?* según su actividad económica (CIIU) y cuántas entidades reportan cada una. No mira complementos (AP, LC, etc.).

**Antes de ejecutar:**  
> "Regla 1 resuelve duplicados donde la calle y puerta son iguales pero el tipo de uso difiere. Según el CIIU de la persona, el sistema prioriza residencia, laboral o correspondencia."

**Al mostrar resultados — narrar así:**

| Persona | Qué decir |
|---------|-----------|
| **1001** | *"Regla 1, Escenario 1: persona asalariada (CIIU 10). Dos fuentes reportan la misma puerta como residencia y laboral. Gana la laboral — es la más útil para contactar a un asalariado."* |
| **1002** | *"Regla 1, Escenario 2: persona sin actividad económica (CIIU 81). Gana la residencia sobre la laboral."* |
| **1003** | *"Regla 1, Escenario 3: otro CIIU, sin preferencia fija. Gana correspondencia porque más entidades la reportan."* |
| **1004** | *"Regla 1, Escenario 1: empate — laboral y correspondencia con el mismo peso. No forzamos decisión; ambas siguen vigentes."* |
| **1005** | *"Caso especial: la residencia ya venía absorbida de un proceso anterior. Regla 1 no la vuelve a tocar; solo queda vigente la correspondencia."* |

*(En pantalla: HIJO = redundante · PADRE = vigente)*  

### Ejecutar en DBeaver

`02_regla1_unificacion.sql`

### Consultas de resultado

```sql
SELECT cod_dw_persona_ubic AS hijo,
  cod_dw_direccion_unificada AS padre,
  unifica_atributos AS regla
FROM bdm_stage.unificacion_direccion
WHERE unifica_atributos = 1
ORDER BY hijo;
```

```sql
SELECT rpu.id_buro_persona AS persona,
  tud.descripcion_tipo_ubicacion_dir AS tipo_uso,
  ciiu.cod_act_econo_ciiu_fte AS ciiu,
  COUNT(DISTINCT rep.id_buro_suscriptor) AS entidades,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS resultado
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
LEFT JOIN bdm_stage.ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona
LEFT JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
WHERE rpu.id_buro_persona IN (1001, 1002, 1003, 1004, 1005)
GROUP BY 1,2,3,5
ORDER BY rpu.id_buro_persona, resultado;
```

### Resultado esperado

| Hijo | Padre | Persona | Resultado |
|------|-------|---------|-----------|
| 100 | 101 | 1001 | LAB gana (CIIU 10) |
| 200 | 201 | 1002 | RES gana (CIIU 81) |
| 300 | 301 | 1003 | CRR gana (más entidades) |

**No aparecen:** 1004 (empate) · 1005 sin par nuevo (hija previa).

**Después:** re-ejecutar **consulta anclada A** — deben desaparecer filas absorbidas de 1001–1003.

**Si falla:** más de 3 pares R1 o 1004 unificada.

---

## PASO 03 — Regla 2 Escenarios 1 y 2

**Checklist:** - [ ] `03_regla2_esc1_2.sql` - [ ] Consultas OK

### Guía en vivo

| | |
|--|--|
| **Regla** | R2 |
| **Escenario** | **Esc 1** (2001) · **Esc 2** (2002) |
| **Subcaso** | — (regla directa, sin motor ni diccionario) |
| **Criterio clave** | R2-01 · R2-02 |

**Qué significa:**  
Regla 2 entra cuando la **misma persona** tiene la **misma calle y puerta** dos veces, pero con **detalle distinto** en el complemento (apartamento, edificio, etc.). El sistema elige cuál dirección queda **oficial para contacto**; la otra queda como redundante en trazabilidad.

- **Escenario 1:** una fuente no trae complemento y otra sí → gana la **informada**.
- **Escenario 2:** un complemento está **contenido** en el otro → gana la **más completa**.

**Antes de ejecutar:**  
> "Regla 2 resuelve duplicados de la misma puerta con distinto detalle. Escenario 1: si una fuente no trae complemento y otra sí, gana la informada. Escenario 2: si un detalle está contenido en el otro, gana la dirección más completa."

**Al mostrar resultados — narrar así:**

| Persona | Qué decir |
|---------|-----------|
| **2001** | *"Regla 2, Escenario 1: dos fuentes reportan la misma calle y puerta. Una no trae apartamento; la otra sí dice AP 802. Nos quedamos con AP 802; la dirección vacía queda como redundante."* |
| **2002** | *"Regla 2, Escenario 2: una fuente solo dice AP 702; otra dice ED GALICIA AP 702. La segunda es más rica — incluye edificio y apartamento — así que esa queda como dirección oficial; AP 702 solo queda absorbida."* |

*(En pantalla: HIJO = redundante · PADRE = vigente · `apunta_a_padre` = trazabilidad)*

**Checkpoint opcional (2007 no debe tocarse aún):**  
`ind_unificacion` NULL en 1200 y 1201.

### Ejecutar en DBeaver

`03_regla2_esc1_2.sql`

### Consultas de resultado

```sql
-- Persona 2001 — Escenario 1
SELECT rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS estado,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona = 2001
ORDER BY estado, cod_rpu;
```

```sql
-- Persona 2002 — Escenario 2
SELECT rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS estado,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona = 2002
ORDER BY estado, cod_rpu;
```

### Resultado esperado

| Persona | Hijo | Padre | Complementos |
|---------|------|-------|--------------|
| 2001 | 600 | 601 | '' vs AP 802 |
| 2002 | 700 | 701 | AP 702 vs ED GALICIA AP 702 |

**Si falla:** vacío queda PADRE en 2001.

---

## PASO 04 — Regla 2 Escenario 4 (diccionario)

**Checklist:** - [ ] `04_regla2_esc4.sql` - [ ] Consultas OK

### Guía en vivo

| | |
|--|--|
| **Regla** | R2 |
| **Escenario** | **Esc 4** — diccionario de complementos |
| **Subcasos** | **Sub 1** (2005, gana diccionario) · **empate** (2010, R2-14) |
| **Datos** | CS = Casa · PI = Piso — mismo nivel (5), mismo número |
| **Criterio clave** | R2-05 · R2-14 (empate = no unifica) |

**Qué significa:**  
Dos fuentes reportan el mismo número pero con **distinta nomenclatura al mismo nivel** (Casa vs Piso, ambos nivel 5). No hay regla simple de inclusión — entra el **diccionario histórico**: gana la nomenclatura **más reportada** en el pasado. Si empatan, **no se fuerza decisión**.

**Antes de ejecutar:**  
> "Regla 2, Escenario 4: cuando dos fuentes dicen lo mismo numéricamente pero con distinta nomenclatura, consultamos el historial. Gana la más frecuente. Si empatan, dejamos ambas vigentes."

**Al mostrar resultados — narrar así:**

| Persona | Qué decir |
|---------|-----------|
| **2005** | *"Persona 2005: una fuente dice Casa 5, otra Piso 5. En el historial, Casa se reportó más veces — esa queda como dirección oficial."* |
| **2010** | *"Persona 2010: Casa 8 vs Piso 8 con la misma frecuencia histórica. Empate — no elegimos una sobre otra; ambas siguen vigentes."* |

*(En pantalla: HIJO/PADRE o ambas vigentes según el caso)*

**Antes del script — abrir consulta anclada B:** filtrar `id_buro_persona = 2005` y luego `= 2010` (ver tabla de filtros en PASO 01).

### Ejecutar en DBeaver

`04_regla2_esc4.sql`

### Consultas de resultado

```sql
SELECT rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS estado,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona = 2005
ORDER BY estado, cod_rpu;
```

```sql
SELECT rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  rpu.ind_unificacion,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona = 2010
ORDER BY cod_rpu;
```

### Resultado esperado

| Persona | Resultado |
|---------|-----------|
| 2005 | HIJO 1001 → PADRE 1000 (CS freq 10 > PI freq 4) |
| 2010 | Sin unificación (CS 8 vs PI 8, empate) |

**Si falla:** 2010 con HIJO/PADRE definido.

---

## PASO 05 — Regla 2 Escenario 3 sin NIT

**Checklist:** - [ ] `05_regla2_esc3_sin_nit.sql` - [ ] Consultas OK

> **Contexto completo:** ver sección *"R2 Escenario 3 — sin NIT vs con NIT"* (antes del PASO 01). Este paso es la rama **sin NIT**.

### Guía en vivo

| | |
|--|--|
| **Regla** | R2 |
| **Escenario** | **Esc 3** — misma nomenclatura, distinto valor |
| **Subcaso** | **Sin NIT** (persona natural, `cod_tipo_ident_fte` ≠ 3) |
| **Persona** | 2003 |
| **Datos** | `AP 105` vs `AP 404` |
| **Criterio clave** | R2-03 |

**Qué significa:**  
Persona **natural** (no empresa): dos fuentes reportan el mismo edificio con **distinto apartamento**. No se pueden combinar — hay que **elegir cuál queda oficial**. Gana la que **más suscriptores confirman**. **No consulta el diccionario** (2003 no está en anclada B).

**Antes de ejecutar:**  
> "Regla 2, Escenario 3 sin NIT: misma nomenclatura AP pero distinto número. Persona natural — elegimos una dirección, no las fusionamos. Gana la más respaldada por las fuentes."

**Antes del script — consulta anclada A:** localizar persona **2003** → ver conflicto `AP 105` vs `AP 404`.

**Al mostrar resultados — narrar así:**

| Persona | Qué decir |
|---------|-----------|
| **2003** | *"Persona 2003, persona natural: AP 105 vs AP 404. Seis entidades confirman el 404 contra dos del 105 — AP 404 queda oficial; AP 105 queda absorbida."* |

### Ejecutar en DBeaver

`05_regla2_esc3_sin_nit.sql`

### Consultas de resultado

```sql
-- Resultado unificación (estado vigente / absorbida)
SELECT rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS estado,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona = 2003
ORDER BY estado, cod_rpu;
```

```sql
-- Evidencia del criterio: conteo de entidades (por qué gana AP 404)
SELECT rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  COUNT(DISTINCT rep.id_buro_suscriptor) AS entidades,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'absorbida' ELSE 'vigente' END AS estado
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
WHERE rpu.id_buro_persona = 2003
GROUP BY 1, 2, 4
ORDER BY estado, cod_rpu;
```

**Al mostrar entidades — decir:** *"Aquí se ve el desempate: no es diccionario, son las fuentes que reportan cada apartamento."*

### Resultado esperado

| Persona | Hijo | Padre | Complementos |
|---------|------|-------|--------------|
| 2003 | 800 | 801 | AP 105 vs AP 404 (6 vs 2 entidades) |

**Si falla:** gana AP 105.

**Puente al siguiente paso:**  
> *"Acabamos el Esc 3 sin NIT. Ahora el mismo escenario pero **con NIT**: la empresa 2004 no elige un local — los combina con el motor (PASO 06–08)."*

---

## PASO 06 — R2 Esc 3 NIT (preparar motor)

**Checklist:** - [ ] `07a_regla2_esc3_nit_prepara.sql` - [ ] COUNT motor = 2

> **Contexto completo:** sección *"R2 Escenario 3 — sin NIT vs con NIT"*. Este paso es la rama **con NIT** (`cod_tipo_ident_fte = 3`).

### Guía en vivo (paso puente)

| | |
|--|--|
| **Regla** | R2 |
| **Escenario** | **Esc 3** con NIT |
| **Subcaso** | **Sub 1 — motor** (preparación) |
| **Persona** | 2004 (`LC 101` + `LC 205`) |
| **Validación** | `stg_motor_input` = **2 filas** |
| **Siguiente** | PASO 07 — motor |

**Qué significa:**  
Contraste con **2003 (sin NIT)**: aquí es **empresa** con dos locales en la misma sede. **No se elige uno** — se prepara el motor para **fusionar** LC 101 y LC 205 en una sola dirección enriquecida.

**Antes de ejecutar:**  
> "Regla 2, Escenario 3 con NIT: empresa con dos locales. A diferencia de la persona 2003, aquí sí combinamos — preparamos el motor."

**Consulta anclada B:** filtrar `id_buro_persona = 2004` — tokens LC 101 / LC 205 que el motor usará.

*(Validación técnica: `stg_motor_input` = 2 filas)*

### Ejecutar en DBeaver

`07a_regla2_esc3_nit_prepara.sql`

### Consultas de resultado

```sql
SELECT COUNT(*) AS filas_motor_input FROM bdm_stage.stg_motor_input;
```

### Resultado esperado

- **2** filas · persona **2004**

**Si falla:** 0 filas → revisar que PASO 05 corrió y 2004 no está unificada.

---

## PASO 07 — Motor NIT (persona 2004)

**Checklist:** - [ ] `06_motor_nuevas_direcciones.sql` - [ ] Consultas OK - [ ] **NO** saltar PASO 08

### Guía en vivo

| | |
|--|--|
| **Regla** | R2 |
| **Escenario** | **Esc 3** con NIT |
| **Subcaso** | **Sub 1 — motor** (1.ª ejecución) |
| **Persona** | 2004 |
| **Criterio clave** | R2-04 · R2-08 · R2-12 |

**Qué significa:**  
El **motor** ejecuta la rama **con NIT** del Escenario 3: genera **`LC 101 LC 205`** como dirección oficial. Las dos fuentes quedan absorbidas; la nueva queda marcada como enriquecida. Contraste con 2003: allí **eligió una**; aquí **fusionó ambas**.

**Antes de ejecutar:**  
> "El motor combina los dos locales en una sola dirección enriquecida — caso empresa NIT. Las fuentes originales quedan en trazabilidad."

**Opcional — consulta anclada B:** filtrar `id_buro_persona = 2004` para mostrar tokens LC 101 / LC 205 que el motor usa para armar la dirección.

**Al mostrar resultados — narrar así:**

| Persona | Qué decir |
|---------|-----------|
| **2004** | *"Persona 2004: el motor creó LC 101 LC 205 como dirección oficial. Las dos fuentes originales quedaron absorbidas pero registradas. Es la primera dirección enriquecida del demo."* |

*(En pantalla: `generada_enriquecida = 1` = dirección creada por el motor)*

### Ejecutar en DBeaver

`06_motor_nuevas_direcciones.sql`

### Consultas de resultado

```sql
SELECT rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  df.generada_enriquecida,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS estado,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona = 2004
ORDER BY estado, cod_rpu;
```

```sql
SELECT cod_dw_direccion_fisica, complemento, generada_enriquecida
FROM bdm_stage.direccion_fisica
WHERE generada_enriquecida = 1
ORDER BY cod_dw_direccion_fisica;
```

```sql
SELECT rpu.id_buro_persona,
  df.complemento AS generado,
  (SELECT LISTAGG(df2.complemento, ' | ') WITHIN GROUP (ORDER BY rpu2.cod_dw_persona_ubic)
   FROM bdm_stage.relacion_persona_ubicacion rpu2
   JOIN bdm_stage.direccion_fisica df2 ON rpu2.cod_dw_direccion_fisica = df2.cod_dw_direccion_fisica
   WHERE rpu2.id_buro_persona = rpu.id_buro_persona AND rpu2.ind_unificacion = 1) AS fuentes_hijo
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.id_buro_persona = 2004 AND df.generada_enriquecida = 1;
```

### Resultado esperado

| Persona | Detalle |
|---------|---------|
| 2004 | PADRE nuevo `LC 101 LC 205` · HIJO 900, 901 |
| Global | 1 fila `generada_enriquecida = 1` |

**Si falla:** HIJO sin `apunta_a_padre` → no ejecutar 08b/09a hasta corregir.

---

## PASO 08 — R2 Esc 3 NIT (cerrar)

**Checklist:** - [ ] `07b_regla2_esc3_nit_finaliza.sql`

### Guía en vivo (paso técnico)

| | |
|--|--|
| **Regla** | R2 |
| **Escenario** | **Esc 3** con NIT |
| **Subcaso** | **Sub 1 — motor** (cierre técnico) |
| **Qué hace** | Sincroniza `stg_regla2_e2` · limpia staging NIT |
| **Validación** | Script sin error · 2004 igual que PASO 07 |
| **Criterio** | R2-10 · R2-11 |

**Qué significa:**  
Paso de **cierre interno** del Escenario 3 NIT: sincroniza tablas de trabajo y limpia staging. **No cambia el resultado de negocio** que ya vimos en el PASO 07.

**Antes de ejecutar:**  
> "Paso técnico de cierre — la decisión de negocio ya la vimos: LC 101 LC 205 quedó como dirección oficial."

### Ejecutar en DBeaver

`07b_regla2_esc3_nit_finaliza.sql`

### Consultas de resultado

*(Opcional — repetir consulta 2004 del PASO 07; debe ser idéntica.)*

### Resultado esperado

- Sin cambios visibles en tablas finales vs PASO 07.

---

## PASO 09 — R2 Esc 5 (preparar motor)

**Checklist:** - [ ] `08a_regla2_esc5_prepara.sql` - [ ] COUNT motor = 2

### Guía en vivo (paso puente)

| | |
|--|--|
| **Regla** | R2 |
| **Escenario** | **Esc 5** — distinto nivel, distinto valor |
| **Subcaso** | **Sub 1 — motor** (preparación) |
| **Persona** | 2006 (`TO 3` nivel 4 + `AP 504` nivel 7) |
| **Validación** | `stg_motor_input` = **2** |
| **Nota** | 2008 (Esc 5 subcaso 2, diccionario) se cierra en PASO 11 |

**Qué significa:**  
Una fuente reporta **Torre 3** y otra **Apartamento 504** — son complementos de **distinto nivel** que no se contienen entre sí. Hay que **combinarlos** en una sola dirección (TO 3 AP 504).

**Antes de ejecutar:**  
> "Regla 2, Escenario 5 subcaso 1: torre y apartamento son detalles de distinto nivel que conviven — preparamos el motor para unirlos."

*(Validación técnica: `stg_motor_input` = 2 filas)*

### Ejecutar en DBeaver

`08a_regla2_esc5_prepara.sql`

### Consultas de resultado

```sql
SELECT COUNT(*) AS filas_motor_input FROM bdm_stage.stg_motor_input;
```

### Resultado esperado

- **2** filas · persona **2006**

---

## PASO 10 — Motor Esc 5 (persona 2006)

**Checklist:** - [ ] `06_motor_nuevas_direcciones.sql` - [ ] Consultas OK

### Guía en vivo

| | |
|--|--|
| **Regla** | R2 |
| **Escenario** | **Esc 5** |
| **Subcaso** | **Sub 1 — motor** (2.ª ejecución) |
| **Persona** | 2006 |
| **Criterio clave** | R2-06 · R2-12 |

**Qué significa:**  
El motor **arma TO 3 AP 504**: una dirección que refleja torre y apartamento juntos. Ninguna fuente se descarta sola — ambas alimentan la dirección enriquecida.

**Antes de ejecutar:**  
> "El motor genera la dirección completa: Torre 3 Apartamento 504. Ya tenemos dos direcciones enriquecidas en el demo (2004 y 2006)."

**Al mostrar resultados — narrar así:**

| Persona | Qué decir |
|---------|-----------|
| **2006** | *"Persona 2006: una fuente traía solo Torre 3, otra solo AP 504. El motor creó TO 3 AP 504 — la dirección más útil para contacto."* |

### Ejecutar en DBeaver

`06_motor_nuevas_direcciones.sql`

### Consultas de resultado

```sql
SELECT rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  df.generada_enriquecida,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS estado,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona = 2006
ORDER BY estado, cod_rpu;
```

```sql
SELECT cod_dw_direccion_fisica, complemento, generada_enriquecida
FROM bdm_stage.direccion_fisica
WHERE generada_enriquecida = 1
ORDER BY cod_dw_direccion_fisica;
```

### Resultado esperado

| Persona | Detalle |
|---------|---------|
| 2006 | PADRE `TO 3 AP 504` · HIJO 1100, 1101 |
| Global | 2 filas generada_enriquecida |

**Si falla:** solo 1 fila global → motor incompleto.

---

## PASO 11 — R2 Esc 5 (cerrar)

**Checklist:** - [ ] `08b_regla2_esc5_finaliza.sql` - [ ] Consulta 2006+2008 OK

### Guía en vivo

| | |
|--|--|
| **Regla** | R2 |
| **Escenario** | **Esc 5** |
| **Subcasos** | **Sub 1** cierre motor (2006) · **Sub 2** diccionario (2008) |
| **Personas** | 2006 (sin cambio) · 2008 (`TO 5` vs `PI 5`) |
| **Criterio clave** | R2-06 · R2-13 |

**Qué significa:**  
- **2006:** el motor del paso anterior **no cambia** — TO 3 AP 504 sigue vigente.  
- **2008 (subcaso 2):** dos fuentes dicen el **mismo número 5** pero una en Torre y otra en Piso. Entra el diccionario: gana **Torre** porque históricamente se reportó más.

**Antes de ejecutar:**  
> "Cerramos Escenario 5. El motor de 2006 queda intacto. En 2008, Torre 5 gana a Piso 5 porque el historial favorece Torre."

**Antes del script — consulta anclada B:** filtrar `id_buro_persona = 2008` (TO **15** vs PI **6**).

**Al mostrar resultados — narrar así:**

| Persona | Qué decir |
|---------|-----------|
| **2006** | *"2006 sin cambios — TO 3 AP 504 sigue como dirección oficial del motor."* |
| **2008** | *"2008: Torre 5 gana a Piso 5 — misma cifra, distinta nomenclatura; el historial desempata."* |  

### Ejecutar en DBeaver

`08b_regla2_esc5_finaliza.sql`

### Consultas de resultado

**Consulta principal** — validar **ambos subcasos** del Escenario 5 en una sola pantalla:

```sql
SELECT rpu.id_buro_persona AS persona,
  rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS estado,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona IN (2006, 2008)
ORDER BY rpu.id_buro_persona, estado, cod_rpu;
```

**Al mostrar fila a fila (como tu captura):**

| persona | complemento | estado | Qué decir |
|---------|---------------|--------|-----------|
| 2006 | TO 3 | HIJO → 1603 | *"Subcaso 1 motor: fuente original absorbida."* |
| 2006 | AP 504 | HIJO → 1603 | *"Subcaso 1 motor: segunda fuente absorbida."* |
| 2006 | TO 3 AP 504 | PADRE | *"Subcaso 1: dirección enriquecida vigente — sin cambios vs PASO 10."* |
| 2008 | PI 5 | HIJO → 1202 | *"Subcaso 2 diccionario: Piso 5 absorbido."* |
| 2008 | TO 5 | PADRE | *"Subcaso 2: Torre 5 oficial — historial TO 15 > PI 6."* |

**Consulta de cierre 1** — par R2 nuevo de 2008 en trazabilidad:

```sql
SELECT cod_dw_persona_ubic AS hijo,
  cod_dw_direccion_unificada AS padre,
  unifica_atributos AS regla
FROM bdm_stage.unificacion_direccion
WHERE cod_dw_persona_ubic IN (1203, 1202)
   OR cod_dw_direccion_unificada IN (1202, 1203);
```

**Esperado:** hijo **1203** → padre **1202** · `unifica_atributos = 2`.

**Consulta de cierre 2** — direcciones enriquecidas acumuladas (sin cambio vs PASO 10):

```sql
SELECT cod_dw_direccion_fisica, complemento, generada_enriquecida
FROM bdm_stage.direccion_fisica
WHERE generada_enriquecida = 1
ORDER BY cod_dw_direccion_fisica;
```

**Esperado:** **2** filas (2004 + 2006). La tercera (2007) llega en PASO 13.

**Opcional — re-ejecutar consulta anclada A:** 2008 ya no debe mostrar dos filas vigentes con distinto complemento; 2006 solo vigente el PADRE enriquecido (~1603).

### Resultado esperado

| Persona | Resultado |
|---------|-----------|
| 2006 | Motor intacto · HIJO 1100, 1101 → PADRE ~1603 `TO 3 AP 504` |
| 2008 | HIJO 1203 (`PI 5`) → PADRE 1202 (`TO 5`) |

**Si falla:** PI padre en 2008 → revisar fechas/frecuencias en setup · consulta anclada B persona 2008.

**PASO 11 completado → siguiente:** **PASO 12** (`09a_regla2_esc6_prepara.sql`) — Escenario 6 subcaso 1, persona **2007**. El Esc 5 ya cerró motor + diccionario; no hay más scripts 08x pendientes.

---

## PASO 12 — R2 Esc 6 (preparar motor)

**Checklist:** - [ ] `09a_regla2_esc6_prepara.sql` - [ ] COUNT motor = 2

### Guía en vivo (paso puente)

| | |
|--|--|
| **Regla** | R2 |
| **Escenario** | **Esc 6** — complementos cruzados |
| **Subcaso** | **Sub 1 — motor** (preparación) |
| **Persona** | 2007 (`ED 2 OF 301` + `OF 302` — cruzadas, no Esc 2) |
| **Validación** | `stg_motor_input` = **2** |
| **Nota** | 2009 (Esc 6 subcaso 3, diccionario) se cierra en PASO 14 |

**Qué significa:**  
Dos complementos **cruzados** que no encajan en Escenario 2 (ninguno contiene al otro): `ED 2 OF 301` y `OF 302`. El motor debe **fusionarlos** sin repetir información.

**Antes de ejecutar:**  
> "Regla 2, Escenario 6 subcaso 1: edificio+oficina por un lado, otra oficina por otro — complementos cruzados que solo el motor puede unir."

*(Validación técnica: `stg_motor_input` = 2 filas)*

### Ejecutar en DBeaver

`09a_regla2_esc6_prepara.sql`

### Consultas de resultado

```sql
SELECT COUNT(*) AS filas_motor_input FROM bdm_stage.stg_motor_input;
```

### Resultado esperado

- **2** filas · persona **2007**

---

## PASO 13 — Motor Esc 6 (persona 2007)

**Checklist:** - [ ] `06_motor_nuevas_direcciones.sql` - [ ] **3** generada_enriquecida - [ ] **NO** ejecutar 09b si falla

### Guía en vivo

| | |
|--|--|
| **Regla** | R2 |
| **Escenario** | **Esc 6** |
| **Subcaso** | **Sub 1 — motor** (3.ª ejecución) |
| **Persona** | 2007 |
| **Criterio clave** | R2-07 · R2-12 |

**Qué significa:**  
El motor produce `ED 2 OF 301 OF 302`: une el edificio con ambas oficinas **sin duplicar** OF 301. Es la **tercera** dirección enriquecida del demo.

**Antes de ejecutar:**  
> "El motor fusiona los complementos cruzados en una sola dirección oficial. Si falla aquí, hay que parar y corregir antes de seguir."

**Al mostrar resultados — narrar así:**

| Persona | Qué decir |
|---------|-----------|
| **2007** | *"Persona 2007: ED 2 OF 301 por un lado, OF 302 por otro. El motor creó ED 2 OF 301 OF 302 — dirección completa sin repetir la oficina 301."* |

*(En pantalla: deben verse **3** filas `generada_enriquecida` — 2004, 2006, 2007)*

### Ejecutar en DBeaver

`06_motor_nuevas_direcciones.sql`

### Consultas de resultado

```sql
SELECT rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  df.generada_enriquecida,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS estado,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona = 2007
ORDER BY estado, cod_rpu;
```

```sql
SELECT cod_dw_direccion_fisica, complemento, generada_enriquecida
FROM bdm_stage.direccion_fisica
WHERE generada_enriquecida = 1
ORDER BY cod_dw_direccion_fisica;
```

```sql
SELECT df.complemento AS generado
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.id_buro_persona = 2007 AND df.generada_enriquecida = 1;
```

### Resultado esperado

| Persona | Detalle |
|---------|---------|
| 2007 | PADRE `ED 2 OF 301 OF 302` · HIJO 1200, 1201 |
| Global | **3** filas generada_enriquecida |

**Si falla:** ambos HIJO sin padre · solo 2 global → **parar** · revisar diccionario 2007 en setup.

---

## PASO 14 — R2 Esc 6 (cerrar)

**Checklist:** - [ ] `09b_regla2_esc6_finaliza.sql` - [ ] Resumen R2 OK

### Guía en vivo

| | |
|--|--|
| **Regla** | R2 |
| **Escenario** | **Esc 6** |
| **Subcasos** | **Sub 1** cierre motor (2007) · **Sub 3** diccionario (2009) |
| **Personas** | 2007 · 2009 · resumen 2001–2009 |
| **Criterio clave** | R2-07 · R2-14 (2010 ausente) |

**Qué significa:**  
Cierre de Regla 2. **2009 (subcaso 3):** complementos cruzados al mismo nivel — gana **LC 10 OF 200** sobre **OF 200** por diccionario. **2010** sigue en empate (Esc 4) — no aparece en los pares R2.

**Antes de ejecutar:**  
> "Cerramos Regla 2. En 2009, Local 10 Oficina 200 gana a solo Oficina 200. El empate de 2010 sigue sin resolver — eso es correcto."

**Antes del script — consulta anclada B:** filtrar `id_buro_persona = 2009`.

**Al mostrar resultados — narrar así:**

| Qué señalar | Qué decir |
|-------------|-----------|
| **Resumen R2** | *"Unificamos personas 2001 a 2009. 2010 no aparece — empate persistente."* |
| **2009** | *"Escenario 6 subcaso 3: LC 10 OF 200 queda oficial; OF 200 queda absorbida."* |
| **Motor global** | *"Tres direcciones enriquecidas en total: 2004, 2006 y 2007."* |

### Ejecutar en DBeaver

`09b_regla2_esc6_finaliza.sql`

### Consultas de resultado

```sql
SELECT ud.cod_dw_persona_ubic AS hijo,
  ud.cod_dw_direccion_unificada AS padre,
  rpu.id_buro_persona AS persona
FROM bdm_stage.unificacion_direccion ud
JOIN bdm_stage.relacion_persona_ubicacion rpu
  ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE ud.unifica_atributos = 2
ORDER BY persona, hijo;
```

```sql
SELECT rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS estado,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona IN (2007, 2009)
ORDER BY rpu.id_buro_persona, estado, cod_rpu;
```

```sql
SELECT cod_dw_direccion_fisica, complemento, generada_enriquecida
FROM bdm_stage.direccion_fisica
WHERE generada_enriquecida = 1
ORDER BY cod_dw_direccion_fisica;
```

### Resultado esperado

- Pares R2 para **2001–2009** · **2010** ausente  
- **2009:** LC 10 OF 200 padre · OF 200 hijo  
- **3** direcciones motor  

**Si falla:** 2010 en lista de pares R2.

---

## PASO 15 — Regla 3: Geolocalización

**Checklist:** - [ ] `10_regla3_geo.sql` - [ ] Consultas OK

### Guía en vivo

| | |
|--|--|
| **Regla** | R3 — casi misma dirección, dif vía gen o puerta ±2 |
| **Escenarios** | **Esc 1** (≠ vía gen) · **Esc 2** (≠ puerta) |
| **Subcasos** | Esc 1 **Sub 1** geo (3001) · Esc 2 **Sub 2** fecha (3002) · Esc 1 **Sub 3** dicc. vía (3003) · Esc 2 fuera umbral (3004) |
| **Criterio clave** | R3-02 · R3-03 · R3-04 · R3-06 |

**Qué significa:**  
Regla 3 procesa direcciones **casi iguales** que R1 y R2 no absorbieron: variaciones leves en vía generadora o número de puerta (±2). Responde: *¿cuál variante es más confiable para ubicar a la persona?*

- **Esc 1 sub 1:** solo una tiene coordenadas → gana la **geolocalizada**.
- **Esc 2 sub 2:** ninguna tiene geo → gana la **más reciente**.
- **Esc 1 sub 3:** ambas con geo → gana la **vía más reportada** en historial.
- **Esc 2 fuera umbral:** diferencia de puerta > 2 → **no unifica** (son direcciones distintas).

**Antes de ejecutar:**  
> "Regla 3 cierra la cascada con variaciones leves de calle. Priorizamos geolocalización, luego fecha, luego historial de vía. Si la diferencia es grande, no unificamos."

**Al mostrar resultados — narrar así:**

| Persona | Qué decir |
|---------|-----------|
| **3001** | *"Regla 3, Escenario 1 subcaso 1: una fuente tiene coordenadas GPS, la otra no. Gana la geolocalizada — es más precisa para ubicar."* |
| **3002** | *"Regla 3, Escenario 2 subcaso 2: ninguna tiene geo. Gana la dirección con fecha de reporte más reciente."* |
| **3003** | *"Regla 3, Escenario 1 subcaso 3: ambas tienen geo pero difieren en vía generadora. Gana la vía más reportada históricamente."* |
| **3004** | *"Regla 3, Escenario 2 fuera de umbral: la puerta difiere en 5 — demasiado lejos para considerarlas la misma dirección. No unificamos."* |

*(Setup 3003: 1500 tiene más filas en `reporte_relacion_persona_ubica` que 1501 → el diccionario runtime desempata sin caso borde.)*

**Anclar en DBeaver (PASO 15):** guarda la **consulta R3 completa** de abajo como pestaña `DEMO — Regla 3 detalle`.

### Ejecutar en DBeaver

`10_regla3_geo.sql`

### CONSULTA R3 COMPLETA — todas las variables (`DEMO — Regla 3 detalle`)

Ejecutar **después** de `10_regla3_geo.sql`. Trae en una sola pantalla: escenario, subcaso, geo, fechas, entidades, diccionario de vía, diferencia de puerta y resultado de unificación.

```sql
-- CONSULTA R3 COMPLETA — personas 3001-3004
WITH base AS (
  SELECT
    rpu.id_buro_persona AS persona,
    rpu.cod_dw_persona_ubic AS cod_rpu,
    ubi.texto_ubicacion AS direccion,
    df.tipo_via_principal,
    df.via_principal,
    df.via_generadora,
    df.numero_puerta,
    ubi.latitud,
    ubi.longitud,
    CASE
      WHEN NULLIF(ubi.latitud, 0) IS NOT NULL AND NULLIF(ubi.longitud, 0) IS NOT NULL
      THEN 'SI' ELSE 'NO'
    END AS tiene_geo,
    rpu.fecha_relacion_persona_ubicaci AS fecha_relacion,
    COALESCE(MAX(rep.fecha_reporte), DATE '1900-01-01') AS fecha_ultimo_reporte,
    COUNT(DISTINCT rep.id_buro_suscriptor) AS entidades,
    TRIM(df.tipo_via_principal) || ' ' || TRIM(df.via_principal) || ' ' || TRIM(CAST(df.numero_puerta AS VARCHAR)) AS llave_dicc_via_gen
  FROM bdm_stage.relacion_persona_ubicacion rpu
  JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
  JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
  LEFT JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
  WHERE rpu.id_buro_persona IN (3001, 3002, 3003, 3004)
  GROUP BY
    rpu.id_buro_persona,
    rpu.cod_dw_persona_ubic,
    ubi.texto_ubicacion,
    df.tipo_via_principal,
    df.via_principal,
    df.via_generadora,
    df.numero_puerta,
    ubi.latitud,
    ubi.longitud,
    rpu.fecha_relacion_persona_ubicaci,
    TRIM(df.tipo_via_principal) || ' ' || TRIM(df.via_principal) || ' ' || TRIM(CAST(df.numero_puerta AS VARCHAR))
),
conflicto AS (
  SELECT
    a.persona,
    CASE
      WHEN a.via_generadora <> b.via_generadora AND a.numero_puerta = b.numero_puerta
        THEN 'Esc 1 — dif vía generadora'
      WHEN a.via_generadora = b.via_generadora AND a.numero_puerta <> b.numero_puerta
        THEN 'Esc 2 — dif puerta'
      ELSE 'Otro'
    END AS escenario_r3,
    ABS(CAST(a.numero_puerta AS INTEGER) - CAST(b.numero_puerta AS INTEGER)) AS dif_puerta,
    (CASE WHEN a.tiene_geo = 'SI' THEN 1 ELSE 0 END
     + CASE WHEN b.tiene_geo = 'SI' THEN 1 ELSE 0 END) AS direcciones_con_geo
  FROM base a
  JOIN base b ON a.persona = b.persona AND a.cod_rpu < b.cod_rpu
),
subcaso AS (
  SELECT
    persona,
    escenario_r3,
    dif_puerta,
    CASE
      WHEN escenario_r3 LIKE 'Esc 1%' AND direcciones_con_geo = 1 THEN 'Sub 1 — geo gana'
      WHEN escenario_r3 LIKE 'Esc 1%' AND direcciones_con_geo = 2 THEN 'Sub 3 — diccionario vía'
      WHEN escenario_r3 LIKE 'Esc 2%' AND dif_puerta = 2 THEN 'Sub 2 — fecha gana'
      WHEN escenario_r3 LIKE 'Esc 2%' AND dif_puerta > 2 THEN 'Fuera umbral — no unifica'
      ELSE '—'
    END AS subcaso_r3,
    CASE
      WHEN escenario_r3 LIKE 'Esc 2%' AND dif_puerta = 2 THEN 'DENTRO ±2'
      WHEN escenario_r3 LIKE 'Esc 2%' AND dif_puerta > 2 THEN 'FUERA ±2'
      ELSE 'N/A'
    END AS umbral_puerta
  FROM conflicto
)
SELECT
  b.persona,
  b.cod_rpu,
  b.direccion,
  s.escenario_r3,
  s.subcaso_r3,
  s.umbral_puerta,
  s.dif_puerta,
  b.via_generadora,
  b.numero_puerta,
  b.tiene_geo,
  b.latitud,
  b.longitud,
  b.fecha_relacion,
  b.fecha_ultimo_reporte,
  b.entidades,
  dv.conteo AS freq_via_generadora,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS resultado,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM base b
JOIN subcaso s ON b.persona = s.persona
LEFT JOIN bdm_stage.diccionario_via dv
  ON dv.tipo = 'Via_Generadora'
 AND dv.llave = b.llave_dicc_via_gen
 AND TRIM(dv.via_generadora) = TRIM(b.via_generadora)
LEFT JOIN bdm_stage.relacion_persona_ubicacion rpu ON rpu.cod_dw_persona_ubic = b.cod_rpu
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = b.cod_rpu
ORDER BY b.persona, b.cod_rpu;
```

**Columnas clave — qué mirar en demo:**

| Columna | Para qué |
|---------|----------|
| `escenario_r3` | Esc 1 (dif. vía gen) vs Esc 2 (dif. puerta) |
| `subcaso_r3` | geo / fecha / diccionario vía / fuera umbral |
| `tiene_geo` | Sub 1 y Sub 3 dependen de esto |
| `fecha_ultimo_reporte` | Desempate Sub 2 (3002) |
| `freq_via_generadora` | Desempate Sub 3 (3003) — mayor freq gana |
| `dif_puerta` / `umbral_puerta` | 3002 dif=2 OK · 3004 dif=5 FUERA |
| `resultado` / `apunta_a_padre` | Vigente vs absorbida |

**Guía fila a fila (esperado):**

| persona | cod_rpu | subcaso | Señalar |
|---------|---------|---------|---------|
| **3001** | 1300 | Sub 1 geo | `tiene_geo=SI`, lat/long informados → PADRE |
| **3001** | 1301 | Sub 1 geo | `tiene_geo=NO` → HIJO → 1300 |
| **3002** | 1400 | Sub 2 fecha | `fecha_ultimo_reporte` **2025-03-01** → HIJO |
| **3002** | 1401 | Sub 2 fecha | `fecha_ultimo_reporte` **2025-08-01** → PADRE |
| **3003** | 1500 | Sub 3 dicc. | `freq_via_generadora` **8** (vía gen 20) → **PADRE** |
| **3003** | 1501 | Sub 3 dicc. | `freq_via_generadora` **3** (vía gen 22) → **HIJO → 1500** |
| **3004** | 1600, 1601 | Fuera umbral | `dif_puerta=5`, ambos **PADRE**, sin `apunta_a_padre` |

**Consulta resumen — pares R3 en trazabilidad:**

```sql
SELECT ud.cod_dw_persona_ubic AS hijo,
  ud.cod_dw_direccion_unificada AS padre,
  ud.unifica_atributos AS regla,
  rpu.id_buro_persona AS persona
FROM bdm_stage.unificacion_direccion ud
JOIN bdm_stage.relacion_persona_ubicacion rpu ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona IN (3001, 3002, 3003, 3004)
ORDER BY persona, hijo;
```

*(Nota: si `regla` no es 3, el script insertó otro código — el par hijo→padre es lo importante.)*

### Resultado esperado

| Persona | Resultado |
|---------|-----------|
| 3001 | 1301 → 1300 (geo gana) |
| 3002 | 1400 → 1401 (fecha gana) |
| 3003 | 1501 → 1500 (diccionario vía: gen 20 gana) |
| 3004 | **Sin** unificación |

**Si falla:** 3004 con HIJO/PADRE.

---

## PASO 16 — Resumen final

**Checklist:** - [ ] Consultas resumen OK

### Guía en vivo

| | |
|--|--|
| **Objetivo** | Cerrar cascada · vigentes vs absorbidas · ordenamiento |
| **Criterio clave** | G-01 · G-09 · G-10 |

**Qué significa:**  
Panorama final: cuántos duplicados resolvió cada regla, cuántas direcciones quedaron **absorbidas** vs **vigentes**, y cuáles son las que **realmente pasarían a ordenamiento** para decidir cómo contactar a cada persona.

**Antes de narrar:**  
> "Toda decisión quedó registrada en trazabilidad. Solo las direcciones vigentes — las que no fueron absorbidas — siguen al ordenamiento. Las redundantes no se borran, pero ya no compiten."

**Al mostrar resultados — narrar así:**

| Consulta | Qué decir |
|----------|-----------|
| **Por regla** | *"Regla 1 resolvió X pares por tipo de uso, Regla 2 por complementos, Regla 3 por variaciones de vía."* |
| **Vigentes vs absorbidas** | *"Las absorbidas son historial; las vigentes son las que el sistema usaría."* |
| **Lista final vigentes** | *"Esta es la lista que entraría a ordenamiento — una dirección oficial por cada caso resuelto."* |

### Ejecutar en DBeaver

*(Sin script — solo consultas)*

### Consultas de resultado

```sql
SELECT unifica_atributos AS regla, COUNT(*) AS pares
FROM bdm_stage.unificacion_direccion
GROUP BY 1 ORDER BY 1;
```

```sql
SELECT
  CASE WHEN ind_unificacion = 1 THEN 'ABSORBIDA (hijo)' ELSE 'VIGENTE (padre/independiente)' END AS estado,
  COUNT(*) AS cantidad
FROM bdm_stage.relacion_persona_ubicacion
GROUP BY 1;
```

```sql
SELECT cod_dw_persona_ubic AS hijo,
  cod_dw_direccion_unificada AS padre,
  unifica_atributos AS regla
FROM bdm_stage.unificacion_direccion
ORDER BY regla, hijo;
```

```sql
SELECT rpu.id_buro_persona AS persona,
  ubi.texto_ubicacion AS direccion,
  df.complemento,
  tud.descripcion_tipo_ubicacion_dir AS tipo_uso
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
WHERE rpu.ind_unificacion IS NULL
ORDER BY rpu.id_buro_persona;
```

### Resultado esperado

| Métrica | Orientativo |
|---------|-------------|
| Pares R1 | 3 |
| Pares R2 | ~12 |
| Pares R3 | 3 |
| Motor | 3 direcciones |
| Sin unificar | 2010 · 3004 |

---

## PASO 17 — Limpieza

**Checklist:** - [ ] `03_demo_cleanup.sql`

### Guía en vivo

**Qué significa:**  
Limpieza del entorno demo — borra tablas de prueba sin afectar el esquema productivo.

**Antes de ejecutar:**  
> "Borramos los datos del demo. El esquema bdm_stage permanece intacto para la próxima ejecución."

### Ejecutar en DBeaver

`03_demo_cleanup.sql`

### Resultado esperado

- Script sin error · esquema `bdm_stage` conservado.

---

## Orden de scripts

| Paso | Script | Escenario · subcaso |
|------|--------|---------------------|
| 01 | `01_demo_setup.sql` | Setup |
| 02 | `02_regla1_unificacion.sql` | R1 Esc 1 · 2 · 3 |
| 03 | `03_regla2_esc1_2.sql` | R2 Esc 1 · Esc 2 |
| 04 | `04_regla2_esc4.sql` | R2 Esc 4 |
| 05 | `05_regla2_esc3_sin_nit.sql` | R2 Esc 3 sin NIT |
| 06 | `07a_regla2_esc3_nit_prepara.sql` | R2 Esc 3 · Sub 1 motor (prep.) |
| 07 | `06_motor_nuevas_direcciones.sql` | R2 Esc 3 · Sub 1 motor |
| 08 | `07b_regla2_esc3_nit_finaliza.sql` | R2 Esc 3 · Sub 1 motor (cierre) |
| 09 | `08a_regla2_esc5_prepara.sql` | R2 Esc 5 · Sub 1 motor (prep.) |
| 10 | `06_motor_nuevas_direcciones.sql` | R2 Esc 5 · Sub 1 motor |
| 11 | `08b_regla2_esc5_finaliza.sql` | R2 Esc 5 · Sub 1 + Sub 2 |
| 12 | `09a_regla2_esc6_prepara.sql` | R2 Esc 6 · Sub 1 motor (prep.) |
| 13 | `06_motor_nuevas_direcciones.sql` | R2 Esc 6 · Sub 1 motor |
| 14 | `09b_regla2_esc6_finaliza.sql` | R2 Esc 6 · Sub 1 + Sub 3 |
| 15 | `10_regla3_geo.sql` | R3 Esc 1/2 · Sub 1/2/3 |
| 17 | `03_demo_cleanup.sql` | Limpieza |

---

## Anexo A — Matriz completa de criterios

### Regla 1

| ID | Escenario | Persona | Criterio |
|----|-----------|---------|----------|
| R1-01 | Esc 1 (CIIU 10) | 1001 | CIIU=10 → LAB gana |
| R1-02 | Esc 2 (CIIU 81) | 1002 | CIIU=81 → RES gana |
| R1-03 | Esc 3 (otro CIIU) | 1003 | Otro CIIU → mayor entidades |
| R1-04 | * | * | Hijos con ind_unificacion=1 |
| R1-05 | * | * | Pares en unificacion_direccion |
| R1-06 | — hija previa | 1005 | Hija previa no re-procesada |
| R1-07 | * | * | Baseline CIIU 10 / 81 / 82 |
| R1-08 | Esc 1 (empate) | 1004 | Empate → no decisión |

### Regla 2

| ID | Escenario · subcaso | Persona | Criterio |
|----|---------------------|---------|----------|
| R2-01 | Esc 1 | 2001 | Vacío vs informado |
| R2-02 | Esc 2 | 2002 | Inclusión → más completo |
| R2-03 | Esc 3 sin NIT | 2003 | Misma nomenclatura → entidades |
| R2-04 | Esc 3 · Sub 1 motor | 2004 | NIT → motor combina |
| R2-05 | Esc 4 | 2005 | Diccionario mismo nivel |
| R2-06 | Esc 5 · Sub 1 motor / Sub 2 dicc. | 2006, 2008 | Distinto nivel → motor / diccionario |
| R2-07 | Esc 6 · Sub 1 motor / Sub 3 dicc. | 2007, 2009 | Cruzadas → motor / diccionario |
| R2-08 | Esc 3/5/6 motor | 2004+ | generada_enriquecida = 1 |
| R2-09 | Esc 3/5/6 motor | 2004+ | Nueva relación persona-ubicación |
| R2-10 | * | * | Padre nunca hijo |
| R2-11 | * | * | Una hija → un padre |
| R2-12 | Esc 3/5/6 motor | 2004+ | Complemento combinado ordenado |
| R2-13 | Esc 4 / Esc 5 Sub 2 | 2005, 2008 | Diccionario por frecuencia |
| R2-14 | Esc 4 (empate) | 2010 | Empate persistente |

### Regla 3

| ID | Escenario · subcaso | Persona | Criterio |
|----|---------------------|---------|----------|
| R3-01 | * | * | Solo tipo vía |
| R3-02 | Esc 1 · Sub 1 geo | 3001 | Una con geo → gana geo |
| R3-03 | Esc 2 · Sub 2 fecha | 3002 | Sin geo → fecha |
| R3-04 | Esc 1 · Sub 3 dicc. vía | 3003 | Ambas geo → diccionario vía |
| R3-05 | Esc 2 | * | Umbral puerta ±2 |
| R3-06 | Esc 2 fuera umbral | 3004 | Dif > 2 → no unifica |

### Globales

| ID | Criterio |
|----|----------|
| G-01 | Cascada R1 → R2 → R3 |
| G-02 | Padre puede ser hijo en regla posterior |
| G-03 | Hijas no se re-procesan |
| G-05 | Trazabilidad unificacion_direccion |
| G-07 | Solo misma persona |
| G-08 | Nada se borra |
| G-09 | Hijas no van a ordenamiento |
| G-10 | Vigentes sí van a ordenamiento |
