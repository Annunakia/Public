-- ============================================================
-- 09b_regla2_esc6_finaliza.sql
-- Regla 2 Escenario 6: PARTE 2 — Usa resultado del motor + subcaso 3
-- Ejecutar DESPUÉS del motor (06_motor_nuevas_direcciones.sql)
-- ============================================================
-- Prerequisito: 09a_regla2_esc6_prepara.sql + 06_motor_nuevas_direcciones.sql
-- Persona 2007: post-motor (subcaso 1)
-- Persona 2009: diccionario D6 (subcaso 3 — LC 10 OF 200 vs OF 200)
-- ============================================================

-- PASO 6: Post-motor — actualizar E2
UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'M6', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
JOIN bdm_stage.stg_motor_hijo h
  ON h.cod_dw_ubic = f.cod_dw_ubic AND h.id_buro_persona = f.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = f.cod_dw_tipo_ubicacion_dir
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = h.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N';

UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'M6', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = f.cod_dw_persona_ubic_padre
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N';

INSERT INTO bdm_stage.stg_regla2_e2 (
  cod_dw_persona_ubic, id_padre, id_buro_persona, cod_dw_tipo_ubicacion_dir,
  cod_dw_ubic, texto_ubicacion, cod_dw_direccion_fisica, complemento,
  ind_unificacion, n_id
)
SELECT f.new_cod_dw_persona_ubic, NULL, f.id_buro_persona, f.cod_dw_tipo_ubicacion_dir,
  f.cod_dw_ubic, f.texto_ubicacion, f.new_cod_dw_direccion_fisica, f.nuevo_complemento,
  'N', NULL
FROM bdm_stage.stg_motor_final f;

-- PASO 7: SUBCASO 3 — Mismo nivel, diccionario decide padre
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3;
CREATE TABLE bdm_stage.stg_regla2_e06_sub3
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM bdm_stage.stg_regla2_e06_c A
JOIN bdm_stage.stg_regla2_e06_c B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.complemento              <> B.complemento
  AND COALESCE(A.nivel_pri, 0) = COALESCE(B.nivel_pri, 0)
WHERE A.cod_dw_persona_ubic NOT IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e06_sub1);

ANALYZE bdm_stage.stg_regla2_e06_sub3;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_freq;
CREATE TABLE bdm_stage.stg_regla2_e06_sub3_freq
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT t1.cod_dw_persona_ubic, COALESCE(t2.conteo, 0) AS conteo
FROM bdm_stage.stg_regla2_e06_sub3 t1
LEFT JOIN (
  SELECT t1.cod_dw_persona_ubic, SUM(dc.frecuencia) AS conteo
  FROM bdm_stage.stg_regla2_e06_sub3 t1
  LEFT JOIN bdm_stage.diccionario_complementos dc
    ON t1.cod_dw_ubic = dc.cod_dw_ubic AND t1.complemento LIKE '%' || dc.nomenclatura || '%'
    AND t1.id_buro_persona = dc.id_buro_persona
  GROUP BY 1
) t2 ON t1.cod_dw_persona_ubic = t2.cod_dw_persona_ubic;

ANALYZE bdm_stage.stg_regla2_e06_sub3_freq;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_d;
CREATE TABLE bdm_stage.stg_regla2_e06_sub3_d
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT u1.*,
  COUNT(*) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id) AS count_empate,
  MAX(id) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio) AS idmax
FROM (
  SELECT a.cod_dw_persona_ubic,
    (COALESCE(b.conteo, 0) + 10000000)
      + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0) AS id,
    a.texto_ubicacion, a.id_buro_persona, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
      ORDER BY (COALESCE(b.conteo, 0) + 10000000)
        + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0)
    ) AS orden
  FROM bdm_stage.stg_regla2_e06_sub3 a
  LEFT JOIN bdm_stage.stg_regla2_e06_sub3_freq b ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
) u1;

ANALYZE bdm_stage.stg_regla2_e06_sub3_d;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_e;
CREATE TABLE bdm_stage.stg_regla2_e06_sub3_e
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT B.cod_dw_persona_ubic, A.cod_dw_persona_ubic AS id_padre
FROM bdm_stage.stg_regla2_e06_sub3_d A
JOIN bdm_stage.stg_regla2_e06_sub3_d B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.id > B.id
JOIN (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, MAX(orden) AS max_orden
  FROM bdm_stage.stg_regla2_e06_sub3_d GROUP BY 1,2,3,4
) mx ON A.id_buro_persona = mx.id_buro_persona AND A.texto_ubicacion = mx.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = mx.cod_dw_municipio
  AND A.orden = mx.max_orden;

ANALYZE bdm_stage.stg_regla2_e06_sub3_e;

UPDATE bdm_stage.stg_regla2_e2
SET id_padre = e.id_padre, ind_unificacion = 'S', n_id = 'D6'
FROM bdm_stage.stg_regla2_e06_sub3_e e
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = e.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.id_padre IS NULL;

INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT e.cod_dw_persona_ubic, e.id_padre AS cod_dw_direccion_unificada,
  2, CURRENT_DATE, 1, 1, LEFT(CURRENT_USER, 30)
FROM bdm_stage.stg_regla2_e06_sub3_e e;

UPDATE bdm_stage.relacion_persona_ubicacion SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e06_sub3_e);

-- PASO 8: Estadísticas y limpieza
ANALYZE bdm_stage.unificacion_direccion;
ANALYZE bdm_stage.relacion_persona_ubicacion;
ANALYZE bdm_stage.stg_regla2_e2;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_a;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_c;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub1;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_freq;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_d;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_e;
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
DROP TABLE IF EXISTS bdm_stage.stg_motor_final;
DROP TABLE IF EXISTS bdm_stage.stg_motor_padre;
DROP TABLE IF EXISTS bdm_stage.stg_motor_hijo;
