# Guion Demo v2 — Unificación Completa (R1 + R2 + R3)

> **Versión:** 2 — un paso por script, formato de guión para demo en vivo
> **Guion original (sin modificar):** `GUION_DEMO_VIDEO.md`
> **Duración estimada:** 35-45 minutos
> **Herramienta:** DBeaver conectado a Redshift
> **Esquema:** `bdm_stage` (debe existir previamente; no ejecutar `CREATE SCHEMA`)
> **Regla:** cada `.sql` se ejecuta **completo** (Run Script). No seleccionar rangos de líneas.

---

## Cómo usar los checklists

Cada paso incluye casillas `- [ ]`. En **Cursor / VS Code** puedes marcarlas haciendo clic en la casilla con la vista previa de Markdown abierta, o editando manualmente `- [ ]` → `- [x]`. También funcionan en GitHub y en la mayoría de visores Markdown.

**Progreso global:**

- [ ] PASO 01 — Setup
- [ ] PASO 02 — Regla 1
- [ ] PASO 03 — R2 Esc 1 y 2
- [ ] PASO 04 — R2 Esc 4
- [ ] PASO 05 — R2 Esc 3 sin NIT
- [ ] PASO 06 — R2 Esc 3 NIT (prepara)
- [ ] PASO 07 — Motor (NIT)
- [ ] PASO 08 — R2 Esc 3 NIT (cierra)
- [ ] PASO 09 — R2 Esc 5 (prepara)
- [ ] PASO 10 — Motor (Esc 5)
- [ ] PASO 11 — R2 Esc 5 (cierra)
- [ ] PASO 12 — R2 Esc 6 (prepara)
- [ ] PASO 13 — Motor (Esc 6)
- [ ] PASO 14 — R2 Esc 6 (cierra)
- [ ] PASO 15 — Regla 3
- [ ] PASO 16 — Resumen final
- [ ] PASO 17 — Limpieza

---

## Contexto (solo narrar al inicio, sin script)

### Frase de apertura (obligatoria)

> "Reconocer determina la mejor forma de contactar a una persona. Unificación elimina direcciones redundantes aplicando 3 reglas en cascada: R1 por tipo de uso, R2 por complementos, R3 por geolocalización. Al final **solo las vigentes** pasan a ordenamiento; las absorbidas quedan en trazabilidad."

### Diagrama de contexto (mostrar antes de PASO 01)

Abrir en [draw.io](https://app.diagrams.net/) el archivo del repo:

`mapa_unificacion_demo.drawio`

*(Flujo end-to-end + casos por regla con persona demo y particularidad.)*

### Flujo en una línea

```
XPM → Redshift (bdm_stage) → R1 → R2 (+ motor) → R3 → Ordenamiento (solo vigentes)
```

### Mapa rápido de casos (referencia al narrar)

| Regla | Persona | Particularidad | Resultado |
|-------|---------|----------------|-----------|
| **R1** | 1001 | CIIU=10, RES vs LAB | LAB gana |
| R1 | 1002 | CIIU=81, LAB vs RES | RES gana |
| R1 | 1003 | CIIU=55, desempate entidades | CRR gana |
| R1 | 1004 | CIIU=10, empate LAB vs CRR | Sin unificación |
| R1 | 1005 | Hija ya absorbida | Solo entra la no unificada |
| **R2** | 2001 | Esc 1: vacío vs AP 802 | Gana informado |
| R2 | 2002 | Esc 2: AP 702 vs ED GALICIA AP 702 | Gana más completo |
| R2 | 2003 | Esc 3 sin NIT: AP 105 vs AP 404 | Gana más entidades |
| R2 | 2004 | Esc 3 NIT → **motor** | LC 101 LC 205 (nueva) |
| R2 | 2005 | Esc 4 diccionario: CS 5 vs PI 5 | CS gana por freq |
| R2 | 2006 | Esc 5 → **motor** | TO 3 AP 504 (nueva) |
| R2 | 2007 | Esc 6 cruzadas → **motor** | ED 2 OF 301 OF 302 (nueva) |
| R2 | 2008 | Esc 5 sub2 diccionario: TO 5 vs PI 5 | TO gana por freq |
| R2 | 2009 | Esc 6 sub3 diccionario | LC gana por freq |
| R2 | 2010 | Esc 4 empate freq+fecha (R2-14) | Sin unificación |
| **R3** | 3001 | Dif vía gen, solo 1 con geo | Gana geolocalizada |
| R3 | 3002 | Dif puerta ±2, sin geo | Gana fecha reciente |
| R3 | 3003 | Dif vía gen, ambas con geo | Diccionario de vía |
| R3 | 3004 | Dif puerta = 5 (>±2) | Sin unificación |

**Motor (dentro de R2):** combina complementos que no pueden resolverse eligiendo uno solo — se ejecuta 3 veces (2004, 2006, 2007).

**Ordenamiento:** `ind_unificacion IS NULL` = vigente (pasa). `= 1` = absorbida (no pasa). Trazabilidad en `unificacion_direccion`.

---

## PASO 01 — Cargar datos

**Checklist del paso:**

- [ ] Ejecuté `01_demo_setup.sql`
- [ ] Corrí las consultas de resultado
- [ ] Verifiqué el resultado esperado

### Narrativa

> "Creamos las tablas de demo y cargamos 19 personas con 2 direcciones cada una, diseñadas para cubrir todos los escenarios, subcasos y criterios R2-01 a R2-14."

### Ejecutar en DBeaver:

`01_demo_setup.sql`

### Consultas de resultado:

```sql
-- Personas y direcciones cargadas
SELECT rpu.id_buro_persona AS persona,
  ubi.texto_ubicacion AS direccion,
  tud.descripcion_tipo_ubicacion_dir AS tipo_uso,
  df.complemento,
  ciiu.cod_act_econo_ciiu_fte AS ciiu
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona
WHERE rpu.ind_unificacion IS NULL
ORDER BY rpu.id_buro_persona, rpu.cod_dw_persona_ubic;
```

```sql
SELECT * FROM bdm_stage.tipo_ubicacion_dir;
```

```sql
SELECT * FROM bdm_stage.nomenclatura ORDER BY nivel_complemento, nomenclatura;
```

### Resultado esperado:

- 19 personas (1001–1005, 2001–2010, 3001–3004), 2 direcciones cada una = **38 registros**
- Catálogo tipo uso: RES, LAB, CRR, JUD, CCL
- Nomenclaturas con niveles 1–7

### Explicación:

> "Todos los objetos viven en bdm_stage. Los datos están listos para ejecutar la cascada R1 → R2 → R3."

### Criterios validados:

- ✅ Dataset demo cargado correctamente

---

## PASO 02 — Regla 1: Tipo de uso + CIIU

**Checklist del paso:**

- [ ] Ejecuté `02_regla1_unificacion.sql`
- [ ] Corrí las consultas de resultado
- [ ] Verifiqué el resultado esperado

### Narrativa

> "Regla 1 busca direcciones de una misma persona con la misma puerta pero distinto tipo de uso (RES, LAB, CRR). Según el CIIU y las entidades reportantes, decide cuál prevalece."

### Ejecutar en DBeaver:

`02_regla1_unificacion.sql`

### Consultas de resultado:

```sql
-- Pares padre-hijo generados por R1
SELECT cod_dw_persona_ubic AS hijo,
  cod_dw_direccion_unificada AS padre,
  unifica_atributos AS regla
FROM bdm_stage.unificacion_direccion
WHERE unifica_atributos = 1
ORDER BY hijo;
```

```sql
-- Detalle por persona R1
SELECT rpu.id_buro_persona AS persona,
  tud.descripcion_tipo_ubicacion_dir AS tipo_uso,
  ciiu.cod_act_econo_ciiu_fte AS ciiu,
  COUNT(DISTINCT rep.id_buro_suscriptor) AS entidades,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS resultado
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
LEFT JOIN bdm_stage.ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona
LEFT JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
WHERE rpu.id_buro_persona IN (1001, 1002, 1003, 1004, 1005)
GROUP BY 1,2,3,5
ORDER BY rpu.id_buro_persona, resultado;
```

### Resultado esperado:

| Hijo | Padre | Persona | Explicación |
|------|-------|---------|-------------|
| 100 | 101 | 1001 | CIIU=10, RES(2 ent) pierde vs LAB(5 ent). Asalariado → prefiere LAB |
| 200 | 201 | 1002 | CIIU=81, LAB(1 ent) pierde vs RES(4 ent). Sin actividad → prefiere RES |
| 300 | 301 | 1003 | CIIU=55, RES(2 ent) pierde vs CRR(6 ent). Otro CIIU → mayor entidades |

**No deben aparecer:**

- Persona **1004**: LAB(3 ent) vs CRR(3 ent) → EMPATE, no se unifica
- Persona **1005**: RES ya tenía `ind_unificacion=1` → no entra al proceso

### Explicación:

> "Persona 1001 es asalariada. Misma puerta como RES y LAB; para CIIU=10 se prefiere LAB y tiene más entidades."

> "Persona 1004 empata en score y entidades → no se fuerza decisión."

> "Persona 1005 ya tenía una hija previa; el proceso la filtra con ind_unificacion IS NULL."

### Criterios validados:

- ✅ R1-01: CIIU=10, LAB gana
- ✅ R1-02: CIIU=81, RES gana
- ✅ R1-03: Otro CIIU, mayor entidades
- ✅ R1-04: Hijos marcados con ind_unificacion=1
- ✅ R1-05: Pares registrados en unificacion_direccion
- ✅ R1-06: Hija previa no entra
- ✅ R1-07: Baseline CIIU (10, 81/82/90)
- ✅ R1-08: Empate = no decisión

---

## PASO 03 — Regla 2 Escenarios 1 y 2

**Checklist del paso:**

- [ ] Ejecuté `03_regla2_esc1_2.sql`
- [ ] Corrí las consultas de resultado
- [ ] Verifiqué el resultado esperado

### Narrativa

> "Regla 2 compara direcciones con la misma puerta pero diferente complemento. En este paso: Escenario 1 (vacío vs informado) y Escenario 2 (un complemento incluido en el otro)."

### Ejecutar en DBeaver:

`03_regla2_esc1_2.sql`

### Consultas de resultado:

```sql
-- Persona 2001 — Escenario 1
SELECT rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS estado,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona = 2001
ORDER BY estado, cod_rpu;
```

```sql
-- Persona 2002 — Escenario 2
SELECT rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS estado,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona = 2002
ORDER BY estado, cod_rpu;
```

### Resultado esperado:

| Persona | Hijo | Padre | Complementos | Escenario |
|---------|------|-------|--------------|-----------|
| 2001 | 600 | 601 | '' vs AP 802 | Esc 1 — gana informado |
| 2002 | 700 | 701 | AP 702 vs ED GALICIA AP 702 | Esc 2 — gana el más completo |

### Explicación:

> "Persona 2001: complemento vacío pierde frente a AP 802."

> "Persona 2002: AP 702 está contenido en ED GALICIA AP 702 → gana el más completo."

### Criterios validados:

- ✅ R2-01: Vacío vs informado → gana informado
- ✅ R2-02: Incluido → gana el más completo

---

## PASO 04 — Regla 2 Escenario 4 (diccionario)

**Checklist del paso:**

- [ ] Ejecuté `04_regla2_esc4.sql`
- [ ] Corrí las consultas de resultado
- [ ] Verifiqué el resultado esperado

### Narrativa

> "Escenario 4: nomenclaturas diferentes al mismo nivel. El diccionario de complementos decide por frecuencia; si hay empate persistente, no hay decisión."

### Ejecutar en DBeaver:

`04_regla2_esc4.sql`

### Consultas de resultado:

```sql
-- Persona 2005: desempate por frecuencia
SELECT rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS estado,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona = 2005
ORDER BY estado, cod_rpu;
```

```sql
-- Persona 2010: empate persistente (R2-14)
SELECT rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  rpu.ind_unificacion,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona = 2010
ORDER BY cod_rpu;
```

### Resultado esperado:

| Persona | Hijo | Padre | Complementos | Explicación |
|---------|------|-------|--------------|-------------|
| 2005 | 1001 | 1000 | PI 5 vs CS 5 | CS 5 freq=10 vs PI 5 freq=4 → gana CS |
| 2010 | — | — | CS 8 vs PI 8 | Misma freq (10) y misma fecha → **no unifica** |

### Explicación:

> "Distinta nomenclatura (CS vs PI), mismo nivel (5) y mismo valor numérico (5 u 8). Con frecuencias distintas gana el diccionario (2005). Con empate total en score, ninguna dirección absorbe a la otra (2010)."

### Criterios validados:

- ✅ R2-05: Diccionario mismo nivel → mayor frecuencia
- ✅ R2-13: Diccionario basado en frecuencia histórica
- ✅ R2-14: Empate persistente = no decisión

---

## PASO 05 — Regla 2 Escenario 3 sin NIT

**Checklist del paso:**

- [ ] Ejecuté `05_regla2_esc3_sin_nit.sql`
- [ ] Corrí las consultas de resultado
- [ ] Verifiqué el resultado esperado

### Narrativa

> "Escenario 3 sin NIT: misma nomenclatura (AP) pero diferente valor. Gana la dirección con más entidades reportantes."

### Ejecutar en DBeaver:

`05_regla2_esc3_sin_nit.sql`

### Consultas de resultado:

```sql
SELECT rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS estado,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona = 2003
ORDER BY estado, cod_rpu;
```

### Resultado esperado:

| Persona | Hijo | Padre | Complementos | Explicación |
|---------|------|-------|--------------|-------------|
| 2003 | 800 | 801 | AP 105 vs AP 404 | AP 404 tiene 6 entidades vs 2 |

### Explicación:

> "No son el mismo complemento aunque compartan nomenclatura AP. Gana la más reportada."

### Criterios validados:

- ✅ R2-03: Misma nomenclatura sin NIT → mayor entidades

---

## PASO 06 — Regla 2 Escenario 3 NIT (preparar motor)

**Checklist del paso:**

- [ ] Ejecuté `07a_regla2_esc3_nit_prepara.sql`
- [ ] Listo para ejecutar el motor (PASO 07)

### Narrativa

> "Escenario 3 NIT: empresa con LC 101 y LC 205 — misma nomenclatura, diferente valor. Para NIT no se elige una; se prepara el motor para combinarlas."

### Ejecutar en DBeaver:

`07a_regla2_esc3_nit_prepara.sql`

### Consultas de resultado:

*(Este paso solo prepara staging. Validar en PASO 07 tras el motor.)*

```sql
-- Opcional: confirmar que hay input para el motor
SELECT COUNT(*) AS filas_motor_input FROM bdm_stage.stg_motor_input;
```

### Resultado esperado:

- `stg_motor_input` con filas para persona **2004** (LC 101 y LC 205)

### Explicación:

> "Identificamos pares NIT con misma nomenclatura y cargamos el input del motor."

### Criterios validados:

- *(Validación funcional en PASO 07)*

---

## PASO 07 — Motor nuevas direcciones (NIT — persona 2004)

**Checklist del paso:**

- [ ] Ejecuté `06_motor_nuevas_direcciones.sql`
- [ ] Corrí las consultas de resultado
- [ ] Verifiqué el resultado esperado

### Narrativa

> "El motor combina los complementos de ambas direcciones NIT en una dirección enriquecida nueva y registra los pares padre-hijo."

### Ejecutar en DBeaver:

`06_motor_nuevas_direcciones.sql`

### Consultas de resultado:

```sql
-- Persona 2004 — resultado NIT
SELECT rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  df.generada_enriquecida,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS estado,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona = 2004
ORDER BY estado, cod_rpu;
```

```sql
SELECT cod_dw_direccion_fisica, complemento, generada_enriquecida
FROM bdm_stage.direccion_fisica
WHERE generada_enriquecida = 1
ORDER BY cod_dw_direccion_fisica;
```

```sql
-- R2-12: complemento generado combina fuentes sin duplicar nomenclaturas repetidas
SELECT rpu.id_buro_persona,
  df.complemento AS generado,
  (SELECT LISTAGG(df2.complemento, ' | ') WITHIN GROUP (ORDER BY rpu2.cod_dw_persona_ubic)
   FROM bdm_stage.relacion_persona_ubicacion rpu2
   JOIN bdm_stage.direccion_fisica df2 ON rpu2.cod_dw_direccion_fisica = df2.cod_dw_direccion_fisica
   WHERE rpu2.id_buro_persona = rpu.id_buro_persona AND rpu2.ind_unificacion = 1) AS fuentes_hijo
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.id_buro_persona = 2004 AND df.generada_enriquecida = 1;
```

### Resultado esperado:

| Persona | Detalle |
|---------|---------|
| 2004 | Nueva dirección con complemento **LC 101 LC 205** y `generada_enriquecida = 1` |
| 2004 | **900** y **901** = HIJO del nuevo padre generado |

### Explicación:

> "Para empresas NIT se combinan ambos locales en orden lógico por jerarquía de nomenclatura. Las originales quedan absorbidas; la nueva es el padre vigente."

### Criterios validados:

- ✅ R2-04: NIT → genera nueva dirección combinada
- ✅ R2-08: generada_enriquecida = 1
- ✅ R2-09: Nueva dirección tiene relación persona-ubicación
- ✅ R2-12: Complemento combinado completo y ordenado (`LC 101 LC 205`)

---

## PASO 08 — Regla 2 Escenario 3 NIT (cerrar)

**Checklist del paso:**

- [ ] Ejecuté `07b_regla2_esc3_nit_finaliza.sql`
- [ ] Continuar con PASO 09

### Narrativa

> "Cierre interno del escenario NIT: actualiza la tabla acumulada de Regla 2 y limpia staging."

### Ejecutar en DBeaver:

`07b_regla2_esc3_nit_finaliza.sql`

### Consultas de resultado:

*(Sin consulta obligatoria — el resultado ya se validó en PASO 07.)*

### Resultado esperado:

- Script termina sin error
- Resultado de persona 2004 se mantiene como en PASO 07

### Explicación:

> "Paso técnico de cierre. La evidencia de negocio ya quedó en las tablas finales."

### Criterios validados:

- ✅ R2-10: Padre nunca marcado como hijo
- ✅ R2-11: Cada hija tiene exactamente 1 padre

---

## PASO 09 — Regla 2 Escenario 5 (preparar motor)

**Checklist del paso:**

- [ ] Ejecuté `08a_regla2_esc5_prepara.sql`
- [ ] Listo para ejecutar el motor (PASO 10)

### Narrativa

> "Escenario 5: TO 3 (nivel 4) vs AP 504 (nivel 7) — nomenclaturas en distinto nivel con valores diferentes. Van al motor."

### Ejecutar en DBeaver:

`08a_regla2_esc5_prepara.sql`

### Consultas de resultado:

```sql
SELECT COUNT(*) AS filas_motor_input FROM bdm_stage.stg_motor_input;
```

### Resultado esperado:

- `stg_motor_input` con filas para persona **2006**

### Explicación:

> "Preparamos el input del motor para generar una dirección combinada."

### Criterios validados:

- *(Validación funcional en PASO 10)*

---

## PASO 10 — Motor nuevas direcciones (Esc 5 — persona 2006)

**Checklist del paso:**

- [ ] Ejecuté `06_motor_nuevas_direcciones.sql`
- [ ] Corrí las consultas de resultado
- [ ] Verifiqué el resultado esperado

### Narrativa

> "El motor genera una dirección enriquecida que combina TO 3 y AP 504."

### Ejecutar en DBeaver:

`06_motor_nuevas_direcciones.sql`

### Consultas de resultado:

```sql
SELECT rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  df.generada_enriquecida,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS estado,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona = 2006
ORDER BY estado, cod_rpu;
```

```sql
SELECT cod_dw_direccion_fisica, complemento, generada_enriquecida
FROM bdm_stage.direccion_fisica
WHERE generada_enriquecida = 1
ORDER BY cod_dw_direccion_fisica;
```

### Resultado esperado:

| Persona | Detalle |
|---------|---------|
| 2006 | Nueva dirección combinada (p. ej. **TO 3 AP 504**) |
| 2006 | **1100** y **1101** = HIJO del nuevo padre |

### Explicación:

> "Distinto nivel y distinto valor → no se elige una sobre otra; se crea una dirección nueva con complemento ordenado por jerarquía de nomenclatura."

### Criterios validados:

- ✅ R2-06: Distinto nivel → motor genera nueva dirección
- ✅ R2-12: Fusión completa en orden lógico (`TO 3 AP 504`)

---

## PASO 11 — Regla 2 Escenario 5 (cerrar)

**Checklist del paso:**

- [ ] Ejecuté `08b_regla2_esc5_finaliza.sql`
- [ ] Corrí las consultas de resultado
- [ ] Verifiqué el resultado esperado

### Narrativa

> "Cierra Escenario 5: post-procesamiento del motor (2006), subcaso 2 por diccionario (2008) y limpieza de staging."

### Ejecutar en DBeaver:

`08b_regla2_esc5_finaliza.sql`

### Consultas de resultado:

```sql
SELECT rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS estado,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona IN (2006, 2008)
ORDER BY rpu.id_buro_persona, estado, cod_rpu;
```

### Resultado esperado:

| Persona | Detalle |
|---------|---------|
| 2006 | Mantiene resultado del PASO 10 (motor) |
| 2008 | **1202** (TO 5) = PADRE, **1203** (PI 5) = HIJO — misma fecha → gana TO por freq 15 vs 6 |

### Explicación:

> "Subcaso 2 del Escenario 5: cuando el valor numérico coincide pero la nomenclatura está en distinto nivel, el diccionario elige padre por frecuencia."

### Criterios validados:

- ✅ R2-06 confirmado en tablas finales (motor subcaso 1 + diccionario subcaso 2)
- ✅ R2-13: Diccionario por frecuencia histórica (2008)

---

## PASO 12 — Regla 2 Escenario 6 (preparar motor)

**Checklist del paso:**

- [ ] Ejecuté `09a_regla2_esc6_prepara.sql`
- [ ] Listo para ejecutar el motor (PASO 13)

### Narrativa

> "Escenario 6: ED 2 OF 301 vs OF 302 — nomenclaturas cruzadas (OF secundaria = OF primaria). No activa Esc 2. Van al motor."

### Ejecutar en DBeaver:

`09a_regla2_esc6_prepara.sql`

### Consultas de resultado:

```sql
SELECT COUNT(*) AS filas_motor_input FROM bdm_stage.stg_motor_input;
```

### Resultado esperado:

- `stg_motor_input` con filas para persona **2007**

### Explicación:

> "Preparamos pares donde los complementos no se contienen mutuamente."

### Criterios validados:

- *(Validación funcional en PASO 13)*

---

## PASO 13 — Motor nuevas direcciones (Esc 6 — persona 2007)

**Checklist del paso:**

- [ ] Ejecuté `06_motor_nuevas_direcciones.sql`
- [ ] Corrí las consultas de resultado
- [ ] Verifiqué el resultado esperado

### Narrativa

> "El motor fusiona ED 2 OF 301 y OF 302 en una dirección enriquecida nueva."

### Ejecutar en DBeaver:

`06_motor_nuevas_direcciones.sql`

### Consultas de resultado:

```sql
SELECT rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  df.generada_enriquecida,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS estado,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona = 2007
ORDER BY estado, cod_rpu;
```

```sql
SELECT cod_dw_direccion_fisica, complemento, generada_enriquecida
FROM bdm_stage.direccion_fisica
WHERE generada_enriquecida = 1
ORDER BY cod_dw_direccion_fisica;
```

```sql
-- R2-12: 2007 combina fuentes sin repetir nomenclatura+valor (ED 2 OF 301 + OF 302)
SELECT df.complemento AS generado
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.id_buro_persona = 2007 AND df.generada_enriquecida = 1;
-- Esperado: p. ej. ED 2 OF 301 OF 302 (OF 301 no duplicado)
```

### Resultado esperado:

| Persona | Detalle |
|---------|---------|
| 2007 | Nueva dirección combinada (p. ej. **ED 2 OF 301 OF 302**) |
| 2007 | **1200** y **1201** = HIJO del nuevo padre |
| 2007 R2-12 | No repite `OF 301` del padre; agrega valor **302** del hijo |

### Explicación:

> "Cuando ninguna dirección contiene a la otra, el motor construye una representación unificada sin repetir nomenclaturas ya presentes en el padre jerárquico."

### Criterios validados:

- ✅ R2-07: Ninguna contenida → motor genera nueva
- ✅ R2-12: Sin duplicidad de complementos (`OF 301` no se repite; se agrega `302`)

---

## PASO 14 — Regla 2 Escenario 6 (cerrar)

**Checklist del paso:**

- [ ] Ejecuté `09b_regla2_esc6_finaliza.sql`
- [ ] Corrí las consultas de resultado
- [ ] Verifiqué el resultado esperado

### Narrativa

> "Cierra Escenario 6: post-procesamiento del motor (2007), subcaso 3 por diccionario (2009) y completa Regla 2."

### Ejecutar en DBeaver:

`09b_regla2_esc6_finaliza.sql`

### Consultas de resultado:

```sql
-- Resumen Regla 2
SELECT ud.cod_dw_persona_ubic AS hijo,
  ud.cod_dw_direccion_unificada AS padre,
  rpu.id_buro_persona AS persona
FROM bdm_stage.unificacion_direccion ud
JOIN bdm_stage.relacion_persona_ubicacion rpu
  ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE ud.unifica_atributos = 2
ORDER BY persona, hijo;
```

```sql
SELECT rpu.cod_dw_persona_ubic AS cod_rpu,
  df.complemento,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS estado,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona IN (2007, 2009)
ORDER BY rpu.id_buro_persona, estado, cod_rpu;
```

```sql
SELECT cod_dw_direccion_fisica, complemento, generada_enriquecida
FROM bdm_stage.direccion_fisica
WHERE generada_enriquecida = 1
ORDER BY cod_dw_direccion_fisica;
```

### Resultado esperado:

- Pares R2 para personas **2001–2009** (unificadas)
- Persona **2010** sin par R2 (empate — R2-14)
- **3 direcciones** con `generada_enriquecida = 1` (personas 2004, 2006, 2007)
- Persona **2009**: **1204** (LC 10 OF 200) = PADRE, **1205** (OF 200) = HIJO — cruzadas, mismo nivel → diccionario D6

### Explicación:

> "Regla 2 completa: escenarios de selección, diccionario en todos los subcasos y motor donde aplica."

### Criterios validados:

- ✅ R2-07 confirmado en tablas finales (motor subcaso 1 + diccionario subcaso 3)
- ✅ R2-12 confirmado en direcciones del motor (2004, 2006, 2007)
- ✅ R2-14 confirmado: persona 2010 permanece sin unificar
- ✅ Cascada R1 → R2 sin reprocesar hijas (G-03)

---

## PASO 15 — Regla 3: Geolocalización

**Checklist del paso:**

- [ ] Ejecuté `10_regla3_geo.sql`
- [ ] Corrí las consultas de resultado
- [ ] Verifiqué el resultado esperado

### Narrativa

> "Regla 3 compara direcciones tipo vía que difieren en vía generadora o número de puerta. Usa coordenadas, fecha o diccionario de vías."

### Ejecutar en DBeaver:

`10_regla3_geo.sql`

### Consultas de resultado:

```sql
-- Personas R3
SELECT rpu.id_buro_persona AS persona,
  ubi.texto_ubicacion AS direccion,
  df.via_generadora,
  df.numero_puerta,
  ubi.latitud,
  ubi.longitud,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS resultado,
  ud.cod_dw_direccion_unificada AS apunta_a_padre
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.unificacion_direccion ud ON ud.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE rpu.id_buro_persona IN (3001, 3002, 3003, 3004)
ORDER BY rpu.id_buro_persona, resultado;
```

```sql
SELECT cod_dw_persona_ubic AS hijo,
  cod_dw_direccion_unificada AS padre,
  unifica_atributos AS regla
FROM bdm_stage.unificacion_direccion
WHERE unifica_atributos = 3
ORDER BY hijo;
```

### Resultado esperado:

| Hijo | Padre | Persona | Subcaso | Explicación |
|------|-------|---------|---------|-------------|
| 1301 | 1300 | 3001 | Subcaso 1 | Vía gen 78 vs 80. Solo 5011 tiene geo → gana geolocalizada |
| 1400 | 1401 | 3002 | Subcaso 2 | Puerta 33 vs 35 (dif=2). Sin geo → gana fecha más reciente |
| 1500 | 1501 | 3003 | Subcaso 3 | Vía gen 20 vs 22. Ambas con geo → diccionario (freq 20=15 vs 22=8) |

**No debe aparecer:**

- Persona **3004**: Puerta 50 vs 55 (dif=5 > 2) → **NO unifica**

### Explicación:

> "3001: geo gana sobre sin geo. 3002: desempate por fecha. 3003: diccionario de vía. 3004: diferencia > ±2 → direcciones distintas."

### Criterios validados:

- ✅ R3-01: Solo tipo Vía
- ✅ R3-02: Solo una con lat/long → gana geolocalizada
- ✅ R3-03: Ninguna con lat/long → fecha más reciente
- ✅ R3-04: Ambas con lat/long → diccionario de vía
- ✅ R3-05: Valida umbral ±2
- ✅ R3-06: Diferencia > 2 → NO unifica

---

## PASO 16 — Resumen final

**Checklist del paso:**

- [ ] Corrí las consultas de resumen
- [ ] Verifiqué métricas finales

### Narrativa

> "Cerramos la demo mostrando la cascada completa: trazabilidad, vigentes vs absorbidas, y qué pasa a ordenamiento."

### Ejecutar en DBeaver:

*(Sin script — solo consultas)*

### Consultas de resultado:

```sql
SELECT unifica_atributos AS regla, COUNT(*) AS pares
FROM bdm_stage.unificacion_direccion
GROUP BY 1 ORDER BY 1;
```

```sql
SELECT
  CASE WHEN ind_unificacion = 1 THEN 'ABSORBIDA (hijo)' ELSE 'VIGENTE (padre/independiente)' END AS estado,
  COUNT(*) AS cantidad
FROM bdm_stage.relacion_persona_ubicacion
GROUP BY 1;
```

```sql
SELECT cod_dw_persona_ubic AS hijo,
  cod_dw_direccion_unificada AS padre,
  unifica_atributos AS regla
FROM bdm_stage.unificacion_direccion
ORDER BY regla, hijo;
```

```sql
SELECT rpu.id_buro_persona AS persona,
  ubi.texto_ubicacion AS direccion,
  df.complemento,
  tud.descripcion_tipo_ubicacion_dir AS tipo_uso
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
WHERE rpu.ind_unificacion IS NULL
ORDER BY rpu.id_buro_persona;
```

### Resultado esperado:

| Métrica | Valor orientativo |
|---------|-------------------|
| Unificaciones R1 | 3 pares base (+ posibles de R3) |
| Unificaciones R2 | 9+ pares (2001–2009) |
| Sin unificación R2 | 2010 (empate R2-14) |
| Unificaciones R3 | 3 pares (3001–3003) |
| Direcciones motor | 3 (2004, 2006, 2007) |
| Diccionario R2 subcasos | 2005, 2008 (Esc5 sub2), 2009 (Esc6 sub3) |
| Criterios R2 | R2-01 a R2-14 cubiertos |
| Persona 3004 | Sin unificación |

### Explicación:

> "Toda unificación quedó en unificacion_direccion. Las hijas no pasan a ordenamiento; solo las vigentes."

### Criterios validados:

- ✅ G-01: Cascada R1 → R2 → R3 en orden
- ✅ G-02: Padres pueden ser hijos en reglas posteriores
- ✅ G-03: Hijas no se re-procesan
- ✅ G-05: Trazabilidad en unificacion_direccion
- ✅ G-07: Solo misma persona
- ✅ G-08: Unificación lógica — nada borrado
- ✅ G-09: Hijas no van a ordenamiento
- ✅ G-10: Padres vigentes sí van a ordenamiento

---

## PASO 17 — Limpieza

**Checklist del paso:**

- [ ] Ejecuté `03_demo_cleanup.sql`

### Narrativa

> "Eliminamos solo las tablas del demo. El esquema bdm_stage se conserva."

### Ejecutar en DBeaver:

`03_demo_cleanup.sql`

### Consultas de resultado:

*(Opcional — confirmar que las tablas demo ya no existen)*

### Resultado esperado:

- Script termina sin error
- Esquema `bdm_stage` permanece

### Explicación:

> "Limpieza para dejar el ambiente listo para otra ejecución."

### Criterios validados:

- ✅ Ambiente restaurado

---

## Orden de scripts (referencia rápida)

| Paso | Script |
|------|--------|
| 01 | `01_demo_setup.sql` |
| 02 | `02_regla1_unificacion.sql` |
| 03 | `03_regla2_esc1_2.sql` |
| 04 | `04_regla2_esc4.sql` |
| 05 | `05_regla2_esc3_sin_nit.sql` |
| 06 | `07a_regla2_esc3_nit_prepara.sql` |
| 07 | `06_motor_nuevas_direcciones.sql` |
| 08 | `07b_regla2_esc3_nit_finaliza.sql` |
| 09 | `08a_regla2_esc5_prepara.sql` |
| 10 | `06_motor_nuevas_direcciones.sql` |
| 11 | `08b_regla2_esc5_finaliza.sql` |
| 12 | `09a_regla2_esc6_prepara.sql` |
| 13 | `06_motor_nuevas_direcciones.sql` |
| 14 | `09b_regla2_esc6_finaliza.sql` |
| 15 | `10_regla3_geo.sql` |
| 17 | `03_demo_cleanup.sql` |
