# Demo Completa — Unificación de Direcciones (R1 + R2 + R3)

## Objetivo
Demostrar que las 3 reglas de Unificación funcionan en cascada en Amazon Redshift, cubriendo todos los criterios de aceptación consolidados (Kidar + Experian).

## Dataset
- 19 personas con escenarios diseñados
- 38 direcciones (2 por persona)
- Cascada: R1 → R2 → R3 (resultado de una alimenta la siguiente)
- **Mapa visual demo:** `mapa_unificacion_demo.drawio` (draw.io — abrir antes del PASO 01)

## Escenarios cubiertos

| Persona | Regla | Escenario | Resultado esperado |
|---------|-------|-----------|-------------------|
| 1001 | R1 | CIIU=10, RES vs LAB | LAB gana (R1-01) |
| 1002 | R1 | CIIU=81, LAB vs RES | RES gana (R1-02) |
| 1003 | R1 | CIIU=55, RES vs CRR | CRR gana por entidades (R1-03) |
| 1004 | R1 | CIIU=10, LAB vs CRR empate | No decisión (R1-08) |
| 1005 | R1 | Hija previa | No entra (R1-06) |
| 2001 | R2 | Vacío vs informado | Informado gana (R2-01) |
| 2002 | R2 | Incluido | Más completo gana (R2-02) |
| 2003 | R2 | Misma nomenclatura, ≠ valor | Mayor entidades (R2-03) |
| 2004 | R2 | NIT, misma nomenclatura | Nueva dirección (R2-04) |
| 2005 | R2 | ≠ nomenclatura, mismo nivel | Diccionario (R2-05) |
| 2006 | R2 | ≠ nivel, valores ≠ | Nueva dirección — motor (R2-06) |
| 2007 | R2 | Ninguna contenida, ≠ nivel | Nueva dirección — motor (R2-07) |
| 2008 | R2 | ≠ nivel, mismo valor | Diccionario — Esc 5 subcaso 2 (R2-06) |
| 2009 | R2 | Cruzadas, = nivel | Diccionario — Esc 6 subcaso 3 (R2-07) |
| 2010 | R2 | ≠ nomenclatura, mismo nivel, empate | Sin decisión (R2-14) |
| 3001 | R3 | Dif vía gen, solo 1 con geo | Geo gana (R3-02) |
| 3002 | R3 | Dif puerta ±2, sin geo | Fecha gana (R3-03) |
| 3003 | R3 | Dif vía gen, ambas con geo | Diccionario (R3-04) |
| 3004 | R3 | Dif puerta > 2 | NO unifica (R3-06) |

## Ejecución

**Guion demo en vivo:** `GUION_DEMO_VIDEO_v3.md` (v3 — guía en vivo por paso)  
**Guion anterior:** `GUION_DEMO_VIDEO_v2.md`  
**Diagrama:** `mapa_unificacion_demo.drawio`

```bash
cd ws-unificacion/demo

# 1. Setup (tablas + datos)
./run_sql_file.sh 01_demo_setup.sql

# 2. Regla 1
./run_sql_file.sh ../src/redshift/sql/02_regla1_unificacion.sql

# 3. Regla 2 (7 scripts en orden)
./run_sql_file.sh ../src/redshift/sql/03_regla2_esc1_2.sql
./run_sql_file.sh ../src/redshift/sql/04_regla2_esc4.sql
./run_sql_file.sh ../src/redshift/sql/05_regla2_esc3_sin_nit.sql
./run_sql_file.sh ../src/redshift/sql/06_motor_nuevas_direcciones.sql
./run_sql_file.sh ../src/redshift/sql/07_regla2_esc3_nit.sql
./run_sql_file.sh ../src/redshift/sql/08_regla2_esc5.sql
./run_sql_file.sh ../src/redshift/sql/09_regla2_esc6.sql

# 4. Regla 3
./run_sql_file.sh ../src/redshift/sql/10_regla3_geo.sql

# 5. Validación
./run_sql_file.sh 02_demo_validacion.sql

# 6. Limpieza
./run_sql_file.sh 03_demo_cleanup.sql
```

## Ambiente
- Workgroup: experian-sandbox-trunk-ddm-xpm-workgroup
- DB: dev
- Profile: sandbox
- Region: us-east-1

## Benchmark de performance (20K personas)

Carpeta [`Benchmark_20K/`](Benchmark_20K/) — un solo `.sql` en DBeaver (`Alt+Shift+X`):

| Archivo | Personas | Motor |
|---------|----------|-------|
| `Benchmark_20K/00_run_benchmark_2k_demo_fiel.sql` | 2.000 (piloto) | 3× |
| `Benchmark_20K/00_run_benchmark_20k_demo_fiel.sql` | 20.000 | 3× |
| `Benchmark_20K/00_run_benchmark_20k_batch.sql` | 20.000 | 1× |
| `Benchmark_20K/00_run_benchmark_20k_batch_edf_stage.sql` | 20.000 | 1× (`edf_stage`, QA) |

Documentación: [`Benchmark_20K/README.md`](Benchmark_20K/README.md), [`RUNBOOK_DBEAVER_BENCHMARK.md`](Benchmark_20K/RUNBOOK_DBEAVER_BENCHMARK.md).

Tiempos por hito en `bdm_stage.perf_timings`. Plantilla de informe: [`INFORME_PLANTILLA.md`](Benchmark_20K/INFORME_PLANTILLA.md).

**Informe cliente (corrida 20K batch):** [`INFORME_BENCHMARK_20K_BATCH.md`](INFORME_BENCHMARK_20K_BATCH.md) — detalle por persona en [`Benchmark_20K/datos/informe_20k_por_persona.csv`](Benchmark_20K/datos/informe_20k_por_persona.csv).
