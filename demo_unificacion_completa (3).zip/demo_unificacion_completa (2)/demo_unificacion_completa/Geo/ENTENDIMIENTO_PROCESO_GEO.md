# Entendimiento — Proceso Geo (Reconocer ↔ ArcGIS)

> Documento de contexto para conversación e implementación futura.  
> **Fecha:** 2026-07-02 · **Fuentes:** PDFs en carpeta `Geo/`

---

## 1. Propósito y alcance

El **enriquecimiento geográfico** es una etapa del pipeline Reconocer Master Cloud que toma direcciones físicas estandarizadas, las geocodifica vía **ArcGIS Enterprise**, enriquece atributos espaciales (barrio, estrato, DANE, distancias a POI, etc.) y devuelve los resultados a **Redshift Reconocer** para actualizar las tablas del DW.

El proceso se ejecuta en **horario valle** (EventBridge → Step Functions) para no competir con otros productos que usan la plataforma ArcGIS.

### Nuestra labor (lado Reconocer)

| # | Responsabilidad | Descripción |
|---|-----------------|-------------|
| 1 | **Generar INPUT** | UNLOAD desde Redshift del delta geo hacia `s3://<bucket-arcgis>/reconocer_input/` |
| 2 | **Consumir OUTPUT** | Leer los archivos que ArcGIS deja en `s3://<bucket-arcgis>/reconocer_output/`, COPY a staging y UPDATE/UPSERT en tablas destino |

ArcGIS, Step Functions y Lambdas gestionan geocodificación, enriquecimiento PostGIS y notificación SQS. No es código nuestro, pero debemos cumplir los **contratos de archivo** y alinearnos con la orquestación.

---

## 2. Diagrama de flujo end-to-end

```mermaid
flowchart LR
  subgraph reconocer [Cuenta Reconocer]
    RS[Redshift Batch]
    UNLOAD[UNLOAD delta geo]
    SF[Step Functions Enrichment]
    RT[Lambda ResultTransfer]
    STG[adf_stages staging]
    DEST[Tablas destino geo]
  end
  subgraph arcgis [Cuenta ArcGIS]
    S3IN["S3 /reconocer_input"]
    AGS[ArcGIS Server]
    AUR[Aurora PostGIS]
    S3OUT["S3 /reconocer_output"]
    SQS[SQS completion]
  end
  RS --> UNLOAD --> S3IN
  SF -->|InvokeArcGis| AGS
  S3IN --> AGS --> AUR
  AUR --> S3OUT
  AGS --> SQS
  SQS --> SF
  S3OUT --> RT --> STG --> DEST
```

**Secuencia resumida:**

1. Redshift exporta delta geo (UNLOAD) → S3 `reconocer_input`
2. Step Functions invoca ArcGIS Server con `batch_id` y ruta de archivos
3. ArcGIS geocodifica, carga Aurora PostgreSQL + PostGIS, ejecuta enriquecimiento espacial
4. ArcGIS exporta resultados → S3 `reconocer_output` y publica mensaje SQS de completitud
5. Lambda `ResultTransfer` copia (cross-account si aplica), COPY a staging Redshift, UPDATE tablas destino

---

## 3. Responsabilidades Reconocer vs ArcGIS

| Actividad | Reconocer | ArcGIS |
|-----------|-----------|--------|
| Seleccionar delta de ubicaciones | Sí (UNLOAD) | — |
| Exportar CSV pipe-delimited GZIP | Sí | — |
| Geocodificar direcciones | — | Sí |
| Enriquecimiento espacial (ST_Intersects) | — | Sí (Aurora PostGIS) |
| Calcular distancias a POI | — | Sí |
| Generar archivos de salida | — | Sí |
| Orquestar flujo (Step Functions, SQS) | Sí (cuenta Reconocer) | Callback SQS |
| COPY + UPDATE en Redshift | Sí | — |

---

## 4. INPUT — Unload Delta Geo (responsabilidad #1)

**Documento fuente:** `Insumo GEO_...835.pdf` — Runbook técnico *Unload Delta Geo — Enriquecimiento Geográfico*

### Destino y naming

| Parámetro | Valor |
|-----------|-------|
| Ruta S3 | `s3://<bucket-arcgis>/reconocer_input/` |
| Patrón nombre | `delta_geo_<lote>_<timestamp>.csv.gz` |
| Máximo registros | **850.000** por ejecución |

### Columnas (exactamente 5)

| # | Columna | Tipo lógico | Longitud estimada | Observaciones |
|---|---------|-------------|-------------------|---------------|
| 1 | `cod_dw_ubic` | BIGINT / VARCHAR | 10–15 (máx. 20) | PK lógica — ID ubicación en DW |
| 2 | `lote` | VARCHAR / INT | 5–10 (máx. 15) | Identificador del batch |
| 3 | `DIRECCION` | VARCHAR | 80–120 (máx. 250) | Dirección completa — campo dominante en tamaño |
| 4 | `MUNICIPIO` | VARCHAR | 15–25 (máx. 50) | Nombre del municipio |
| 5 | `DEPARTAMENTO` | VARCHAR | 12–20 (máx. 40) | Nombre del departamento |

### Formato de archivo

| Atributo | Valor |
|----------|-------|
| Formato | CSV delimitado por pipe (`\|`) |
| Encoding | UTF-8 |
| Compresión | GZIP (`.csv.gz`) |
| Cabecera | Sí (primera línea con nombres de columna) |
| NULL | Cadena vacía o `\N` (definir estándar único) |

**Ejemplo de registro:**

```
1234567890|LOTE20260702|CARRERA 7 # 45-67 BARRIO CENTRO|BOGOTA D.C.|CUNDINAMARCA
```

### Tamaño estimado (850K registros)

| Escenario | Sin comprimir | Con GZIP (~70%) |
|-----------|---------------|-----------------|
| Promedio (~161 B/reg) | ~130 MB | ~40 MB |
| P95 (~266 B/reg) | ~215 MB | ~65 MB |
| Máximo (~381 B/reg) | ~309 MB | ~93 MB |

### Script UNLOAD de referencia

```sql
UNLOAD ('SELECT cod_dw_ubic, lote, DIRECCION, MUNICIPIO, DEPARTAMENTO
         FROM <tabla_delta>
         WHERE <filtro_delta>
         LIMIT 850000')
TO 's3://<bucket>/reconocer_input/delta_geo_'
IAM_ROLE 'arn:aws:iam::<account>:role/<role>'
DELIMITER '|'
ADDQUOTES
GZIP
HEADER
MAXFILESIZE 128 MB
PARALLEL OFF
ALLOWOVERWRITE;
```

| MAXFILESIZE | Cuándo usar |
|-------------|-------------|
| **128 MB** (recomendado) | Un archivo en caso típico (~40 MB gzip); P95 genera 2 partes manejables |
| 256 MB | Si se prefiere un único archivo incluso en escenario máximo |
| 6.2 GB (default Redshift) | **No recomendado** — demasiado grande para ArcGIS Server |

### Parámetros SSM sugeridos

| Parámetro | Valor |
|-----------|-------|
| `/geo-enrichment/max-records` | 850000 |
| `/geo-enrichment/maxfilesize-mb` | 128 |
| `/geo-enrichment/s3-prefix` | reconocer_input/ |
| `/geo-enrichment/delimiter` | \| |
| `/geo-enrichment/compression` | GZIP |

### Validación pre-UNLOAD

```sql
-- Conteo (debe ser <= 850000)
SELECT COUNT(*) AS total_registros
FROM <tabla_delta>
WHERE <filtro_delta>;

-- Estimar tamaño real
SELECT
  COUNT(*) AS registros,
  SUM(LEN(cod_dw_ubic::VARCHAR) + LEN(lote::VARCHAR) +
      LEN(DIRECCION) + LEN(MUNICIPIO) + LEN(DEPARTAMENTO) + 6) AS bytes_estimados,
  ROUND(bytes_estimados / 1024.0 / 1024.0, 2) AS mb_estimados
FROM <tabla_delta>
WHERE <filtro_delta>;
```

---

## 5. OUTPUT — Archivos de salida ArcGIS (responsabilidad #2)

**Documento fuente:** `Salida Geo_...837.pdf` — Runbook técnico *Reconocer Output — Archivos de Salida ArcGIS*

Tras procesar el lote, ArcGIS genera **exactamente 2 archivos** en `s3://<bucket-arcgis>/reconocer_output/`.

### Archivo 1 — Georeferenciación

| Atributo | Valor |
|----------|-------|
| Patrón nombre | `geo_result_<lote>_<timestamp>.csv.gz` |
| Relación | **1:1** (1 registro entrada = 1 registro salida) |
| Columnas | **32** |
| Clave lógica | `Cod_DW_Ubic` + `Lote` |
| `Descripcion_Proceso` | Fijo: `GEOCODE` |
| Acción Redshift | UPDATE atributos geo en tabla destino |

#### Columnas principales

| # | Columna | Tipo Redshift | Nullable | Observaciones |
|---|---------|---------------|----------|---------------|
| 1 | Cod_DW_Ubic | INTEGER | NOT NULL | PK lógica |
| 2 | Lote | VARCHAR(100) | NOT NULL | Batch de enriquecimiento |
| 3 | Direccion | VARCHAR(100) | NULL | Dirección original |
| 4 | Cod_Dane_Ciudad | VARCHAR(20) | NULL | Código DANE municipio |
| 5 | Descripcion_Proceso | VARCHAR(20) | NOT NULL | `GEOCODE` |
| 6 | Zona | VARCHAR(50) | NULL | Urbano / Rural |
| 7 | Barrio | VARCHAR(100) | NULL | Barrio geocodificado |
| 8 | Localidad_Comuna | VARCHAR(100) | NULL | Localidad o comuna |
| 9 | Estrato | VARCHAR(20) | NULL | Estrato socioeconómico |
| 10 | Score | VARCHAR(100) | NULL | Score de match (0.0 – 100.0) |
| 11 | Side | VARCHAR(20) | NULL | Lado de la vía: L / R |
| 12 | **Latitud** | VARCHAR(100) | NULL | Coordenada geocodificada (texto) |
| 13 | **Longitud** | VARCHAR(100) | NULL | Coordenada geocodificada (texto) |
| … | … | … | … | Segmento, Tipo_Via, Marca_Geo, etc. |
| 26 | **Status** | VARCHAR(20) | NOT NULL | **M** = Match, **U** = Unmatched |
| 27 | Match_Addr | VARCHAR(400) | NULL | Dirección matcheada por ArcGIS |

**Regla de negocio — Status:**

| Status | Acción |
|--------|--------|
| **M** (Match) | Actualizar atributos geo (lat, long, barrio, estrato, etc.) |
| **U** (Unmatched) | Actualizar status; conservar coordenadas previas o NULL |

### Archivo 2 — Distancias

| Atributo | Valor |
|----------|-------|
| Patrón nombre | `distancias_result_<lote>_<timestamp>.csv.gz` |
| Relación | **1:N** (1 ubicación = N filas, una por POI) |
| Columnas | **12** |
| Clave lógica | `Cod_DW_Ubic` + `Tipo_Punto_Interes` + `Cod_Punto_Interes_Host` |
| `Descripcion_Proceso` | Fijo: `DISTANCIAS` |
| Acción Redshift | DELETE + INSERT delta por lote |

#### Columnas

| # | Columna | Tipo Redshift | Observaciones |
|---|---------|---------------|---------------|
| 1 | Cod_DW_Ubic | BIGINT | FK — join con georeferenciación |
| 2 | Lote | INTEGER | Numérico (distinto al VARCHAR del archivo geo) |
| 3 | Direccion | VARCHAR(100) | Dirección de la ubicación |
| 4 | Latitud | DECIMAL(38,8) | Coordenada numérica origen |
| 5 | Longitud | DECIMAL(38,8) | Coordenada numérica origen |
| 6 | Descripcion_Proceso | VARCHAR(20) | `DISTANCIAS` |
| 7 | Tipo_Punto_Interes | VARCHAR(100) | Ej: Cajeros, Bancos, Restaurante |
| 8 | Nombre_Punto_Interes | VARCHAR(200) | POI más cercano |
| 9 | Latitud_Punto_Interes | DECIMAL(38,8) | Latitud del POI |
| 10 | Longitud_Punto_Interes | DECIMAL(38,8) | Longitud del POI |
| 11 | Distancia_Punto_Interes | INTEGER | Distancia en **metros** |
| 12 | Cod_Punto_Interes_Host | VARCHAR(20) | ID del POI en sistema host |

**Tipos de POI de referencia:** Cajeros, Bancos, Oficinas de Gobierno, Restaurante, entre otros configurados en ArcGIS.

### Formato común (ambos archivos)

| Atributo | Valor |
|----------|-------|
| Delimitador | Pipe (`\|`) |
| Encoding | UTF-8 |
| Compresión | GZIP |
| Cabecera | Sí — nombres exactos de columna |
| NULL | Cadena vacía o literal `null` |
| Decimal | Punto (`.`) como separador — ej: `4.62291939` |

---

## 6. Carga en Redshift — Flujo de actualización

### Pipeline de carga

```
COPY → staging tables → Validar conteos/joins → UPDATE geo (1:1) → UPSERT distancias (1:N)
```

| Archivo | Tabla staging | Operación destino | Clave de join |
|---------|---------------|-------------------|--------------|
| Georeferenciación | `adf_stages.stg_arcgis_georeferenciacion` | UPDATE | `Cod_DW_Ubic` |
| Distancias | `adf_stages.stg_arcgis_distancias` | DELETE + INSERT | `Cod_DW_Ubic` + `Tipo_Punto_Interes` + `Cod_Punto_Interes_Host` |

### Atributos actualizados desde Georeferenciación

`Zona`, `Barrio`, `Localidad_Comuna`, `Estrato`, `Score`, `Latitud`, `Longitud`, `Cod_Dane_Ciudad`, `Cod_Dane_Dpto`, `Cod_Postal`, `Cod_Manzana`, `Status`, `Match_Addr`, `Marca_Geo`, `ArcStreet`, `ArcZone`, entre otros.

### COPY de referencia

```sql
COPY adf_stages.stg_arcgis_georeferenciacion
FROM 's3://<bucket>/reconocer_output/geo_result_<lote>_'
IAM_ROLE 'arn:aws:iam::<account>:role/<role>'
DELIMITER '|' GZIP IGNOREHEADER 1
EMPTYASNULL BLANKSASNULL
ACCEPTINVCHARS TRUNCATECOLUMNS
COMPUPDATE OFF STATUPDATE OFF;

COPY adf_stages.stg_arcgis_distancias
FROM 's3://<bucket>/reconocer_output/distancias_result_<lote>_'
IAM_ROLE 'arn:aws:iam::<account>:role/<role>'
DELIMITER '|' GZIP IGNOREHEADER 1
EMPTYASNULL BLANKSASNULL
ACCEPTINVCHARS TRUNCATECOLUMNS
COMPUPDATE OFF STATUPDATE OFF;
```

### UPDATE de referencia (georeferenciación)

```sql
UPDATE <tabla_destino> d
SET
  zona = s.zona,
  barrio = s.barrio,
  localidad_comuna = s.localidad_comuna,
  estrato = s.estrato,
  score_geo = s.score,
  latitud = s.latitud,
  longitud = s.longitud,
  cod_dane_ciudad = s.cod_dane_ciudad,
  cod_dane_dpto = s.cod_dane_dpto,
  cod_postal = s.cod_postal,
  cod_manzana = s.cod_manzana,
  status_geo = s.status,
  match_addr = s.match_addr,
  marca_geo = s.marca_geo,
  fecha_enriquecimiento = GETDATE()
FROM adf_stages.stg_arcgis_georeferenciacion s
WHERE d.cod_dw_ubic = s.cod_dw_ubic
  AND s.lote = :lote_actual
  AND s.descripcion_proceso = 'GEOCODE';
```

### Validaciones post-COPY

| Validación | Criterio esperado |
|------------|-------------------|
| Conteo georeferenciación | = registros enviados en delta geo |
| Conteo distancias | >= conteo geo |
| Ubicaciones geo sin distancia | **0 filas** |
| Status válidos | Solo `M` y/o `U` |
| PK presente | `Cod_DW_Ubic IS NOT NULL` en ambos archivos |
| Lote consistente | Mismo `Lote` en geo y distancias del batch |
| Distancia >= 0 | `Distancia_Punto_Interes >= 0` (metros) |

**Orquestación:** SQS notifica finalización; `ResultTransfer` ejecuta COPY **solo si ambos archivos existen**.

---

## 7. Orquestación — Arquitectura To-Be (HLD)

**Documento fuente:** `Reconocer Master Cloud - Etapa d_...486.pdf` — HLD aprobado (COAR-1345, Jira COAR-1345)

**Dependencia crítica:** ArcGIS Enterprise **11.5** + Aurora PostgreSQL **16.x** + PostGIS **3.4** (COAR-1315).

### Componentes

| Componente | Cuenta | Función |
|------------|--------|---------|
| **EventBridge Scheduler** | Reconocer | Dispara Step Functions según ventana horaria ArcGIS |
| **Step Functions Enrichments** | Reconocer | Orquesta flujo completo (timeout ~8h) |
| **ArcGISInvoker Lambda** | Reconocer | POST a ArcGIS Enterprise con batch_id y ruta archivos |
| **ArcGIS Enterprise** | ArcGIS | Geocodifica, escribe Aurora, publica SQS al terminar |
| **geo-completion-queue SQS** | Reconocer | Callback: batch_id, status, métricas |
| **CompletionHandler Lambda** | Reconocer | `SendTaskSuccess` / `SendTaskFailure` a Step Functions |
| **EnrichmentExecutor Lambda** | Reconocer | Ejecuta SP `geo_enrich_batch` en Aurora (ST_Intersects) |
| **DataExtractor Lambda** | Reconocer | `aws_s3.query_export_to_s3()` desde Aurora |
| **ResultTransfer Lambda** | Reconocer | Copia cross-account ArcGIS→Reconocer + COPY Redshift |
| **GeoEnrichmentBatchState DynamoDB** | Reconocer | Trazabilidad por batch_id |
| **Triggers_reconocer S3** | Reconocer | Prefijo donde Redshift consume resultados |
| **Aurora PostgreSQL + PostGIS** | ArcGIS | Geocodificación + enriquecimiento espacial |

### Estados DynamoDB (GeoEnrichmentBatchState)

```
pending
  → geocodificacion_en_curso
  → geocodificacion_completada
  → enriquecimiento_en_curso
  → enriquecimiento_completado
  → extraccion_completada
  (o fallido)
```

### Enriquecimiento espacial en Aurora (SP `geo_enrich_batch`)

Por cada capa temática, ejecuta `ST_Intersects` sobre puntos geocodificados del batch:

- Estrato (`capa_estratos`)
- Barrio (`capa_barrios`)
- Comuna/Localidad (`capa_comunas`)
- Municipio + DANE (`capa_municipios`)
- Departamento (`capa_departamentos`)

**Performance estimada (con índices GiST):**

| Volumen | Capas | Tiempo |
|---------|-------|--------|
| 800K registros | 5 | 1–2 min |
| 3M registros | 5 | 4–8 min |

### Mensaje SQS de completitud (ArcGIS → Reconocer)

```json
{
  "batch_id": "uuid",
  "status": "completed|failed",
  "records_geocoded": ____ ,
  "records_no_match": ____ ,
  "records_error": ____
}
```

### Nota cross-account

- Cuenta ArcGIS es **distinta** a Reconocer.
- Rol Reconocer requiere `s3:PutObject` (input) y `s3:GetObject` (output) vía bucket policy o rol cross-account.
- `aws_s3.query_export_to_s3()` no exporta directamente a bucket en otra cuenta → `ResultTransfer` copia de staging ArcGIS a bucket Reconocer.

---

## 8. Integración con Unificación — Regla 3 (R3)

### Demo actual (este repositorio)

En la demo/benchmark, R3 **no calcula** coordenadas. Las **consume** de `ubicacion_estandarizada`:

```sql
-- 10_regla3_geo.sql (PASO 1)
ubi.latitud,
ubi.longitud,
```

| Aspecto | Demo | Producción |
|---------|------|------------|
| Origen coords | INSERT mock en `01_demo_setup.sql` | Proceso Geo (ArcGIS) → UPDATE tablas destino |
| Tabla `relacion_ubicac_estandar_geo` | Existe, **no se usa** en R3 | Por confirmar uso productivo |
| Uso en R3 | Presencia binaria: `latitud`/`longitud` ≠ NULL y ≠ 0 | Igual — desempate por “tiene geo” |
| Distancias POI | No consumidas por R3 | Atributo enriquecido adicional (otros procesos) |

### Cómo R3 usa las coordenadas

R3 busca pares de direcciones de la misma persona con variación en **vía generadora** o **puerta ±2**. Al desempatar:

1. **Geo** — gana quien tiene lat/long (presencia, no distancia GPS)
2. **Fecha** — si ninguno tiene geo, gana el reporte más reciente
3. **Diccionario vía** — si ambos tienen geo (o empate fecha), gana vía más frecuente en catálogo

### Implicación para el pipeline productivo

```
… → Estandarización/Split → [Proceso Geo] → Unificación (R1 → R2 → R3) → Ordenamiento → …
```

El proceso Geo debe poblar/actualizar las tablas que alimentan `ubicacion_estandarizada` (o equivalente productivo) **antes** de que R3 corra en el batch de Unificación.

El batch de Unificación (Master Cloud) además tiene un UNLOAD separado como **trigger para ordenamiento** — distinto del delta geo, pero parte del mismo proceso batch.

---

## 9. Ambientes AWS y parámetros

### Cuentas Reconocer (Account IDs)

| Ambiente | Account ID |
|----------|------------|
| PROD | 696708350333 |
| UAT | 453645298399 |
| TEST | 667397050561 |
| DEV | 647096294147 |

Nombres exactos de bucket y rol IAM deben completarse según nomenclatura del proyecto.

### Parámetros SSM — Output (Salida Geo)

| Parámetro | Valor |
|-----------|-------|
| `/geo-enrichment/output-s3-prefix` | reconocer_output/ |
| `/geo-enrichment/geo-file-pattern` | geo_result_* |
| `/geo-enrichment/dist-file-pattern` | distancias_result_* |
| `/geo-enrichment/stg-geo-table` | adf_stages.stg_arcgis_georeferenciacion |
| `/geo-enrichment/stg-dist-table` | adf_stages.stg_arcgis_distancias |
| `/geo-enrichment/delimiter` | \| |

---

## 10. Referencias en carpeta Geo/

| Archivo | Contenido |
|---------|-----------|
| `Insumo GEO_9a4955abd80f431ea904d35261067d68-020726-2015-835.pdf` | Runbook INPUT: UNLOAD delta, columnas, MAXFILESIZE, ambientes |
| `Salida Geo_9730ed5886d840409f8d25de0e175b28-020726-2020-837.pdf` | Runbook OUTPUT: 2 archivos, DDL staging, COPY, UPDATE, validaciones |
| `Reconocer Master Cloud - Etapa d_a5383b4c4823491383bab1fdeb36bd5e-020726-1343-486.pdf` | HLD To-Be: Step Functions, Lambdas, Aurora PostGIS, DynamoDB, riesgos |

---

## 11. Gaps y preguntas abiertas

| # | Tema | Detalle |
|---|------|---------|
| 1 | **Definición del delta** | Los PDFs no especifican el filtro SQL de qué ubicaciones entran al UNLOAD (ej. `marca_geo IS NULL`, cambios desde último lote, etc.) |
| 2 | **Tabla destino productiva** | El runbook usa placeholder `<tabla_destino>` — confirmar nombre y esquema real en Redshift |
| 3 | **Orden en pipeline batch** | Geo vs Unificación vs Ordenamiento; relación entre UNLOAD delta geo y UNLOAD trigger ordenamiento |
| 4 | **Demo/benchmark** | Simular flujo con archivos pipe-delimited vs seguir INSERT directo de lat/long en `01_demo_setup.sql` |
| 5 | **Nomenclatura IAM/S3** | Completar nombres finales de buckets y roles cross-account |
| 6 | **`relacion_ubicac_estandar_geo`** | Uso productivo vs `ubicacion_estandarizada.latitud/longitud` directo |

---

## 12. Criterios de aceptación consolidados

### INPUT (UNLOAD)

- [ ] Exactamente 5 columnas: `cod_dw_ubic`, `lote`, `DIRECCION`, `MUNICIPIO`, `DEPARTAMENTO`
- [ ] Máximo 850.000 registros por ejecución
- [ ] Formo CSV pipe, UTF-8, GZIP, con cabecera
- [ ] `MAXFILESIZE 128 MB`
- [ ] Destino: `s3://.../reconocer_input/`
- [ ] Funciona en PROD, UAT, TEST, DEV
- [ ] Step Function valida que el archivo llegó antes de invocar ArcGIS

### OUTPUT (COPY + UPDATE)

- [ ] ArcGIS genera 2 archivos por lote en `/reconocer_output`
- [ ] Geo: 32 columnas, 1:1, `Descripcion_Proceso = GEOCODE`
- [ ] Distancias: 12 columnas, 1:N, `Descripcion_Proceso = DISTANCIAS`
- [ ] SQS notifica finalización; `ResultTransfer` COPY solo si ambos archivos existen
- [ ] COPY a staging → UPDATE geo + UPSERT distancias
- [ ] Validación: conteo geo = entrada; toda ubicación geo tiene ≥1 distancia

---

*© Contexto interno Experian Colombia — Enriquecimiento Geográfico Reconocer Master Cloud*
