-- ============================================================
-- 08_regla2_esc5.sql
-- Regla 2 Escenario 5: Nomenclaturas diferentes, diferente nivel
-- Fuente Teradata: PRO_UnificacionR2.sql líneas 2250-4011
-- ============================================================
-- NOTA: Para demo paso a paso (un script = una ejecución completa)
--       usar: 08a_regla2_esc5_prepara.sql → 06 → 08b_regla2_esc5_finaliza.sql
--       Ver GUION_DEMO_VIDEO_v2.md
-- ============================================================
-- Prerequisito: 07_regla2_esc3_nit.sql ejecutado (stg_regla2_e2 actualizado)
--
-- Subcaso 1: Valores diferentes → MOTOR genera nueva dirección
--   P09: TO 3 (nivel 4) + AP 504 (nivel 7) → "TO 3 AP 504"
-- Subcaso 2: Valores iguales → diccionario, mayor frecuencia = padre
--   P10: TO 3 (nivel 4, freq=12) vs AP 3 (nivel 7, freq=4) → padre = TO 3
-- ============================================================

-- ============================================================
-- PASO 1: Filtrar no-unificados con complemento diferente
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05;
CREATE TABLE bdm_stage.stg_regla2_e05
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') A
JOIN (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.complemento              <> B.complemento;

ANALYZE bdm_stage.stg_regla2_e05;

-- ============================================================
-- PASO 2: Identificar nomenclaturas de cada complemento
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_a;
CREATE TABLE bdm_stage.stg_regla2_e05_a
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT
  A.*,
  NMC1.nomenclatura AS nomenclatura_pri,
  NMC1.nivel_complemento AS nivel_pri,
  NMC2.nomenclatura AS nomenclatura_sec,
  NMC2.nivel_complemento AS nivel_sec,
  TRIM(REPLACE(REPLACE(A.complemento, COALESCE(NMC1.nomenclatura,''), ''), COALESCE(NMC2.nomenclatura,''), '')) AS complemento2
FROM bdm_stage.stg_regla2_e05 A
LEFT JOIN bdm_stage.nomenclatura NMC1
  ON A.complemento LIKE TRIM(NMC1.nomenclatura) || ' %'
LEFT JOIN bdm_stage.nomenclatura NMC2
  ON A.complemento LIKE '% ' || TRIM(NMC2.nomenclatura) || ' %'
  AND NMC2.nomenclatura <> COALESCE(NMC1.nomenclatura, '');

ANALYZE bdm_stage.stg_regla2_e05_a;

-- ============================================================
-- PASO 3: Filtrar pares donde nomenclaturas están en DIFERENTE nivel
-- Caso 1: misma nomenclatura primaria, ≠ secundaria, ≠ nivel secundario
-- Caso 2: ≠ nomenclatura primaria, misma secundaria, ≠ nivel primario
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_c;
CREATE TABLE bdm_stage.stg_regla2_e05_c
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT * FROM (
  SELECT DISTINCT A.*
  FROM bdm_stage.stg_regla2_e05_a A
  JOIN bdm_stage.stg_regla2_e05_a B
    ON  A.id_buro_persona          = B.id_buro_persona
    AND A.texto_ubicacion           = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
    AND A.cod_dw_municipio          = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
    AND A.complemento              <> B.complemento
    AND (A.complemento2 NOT LIKE '%' || B.complemento2 || '%'
         OR B.complemento2 NOT LIKE '%' || A.complemento2 || '%')
    AND A.nomenclatura_pri = B.nomenclatura_pri
    AND COALESCE(A.nomenclatura_sec, 'X') <> COALESCE(B.nomenclatura_sec, 'X')
    AND COALESCE(A.nivel_sec, 0) <> COALESCE(B.nivel_sec, 0)

  UNION

  SELECT DISTINCT A.*
  FROM bdm_stage.stg_regla2_e05_a A
  JOIN bdm_stage.stg_regla2_e05_a B
    ON  A.id_buro_persona          = B.id_buro_persona
    AND A.texto_ubicacion           = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
    AND A.cod_dw_municipio          = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
    AND A.complemento              <> B.complemento
    AND (A.complemento2 NOT LIKE '%' || B.complemento2 || '%'
         OR B.complemento2 NOT LIKE '%' || A.complemento2 || '%')
    AND A.nomenclatura_pri <> B.nomenclatura_pri
    AND COALESCE(A.nomenclatura_sec, 'X') = COALESCE(B.nomenclatura_sec, 'X')
    AND A.nivel_pri <> B.nivel_pri
) sub;

ANALYZE bdm_stage.stg_regla2_e05_c;

-- ============================================================
-- PASO 4: Separar subcaso 1 (valores ≠) y subcaso 2 (valores =)
-- Subcaso 1: complemento2 diferentes → va al motor
-- Subcaso 2: complemento2 iguales → diccionario
-- ============================================================

-- Subcaso 1: pares con valores diferentes → motor
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub1;
CREATE TABLE bdm_stage.stg_regla2_e05_sub1
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM bdm_stage.stg_regla2_e05_c A
JOIN bdm_stage.stg_regla2_e05_c B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.complemento              <> B.complemento
  AND TRIM(A.complemento2) <> TRIM(B.complemento2);

ANALYZE bdm_stage.stg_regla2_e05_sub1;

-- ============================================================
-- PASO 5: SUBCASO 1 — Preparar motor input y ejecutar
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
CREATE TABLE bdm_stage.stg_motor_input
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  e.cod_dw_persona_ubic, e.cod_dw_ubic, e.complemento, e.id_buro_persona,
  e.cod_dw_tipo_ubicacion_dir, rpu.cod_pin_persona, rpu.cod_dw_direccion_fisica,
  e.texto_ubicacion, e.fecha_relacion_persona_ubicaci
FROM bdm_stage.stg_regla2_e05_sub1 e
JOIN bdm_stage.relacion_persona_ubicacion rpu
  ON e.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

ANALYZE bdm_stage.stg_motor_input;

-- >>> EJECUTAR 06_motor_nuevas_direcciones.sql AQUÍ <<<

-- Post-motor: actualizar E2 para subcaso 1
-- Hijo MDIR
UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'M5', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
JOIN bdm_stage.stg_motor_hijo h
  ON h.cod_dw_ubic = f.cod_dw_ubic AND h.id_buro_persona = f.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = f.cod_dw_tipo_ubicacion_dir
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = h.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N';

-- Padre MDIR original también es hijo del nuevo padre
UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'M5', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = f.cod_dw_persona_ubic_padre
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N';

-- Insertar nueva dirección generada en E2
INSERT INTO bdm_stage.stg_regla2_e2 (
  cod_dw_persona_ubic, id_padre, id_buro_persona, cod_dw_tipo_ubicacion_dir,
  cod_dw_ubic, texto_ubicacion, cod_dw_direccion_fisica, complemento,
  ind_unificacion, n_id
)
SELECT f.new_cod_dw_persona_ubic, NULL, f.id_buro_persona, f.cod_dw_tipo_ubicacion_dir,
  f.cod_dw_ubic, f.texto_ubicacion, f.new_cod_dw_direccion_fisica, f.nuevo_complemento,
  'N', NULL
FROM bdm_stage.stg_motor_final f;

-- ============================================================
-- PASO 6: SUBCASO 2 — Valores iguales, diccionario decide padre
-- Misma lógica que escenario 4: frecuencia + fecha = score
-- ============================================================

-- Filtrar pares con valores iguales que NO fueron al motor
-- Filtro directo desde E05_A (no desde E05_C, que excluye valores iguales)
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2;
CREATE TABLE bdm_stage.stg_regla2_e05_sub2
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM bdm_stage.stg_regla2_e05_a A
JOIN bdm_stage.stg_regla2_e05_a B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.complemento              <> B.complemento
  AND TRIM(A.complemento2) = TRIM(B.complemento2)
  AND A.nivel_pri <> B.nivel_pri
WHERE A.cod_dw_persona_ubic NOT IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e05_sub1);

ANALYZE bdm_stage.stg_regla2_e05_sub2;

-- Sumar frecuencias del diccionario
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_freq;
CREATE TABLE bdm_stage.stg_regla2_e05_sub2_freq
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT t1.cod_dw_persona_ubic, COALESCE(t2.conteo, 0) AS conteo
FROM bdm_stage.stg_regla2_e05_sub2 t1
LEFT JOIN (
  SELECT t1.cod_dw_persona_ubic, SUM(dc.frecuencia) AS conteo
  FROM bdm_stage.stg_regla2_e05_sub2 t1
  LEFT JOIN bdm_stage.diccionario_complementos dc
    ON t1.cod_dw_ubic = dc.cod_dw_ubic
    AND t1.complemento LIKE '%' || dc.nomenclatura || '%'
    AND t1.id_buro_persona = dc.id_buro_persona
  GROUP BY 1
) t2 ON t1.cod_dw_persona_ubic = t2.cod_dw_persona_ubic;

ANALYZE bdm_stage.stg_regla2_e05_sub2_freq;

-- Score y ranking
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_d;
CREATE TABLE bdm_stage.stg_regla2_e05_sub2_d
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT u1.*,
  COUNT(*) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id) AS count_empate,
  MAX(id) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio) AS idmax
FROM (
  SELECT a.cod_dw_persona_ubic,
    (COALESCE(b.conteo, 0) + 10000000)
      + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0) AS id,
    a.texto_ubicacion, a.id_buro_persona, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio,
    a.cod_dw_ubic, a.complemento,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
      ORDER BY (COALESCE(b.conteo, 0) + 10000000)
        + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0)
    ) AS orden
  FROM bdm_stage.stg_regla2_e05_sub2 a
  LEFT JOIN bdm_stage.stg_regla2_e05_sub2_freq b ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
) u1;

ANALYZE bdm_stage.stg_regla2_e05_sub2_d;

-- Generar pares padre-hijo
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_e;
CREATE TABLE bdm_stage.stg_regla2_e05_sub2_e
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT B.cod_dw_persona_ubic, A.cod_dw_persona_ubic AS id_padre
FROM bdm_stage.stg_regla2_e05_sub2_d A
JOIN bdm_stage.stg_regla2_e05_sub2_d B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.id > B.id
JOIN (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, MAX(orden) AS max_orden
  FROM bdm_stage.stg_regla2_e05_sub2_d GROUP BY 1,2,3,4
) mx ON A.id_buro_persona = mx.id_buro_persona AND A.texto_ubicacion = mx.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = mx.cod_dw_municipio
  AND A.orden = mx.max_orden;

ANALYZE bdm_stage.stg_regla2_e05_sub2_e;

-- Actualizar E2 con subcaso 2
UPDATE bdm_stage.stg_regla2_e2
SET id_padre = e.id_padre, ind_unificacion = 'S', n_id = 'D5'
FROM bdm_stage.stg_regla2_e05_sub2_e e
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = e.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.id_padre IS NULL;

-- Persistir pares subcaso 2
INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT e.cod_dw_persona_ubic, e.id_padre AS cod_dw_direccion_unificada,
  2, CURRENT_DATE, 1, 1, LEFT(CURRENT_USER, 30)
FROM bdm_stage.stg_regla2_e05_sub2_e e;

UPDATE bdm_stage.relacion_persona_ubicacion SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e05_sub2_e);

-- ============================================================
-- PASO 7: Estadísticas y limpieza
-- ============================================================
ANALYZE bdm_stage.unificacion_direccion;
ANALYZE bdm_stage.relacion_persona_ubicacion;
ANALYZE bdm_stage.stg_regla2_e2;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_a;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_c;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub1;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_freq;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_d;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_e;
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
