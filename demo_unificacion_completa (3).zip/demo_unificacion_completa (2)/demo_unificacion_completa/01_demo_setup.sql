-- ============================================================
-- 01_demo_setup.sql
-- Demo COMPLETA Unificación: R1 + R2 + R3 en cascada
-- Cubre 32+ criterios de aceptación (Kidar + Experian)
-- 19 personas diseñadas para todos los escenarios y subcasos
-- ============================================================

-- Esquema: bdm_stage (debe existir; el usuario debe tener permisos CREATE)

-- ============================================================
-- CATÁLOGOS
-- ============================================================

DROP TABLE IF EXISTS bdm_stage.tipo_ubicacion_dir;
CREATE TABLE bdm_stage.tipo_ubicacion_dir (
  cod_dw_tipo_ubicacion_dir INTEGER ENCODE AZ64,
  descripcion_tipo_ubicacion_dir VARCHAR(20) ENCODE BYTEDICT
) DISTSTYLE ALL;

INSERT INTO bdm_stage.tipo_ubicacion_dir VALUES
(1, 'RES'), (2, 'LAB'), (3, 'CRR'), (4, 'JUD'), (5, 'CCL');

-- Nomenclatura: niveles para Regla 2
DROP TABLE IF EXISTS bdm_stage.nomenclatura;
CREATE TABLE bdm_stage.nomenclatura (
  nomenclatura VARCHAR(10) ENCODE ZSTD,
  nivel_complemento INTEGER ENCODE AZ64
) DISTSTYLE ALL;

INSERT INTO bdm_stage.nomenclatura VALUES
('BR',1),('UR',1),('CJ',1),('UN',1),
('ED',2),('ZN',2),('SEC',2),
('MZ',3),('ET',3),
('TO',4),('BQ',4),
('PI',5),('CS',5),('IN',5),('BL',5),
('LC',6),('OF',6),('PL',6),
('AP',7),('GJ',7),('DP',7),('ST',7);

-- ============================================================
-- TABLAS PRINCIPALES
-- ============================================================

DROP TABLE IF EXISTS bdm_stage.ubicacion_estandarizada;
CREATE TABLE bdm_stage.ubicacion_estandarizada (
  cod_dw_ubic BIGINT ENCODE AZ64,
  texto_ubicacion VARCHAR(200) ENCODE ZSTD,
  cod_dw_ciudad INTEGER ENCODE AZ64,
  latitud DECIMAL(10,7),
  longitud DECIMAL(10,7)
) DISTSTYLE ALL SORTKEY(cod_dw_ubic);

DROP TABLE IF EXISTS bdm_stage.direccion_fisica;
CREATE TABLE bdm_stage.direccion_fisica (
  cod_dw_direccion_fisica BIGINT ENCODE AZ64,
  complemento VARCHAR(100) ENCODE ZSTD,
  cod_dw_ubic BIGINT ENCODE AZ64,
  tipo_via_principal VARCHAR(5) ENCODE ZSTD,
  via_principal VARCHAR(10) ENCODE ZSTD,
  via_generadora VARCHAR(10) ENCODE ZSTD,
  numero_puerta VARCHAR(10) ENCODE ZSTD,
  generada_enriquecida INTEGER ENCODE AZ64
) DISTSTYLE ALL SORTKEY(cod_dw_direccion_fisica);

DROP TABLE IF EXISTS bdm_stage.relacion_persona_ubicacion;
CREATE TABLE bdm_stage.relacion_persona_ubicacion (
  cod_dw_persona_ubic BIGINT ENCODE AZ64,
  id_buro_persona INTEGER ENCODE AZ64,
  cod_pin_persona INTEGER ENCODE AZ64,
  cod_dw_ubic BIGINT ENCODE AZ64,
  cod_dw_direccion_fisica BIGINT ENCODE AZ64,
  cod_dw_tipo_ubicacion_dir INTEGER ENCODE AZ64,
  ind_unificacion INTEGER ENCODE AZ64,
  orden_prioridad INTEGER ENCODE AZ64,
  fecha_relacion_persona_ubicaci DATE ENCODE AZ64,
  lote INTEGER ENCODE AZ64,
  cod_tipo_ident_fte INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, cod_dw_persona_ubic);

DROP TABLE IF EXISTS bdm_stage.ciiu_persona;
CREATE TABLE bdm_stage.ciiu_persona (
  id_buro_persona INTEGER ENCODE AZ64,
  cod_act_econo_ciiu_fte VARCHAR(10) ENCODE BYTEDICT
) DISTSTYLE KEY DISTKEY(id_buro_persona);

DROP TABLE IF EXISTS bdm_stage.reporte_relacion_persona_ubica;
CREATE TABLE bdm_stage.reporte_relacion_persona_ubica (
  cod_dw_persona_ubic BIGINT ENCODE AZ64,
  id_buro_suscriptor INTEGER ENCODE AZ64,
  fecha_reporte DATE ENCODE AZ64,
  lote INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
SORTKEY(cod_dw_persona_ubic);

DROP TABLE IF EXISTS bdm_stage.unificacion_direccion;
CREATE TABLE bdm_stage.unificacion_direccion (
  cod_dw_persona_ubic BIGINT ENCODE AZ64,
  cod_dw_direccion_unificada BIGINT ENCODE AZ64,
  unifica_atributos INTEGER ENCODE AZ64,
  fecha_unificacion DATE ENCODE AZ64,
  lote INTEGER ENCODE AZ64,
  severidad INTEGER ENCODE AZ64,
  usuario_bd VARCHAR(100) ENCODE ZSTD
) DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
SORTKEY(cod_dw_persona_ubic);

DROP TABLE IF EXISTS bdm_stage.diccionario_complementos;
CREATE TABLE bdm_stage.diccionario_complementos (
  cod_dw_ubic BIGINT ENCODE AZ64,
  id_buro_persona INTEGER ENCODE AZ64,
  nomenclatura VARCHAR(50) ENCODE ZSTD,
  nomen VARCHAR(10) ENCODE ZSTD,
  valor VARCHAR(50) ENCODE ZSTD,
  frecuencia INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(cod_dw_ubic)
SORTKEY(cod_dw_ubic, id_buro_persona);

DROP TABLE IF EXISTS bdm_stage.diccionario_via;
CREATE TABLE bdm_stage.diccionario_via (
  tipo VARCHAR(20) ENCODE ZSTD,
  llave VARCHAR(100) ENCODE ZSTD,
  via_generadora VARCHAR(10) ENCODE ZSTD,
  cod_dw_municipio INTEGER ENCODE AZ64,
  conteo INTEGER ENCODE AZ64
) DISTSTYLE ALL;

-- Tabla para geo (Regla 3)
DROP TABLE IF EXISTS bdm_stage.relacion_ubicac_estandar_geo;
CREATE TABLE bdm_stage.relacion_ubicac_estandar_geo (
  cod_dw_ubic BIGINT ENCODE AZ64,
  latitud DECIMAL(10,7),
  longitud DECIMAL(10,7)
) DISTSTYLE ALL;

-- ============================================================
-- DATOS: UBICACIONES ESTANDARIZADAS (PUERTAS)
-- ============================================================

INSERT INTO bdm_stage.ubicacion_estandarizada VALUES
-- R1: personas con misma puerta, diferente tipo uso
(5001, 'CL 45 12 33', 1, NULL, NULL),
(5002, 'KR 7 80 22', 1, NULL, NULL),
(5003, 'AK 57 SUR 63 45', 1, NULL, NULL),
-- R2: personas con misma puerta, diferente complemento
(5004, 'DG 50 30 10', 1, NULL, NULL),
(5005, 'TV 20 15 40', 1, NULL, NULL),
(5006, 'CL 22 27 45', 1, NULL, NULL),
(5007, 'KR 10 20 30', 1, NULL, NULL),
(5008, 'CL 80 55 18', 1, NULL, NULL),
(5009, 'KR 30 45 12', 1, NULL, NULL),
(5010, 'DG 70 25 88', 1, NULL, NULL),
(5019, 'CL 91 12 34', 1, NULL, NULL),                -- 2008: Esc5 subcaso 2
(5020, 'KR 55 33 22', 1, NULL, NULL),                -- 2009: Esc6 subcaso 3
(5021, 'CL 95 18 42', 1, NULL, NULL),                -- 2010: Esc4 empate (R2-14)
-- R3: personas con diferencia en vía generadora o puerta
(5011, 'CL 34 78 52', 1, 4.6097100, -74.0817500),   -- 3001: tiene geo
(5012, 'CL 34 80 52', 1, NULL, NULL),                -- 3001: sin geo
(5013, 'KR 15 45 33', 1, NULL, NULL),                -- 3002: sin geo
(5014, 'KR 15 45 35', 1, NULL, NULL),                -- 3002: sin geo
(5015, 'TV 60 20 44', 1, 4.6200000, -74.0900000),   -- 3003: tiene geo
(5016, 'TV 60 22 44', 1, 4.6201000, -74.0901000),   -- 3003: tiene geo
(5017, 'DG 90 10 50', 1, NULL, NULL),                -- 3004: sin geo
(5018, 'DG 90 10 55', 1, NULL, NULL);                -- 3004: sin geo

-- ============================================================
-- DATOS: DIRECCIONES FÍSICAS (COMPLEMENTOS)
-- ============================================================

INSERT INTO bdm_stage.direccion_fisica VALUES
-- R1: mismo complemento (vacío) para validar solo tipo uso
(6001, '', 5001, 'CL', '45', '12', '33', NULL),
(6002, '', 5002, 'KR', '7', '80', '22', NULL),
(6003, '', 5003, 'AK', '57', '63', '45', NULL),
-- R2: complementos diferentes por escenario
(6004, '', 5004, 'DG', '50', '30', '10', NULL),          -- 2001-A: vacío
(6005, 'AP 802', 5004, 'DG', '50', '30', '10', NULL),    -- 2001-B: informado
(6006, 'AP 702', 5005, 'TV', '20', '15', '40', NULL),    -- 2002-A: simple
(6007, 'ED GALICIA AP 702', 5005, 'TV', '20', '15', '40', NULL), -- 2002-B: incluye A
(6008, 'AP 105', 5006, 'CL', '22', '27', '45', NULL),    -- 2003-A: AP 105
(6009, 'AP 404', 5006, 'CL', '22', '27', '45', NULL),    -- 2003-B: AP 404
(6010, 'LC 101', 5007, 'KR', '10', '20', '30', NULL),    -- 2004-A: LC 101 (NIT)
(6011, 'LC 205', 5007, 'KR', '10', '20', '30', NULL),    -- 2004-B: LC 205 (NIT)
(6012, 'CS 5', 5008, 'CL', '80', '55', '18', NULL),       -- 2005-A: CS nivel 5
(6013, 'PI 5', 5008, 'CL', '80', '55', '18', NULL),      -- 2005-B: PI nivel 5
(6014, 'TO 3', 5009, 'KR', '30', '45', '12', NULL),      -- 2006-A: TO nivel 4
(6015, 'AP 504', 5009, 'KR', '30', '45', '12', NULL),    -- 2006-B: AP nivel 7
(6016, 'ED 2 OF 301', 5010, 'DG', '70', '25', '88', NULL),-- 2007-A: ED+OF (niv. pri 2, sec 6)
(6017, 'OF 302', 5010, 'DG', '70', '25', '88', NULL),      -- 2007-B: OF solo (cruzada; no Esc2)
(6026, 'TO 5', 5019, 'CL', '91', '12', '34', NULL),        -- 2008-A: TO nivel 4
(6027, 'PI 5', 5019, 'CL', '91', '12', '34', NULL),        -- 2008-B: PI nivel 5 (mismo valor 5)
(6028, 'LC 10 OF 200', 5020, 'KR', '55', '33', '22', NULL),-- 2009-A: LC+OF cruzada
(6029, 'OF 200', 5020, 'KR', '55', '33', '22', NULL),      -- 2009-B: OF solo (cruzada con sec de A)
(6030, 'CS 8', 5021, 'CL', '95', '18', '42', NULL),        -- 2010-A: CS nivel 5
(6031, 'PI 8', 5021, 'CL', '95', '18', '42', NULL),        -- 2010-B: PI nivel 5 (empate R2-14)
-- R3: sin complemento (Regla 3 compara puertas)
(6018, '', 5011, 'CL', '34', '78', '52', NULL),
(6019, '', 5012, 'CL', '34', '80', '52', NULL),
(6020, '', 5013, 'KR', '15', '45', '33', NULL),
(6021, '', 5014, 'KR', '15', '45', '35', NULL),
(6022, '', 5015, 'TV', '60', '20', '44', NULL),
(6023, '', 5016, 'TV', '60', '22', '44', NULL),
(6024, '', 5017, 'DG', '90', '10', '50', NULL),
(6025, '', 5018, 'DG', '90', '10', '55', NULL);

-- ============================================================
-- DATOS: CIIU POR PERSONA
-- ============================================================

INSERT INTO bdm_stage.ciiu_persona VALUES
(1001, '10'),   -- R1: Asalariado
(1002, '81'),   -- R1: Sin actividad
(1003, '55'),   -- R1: Otro CIIU
(1004, '10'),   -- R1: Empate
(1005, '82'),   -- R1: Hija previa
(2001, '10'),   -- R2: Esc 1
(2002, '10'),   -- R2: Esc 2
(2003, '55'),   -- R2: Esc 3 sin NIT
(2004, '10'),   -- R2: Esc 3 NIT
(2005, '10'),   -- R2: Esc 4
(2006, '10'),   -- R2: Esc 5
(2007, '10'),   -- R2: Esc 6 subcaso 1 (motor)
(2008, '10'),   -- R2: Esc 5 subcaso 2 (diccionario)
(2009, '10'),   -- R2: Esc 6 subcaso 3 (diccionario)
(2010, '10'),   -- R2: Esc 4 empate persistente (R2-14)
(3001, '10'),   -- R3: Dif vía gen, solo 1 con geo
(3002, '10'),   -- R3: Dif puerta, ninguna con geo
(3003, '10'),   -- R3: Dif vía gen, ambas con geo
(3004, '10');   -- R3: Dif puerta > 2 (NO unifica)

-- ============================================================
-- DATOS: RELACION_PERSONA_UBICACION
-- ============================================================

-- === REGLA 1: Misma puerta, diferente tipo uso ===
-- Persona 1001 (CIIU=10): RES vs LAB → LAB gana (R1-01)
INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
(100, 1001, 9001, 5001, 6001, 1, NULL, NULL, '2025-03-01', 1, 1),
(101, 1001, 9001, 5001, 6001, 2, NULL, NULL, '2025-06-01', 1, 1);
-- Persona 1002 (CIIU=81): LAB vs RES → RES gana (R1-02)
INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
(200, 1002, 9002, 5001, 6001, 2, NULL, NULL, '2025-04-01', 1, 1),
(201, 1002, 9002, 5001, 6001, 1, NULL, NULL, '2025-05-01', 1, 1);
-- Persona 1003 (CIIU=55): RES vs CRR → CRR gana por entidades (R1-03)
INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
(300, 1003, 9003, 5001, 6001, 1, NULL, NULL, '2025-02-01', 1, 1),
(301, 1003, 9003, 5001, 6001, 3, NULL, NULL, '2025-07-01', 1, 1);
-- Persona 1004 (CIIU=10): LAB vs CRR, EMPATE (R1-08)
INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
(400, 1004, 9004, 5002, 6002, 2, NULL, NULL, '2025-05-01', 1, 1),
(401, 1004, 9004, 5002, 6002, 3, NULL, NULL, '2025-05-01', 1, 1);
-- Persona 1005 (CIIU=82): RES ya unificada + CRR (R1-06: hija previa)
INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
(500, 1005, 9005, 5003, 6003, 1, 1, NULL, '2025-03-01', 1, 1),
(501, 1005, 9005, 5003, 6003, 3, NULL, NULL, '2025-05-01', 1, 1);

-- === REGLA 2: Misma puerta, diferente complemento ===
-- Persona 2001: Esc1 vacío vs AP 802 → gana informado (R2-01)
INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
(600, 2001, 9006, 5004, 6004, 1, NULL, NULL, '2025-04-01', 1, 1),
(601, 2001, 9006, 5004, 6005, 1, NULL, NULL, '2025-05-01', 1, 1);
-- Persona 2002: Esc2 AP 702 vs ED GALICIA AP 702 → gana el más completo (R2-02)
INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
(700, 2002, 9007, 5005, 6006, 1, NULL, NULL, '2025-03-01', 1, 1),
(701, 2002, 9007, 5005, 6007, 1, NULL, NULL, '2025-06-01', 1, 1);
-- Persona 2003: Esc3 sin NIT, AP 105 vs AP 404 → mayor entidades (R2-03)
INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
(800, 2003, 9008, 5006, 6008, 1, NULL, NULL, '2025-04-01', 1, 1),
(801, 2003, 9008, 5006, 6009, 1, NULL, NULL, '2025-05-01', 1, 1);
-- Persona 2004: Esc3 NIT, LC 101 vs LC 205 → genera nueva (R2-04)
INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
(900, 2004, 9009, 5007, 6010, 1, NULL, NULL, '2025-03-01', 1, 3),
(901, 2004, 9009, 5007, 6011, 1, NULL, NULL, '2025-04-01', 1, 3);
-- Persona 2005: Esc4 CS 5 vs PI 5 (mismo nivel 5, mismo valor) → diccionario (R2-05)
INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
(1000, 2005, 9010, 5008, 6012, 1, NULL, NULL, '2025-05-01', 1, 1),
(1001, 2005, 9010, 5008, 6013, 1, NULL, NULL, '2025-04-01', 1, 1);
-- Persona 2006: Esc5 TO 3 (nivel 4) vs AP 504 (nivel 7) → genera nueva (R2-06)
INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
(1100, 2006, 9011, 5009, 6014, 1, NULL, NULL, '2025-06-01', 1, 1),
(1101, 2006, 9011, 5009, 6015, 1, NULL, NULL, '2025-07-01', 1, 1);
-- Persona 2007: Esc6 ED 2 OF 301 vs OF 302 — cruzadas, sin Esc2 (R2-07)
INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
(1200, 2007, 9012, 5010, 6016, 1, NULL, NULL, '2025-05-01', 1, 1),
(1201, 2007, 9012, 5010, 6017, 1, NULL, NULL, '2025-06-01', 1, 1);
-- Persona 2008: Esc5 sub2 TO 5 vs PI 5 (mismo valor, distinto nivel) → diccionario
INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
(1202, 2008, 9017, 5019, 6026, 1, NULL, NULL, '2025-05-01', 1, 1),
(1203, 2008, 9017, 5019, 6027, 1, NULL, NULL, '2025-05-01', 1, 1);
-- Persona 2009: Esc6 sub3 LC 10 OF 200 vs OF 200 (cruzadas, mismo nivel) → diccionario
INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
(1204, 2009, 9018, 5020, 6028, 1, NULL, NULL, '2025-04-01', 1, 1),
(1205, 2009, 9018, 5020, 6029, 1, NULL, NULL, '2025-08-01', 1, 1);
-- Persona 2010: Esc4 CS 8 vs PI 8 — empate freq+fecha (R2-14)
INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
(1210, 2010, 9019, 5021, 6030, 1, NULL, NULL, '2025-05-01', 1, 1),
(1211, 2010, 9019, 5021, 6031, 1, NULL, NULL, '2025-05-01', 1, 1);

-- === REGLA 3: Diferencia en vía generadora o puerta ===
-- Persona 3001: Dif vía gen (78 vs 80), solo 5011 tiene geo → gana geo (R3-02)
INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
(1300, 3001, 9013, 5011, 6018, 1, NULL, NULL, '2025-04-01', 1, 1),
(1301, 3001, 9013, 5012, 6019, 1, NULL, NULL, '2025-05-01', 1, 1);
-- Persona 3002: Dif puerta (33 vs 35, ±2), ninguna con geo → fecha gana (R3-03)
INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
(1400, 3002, 9014, 5013, 6020, 1, NULL, NULL, '2025-03-01', 1, 1),
(1401, 3002, 9014, 5014, 6021, 1, NULL, NULL, '2025-08-01', 1, 1);
-- Persona 3003: Dif vía gen (20 vs 22), ambas con geo → diccionario (R3-04)
INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
(1500, 3003, 9015, 5015, 6022, 1, NULL, NULL, '2025-05-01', 1, 1),
(1501, 3003, 9015, 5016, 6023, 1, NULL, NULL, '2025-06-01', 1, 1);
-- Persona 3004: Dif puerta (50 vs 55, dif=5 >2) → NO unifica (R3-06)
INSERT INTO bdm_stage.relacion_persona_ubicacion VALUES
(1600, 3004, 9016, 5017, 6024, 1, NULL, NULL, '2025-04-01', 1, 1),
(1601, 3004, 9016, 5018, 6025, 1, NULL, NULL, '2025-05-01', 1, 1);

-- ============================================================
-- DATOS: REPORTES (entidades por dirección)
-- ============================================================

-- R1: Entidades para desempate
INSERT INTO bdm_stage.reporte_relacion_persona_ubica VALUES
(100,901,'2025-03-01',1),(100,902,'2025-03-01',1),
(101,901,'2025-06-01',1),(101,902,'2025-06-01',1),(101,903,'2025-06-01',1),(101,904,'2025-06-01',1),(101,905,'2025-06-01',1),
(200,901,'2025-04-01',1),
(201,901,'2025-05-01',1),(201,902,'2025-05-01',1),(201,903,'2025-05-01',1),(201,904,'2025-05-01',1),
(300,901,'2025-02-01',1),(300,902,'2025-02-01',1),
(301,901,'2025-07-01',1),(301,902,'2025-07-01',1),(301,903,'2025-07-01',1),(301,904,'2025-07-01',1),(301,905,'2025-07-01',1),(301,906,'2025-07-01',1),
(400,901,'2025-05-01',1),(400,902,'2025-05-01',1),(400,903,'2025-05-01',1),
(401,904,'2025-05-01',1),(401,905,'2025-05-01',1),(401,906,'2025-05-01',1),
(500,901,'2025-03-01',1),(500,902,'2025-03-01',1),
(501,901,'2025-05-01',1),(501,902,'2025-05-01',1),(501,903,'2025-05-01',1);

-- R2: Entidades para escenarios
INSERT INTO bdm_stage.reporte_relacion_persona_ubica VALUES
(600,901,'2025-04-01',1),(600,902,'2025-04-01',1),
(601,901,'2025-05-01',1),(601,902,'2025-05-01',1),(601,903,'2025-05-01',1),
(700,901,'2025-03-01',1),(700,902,'2025-03-01',1),
(701,901,'2025-06-01',1),(701,902,'2025-06-01',1),(701,903,'2025-06-01',1),(701,904,'2025-06-01',1),
(800,901,'2025-04-01',1),(800,902,'2025-04-01',1),
(801,901,'2025-05-01',1),(801,902,'2025-05-01',1),(801,903,'2025-05-01',1),(801,904,'2025-05-01',1),(801,905,'2025-05-01',1),(801,906,'2025-05-01',1),
(900,901,'2025-03-01',1),(900,902,'2025-03-01',1),(900,903,'2025-03-01',1),
(901,901,'2025-04-01',1),(901,902,'2025-04-01',1),(901,903,'2025-04-01',1),
(1000,901,'2025-05-01',1),(1000,902,'2025-05-01',1),(1000,903,'2025-05-01',1),
(1001,901,'2025-04-01',1),(1001,902,'2025-04-01',1),
(1100,901,'2025-06-01',1),(1100,902,'2025-06-01',1),
(1101,901,'2025-07-01',1),(1101,902,'2025-07-01',1),(1101,903,'2025-07-01',1),
(1200,901,'2025-05-01',1),(1200,902,'2025-05-01',1),(1200,903,'2025-05-01',1),
(1201,901,'2025-06-01',1),(1201,902,'2025-06-01',1),
(1202,901,'2025-05-01',1),(1202,902,'2025-05-01',1),(1202,903,'2025-05-01',1),
(1203,901,'2025-05-01',1),(1203,902,'2025-05-01',1),
(1204,901,'2025-04-01',1),(1204,902,'2025-04-01',1),(1204,903,'2025-04-01',1),(1204,904,'2025-04-01',1),
(1205,901,'2025-08-01',1),(1205,902,'2025-08-01',1),
(1210,901,'2025-05-01',1),(1210,902,'2025-05-01',1),
(1211,901,'2025-05-01',1),(1211,902,'2025-05-01',1);

-- R3: Entidades
INSERT INTO bdm_stage.reporte_relacion_persona_ubica VALUES
(1300,901,'2025-04-01',1),(1300,902,'2025-04-01',1),(1300,903,'2025-04-01',1),
(1301,901,'2025-05-01',1),(1301,902,'2025-05-01',1),
(1400,901,'2025-03-01',1),(1400,902,'2025-03-01',1),
(1401,901,'2025-08-01',1),(1401,902,'2025-08-01',1),(1401,903,'2025-08-01',1),(1401,904,'2025-08-01',1),
-- 3003: más reportes en 1500 (vía gen 20) que en 1501 (vía gen 22) → diccionario runtime desempata
(1500,901,'2025-05-01',1),(1500,902,'2025-05-01',1),(1500,903,'2025-05-01',1),
(1500,904,'2025-05-01',1),(1500,905,'2025-05-01',1),(1500,906,'2025-05-01',1),
(1500,907,'2025-05-01',1),(1500,908,'2025-05-01',1),
(1501,901,'2025-06-01',1),(1501,902,'2025-06-01',1),(1501,903,'2025-06-01',1),
(1600,901,'2025-04-01',1),(1600,902,'2025-04-01',1),
(1601,901,'2025-05-01',1),(1601,902,'2025-05-01',1),(1601,903,'2025-05-01',1);

-- ============================================================
-- DATOS: DICCIONARIO COMPLEMENTOS (Esc4, NIT y motor Esc5/Esc6)
-- ============================================================
-- Persona 2005: CS 5 freq=10, PI 5 freq=4 → CS gana
INSERT INTO bdm_stage.diccionario_complementos VALUES
(5008, 2005, 'CS 5', 'CS', '5', 10),
(5008, 2005, 'PI 5', 'PI', '5', 4);
-- Persona 2004 (NIT): LC 101 y LC 205 (para el motor)
INSERT INTO bdm_stage.diccionario_complementos VALUES
(5007, 2004, 'LC 101', 'LC', '101', 8),
(5007, 2004, 'LC 205', 'LC', '205', 4);
-- Persona 2006 (Esc5 motor): TO 3 y AP 504
INSERT INTO bdm_stage.diccionario_complementos VALUES
(5009, 2006, 'TO 3', 'TO', '3', 8),
(5009, 2006, 'AP 504', 'AP', '504', 4);
-- Persona 2007 (Esc6 motor): nomenclatura = complemento completo (evita LIKE ambiguo en motor)
INSERT INTO bdm_stage.diccionario_complementos VALUES
(5010, 2007, 'ED 2 OF 301', 'ED', '2', 6),
(5010, 2007, 'ED 2 OF 301', 'OF', '301', 4),
(5010, 2007, 'OF 302', 'OF', '302', 4);
-- Persona 2008 (Esc5 sub2 diccionario): TO 5 freq=15, PI 5 freq=6 → TO gana
INSERT INTO bdm_stage.diccionario_complementos VALUES
(5019, 2008, 'TO 5', 'TO', '5', 15),
(5019, 2008, 'PI 5', 'PI', '5', 6);
-- Persona 2009 (Esc6 sub3 diccionario): LC 10 OF 200 suma 28, OF 200 suma 8 → LC gana
INSERT INTO bdm_stage.diccionario_complementos VALUES
(5020, 2009, 'LC', 'LC', '10', 20),
(5020, 2009, 'OF', 'OF', '200', 8);
-- Persona 2010 (Esc4 empate R2-14): CS 8 y PI 8 freq=10, misma fecha → sin decisión
INSERT INTO bdm_stage.diccionario_complementos VALUES
(5021, 2010, 'CS 8', 'CS', '8', 10),
(5021, 2010, 'PI 8', 'PI', '8', 10);

-- ============================================================
-- DATOS: GEORREFERENCIACIÓN
-- ============================================================
-- Las coordenadas ya están en ubicacion_estandarizada directamente
-- (personas 3001-5011, 3003-5015, 3003-5016)

-- ============================================================
-- DATOS: DICCIONARIO VÍA (para R3 subcaso 3)
-- ============================================================
-- Persona 3003: vía gen 20 freq=15, vía gen 22 freq=8 → 20 gana
INSERT INTO bdm_stage.diccionario_via VALUES
('Via_Generadora', 'TV 60 44', '20', 1, 15),
('Via_Generadora', 'TV 60 44', '22', 1, 8);

-- ============================================================
-- ESTADÍSTICAS
-- ============================================================
ANALYZE bdm_stage.tipo_ubicacion_dir;
ANALYZE bdm_stage.nomenclatura;
ANALYZE bdm_stage.ubicacion_estandarizada;
ANALYZE bdm_stage.direccion_fisica;
ANALYZE bdm_stage.relacion_persona_ubicacion;
ANALYZE bdm_stage.ciiu_persona;
ANALYZE bdm_stage.reporte_relacion_persona_ubica;
ANALYZE bdm_stage.diccionario_complementos;
ANALYZE bdm_stage.diccionario_via;
ANALYZE bdm_stage.relacion_ubicac_estandar_geo;
