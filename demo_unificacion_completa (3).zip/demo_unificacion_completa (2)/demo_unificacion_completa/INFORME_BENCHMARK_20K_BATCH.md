# Informe de validación — Benchmark Unificación Reconocer (20.000 personas)

> **Producto:** Reconocer Master Cloud · **Componente:** Unificación de direcciones  
> **Modo de ejecución:** Batch (motor 1×)  
> **Fecha de corrida:** 2026-07-03  
> **Entorno:** Redshift DEV — conexión `dba_batch_DEV`  
> **run_id:** `benchmark_20k_batch_v1`

---

## 1. Resumen ejecutivo

Se ejecutó con éxito el benchmark end-to-end de **Unificación** (Regla 1 → Regla 2 + motor → Regla 3) sobre un dataset sintético de **20.000 personas** (~40.000 RPU iniciales), utilizando el script maestro [`Benchmark_20K/00_run_benchmark_20k_batch.sql`](Benchmark_20K/00_run_benchmark_20k_batch.sql) en DBeaver.

| Resultado | Valor |
|-----------|-------|
| **Tiempo total (E2E)** | **33 segundos** |
| **Personas procesadas** | 20.000 |
| **Absorciones registradas** | 12.400 |
| **Invariantes de integridad** | 0 violaciones |
| **Escenarios cubiertos** | 22 códigos (`scenario_code`) |

**Conclusión principal:** el pipeline de Unificación escala a 20K personas manteniendo la corrección funcional del diseño (incluidos escenarios de control que no deben unificarse) y un tiempo de respuesta adecuado para el entorno DEV en modo batch.

---

## 2. Objetivo y alcance

### Objetivo

Validar **correctitud funcional** y **performance** del benchmark de Unificación diseñado en [`Benchmark_20K/SDD_BENCHMARK_20K.md`](Benchmark_20K/SDD_BENCHMARK_20K.md): dataset estratificado, cascada R1/R2/R3, motor en modo lote y métricas en `bdm_stage.perf_timings`.

### Dentro del alcance

- Generación SQL de 20.000 personas con distribución por escenario (12% R1, 36% R2, 12% R3, 40% control).
- Ejecución completa de reglas de unificación y motor **batch (1 ejecución unificada)**.
- Validación de conteos, invariantes y desglose por regla/escenario.
- Comparación con piloto previo de 2.000 personas.

### Fuera del alcance

- Etapa de **Geo** / geocodificación ArcGIS (coordenadas mock en dataset).
- Ordenamiento y score de contactabilidad.
- Ejecución en UAT/PROD ni volumen productivo real.
- Benchmark **demo fiel 20K** (motor 3×) — pendiente como siguiente corrida.

---

## 3. Configuración de la prueba

| Parámetro | Valor |
|-----------|-------|
| Script ejecutado | [`Benchmark_20K/00_run_benchmark_20k_batch.sql`](Benchmark_20K/00_run_benchmark_20k_batch.sql) |
| Herramienta | DBeaver — Execute SQL Script (`Alt+Shift+X`) |
| Esquema | `bdm_stage` |
| run_id | `benchmark_20k_batch_v1` |
| Personas | 20.000 |
| RPU iniciales | 40.000 (2 por persona) |
| Modo motor | Batch unificado (prep + run + finalize en un solo flujo) |
| Dataset | Sintético vía `perf_scenario_seed` — no golden records de negocio |

---

## 4. Comparación piloto 2K vs benchmark 20K

| Dimensión | Piloto 2K | Benchmark 20K batch | Observación |
|-----------|-----------|---------------------|-------------|
| run_id | `benchmark_2k_v1` | `benchmark_20k_batch_v1` | |
| Personas | 2.000 | 20.000 | Escala ×10 |
| RPU post-motor | ~4.200 | **42.000** | +2.000 direcciones enriquecidas por motor |
| Unificaciones | ~1.240 | **12.400** | Proporción ×10 |
| Motor (`generada_enriquecida=1`) | ~200 | **2.000** | Proporción ×10 |
| Tiempo E2E | ~26 s | **33 s** | +27% pese a ×10 personas |
| Modo motor | Demo fiel (3×) | **Batch (1×)** | Distinto diseño de ejecución |
| Invariantes | 0 / 0 | **0 / 0** | Integridad confirmada |

**Interpretación:** escalar de 2K a 20K personas (×10) incrementó el tiempo total solo ~27% (26 → 33 s) en modo batch DEV. El diseño del dataset mantiene las proporciones de negocio entre escenarios.

### Desglose de tiempos — 20K batch

| step_id | label | Duración (s) | % del total |
|---------|-------|--------------|-------------|
| DATA_LOAD | Carga 20.000 personas | 4 | 12% |
| R1 | Regla 1 | 1 | 3% |
| R2_ESC1_2 | R2 Escenarios 1 y 2 | 2 | 6% |
| R2_ESC4 | R2 Escenario 4 | 2 | 6% |
| R2_ESC3_SIN_NIT | R2 Esc 3 sin NIT | 1 | 3% |
| R2_MOTOR_BATCH_PREP | Motor batch prep unificado | **7** | **21%** |
| R2_MOTOR_BATCH_RUN | Motor batch ejecución única | 3 | 9% |
| R2_MOTOR_BATCH_FIN | Motor batch finalize | **7** | **21%** |
| R3 | Regla 3 | **5** | **15%** |
| VALIDATION | Validación post-run | 1 | 3% |
| **TOTAL E2E** | | **33** | **100%** |

**Cuellos de botella relativos:** preparación y finalización del motor (7 s c/u) y Regla 3 (5 s).

---

## 5. Validación de datos — contadores globales

| Métrica | Resultado | Esperado | Estado |
|---------|-----------|----------|--------|
| Personas (`VAL personas`) | 20.000 | 20.000 | OK |
| RPU total (`VAL rpu_total`) | 42.000 | 40.000 + 2.000 motor | OK |
| RPU vigentes (`VAL rpu_vigentes`) | 29.000 | — | OK |
| RPU hijas (`VAL rpu_hijas`) | 13.000 | — | OK |
| Unificaciones (`VAL unificaciones`) | 12.400 | ~12.400 | OK |
| Motor (`VAL generada_enriquecida`) | 2.000 | 2.000 | OK |
| `INV padre_no_hijo` | **0** | 0 | OK |
| `INV control_vigentes` | **0** | 0 | OK |

### Balance contable

```
42.000 RPU total  = 40.000 iniciales + 2.000 RPU padre creados por el motor
13.000 hijas      = 12.400 en unificacion_direccion + 600 R1_HIJA pre-marcadas en carga
29.000 vigentes   = 42.000 − 13.000
```

---

## 6. Desglose por regla y escenario

### 6.1 Por campo `unifica_atributos`

| unifica_atributos | Absorciones (RPU hijas en log) | Interpretación |
|-------------------|-------------------------------|----------------|
| 1 | 3.200 | R1 (1.400) + **R3 (1.800)** — ver nota técnica §6.2 |
| 2 | 9.200 | Regla 2 + motor |
| **Total** | **12.400** | |

### 6.2 Nota técnica — trazabilidad Regla 3

El guion funcional y la trazabilidad de negocio definen:

| `unifica_atributos` | Regla |
|---------------------|-------|
| 1 | Regla 1 |
| 2 | Regla 2 (+ motor) |
| 3 | Regla 3 |

Sin embargo, el script [`10_regla3_geo.sql`](10_regla3_geo.sql) persiste las unificaciones de R3 con **`unifica_atributos = 1`** (mismo valor que R1):

```sql
-- 10_regla3_geo.sql — PASO 6: Persistir
INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  1 AS unifica_atributos,   -- debería ser 3
  ...
FROM bdm_stage.stg_regla3_resultado;
```

**Impacto:**

- La **lógica de unificación R3 funciona correctamente** (pares hijo/padre, escenarios negativos respetados).
- Los **reportes que filtran solo por `unifica_atributos`** no distinguen R3 de R1 sin cruzar `scenario_code`.
- **Recomendación:** corregir a `3 AS unifica_atributos` antes de reporting operativo o producción; regenerar benchmarks con `build_benchmark.ps1`.

En este informe, las **1.800 unificaciones R3** se identifican por escenarios `R3_GEO`, `R3_FECHA` y `R3_DICC_VIA`.

### 6.3 Matriz por `scenario_code`

| scenario_code | Personas | RPU en log unificación | Personas con ≥1 hijo |
|---------------|----------|------------------------|----------------------|
| CONTROL | 8.000 | 0 | 0 |
| R1_EMPATE | 400 | 0 | 0 |
| R1_ESC1 | 600 | 600 | 600 |
| R1_ESC2 | 400 | 400 | 400 |
| R1_ESC3 | 400 | 400 | 400 |
| R1_HIJA | 600 | 0 | 0 |
| R2_EMPATE | 1.200 | 1.200 | 1.200 |
| R2_ESC1 | 600 | 600 | 600 |
| R2_ESC2 | 600 | 600 | 600 |
| R2_ESC3_NIT | 600 | 1.200 | 600 |
| R2_ESC3_SIN_NIT | 600 | 600 | 600 |
| R2_ESC4 | 600 | 600 | 600 |
| R2_ESC4_DIC | 600 | 600 | 600 |
| R2_ESC5_DIC | 400 | 400 | 400 |
| R2_ESC5_MOTOR | 800 | 1.600 | 800 |
| R2_ESC6_DIC | 600 | 600 | 600 |
| R2_ESC6_MOTOR | 600 | 1.200 | 600 |
| R3_DICC_VIA | 600 | 600 | 600 |
| R3_FECHA | 600 | 600 | 600 |
| R3_FUERA | 600 | 0 | 0 |
| R3_GEO | 600 | 600 | 600 |

**Escenarios sin unificación (esperado):**

| Escenario | Personas | Motivo |
|-----------|----------|--------|
| CONTROL | 8.000 | Calles distintas — no hay par candidato |
| R1_EMPATE | 400 | Empate CIIU/entidades — no se unifica |
| R1_HIJA | 600 | Hija pre-absorbida en carga (sin fila en log) |
| R3_FUERA | 600 | Diferencia de puerta > ±2 — fuera de umbral R3 |

**Escenarios motor** (`R2_ESC3_NIT`, `R2_ESC5_MOTOR`, `R2_ESC6_MOTOR`): 2 filas en log por persona (hijo original + padre MDIR absorbido hacia dirección enriquecida).

### 6.4 Patrones por persona (CSV anexo)

Resumen de estados finales por tipo de escenario:

| Patrón | Escenarios | rpu_total | vigentes | hijas | en_log | tuvo_motor |
|--------|------------|-----------|----------|-------|--------|------------|
| Sin cambio | CONTROL, R1_EMPATE, R3_FUERA | 2 | 2 | 0 | 0 | 0 |
| Unificación simple | R1_ESC*, R2_ESC*, R3_GEO/FECHA/DICC | 2 | 1 | 1 | 1 | 0 |
| Pre-hija | R1_HIJA | 2 | 1 | 1 | 0 | 0 |
| Motor | R2_ESC5_MOTOR, R2_ESC6_MOTOR, R2_ESC3_NIT | 3 | 1 | 2 | 2 | 1 |

**Ejemplos:**

| scenario_code | id_buro_persona (muestra) | rpu | vig | hijas | log | motor |
|---------------|----------------------------|-----|-----|-------|-----|-------|
| R2_ESC5_MOTOR | 100033 | 3 | 1 | 2 | 2 | 1 |
| R1_HIJA | 100009 | 2 | 1 | 1 | 0 | 0 |
| CONTROL | 100060 | 2 | 2 | 0 | 0 | 0 |
| R3_FUERA | 100057 | 2 | 2 | 0 | 0 | 0 |

Detalle completo (20.000 filas): [`Benchmark_20K/datos/informe_20k_por_persona.csv`](Benchmark_20K/datos/informe_20k_por_persona.csv)

### 6.5 Personas impactadas por regla

| Regla / grupo | Personas |
|---------------|----------|
| R1 unificada (ESC1–3) | 1.400 |
| R2 + motor | 7.200 |
| R3 unificada (GEO, FECHA, DICC_VIA) | 1.800 |
| Control (sin unificación) | 8.000 |
| Hija precargada (R1_HIJA) | 600 |
| Sin unificación por diseño (EMPATE, FUERA) | 1.000 |
| **Total** | **20.000** |

---

## 7. Conclusiones

1. **Funcional:** los 22 escenarios sintéticos se comportan según el diseño. Escenarios positivos unifican; escenarios negativos (control, empate R1, puerta fuera de umbral R3) no unifican.

2. **Integridad:** invariantes `padre_no_hijo` y `control_vigentes` en cero confirman consistencia del modelo padre/hijo.

3. **Performance:** 20.000 personas procesadas en **33 segundos** (DEV, batch). Escala favorable respecto al piloto 2K.

4. **Trazabilidad:** detalle por persona disponible en CSV anexo; desglose por `scenario_code` permite auditoría por criterio de aceptación.

5. **Riesgo conocido:** campo `unifica_atributos` en R3 registra valor `1` en lugar de `3`. No afecta la decisión de unificación, pero sí el reporting por regla hasta corregir el script.

---

## 8. Próximos pasos

1. Ejecutar [`Benchmark_20K/00_run_benchmark_20k_demo_fiel.sql`](Benchmark_20K/00_run_benchmark_20k_demo_fiel.sql) (motor 3×) y comparar tiempos con este informe batch.

2. Corregir `unifica_atributos = 3` en [`10_regla3_geo.sql`](10_regla3_geo.sql) y regenerar scripts benchmark; re-validar reporting por regla.

3. Realizar **3 corridas** adicionales en DEV para calcular mediana y p95 por hito ([`Benchmark_20K/INFORME_PLANTILLA.md`](Benchmark_20K/INFORME_PLANTILLA.md)).

4. Integrar etapa **Geo** (ArcGIS → Redshift) antes de R3 en pipeline productivo — ver [`Geo/ENTENDIMIENTO_PROCESO_GEO.md`](Geo/ENTENDIMIENTO_PROCESO_GEO.md).

5. Planificar ejecución en UAT/PROD con ventana batch y volumen real.

---

## Anexos

### Anexo A — Consultas SQL de validación

**Contadores globales** ([`Benchmark_20K/inc_validation.sql`](Benchmark_20K/inc_validation.sql)):

```sql
SELECT 'VAL personas' AS metric, COUNT(DISTINCT id_buro_persona) AS val
FROM bdm_stage.relacion_persona_ubicacion;
SELECT 'VAL rpu_total' AS metric, COUNT(*) AS val
FROM bdm_stage.relacion_persona_ubicacion;
SELECT 'VAL rpu_vigentes' AS metric, COUNT(*) AS val
FROM bdm_stage.relacion_persona_ubicacion WHERE ind_unificacion IS NULL;
SELECT 'VAL rpu_hijas' AS metric, COUNT(*) AS val
FROM bdm_stage.relacion_persona_ubicacion WHERE ind_unificacion = 1;
SELECT 'VAL unificaciones' AS metric, COUNT(*) AS val
FROM bdm_stage.unificacion_direccion;
SELECT 'VAL generada_enriquecida' AS metric, COUNT(*) AS val
FROM bdm_stage.direccion_fisica WHERE generada_enriquecida = 1;
```

**Invariantes:**

```sql
SELECT 'INV padre_no_hijo' AS check_name, COUNT(*) AS violaciones
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r
  ON r.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
WHERE r.ind_unificacion = 1;

SELECT 'INV control_vigentes' AS check_name, COUNT(*) AS violaciones
FROM bdm_stage.perf_persona_meta m
WHERE m.scenario_code = 'CONTROL'
  AND (
    SELECT COUNT(*) FROM bdm_stage.relacion_persona_ubicacion r
    WHERE r.id_buro_persona = m.id_buro_persona AND r.ind_unificacion IS NULL
  ) <> 2;
```

**Desglose por regla y escenario:**

```sql
-- Por unifica_atributos
SELECT u.unifica_atributos, COUNT(*) AS absorciones
FROM bdm_stage.unificacion_direccion u
GROUP BY 1 ORDER BY 1;

-- Por scenario_code
SELECT m.scenario_code,
       COUNT(DISTINCT m.id_buro_persona) AS personas,
       SUM(CASE WHEN u.cod_dw_persona_ubic IS NOT NULL THEN 1 ELSE 0 END) AS rpu_en_log
FROM bdm_stage.perf_persona_meta m
LEFT JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
LEFT JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic
GROUP BY 1 ORDER BY 1;
```

### Anexo B — Tiempos completos (`perf_timings`)

| step_order | step_id | label | started_at | ended_at | duration_sec | status |
|------------|---------|-------|------------|----------|--------------|--------|
| 1 | DATA_LOAD | Carga 20000 personas | 2026-07-03 09:57:33 | 2026-07-03 09:57:37 | 4 | OK |
| 2 | R1 | Regla 1 | 2026-07-03 09:57:37 | 2026-07-03 09:57:38 | 1 | OK |
| 3 | R2_ESC1_2 | R2 Escenarios 1 y 2 | 2026-07-03 09:57:38 | 2026-07-03 09:57:40 | 2 | OK |
| 4 | R2_ESC4 | R2 Escenario 4 | 2026-07-03 09:57:40 | 2026-07-03 09:57:42 | 2 | OK |
| 5 | R2_ESC3_SIN_NIT | R2 Esc 3 sin NIT | 2026-07-03 09:57:42 | 2026-07-03 09:57:43 | 1 | OK |
| 6 | R2_MOTOR_BATCH_PREP | Motor batch prep unificado | 2026-07-03 09:57:43 | 2026-07-03 09:57:50 | 7 | OK |
| 7 | R2_MOTOR_BATCH_RUN | Motor batch ejecución única | 2026-07-03 09:57:50 | 2026-07-03 09:57:53 | 3 | OK |
| 8 | R2_MOTOR_BATCH_FIN | Motor batch finalize | 2026-07-03 09:57:53 | 2026-07-03 09:58:00 | 7 | OK |
| 9 | R3 | Regla 3 | 2026-07-03 09:58:00 | 2026-07-03 09:58:05 | 5 | OK |
| 10 | VALIDATION | Validación post-run | 2026-07-03 09:58:05 | 2026-07-03 09:58:06 | 1 | OK |

### Anexo C — Detalle por persona (CSV)

| Campo | Descripción |
|-------|-------------|
| `id_buro_persona` | Identificador persona |
| `scenario_code` | Escenario diseñado en benchmark |
| `rpu_total` | Filas RPU finales de la persona |
| `vigentes` | RPU con `ind_unificacion IS NULL` |
| `hijas` | RPU con `ind_unificacion = 1` |
| `en_log_unificacion` | RPU registradas como hijo en `unificacion_direccion` |
| `tuvo_motor` | 1 si la persona tiene dirección `generada_enriquecida=1` |

**Archivo:** [`Benchmark_20K/datos/informe_20k_por_persona.csv`](Benchmark_20K/datos/informe_20k_por_persona.csv) (20.000 filas)

### Anexo D — Referencias del repositorio

| Documento | Propósito |
|-----------|-----------|
| [`Benchmark_20K/SDD_BENCHMARK_20K.md`](Benchmark_20K/SDD_BENCHMARK_20K.md) | Diseño del benchmark |
| [`Benchmark_20K/RUNBOOK_DBEAVER_BENCHMARK.md`](Benchmark_20K/RUNBOOK_DBEAVER_BENCHMARK.md) | Procedimiento de ejecución |
| [`Geo/ENTENDIMIENTO_PROCESO_GEO.md`](Geo/ENTENDIMIENTO_PROCESO_GEO.md) | Integración Geo (próxima etapa) |

---

*Informe generado a partir de corrida `benchmark_20k_batch_v1` — Experian Colombia · Reconocer · Unificación de direcciones*
