-- ============================================================
-- 05_regla2_esc3_sin_nit.sql
-- Regla 2 Escenario 3 Caso Sin NIT: Misma nomenclatura, diferente valor
-- → Mayor score (fecha + entidades) = padre
-- Fuente Teradata: PRO_UnificacionR2.sql líneas 462-630 + 1720-1834
-- ============================================================
-- Prerequisito: 03_regla2_esc1_2.sql ejecutado (stg_regla2_e2 existe)
--
-- Lógica:
--   1. Filtrar no-unificados que NO son NIT
--   2. JOIN por misma nomenclatura (AP=AP, CS=CS, etc.) pero diferente valor
--   3. Score = fecha_como_entero + (entidades + 10000000)
--   4. Mayor score = padre, menor = hijo
--
-- Datos mock: P06 (AP 105 vs AP 404), P08 (CS 312 vs CS 108)
-- ============================================================

-- PASO 1: Filtrar no-unificados que NO son NIT
-- En datos mock, Cod_Tipo_Ident_Fte=3 es NIT. Excluimos esos.
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03;
CREATE TABLE bdm_stage.stg_regla2_e03
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT a.*
FROM bdm_stage.stg_regla2_e2 a
WHERE a.ind_unificacion = 'N'
  AND COALESCE(a.cod_dw_tipo_ubicacion_dir, 0) NOT IN (
    SELECT cod_dw_tipo_ubicacion_dir FROM bdm_stage.tipo_ubicacion_dir WHERE 1=0
  )
  -- Filtro NIT: excluir registros con tipo identificación = NIT (cod_tipo_ident_fte = 3)
  -- En Teradata se hace con LEFT JOIN V_Tipo_Identificacion WHERE NOT LIKE '%Nit%'
  -- Aquí usamos el campo cod_tipo_ident_fte directamente del insumo de R2
  -- TODO: cuando exista tabla tipo_identificacion, usar JOIN
;

-- Corrección: el filtro NIT debe venir de relacion_persona_ubicacion.cod_tipo_ident_fte
-- que ya está en stg_regla2_e2 (no se copió). Necesitamos JOINear con RPU.
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03;
CREATE TABLE bdm_stage.stg_regla2_e03
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT a.*
FROM bdm_stage.stg_regla2_e2 a
JOIN bdm_stage.relacion_persona_ubicacion rpu
  ON a.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE a.ind_unificacion = 'N'
  AND COALESCE(rpu.cod_tipo_ident_fte, 0) <> 3;  -- 3 = NIT

ANALYZE bdm_stage.stg_regla2_e03;

-- PASO 2: JOIN por misma nomenclatura, calcular score
-- Score = fecha_como_entero + (entidades + 10000000)
-- Detectar empates
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_a;
CREATE TABLE bdm_stage.stg_regla2_e03_a
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT u1.*,
  COUNT(*) OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, nomenclatura, id
  ) AS count_empate,
  MAX(id) OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, cod_dw_persona_ubic, nomenclatura
  ) AS idmax
FROM (
  SELECT
    a.cod_dw_persona_ubic,
    COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 19000101)
      + (COALESCE(a.numero_entidades_reportan, 0) + 10000000) AS id,
    a.texto_ubicacion,
    a.fecha_relacion_persona_ubicaci,
    nmc1.nomenclatura,
    a.complemento AS complemento1,
    b.complemento AS complemento2,
    a.numero_entidades_reportan,
    a.id_buro_persona,
    a.cod_dw_tipo_ubicacion_dir,
    a.cod_dw_municipio,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio, nmc1.nomenclatura
      ORDER BY COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 19000101)
        + (COALESCE(a.numero_entidades_reportan, 0) + 10000000)
    ) AS orden
  FROM bdm_stage.stg_regla2_e03 a
  JOIN bdm_stage.stg_regla2_e03 b
    ON  a.id_buro_persona          = b.id_buro_persona
    AND a.texto_ubicacion           = b.texto_ubicacion
    AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
    AND a.cod_dw_municipio          = b.cod_dw_municipio
    AND a.cod_dw_persona_ubic      <> b.cod_dw_persona_ubic
    AND a.complemento              <> b.complemento
  JOIN bdm_stage.nomenclatura nmc1
    ON a.complemento LIKE nmc1.nomenclatura || '%'
  JOIN bdm_stage.nomenclatura nmc2
    ON b.complemento LIKE nmc2.nomenclatura || '%'
  WHERE nmc1.nomenclatura = nmc2.nomenclatura
) u1;

ANALYZE bdm_stage.stg_regla2_e03_a;

-- PASO 3: Generar pares padre-hijo (mayor score = padre)
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_e1;
CREATE TABLE bdm_stage.stg_regla2_e03_e1
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT
  b.cod_dw_persona_ubic,
  a.cod_dw_persona_ubic AS id_padre
FROM bdm_stage.stg_regla2_e03_a a
JOIN bdm_stage.stg_regla2_e03_a b
  ON  a.id_buro_persona          = b.id_buro_persona
  AND a.texto_ubicacion           = b.texto_ubicacion
  AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
  AND a.cod_dw_municipio          = b.cod_dw_municipio
  AND a.nomenclatura              = b.nomenclatura
  AND a.cod_dw_persona_ubic      <> b.cod_dw_persona_ubic
  AND a.id > b.id
JOIN (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, nomenclatura,
         MAX(orden) AS max_orden
  FROM bdm_stage.stg_regla2_e03_a
  GROUP BY 1,2,3,4,5
) mx
  ON  a.id_buro_persona          = mx.id_buro_persona
  AND a.texto_ubicacion           = mx.texto_ubicacion
  AND a.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir
  AND a.cod_dw_municipio          = mx.cod_dw_municipio
  AND a.nomenclatura              = mx.nomenclatura
  AND a.orden = mx.max_orden;

ANALYZE bdm_stage.stg_regla2_e03_e1;

-- PASO 4: UPDATE E2 — marcar hijos del Escenario 3 sin NIT
UPDATE bdm_stage.stg_regla2_e2
SET id_padre = stg.id_padre,
    ind_unificacion = 'S',
    n_id = 'L3'
FROM bdm_stage.stg_regla2_e03_e1 stg
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = stg.cod_dw_persona_ubic;

-- PASO 5: Persistir pares en tabla de unificación
INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT
  cod_dw_persona_ubic,
  id_padre AS cod_dw_direccion_unificada,
  2 AS unifica_atributos,
  CURRENT_DATE AS fecha_unificacion,
  1 AS lote,
  1 AS severidad,
  LEFT(CURRENT_USER, 30) AS usuario_bd
FROM bdm_stage.stg_regla2_e03_e1;

-- PASO 6: Marcar hijos
UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e03_e1
);

-- PASO 7: Estadísticas
ANALYZE bdm_stage.unificacion_direccion;
ANALYZE bdm_stage.relacion_persona_ubicacion;
ANALYZE bdm_stage.stg_regla2_e2;

-- PASO 8: Limpiar staging
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_a;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_e1;
