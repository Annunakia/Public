-- ============================================================
-- 07b_regla2_esc3_nit_finaliza.sql
-- Regla 2 Escenario 3 NIT: PARTE 2 — Usa resultado del motor
-- Ejecutar DESPUÉS del motor (06_motor_nuevas_direcciones.sql)
-- ============================================================

-- PASO 5: Actualizar stg_regla2_e2 con los hijos NIT
UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S',
    n_id = 'X4',
    id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
JOIN bdm_stage.stg_motor_hijo h
  ON h.cod_dw_ubic = f.cod_dw_ubic
  AND h.id_buro_persona = f.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = f.cod_dw_tipo_ubicacion_dir
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = h.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N';

-- Padre MDIR original también es hijo del nuevo padre generado
UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S',
    n_id = 'X4',
    id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = f.cod_dw_persona_ubic_padre
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N';

-- PASO 6: Insertar nueva dirección generada en E2
INSERT INTO bdm_stage.stg_regla2_e2 (
  cod_dw_persona_ubic, id_padre, id_buro_persona,
  cod_dw_tipo_ubicacion_dir, cod_dw_ubic, texto_ubicacion,
  cod_dw_direccion_fisica, complemento,
  ind_unificacion, n_id
)
SELECT
  f.new_cod_dw_persona_ubic,
  NULL,
  f.id_buro_persona,
  f.cod_dw_tipo_ubicacion_dir,
  f.cod_dw_ubic,
  f.texto_ubicacion,
  f.new_cod_dw_direccion_fisica,
  f.nuevo_complemento,
  'N',
  NULL
FROM bdm_stage.stg_motor_final f;

-- PASO 7: Estadísticas
ANALYZE bdm_stage.stg_regla2_e2;

-- PASO 8: Limpiar staging del escenario
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e031;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_nit_pares;
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
DROP TABLE IF EXISTS bdm_stage.stg_motor_final;
DROP TABLE IF EXISTS bdm_stage.stg_motor_padre;
DROP TABLE IF EXISTS bdm_stage.stg_motor_hijo;
