-- ============================================================
-- 09a_regla2_esc6_prepara.sql
-- Regla 2 Escenario 6: PARTE 1 — Prepara stg_motor_input
-- Ejecutar ANTES del motor (06_motor_nuevas_direcciones.sql)
-- ============================================================
-- Prerequisito: 08b_regla2_esc5_finaliza.sql ejecutado
--
-- Subcaso 1: ≠ nivel → MOTOR genera nueva dirección
--   Persona 2007: ED 2 OF 301 + OF 302 (cruzadas, sin Esc2) → dirección combinada
-- Subcaso 3: = nivel → diccionario (procesado en 09b)
--   Persona 2009: LC 10 OF 200 + OF 200 (cruzadas, mismo nivel) → gana LC por frecuencia
-- ============================================================

-- PASO 1: Filtrar no-unificados con complemento diferente
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06;
CREATE TABLE bdm_stage.stg_regla2_e06
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') A
JOIN (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.complemento              <> B.complemento;

ANALYZE bdm_stage.stg_regla2_e06;

-- PASO 2: Identificar nomenclaturas (primaria y secundaria)
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_a;
CREATE TABLE bdm_stage.stg_regla2_e06_a
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*,
  NMC1.nomenclatura AS nomenclatura_pri,
  NMC1.nivel_complemento AS nivel_pri,
  NMC2.nomenclatura AS nomenclatura_sec,
  NMC2.nivel_complemento AS nivel_sec
FROM bdm_stage.stg_regla2_e06 A
LEFT JOIN bdm_stage.nomenclatura NMC1
  ON A.complemento LIKE TRIM(NMC1.nomenclatura) || ' %'
LEFT JOIN bdm_stage.nomenclatura NMC2
  ON A.complemento LIKE '% ' || TRIM(NMC2.nomenclatura) || ' %'
  AND NMC2.nomenclatura <> COALESCE(NMC1.nomenclatura, '');

ANALYZE bdm_stage.stg_regla2_e06_a;

-- PASO 3: Filtrar pares donde nomenclaturas están "cruzadas"
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_c;
CREATE TABLE bdm_stage.stg_regla2_e06_c
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT * FROM (
  SELECT DISTINCT A.*
  FROM bdm_stage.stg_regla2_e06_a A
  JOIN bdm_stage.stg_regla2_e06_a B
    ON  A.id_buro_persona          = B.id_buro_persona
    AND A.texto_ubicacion           = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
    AND A.cod_dw_municipio          = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
    AND A.complemento              <> B.complemento
    AND COALESCE(A.nomenclatura_pri, 'A') = COALESCE(B.nomenclatura_sec, 'B')

  UNION

  SELECT DISTINCT A.*
  FROM bdm_stage.stg_regla2_e06_a A
  JOIN bdm_stage.stg_regla2_e06_a B
    ON  A.id_buro_persona          = B.id_buro_persona
    AND A.texto_ubicacion           = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
    AND A.cod_dw_municipio          = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
    AND A.complemento              <> B.complemento
    AND COALESCE(A.nomenclatura_sec, 'A') = COALESCE(B.nomenclatura_pri, 'B')
) sub;

ANALYZE bdm_stage.stg_regla2_e06_c;

-- PASO 4: Subcaso 1 — pares con diferente nivel → motor
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub1;
CREATE TABLE bdm_stage.stg_regla2_e06_sub1
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM bdm_stage.stg_regla2_e06_c A
JOIN bdm_stage.stg_regla2_e06_c B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.complemento              <> B.complemento
  AND COALESCE(A.nivel_pri, 0) <> COALESCE(B.nivel_pri, 0);

ANALYZE bdm_stage.stg_regla2_e06_sub1;

-- PASO 5: Preparar stg_motor_input
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
CREATE TABLE bdm_stage.stg_motor_input
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT e.cod_dw_persona_ubic, e.cod_dw_ubic, e.complemento, e.id_buro_persona,
  e.cod_dw_tipo_ubicacion_dir, rpu.cod_pin_persona, rpu.cod_dw_direccion_fisica,
  e.texto_ubicacion, e.fecha_relacion_persona_ubicaci
FROM bdm_stage.stg_regla2_e06_sub1 e
JOIN bdm_stage.relacion_persona_ubicacion rpu
  ON e.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

ANALYZE bdm_stage.stg_motor_input;
