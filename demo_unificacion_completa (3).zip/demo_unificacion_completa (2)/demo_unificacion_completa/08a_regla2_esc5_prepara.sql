-- ============================================================
-- 08a_regla2_esc5_prepara.sql
-- Regla 2 Escenario 5: PARTE 1 — Prepara stg_motor_input
-- Ejecutar ANTES del motor (06_motor_nuevas_direcciones.sql)
-- ============================================================
-- Prerequisito: 07b_regla2_esc3_nit_finaliza.sql ejecutado
--
-- Subcaso 1: Valores diferentes → MOTOR genera nueva dirección
--   Persona 2006: TO 3 (nivel 4) + AP 504 (nivel 7) → "TO 3 AP 504"
-- Subcaso 2: Valores iguales → diccionario (procesado en 08b)
--   Persona 2008: TO 5 (nivel 4) + PI 5 (nivel 5) → gana TO por frecuencia
-- ============================================================

-- PASO 1: Filtrar no-unificados con complemento diferente
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05;
CREATE TABLE bdm_stage.stg_regla2_e05
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') A
JOIN (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.complemento              <> B.complemento;

ANALYZE bdm_stage.stg_regla2_e05;

-- PASO 2: Identificar nomenclaturas de cada complemento
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_a;
CREATE TABLE bdm_stage.stg_regla2_e05_a
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT
  A.*,
  NMC1.nomenclatura AS nomenclatura_pri,
  NMC1.nivel_complemento AS nivel_pri,
  NMC2.nomenclatura AS nomenclatura_sec,
  NMC2.nivel_complemento AS nivel_sec,
  TRIM(REPLACE(REPLACE(A.complemento, COALESCE(NMC1.nomenclatura,''), ''), COALESCE(NMC2.nomenclatura,''), '')) AS complemento2
FROM bdm_stage.stg_regla2_e05 A
LEFT JOIN bdm_stage.nomenclatura NMC1
  ON A.complemento LIKE TRIM(NMC1.nomenclatura) || ' %'
LEFT JOIN bdm_stage.nomenclatura NMC2
  ON A.complemento LIKE '% ' || TRIM(NMC2.nomenclatura) || ' %'
  AND NMC2.nomenclatura <> COALESCE(NMC1.nomenclatura, '');

ANALYZE bdm_stage.stg_regla2_e05_a;

-- PASO 3: Filtrar pares donde nomenclaturas están en DIFERENTE nivel
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_c;
CREATE TABLE bdm_stage.stg_regla2_e05_c
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT * FROM (
  SELECT DISTINCT A.*
  FROM bdm_stage.stg_regla2_e05_a A
  JOIN bdm_stage.stg_regla2_e05_a B
    ON  A.id_buro_persona          = B.id_buro_persona
    AND A.texto_ubicacion           = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
    AND A.cod_dw_municipio          = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
    AND A.complemento              <> B.complemento
    AND (A.complemento2 NOT LIKE '%' || B.complemento2 || '%'
         OR B.complemento2 NOT LIKE '%' || A.complemento2 || '%')
    AND A.nomenclatura_pri = B.nomenclatura_pri
    AND COALESCE(A.nomenclatura_sec, 'X') <> COALESCE(B.nomenclatura_sec, 'X')
    AND COALESCE(A.nivel_sec, 0) <> COALESCE(B.nivel_sec, 0)

  UNION

  SELECT DISTINCT A.*
  FROM bdm_stage.stg_regla2_e05_a A
  JOIN bdm_stage.stg_regla2_e05_a B
    ON  A.id_buro_persona          = B.id_buro_persona
    AND A.texto_ubicacion           = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
    AND A.cod_dw_municipio          = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
    AND A.complemento              <> B.complemento
    AND (A.complemento2 NOT LIKE '%' || B.complemento2 || '%'
         OR B.complemento2 NOT LIKE '%' || A.complemento2 || '%')
    AND A.nomenclatura_pri <> B.nomenclatura_pri
    AND COALESCE(A.nomenclatura_sec, 'X') = COALESCE(B.nomenclatura_sec, 'X')
    AND A.nivel_pri <> B.nivel_pri
) sub;

ANALYZE bdm_stage.stg_regla2_e05_c;

-- PASO 4: Subcaso 1 — pares con valores diferentes → motor
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub1;
CREATE TABLE bdm_stage.stg_regla2_e05_sub1
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM bdm_stage.stg_regla2_e05_c A
JOIN bdm_stage.stg_regla2_e05_c B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.complemento              <> B.complemento
  AND TRIM(A.complemento2) <> TRIM(B.complemento2);

ANALYZE bdm_stage.stg_regla2_e05_sub1;

-- PASO 5: Preparar stg_motor_input
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
CREATE TABLE bdm_stage.stg_motor_input
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  e.cod_dw_persona_ubic, e.cod_dw_ubic, e.complemento, e.id_buro_persona,
  e.cod_dw_tipo_ubicacion_dir, rpu.cod_pin_persona, rpu.cod_dw_direccion_fisica,
  e.texto_ubicacion, e.fecha_relacion_persona_ubicaci
FROM bdm_stage.stg_regla2_e05_sub1 e
JOIN bdm_stage.relacion_persona_ubicacion rpu
  ON e.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

ANALYZE bdm_stage.stg_motor_input;
