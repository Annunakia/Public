# Requerimientos — Proceso de Ordenamiento (Reconocer Master Cloud)

> **Producto:** Reconocer · **Componente:** Ordenamiento de direcciones  
> **Fecha:** 2026-07-03  
> **Fuentes:** demo Unificación (`README.md`, `GUION_DEMO_VIDEO_v3.md`, `mapa_unificacion_demo.drawio`), pipeline Geo (`Geo/ENTENDIMIENTO_PROCESO_GEO.md`), benchmark (`INFORME_BENCHMARK_20K_BATCH.md`)

---

## 1. Contexto y propósito

**Ordenamiento** es la etapa posterior a **Unificación** (R1 → R2 → R3) dentro del pipeline Reconocer Master Cloud. Su objetivo de negocio es **priorizar las direcciones vigentes de una persona** para determinar la **mejor forma de contactarla**, en coherencia con el propósito del producto Reconocer.

```
XPM → Estandarización/Split → Geo → Unificación (R1 → R2 + motor → R3) → Ordenamiento → Score de contactabilidad → …
```

| Etapa previa | Qué entrega a Ordenamiento |
|--------------|----------------------------|
| **Unificación** | Elimina redundancias; marca direcciones absorbidas; conserva trazabilidad |
| **Geo** (opcional por dirección) | Coordenadas y atributos espaciales en tablas de ubicación |
| **Ordenamiento** | Ranking/prioridad entre direcciones **vigentes** de cada persona |

> **Nota de alcance de este documento:** el repositorio actual implementa y valida **Unificación**, no Ordenamiento. Los requerimientos aquí consolidan lo **explícito en la documentación del demo** y lo **inferido del modelo de datos y del pipeline**. Los ítems marcados como *Pendiente de confirmación* requieren especificación formal (Kidar / HLD Ordenamiento).

---

## 2. Requerimientos funcionales

### 2.1 Objetivo de negocio

| ID | Requerimiento | Fuente |
|----|---------------|--------|
| **OR-F-01** | El proceso debe **ordenar/priorizar** las direcciones físicas vigentes de cada persona para soportar la decisión de **contacto óptimo**. | Guion demo v1/v3 |
| **OR-F-02** | Ordenamiento opera **después** de que Unificación haya aplicado la cascada R1 → R2 → R3. | G-01, diagrama pipeline |
| **OR-F-03** | Una persona puede conservar **múltiples direcciones vigentes** (p. ej. casos sin unificar por empate o fuera de umbral); Ordenamiento debe **rankearlas**, no eliminarlas. | Demo personas 1004, 2010, 3004 |
| **OR-F-04** | El resultado de Ordenamiento alimenta el **score de contactabilidad** y, en última instancia, la recomendación de canal de contacto del producto Reconocer. | Informe benchmark 20K (fuera de alcance explícito) |

### 2.2 Elegibilidad de direcciones (insumo)

| ID | Requerimiento | Fuente |
|----|---------------|--------|
| **OR-F-05** | Solo entran direcciones **vigentes**: relaciones persona–ubicación con `ind_unificacion IS NULL`. | G-10, guion v2/v3, diagrama draw.io |
| **OR-F-06** | Las direcciones **absorbidas** (`ind_unificacion = 1`, HIJO) **no participan** en Ordenamiento; permanecen solo para trazabilidad. | G-09, guion v3 |
| **OR-F-07** | Deben incluirse como candidatas vigentes: **padres ganadores** de unificación, **direcciones enriquecidas por el motor** (`generada_enriquecida = 1`) y **direcciones que no unificaron** por empate o regla negativa. | Diagrama draw.io, PASO 16 guion v3 |
| **OR-F-08** | Las direcciones absorbidas **no se eliminan** del DW; la exclusión de Ordenamiento es **lógica**, no física. | G-08 |

### 2.3 Reglas de negocio conocidas / esperadas

| ID | Requerimiento | Estado |
|----|---------------|--------|
| **OR-F-09** | El **tipo de uso** de la dirección (RES, LAB, CRR, JUD, CCL) es un atributo relevante para priorización, coherente con la lógica de R1 y el catálogo `tipo_ubicacion_dir`. | Inferido del modelo |
| **OR-F-10** | La **actividad económica (CIIU)** de la persona puede influir en la prioridad de contacto (continuidad con criterios R1). | Inferido de R1 |
| **OR-F-11** | Atributos de **respaldo de fuentes** (número de entidades/suscriptores, fecha de último reporte) son criterios probables de desempate, alineados con R2/R3. | Inferido de reglas previas |
| **OR-F-12** | La **presencia de geolocalización** y calidad geo (`score_geo`, coordenadas válidas) pueden incrementar la prioridad de una dirección. | Geo doc + R3 |
| **OR-F-13** | Direcciones **más completas** (con complemento informado, enriquecidas por motor) pueden recibir mayor peso frente a direcciones parciales. | Inferido de R2/motor |
| **OR-F-14** | Ordenamiento debe producir un **orden relativo** por persona (p. ej. prioridad 1 = dirección principal de contacto). | Campo `orden_prioridad` en modelo |
| **OR-F-15** | *Pendiente de confirmación:* reglas exactas de score/peso por tipo de uso, CIIU, geo, fecha y entidades para el ranking final. | Gap documental |

### 2.4 Comportamiento esperado y casos límite

| ID | Requerimiento | Fuente |
|----|---------------|--------|
| **OR-F-16** | Si una persona tiene **una sola** dirección vigente, Ordenamiento la marca como **prioridad 1** sin competencia. | Lógica derivada |
| **OR-F-17** | Si existen **varias direcciones vigentes** del mismo tipo de uso en distintas ubicaciones, todas compiten en el ranking (Unificación ya no las fusionó). | Demo post-R1/R2/R3 |
| **OR-F-18** | Direcciones enriquecidas por motor deben tratarse como **direcciones oficiales vigentes** en el ranking, no como secundarias respecto a sus fuentes absorbidas. | Demo motor 2004, 2006, 2007 |
| **OR-F-19** | *Pendiente de confirmación:* tratamiento de tipos de uso **JUD** (judicial) y **CCL** (correspondencia cliente) en la jerarquía de contacto. | Catálogo demo |

### 2.5 Trazabilidad y auditoría

| ID | Requerimiento | Fuente |
|----|---------------|--------|
| **OR-F-20** | Ordenamiento **no debe alterar** los resultados de Unificación (`ind_unificacion`, `unificacion_direccion`). | G-08, separación de etapas |
| **OR-F-21** | Debe ser posible auditar **por qué** una dirección quedó en posición N (componentes del score o regla aplicada). | Buena práctica / score contactabilidad |
| **OR-F-22** | *Pendiente de confirmación:* retención histórica de rankings por lote/fecha de proceso. | Gap documental |

---

## 3. Requerimientos técnicos

### 3.1 Posición en el pipeline batch

| ID | Requerimiento | Fuente |
|----|---------------|--------|
| **OR-T-01** | Ordenamiento se ejecuta en **Amazon Redshift** dentro del batch Master Cloud, **después** de Unificación completa. | Pipeline guiones |
| **OR-T-02** | El enriquecimiento **Geo** debe haber actualizado las tablas de ubicación **antes** de R3 en el batch; Ordenamiento consume el estado **post-R3**. | Geo doc §8 |
| **OR-T-03** | El batch de Unificación incluye un **UNLOAD separado como trigger de Ordenamiento**, distinto del UNLOAD delta geo. | Geo doc §8 |
| **OR-T-04** | *Pendiente de confirmación:* secuencia exacta Step Functions / dependencias entre UNLOAD trigger, Ordenamiento SQL y score de contactabilidad. | Geo doc gaps §11 |

### 3.2 Insumos de datos (tablas y filtros)

| ID | Requerimiento | Detalle |
|----|---------------|---------|
| **OR-T-05** | Tabla principal de insumo: `relacion_persona_ubicacion`. | Modelo demo |
| **OR-T-06** | Filtro obligatorio de elegibilidad: `WHERE ind_unificacion IS NULL`. | G-10 |
| **OR-T-07** | Joins esperados para enriquecer el ranking: | Modelo demo |
| | | `ubicacion_estandarizada` — texto, ciudad, lat/long |
| | | `direccion_fisica` — complemento, vía, puerta, `generada_enriquecida` |
| | | `tipo_ubicacion_dir` — RES, LAB, CRR, JUD, CCL |
| | | `ciiu_persona` — actividad económica |
| | | `reporte_relacion_persona_ubica` — entidades, fechas de reporte |
| | | Atributos geo (`score_geo`, `status_geo`, etc.) vía tablas destino post-ArcGIS |
| **OR-T-08** | Particionamiento lógico del procesamiento: **por `id_buro_persona`** (solo se ordenan direcciones de la misma persona entre sí). | G-07, analogía R1/R2/R3 |
| **OR-T-09** | El campo `lote` en RPU y tablas relacionadas identifica el batch de procesamiento. | Modelo demo |

### 3.3 Salidas esperadas

| ID | Requerimiento | Detalle |
|----|---------------|---------|
| **OR-T-10** | Actualizar o poblar **`orden_prioridad`** en `relacion_persona_ubicacion` (o tabla equivalente productiva) para direcciones vigentes. | DDL demo — campo reservado, sin lógica en repo |
| **OR-T-11** | *Pendiente de confirmación:* tabla dedicada de resultados de ordenamiento (p. ej. `ordenamiento_direccion`) con score desglosado. | Gap documental |
| **OR-T-12** | *Pendiente de confirmación:* UNLOAD de salida hacia sistemas consumidores / capa de contactabilidad. | Trigger mencionado en Geo doc |
| **OR-T-13** | El ranking debe ser **determinístico** para un mismo insumo y versión de reglas (reproducible en re-procesos). | Requisito implícito batch |

### 3.4 Consulta de validación (referencia demo)

Consulta usada en la demo para simular el **universo que entra a Ordenamiento**:

```sql
SELECT rpu.id_buro_persona AS persona,
  ubi.texto_ubicacion AS direccion,
  df.complemento,
  tud.descripcion_tipo_ubicacion_dir AS tipo_uso
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
WHERE rpu.ind_unificacion IS NULL
ORDER BY rpu.id_buro_persona;
```

| ID | Requerimiento |
|----|---------------|
| **OR-T-14** | Toda validación de Ordenamiento debe comprobar que **ninguna fila con `ind_unificacion = 1`** aparece en el insumo. |
| **OR-T-15** | Validación cruzada: conteo de vigentes post-Unificación = conteo de insumo Ordenamiento (por lote/persona). |

### 3.5 Infraestructura y operación

| ID | Requerimiento | Detalle |
|----|---------------|---------|
| **OR-T-16** | Esquema staging demo: `bdm_stage`; esquema alterno benchmark QA: `edf_stage`. | Benchmark SDD |
| **OR-T-17** | Entorno DEV de referencia: workgroup `experian-sandbox-trunk-ddm-xpm-workgroup`, BD `dev`, región `us-east-1`. | README demo |
| **OR-T-18** | Ejecución batch sobre volúmenes productivos (~65–70 M registros de contacto en Reconocer; subconjunto de direcciones vigentes post-unificación). | Guion v1 |
| **OR-T-19** | *Pendiente de confirmación:* métricas de performance (`perf_timings` o equivalente) para Ordenamiento en batch 20K+. | Benchmark solo cubre Unificación |
| **OR-T-20** | Idempotencia: re-ejecutar Ordenamiento sobre el mismo lote debe sobrescribir ranking sin corromper Unificación. | Buena práctica pipeline |

### 3.6 Integración con score de contactabilidad

| ID | Requerimiento | Estado |
|----|---------------|--------|
| **OR-T-21** | Ordenamiento es **etapa previa** al cálculo del **score de contactabilidad** (direcciones + teléfonos + emails). | Informe benchmark §2 |
| **OR-T-22** | *Pendiente de confirmación:* contrato de datos entre Ordenamiento y Contactabilidad (campos, granularidad, PK). | Gap documental |

---

## 4. Criterios de aceptación heredados de Unificación

Estos criterios del demo de Unificación **definen la frontera** de Ordenamiento:

| ID | Criterio | Implicación para Ordenamiento |
|----|----------|-------------------------------|
| **G-09** | Hijas no van a Ordenamiento | Excluir `ind_unificacion = 1` |
| **G-10** | Vigentes sí van a Ordenamiento | Incluir `ind_unificacion IS NULL` |
| **G-08** | Nada se borra | Ranking no implica DELETE |
| **G-05** | Trazabilidad en `unificacion_direccion` | Ordenamiento no modifica pares padre-hijo |
| **G-07** | Solo misma persona | Ranking scoped por `id_buro_persona` |

---

## 5. Matriz resumen — ¿Qué pasa a Ordenamiento?

| Estado | Condición | ¿Entra a Ordenamiento? | Ejemplo demo |
|--------|-----------|------------------------|--------------|
| **Vigente — padre** | `ind_unificacion IS NULL`, ganó unificación | ✅ Sí | 1001 LAB, 2001 AP 802 |
| **Vigente — motor** | Nueva RPU, `generada_enriquecida = 1`, vigente | ✅ Sí | 2004 `LC 101 LC 205` |
| **Vigente — sin unificar** | Empate o fuera de umbral, `ind_unificacion IS NULL` | ✅ Sí | 2010, 3004 |
| **Absorbida — hijo** | `ind_unificacion = 1` | ❌ No | AP 105 (2003), RES absorbida (1001) |
| **Hija previa** | Ya absorbida antes del batch | ❌ No | 1005 (RES previa) |

---

## 6. Gaps y preguntas abiertas

| # | Tema | Pregunta |
|---|------|----------|
| 1 | **Reglas de score** | ¿Cuál es la fórmula oficial de priorización (pesos CIIU, tipo uso, geo, fecha, entidades)? |
| 2 | **Campo `orden_prioridad`** | ¿Se escribe en Ordenamiento o viene de upstream? ¿Permite empates? |
| 3 | **UNLOAD trigger** | ¿Formato, destino S3 y consumidor del UNLOAD post-Unificación para Ordenamiento? |
| 4 | **Tablas productivas** | ¿Nombres definitivos de esquema/tablas fuera de `bdm_stage`? |
| 5 | **Contactabilidad** | ¿Ordenamiento entrega solo direcciones o ranking multi-canal? |
| 6 | **Empates** | ¿Pueden dos direcciones compartir `orden_prioridad = 1`? |
| 7 | **Teléfonos / emails** | ¿Ordenamiento es solo direcciones o un proceso unificado de contacto? |
| 8 | **Implementación** | ¿Existe script SQL / Step Function de Ordenamiento en otro repositorio? |

---

## 7. Referencias en este repositorio

| Archivo | Contenido relevante |
|---------|---------------------|
| `README.md` | Flujo R1+R2+R3; criterios G-09/G-10 |
| `GUION_DEMO_VIDEO_v3.md` | PASO 16 — vigentes vs absorbidas; glosario Ordenamiento |
| `GUION_DEMO_VIDEO_v2.md` | Regla `ind_unificacion` para Ordenamiento |
| `mapa_unificacion_demo.drawio` | Diagrama «¿Qué pasa a Ordenamiento?» |
| `Geo/ENTENDIMIENTO_PROCESO_GEO.md` | Pipeline batch; UNLOAD trigger Ordenamiento |
| `INFORME_BENCHMARK_20K_BATCH.md` | Ordenamiento explícitamente fuera de alcance del benchmark |
| `01_demo_setup.sql` | DDL con `orden_prioridad`; catálogo `tipo_ubicacion_dir` |

---

## 8. Próximos pasos sugeridos

1. Obtener especificación formal de Ordenamiento (Kidar / HLD Master Cloud).
2. Confirmar fórmula de score y mapeo a `orden_prioridad`.
3. Documentar UNLOAD trigger y contrato con Contactabilidad.
4. Implementar script de Ordenamiento + casos de prueba análogos al demo de Unificación.
5. Extender benchmark 20K para incluir métricas E2E hasta Ordenamiento.

---

*Documento derivado del análisis del repositorio `demo_unificacion_completa`. Los requerimientos marcados como «Pendiente de confirmación» deben validarse con el equipo de negocio/arquitectura antes de implementación.*
