-- ============================================================
-- 08b_regla2_esc5_finaliza.sql
-- Regla 2 Escenario 5: PARTE 2 — Usa resultado del motor + subcaso 2
-- Ejecutar DESPUÉS del motor (06_motor_nuevas_direcciones.sql)
-- ============================================================
-- Prerequisito: 08a_regla2_esc5_prepara.sql + 06_motor_nuevas_direcciones.sql
-- Persona 2006: post-motor (subcaso 1)
-- Persona 2008: diccionario D5 (subcaso 2 — TO 5 vs PI 5, mismo valor)
-- ============================================================

-- PASO 6: Post-motor — actualizar E2 para subcaso 1
UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'M5', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
JOIN bdm_stage.stg_motor_hijo h
  ON h.cod_dw_ubic = f.cod_dw_ubic AND h.id_buro_persona = f.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = f.cod_dw_tipo_ubicacion_dir
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = h.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N';

UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'M5', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = f.cod_dw_persona_ubic_padre
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N';

INSERT INTO bdm_stage.stg_regla2_e2 (
  cod_dw_persona_ubic, id_padre, id_buro_persona, cod_dw_tipo_ubicacion_dir,
  cod_dw_ubic, texto_ubicacion, cod_dw_direccion_fisica, complemento,
  ind_unificacion, n_id
)
SELECT f.new_cod_dw_persona_ubic, NULL, f.id_buro_persona, f.cod_dw_tipo_ubicacion_dir,
  f.cod_dw_ubic, f.texto_ubicacion, f.new_cod_dw_direccion_fisica, f.nuevo_complemento,
  'N', NULL
FROM bdm_stage.stg_motor_final f;

-- PASO 7: SUBCASO 2 — Valores iguales, diccionario decide padre
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2;
CREATE TABLE bdm_stage.stg_regla2_e05_sub2
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM bdm_stage.stg_regla2_e05_a A
JOIN bdm_stage.stg_regla2_e05_a B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.complemento              <> B.complemento
  AND TRIM(A.complemento2) = TRIM(B.complemento2)
  AND A.nivel_pri <> B.nivel_pri
WHERE A.cod_dw_persona_ubic NOT IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e05_sub1);

ANALYZE bdm_stage.stg_regla2_e05_sub2;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_freq;
CREATE TABLE bdm_stage.stg_regla2_e05_sub2_freq
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT t1.cod_dw_persona_ubic, COALESCE(t2.conteo, 0) AS conteo
FROM bdm_stage.stg_regla2_e05_sub2 t1
LEFT JOIN (
  SELECT t1.cod_dw_persona_ubic, SUM(dc.frecuencia) AS conteo
  FROM bdm_stage.stg_regla2_e05_sub2 t1
  LEFT JOIN bdm_stage.diccionario_complementos dc
    ON t1.cod_dw_ubic = dc.cod_dw_ubic
    AND t1.complemento LIKE '%' || dc.nomenclatura || '%'
    AND t1.id_buro_persona = dc.id_buro_persona
  GROUP BY 1
) t2 ON t1.cod_dw_persona_ubic = t2.cod_dw_persona_ubic;

ANALYZE bdm_stage.stg_regla2_e05_sub2_freq;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_d;
CREATE TABLE bdm_stage.stg_regla2_e05_sub2_d
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT u1.*,
  COUNT(*) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id) AS count_empate,
  MAX(id) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio) AS idmax
FROM (
  SELECT a.cod_dw_persona_ubic,
    (COALESCE(b.conteo, 0) + 10000000)
      + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0) AS id,
    a.texto_ubicacion, a.id_buro_persona, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio,
    a.cod_dw_ubic, a.complemento,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
      ORDER BY (COALESCE(b.conteo, 0) + 10000000)
        + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0)
    ) AS orden
  FROM bdm_stage.stg_regla2_e05_sub2 a
  LEFT JOIN bdm_stage.stg_regla2_e05_sub2_freq b ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
) u1;

ANALYZE bdm_stage.stg_regla2_e05_sub2_d;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_e;
CREATE TABLE bdm_stage.stg_regla2_e05_sub2_e
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT B.cod_dw_persona_ubic, A.cod_dw_persona_ubic AS id_padre
FROM bdm_stage.stg_regla2_e05_sub2_d A
JOIN bdm_stage.stg_regla2_e05_sub2_d B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.id > B.id
JOIN (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, MAX(orden) AS max_orden
  FROM bdm_stage.stg_regla2_e05_sub2_d GROUP BY 1,2,3,4
) mx ON A.id_buro_persona = mx.id_buro_persona AND A.texto_ubicacion = mx.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = mx.cod_dw_municipio
  AND A.orden = mx.max_orden;

ANALYZE bdm_stage.stg_regla2_e05_sub2_e;

UPDATE bdm_stage.stg_regla2_e2
SET id_padre = e.id_padre, ind_unificacion = 'S', n_id = 'D5'
FROM bdm_stage.stg_regla2_e05_sub2_e e
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = e.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.id_padre IS NULL;

INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT e.cod_dw_persona_ubic, e.id_padre AS cod_dw_direccion_unificada,
  2, CURRENT_DATE, 1, 1, LEFT(CURRENT_USER, 30)
FROM bdm_stage.stg_regla2_e05_sub2_e e;

UPDATE bdm_stage.relacion_persona_ubicacion SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e05_sub2_e);

-- PASO 8: Estadísticas y limpieza
ANALYZE bdm_stage.unificacion_direccion;
ANALYZE bdm_stage.relacion_persona_ubicacion;
ANALYZE bdm_stage.stg_regla2_e2;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_a;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_c;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub1;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_freq;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_d;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_e;
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
DROP TABLE IF EXISTS bdm_stage.stg_motor_final;
DROP TABLE IF EXISTS bdm_stage.stg_motor_padre;
DROP TABLE IF EXISTS bdm_stage.stg_motor_hijo;
