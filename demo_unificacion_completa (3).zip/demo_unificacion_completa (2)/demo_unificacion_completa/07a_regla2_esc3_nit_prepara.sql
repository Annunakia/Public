-- ============================================================
-- 07a_regla2_esc3_nit_prepara.sql
-- Regla 2 Escenario 3 NIT: PARTE 1 — Prepara stg_motor_input
-- Ejecutar ANTES del motor (06_motor_nuevas_direcciones.sql)
-- ============================================================

-- PASO 1: Filtrar no-unificados que SÍ son NIT
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e031;
CREATE TABLE bdm_stage.stg_regla2_e031
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT a.*
FROM bdm_stage.stg_regla2_e2 a
JOIN bdm_stage.relacion_persona_ubicacion rpu
  ON a.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE a.ind_unificacion = 'N'
  AND rpu.cod_tipo_ident_fte = 3;

ANALYZE bdm_stage.stg_regla2_e031;

-- PASO 2: Encontrar pares con misma nomenclatura, diferente valor
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_nit_pares;
CREATE TABLE bdm_stage.stg_regla2_e03_nit_pares
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT a.cod_dw_persona_ubic
FROM bdm_stage.stg_regla2_e031 a
JOIN bdm_stage.stg_regla2_e031 b
  ON  a.id_buro_persona          = b.id_buro_persona
  AND a.texto_ubicacion           = b.texto_ubicacion
  AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
  AND a.cod_dw_municipio          = b.cod_dw_municipio
  AND a.cod_dw_persona_ubic      <> b.cod_dw_persona_ubic
  AND a.complemento              <> b.complemento
JOIN bdm_stage.nomenclatura nmc1
  ON a.complemento LIKE nmc1.nomenclatura || '%'
JOIN bdm_stage.nomenclatura nmc2
  ON b.complemento LIKE nmc2.nomenclatura || '%'
WHERE nmc1.nomenclatura = nmc2.nomenclatura;

ANALYZE bdm_stage.stg_regla2_e03_nit_pares;

-- PASO 3: Preparar stg_motor_input
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
CREATE TABLE bdm_stage.stg_motor_input
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  e.cod_dw_persona_ubic,
  e.cod_dw_ubic,
  e.complemento,
  e.id_buro_persona,
  e.cod_dw_tipo_ubicacion_dir,
  rpu.cod_pin_persona,
  rpu.cod_dw_direccion_fisica,
  e.texto_ubicacion,
  e.fecha_relacion_persona_ubicaci
FROM bdm_stage.stg_regla2_e031 e
JOIN bdm_stage.stg_regla2_e03_nit_pares p
  ON e.cod_dw_persona_ubic = p.cod_dw_persona_ubic
JOIN bdm_stage.relacion_persona_ubicacion rpu
  ON e.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

ANALYZE bdm_stage.stg_motor_input;
