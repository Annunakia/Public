# Guion Demo — Unificación Completa (R1 + R2 + R3) en Redshift

> **Duración estimada:** 30-40 minutos
> **Herramienta:** DBeaver conectado a Redshift Serverless
> **Objetivo:** Demostrar que las 3 reglas de Unificación funcionan en cascada, cumpliendo criterios de aceptación.

---

## PARTE 1 — Contexto

> "Reconocer es un producto de Experian que determina cuál es la mejor forma de contactar a una persona. Procesa ~65-70 millones de registros de direcciones, teléfonos y emails."

> "Unificación es el proceso que toma todas las direcciones físicas de una persona y elimina redundancias. Se aplican 3 reglas en cascada: R1 decide por tipo de uso, R2 por complementos, R3 por geolocalización."

```
XPM (JSON) → Relationalize → Tablas en Redshift → R1 → R2 → R3 → Ordenamiento
```

---

## PARTE 2 — Cargar datos

### Ejecutar en DBeaver:
Abrir y ejecutar completo: `01_demo_setup.sql`

### Ver datos cargados:

```sql
-- Personas y sus direcciones
SELECT rpu.id_buro_persona AS persona,
  ubi.texto_ubicacion AS direccion,
  tud.descripcion_tipo_ubicacion_dir AS tipo_uso,
  df.complemento,
  ciiu.cod_act_econo_ciiu_fte AS ciiu
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona
WHERE rpu.ind_unificacion IS NULL
ORDER BY rpu.id_buro_persona, rpu.cod_dw_persona_ubic;
```

```sql
-- Catálogo de tipos de uso
SELECT * FROM bdm_stage.tipo_ubicacion_dir;
```

```sql
-- Catálogo de nomenclaturas (niveles)
SELECT * FROM bdm_stage.nomenclatura ORDER BY nivel_complemento, nomenclatura;
```

---

## PARTE 3 — Regla 1: Tipo de Uso + CIIU

### Narrativa:
> "Regla 1 busca direcciones de una misma persona que comparten la misma puerta pero tienen diferente tipo de uso (RES, LAB, CRR). Según la actividad económica (CIIU) de la persona, decide cuál prevalece."

### Ejecutar en DBeaver:
Abrir y ejecutar completo: `02_regla1_unificacion.sql`

### Consultas de resultado:

```sql
-- Pares padre-hijo generados por R1
SELECT cod_dw_persona_ubic AS hijo,
  cod_dw_direccion_unificada AS padre,
  unifica_atributos AS regla
FROM bdm_stage.unificacion_direccion
WHERE unifica_atributos = 1
ORDER BY hijo;
```

```sql
-- Vista completa con score
SELECT rpu.id_buro_persona AS persona,
  tud.descripcion_tipo_ubicacion_dir AS tipo_uso,
  ciiu.cod_act_econo_ciiu_fte AS ciiu,
  COUNT(DISTINCT rep.id_buro_suscriptor) AS entidades,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS resultado
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
LEFT JOIN bdm_stage.ciiu_persona ciiu ON rpu.id_buro_persona = ciiu.id_buro_persona
LEFT JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
WHERE rpu.id_buro_persona IN (1001, 1002, 1003, 1004, 1005)
GROUP BY 1,2,3,5
ORDER BY rpu.id_buro_persona, resultado;
```

### Resultado esperado:

| Hijo | Padre | Persona | Explicación |
|------|-------|---------|-------------|
| 100 | 101 | 1001 | CIIU=10, RES(2 ent) pierde vs LAB(5 ent). Asalariado → prefiere LAB |
| 200 | 201 | 1002 | CIIU=81, LAB(1 ent) pierde vs RES(4 ent). Sin actividad → prefiere RES |
| 300 | 301 | 1003 | CIIU=55, RES(2 ent) pierde vs CRR(6 ent). Otro CIIU → mayor entidades |

**No deben aparecer:**
- Persona 1004: LAB(3 ent) vs CRR(3 ent) → EMPATE, no se unifica
- Persona 1005: RES ya tenía `ind_unificacion=1` → no entra al proceso

### Explicación:
> "Persona 1001 es asalariada (CIIU=10). Tiene la misma puerta 'CL 45 12 33' como RES y como LAB. Para un asalariado, se prefiere LAB porque es más probable contactarlo en el trabajo. Además LAB tiene más entidades (5 vs 2), confirmando que es la más reportada."

> "Persona 1004 tiene LAB y CRR, ambas con bonus 100,000 (por CIIU=10 ambas son preferidas), y ambas con 3 entidades. Empate perfecto → no se fuerza decisión."

> "Persona 1005 ya tenía una dirección marcada como hija (ind_unificacion=1 de una ejecución anterior). El proceso la filtra con WHERE ind_unificacion IS NULL."

### Criterios validados:
- ✅ R1-01: CIIU=10, LAB gana
- ✅ R1-02: CIIU=81, RES gana
- ✅ R1-03: Otro CIIU, mayor entidades
- ✅ R1-04: Hijos marcados con ind_unificacion=1
- ✅ R1-05: Pares registrados en unificacion_direccion
- ✅ R1-06: Hija previa no entra
- ✅ R1-07: Baseline CIIU (10, 81/82/90)
- ✅ R1-08: Empate = no decisión

---

## PARTE 4 — Regla 2: Complementos

### Narrativa:
> "Regla 2 busca direcciones con la misma puerta pero diferente complemento. Evalúa 6 escenarios para decidir cuál es más completa, o si debe generar una nueva dirección combinando ambas."

### Ejecutar en DBeaver (en este orden):
1. `03_regla2_esc1_2.sql`
2. `04_regla2_esc4.sql`
3. `05_regla2_esc3_sin_nit.sql`
4. `07a_regla2_esc3_nit_prepara.sql` (de carpeta demo/)
5. `06_motor_nuevas_direcciones.sql`
6. `07b_regla2_esc3_nit_finaliza.sql` (de carpeta demo/)
7. `08_regla2_esc5.sql`
8. `09_regla2_esc6.sql`

### Consultas de resultado:

```sql
-- Pares padre-hijo de R2
SELECT cod_dw_persona_ubic AS hijo,
  cod_dw_direccion_unificada AS padre,
  unifica_atributos AS regla
FROM bdm_stage.unificacion_direccion
WHERE unifica_atributos = 2
ORDER BY hijo;
```

```sql
-- Nueva dirección generada (caso NIT)
SELECT cod_dw_direccion_fisica, complemento, generada_enriquecida
FROM bdm_stage.direccion_fisica
WHERE generada_enriquecida = 1;
```

```sql
-- Detalle de complementos por persona R2
SELECT rpu.id_buro_persona AS persona,
  df.complemento,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS resultado
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.id_buro_persona IN (2001, 2002, 2003, 2004)
ORDER BY rpu.id_buro_persona, resultado;
```

### Resultado esperado:

| Hijo | Padre | Persona | Escenario | Explicación |
|------|-------|---------|-----------|-------------|
| 600 | 601 | 2001 | Esc 1 | Complemento vacío vs "AP 802" → gana el informado |
| 700 | 701 | 2002 | Esc 2 | "AP 702" vs "ED GALICIA AP 702" → gana el más completo (contiene al otro) |
| 800 | 801 | 2003 | Esc 3 | "AP 105"(2 ent) vs "AP 404"(6 ent) → misma nomenclatura, gana mayor entidades |
| 900 | 1602 | 2004 | Esc 3 NIT | "LC 101" → hijo del nuevo padre generado |
| 901 | 1602 | 2004 | Esc 3 NIT | "LC 205" → hijo del nuevo padre generado |

**Nueva dirección generada:**
| ID | Complemento | Flag |
|----|-------------|------|
| 6026 | LC 101 LC 205 | generada_enriquecida = 1 |

### Explicación:
> "Persona 2001: una dirección tiene complemento vacío, la otra tiene 'AP 802'. No tiene sentido usar la vacía cuando hay una más completa. Gana la informada."

> "Persona 2002: 'AP 702' está contenido completamente dentro de 'ED GALICIA AP 702'. La segunda es más completa — incluye el edificio."

> "Persona 2003: ambas tienen nomenclatura AP pero con diferente número (105 vs 404). No son la misma. Se decide por entidades: 'AP 404' tiene 6 suscriptores reportándola vs 2 de 'AP 105'."

> "Persona 2004 es NIT (empresa). Tiene 'LC 101' y 'LC 205' — misma nomenclatura, diferente valor. Para empresas se COMBINAN ambos: se genera nueva dirección 'LC 101 LC 205' que contiene los dos locales. Ambas originales quedan como hijas del nuevo padre."

### Criterios validados:
- ✅ R2-01: Vacío vs informado → gana informado
- ✅ R2-02: Incluido → gana el más completo
- ✅ R2-03: Misma nomenclatura sin NIT → mayor entidades
- ✅ R2-04: NIT → genera nueva dirección combinada
- ✅ R2-08: Nueva dirección marcada con generada_enriquecida=1
- ✅ R2-09: Nueva dirección tiene relación persona-ubicación
- ✅ R2-10: Padre nunca marcado como hijo
- ✅ R2-11: Cada hija tiene exactamente 1 padre

---

## PARTE 5 — Regla 3: Geolocalización

### Narrativa:
> "Regla 3 busca direcciones tipo vía que difieren en vía generadora o número de puerta. Usa coordenadas geográficas como indicador de calidad. Si una dirección fue geolocalizada y la otra no, la geolocalizada es más confiable."

### Ejecutar en DBeaver:
Abrir y ejecutar completo: `10_regla3_geo.sql`

### Consultas de resultado:

```sql
-- Todos los pares después de R3 (incluye R1 + R2 + R3)
SELECT cod_dw_persona_ubic AS hijo,
  cod_dw_direccion_unificada AS padre,
  unifica_atributos AS regla
FROM bdm_stage.unificacion_direccion
ORDER BY regla, hijo;
```

```sql
-- Detalle R3: personas con sus coordenadas y resultado
SELECT rpu.id_buro_persona AS persona,
  ubi.texto_ubicacion AS direccion,
  df.via_generadora,
  df.numero_puerta,
  ubi.latitud,
  ubi.longitud,
  CASE WHEN rpu.ind_unificacion = 1 THEN 'HIJO' ELSE 'PADRE' END AS resultado
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
WHERE rpu.id_buro_persona IN (3001, 3002, 3003, 3004)
ORDER BY rpu.id_buro_persona, resultado;
```

### Resultado esperado:

| Hijo | Padre | Persona | Subcaso | Explicación |
|------|-------|---------|---------|-------------|
| 1301 | 1300 | 3001 | Subcaso 1 | Vía gen 78 vs 80. Solo 5011 tiene lat/long → gana la geolocalizada |
| 1400 | 1401 | 3002 | Subcaso 2 | Puerta 33 vs 35 (dif=2). Ninguna con geo → gana fecha más reciente (2025-08 vs 2025-03) |
| 1500 | 1501 | 3003 | Subcaso 3 | Vía gen 20 vs 22. Ambas con geo → diccionario vía: freq 20=15 vs freq 22=8 → gana 20 |

**No debe aparecer:**
- Persona 3004: Puerta 50 vs 55 (dif=5 > 2) → NO unifica. La diferencia es demasiado grande.

### Explicación:
> "Persona 3001: tiene dos direcciones que difieren en vía generadora (78 vs 80). La dirección 'CL 34 78 52' tiene coordenadas geográficas (lat=4.61, long=-74.08), la otra no. Una dirección geolocalizada es más confiable porque se pudo verificar geográficamente. Gana la que tiene geo."

> "Persona 3002: difieren en número de puerta (33 vs 35). La diferencia es ≤2, entonces son candidatas. Ninguna tiene coordenadas, entonces se desempata por fecha: 2025-08-01 es más reciente que 2025-03-01. Gana la más reciente."

> "Persona 3003: difieren en vía generadora (20 vs 22). Ambas tienen coordenadas. Se consulta el Diccionario de Vía: la vía generadora 20 se ha reportado 15 veces, la 22 solo 8 veces. La más reportada históricamente es más confiable."

> "Persona 3004: difieren en puerta (50 vs 55). La diferencia es 5, que es mayor a ±2. El proceso asume que son direcciones DIFERENTES (no un error de digitación) y no las unifica."

### Criterios validados:
- ✅ R3-01: Solo tipo Vía
- ✅ R3-02: Solo una con lat/long → gana geolocalizada
- ✅ R3-03: Ninguna con lat/long → fecha más reciente
- ✅ R3-04: Ambas con lat/long → diccionario de vía
- ✅ R3-05: Valida umbral ±2
- ✅ R3-06: Diferencia > 2 → NO unifica

---

## PARTE 6 — Resumen Final

### Consulta resumen:

```sql
-- Resumen por regla
SELECT unifica_atributos AS regla, COUNT(*) AS pares
FROM bdm_stage.unificacion_direccion
GROUP BY 1 ORDER BY 1;
```

```sql
-- Direcciones vigentes vs absorbidas
SELECT
  CASE WHEN ind_unificacion = 1 THEN 'ABSORBIDA (hijo)' ELSE 'VIGENTE (padre/independiente)' END AS estado,
  COUNT(*) AS cantidad
FROM bdm_stage.relacion_persona_ubicacion
GROUP BY 1;
```

```sql
-- Direcciones que pasan a Ordenamiento (solo vigentes)
SELECT rpu.id_buro_persona AS persona,
  ubi.texto_ubicacion AS direccion,
  df.complemento,
  tud.descripcion_tipo_ubicacion_dir AS tipo_uso
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.tipo_ubicacion_dir tud ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
WHERE rpu.ind_unificacion IS NULL
ORDER BY rpu.id_buro_persona;
```

### Resultado esperado resumen:

| Métrica | Valor |
|---------|-------|
| Total unificaciones R1 | 7 (3 propias + 4 de R3) |
| Total unificaciones R2 | 5 |
| Total pares | 12 |
| Direcciones absorbidas | ~12 |
| Direcciones vigentes | ~21 |
| Nuevas direcciones generadas | 1 (LC 101 LC 205) |

### Criterios generales validados:
- ✅ G-01: Cascada R1 → R2 → R3 ejecutada en orden
- ✅ G-02: Padres de R1 pueden ser hijos en R2 (si aplicara)
- ✅ G-03: Hijas no se re-procesan
- ✅ G-05: Toda unificación genera registro de trazabilidad
- ✅ G-07: Solo se comparan direcciones de la misma persona
- ✅ G-08: Nada se borró — unificación es lógica
- ✅ G-09: Hijas no pasarían a ordenamiento
- ✅ G-10: Padres vigentes sí pasan a ordenamiento

---

## Limpieza (después de la demo)

Ejecutar en DBeaver: `03_demo_cleanup.sql`

---

## Archivos de la demo

| Archivo | Ubicación | Función |
|---------|-----------|---------|
| `01_demo_setup.sql` | demo/ | Crea tablas + carga 16 personas |
| `02_regla1_unificacion.sql` | src/redshift/sql/ | Regla 1 |
| `03_regla2_esc1_2.sql` | src/redshift/sql/ | R2 Escenarios 1-2 |
| `04_regla2_esc4.sql` | src/redshift/sql/ | R2 Escenario 4 |
| `05_regla2_esc3_sin_nit.sql` | src/redshift/sql/ | R2 Escenario 3 sin NIT |
| `07a_regla2_esc3_nit_prepara.sql` | demo/ | R2 Esc 3 NIT parte 1 |
| `06_motor_nuevas_direcciones.sql` | src/redshift/sql/ | Motor nuevas direcciones |
| `07b_regla2_esc3_nit_finaliza.sql` | demo/ | R2 Esc 3 NIT parte 2 |
| `08_regla2_esc5.sql` | src/redshift/sql/ | R2 Escenario 5 |
| `09_regla2_esc6.sql` | src/redshift/sql/ | R2 Escenario 6 |
| `10_regla3_geo.sql` | src/redshift/sql/ | Regla 3 |
| `03_demo_cleanup.sql` | demo/ | Limpieza |
