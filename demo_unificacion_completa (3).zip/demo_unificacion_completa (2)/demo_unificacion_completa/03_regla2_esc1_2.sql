-- ============================================================
-- 03_regla2_esc1_2.sql
-- Regla 2 Escenarios 1-2: Unificación por Complementos
-- Fuente Teradata: PRO_UnificacionR2.sql líneas 72-439
-- ============================================================
-- Prerequisito: Regla 1 ya ejecutada (02_regla1_unificacion.sql)
--
-- Escenario 1: Un complemento vacío, otro no → padre = el que tiene complemento
-- Escenario 2: Un complemento incluido en otro → padre = el más completo
--
-- Criterio de agrupación:
--   Id_Buro_Persona + Texto_Ubicacion + Cod_DW_Tipo_Ubicacion_Dir + Cod_DW_Municipio
-- ============================================================

-- PASO 1: Materializar insumo de Regla 2
-- Solo registros NO unificados por Regla 1 (ind_unificacion IS NULL)
DROP TABLE IF EXISTS bdm_stage.stg_regla2_insumo;
CREATE TABLE bdm_stage.stg_regla2_insumo
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, texto_ubicacion)
AS
SELECT
  rpu.cod_dw_persona_ubic,
  rpu.cod_pin_persona,
  rpu.id_buro_persona,
  rpu.cod_dw_tipo_ubicacion_dir,
  rpu.cod_dw_ubic,
  ubi.texto_ubicacion,
  rpu.cod_dw_direccion_fisica,
  df.complemento,
  rpu.cod_dw_tipo_ubicacion_dir AS cod_dw_municipio,  -- TODO: confirmar campo municipio real
  COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor), 0) AS numero_entidades_reportan,
  rpu.fecha_relacion_persona_ubicaci
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi
  ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df
  ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
JOIN bdm_stage.reporte_relacion_persona_ubica rep
  ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
WHERE rpu.ind_unificacion IS NULL
GROUP BY 1,2,3,4,5,6,7,8,9,11;

ANALYZE bdm_stage.stg_regla2_insumo;

-- PASO 2: Escenario 1 — Un complemento vacío, otro no
-- A tiene complemento, B no → B es hijo de A
-- A no tiene complemento, B sí → A es hijo de B
DROP TABLE IF EXISTS bdm_stage.stg_regla2_esc1_pares;
CREATE TABLE bdm_stage.stg_regla2_esc1_pares
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT cod_dw_persona_ubic, id_padre
FROM (
  -- Caso 1: B no tiene complemento → B es hijo, A es padre
  SELECT
    b.cod_dw_persona_ubic,
    a.cod_dw_persona_ubic AS id_padre,
    ROW_NUMBER() OVER (PARTITION BY b.cod_dw_persona_ubic ORDER BY a.cod_dw_persona_ubic DESC) AS rn
  FROM bdm_stage.stg_regla2_insumo a
  JOIN bdm_stage.stg_regla2_insumo b
    ON  a.id_buro_persona           = b.id_buro_persona
    AND a.texto_ubicacion            = b.texto_ubicacion
    AND a.cod_dw_tipo_ubicacion_dir  = b.cod_dw_tipo_ubicacion_dir
    AND a.cod_dw_municipio           = b.cod_dw_municipio
    AND a.cod_dw_persona_ubic       <> b.cod_dw_persona_ubic
  WHERE a.complemento IS NOT NULL
    AND b.complemento IS NULL

  UNION ALL

  -- Caso 2: A no tiene complemento → A es hijo, B es padre
  SELECT
    a.cod_dw_persona_ubic,
    b.cod_dw_persona_ubic AS id_padre,
    ROW_NUMBER() OVER (PARTITION BY a.cod_dw_persona_ubic ORDER BY b.cod_dw_persona_ubic DESC) AS rn
  FROM bdm_stage.stg_regla2_insumo a
  JOIN bdm_stage.stg_regla2_insumo b
    ON  a.id_buro_persona           = b.id_buro_persona
    AND a.texto_ubicacion            = b.texto_ubicacion
    AND a.cod_dw_tipo_ubicacion_dir  = b.cod_dw_tipo_ubicacion_dir
    AND a.cod_dw_municipio           = b.cod_dw_municipio
    AND a.cod_dw_persona_ubic       <> b.cod_dw_persona_ubic
  WHERE b.complemento IS NOT NULL
    AND a.complemento IS NULL
)
WHERE rn = 1;

ANALYZE bdm_stage.stg_regla2_esc1_pares;

-- PASO 3: Construir tabla intermedia E1 con marca de unificación
-- Hereda todos los registros del insumo, marcando hijos del Esc 1
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e1;
CREATE TABLE bdm_stage.stg_regla2_e1
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, texto_ubicacion)
AS
SELECT
  a.cod_dw_persona_ubic,
  b.id_padre,
  a.id_buro_persona,
  a.cod_dw_tipo_ubicacion_dir,
  a.cod_dw_ubic,
  a.texto_ubicacion,
  a.cod_dw_direccion_fisica,
  a.complemento,
  a.cod_dw_municipio,
  a.numero_entidades_reportan,
  a.fecha_relacion_persona_ubicaci,
  CASE WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S' ELSE 'N' END AS ind_unificacion,
  CASE WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'H1' END AS n_id,
  ROW_NUMBER() OVER (
    PARTITION BY a.id_buro_persona, a.cod_dw_ubic,
      CASE WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S' ELSE 'N' END,
      a.cod_dw_tipo_ubicacion_dir
    ORDER BY a.complemento
  ) AS row_u
FROM bdm_stage.stg_regla2_insumo a
LEFT JOIN bdm_stage.stg_regla2_esc1_pares b
  ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic;

ANALYZE bdm_stage.stg_regla2_e1;

-- PASO 4: Escenario 2 — Un complemento incluido en otro
-- Solo procesa registros con ind_unificacion='N' (no unificados por Esc 1)
-- A.COMPLEMENTO contiene B.COMPLEMENTO → B es hijo de A
DROP TABLE IF EXISTS bdm_stage.stg_regla2_esc2_pares;
CREATE TABLE bdm_stage.stg_regla2_esc2_pares
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT cod_dw_persona_ubic, id_padre
FROM (
  -- Caso 1: B contenido en A → B es hijo
  SELECT
    b.cod_dw_persona_ubic,
    a.cod_dw_persona_ubic AS id_padre,
    ROW_NUMBER() OVER (PARTITION BY b.cod_dw_persona_ubic ORDER BY b.cod_dw_persona_ubic DESC) AS rn
  FROM bdm_stage.stg_regla2_e1 a
  JOIN bdm_stage.stg_regla2_e1 b
    ON  a.id_buro_persona           = b.id_buro_persona
    AND a.texto_ubicacion            = b.texto_ubicacion
    AND a.cod_dw_tipo_ubicacion_dir  = b.cod_dw_tipo_ubicacion_dir
    AND a.cod_dw_municipio           = b.cod_dw_municipio
    AND a.cod_dw_persona_ubic       <> b.cod_dw_persona_ubic
    AND a.complemento               <> b.complemento
  WHERE a.complemento LIKE '%' || b.complemento || '%'
    AND a.ind_unificacion = 'N'

  UNION ALL

  -- Caso 2: A contenido en B → A es hijo
  SELECT
    a.cod_dw_persona_ubic,
    b.cod_dw_persona_ubic AS id_padre,
    ROW_NUMBER() OVER (PARTITION BY a.cod_dw_persona_ubic ORDER BY a.cod_dw_persona_ubic DESC) AS rn
  FROM bdm_stage.stg_regla2_e1 a
  JOIN bdm_stage.stg_regla2_e1 b
    ON  a.id_buro_persona           = b.id_buro_persona
    AND a.texto_ubicacion            = b.texto_ubicacion
    AND a.cod_dw_tipo_ubicacion_dir  = b.cod_dw_tipo_ubicacion_dir
    AND a.cod_dw_municipio           = b.cod_dw_municipio
    AND a.cod_dw_persona_ubic       <> b.cod_dw_persona_ubic
    AND a.complemento               <> b.complemento
  WHERE b.complemento LIKE '%' || a.complemento || '%'
    AND a.ind_unificacion = 'N'
)
WHERE rn = 1;

ANALYZE bdm_stage.stg_regla2_esc2_pares;

-- PASO 5: Construir tabla E2 acumulada (hereda Esc 1 + agrega Esc 2)
-- Esta tabla será input para escenarios 3-6 en el siguiente script
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e2;
CREATE TABLE bdm_stage.stg_regla2_e2
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, texto_ubicacion)
AS
SELECT
  a.cod_dw_persona_ubic,
  CASE WHEN a.id_padre IS NOT NULL THEN a.id_padre ELSE b.id_padre END AS id_padre,
  a.id_buro_persona,
  a.cod_dw_tipo_ubicacion_dir,
  a.cod_dw_ubic,
  a.texto_ubicacion,
  a.cod_dw_direccion_fisica,
  a.complemento,
  a.cod_dw_municipio,
  a.numero_entidades_reportan,
  a.fecha_relacion_persona_ubicaci,
  CASE
    WHEN a.ind_unificacion = 'S' THEN 'S'
    WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S'
    ELSE 'N'
  END AS ind_unificacion,
  CASE
    WHEN a.n_id IS NOT NULL THEN a.n_id
    WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'K2'
  END AS n_id,
  ROW_NUMBER() OVER (
    PARTITION BY a.id_buro_persona, a.cod_dw_ubic,
      CASE
        WHEN a.ind_unificacion = 'S' THEN 'S'
        WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S'
        ELSE 'N'
      END,
      a.cod_dw_tipo_ubicacion_dir
    ORDER BY a.complemento
  ) AS row_u
FROM bdm_stage.stg_regla2_e1 a
LEFT JOIN bdm_stage.stg_regla2_esc2_pares b
  ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic;

ANALYZE bdm_stage.stg_regla2_e2;

-- PASO 6: Persistir pares padre-hijo de Esc 1 y 2 en tabla de unificación
INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT
  e.cod_dw_persona_ubic,
  e.id_padre AS cod_dw_direccion_unificada,
  2 AS unifica_atributos,
  CURRENT_DATE AS fecha_unificacion,
  1 AS lote,
  1 AS severidad,
  LEFT(CURRENT_USER, 30) AS usuario_bd
FROM bdm_stage.stg_regla2_e2 e
WHERE e.ind_unificacion = 'S'
  AND e.id_padre IS NOT NULL;

-- PASO 7: Marcar hijos en relacion_persona_ubicacion
UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic
  FROM bdm_stage.stg_regla2_e2
  WHERE ind_unificacion = 'S'
    AND id_padre IS NOT NULL
);

-- PASO 8: Actualizar estadísticas
ANALYZE bdm_stage.unificacion_direccion;
ANALYZE bdm_stage.relacion_persona_ubicacion;

-- PASO 9: Limpiar staging de escenarios 1-2
-- NOTA: stg_regla2_e2 se mantiene como input para escenarios 3-6
DROP TABLE IF EXISTS bdm_stage.stg_regla2_insumo;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_esc1_pares;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e1;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_esc2_pares;
