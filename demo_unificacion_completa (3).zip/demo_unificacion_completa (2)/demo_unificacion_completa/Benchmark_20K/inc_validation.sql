-- ============================================================
-- VALIDATION — conteos post-run sobre lote completo
-- ============================================================

SELECT 'VAL personas' AS metric, COUNT(DISTINCT id_buro_persona) AS val FROM bdm_stage.relacion_persona_ubicacion;
SELECT 'VAL rpu_total' AS metric, COUNT(*) AS val FROM bdm_stage.relacion_persona_ubicacion;
SELECT 'VAL rpu_vigentes' AS metric, COUNT(*) AS val FROM bdm_stage.relacion_persona_ubicacion WHERE ind_unificacion IS NULL;
SELECT 'VAL rpu_hijas' AS metric, COUNT(*) AS val FROM bdm_stage.relacion_persona_ubicacion WHERE ind_unificacion = 1;
SELECT 'VAL unificaciones' AS metric, COUNT(*) AS val FROM bdm_stage.unificacion_direccion;
SELECT 'VAL generada_enriquecida' AS metric, COUNT(*) AS val FROM bdm_stage.direccion_fisica WHERE generada_enriquecida = 1;

SELECT m.scenario_code, COUNT(DISTINCT m.id_buro_persona) AS personas,
  SUM(CASE WHEN u.cod_dw_persona_ubic IS NOT NULL THEN 1 ELSE 0 END) AS rpu_unificadas
FROM bdm_stage.perf_persona_meta m
LEFT JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
LEFT JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic
GROUP BY 1 ORDER BY 1;

-- Invariante: padre (destino) no debe ser hijo
SELECT 'INV padre_no_hijo' AS check_name, COUNT(*) AS violaciones
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
WHERE r.ind_unificacion = 1;

-- CONTROL: deben quedar 2 vigentes por persona
SELECT 'INV control_vigentes' AS check_name, COUNT(*) AS violaciones
FROM bdm_stage.perf_persona_meta m
WHERE m.scenario_code = 'CONTROL'
  AND (
    SELECT COUNT(*) FROM bdm_stage.relacion_persona_ubicacion r
    WHERE r.id_buro_persona = m.id_buro_persona AND r.ind_unificacion IS NULL
  ) <> 2;
