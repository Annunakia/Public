# SDD — Benchmark de performance Unificación (20K personas)

## Objetivo

Medir tiempos del pipeline **R1 → R2 (+ motor) → R3** a escala **20.000 personas** (~40.000 RPU) en Redshift (`bdm_stage`), vía DBeaver, un solo `.sql` por corrida.

## Restricciones

- Sin AWS CLI / consola AWS
- Sin Python en runtime — solo SQL en DBeaver
- Scripts de reglas en raíz del repo — embebidos, sin cambiar lógica

## Dataset — 20.000 personas

### Identificadores

| Campo | Rango / fórmula |
|-------|-----------------|
| `id_buro_persona` | `100000 + persona_seq` (1…N) |
| `cod_dw_persona_ubic` | `id * 1000 + 1`, `+ 2` |
| `cod_dw_ubic` | `id * 1000 + 1`, `+ 2` |
| `cod_dw_direccion_fisica` | `id * 1000 + 101`, `+ 102` |

### Distribución (`persona_seq % 100`)

| Rango mod 100 | % | Escenarios |
|---------------|---|------------|
| 0–11 | 12% | R1 (5 subtipos) |
| 12–29 | 18% | R2 directa |
| 30–39 | 10% | R2 motor |
| 40–47 | 8% | R2 diccionario |
| 48–59 | 12% | R3 |
| 60–99 | 40% | Control (sin unificación) |

### Tabla `perf_scenario_seed`

Plantillas derivadas del demo (`01_demo_setup.sql`). Cada persona hereda forma de escenario; calles/puertas varían con `persona_seq` para evitar colisiones.

### Tablas pobladas

`tipo_ubicacion_dir`, `nomenclatura`, `ubicacion_estandarizada`, `direccion_fisica`, `relacion_persona_ubicacion`, `ciiu_persona`, `reporte_relacion_persona_ubica`, `diccionario_complementos`, `diccionario_via`, `unificacion_direccion` (vacía), `relacion_ubicac_estandar_geo`.

## Instrumentación

Tabla `bdm_stage.perf_timings`: `run_id`, `step_order`, `step_id`, `label`, `started_at`, `ended_at`, `duration_sec`, `status`.

## Modos motor

| Archivo | Motor |
|---------|-------|
| `00_run_benchmark_20k_demo_fiel.sql` | 07a→06→07b, 08a→06→08b, 09a→06→09b |
| `00_run_benchmark_20k_batch.sql` | Prep unificado → 06×1 → finalize |

## Validación post-run

Conteos globales, desglose por `scenario_code`, invariantes (padre no hijo, hijas no reprocesadas).

## Entregables

Ver [`README.md`](README.md).
