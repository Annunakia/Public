-- ============================================================
-- BATCH MOTOR — prep unificado (07a + 08a + 09a lógica combinada)
-- Reemplaza hitos R2_ESC3_NIT_* .. R2_ESC6_* prep en modo batch
-- ============================================================

/* SOURCE: combinación 07a + 08a + 09a */

-- --- 07a NIT prep ---
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e031;
CREATE TABLE bdm_stage.stg_regla2_e031
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT a.*
FROM bdm_stage.stg_regla2_e2 a
JOIN bdm_stage.relacion_persona_ubicacion rpu
  ON a.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE a.ind_unificacion = 'N'
  AND rpu.cod_tipo_ident_fte = 3;

ANALYZE bdm_stage.stg_regla2_e031;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_nit_pares;
CREATE TABLE bdm_stage.stg_regla2_e03_nit_pares
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT a.cod_dw_persona_ubic
FROM bdm_stage.stg_regla2_e031 a
JOIN bdm_stage.stg_regla2_e031 b
  ON  a.id_buro_persona          = b.id_buro_persona
  AND a.texto_ubicacion           = b.texto_ubicacion
  AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
  AND a.cod_dw_municipio          = b.cod_dw_municipio
  AND a.cod_dw_persona_ubic      <> b.cod_dw_persona_ubic
  AND a.complemento              <> b.complemento
JOIN bdm_stage.nomenclatura nmc1 ON a.complemento LIKE nmc1.nomenclatura || '%'
JOIN bdm_stage.nomenclatura nmc2 ON b.complemento LIKE nmc2.nomenclatura || '%'
WHERE nmc1.nomenclatura = nmc2.nomenclatura;

DROP TABLE IF EXISTS bdm_stage.stg_motor_input_nit;
CREATE TABLE bdm_stage.stg_motor_input_nit
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT e.cod_dw_persona_ubic, e.cod_dw_ubic, e.complemento, e.id_buro_persona,
  e.cod_dw_tipo_ubicacion_dir, rpu.cod_pin_persona, rpu.cod_dw_direccion_fisica,
  e.texto_ubicacion, e.fecha_relacion_persona_ubicaci, 'NIT' AS motor_src
FROM bdm_stage.stg_regla2_e031 e
JOIN bdm_stage.stg_regla2_e03_nit_pares p ON e.cod_dw_persona_ubic = p.cod_dw_persona_ubic
JOIN bdm_stage.relacion_persona_ubicacion rpu ON e.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

-- --- 08a Esc5 prep (sub1 motor) ---
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05;
CREATE TABLE bdm_stage.stg_regla2_e05
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') A
JOIN (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') B
  ON  A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_a;
CREATE TABLE bdm_stage.stg_regla2_e05_a
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*,
  NMC1.nomenclatura AS nomenclatura_pri, NMC1.nivel_complemento AS nivel_pri,
  NMC2.nomenclatura AS nomenclatura_sec, NMC2.nivel_complemento AS nivel_sec,
  TRIM(REPLACE(REPLACE(A.complemento, COALESCE(NMC1.nomenclatura,''), ''), COALESCE(NMC2.nomenclatura,''), '')) AS complemento2
FROM bdm_stage.stg_regla2_e05 A
LEFT JOIN bdm_stage.nomenclatura NMC1 ON A.complemento LIKE TRIM(NMC1.nomenclatura) || ' %'
LEFT JOIN bdm_stage.nomenclatura NMC2 ON A.complemento LIKE '% ' || TRIM(NMC2.nomenclatura) || ' %'
  AND NMC2.nomenclatura <> COALESCE(NMC1.nomenclatura, '');

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_c;
CREATE TABLE bdm_stage.stg_regla2_e05_c
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT * FROM (
  SELECT DISTINCT A.* FROM bdm_stage.stg_regla2_e05_a A
  JOIN bdm_stage.stg_regla2_e05_a B
    ON A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
    AND (A.complemento2 NOT LIKE '%' || B.complemento2 || '%' OR B.complemento2 NOT LIKE '%' || A.complemento2 || '%')
    AND A.nomenclatura_pri = B.nomenclatura_pri
    AND COALESCE(A.nomenclatura_sec, 'X') <> COALESCE(B.nomenclatura_sec, 'X')
    AND COALESCE(A.nivel_sec, 0) <> COALESCE(B.nivel_sec, 0)
  UNION
  SELECT DISTINCT A.* FROM bdm_stage.stg_regla2_e05_a A
  JOIN bdm_stage.stg_regla2_e05_a B
    ON A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
    AND (A.complemento2 NOT LIKE '%' || B.complemento2 || '%' OR B.complemento2 NOT LIKE '%' || A.complemento2 || '%')
    AND A.nomenclatura_pri <> B.nomenclatura_pri
    AND COALESCE(A.nomenclatura_sec, 'X') = COALESCE(B.nomenclatura_sec, 'X')
    AND A.nivel_pri <> B.nivel_pri
) sub;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub1;
CREATE TABLE bdm_stage.stg_regla2_e05_sub1
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.* FROM bdm_stage.stg_regla2_e05_c A
JOIN bdm_stage.stg_regla2_e05_c B
  ON A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
  AND TRIM(A.complemento2) <> TRIM(B.complemento2);

DROP TABLE IF EXISTS bdm_stage.stg_motor_input_esc5;
CREATE TABLE bdm_stage.stg_motor_input_esc5
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT e.cod_dw_persona_ubic, e.cod_dw_ubic, e.complemento, e.id_buro_persona,
  e.cod_dw_tipo_ubicacion_dir, rpu.cod_pin_persona, rpu.cod_dw_direccion_fisica,
  e.texto_ubicacion, e.fecha_relacion_persona_ubicaci, 'ESC5' AS motor_src
FROM bdm_stage.stg_regla2_e05_sub1 e
JOIN bdm_stage.relacion_persona_ubicacion rpu ON e.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

-- --- 09a Esc6 prep (sub1 motor) ---
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06;
CREATE TABLE bdm_stage.stg_regla2_e06
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') A
JOIN (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') B
  ON  A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_a;
CREATE TABLE bdm_stage.stg_regla2_e06_a
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*,
  NMC1.nomenclatura AS nomenclatura_pri, NMC1.nivel_complemento AS nivel_pri,
  NMC2.nomenclatura AS nomenclatura_sec, NMC2.nivel_complemento AS nivel_sec
FROM bdm_stage.stg_regla2_e06 A
LEFT JOIN bdm_stage.nomenclatura NMC1 ON A.complemento LIKE TRIM(NMC1.nomenclatura) || ' %'
LEFT JOIN bdm_stage.nomenclatura NMC2 ON A.complemento LIKE '% ' || TRIM(NMC2.nomenclatura) || ' %'
  AND NMC2.nomenclatura <> COALESCE(NMC1.nomenclatura, '');

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_c;
CREATE TABLE bdm_stage.stg_regla2_e06_c
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT * FROM (
  SELECT DISTINCT A.* FROM bdm_stage.stg_regla2_e06_a A
  JOIN bdm_stage.stg_regla2_e06_a B
    ON A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
    AND COALESCE(A.nomenclatura_pri, 'A') = COALESCE(B.nomenclatura_sec, 'B')
  UNION
  SELECT DISTINCT A.* FROM bdm_stage.stg_regla2_e06_a A
  JOIN bdm_stage.stg_regla2_e06_a B
    ON A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
    AND COALESCE(A.nomenclatura_sec, 'A') = COALESCE(B.nomenclatura_pri, 'B')
) sub;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub1;
CREATE TABLE bdm_stage.stg_regla2_e06_sub1
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.* FROM bdm_stage.stg_regla2_e06_c A
JOIN bdm_stage.stg_regla2_e06_c B
  ON A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
  AND COALESCE(A.nivel_pri, 0) <> COALESCE(B.nivel_pri, 0);

DROP TABLE IF EXISTS bdm_stage.stg_motor_input_esc6;
CREATE TABLE bdm_stage.stg_motor_input_esc6
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT e.cod_dw_persona_ubic, e.cod_dw_ubic, e.complemento, e.id_buro_persona,
  e.cod_dw_tipo_ubicacion_dir, rpu.cod_pin_persona, rpu.cod_dw_direccion_fisica,
  e.texto_ubicacion, e.fecha_relacion_persona_ubicaci, 'ESC6' AS motor_src
FROM bdm_stage.stg_regla2_e06_sub1 e
JOIN bdm_stage.relacion_persona_ubicacion rpu ON e.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

-- Unificar stg_motor_input
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
CREATE TABLE bdm_stage.stg_motor_input
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT cod_dw_persona_ubic, cod_dw_ubic, complemento, id_buro_persona,
  cod_dw_tipo_ubicacion_dir, cod_pin_persona, cod_dw_direccion_fisica,
  texto_ubicacion, fecha_relacion_persona_ubicaci
FROM bdm_stage.stg_motor_input_nit
UNION ALL
SELECT cod_dw_persona_ubic, cod_dw_ubic, complemento, id_buro_persona,
  cod_dw_tipo_ubicacion_dir, cod_pin_persona, cod_dw_direccion_fisica,
  texto_ubicacion, fecha_relacion_persona_ubicaci
FROM bdm_stage.stg_motor_input_esc5
UNION ALL
SELECT cod_dw_persona_ubic, cod_dw_ubic, complemento, id_buro_persona,
  cod_dw_tipo_ubicacion_dir, cod_pin_persona, cod_dw_direccion_fisica,
  texto_ubicacion, fecha_relacion_persona_ubicaci
FROM bdm_stage.stg_motor_input_esc6;

ANALYZE bdm_stage.stg_motor_input;
