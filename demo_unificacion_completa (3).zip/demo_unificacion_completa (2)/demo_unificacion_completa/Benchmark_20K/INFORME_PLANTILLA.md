# Plantilla informe — Benchmark 20K

Completar tras ejecutar en DBeaver (3 corridas por modo). Exportar CSV desde:

```sql
SELECT step_id, label, duration_sec FROM bdm_stage.perf_timings
WHERE run_id = '<run_id>' ORDER BY step_order;
```

## Modo demo fiel (20K)

| step_id | run_1_s | run_2_s | run_3_s | mediana | p95 |
|---------|---------|---------|---------|---------|-----|
| DATA_LOAD | | | | | |
| R1 | | | | | |
| R2_ESC1_2 | | | | | |
| R2_ESC4 | | | | | |
| R2_ESC3_SIN_NIT | | | | | |
| R2_ESC3_NIT_PREP | | | | | |
| R2_ESC3_NIT_MOTOR | | | | | |
| R2_ESC3_NIT_FIN | | | | | |
| R2_ESC5_PREP | | | | | |
| R2_ESC5_MOTOR | | | | | |
| R2_ESC5_FIN | | | | | |
| R2_ESC6_PREP | | | | | |
| R2_ESC6_MOTOR | | | | | |
| R2_ESC6_FIN | | | | | |
| R3 | | | | | |
| VALIDATION | | | | | |
| **TOTAL E2E** | | | | | |

## Modo batch (20K)

| step_id | run_1_s | run_2_s | run_3_s | mediana | p95 |
|---------|---------|---------|---------|---------|-----|
| DATA_LOAD | | | | | |
| R1 | | | | | |
| R2_ESC1_2 | | | | | |
| R2_ESC4 | | | | | |
| R2_ESC3_SIN_NIT | | | | | |
| R2_MOTOR_BATCH_PREP | | | | | |
| R2_MOTOR_BATCH_RUN | | | | | |
| R2_MOTOR_BATCH_FIN | | | | | |
| R3 | | | | | |
| VALIDATION | | | | | |
| **TOTAL E2E** | | | | | |

## Notas de corrida

- Fecha:
- Workgroup / cluster:
- Personas cargadas (CHECK): 20000
- RPU (CHECK): ~40000
- Cuello de botella observado:
