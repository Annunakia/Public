# Runbook — Benchmark 20K en DBeaver

Ejecución manual en Redshift (sin consola AWS). Esquema **`bdm_stage`**.

---

## Pre-requisitos

- [ ] Conexión DBeaver a Redshift activa
- [ ] Permisos `CREATE` y `USAGE` en `bdm_stage`
- [ ] Timeout de query aumentado (Preferences → Connections → SQL Editor → **Query timeout** ≥ 0 o valor alto; sesiones largas a 20K)

---

## Orden recomendado

| # | Archivo | Personas | Motor |
|:-:|---------|----------|-------|
| 1 | `00_run_benchmark_2k_demo_fiel.sql` | 2.000 | 3× |
| 2 | `00_run_benchmark_20k_demo_fiel.sql` | 20.000 | 3× |
| 3 | `00_run_benchmark_20k_batch.sql` | 20.000 | 1× |

Repetir pasos 2 y 3 **tres veces** cada uno para mediana/p95.

---

## Pasos por corrida

1. Abrir el `.sql` en DBeaver.
2. Línea ~15: cambiar `'benchmark_20k_v1'` por un `run_id` único (ej. `run_20250625_a1`).
3. `Alt+Shift+X` — esperar fin completo.
4. Exportar resultado del reporte final:

```sql
SELECT step_id, label, duration_sec, started_at, ended_at, status
FROM bdm_stage.perf_timings
WHERE run_id = '<tu_run_id>'
ORDER BY step_order;
```

5. Guardar CSV en carpeta local de informes.

---

## Verificaciones post-carga (incluidas en el script)

| Métrica | Esperado |
|---------|----------|
| Personas distintas | 2.000 o 20.000 según archivo |
| Filas RPU | ~2× personas |
| Bloque VALIDATION | Sin error; conteos por escenario |

---

## Informe de performance (plantilla)

Tras 3 corridas del mismo modo, calcular mediana de `duration_sec` por `step_id`:

| step_id | run_1 (s) | run_2 (s) | run_3 (s) | mediana | notas |
|---------|-----------|-----------|-----------|---------|-------|
| DATA_LOAD | | | | | |
| R1 | | | | | |
| R2_ESC3_NIT_MOTOR | | | | | solo demo fiel |
| R2_MOTOR_BATCH_RUN | | | | | solo batch |
| R3 | | | | | |
| **TOTAL** | | | | | suma hitos |

Comparar **demo fiel vs batch** en tiempo total E2E y bloque motor.

---

## Si falla a mitad

- `perf_timings` conserva hitos ya completados.
- Corregir causa, opcionalmente limpiar tablas demo (`03_demo_cleanup.sql` en raíz).
- Re-ejecutar con nuevo `run_id`.

---

## Checklist

```
PRE-CHECK
  □ DBeaver conectado
  □ bdm_stage accesible
  □ Timeout configurado

PILOTO 2K
  □ 00_run_benchmark_2k_demo_fiel.sql
  □ perf_timings OK
  □ VALIDATION conteos OK

BENCHMARK 20K — demo fiel × 3
  □ run_id distinto por corrida
  □ CSV exportados

BENCHMARK 20K — batch × 3
  □ run_id distinto por corrida
  □ CSV exportados

INFORME
  □ Tabla mediana/p95 completada
  □ Cuello de botella identificado
```
