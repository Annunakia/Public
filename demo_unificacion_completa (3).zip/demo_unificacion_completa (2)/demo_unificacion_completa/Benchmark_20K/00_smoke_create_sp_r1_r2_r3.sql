﻿-- Smoke: solo CREATE PROCEDURE (sin carga 20K)
-- Requiere tablas STRCT ya creadas. Alt+Shift+X
-- ============================================================
-- SLCOPRBA-1147-01_bdm_stage_tables.sql
-- STRCT: tablas base Unificacion en bdm_stage
-- Idempotente: CREATE TABLE IF NOT EXISTS
-- ============================================================

CREATE TABLE IF NOT EXISTS bdm_stage.tipo_ubicacion_dir (
  cod_dw_tipo_ubicacion_dir INTEGER ENCODE AZ64,
  descripcion_tipo_ubicacion_dir VARCHAR(20) ENCODE BYTEDICT
) DISTSTYLE ALL;

CREATE TABLE IF NOT EXISTS bdm_stage.nomenclatura (
  nomenclatura VARCHAR(10) ENCODE ZSTD,
  nivel_complemento INTEGER ENCODE AZ64
) DISTSTYLE ALL;

CREATE TABLE IF NOT EXISTS bdm_stage.ubicacion_estandarizada (
  cod_dw_ubic BIGINT ENCODE AZ64,
  texto_ubicacion VARCHAR(200) ENCODE ZSTD,
  cod_dw_ciudad INTEGER ENCODE AZ64,
  latitud DECIMAL(10,7),
  longitud DECIMAL(10,7)
) DISTSTYLE KEY DISTKEY(cod_dw_ubic) SORTKEY(cod_dw_ubic);

CREATE TABLE IF NOT EXISTS bdm_stage.direccion_fisica (
  cod_dw_direccion_fisica BIGINT ENCODE AZ64,
  complemento VARCHAR(100) ENCODE ZSTD,
  cod_dw_ubic BIGINT ENCODE AZ64,
  tipo_via_principal VARCHAR(5) ENCODE ZSTD,
  via_principal VARCHAR(10) ENCODE ZSTD,
  via_generadora VARCHAR(10) ENCODE ZSTD,
  numero_puerta VARCHAR(10) ENCODE ZSTD,
  generada_enriquecida INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(cod_dw_direccion_fisica) SORTKEY(cod_dw_direccion_fisica);

CREATE TABLE IF NOT EXISTS bdm_stage.relacion_persona_ubicacion (
  cod_dw_persona_ubic BIGINT ENCODE AZ64,
  id_buro_persona INTEGER ENCODE AZ64,
  cod_pin_persona INTEGER ENCODE AZ64,
  cod_dw_ubic BIGINT ENCODE AZ64,
  cod_dw_direccion_fisica BIGINT ENCODE AZ64,
  cod_dw_tipo_ubicacion_dir INTEGER ENCODE AZ64,
  ind_unificacion INTEGER ENCODE AZ64,
  orden_prioridad INTEGER ENCODE AZ64,
  fecha_relacion_persona_ubicaci DATE ENCODE AZ64,
  lote INTEGER ENCODE AZ64,
  cod_tipo_ident_fte INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(id_buro_persona) SORTKEY(id_buro_persona, cod_dw_persona_ubic);

CREATE TABLE IF NOT EXISTS bdm_stage.ciiu_persona (
  id_buro_persona INTEGER ENCODE AZ64,
  cod_act_econo_ciiu_fte VARCHAR(10) ENCODE BYTEDICT
) DISTSTYLE KEY DISTKEY(id_buro_persona);

CREATE TABLE IF NOT EXISTS bdm_stage.reporte_relacion_persona_ubica (
  cod_dw_persona_ubic BIGINT ENCODE AZ64,
  id_buro_suscriptor INTEGER ENCODE AZ64,
  fecha_reporte DATE ENCODE AZ64,
  lote INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic) SORTKEY(cod_dw_persona_ubic);

CREATE TABLE IF NOT EXISTS bdm_stage.unificacion_direccion (
  cod_dw_persona_ubic BIGINT ENCODE AZ64,
  cod_dw_direccion_unificada BIGINT ENCODE AZ64,
  unifica_atributos INTEGER ENCODE AZ64,
  fecha_unificacion DATE ENCODE AZ64,
  lote INTEGER ENCODE AZ64,
  severidad INTEGER ENCODE AZ64,
  usuario_bd VARCHAR(100) ENCODE ZSTD
) DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic) SORTKEY(cod_dw_persona_ubic);

CREATE TABLE IF NOT EXISTS bdm_stage.diccionario_complementos (
  cod_dw_ubic BIGINT ENCODE AZ64,
  id_buro_persona INTEGER ENCODE AZ64,
  nomenclatura VARCHAR(50) ENCODE ZSTD,
  nomen VARCHAR(10) ENCODE ZSTD,
  valor VARCHAR(50) ENCODE ZSTD,
  frecuencia INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(cod_dw_ubic) SORTKEY(cod_dw_ubic, id_buro_persona);

CREATE TABLE IF NOT EXISTS bdm_stage.diccionario_via (
  tipo VARCHAR(20) ENCODE ZSTD,
  llave VARCHAR(100) ENCODE ZSTD,
  via_generadora VARCHAR(10) ENCODE ZSTD,
  cod_dw_municipio INTEGER ENCODE AZ64,
  conteo INTEGER ENCODE AZ64
) DISTSTYLE ALL;

CREATE TABLE IF NOT EXISTS bdm_stage.relacion_ubicac_estandar_geo (
  cod_dw_ubic BIGINT ENCODE AZ64,
  latitud DECIMAL(10,7),
  longitud DECIMAL(10,7)
) DISTSTYLE ALL;

CREATE TABLE IF NOT EXISTS bdm_stage.bloqueo (
  id_buro_persona INTEGER ENCODE AZ64
) DISTSTYLE ALL;

-- Instrumentacion de corridas (compartida por DT / SPs)
CREATE TABLE IF NOT EXISTS bdm_stage.perf_timings (
  run_id          VARCHAR(64),
  step_order      INT,
  step_id         VARCHAR(64),
  label           VARCHAR(256),
  script_source   VARCHAR(256),
  started_at      TIMESTAMP,
  ended_at        TIMESTAMP,
  duration_sec    BIGINT,
  status          VARCHAR(16)
) DISTSTYLE ALL;


-- ============================================================
-- SLCOPRBA-1147-02_bdm_stage_catalog.sql
-- STRCT: catalogos base (seed) en bdm_stage
-- ============================================================

DELETE FROM bdm_stage.tipo_ubicacion_dir;
INSERT INTO bdm_stage.tipo_ubicacion_dir VALUES
(1, 'RES'), (2, 'LAB'), (3, 'CRR'), (4, 'JUD'), (5, 'CCL');

DELETE FROM bdm_stage.nomenclatura;
INSERT INTO bdm_stage.nomenclatura VALUES
('BR',1),('UR',1),('CJ',1),('UN',1),
('ED',2),('ZN',2),('SEC',2),
('MZ',3),('ET',3),
('TO',4),('BQ',4),
('PI',5),('CS',5),('IN',5),('BL',5),
('LC',6),('OF',6),('PL',6),
('AP',7),('GJ',7),('DP',7),('ST',7);


-- ============================================================
-- SLCOPRBA-1147-03_bdm_stage_views.sql
-- STRCT: vistas de apoyo Unificacion / validacion en bdm_stage
-- ============================================================

CREATE OR REPLACE VIEW bdm_stage.vw_rpu_con_direccion AS
SELECT
  rpu.cod_dw_persona_ubic,
  rpu.id_buro_persona,
  rpu.cod_dw_ubic,
  rpu.cod_dw_direccion_fisica,
  rpu.cod_dw_tipo_ubicacion_dir,
  rpu.ind_unificacion,
  rpu.orden_prioridad,
  rpu.lote,
  ubi.texto_ubicacion,
  ubi.cod_dw_ciudad,
  ubi.latitud,
  ubi.longitud,
  df.complemento,
  df.tipo_via_principal,
  df.via_principal,
  df.via_generadora,
  df.numero_puerta,
  df.generada_enriquecida,
  tud.descripcion_tipo_ubicacion_dir AS tipo_direccion
FROM bdm_stage.relacion_persona_ubicacion rpu
LEFT JOIN bdm_stage.ubicacion_estandarizada ubi
  ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df
  ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.tipo_ubicacion_dir tud
  ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir;

CREATE OR REPLACE VIEW bdm_stage.vw_unificacion_detalle AS
SELECT
  u.cod_dw_persona_ubic,
  u.cod_dw_direccion_unificada,
  u.unifica_atributos,
  u.fecha_unificacion,
  u.lote,
  u.severidad,
  u.usuario_bd,
  rpu.id_buro_persona,
  rpu.ind_unificacion,
  rpu.cod_dw_ubic,
  rpu.cod_dw_direccion_fisica
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion rpu
  ON u.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

CREATE OR REPLACE VIEW bdm_stage.vw_perf_timings_resumen AS
SELECT
  run_id,
  step_order,
  step_id,
  label,
  duration_sec,
  status,
  started_at,
  ended_at
FROM bdm_stage.perf_timings;


-- ============================================================
-- SP_R1 — Regla 1 unificacion
-- Schema: bdm_stage | Pipeline: db_rcncr_btch_rdshft_pgm
-- Fuente: 00_run_benchmark_20k_batch_exec.sql
-- ============================================================
CREATE OR REPLACE PROCEDURE bdm_stage.sp_r1(p_run_id VARCHAR(64))
NONATOMIC
AS $$
BEGIN
-- HITO 2 : Regla 1
-- SOURCE: 02_regla1_unificacion.sql
-- ============================================================

-- PERF:BEGIN step=R1 order=2
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES (p_run_id, 2, 'R1', 'Regla 1', '02_regla1_unificacion.sql', GETDATE());

/* === INICIO 02_regla1_unificacion.sql === */
-- PASO 1: Materializar insumo en bdm_stage (staging volátil)
DROP TABLE IF EXISTS bdm_stage.stg_regla1_insumo;
CREATE TABLE bdm_stage.stg_regla1_insumo
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, texto_ubicacion)
AS
SELECT
  rpu.cod_dw_persona_ubic,
  rpu.id_buro_persona,
  ubi.texto_ubicacion,
  df.complemento,
  ubi.cod_dw_ciudad,
  rpu.cod_dw_tipo_ubicacion_dir,
  COALESCE(ciiu.cod_act_econo_ciiu_fte, '') AS cod_act_econo_ciiu_fte,
  COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor), 0) AS numero_entidades_reportan,
  tud.descripcion_tipo_ubicacion_dir AS tipo_direccion
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi
  ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df
  ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
JOIN bdm_stage.reporte_relacion_persona_ubica rep
  ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
LEFT JOIN bdm_stage.ciiu_persona ciiu
  ON rpu.id_buro_persona = ciiu.id_buro_persona
LEFT JOIN bdm_stage.tipo_ubicacion_dir tud
  ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
WHERE rpu.ind_unificacion IS NULL
GROUP BY 1,2,3,4,5,6,7,9;

ANALYZE bdm_stage.stg_regla1_insumo;

-- PASO 2: Calcular score y ranking por escenario
DROP TABLE IF EXISTS bdm_stage.stg_regla1_scored;
CREATE TABLE bdm_stage.stg_regla1_scored
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, texto_ubicacion)
AS
SELECT *,
  CASE
    WHEN cod_act_econo_ciiu_fte = '10' THEN 'ESC1'
    WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN 'ESC2'
    ELSE 'ESC3'
  END AS escenario,

  CASE
    WHEN cod_act_econo_ciiu_fte = '10' THEN
      CASE WHEN tipo_direccion IN ('LAB','CRR') THEN 100000 ELSE 0 END
      + numero_entidades_reportan
    WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN
      CASE WHEN tipo_direccion IN ('RES','CRR') THEN 100000 ELSE 0 END
      + numero_entidades_reportan
    ELSE
      numero_entidades_reportan
  END AS score,

  ROW_NUMBER() OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_ciudad,
      CASE
        WHEN cod_act_econo_ciiu_fte = '10' THEN 'ESC1'
        WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN 'ESC2'
        ELSE 'ESC3'
      END
    ORDER BY
      CASE
        WHEN cod_act_econo_ciiu_fte = '10' THEN
          CASE WHEN tipo_direccion IN ('LAB','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan
        WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN
          CASE WHEN tipo_direccion IN ('RES','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan
        ELSE numero_entidades_reportan
      END DESC
  ) AS orden
FROM bdm_stage.stg_regla1_insumo;

ANALYZE bdm_stage.stg_regla1_scored;

-- PASO 3: Generar pares padre-hijo
DROP TABLE IF EXISTS bdm_stage.stg_regla1_pares;
CREATE TABLE bdm_stage.stg_regla1_pares
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT
  hijo.cod_dw_persona_ubic        AS cod_dw_persona_ubic,
  padre.cod_dw_persona_ubic       AS cod_dw_direccion_unificada
FROM bdm_stage.stg_regla1_scored padre
JOIN bdm_stage.stg_regla1_scored hijo
  ON padre.id_buro_persona = hijo.id_buro_persona
 AND padre.texto_ubicacion = hijo.texto_ubicacion
 AND padre.cod_dw_ciudad = hijo.cod_dw_ciudad
 AND padre.escenario = hijo.escenario
 AND padre.score > hijo.score
 AND padre.cod_dw_tipo_ubicacion_dir <> hijo.cod_dw_tipo_ubicacion_dir
WHERE padre.orden = 1;

-- PASO 4: Persistir resultado
INSERT INTO bdm_stage.unificacion_direccion
SELECT
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  1 AS unifica_atributos,
  CURRENT_DATE AS fecha_unificacion,
  1 AS lote,
  1 AS severidad,
  CURRENT_USER AS usuario_bd
FROM bdm_stage.stg_regla1_pares;

-- PASO 5: Marcar hijos como unificados
UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla1_pares
);

-- PASO 6: Actualizar estadísticas de tablas modificadas
ANALYZE bdm_stage.unificacion_direccion;
ANALYZE bdm_stage.relacion_persona_ubicacion;

-- PASO 7: Limpiar staging (bdm_stage es volátil)
DROP TABLE IF EXISTS bdm_stage.stg_regla1_insumo;
DROP TABLE IF EXISTS bdm_stage.stg_regla1_scored;
DROP TABLE IF EXISTS bdm_stage.stg_regla1_pares;
/* === FIN 02_regla1_unificacion.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = p_run_id AND step_id = 'R1' AND ended_at IS NULL;
-- PERF:END step=R1



END;
$$ LANGUAGE plpgsql;


-- ============================================================
-- SP_R2 — Regla 2 escenarios + motor batch 1x
-- Schema: bdm_stage | Pipeline: db_rcncr_btch_rdshft_pgm
-- Fuente: 00_run_benchmark_20k_batch_exec.sql
-- ============================================================
CREATE OR REPLACE PROCEDURE bdm_stage.sp_r2(p_run_id VARCHAR(64))
NONATOMIC
AS $$
BEGIN
-- HITO 3 : R2 Escenarios 1 y 2
-- SOURCE: 03_regla2_esc1_2.sql
-- ============================================================

-- PERF:BEGIN step=R2_ESC1_2 order=3
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES (p_run_id, 3, 'R2_ESC1_2', 'R2 Escenarios 1 y 2', '03_regla2_esc1_2.sql', GETDATE());

/* === INICIO 03_regla2_esc1_2.sql === */
-- PASO 1: Materializar insumo de Regla 2
-- Solo registros NO unificados por Regla 1 (ind_unificacion IS NULL)
DROP TABLE IF EXISTS bdm_stage.stg_regla2_insumo;
CREATE TABLE bdm_stage.stg_regla2_insumo
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, texto_ubicacion)
AS
SELECT
  rpu.cod_dw_persona_ubic,
  rpu.cod_pin_persona,
  rpu.id_buro_persona,
  rpu.cod_dw_tipo_ubicacion_dir,
  rpu.cod_dw_ubic,
  ubi.texto_ubicacion,
  rpu.cod_dw_direccion_fisica,
  df.complemento,
  rpu.cod_dw_tipo_ubicacion_dir AS cod_dw_municipio,  -- TODO: confirmar campo municipio real
  COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor), 0) AS numero_entidades_reportan,
  rpu.fecha_relacion_persona_ubicaci
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi
  ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df
  ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
JOIN bdm_stage.reporte_relacion_persona_ubica rep
  ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
WHERE rpu.ind_unificacion IS NULL
GROUP BY 1,2,3,4,5,6,7,8,9,11;

ANALYZE bdm_stage.stg_regla2_insumo;

-- PASO 2: Escenario 1 — Un complemento vacío, otro no
-- A tiene complemento, B no → B es hijo de A
-- A no tiene complemento, B sí → A es hijo de B
DROP TABLE IF EXISTS bdm_stage.stg_regla2_esc1_pares;
CREATE TABLE bdm_stage.stg_regla2_esc1_pares
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT cod_dw_persona_ubic, id_padre
FROM (
  -- Caso 1: B no tiene complemento → B es hijo, A es padre
  SELECT
    b.cod_dw_persona_ubic,
    a.cod_dw_persona_ubic AS id_padre,
    ROW_NUMBER() OVER (PARTITION BY b.cod_dw_persona_ubic ORDER BY a.cod_dw_persona_ubic DESC) AS rn
  FROM bdm_stage.stg_regla2_insumo a
  JOIN bdm_stage.stg_regla2_insumo b
    ON  a.id_buro_persona           = b.id_buro_persona
    AND a.texto_ubicacion            = b.texto_ubicacion
    AND a.cod_dw_tipo_ubicacion_dir  = b.cod_dw_tipo_ubicacion_dir
    AND a.cod_dw_municipio           = b.cod_dw_municipio
    AND a.cod_dw_persona_ubic       <> b.cod_dw_persona_ubic
  WHERE a.complemento IS NOT NULL
    AND b.complemento IS NULL

  UNION ALL

  -- Caso 2: A no tiene complemento → A es hijo, B es padre
  SELECT
    a.cod_dw_persona_ubic,
    b.cod_dw_persona_ubic AS id_padre,
    ROW_NUMBER() OVER (PARTITION BY a.cod_dw_persona_ubic ORDER BY b.cod_dw_persona_ubic DESC) AS rn
  FROM bdm_stage.stg_regla2_insumo a
  JOIN bdm_stage.stg_regla2_insumo b
    ON  a.id_buro_persona           = b.id_buro_persona
    AND a.texto_ubicacion            = b.texto_ubicacion
    AND a.cod_dw_tipo_ubicacion_dir  = b.cod_dw_tipo_ubicacion_dir
    AND a.cod_dw_municipio           = b.cod_dw_municipio
    AND a.cod_dw_persona_ubic       <> b.cod_dw_persona_ubic
  WHERE b.complemento IS NOT NULL
    AND a.complemento IS NULL
)
WHERE rn = 1;

ANALYZE bdm_stage.stg_regla2_esc1_pares;

-- PASO 3: Construir tabla intermedia E1 con marca de unificación
-- Hereda todos los registros del insumo, marcando hijos del Esc 1
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e1;
CREATE TABLE bdm_stage.stg_regla2_e1
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, texto_ubicacion)
AS
SELECT
  a.cod_dw_persona_ubic,
  b.id_padre,
  a.id_buro_persona,
  a.cod_dw_tipo_ubicacion_dir,
  a.cod_dw_ubic,
  a.texto_ubicacion,
  a.cod_dw_direccion_fisica,
  a.complemento,
  a.cod_dw_municipio,
  a.numero_entidades_reportan,
  a.fecha_relacion_persona_ubicaci,
  CASE WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S' ELSE 'N' END AS ind_unificacion,
  CASE WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'H1' END AS n_id,
  ROW_NUMBER() OVER (
    PARTITION BY a.id_buro_persona, a.cod_dw_ubic,
      CASE WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S' ELSE 'N' END,
      a.cod_dw_tipo_ubicacion_dir
    ORDER BY a.complemento
  ) AS row_u
FROM bdm_stage.stg_regla2_insumo a
LEFT JOIN bdm_stage.stg_regla2_esc1_pares b
  ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic;

ANALYZE bdm_stage.stg_regla2_e1;

-- PASO 4: Escenario 2 — Un complemento incluido en otro
-- Solo procesa registros con ind_unificacion='N' (no unificados por Esc 1)
-- A.COMPLEMENTO contiene B.COMPLEMENTO → B es hijo de A
DROP TABLE IF EXISTS bdm_stage.stg_regla2_esc2_pares;
CREATE TABLE bdm_stage.stg_regla2_esc2_pares
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT cod_dw_persona_ubic, id_padre
FROM (
  -- Caso 1: B contenido en A → B es hijo
  SELECT
    b.cod_dw_persona_ubic,
    a.cod_dw_persona_ubic AS id_padre,
    ROW_NUMBER() OVER (PARTITION BY b.cod_dw_persona_ubic ORDER BY b.cod_dw_persona_ubic DESC) AS rn
  FROM bdm_stage.stg_regla2_e1 a
  JOIN bdm_stage.stg_regla2_e1 b
    ON  a.id_buro_persona           = b.id_buro_persona
    AND a.texto_ubicacion            = b.texto_ubicacion
    AND a.cod_dw_tipo_ubicacion_dir  = b.cod_dw_tipo_ubicacion_dir
    AND a.cod_dw_municipio           = b.cod_dw_municipio
    AND a.cod_dw_persona_ubic       <> b.cod_dw_persona_ubic
    AND a.complemento               <> b.complemento
  WHERE a.complemento LIKE '%' || b.complemento || '%'
    AND a.ind_unificacion = 'N'

  UNION ALL

  -- Caso 2: A contenido en B → A es hijo
  SELECT
    a.cod_dw_persona_ubic,
    b.cod_dw_persona_ubic AS id_padre,
    ROW_NUMBER() OVER (PARTITION BY a.cod_dw_persona_ubic ORDER BY a.cod_dw_persona_ubic DESC) AS rn
  FROM bdm_stage.stg_regla2_e1 a
  JOIN bdm_stage.stg_regla2_e1 b
    ON  a.id_buro_persona           = b.id_buro_persona
    AND a.texto_ubicacion            = b.texto_ubicacion
    AND a.cod_dw_tipo_ubicacion_dir  = b.cod_dw_tipo_ubicacion_dir
    AND a.cod_dw_municipio           = b.cod_dw_municipio
    AND a.cod_dw_persona_ubic       <> b.cod_dw_persona_ubic
    AND a.complemento               <> b.complemento
  WHERE b.complemento LIKE '%' || a.complemento || '%'
    AND a.ind_unificacion = 'N'
)
WHERE rn = 1;

ANALYZE bdm_stage.stg_regla2_esc2_pares;

-- PASO 5: Construir tabla E2 acumulada (hereda Esc 1 + agrega Esc 2)
-- Esta tabla será input para escenarios 3-6 en el siguiente script
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e2;
CREATE TABLE bdm_stage.stg_regla2_e2
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, texto_ubicacion)
AS
SELECT
  a.cod_dw_persona_ubic,
  CASE WHEN a.id_padre IS NOT NULL THEN a.id_padre ELSE b.id_padre END AS id_padre,
  a.id_buro_persona,
  a.cod_dw_tipo_ubicacion_dir,
  a.cod_dw_ubic,
  a.texto_ubicacion,
  a.cod_dw_direccion_fisica,
  a.complemento,
  a.cod_dw_municipio,
  a.numero_entidades_reportan,
  a.fecha_relacion_persona_ubicaci,
  CASE
    WHEN a.ind_unificacion = 'S' THEN 'S'
    WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S'
    ELSE 'N'
  END AS ind_unificacion,
  CASE
    WHEN a.n_id IS NOT NULL THEN a.n_id
    WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'K2'
  END AS n_id,
  ROW_NUMBER() OVER (
    PARTITION BY a.id_buro_persona, a.cod_dw_ubic,
      CASE
        WHEN a.ind_unificacion = 'S' THEN 'S'
        WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S'
        ELSE 'N'
      END,
      a.cod_dw_tipo_ubicacion_dir
    ORDER BY a.complemento
  ) AS row_u
FROM bdm_stage.stg_regla2_e1 a
LEFT JOIN bdm_stage.stg_regla2_esc2_pares b
  ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic;

ANALYZE bdm_stage.stg_regla2_e2;

-- PASO 6: Persistir pares padre-hijo de Esc 1 y 2 en tabla de unificación
INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT
  e.cod_dw_persona_ubic,
  e.id_padre AS cod_dw_direccion_unificada,
  2 AS unifica_atributos,
  CURRENT_DATE AS fecha_unificacion,
  1 AS lote,
  1 AS severidad,
  LEFT(CURRENT_USER, 30) AS usuario_bd
FROM bdm_stage.stg_regla2_e2 e
WHERE e.ind_unificacion = 'S'
  AND e.id_padre IS NOT NULL;

-- PASO 7: Marcar hijos en relacion_persona_ubicacion
UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic
  FROM bdm_stage.stg_regla2_e2
  WHERE ind_unificacion = 'S'
    AND id_padre IS NOT NULL
);

-- PASO 8: Actualizar estadísticas
ANALYZE bdm_stage.unificacion_direccion;
ANALYZE bdm_stage.relacion_persona_ubicacion;

-- PASO 9: Limpiar staging de escenarios 1-2
-- NOTA: stg_regla2_e2 se mantiene como input para escenarios 3-6
DROP TABLE IF EXISTS bdm_stage.stg_regla2_insumo;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_esc1_pares;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e1;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_esc2_pares;
/* === FIN 03_regla2_esc1_2.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = p_run_id AND step_id = 'R2_ESC1_2' AND ended_at IS NULL;
-- PERF:END step=R2_ESC1_2


-- ============================================================
-- HITO 4 : R2 Escenario 4
-- SOURCE: 04_regla2_esc4.sql
-- ============================================================

-- PERF:BEGIN step=R2_ESC4 order=4
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES (p_run_id, 4, 'R2_ESC4', 'R2 Escenario 4', '04_regla2_esc4.sql', GETDATE());

/* === INICIO 04_regla2_esc4.sql === */
-- PASO 1: Filtrar no-unificados con complemento diferente
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04;
CREATE TABLE bdm_stage.stg_regla2_e04
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT A.*
FROM (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') A
JOIN (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.complemento              <> B.complemento;

ANALYZE bdm_stage.stg_regla2_e04;

-- PASO 2: Identificar nomenclaturas de cada complemento
-- NMC1 = nomenclatura al inicio del complemento (ej: "CS" de "CS 312")
-- NMC2 = nomenclatura secundaria en medio del complemento (si existe)
-- COMPLEMENTO2 = complemento sin las nomenclaturas (solo valores numéricos)
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_a;
CREATE TABLE bdm_stage.stg_regla2_e04_a
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT
  A.*,
  NMC1.nomenclatura AS nomenclatura_pri,
  NMC1.nivel_complemento AS nivel_pri,
  NMC2.nomenclatura AS nomenclatura_sec,
  NMC2.nivel_complemento AS nivel_sec,
  TRIM(REPLACE(REPLACE(A.complemento, COALESCE(NMC1.nomenclatura,''), ''), COALESCE(NMC2.nomenclatura,''), '')) AS complemento2
FROM bdm_stage.stg_regla2_e04 A
LEFT JOIN bdm_stage.nomenclatura NMC1
  ON A.complemento LIKE TRIM(NMC1.nomenclatura) || ' %'
LEFT JOIN bdm_stage.nomenclatura NMC2
  ON A.complemento LIKE '% ' || TRIM(NMC2.nomenclatura) || ' %'
  AND NMC2.nomenclatura <> COALESCE(NMC1.nomenclatura, '');

ANALYZE bdm_stage.stg_regla2_e04_a;

-- PASO 3: Filtrar pares donde nomenclaturas están al mismo nivel
-- Caso 1: misma nomenclatura primaria, diferente secundaria, mismo nivel secundario
-- Caso 2: diferente nomenclatura primaria, misma secundaria, mismo nivel primario
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_c;
CREATE TABLE bdm_stage.stg_regla2_e04_c
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT * FROM (
  -- Caso 1: misma nomenclatura primaria, ≠ secundaria, mismo nivel secundario
  SELECT A.*
  FROM bdm_stage.stg_regla2_e04_a A
  JOIN bdm_stage.stg_regla2_e04_a B
    ON  A.id_buro_persona          = B.id_buro_persona
    AND A.texto_ubicacion           = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
    AND A.cod_dw_municipio          = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
    AND A.complemento              <> B.complemento
    AND (A.complemento2 LIKE '%' || B.complemento2 || '%'
         OR B.complemento2 LIKE '%' || A.complemento2 || '%')
    AND A.nomenclatura_pri = B.nomenclatura_pri
    AND COALESCE(A.nomenclatura_sec, 'X') <> COALESCE(B.nomenclatura_sec, 'X')
    AND COALESCE(A.nivel_sec, 0) = COALESCE(B.nivel_sec, 0)

  UNION ALL

  -- Caso 2: ≠ nomenclatura primaria, misma secundaria, mismo nivel primario
  SELECT A.*
  FROM bdm_stage.stg_regla2_e04_a A
  JOIN bdm_stage.stg_regla2_e04_a B
    ON  A.id_buro_persona          = B.id_buro_persona
    AND A.texto_ubicacion           = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
    AND A.cod_dw_municipio          = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
    AND A.complemento              <> B.complemento
    AND (A.complemento2 LIKE '%' || B.complemento2 || '%'
         OR B.complemento2 LIKE '%' || A.complemento2 || '%')
    AND A.nomenclatura_pri <> B.nomenclatura_pri
    AND COALESCE(A.nomenclatura_sec, 'X') = COALESCE(B.nomenclatura_sec, 'X')
    AND A.nivel_pri = B.nivel_pri
) sub;

ANALYZE bdm_stage.stg_regla2_e04_c;

-- PASO 4: Sumar frecuencias del DICCIONARIO_COMPLEMENTOS por persona/ubicación
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_c1;
CREATE TABLE bdm_stage.stg_regla2_e04_c1
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT
  t1.cod_dw_persona_ubic,
  COALESCE(t2.conteo, 0) AS conteo
FROM bdm_stage.stg_regla2_e04_c t1
LEFT JOIN (
  SELECT t1.cod_dw_persona_ubic, SUM(dc.frecuencia) AS conteo
  FROM bdm_stage.stg_regla2_e04_c t1
  LEFT JOIN bdm_stage.diccionario_complementos dc
    ON  t1.cod_dw_ubic = dc.cod_dw_ubic
    AND t1.complemento LIKE '%' || dc.nomenclatura || '%'
    AND t1.id_buro_persona = dc.id_buro_persona
  GROUP BY 1
) t2 ON t1.cod_dw_persona_ubic = t2.cod_dw_persona_ubic;

ANALYZE bdm_stage.stg_regla2_e04_c1;

-- PASO 5: Calcular score y detectar empates
-- Score = (frecuencia_diccionario + 10000000) + fecha_como_entero
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_d;
CREATE TABLE bdm_stage.stg_regla2_e04_d
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  u1.*,
  COUNT(*) OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id
  ) AS count_empate,
  MAX(id) OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio
  ) AS idmax,
  CASE
    WHEN COUNT(*) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id) > 1
         AND MAX(id) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio) > id
    THEN 1
    WHEN COUNT(*) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id) = 1
    THEN 1
    ELSE 0
  END AS empate
FROM (
  SELECT
    a.cod_dw_persona_ubic,
    (COALESCE(b.conteo, 0) + 10000000)
      + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0) AS id,
    a.texto_ubicacion,
    a.fecha_relacion_persona_ubicaci,
    a.numero_entidades_reportan,
    a.id_buro_persona,
    a.cod_dw_tipo_ubicacion_dir,
    a.cod_dw_municipio,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
      ORDER BY (COALESCE(b.conteo, 0) + 10000000)
        + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0)
    ) AS orden,
    a.cod_dw_ubic,
    a.complemento
  FROM bdm_stage.stg_regla2_e04_c a
  LEFT JOIN bdm_stage.stg_regla2_e04_c1 b
    ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
) u1;

ANALYZE bdm_stage.stg_regla2_e04_d;

-- PASO 6: Generar pares padre-hijo (mayor score = padre)
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_e;
CREATE TABLE bdm_stage.stg_regla2_e04_e
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT
  B.cod_dw_persona_ubic,
  A.cod_dw_persona_ubic AS id_padre
FROM bdm_stage.stg_regla2_e04_d A
JOIN bdm_stage.stg_regla2_e04_d B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.id > B.id
JOIN (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio,
         MAX(orden) AS max_orden
  FROM bdm_stage.stg_regla2_e04_d
  GROUP BY 1,2,3,4
) mx
  ON  A.id_buro_persona          = mx.id_buro_persona
  AND A.texto_ubicacion           = mx.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = mx.cod_dw_municipio
  AND A.orden = mx.max_orden;

ANALYZE bdm_stage.stg_regla2_e04_e;

-- PASO 7: Actualizar tabla E2 acumulada con pares del Escenario 4
UPDATE bdm_stage.stg_regla2_e2
SET id_padre = e.id_padre,
    ind_unificacion = 'S',
    n_id = 'B5'
FROM bdm_stage.stg_regla2_e04_e e
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = e.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.id_padre IS NULL;

-- PASO 8: Persistir pares en tabla de unificación
INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT
  e.cod_dw_persona_ubic,
  e.id_padre AS cod_dw_direccion_unificada,
  2 AS unifica_atributos,
  CURRENT_DATE AS fecha_unificacion,
  1 AS lote,
  1 AS severidad,
  LEFT(CURRENT_USER, 30) AS usuario_bd
FROM bdm_stage.stg_regla2_e04_e e;

-- PASO 9: Marcar hijos
UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e04_e
);

-- PASO 10: Estadísticas
ANALYZE bdm_stage.unificacion_direccion;
ANALYZE bdm_stage.relacion_persona_ubicacion;

-- PASO 11: Limpiar staging del escenario 4
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_a;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_c;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_c1;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_d;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_e;
/* === FIN 04_regla2_esc4.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = p_run_id AND step_id = 'R2_ESC4' AND ended_at IS NULL;
-- PERF:END step=R2_ESC4


-- ============================================================
-- HITO 5 : R2 Esc 3 sin NIT
-- SOURCE: 05_regla2_esc3_sin_nit.sql
-- ============================================================

-- PERF:BEGIN step=R2_ESC3_SIN_NIT order=5
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES (p_run_id, 5, 'R2_ESC3_SIN_NIT', 'R2 Esc 3 sin NIT', '05_regla2_esc3_sin_nit.sql', GETDATE());

/* === INICIO 05_regla2_esc3_sin_nit.sql === */
-- PASO 1: Filtrar no-unificados que NO son NIT
-- En datos mock, Cod_Tipo_Ident_Fte=3 es NIT. Excluimos esos.
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03;
CREATE TABLE bdm_stage.stg_regla2_e03
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT a.*
FROM bdm_stage.stg_regla2_e2 a
WHERE a.ind_unificacion = 'N'
  AND COALESCE(a.cod_dw_tipo_ubicacion_dir, 0) NOT IN (
    SELECT cod_dw_tipo_ubicacion_dir FROM bdm_stage.tipo_ubicacion_dir WHERE 1=0
  )
  -- Filtro NIT: excluir registros con tipo identificación = NIT (cod_tipo_ident_fte = 3)
  -- En Teradata se hace con LEFT JOIN V_Tipo_Identificacion WHERE NOT LIKE '%Nit%'
  -- Aquí usamos el campo cod_tipo_ident_fte directamente del insumo de R2
  -- TODO: cuando exista tabla tipo_identificacion, usar JOIN
;

-- Corrección: el filtro NIT debe venir de relacion_persona_ubicacion.cod_tipo_ident_fte
-- que ya está en stg_regla2_e2 (no se copió). Necesitamos JOINear con RPU.
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03;
CREATE TABLE bdm_stage.stg_regla2_e03
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT a.*
FROM bdm_stage.stg_regla2_e2 a
JOIN bdm_stage.relacion_persona_ubicacion rpu
  ON a.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE a.ind_unificacion = 'N'
  AND COALESCE(rpu.cod_tipo_ident_fte, 0) <> 3;  -- 3 = NIT

ANALYZE bdm_stage.stg_regla2_e03;

-- PASO 2: JOIN por misma nomenclatura, calcular score
-- Score = fecha_como_entero + (entidades + 10000000)
-- Detectar empates
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_a;
CREATE TABLE bdm_stage.stg_regla2_e03_a
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT u1.*,
  COUNT(*) OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, nomenclatura, id
  ) AS count_empate,
  MAX(id) OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, cod_dw_persona_ubic, nomenclatura
  ) AS idmax
FROM (
  SELECT
    a.cod_dw_persona_ubic,
    COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 19000101)
      + (COALESCE(a.numero_entidades_reportan, 0) + 10000000) AS id,
    a.texto_ubicacion,
    a.fecha_relacion_persona_ubicaci,
    nmc1.nomenclatura,
    a.complemento AS complemento1,
    b.complemento AS complemento2,
    a.numero_entidades_reportan,
    a.id_buro_persona,
    a.cod_dw_tipo_ubicacion_dir,
    a.cod_dw_municipio,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio, nmc1.nomenclatura
      ORDER BY COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 19000101)
        + (COALESCE(a.numero_entidades_reportan, 0) + 10000000)
    ) AS orden
  FROM bdm_stage.stg_regla2_e03 a
  JOIN bdm_stage.stg_regla2_e03 b
    ON  a.id_buro_persona          = b.id_buro_persona
    AND a.texto_ubicacion           = b.texto_ubicacion
    AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
    AND a.cod_dw_municipio          = b.cod_dw_municipio
    AND a.cod_dw_persona_ubic      <> b.cod_dw_persona_ubic
    AND a.complemento              <> b.complemento
  JOIN bdm_stage.nomenclatura nmc1
    ON a.complemento LIKE nmc1.nomenclatura || '%'
  JOIN bdm_stage.nomenclatura nmc2
    ON b.complemento LIKE nmc2.nomenclatura || '%'
  WHERE nmc1.nomenclatura = nmc2.nomenclatura
) u1;

ANALYZE bdm_stage.stg_regla2_e03_a;

-- PASO 3: Generar pares padre-hijo (mayor score = padre)
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_e1;
CREATE TABLE bdm_stage.stg_regla2_e03_e1
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT
  b.cod_dw_persona_ubic,
  a.cod_dw_persona_ubic AS id_padre
FROM bdm_stage.stg_regla2_e03_a a
JOIN bdm_stage.stg_regla2_e03_a b
  ON  a.id_buro_persona          = b.id_buro_persona
  AND a.texto_ubicacion           = b.texto_ubicacion
  AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
  AND a.cod_dw_municipio          = b.cod_dw_municipio
  AND a.nomenclatura              = b.nomenclatura
  AND a.cod_dw_persona_ubic      <> b.cod_dw_persona_ubic
  AND a.id > b.id
JOIN (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, nomenclatura,
         MAX(orden) AS max_orden
  FROM bdm_stage.stg_regla2_e03_a
  GROUP BY 1,2,3,4,5
) mx
  ON  a.id_buro_persona          = mx.id_buro_persona
  AND a.texto_ubicacion           = mx.texto_ubicacion
  AND a.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir
  AND a.cod_dw_municipio          = mx.cod_dw_municipio
  AND a.nomenclatura              = mx.nomenclatura
  AND a.orden = mx.max_orden;

ANALYZE bdm_stage.stg_regla2_e03_e1;

-- PASO 4: UPDATE E2 — marcar hijos del Escenario 3 sin NIT
UPDATE bdm_stage.stg_regla2_e2
SET id_padre = stg.id_padre,
    ind_unificacion = 'S',
    n_id = 'L3'
FROM bdm_stage.stg_regla2_e03_e1 stg
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = stg.cod_dw_persona_ubic;

-- PASO 5: Persistir pares en tabla de unificación
INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT
  cod_dw_persona_ubic,
  id_padre AS cod_dw_direccion_unificada,
  2 AS unifica_atributos,
  CURRENT_DATE AS fecha_unificacion,
  1 AS lote,
  1 AS severidad,
  LEFT(CURRENT_USER, 30) AS usuario_bd
FROM bdm_stage.stg_regla2_e03_e1;

-- PASO 6: Marcar hijos
UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e03_e1
);

-- PASO 7: Estadísticas
ANALYZE bdm_stage.unificacion_direccion;
ANALYZE bdm_stage.relacion_persona_ubicacion;
ANALYZE bdm_stage.stg_regla2_e2;

-- PASO 8: Limpiar staging
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_a;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_e1;
/* === FIN 05_regla2_esc3_sin_nit.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = p_run_id AND step_id = 'R2_ESC3_SIN_NIT' AND ended_at IS NULL;
-- PERF:END step=R2_ESC3_SIN_NIT



-- PERF:BEGIN step=R2_MOTOR_BATCH_PREP order=6
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES (p_run_id, 6, 'R2_MOTOR_BATCH_PREP', 'Motor batch prep unificado', 'inc_batch_motor_prep.sql', GETDATE());

-- ============================================================
-- BATCH MOTOR — prep unificado (07a + 08a + 09a lógica combinada)
-- Reemplaza hitos R2_ESC3_NIT_* .. R2_ESC6_* prep en modo batch
-- ============================================================

/* SOURCE: combinación 07a + 08a + 09a */

-- --- 07a NIT prep ---
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e031;
CREATE TABLE bdm_stage.stg_regla2_e031
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT a.*
FROM bdm_stage.stg_regla2_e2 a
JOIN bdm_stage.relacion_persona_ubicacion rpu
  ON a.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE a.ind_unificacion = 'N'
  AND rpu.cod_tipo_ident_fte = 3;

ANALYZE bdm_stage.stg_regla2_e031;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_nit_pares;
CREATE TABLE bdm_stage.stg_regla2_e03_nit_pares
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT a.cod_dw_persona_ubic
FROM bdm_stage.stg_regla2_e031 a
JOIN bdm_stage.stg_regla2_e031 b
  ON  a.id_buro_persona          = b.id_buro_persona
  AND a.texto_ubicacion           = b.texto_ubicacion
  AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
  AND a.cod_dw_municipio          = b.cod_dw_municipio
  AND a.cod_dw_persona_ubic      <> b.cod_dw_persona_ubic
  AND a.complemento              <> b.complemento
JOIN bdm_stage.nomenclatura nmc1 ON a.complemento LIKE nmc1.nomenclatura || '%'
JOIN bdm_stage.nomenclatura nmc2 ON b.complemento LIKE nmc2.nomenclatura || '%'
WHERE nmc1.nomenclatura = nmc2.nomenclatura;

DROP TABLE IF EXISTS bdm_stage.stg_motor_input_nit;
CREATE TABLE bdm_stage.stg_motor_input_nit
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT e.cod_dw_persona_ubic, e.cod_dw_ubic, e.complemento, e.id_buro_persona,
  e.cod_dw_tipo_ubicacion_dir, rpu.cod_pin_persona, rpu.cod_dw_direccion_fisica,
  e.texto_ubicacion, e.fecha_relacion_persona_ubicaci, 'NIT' AS motor_src
FROM bdm_stage.stg_regla2_e031 e
JOIN bdm_stage.stg_regla2_e03_nit_pares p ON e.cod_dw_persona_ubic = p.cod_dw_persona_ubic
JOIN bdm_stage.relacion_persona_ubicacion rpu ON e.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

-- --- 08a Esc5 prep (sub1 motor) ---
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05;
CREATE TABLE bdm_stage.stg_regla2_e05
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') A
JOIN (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') B
  ON  A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_a;
CREATE TABLE bdm_stage.stg_regla2_e05_a
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*,
  NMC1.nomenclatura AS nomenclatura_pri, NMC1.nivel_complemento AS nivel_pri,
  NMC2.nomenclatura AS nomenclatura_sec, NMC2.nivel_complemento AS nivel_sec,
  TRIM(REPLACE(REPLACE(A.complemento, COALESCE(NMC1.nomenclatura,''), ''), COALESCE(NMC2.nomenclatura,''), '')) AS complemento2
FROM bdm_stage.stg_regla2_e05 A
LEFT JOIN bdm_stage.nomenclatura NMC1 ON A.complemento LIKE TRIM(NMC1.nomenclatura) || ' %'
LEFT JOIN bdm_stage.nomenclatura NMC2 ON A.complemento LIKE '% ' || TRIM(NMC2.nomenclatura) || ' %'
  AND NMC2.nomenclatura <> COALESCE(NMC1.nomenclatura, '');

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_c;
CREATE TABLE bdm_stage.stg_regla2_e05_c
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT * FROM (
  SELECT DISTINCT A.* FROM bdm_stage.stg_regla2_e05_a A
  JOIN bdm_stage.stg_regla2_e05_a B
    ON A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
    AND (A.complemento2 NOT LIKE '%' || B.complemento2 || '%' OR B.complemento2 NOT LIKE '%' || A.complemento2 || '%')
    AND A.nomenclatura_pri = B.nomenclatura_pri
    AND COALESCE(A.nomenclatura_sec, 'X') <> COALESCE(B.nomenclatura_sec, 'X')
    AND COALESCE(A.nivel_sec, 0) <> COALESCE(B.nivel_sec, 0)
  UNION
  SELECT DISTINCT A.* FROM bdm_stage.stg_regla2_e05_a A
  JOIN bdm_stage.stg_regla2_e05_a B
    ON A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
    AND (A.complemento2 NOT LIKE '%' || B.complemento2 || '%' OR B.complemento2 NOT LIKE '%' || A.complemento2 || '%')
    AND A.nomenclatura_pri <> B.nomenclatura_pri
    AND COALESCE(A.nomenclatura_sec, 'X') = COALESCE(B.nomenclatura_sec, 'X')
    AND A.nivel_pri <> B.nivel_pri
) sub;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub1;
CREATE TABLE bdm_stage.stg_regla2_e05_sub1
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.* FROM bdm_stage.stg_regla2_e05_c A
JOIN bdm_stage.stg_regla2_e05_c B
  ON A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
  AND TRIM(A.complemento2) <> TRIM(B.complemento2);

DROP TABLE IF EXISTS bdm_stage.stg_motor_input_esc5;
CREATE TABLE bdm_stage.stg_motor_input_esc5
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT e.cod_dw_persona_ubic, e.cod_dw_ubic, e.complemento, e.id_buro_persona,
  e.cod_dw_tipo_ubicacion_dir, rpu.cod_pin_persona, rpu.cod_dw_direccion_fisica,
  e.texto_ubicacion, e.fecha_relacion_persona_ubicaci, 'ESC5' AS motor_src
FROM bdm_stage.stg_regla2_e05_sub1 e
JOIN bdm_stage.relacion_persona_ubicacion rpu ON e.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

-- --- 09a Esc6 prep (sub1 motor) ---
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06;
CREATE TABLE bdm_stage.stg_regla2_e06
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') A
JOIN (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') B
  ON  A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_a;
CREATE TABLE bdm_stage.stg_regla2_e06_a
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*,
  NMC1.nomenclatura AS nomenclatura_pri, NMC1.nivel_complemento AS nivel_pri,
  NMC2.nomenclatura AS nomenclatura_sec, NMC2.nivel_complemento AS nivel_sec
FROM bdm_stage.stg_regla2_e06 A
LEFT JOIN bdm_stage.nomenclatura NMC1 ON A.complemento LIKE TRIM(NMC1.nomenclatura) || ' %'
LEFT JOIN bdm_stage.nomenclatura NMC2 ON A.complemento LIKE '% ' || TRIM(NMC2.nomenclatura) || ' %'
  AND NMC2.nomenclatura <> COALESCE(NMC1.nomenclatura, '');

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_c;
CREATE TABLE bdm_stage.stg_regla2_e06_c
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT * FROM (
  SELECT DISTINCT A.* FROM bdm_stage.stg_regla2_e06_a A
  JOIN bdm_stage.stg_regla2_e06_a B
    ON A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
    AND COALESCE(A.nomenclatura_pri, 'A') = COALESCE(B.nomenclatura_sec, 'B')
  UNION
  SELECT DISTINCT A.* FROM bdm_stage.stg_regla2_e06_a A
  JOIN bdm_stage.stg_regla2_e06_a B
    ON A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
    AND COALESCE(A.nomenclatura_sec, 'A') = COALESCE(B.nomenclatura_pri, 'B')
) sub;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub1;
CREATE TABLE bdm_stage.stg_regla2_e06_sub1
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.* FROM bdm_stage.stg_regla2_e06_c A
JOIN bdm_stage.stg_regla2_e06_c B
  ON A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
  AND COALESCE(A.nivel_pri, 0) <> COALESCE(B.nivel_pri, 0);

DROP TABLE IF EXISTS bdm_stage.stg_motor_input_esc6;
CREATE TABLE bdm_stage.stg_motor_input_esc6
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT e.cod_dw_persona_ubic, e.cod_dw_ubic, e.complemento, e.id_buro_persona,
  e.cod_dw_tipo_ubicacion_dir, rpu.cod_pin_persona, rpu.cod_dw_direccion_fisica,
  e.texto_ubicacion, e.fecha_relacion_persona_ubicaci, 'ESC6' AS motor_src
FROM bdm_stage.stg_regla2_e06_sub1 e
JOIN bdm_stage.relacion_persona_ubicacion rpu ON e.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

-- Unificar stg_motor_input
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
CREATE TABLE bdm_stage.stg_motor_input
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT cod_dw_persona_ubic, cod_dw_ubic, complemento, id_buro_persona,
  cod_dw_tipo_ubicacion_dir, cod_pin_persona, cod_dw_direccion_fisica,
  texto_ubicacion, fecha_relacion_persona_ubicaci
FROM bdm_stage.stg_motor_input_nit
UNION ALL
SELECT cod_dw_persona_ubic, cod_dw_ubic, complemento, id_buro_persona,
  cod_dw_tipo_ubicacion_dir, cod_pin_persona, cod_dw_direccion_fisica,
  texto_ubicacion, fecha_relacion_persona_ubicaci
FROM bdm_stage.stg_motor_input_esc5
UNION ALL
SELECT cod_dw_persona_ubic, cod_dw_ubic, complemento, id_buro_persona,
  cod_dw_tipo_ubicacion_dir, cod_pin_persona, cod_dw_direccion_fisica,
  texto_ubicacion, fecha_relacion_persona_ubicaci
FROM bdm_stage.stg_motor_input_esc6;

ANALYZE bdm_stage.stg_motor_input;


UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = p_run_id AND step_id = 'R2_MOTOR_BATCH_PREP' AND ended_at IS NULL;
-- PERF:END step=R2_MOTOR_BATCH_PREP


-- ============================================================
-- HITO 7 : Motor batch ejecucion unica
-- SOURCE: 06_motor_nuevas_direcciones.sql
-- ============================================================

-- PERF:BEGIN step=R2_MOTOR_BATCH_RUN order=7
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES (p_run_id, 7, 'R2_MOTOR_BATCH_RUN', 'Motor batch ejecucion unica', '06_motor_nuevas_direcciones.sql', GETDATE());

/* === INICIO 06_motor_nuevas_direcciones.sql === */
-- ============================================================
-- PASO 1: Descomponer complementos en nomenclaturas individuales
-- Cada fila = 1 nomenclatura de 1 dirección
-- JOIN con DICCIONARIO_COMPLEMENTOS por LIKE con separadores
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_descomp;
CREATE TABLE bdm_stage.stg_motor_descomp
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  sub.*,
  ROW_NUMBER() OVER (PARTITION BY sub.cod_dw_persona_ubic
    ORDER BY sub.nivel_complemento DESC) AS id_com,
  ROW_NUMBER() OVER (PARTITION BY sub.cod_dw_persona_ubic
    ORDER BY sub.nivel_complemento ASC) AS id_com1
FROM (
  SELECT
    tu.cod_dw_persona_ubic,
    tu.cod_dw_ubic,
    tu.id_buro_persona,
    tu.cod_dw_tipo_ubicacion_dir,
    dc.nomenclatura,
    dc.nomen,
    dc.valor AS valor_original,
    CASE WHEN REGEXP_COUNT(dc.valor, '^[0-9]+$') > 0 THEN CAST(dc.valor AS BIGINT) ELSE 0 END AS valor_num,
    COALESCE(nom.nivel_complemento, 99) AS nivel_complemento,
    COUNT(*) AS cantidad
  FROM bdm_stage.stg_motor_input tu
  JOIN bdm_stage.diccionario_complementos dc
    ON tu.complemento LIKE '%' || dc.nomenclatura || '%'
    AND tu.cod_dw_ubic = dc.cod_dw_ubic
    AND tu.id_buro_persona = dc.id_buro_persona
  LEFT JOIN bdm_stage.nomenclatura nom
    ON nom.nomenclatura = dc.nomen
  GROUP BY 1,2,3,4,5,6,7,8,9
) sub;

ANALYZE bdm_stage.stg_motor_descomp;

-- ============================================================
-- PASO 2: Agrupar nomenclaturas por dirección
-- NOM_AGRUP = concatenación de abreviaturas (ej: "TO|AP")
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_agrup;
CREATE TABLE bdm_stage.stg_motor_agrup
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT
  cod_dw_persona_ubic,
  LISTAGG(nomen, '|') WITHIN GROUP (ORDER BY id_com) AS nom_agrup,
  SUM(cantidad) AS cantidad
FROM bdm_stage.stg_motor_descomp
GROUP BY 1;

ANALYZE bdm_stage.stg_motor_agrup;

-- ============================================================
-- PASO 3: Calcular MDIR (jerarquía de dirección)
-- String ordenable: nivel(3 chars) + valor(6 chars) por nomenclatura
-- MDIR=1 = padre (mayor jerarquía), MDIR>1 = hijos
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_mdir;
CREATE TABLE bdm_stage.stg_motor_mdir
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  sub.cod_dw_persona_ubic,
  sub.cod_dw_ubic,
  sub.id_buro_persona,
  sub.cod_dw_tipo_ubicacion_dir,
  sub.mdir_key,
  ROW_NUMBER() OVER (
    PARTITION BY sub.cod_dw_ubic, sub.id_buro_persona, sub.cod_dw_tipo_ubicacion_dir
    ORDER BY sub.mdir_key, sub.cod_dw_persona_ubic ASC
  ) AS mdir
FROM (
  SELECT
    cod_dw_persona_ubic,
    cod_dw_ubic,
    id_buro_persona,
    cod_dw_tipo_ubicacion_dir,
    RPAD(
      LISTAGG(
        LPAD(CAST(nivel_complemento AS VARCHAR), 3, '0')
        || LPAD(CAST(CASE WHEN valor_num > 999999 THEN 999999 ELSE valor_num END AS VARCHAR), 6, '0'),
        ''
      ) WITHIN GROUP (ORDER BY id_com1),
      54, '099999999'
    ) AS mdir_key
  FROM bdm_stage.stg_motor_descomp
  GROUP BY 1,2,3,4
) sub;

ANALYZE bdm_stage.stg_motor_mdir;

-- ============================================================
-- PASO 4: Identificar padre (MDIR=1) e hijo (MDIR>1)
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_padre;
CREATE TABLE bdm_stage.stg_motor_padre
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  m.cod_dw_persona_ubic,
  m.cod_dw_ubic,
  m.id_buro_persona,
  m.cod_dw_tipo_ubicacion_dir,
  tu.complemento,
  tu.cod_pin_persona,
  tu.cod_dw_direccion_fisica,
  tu.texto_ubicacion,
  tu.fecha_relacion_persona_ubicaci,
  a.nom_agrup,
  a.cantidad
FROM bdm_stage.stg_motor_mdir m
JOIN bdm_stage.stg_motor_input tu
  ON m.cod_dw_persona_ubic = tu.cod_dw_persona_ubic
JOIN bdm_stage.stg_motor_agrup a
  ON m.cod_dw_persona_ubic = a.cod_dw_persona_ubic
WHERE m.mdir = 1;

ANALYZE bdm_stage.stg_motor_padre;

DROP TABLE IF EXISTS bdm_stage.stg_motor_hijo;
CREATE TABLE bdm_stage.stg_motor_hijo
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  m.cod_dw_persona_ubic,
  m.cod_dw_ubic,
  m.id_buro_persona,
  m.cod_dw_tipo_ubicacion_dir,
  tu.complemento,
  m.mdir,
  a.nom_agrup,
  a.cantidad
FROM bdm_stage.stg_motor_mdir m
JOIN bdm_stage.stg_motor_input tu
  ON m.cod_dw_persona_ubic = tu.cod_dw_persona_ubic
JOIN bdm_stage.stg_motor_agrup a
  ON m.cod_dw_persona_ubic = a.cod_dw_persona_ubic
WHERE m.mdir > 1;

ANALYZE bdm_stage.stg_motor_hijo;

-- ============================================================
-- PASO 5: Nomenclaturas del hijo que NO están en el padre
-- Reemplaza cursor + columnas dinámicas C1..CN + código binario
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_diff;
CREATE TABLE bdm_stage.stg_motor_diff
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic_hijo)
AS
SELECT
  h_nom.cod_dw_persona_ubic AS cod_dw_persona_ubic_hijo,
  p.cod_dw_persona_ubic AS cod_dw_persona_ubic_padre,
  h_nom.nomenclatura,
  h_nom.nomen,
  h_nom.valor_original,
  h_nom.id_com
FROM bdm_stage.stg_motor_descomp h_nom
JOIN bdm_stage.stg_motor_hijo h
  ON h_nom.cod_dw_persona_ubic = h.cod_dw_persona_ubic
JOIN bdm_stage.stg_motor_padre p
  ON h.cod_dw_ubic = p.cod_dw_ubic
  AND h.id_buro_persona = p.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = p.cod_dw_tipo_ubicacion_dir
LEFT JOIN bdm_stage.stg_motor_descomp p_nom
  ON p.cod_dw_persona_ubic = p_nom.cod_dw_persona_ubic
  AND h_nom.nomen = p_nom.nomen
  AND TRIM(h_nom.valor_original) = TRIM(p_nom.valor_original)
WHERE p_nom.cod_dw_persona_ubic IS NULL
  AND h.complemento <> p.complemento;

ANALYZE bdm_stage.stg_motor_diff;

-- ============================================================
-- PASO 6: Concatenar diferencias → nueva nomenclatura por par
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_codigo;
CREATE TABLE bdm_stage.stg_motor_codigo
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic_padre)
AS
SELECT
  cod_dw_persona_ubic_padre,
  cod_dw_persona_ubic_hijo,
  LISTAGG(nomenclatura, ' ') WITHIN GROUP (ORDER BY id_com) AS nueva_nomenclatura
FROM bdm_stage.stg_motor_diff
GROUP BY 1,2;

ANALYZE bdm_stage.stg_motor_codigo;

-- ============================================================
-- PASO 7: Construir nueva dirección completa
-- complemento_padre + nuevas nomenclaturas de todos los hijos
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_resultado;
CREATE TABLE bdm_stage.stg_motor_resultado
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  p.cod_dw_persona_ubic AS cod_dw_persona_ubic_padre,
  p.complemento AS complemento_padre,
  p.cod_dw_ubic,
  p.id_buro_persona,
  p.cod_dw_tipo_ubicacion_dir,
  p.cod_pin_persona,
  p.texto_ubicacion,
  p.fecha_relacion_persona_ubicaci,
  LEFT(
    TRIM(p.complemento) || ' ' || TRIM(LISTAGG(c.nueva_nomenclatura, ' ')
      WITHIN GROUP (ORDER BY h.mdir)),
    100
  ) AS nuevo_complemento,
  LISTAGG(CAST(c.cod_dw_persona_ubic_hijo AS VARCHAR), ',')
    WITHIN GROUP (ORDER BY h.mdir) AS hijos_ids
FROM bdm_stage.stg_motor_padre p
JOIN bdm_stage.stg_motor_codigo c
  ON p.cod_dw_persona_ubic = c.cod_dw_persona_ubic_padre
JOIN bdm_stage.stg_motor_hijo h
  ON c.cod_dw_persona_ubic_hijo = h.cod_dw_persona_ubic
GROUP BY 1,2,3,4,5,6,7,8;

ANALYZE bdm_stage.stg_motor_resultado;

-- ============================================================
-- PASO 8: Verificar existencia y generar IDs
-- Si la dirección combinada ya existe → reusar ID
-- Si no → MAX(id) + ROW_NUMBER() (sandbox; producción usa tabla de secuencias)
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_max_ids;
CREATE TABLE bdm_stage.stg_motor_max_ids AS
SELECT
  COALESCE((SELECT MAX(cod_dw_direccion_fisica) FROM bdm_stage.direccion_fisica), 0) AS max_df,
  COALESCE((SELECT MAX(cod_dw_persona_ubic) FROM bdm_stage.relacion_persona_ubicacion), 0) AS max_rpu;

DROP TABLE IF EXISTS bdm_stage.stg_motor_final;
CREATE TABLE bdm_stage.stg_motor_final
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  r.*,
  CASE WHEN df.cod_dw_direccion_fisica IS NOT NULL
    THEN df.cod_dw_direccion_fisica
    ELSE mx.max_df + ROW_NUMBER() OVER (
      PARTITION BY CASE WHEN df.cod_dw_direccion_fisica IS NULL THEN 1 ELSE 0 END
      ORDER BY r.cod_dw_persona_ubic_padre
    )
  END AS new_cod_dw_direccion_fisica,
  CASE WHEN df.cod_dw_direccion_fisica IS NULL THEN 1 ELSE 0 END AS es_nueva_df,
  mx.max_rpu + ROW_NUMBER() OVER (ORDER BY r.cod_dw_persona_ubic_padre) AS new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_resultado r
CROSS JOIN bdm_stage.stg_motor_max_ids mx
LEFT JOIN bdm_stage.direccion_fisica df
  ON df.cod_dw_ubic = r.cod_dw_ubic
  AND TRIM(df.complemento) = TRIM(r.nuevo_complemento);

ANALYZE bdm_stage.stg_motor_final;

-- ============================================================
-- PASO 9: INSERT en DIRECCION_FISICA (solo nuevas)
-- Generada_Enriquecida=1 marca que fue generada por el motor
-- ============================================================
INSERT INTO bdm_stage.direccion_fisica (
  cod_dw_direccion_fisica, complemento, cod_dw_ubic, generada_enriquecida
)
SELECT DISTINCT
  new_cod_dw_direccion_fisica,
  nuevo_complemento,
  cod_dw_ubic,
  1
FROM bdm_stage.stg_motor_final
WHERE es_nueva_df = 1;

-- ============================================================
-- PASO 10: INSERT en RELACION_PERSONA_UBICACION (nueva relación padre)
-- ============================================================
INSERT INTO bdm_stage.relacion_persona_ubicacion (
  cod_dw_persona_ubic,
  id_buro_persona,
  cod_pin_persona,
  cod_dw_ubic,
  cod_dw_direccion_fisica,
  cod_dw_tipo_ubicacion_dir,
  ind_unificacion,
  fecha_relacion_persona_ubicaci,
  lote
)
SELECT
  new_cod_dw_persona_ubic,
  id_buro_persona,
  cod_pin_persona,
  cod_dw_ubic,
  new_cod_dw_direccion_fisica,
  cod_dw_tipo_ubicacion_dir,
  NULL,
  CURRENT_DATE,
  1
FROM bdm_stage.stg_motor_final;

-- ============================================================
-- PASO 11: INSERT en UNIFICACION_DIRECCION (pares padre-hijo)
-- Cada hijo original apunta al nuevo cod_dw_persona_ubic del padre generado
-- En escenarios con motor, el padre MDIR original TAMBIÉN es hijo del nuevo padre
-- ============================================================
INSERT INTO bdm_stage.unificacion_direccion (
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  unifica_atributos,
  fecha_unificacion,
  lote,
  severidad,
  usuario_bd
)
SELECT
  h.cod_dw_persona_ubic,
  f.new_cod_dw_persona_ubic,
  2,
  CURRENT_DATE,
  1,
  1,
  LEFT(CURRENT_USER, 30)
FROM bdm_stage.stg_motor_final f
JOIN bdm_stage.stg_motor_hijo h
  ON h.cod_dw_ubic = f.cod_dw_ubic
  AND h.id_buro_persona = f.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = f.cod_dw_tipo_ubicacion_dir;

-- Padre MDIR original también es hijo del nuevo padre generado
INSERT INTO bdm_stage.unificacion_direccion (
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  unifica_atributos,
  fecha_unificacion,
  lote,
  severidad,
  usuario_bd
)
SELECT
  f.cod_dw_persona_ubic_padre,
  f.new_cod_dw_persona_ubic,
  2,
  CURRENT_DATE,
  1,
  1,
  LEFT(CURRENT_USER, 30)
FROM bdm_stage.stg_motor_final f;

-- ============================================================
-- PASO 12: UPDATE Ind_Unificacion=1 en TODAS las originales (hijos + padre MDIR)
-- ============================================================
UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_motor_hijo
  UNION ALL
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_motor_padre
);

-- ============================================================
-- PASO 13: ANALYZE en todas las tablas modificadas
-- ============================================================
ANALYZE bdm_stage.direccion_fisica;
ANALYZE bdm_stage.relacion_persona_ubicacion;
ANALYZE bdm_stage.unificacion_direccion;

-- ============================================================
-- Limpieza de tablas staging del motor
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_max_ids;
DROP TABLE IF EXISTS bdm_stage.stg_motor_descomp;
DROP TABLE IF EXISTS bdm_stage.stg_motor_agrup;
DROP TABLE IF EXISTS bdm_stage.stg_motor_mdir;
DROP TABLE IF EXISTS bdm_stage.stg_motor_diff;
DROP TABLE IF EXISTS bdm_stage.stg_motor_codigo;
DROP TABLE IF EXISTS bdm_stage.stg_motor_resultado;
-- Nota: stg_motor_input, stg_motor_final, stg_motor_padre y stg_motor_hijo
--       NO se borran aquí — los limpia el script *b que invoca al motor (07b/08b/09b)
/* === FIN 06_motor_nuevas_direcciones.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = p_run_id AND step_id = 'R2_MOTOR_BATCH_RUN' AND ended_at IS NULL;
-- PERF:END step=R2_MOTOR_BATCH_RUN



-- PERF:BEGIN step=R2_MOTOR_BATCH_FIN order=8
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES (p_run_id, 8, 'R2_MOTOR_BATCH_FIN', 'Motor batch finalize', 'inc_batch_motor_finalize.sql', GETDATE());

-- ============================================================
-- BATCH MOTOR — finalize (07b + 08b + 09b filtrado por origen)
-- Ejecutar DESPUÉS de 06_motor en modo batch
-- ============================================================

-- --- 07b NIT finalize (solo filas NIT) ---
UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'X4', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
JOIN bdm_stage.stg_motor_hijo h
  ON h.cod_dw_ubic = f.cod_dw_ubic AND h.id_buro_persona = f.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = f.cod_dw_tipo_ubicacion_dir
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = h.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N'
  AND h.cod_dw_persona_ubic IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_motor_input_nit);

UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'X4', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = f.cod_dw_persona_ubic_padre
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N'
  AND f.cod_dw_persona_ubic_padre IN (
    SELECT DISTINCT e.cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e031 e
    JOIN bdm_stage.stg_regla2_e03_nit_pares p ON e.cod_dw_persona_ubic = p.cod_dw_persona_ubic
  );

INSERT INTO bdm_stage.stg_regla2_e2 (
  cod_dw_persona_ubic, id_padre, id_buro_persona, cod_dw_tipo_ubicacion_dir,
  cod_dw_ubic, texto_ubicacion, cod_dw_direccion_fisica, complemento, ind_unificacion, n_id
)
SELECT f.new_cod_dw_persona_ubic, NULL, f.id_buro_persona, f.cod_dw_tipo_ubicacion_dir,
  f.cod_dw_ubic, f.texto_ubicacion, f.new_cod_dw_direccion_fisica, f.nuevo_complemento, 'N', NULL
FROM bdm_stage.stg_motor_final f
WHERE f.new_cod_dw_persona_ubic IN (
  SELECT DISTINCT mf.new_cod_dw_persona_ubic FROM bdm_stage.stg_motor_final mf
  JOIN bdm_stage.stg_motor_hijo h ON h.cod_dw_ubic = mf.cod_dw_ubic
    AND h.id_buro_persona = mf.id_buro_persona
  WHERE h.cod_dw_persona_ubic IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_motor_input_nit)
);

-- --- 08b Esc5 motor part (solo ESC5) ---
UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'M5', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
JOIN bdm_stage.stg_motor_hijo h
  ON h.cod_dw_ubic = f.cod_dw_ubic AND h.id_buro_persona = f.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = f.cod_dw_tipo_ubicacion_dir
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = h.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N'
  AND h.cod_dw_persona_ubic IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_motor_input_esc5);

UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'M5', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = f.cod_dw_persona_ubic_padre
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N'
  AND f.cod_dw_persona_ubic_padre IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e05_sub1);

INSERT INTO bdm_stage.stg_regla2_e2 (
  cod_dw_persona_ubic, id_padre, id_buro_persona, cod_dw_tipo_ubicacion_dir,
  cod_dw_ubic, texto_ubicacion, cod_dw_direccion_fisica, complemento, ind_unificacion, n_id
)
SELECT f.new_cod_dw_persona_ubic, NULL, f.id_buro_persona, f.cod_dw_tipo_ubicacion_dir,
  f.cod_dw_ubic, f.texto_ubicacion, f.new_cod_dw_direccion_fisica, f.nuevo_complemento, 'N', NULL
FROM bdm_stage.stg_motor_final f
WHERE EXISTS (
  SELECT 1 FROM bdm_stage.stg_motor_input_esc5 e
  WHERE e.id_buro_persona = f.id_buro_persona AND e.cod_dw_ubic = f.cod_dw_ubic
);

-- 08b subcaso 2 diccionario (igual que 08b original)
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2;
CREATE TABLE bdm_stage.stg_regla2_e05_sub2
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM bdm_stage.stg_regla2_e05_a A
JOIN bdm_stage.stg_regla2_e05_a B
  ON  A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
  AND TRIM(A.complemento2) = TRIM(B.complemento2) AND A.nivel_pri <> B.nivel_pri
WHERE A.cod_dw_persona_ubic NOT IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e05_sub1);

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_freq;
CREATE TABLE bdm_stage.stg_regla2_e05_sub2_freq
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT t1.cod_dw_persona_ubic, COALESCE(t2.conteo, 0) AS conteo
FROM bdm_stage.stg_regla2_e05_sub2 t1
LEFT JOIN (
  SELECT t1.cod_dw_persona_ubic, SUM(dc.frecuencia) AS conteo
  FROM bdm_stage.stg_regla2_e05_sub2 t1
  LEFT JOIN bdm_stage.diccionario_complementos dc
    ON t1.cod_dw_ubic = dc.cod_dw_ubic AND t1.complemento LIKE '%' || dc.nomenclatura || '%'
    AND t1.id_buro_persona = dc.id_buro_persona
  GROUP BY 1
) t2 ON t1.cod_dw_persona_ubic = t2.cod_dw_persona_ubic;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_d;
CREATE TABLE bdm_stage.stg_regla2_e05_sub2_d
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT u1.*,
  COUNT(*) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id) AS count_empate,
  MAX(id) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio) AS idmax
FROM (
  SELECT a.cod_dw_persona_ubic,
    (COALESCE(b.conteo, 0) + 10000000)
      + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0) AS id,
    a.texto_ubicacion, a.id_buro_persona, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio,
    a.cod_dw_ubic, a.complemento,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
      ORDER BY (COALESCE(b.conteo, 0) + 10000000)
        + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0)
    ) AS orden
  FROM bdm_stage.stg_regla2_e05_sub2 a
  LEFT JOIN bdm_stage.stg_regla2_e05_sub2_freq b ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
) u1;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_e;
CREATE TABLE bdm_stage.stg_regla2_e05_sub2_e
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT B.cod_dw_persona_ubic, A.cod_dw_persona_ubic AS id_padre
FROM bdm_stage.stg_regla2_e05_sub2_d A
JOIN bdm_stage.stg_regla2_e05_sub2_d B
  ON  A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.id > B.id
JOIN (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, MAX(orden) AS max_orden
  FROM bdm_stage.stg_regla2_e05_sub2_d GROUP BY 1,2,3,4
) mx ON A.id_buro_persona = mx.id_buro_persona AND A.texto_ubicacion = mx.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = mx.cod_dw_municipio
  AND A.orden = mx.max_orden;

UPDATE bdm_stage.stg_regla2_e2
SET id_padre = e.id_padre, ind_unificacion = 'S', n_id = 'D5'
FROM bdm_stage.stg_regla2_e05_sub2_e e
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = e.cod_dw_persona_ubic AND bdm_stage.stg_regla2_e2.id_padre IS NULL;

INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT e.cod_dw_persona_ubic, e.id_padre, 2, CURRENT_DATE, 1, 1, LEFT(CURRENT_USER, 30)
FROM bdm_stage.stg_regla2_e05_sub2_e e;

UPDATE bdm_stage.relacion_persona_ubicacion SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e05_sub2_e);

-- --- 09b Esc6 motor part (solo ESC6) ---
UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'M6', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
JOIN bdm_stage.stg_motor_hijo h
  ON h.cod_dw_ubic = f.cod_dw_ubic AND h.id_buro_persona = f.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = f.cod_dw_tipo_ubicacion_dir
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = h.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N'
  AND h.cod_dw_persona_ubic IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_motor_input_esc6);

UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'M6', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = f.cod_dw_persona_ubic_padre
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N'
  AND f.cod_dw_persona_ubic_padre IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e06_sub1);

INSERT INTO bdm_stage.stg_regla2_e2 (
  cod_dw_persona_ubic, id_padre, id_buro_persona, cod_dw_tipo_ubicacion_dir,
  cod_dw_ubic, texto_ubicacion, cod_dw_direccion_fisica, complemento, ind_unificacion, n_id
)
SELECT f.new_cod_dw_persona_ubic, NULL, f.id_buro_persona, f.cod_dw_tipo_ubicacion_dir,
  f.cod_dw_ubic, f.texto_ubicacion, f.new_cod_dw_direccion_fisica, f.nuevo_complemento, 'N', NULL
FROM bdm_stage.stg_motor_final f
WHERE EXISTS (
  SELECT 1 FROM bdm_stage.stg_motor_input_esc6 e
  WHERE e.id_buro_persona = f.id_buro_persona AND e.cod_dw_ubic = f.cod_dw_ubic
);

-- 09b subcaso 3 diccionario
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3;
CREATE TABLE bdm_stage.stg_regla2_e06_sub3
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM bdm_stage.stg_regla2_e06_c A
JOIN bdm_stage.stg_regla2_e06_c B
  ON  A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.complemento <> B.complemento
  AND COALESCE(A.nivel_pri, 0) = COALESCE(B.nivel_pri, 0)
WHERE A.cod_dw_persona_ubic NOT IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e06_sub1);

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_freq;
CREATE TABLE bdm_stage.stg_regla2_e06_sub3_freq
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT t1.cod_dw_persona_ubic, COALESCE(t2.conteo, 0) AS conteo
FROM bdm_stage.stg_regla2_e06_sub3 t1
LEFT JOIN (
  SELECT t1.cod_dw_persona_ubic, SUM(dc.frecuencia) AS conteo
  FROM bdm_stage.stg_regla2_e06_sub3 t1
  LEFT JOIN bdm_stage.diccionario_complementos dc
    ON t1.cod_dw_ubic = dc.cod_dw_ubic AND t1.complemento LIKE '%' || dc.nomenclatura || '%'
    AND t1.id_buro_persona = dc.id_buro_persona
  GROUP BY 1
) t2 ON t1.cod_dw_persona_ubic = t2.cod_dw_persona_ubic;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_d;
CREATE TABLE bdm_stage.stg_regla2_e06_sub3_d
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT u1.*,
  COUNT(*) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id) AS count_empate,
  MAX(id) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio) AS idmax
FROM (
  SELECT a.cod_dw_persona_ubic,
    (COALESCE(b.conteo, 0) + 10000000)
      + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0) AS id,
    a.texto_ubicacion, a.id_buro_persona, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
      ORDER BY (COALESCE(b.conteo, 0) + 10000000)
        + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0)
    ) AS orden
  FROM bdm_stage.stg_regla2_e06_sub3 a
  LEFT JOIN bdm_stage.stg_regla2_e06_sub3_freq b ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
) u1;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_e;
CREATE TABLE bdm_stage.stg_regla2_e06_sub3_e
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT B.cod_dw_persona_ubic, A.cod_dw_persona_ubic AS id_padre
FROM bdm_stage.stg_regla2_e06_sub3_d A
JOIN bdm_stage.stg_regla2_e06_sub3_d B
  ON  A.id_buro_persona = B.id_buro_persona AND A.texto_ubicacion = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic <> B.cod_dw_persona_ubic AND A.id > B.id
JOIN (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, MAX(orden) AS max_orden
  FROM bdm_stage.stg_regla2_e06_sub3_d GROUP BY 1,2,3,4
) mx ON A.id_buro_persona = mx.id_buro_persona AND A.texto_ubicacion = mx.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = mx.cod_dw_municipio
  AND A.orden = mx.max_orden;

UPDATE bdm_stage.stg_regla2_e2
SET id_padre = e.id_padre, ind_unificacion = 'S', n_id = 'D6'
FROM bdm_stage.stg_regla2_e06_sub3_e e
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = e.cod_dw_persona_ubic AND bdm_stage.stg_regla2_e2.id_padre IS NULL;

INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT e.cod_dw_persona_ubic, e.id_padre, 2, CURRENT_DATE, 1, 1, LEFT(CURRENT_USER, 30)
FROM bdm_stage.stg_regla2_e06_sub3_e e;

UPDATE bdm_stage.relacion_persona_ubicacion SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e06_sub3_e);

ANALYZE bdm_stage.unificacion_direccion;
ANALYZE bdm_stage.relacion_persona_ubicacion;
ANALYZE bdm_stage.stg_regla2_e2;

-- Limpieza batch staging
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e031;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_nit_pares;
DROP TABLE IF EXISTS bdm_stage.stg_motor_input_nit;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_a;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_c;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub1;
DROP TABLE IF EXISTS bdm_stage.stg_motor_input_esc5;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_a;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_c;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub1;
DROP TABLE IF EXISTS bdm_stage.stg_motor_input_esc6;
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
DROP TABLE IF EXISTS bdm_stage.stg_motor_final;
DROP TABLE IF EXISTS bdm_stage.stg_motor_padre;
DROP TABLE IF EXISTS bdm_stage.stg_motor_hijo;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_freq;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_d;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_e;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_freq;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_d;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_e;


UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = p_run_id AND step_id = 'R2_MOTOR_BATCH_FIN' AND ended_at IS NULL;
-- PERF:END step=R2_MOTOR_BATCH_FIN


END;
$$ LANGUAGE plpgsql;


-- ============================================================
-- SP_R3 — Regla 3 geo
-- Schema: bdm_stage | Pipeline: db_rcncr_btch_rdshft_pgm
-- Fuente: 00_run_benchmark_20k_batch_exec.sql
-- ============================================================
CREATE OR REPLACE PROCEDURE bdm_stage.sp_r3(p_run_id VARCHAR(64))
NONATOMIC
AS $$
BEGIN
-- HITO 9 : Regla 3
-- SOURCE: 10_regla3_geo.sql
-- ============================================================

-- PERF:BEGIN step=R3 order=9
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES (p_run_id, 9, 'R3', 'Regla 3', '10_regla3_geo.sql', GETDATE());

/* === INICIO 10_regla3_geo.sql === */
-- ============================================================
-- PASO 1: Materializar insumo de Regla 3
-- Solo registros NO unificados, tipo vía, sin modificadores
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_regla3_insumo;
CREATE TABLE bdm_stage.stg_regla3_insumo
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, tipo_via_principal, via_principal)
AS
SELECT
  rpu.cod_dw_persona_ubic,
  rpu.id_buro_persona,
  ubi.texto_ubicacion,
  df.tipo_via_principal,
  df.via_principal,
  df.via_generadora,
  df.numero_puerta,
  ubi.cod_dw_ciudad AS cod_dw_municipio,
  ubi.latitud,
  ubi.longitud,
  COALESCE(cnt.numero_entidades_reportan, 0) AS numero_entidades_reportan,
  COALESCE(MAX(rep.fecha_reporte), '1900-01-01') AS fecha_ultima_actualizacion
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
LEFT JOIN (
  SELECT cod_dw_persona_ubic, COUNT(DISTINCT id_buro_suscriptor) AS numero_entidades_reportan
  FROM bdm_stage.reporte_relacion_persona_ubica GROUP BY 1
) cnt ON rpu.cod_dw_persona_ubic = cnt.cod_dw_persona_ubic
WHERE rpu.ind_unificacion IS NULL
  -- Excluir modificadores de vía (B, C, F, BIS, etc.) y cuadrantes
  AND ubi.texto_ubicacion !~ '[0-9]{1,3}[A-Z]{1,5}| OE$| E$| NE$| SE$| O$| S$| N$| SOE$'
GROUP BY 1,2,3,4,5,6,7,8,9,10,11;

ANALYZE bdm_stage.stg_regla3_insumo;

-- ============================================================
-- PASO 2: Identificar pares candidatos
-- ID_U=1: misma persona+municipio+tipo_via+via_principal+puerta, ≠ vía generadora
-- ID_U=2: misma persona+municipio+tipo_via+via_principal+via_gen, ≠ puerta (±2)
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_regla3_pares;
CREATE TABLE bdm_stage.stg_regla3_pares
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
-- Escenario 1: ≠ vía generadora
SELECT T1.*, 1 AS id_u
FROM bdm_stage.stg_regla3_insumo T1
JOIN bdm_stage.stg_regla3_insumo T2
  ON  T1.id_buro_persona     = T2.id_buro_persona
  AND T1.cod_dw_municipio    = T2.cod_dw_municipio
  AND T1.tipo_via_principal  = T2.tipo_via_principal
  AND T1.via_principal       = T2.via_principal
  AND T1.numero_puerta       = T2.numero_puerta
  AND T1.via_generadora     <> T2.via_generadora
GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12

UNION ALL

-- Escenario 2: ≠ número de puerta (±2)
SELECT T1.*, 2 AS id_u
FROM bdm_stage.stg_regla3_insumo T1
JOIN bdm_stage.stg_regla3_insumo T2
  ON  T1.id_buro_persona     = T2.id_buro_persona
  AND T1.cod_dw_municipio    = T2.cod_dw_municipio
  AND T1.tipo_via_principal  = T2.tipo_via_principal
  AND T1.via_principal       = T2.via_principal
  AND T1.via_generadora      = T2.via_generadora
  AND ABS(T1.numero_puerta - T2.numero_puerta) = 2
  AND T1.numero_puerta      <> T2.numero_puerta
GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12;

ANALYZE bdm_stage.stg_regla3_pares;

-- ============================================================
-- PASO 3: Construir diccionario de vía (frecuencias)
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_regla3_diccionario_via;
CREATE TABLE bdm_stage.stg_regla3_diccionario_via
DISTSTYLE ALL
AS
-- Via_Generadora: llave = tipo_via + via_principal + numero_puerta
SELECT
  'Via_Generadora' AS tipo,
  df.tipo_via_principal || ' ' || df.via_principal || ' ' || CAST(df.numero_puerta AS VARCHAR) AS llave,
  df.via_generadora,
  p.cod_dw_municipio,
  COUNT(rep.cod_dw_persona_ubic) AS conteo
FROM bdm_stage.direccion_fisica df
JOIN bdm_stage.ubicacion_estandarizada ue ON df.cod_dw_ubic = ue.cod_dw_ubic
JOIN bdm_stage.stg_regla3_pares p ON p.texto_ubicacion = ue.texto_ubicacion AND p.id_u = 1
JOIN bdm_stage.relacion_persona_ubicacion rpu ON df.cod_dw_ubic = rpu.cod_dw_ubic AND df.cod_dw_direccion_fisica = rpu.cod_dw_direccion_fisica
JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
GROUP BY 1,2,3,4

UNION ALL

-- Numero_Puerta: llave = tipo_via + via_principal + via_generadora
SELECT
  'Numero_Puerta' AS tipo,
  df.tipo_via_principal || ' ' || df.via_principal || ' ' || CAST(df.via_generadora AS VARCHAR) AS llave,
  df.numero_puerta AS via_generadora,
  p.cod_dw_municipio,
  COUNT(rep.cod_dw_persona_ubic) AS conteo
FROM bdm_stage.direccion_fisica df
JOIN bdm_stage.ubicacion_estandarizada ue ON df.cod_dw_ubic = ue.cod_dw_ubic
JOIN bdm_stage.stg_regla3_pares p ON p.texto_ubicacion = ue.texto_ubicacion AND p.id_u = 2
JOIN bdm_stage.relacion_persona_ubicacion rpu ON df.cod_dw_ubic = rpu.cod_dw_ubic AND df.cod_dw_direccion_fisica = rpu.cod_dw_direccion_fisica
JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
GROUP BY 1,2,3,4;

ANALYZE bdm_stage.stg_regla3_diccionario_via;

-- Persistir diccionario en bdm_stage para referencia
DELETE FROM bdm_stage.diccionario_via WHERE 1=1;
INSERT INTO bdm_stage.diccionario_via SELECT * FROM bdm_stage.stg_regla3_diccionario_via;
ANALYZE bdm_stage.diccionario_via;

-- ============================================================
-- PASO 4: Calcular score unificado (combina los 3 subcasos)
-- Score = geo_component + fecha_component + entidades
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_regla3_scored;
CREATE TABLE bdm_stage.stg_regla3_scored
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  v.*,
  CASE
    -- Escenario 1: ≠ vía generadora
    WHEN v.id_u = 1 THEN
      CASE WHEN NULLIF(v.latitud, 0) IS NOT NULL AND NULLIF(v.longitud, 0) IS NOT NULL
        THEN 100000000 + COALESCE(dvv.conteo, 0) ELSE 0 END
      + CASE WHEN NULLIF(v.latitud, 0) IS NULL OR NULLIF(v.longitud, 0) IS NULL
        THEN COALESCE(CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR), '-', '') AS BIGINT), 0) ELSE 0 END
      + COALESCE(v.numero_entidades_reportan, 0)
    -- Escenario 2: ≠ número de puerta
    WHEN v.id_u = 2 THEN
      CASE WHEN NULLIF(v.latitud, 0) IS NOT NULL AND NULLIF(v.longitud, 0) IS NOT NULL
        THEN 100000000 + COALESCE(dvp.conteo, 0) ELSE 0 END
      + CASE WHEN NULLIF(v.latitud, 0) IS NULL AND NULLIF(v.longitud, 0) IS NULL
        THEN COALESCE(CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR), '-', '') AS BIGINT), 0) ELSE 0 END
      + COALESCE(v.numero_entidades_reportan, 0)
    ELSE 0
  END AS id_unificacion,

  -- Rankings por escenario
  ROW_NUMBER() OVER (PARTITION BY v.tipo_via_principal, v.via_principal, v.via_generadora,
    v.id_buro_persona, v.cod_dw_municipio
    ORDER BY CASE WHEN v.id_u=1 THEN
      CASE WHEN NULLIF(v.latitud,0) IS NOT NULL AND NULLIF(v.longitud,0) IS NOT NULL THEN 100000000+COALESCE(dvv.conteo,0) ELSE 0 END
      + CASE WHEN NULLIF(v.latitud,0) IS NULL OR NULLIF(v.longitud,0) IS NULL THEN COALESCE(CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR),'-','') AS BIGINT),0) ELSE 0 END
      + COALESCE(v.numero_entidades_reportan,0) ELSE 0 END DESC) AS id1,

  ROW_NUMBER() OVER (PARTITION BY v.tipo_via_principal, v.via_principal, v.numero_puerta,
    v.id_buro_persona, v.cod_dw_municipio
    ORDER BY CASE WHEN v.id_u=2 THEN
      CASE WHEN NULLIF(v.latitud,0) IS NOT NULL AND NULLIF(v.longitud,0) IS NOT NULL THEN 100000000+COALESCE(dvp.conteo,0) ELSE 0 END
      + CASE WHEN NULLIF(v.latitud,0) IS NULL AND NULLIF(v.longitud,0) IS NULL THEN COALESCE(CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR),'-','') AS BIGINT),0) ELSE 0 END
      + COALESCE(v.numero_entidades_reportan,0) ELSE 0 END DESC) AS id2,

  -- Detectar empates
  COUNT(*) OVER (PARTITION BY v.tipo_via_principal, v.via_principal, v.via_generadora,
    v.id_buro_persona, v.cod_dw_municipio,
    CASE WHEN v.id_u=1 THEN
      CASE WHEN NULLIF(v.latitud,0) IS NOT NULL AND NULLIF(v.longitud,0) IS NOT NULL THEN 100000000+COALESCE(dvv.conteo,0) ELSE 0 END
      + CASE WHEN NULLIF(v.latitud,0) IS NULL OR NULLIF(v.longitud,0) IS NULL THEN COALESCE(CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR),'-','') AS BIGINT),0) ELSE 0 END
      + COALESCE(v.numero_entidades_reportan,0) ELSE 0 END) AS cantidad1,

  COUNT(*) OVER (PARTITION BY v.tipo_via_principal, v.via_principal, v.numero_puerta,
    v.id_buro_persona, v.cod_dw_municipio,
    CASE WHEN v.id_u=2 THEN
      CASE WHEN NULLIF(v.latitud,0) IS NOT NULL AND NULLIF(v.longitud,0) IS NOT NULL THEN 100000000+COALESCE(dvp.conteo,0) ELSE 0 END
      + CASE WHEN NULLIF(v.latitud,0) IS NULL AND NULLIF(v.longitud,0) IS NULL THEN COALESCE(CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR),'-','') AS BIGINT),0) ELSE 0 END
      + COALESCE(v.numero_entidades_reportan,0) ELSE 0 END) AS cantidad2

FROM bdm_stage.stg_regla3_pares v
-- Diccionario vía generadora
LEFT JOIN bdm_stage.stg_regla3_diccionario_via dvv
  ON v.tipo_via_principal || ' ' || v.via_principal || ' ' || CAST(v.numero_puerta AS VARCHAR) = dvv.llave
  AND v.via_generadora = dvv.via_generadora
  AND v.cod_dw_municipio = dvv.cod_dw_municipio
  AND dvv.tipo = 'Via_Generadora'
-- Diccionario número puerta
LEFT JOIN bdm_stage.stg_regla3_diccionario_via dvp
  ON v.tipo_via_principal || ' ' || v.via_principal || ' ' || CAST(v.via_generadora AS VARCHAR) = dvp.llave
  AND v.numero_puerta = dvp.via_generadora
  AND dvp.tipo = 'Numero_Puerta';

ANALYZE bdm_stage.stg_regla3_scored;

-- ============================================================
-- PASO 5: Generar pares padre-hijo
-- Escenario 1 (ID_U=1): partición por tipo_via+via_principal+puerta
-- Escenario 2 (ID_U=2): partición por tipo_via+via_principal+via_gen
-- Empate (cantidad>1) → no unifica
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_regla3_resultado;
CREATE TABLE bdm_stage.stg_regla3_resultado
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
-- Escenario 1: ≠ vía generadora
SELECT T1.cod_dw_persona_ubic, T2.cod_dw_persona_ubic AS cod_dw_direccion_unificada
FROM bdm_stage.stg_regla3_scored T1
JOIN (
  SELECT cod_dw_persona_ubic, id_buro_persona, cod_dw_municipio, tipo_via_principal, via_principal, numero_puerta, via_generadora, id_unificacion
  FROM bdm_stage.stg_regla3_scored
  WHERE cantidad1 = 1 AND id_u = 1 AND id1 = 1
) T2
  ON  T1.id_buro_persona    = T2.id_buro_persona
  AND T1.cod_dw_municipio   = T2.cod_dw_municipio
  AND T1.tipo_via_principal  = T2.tipo_via_principal
  AND T1.via_principal       = T2.via_principal
  AND T1.numero_puerta       = T2.numero_puerta
  AND T1.via_generadora     <> T2.via_generadora
  AND T1.id_unificacion     <= T2.id_unificacion
  AND T1.cod_dw_persona_ubic <> T2.cod_dw_persona_ubic
WHERE T1.id_u = 1

UNION ALL

-- Escenario 2: ≠ número de puerta
SELECT T1.cod_dw_persona_ubic, T2.cod_dw_persona_ubic AS cod_dw_direccion_unificada
FROM bdm_stage.stg_regla3_scored T1
JOIN (
  SELECT cod_dw_persona_ubic, id_buro_persona, cod_dw_municipio, tipo_via_principal, via_principal, via_generadora, numero_puerta, id_unificacion
  FROM bdm_stage.stg_regla3_scored
  WHERE cantidad2 = 1 AND id_u = 2 AND id2 = 1
) T2
  ON  T1.id_buro_persona    = T2.id_buro_persona
  AND T1.cod_dw_municipio   = T2.cod_dw_municipio
  AND T1.tipo_via_principal  = T2.tipo_via_principal
  AND T1.via_principal       = T2.via_principal
  AND T1.via_generadora      = T2.via_generadora
  AND T1.numero_puerta      <> T2.numero_puerta
  AND T1.id_unificacion     <= T2.id_unificacion
  AND T1.cod_dw_persona_ubic <> T2.cod_dw_persona_ubic
WHERE T1.id_u = 2;

ANALYZE bdm_stage.stg_regla3_resultado;

-- ============================================================
-- PASO 6: Persistir
-- ============================================================
INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  1 AS unifica_atributos,
  CURRENT_DATE AS fecha_unificacion,
  1 AS lote,
  1 AS severidad,
  LEFT(CURRENT_USER, 30) AS usuario_bd
FROM bdm_stage.stg_regla3_resultado;

UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla3_resultado
);

-- ============================================================
-- PASO 7: Estadísticas y limpieza
-- ============================================================
ANALYZE bdm_stage.unificacion_direccion;
ANALYZE bdm_stage.relacion_persona_ubicacion;

DROP TABLE IF EXISTS bdm_stage.stg_regla3_insumo;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_pares;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_diccionario_via;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_scored;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_resultado;
/* === FIN 10_regla3_geo.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = p_run_id AND step_id = 'R3' AND ended_at IS NULL;
-- PERF:END step=R3


END;
$$ LANGUAGE plpgsql;


SELECT proname
FROM pg_proc p
JOIN pg_namespace n ON n.oid = p.pronamespace
WHERE n.nspname = 'bdm_stage' AND proname IN ('sp_r1','sp_r2','sp_r3')
ORDER BY 1;

