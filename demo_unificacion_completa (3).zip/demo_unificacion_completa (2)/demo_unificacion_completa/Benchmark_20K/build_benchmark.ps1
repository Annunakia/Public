# build_benchmark.ps1 — Ensambla 00_run_benchmark_*.sql desde fragmentos y scripts raíz
# Uso: .\build_benchmark.ps1
# NO ejecutar en DBeaver — solo mantenimiento del repo

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$Bmk  = $PSScriptRoot

function Get-SqlBody {
    param([string]$Path)
    $content = Get-Content -Path $Path -Raw -Encoding UTF8
    # Quitar header de comentarios del archivo fuente (primer bloque ===)
    if ($content -match '(?s)^-- =+.*?\n\n') {
        $content = $content -replace '(?s)^-- =+.*?\n\n', ''
    }
    return $content.Trim()
}

function Write-TimingStart {
    param([int]$Order, [string]$StepId, [string]$Label, [string]$Source, [string]$RunId)
    @"

-- PERF:BEGIN step=$StepId order=$Order
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES ('$RunId', $Order, '$StepId', '$Label', '$Source', GETDATE());

"@
}

function Write-TimingEnd {
    param([string]$StepId, [string]$RunId)
    @"

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = '$RunId' AND step_id = '$StepId' AND ended_at IS NULL;
-- PERF:END step=$StepId

"@
}

function Embed-Script {
    param([int]$Order, [string]$StepId, [string]$Label, [string]$RelPath, [string]$RunId)
    $full = Join-Path $Root $RelPath
    if (-not (Test-Path $full)) { throw "No encontrado: $full" }
    $src = Split-Path $RelPath -Leaf
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine("-- ============================================================")
    [void]$sb.AppendLine("-- HITO $Order : $Label")
    [void]$sb.AppendLine("-- SOURCE: $RelPath")
    [void]$sb.AppendLine("-- ============================================================")
    [void]$sb.AppendLine((Write-TimingStart -Order $Order -StepId $StepId -Label $Label -Source $src -RunId $RunId))
    [void]$sb.AppendLine("/* === INICIO $src === */")
    [void]$sb.AppendLine((Get-SqlBody $full))
    [void]$sb.AppendLine("/* === FIN $src === */")
    [void]$sb.AppendLine((Write-TimingEnd -StepId $StepId -RunId $RunId))
    return $sb.ToString()
}

function Embed-Fragment {
    param([int]$Order, [string]$StepId, [string]$Label, [string]$FragName, [string]$RunId)
    $full = Join-Path $Bmk $FragName
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine((Write-TimingStart -Order $Order -StepId $StepId -Label $Label -Source $FragName -RunId $RunId))
    [void]$sb.AppendLine((Get-Content $full -Raw -Encoding UTF8))
    [void]$sb.AppendLine((Write-TimingEnd -StepId $StepId -RunId $RunId))
    return $sb.ToString()
}

function Build-Benchmark {
    param(
        [string]$OutName,
        [int]$PersonaCount,
        [string]$RunIdDefault,
        [ValidateSet('demo_fiel','batch')]
        [string]$MotorMode
    )

    $rpu = $PersonaCount * 2
    $header = @"
-- ============================================================
-- $OutName
-- Benchmark Unificacion — $PersonaCount personas (~$rpu RPU)
-- Motor: $MotorMode
-- Ejecutar en DBeaver: Execute SQL Script (Alt+Shift+X)
-- ============================================================
-- Editar run_id en perf_timings si repite corrida (buscar '$RunIdDefault')

"@

    $parts = New-Object System.Collections.Generic.List[string]

    $parts.Add($header)

    $parts.Add(@"
-- ============================================================
-- perf_timings
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.perf_timings;
CREATE TABLE bdm_stage.perf_timings (
  run_id          VARCHAR(64),
  step_order      INT,
  step_id         VARCHAR(64),
  label           VARCHAR(256),
  script_source   VARCHAR(256),
  started_at      TIMESTAMP,
  ended_at        TIMESTAMP,
  duration_sec    BIGINT,
  status          VARCHAR(16)
);

DELETE FROM bdm_stage.perf_timings WHERE run_id = '$RunIdDefault';

"@)

    # DATA_LOAD
    $dataLoad = Get-Content (Join-Path $Bmk 'inc_data_load.sql') -Raw -Encoding UTF8
    $dataLoad = $dataLoad -replace '@PERSONA_COUNT@', "$PersonaCount"
    $dataLoad = $dataLoad -replace '@RPU_COUNT@', "$rpu"
    $parts.Add("-- HITO 1: DATA_LOAD`n")
    $parts.Add((Write-TimingStart -Order 1 -StepId 'DATA_LOAD' -Label "Carga $PersonaCount personas" -Source 'inc_data_load.sql' -RunId $RunIdDefault))
    $parts.Add($dataLoad)
    $parts.Add((Write-TimingEnd -StepId 'DATA_LOAD' -RunId $RunIdDefault))

    $order = 2
    $parts.Add((Embed-Script -Order $order -StepId 'R1' -Label 'Regla 1' -RelPath '02_regla1_unificacion.sql' -RunId $RunIdDefault))
    $order++
    $parts.Add((Embed-Script -Order $order -StepId 'R2_ESC1_2' -Label 'R2 Escenarios 1 y 2' -RelPath '03_regla2_esc1_2.sql' -RunId $RunIdDefault))
    $order++
    $parts.Add((Embed-Script -Order $order -StepId 'R2_ESC4' -Label 'R2 Escenario 4' -RelPath '04_regla2_esc4.sql' -RunId $RunIdDefault))
    $order++
    $parts.Add((Embed-Script -Order $order -StepId 'R2_ESC3_SIN_NIT' -Label 'R2 Esc 3 sin NIT' -RelPath '05_regla2_esc3_sin_nit.sql' -RunId $RunIdDefault))
    $order++

    if ($MotorMode -eq 'demo_fiel') {
        $motorSteps = @(
            @{ id='R2_ESC3_NIT_PREP';  lab='R2 Esc3 NIT preparar'; f='07a_regla2_esc3_nit_prepara.sql' },
            @{ id='R2_ESC3_NIT_MOTOR'; lab='Motor NIT'; f='06_motor_nuevas_direcciones.sql' },
            @{ id='R2_ESC3_NIT_FIN';   lab='R2 Esc3 NIT cerrar'; f='07b_regla2_esc3_nit_finaliza.sql' },
            @{ id='R2_ESC5_PREP';      lab='R2 Esc5 preparar'; f='08a_regla2_esc5_prepara.sql' },
            @{ id='R2_ESC5_MOTOR';     lab='Motor Esc5'; f='06_motor_nuevas_direcciones.sql' },
            @{ id='R2_ESC5_FIN';       lab='R2 Esc5 cerrar'; f='08b_regla2_esc5_finaliza.sql' },
            @{ id='R2_ESC6_PREP';      lab='R2 Esc6 preparar'; f='09a_regla2_esc6_prepara.sql' },
            @{ id='R2_ESC6_MOTOR';     lab='Motor Esc6'; f='06_motor_nuevas_direcciones.sql' },
            @{ id='R2_ESC6_FIN';       lab='R2 Esc6 cerrar'; f='09b_regla2_esc6_finaliza.sql' }
        )
        foreach ($s in $motorSteps) {
            $parts.Add((Embed-Script -Order $order -StepId $s.id -Label $s.lab -RelPath $s.f -RunId $RunIdDefault))
            $order++
        }
    } else {
        $parts.Add((Embed-Fragment -Order $order -StepId 'R2_MOTOR_BATCH_PREP' -Label 'Motor batch prep unificado' -FragName 'inc_batch_motor_prep.sql' -RunId $RunIdDefault))
        $order++
        $parts.Add((Embed-Script -Order $order -StepId 'R2_MOTOR_BATCH_RUN' -Label 'Motor batch ejecucion unica' -RelPath '06_motor_nuevas_direcciones.sql' -RunId $RunIdDefault))
        $order++
        $parts.Add((Embed-Fragment -Order $order -StepId 'R2_MOTOR_BATCH_FIN' -Label 'Motor batch finalize' -FragName 'inc_batch_motor_finalize.sql' -RunId $RunIdDefault))
        $order++
    }

    $parts.Add((Embed-Script -Order $order -StepId 'R3' -Label 'Regla 3' -RelPath '10_regla3_geo.sql' -RunId $RunIdDefault))
    $order++

    $parts.Add("-- HITO $order : VALIDATION`n")
    $parts.Add((Write-TimingStart -Order $order -StepId 'VALIDATION' -Label 'Validacion post-run' -Source 'inc_validation.sql' -RunId $RunIdDefault))
    $parts.Add((Get-Content (Join-Path $Bmk 'inc_validation.sql') -Raw -Encoding UTF8))
    $parts.Add((Write-TimingEnd -StepId 'VALIDATION' -RunId $RunIdDefault))
    $order++

    $parts.Add(@"

-- ============================================================
-- REPORTE — tiempos por hito
-- ============================================================
SELECT step_order, step_id, label, duration_sec, started_at, ended_at, status, script_source
FROM bdm_stage.perf_timings
WHERE run_id = '$RunIdDefault'
ORDER BY step_order;

SELECT step_id, label, duration_sec
FROM bdm_stage.perf_timings
WHERE run_id = '$RunIdDefault'
ORDER BY step_order;

-- CLEANUP opcional (descomentar):
-- SOURCE: 03_demo_cleanup.sql

"@)

    $outPath = Join-Path $Bmk $OutName
    [System.IO.File]::WriteAllText($outPath, ($parts -join "`n"), [System.Text.UTF8Encoding]::new($false))
    Write-Host "Generado: $outPath ($PersonaCount personas, motor=$MotorMode)"
}

Build-Benchmark -OutName '00_run_benchmark_2k_demo_fiel.sql' -PersonaCount 2000 -RunIdDefault 'benchmark_2k_v1' -MotorMode 'demo_fiel'
Build-Benchmark -OutName '00_run_benchmark_20k_demo_fiel.sql' -PersonaCount 20000 -RunIdDefault 'benchmark_20k_v1' -MotorMode 'demo_fiel'
Build-Benchmark -OutName '00_run_benchmark_20k_batch.sql' -PersonaCount 20000 -RunIdDefault 'benchmark_20k_batch_v1' -MotorMode 'batch'

Write-Host 'Listo.'
