# Benchmark 20K — Unificación de Direcciones

Benchmark de performance end-to-end sobre **20.000 personas** (~40.000 RPU) en Redshift, esquema `bdm_stage`.

## Ejecución (DBeaver)

| Archivo | Descripción |
|---------|-------------|
| [`00_run_benchmark_2k_demo_fiel.sql`](00_run_benchmark_2k_demo_fiel.sql) | **Piloto** — 2.000 personas, motor 3× |
| [`00_run_benchmark_20k_demo_fiel.sql`](00_run_benchmark_20k_demo_fiel.sql) | **Producción** — 20.000 personas, motor 3× (como guion v3) |
| [`00_run_benchmark_20k_batch.sql`](00_run_benchmark_20k_batch.sql) | **Producción** — 20.000 personas, motor 1× (lote) |
| [`00_run_benchmark_20k_batch_edf_stage.sql`](00_run_benchmark_20k_batch_edf_stage.sql) | **QA** — 20.000 personas, motor 1×, esquema `edf_stage` |

1. Conectar DBeaver a Redshift (misma conexión que la demo).
2. Abrir el archivo deseado.
3. (Opcional) Editar `run_id` al inicio del script para distinguir corridas.
4. **Execute SQL Script** (`Alt+Shift+X`) — ejecutar **todo** el archivo.
5. Al final, revisar la pestaña de resultados del `SELECT` sobre `bdm_stage.perf_timings`.

Ver [`RUNBOOK_DBEAVER_BENCHMARK.md`](RUNBOOK_DBEAVER_BENCHMARK.md) para checklist e informe de tiempos.

## Diseño

- [`SDD_BENCHMARK_20K.md`](SDD_BENCHMARK_20K.md) — especificación completa del dataset y pipeline.
- Scripts de reglas **no se mueven** — están embebidos desde la raíz del repo (`../02_*.sql`, etc.).

## Tiempos por hito

Registrados en `bdm_stage.perf_timings`:

| step_id | Hito |
|---------|------|
| DATA_LOAD | Carga 20K + catálogos |
| R1 | Regla 1 |
| R2_ESC1_2 … R2_ESC6_FIN | Regla 2 por escenario |
| R3 | Regla 3 |
| VALIDATION | Conteos post-run |

Modo **batch** reemplaza los hitos motor 3× por `R2_MOTOR_BATCH_PREP`, `R2_MOTOR_BATCH_RUN`, `R2_MOTOR_BATCH_FIN`.

## Mantenimiento

Los archivos `00_run_benchmark_*.sql` se generan con [`build_benchmark.ps1`](build_benchmark.ps1) tras cambiar scripts raíz o fragmentos `inc_*.sql`. No ejecutar `build_benchmark.ps1` en DBeaver.
