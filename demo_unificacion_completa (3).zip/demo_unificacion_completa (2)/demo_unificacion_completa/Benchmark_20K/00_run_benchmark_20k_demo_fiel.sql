-- ============================================================
-- 00_run_benchmark_20k_demo_fiel.sql
-- Benchmark Unificacion â€” 20000 personas (~40000 RPU)
-- Motor: demo_fiel
-- Ejecutar en DBeaver: Execute SQL Script (Alt+Shift+X)
-- ============================================================
-- Editar run_id en perf_timings si repite corrida (buscar 'benchmark_20k_v1')

-- ============================================================
-- perf_timings
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.perf_timings;
CREATE TABLE bdm_stage.perf_timings (
  run_id          VARCHAR(64),
  step_order      INT,
  step_id         VARCHAR(64),
  label           VARCHAR(256),
  script_source   VARCHAR(256),
  started_at      TIMESTAMP,
  ended_at        TIMESTAMP,
  duration_sec    BIGINT,
  status          VARCHAR(16)
);

DELETE FROM bdm_stage.perf_timings WHERE run_id = 'benchmark_20k_v1';

-- HITO 1: DATA_LOAD


-- PERF:BEGIN step=DATA_LOAD order=1
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES ('benchmark_20k_v1', 1, 'DATA_LOAD', 'Carga 20000 personas', 'inc_data_load.sql', GETDATE());

-- ============================================================
-- DATA_LOAD — Benchmark 20000 personas
-- Genera ~20000 personas x 2 RPU = ~40000 filas
-- ============================================================

-- Catálogos (igual que 01_demo_setup.sql)
DROP TABLE IF EXISTS bdm_stage.tipo_ubicacion_dir;
CREATE TABLE bdm_stage.tipo_ubicacion_dir (
  cod_dw_tipo_ubicacion_dir INTEGER ENCODE AZ64,
  descripcion_tipo_ubicacion_dir VARCHAR(20) ENCODE BYTEDICT
) DISTSTYLE ALL;
INSERT INTO bdm_stage.tipo_ubicacion_dir VALUES
(1, 'RES'), (2, 'LAB'), (3, 'CRR'), (4, 'JUD'), (5, 'CCL');

DROP TABLE IF EXISTS bdm_stage.nomenclatura;
CREATE TABLE bdm_stage.nomenclatura (
  nomenclatura VARCHAR(10) ENCODE ZSTD,
  nivel_complemento INTEGER ENCODE AZ64
) DISTSTYLE ALL;
INSERT INTO bdm_stage.nomenclatura VALUES
('BR',1),('UR',1),('CJ',1),('UN',1),
('ED',2),('ZN',2),('SEC',2),
('MZ',3),('ET',3),
('TO',4),('BQ',4),
('PI',5),('CS',5),('IN',5),('BL',5),
('LC',6),('OF',6),('PL',6),
('AP',7),('GJ',7),('DP',7),('ST',7);

DROP TABLE IF EXISTS bdm_stage.ubicacion_estandarizada;
CREATE TABLE bdm_stage.ubicacion_estandarizada (
  cod_dw_ubic BIGINT ENCODE AZ64,
  texto_ubicacion VARCHAR(200) ENCODE ZSTD,
  cod_dw_ciudad INTEGER ENCODE AZ64,
  latitud DECIMAL(10,7),
  longitud DECIMAL(10,7)
) DISTSTYLE KEY DISTKEY(cod_dw_ubic) SORTKEY(cod_dw_ubic);

DROP TABLE IF EXISTS bdm_stage.direccion_fisica;
CREATE TABLE bdm_stage.direccion_fisica (
  cod_dw_direccion_fisica BIGINT ENCODE AZ64,
  complemento VARCHAR(100) ENCODE ZSTD,
  cod_dw_ubic BIGINT ENCODE AZ64,
  tipo_via_principal VARCHAR(5) ENCODE ZSTD,
  via_principal VARCHAR(10) ENCODE ZSTD,
  via_generadora VARCHAR(10) ENCODE ZSTD,
  numero_puerta VARCHAR(10) ENCODE ZSTD,
  generada_enriquecida INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(cod_dw_direccion_fisica) SORTKEY(cod_dw_direccion_fisica);

DROP TABLE IF EXISTS bdm_stage.relacion_persona_ubicacion;
CREATE TABLE bdm_stage.relacion_persona_ubicacion (
  cod_dw_persona_ubic BIGINT ENCODE AZ64,
  id_buro_persona INTEGER ENCODE AZ64,
  cod_pin_persona INTEGER ENCODE AZ64,
  cod_dw_ubic BIGINT ENCODE AZ64,
  cod_dw_direccion_fisica BIGINT ENCODE AZ64,
  cod_dw_tipo_ubicacion_dir INTEGER ENCODE AZ64,
  ind_unificacion INTEGER ENCODE AZ64,
  orden_prioridad INTEGER ENCODE AZ64,
  fecha_relacion_persona_ubicaci DATE ENCODE AZ64,
  lote INTEGER ENCODE AZ64,
  cod_tipo_ident_fte INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(id_buro_persona) SORTKEY(id_buro_persona, cod_dw_persona_ubic);

DROP TABLE IF EXISTS bdm_stage.ciiu_persona;
CREATE TABLE bdm_stage.ciiu_persona (
  id_buro_persona INTEGER ENCODE AZ64,
  cod_act_econo_ciiu_fte VARCHAR(10) ENCODE BYTEDICT
) DISTSTYLE KEY DISTKEY(id_buro_persona);

DROP TABLE IF EXISTS bdm_stage.reporte_relacion_persona_ubica;
CREATE TABLE bdm_stage.reporte_relacion_persona_ubica (
  cod_dw_persona_ubic BIGINT ENCODE AZ64,
  id_buro_suscriptor INTEGER ENCODE AZ64,
  fecha_reporte DATE ENCODE AZ64,
  lote INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic) SORTKEY(cod_dw_persona_ubic);

DROP TABLE IF EXISTS bdm_stage.unificacion_direccion;
CREATE TABLE bdm_stage.unificacion_direccion (
  cod_dw_persona_ubic BIGINT ENCODE AZ64,
  cod_dw_direccion_unificada BIGINT ENCODE AZ64,
  unifica_atributos INTEGER ENCODE AZ64,
  fecha_unificacion DATE ENCODE AZ64,
  lote INTEGER ENCODE AZ64,
  severidad INTEGER ENCODE AZ64,
  usuario_bd VARCHAR(100) ENCODE ZSTD
) DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic) SORTKEY(cod_dw_persona_ubic);

DROP TABLE IF EXISTS bdm_stage.diccionario_complementos;
CREATE TABLE bdm_stage.diccionario_complementos (
  cod_dw_ubic BIGINT ENCODE AZ64,
  id_buro_persona INTEGER ENCODE AZ64,
  nomenclatura VARCHAR(50) ENCODE ZSTD,
  nomen VARCHAR(10) ENCODE ZSTD,
  valor VARCHAR(50) ENCODE ZSTD,
  frecuencia INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(cod_dw_ubic) SORTKEY(cod_dw_ubic, id_buro_persona);

DROP TABLE IF EXISTS bdm_stage.diccionario_via;
CREATE TABLE bdm_stage.diccionario_via (
  tipo VARCHAR(20) ENCODE ZSTD,
  llave VARCHAR(100) ENCODE ZSTD,
  via_generadora VARCHAR(10) ENCODE ZSTD,
  cod_dw_municipio INTEGER ENCODE AZ64,
  conteo INTEGER ENCODE AZ64
) DISTSTYLE ALL;

DROP TABLE IF EXISTS bdm_stage.relacion_ubicac_estandar_geo;
CREATE TABLE bdm_stage.relacion_ubicac_estandar_geo (
  cod_dw_ubic BIGINT ENCODE AZ64,
  latitud DECIMAL(10,7),
  longitud DECIMAL(10,7)
) DISTSTYLE ALL;

DROP TABLE IF EXISTS bdm_stage.bloqueo;
CREATE TABLE bdm_stage.bloqueo (
  id_buro_persona INTEGER ENCODE AZ64
) DISTSTYLE ALL;

-- Secuencia 1..N personas
DROP TABLE IF EXISTS bdm_stage.perf_digit;
CREATE TABLE bdm_stage.perf_digit (d INT) DISTSTYLE ALL;
INSERT INTO bdm_stage.perf_digit
SELECT 0 UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4
UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9;

DROP TABLE IF EXISTS bdm_stage.perf_nums;
CREATE TABLE bdm_stage.perf_nums AS
SELECT persona_seq
FROM (
  SELECT ROW_NUMBER() OVER (ORDER BY d1.d, d2.d, d3.d, d4.d, d5.d) AS persona_seq
  FROM bdm_stage.perf_digit d1
  CROSS JOIN bdm_stage.perf_digit d2
  CROSS JOIN bdm_stage.perf_digit d3
  CROSS JOIN bdm_stage.perf_digit d4
  CROSS JOIN bdm_stage.perf_digit d5
) seq
WHERE persona_seq <= 20000;

-- Plantillas de escenario (patrones del demo 1001-3004)
DROP TABLE IF EXISTS bdm_stage.perf_scenario_seed;
CREATE TABLE bdm_stage.perf_scenario_seed (
  bucket_lo INT,
  bucket_hi INT,
  scenario_code VARCHAR(32),
  ciiu VARCHAR(10),
  tipo_a INT,
  tipo_b INT,
  comp_a VARCHAR(100),
  comp_b VARCHAR(100),
  same_ubic INT,
  tipo_via VARCHAR(5),
  via_base INT,
  gen_a INT,
  gen_b INT,
  puerta_a INT,
  puerta_b INT,
  lat_a DECIMAL(10,7),
  lon_a DECIMAL(10,7),
  lat_b DECIMAL(10,7),
  lon_b DECIMAL(10,7),
  nit_flag INT,
  hijo_a INT,
  rep_a INT,
  rep_b INT,
  needs_dic INT
) DISTSTYLE ALL;

INSERT INTO bdm_stage.perf_scenario_seed VALUES
-- R1 (0-11)
(0,2,'R1_ESC1','10',1,2,'','',1,'CL',45,12,12,'33','33',NULL,NULL,NULL,NULL,1,0,2,5),
(3,4,'R1_ESC2','81',2,1,'','',1,'KR',7,80,80,'22','22',NULL,NULL,NULL,NULL,1,0,1,4),
(5,6,'R1_ESC3','55',1,3,'','',1,'AK',57,63,63,'45','45',NULL,NULL,NULL,NULL,1,0,2,6),
(7,8,'R1_EMPATE','10',2,3,'','',1,'KR',7,80,80,'22','22',NULL,NULL,NULL,NULL,1,0,3,3),
(9,11,'R1_HIJA','82',1,3,'','',1,'AK',57,63,63,'45','45',NULL,NULL,NULL,NULL,1,1,2,3),
-- R2 directa (12-29)
(12,14,'R2_ESC1','10',1,1,'','AP 802',1,'DG',50,30,30,'10','10',NULL,NULL,NULL,NULL,1,0,2,3),
(15,17,'R2_ESC2','10',1,1,'AP 702','ED GALICIA AP 702',1,'TV',20,15,15,'40','40',NULL,NULL,NULL,NULL,1,0,2,4),
(18,20,'R2_ESC3_SIN_NIT','55',1,1,'AP 105','AP 404',1,'CL',22,27,27,'45','45',NULL,NULL,NULL,NULL,1,0,2,6),
(21,23,'R2_ESC4','10',1,1,'CS 5','PI 5',1,'CL',80,55,55,'18','18',NULL,NULL,NULL,NULL,1,0,3,2),
(24,29,'R2_EMPATE','10',1,1,'CS 8','PI 8',1,'CL',95,18,18,'42','42',NULL,NULL,NULL,NULL,1,0,2,2),
-- R2 motor (30-39)
(30,32,'R2_ESC3_NIT','10',1,1,'LC 101','LC 205',1,'KR',10,20,20,'30','30',NULL,NULL,NULL,NULL,3,0,3,3),
(33,36,'R2_ESC5_MOTOR','10',1,1,'TO 3','AP 504',1,'KR',30,45,45,'12','12',NULL,NULL,NULL,NULL,1,0,2,3),
(37,39,'R2_ESC6_MOTOR','10',1,1,'ED 2 OF 301','OF 302',1,'DG',70,25,25,'88','88',NULL,NULL,NULL,NULL,1,0,3,2),
-- R2 diccionario (40-47)
(40,42,'R2_ESC4_DIC','10',1,1,'CS 5','PI 5',1,'CL',80,55,55,'18','18',NULL,NULL,NULL,NULL,1,0,3,2),
(43,44,'R2_ESC5_DIC','10',1,1,'TO 5','PI 5',1,'CL',91,12,12,'34','34',NULL,NULL,NULL,NULL,1,0,3,2),
(45,47,'R2_ESC6_DIC','10',1,1,'LC 10 OF 200','OF 200',1,'KR',55,33,33,'22','22',NULL,NULL,NULL,NULL,1,0,4,2),
-- R3 (48-59)
(48,50,'R3_GEO','10',1,1,'','',0,'CL',34,78,80,'52','52',4.6097100,-74.0817500,NULL,NULL,1,0,3,2),
(51,53,'R3_FECHA','10',1,1,'','',0,'KR',15,45,45,'33','35',NULL,NULL,NULL,NULL,1,0,2,4),
(54,56,'R3_DICC_VIA','10',1,1,'','',0,'TV',60,20,22,'44','44',4.6200000,-74.0900000,4.6201000,-74.0901000,1,0,3,8),
(57,59,'R3_FUERA','10',1,1,'','',0,'DG',90,10,10,'50','55',NULL,NULL,NULL,NULL,1,0,2,3),
-- Control (60-99) — calles distintas por dirección
(60,99,'CONTROL','10',1,1,'','',0,'CL',100,10,20,'30','40',NULL,NULL,NULL,NULL,1,0,1,1);

DROP TABLE IF EXISTS bdm_stage.perf_persona;
CREATE TABLE bdm_stage.perf_persona AS
SELECT
  n.persona_seq,
  100000 + n.persona_seq AS id_buro_persona,
  (n.persona_seq % 100) AS bucket,
  s.scenario_code,
  s.ciiu,
  s.tipo_a,
  s.tipo_b,
  s.comp_a,
  s.comp_b,
  s.same_ubic,
  s.tipo_via,
  s.via_base + (n.persona_seq % 500) AS via_num,
  s.gen_a,
  s.gen_b,
  s.puerta_a,
  s.puerta_b,
  s.lat_a,
  s.lon_a,
  s.lat_b,
  s.lon_b,
  s.nit_flag,
  s.hijo_a,
  s.rep_a,
  s.rep_b,
  s.needs_dic
FROM bdm_stage.perf_nums n
JOIN bdm_stage.perf_scenario_seed s
  ON (n.persona_seq % 100) BETWEEN s.bucket_lo AND s.bucket_hi;

-- Ubicaciones (2 por persona)
INSERT INTO bdm_stage.ubicacion_estandarizada (cod_dw_ubic, texto_ubicacion, cod_dw_ciudad, latitud, longitud)
SELECT
  p.id_buro_persona * 1000 + 1,
  CASE
    WHEN p.scenario_code = 'CONTROL' THEN
      p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR) || ' ' || CAST(p.gen_a AS VARCHAR) || ' ' || CAST(p.puerta_a AS VARCHAR)
    WHEN p.same_ubic = 1 THEN
      p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR) || ' ' || CAST(p.gen_a AS VARCHAR) || ' ' || CAST(p.puerta_a AS VARCHAR)
    ELSE
      p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR) || ' ' || CAST(p.gen_a AS VARCHAR) || ' ' || CAST(p.puerta_a AS VARCHAR)
  END,
  1,
  p.lat_a,
  p.lon_a
FROM bdm_stage.perf_persona p;

INSERT INTO bdm_stage.ubicacion_estandarizada (cod_dw_ubic, texto_ubicacion, cod_dw_ciudad, latitud, longitud)
SELECT
  p.id_buro_persona * 1000 + 2,
  CASE
    WHEN p.scenario_code = 'CONTROL' THEN
      p.tipo_via || ' ' || CAST(p.via_num + 50 AS VARCHAR) || ' ' || CAST(p.gen_b AS VARCHAR) || ' ' || CAST(p.puerta_b AS VARCHAR)
    WHEN p.same_ubic = 1 THEN
      p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR) || ' ' || CAST(p.gen_a AS VARCHAR) || ' ' || CAST(p.puerta_a AS VARCHAR)
    WHEN p.scenario_code IN ('R3_GEO','R3_FECHA','R3_DICC_VIA','R3_FUERA') THEN
      p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR) || ' ' || CAST(p.gen_b AS VARCHAR) || ' ' || CAST(p.puerta_b AS VARCHAR)
    ELSE
      p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR) || ' ' || CAST(p.gen_a AS VARCHAR) || ' ' || CAST(p.puerta_a AS VARCHAR)
  END,
  1,
  p.lat_b,
  p.lon_b
FROM bdm_stage.perf_persona p;

-- Direcciones físicas
INSERT INTO bdm_stage.direccion_fisica
SELECT p.id_buro_persona * 1000 + 101, p.comp_a,
  CASE WHEN p.same_ubic = 1 THEN p.id_buro_persona * 1000 + 1 ELSE p.id_buro_persona * 1000 + 1 END,
  p.tipo_via, CAST(p.via_num AS VARCHAR), CAST(p.gen_a AS VARCHAR), CAST(p.puerta_a AS VARCHAR), NULL
FROM bdm_stage.perf_persona p;

INSERT INTO bdm_stage.direccion_fisica
SELECT p.id_buro_persona * 1000 + 102, p.comp_b,
  CASE WHEN p.same_ubic = 1 THEN p.id_buro_persona * 1000 + 1 ELSE p.id_buro_persona * 1000 + 2 END,
  p.tipo_via,
  CAST(CASE WHEN p.scenario_code = 'CONTROL' THEN p.via_num + 50 ELSE p.via_num END AS VARCHAR),
  CAST(CASE WHEN p.same_ubic = 1 THEN p.gen_a ELSE p.gen_b END AS VARCHAR),
  CAST(CASE WHEN p.same_ubic = 1 THEN p.puerta_a ELSE p.puerta_b END AS VARCHAR),
  NULL
FROM bdm_stage.perf_persona p;

-- CIIU
INSERT INTO bdm_stage.ciiu_persona
SELECT id_buro_persona, ciiu FROM bdm_stage.perf_persona;

-- RPU fila A
INSERT INTO bdm_stage.relacion_persona_ubicacion
SELECT
  p.id_buro_persona * 1000 + 1,
  p.id_buro_persona,
  900000 + p.persona_seq,
  CASE WHEN p.same_ubic = 1 THEN p.id_buro_persona * 1000 + 1 ELSE p.id_buro_persona * 1000 + 1 END,
  p.id_buro_persona * 1000 + 101,
  p.tipo_a,
  CASE WHEN p.hijo_a = 1 THEN 1 ELSE NULL END,
  NULL,
  DATEADD(day, -(p.persona_seq % 30), DATE '2025-06-01'),
  1,
  p.nit_flag
FROM bdm_stage.perf_persona p;

-- RPU fila B
INSERT INTO bdm_stage.relacion_persona_ubicacion
SELECT
  p.id_buro_persona * 1000 + 2,
  p.id_buro_persona,
  900000 + p.persona_seq,
  CASE WHEN p.same_ubic = 1 THEN p.id_buro_persona * 1000 + 1 ELSE p.id_buro_persona * 1000 + 2 END,
  p.id_buro_persona * 1000 + 102,
  p.tipo_b,
  NULL,
  NULL,
  DATEADD(day, p.persona_seq % 60, DATE '2025-03-01'),
  1,
  p.nit_flag
FROM bdm_stage.perf_persona p;

-- Reportes (simplificado: rep_a entidades en A, rep_b en B)
INSERT INTO bdm_stage.reporte_relacion_persona_ubica
SELECT p.id_buro_persona * 1000 + 1, 900 + (s.n % 20), DATE '2025-05-01', 1
FROM bdm_stage.perf_persona p
CROSS JOIN (SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8) s
WHERE s.n <= p.rep_a;

INSERT INTO bdm_stage.reporte_relacion_persona_ubica
SELECT p.id_buro_persona * 1000 + 2, 900 + (s.n % 20), DATE '2025-06-01', 1
FROM bdm_stage.perf_persona p
CROSS JOIN (SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8) s
WHERE s.n <= p.rep_b;

-- R3_DICC_VIA: más reportes en A que B
INSERT INTO bdm_stage.reporte_relacion_persona_ubica
SELECT p.id_buro_persona * 1000 + 1, 910 + s.n, DATE '2025-05-01', 1
FROM bdm_stage.perf_persona p
CROSS JOIN (SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3) s
WHERE p.scenario_code = 'R3_DICC_VIA';

-- Diccionario complementos (personas que lo requieren)
INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, 'CS 5', 'CS', '5', 10
FROM bdm_stage.perf_persona p WHERE p.scenario_code IN ('R2_ESC4','R2_ESC4_DIC');
INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, 'PI 5', 'PI', '5', 4
FROM bdm_stage.perf_persona p WHERE p.scenario_code IN ('R2_ESC4','R2_ESC4_DIC');

INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, p.comp_a, 'LC', '101', 8
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC3_NIT';
INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, p.comp_b, 'LC', '205', 4
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC3_NIT';

INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, p.comp_a, 'TO', '3', 8
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC5_MOTOR';
INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, p.comp_b, 'AP', '504', 4
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC5_MOTOR';

INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, 'ED 2 OF 301', 'ED', '2', 6
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC6_MOTOR';
INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, 'ED 2 OF 301', 'OF', '301', 4
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC6_MOTOR';
INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, p.comp_b, 'OF', '302', 4
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC6_MOTOR';

INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, p.comp_a, 'TO', '5', 15
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC5_DIC';
INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, p.comp_b, 'PI', '5', 6
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC5_DIC';

INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, 'LC', 'LC', '10', 20
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC6_DIC';
INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, 'OF', 'OF', '200', 8
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC6_DIC';

INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, p.comp_a, 'CS', '8', 10
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_EMPATE';
INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, p.comp_b, 'PI', '8', 10
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_EMPATE';

-- Metadata escenario por persona (validación)
DROP TABLE IF EXISTS bdm_stage.perf_persona_meta;
CREATE TABLE bdm_stage.perf_persona_meta AS
SELECT id_buro_persona, persona_seq, scenario_code FROM bdm_stage.perf_persona;

-- Diccionario vía seed R3
INSERT INTO bdm_stage.diccionario_via
SELECT 'Via_Generadora',
  p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR) || ' ' || CAST(p.puerta_a AS VARCHAR),
  CAST(p.gen_a AS VARCHAR), 1, 15
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R3_DICC_VIA';
INSERT INTO bdm_stage.diccionario_via
SELECT 'Via_Generadora',
  p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR) || ' ' || CAST(p.puerta_a AS VARCHAR),
  CAST(p.gen_b AS VARCHAR), 1, 8
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R3_DICC_VIA';

ANALYZE bdm_stage.relacion_persona_ubicacion;
ANALYZE bdm_stage.ubicacion_estandarizada;
ANALYZE bdm_stage.direccion_fisica;
ANALYZE bdm_stage.ciiu_persona;
ANALYZE bdm_stage.reporte_relacion_persona_ubica;
ANALYZE bdm_stage.diccionario_complementos;

-- Verificación post-carga
SELECT 'CHECK personas' AS chk, COUNT(DISTINCT id_buro_persona) AS cnt FROM bdm_stage.relacion_persona_ubicacion;
SELECT 'CHECK rpu' AS chk, COUNT(*) AS cnt FROM bdm_stage.relacion_persona_ubicacion;
SELECT scenario_code, COUNT(*) AS personas FROM bdm_stage.perf_persona_meta GROUP BY 1 ORDER BY 1;

DROP TABLE IF EXISTS bdm_stage.perf_digit;
DROP TABLE IF EXISTS bdm_stage.perf_nums;


UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = 'benchmark_20k_v1' AND step_id = 'DATA_LOAD' AND ended_at IS NULL;
-- PERF:END step=DATA_LOAD

-- ============================================================
-- HITO 2 : Regla 1
-- SOURCE: 02_regla1_unificacion.sql
-- ============================================================

-- PERF:BEGIN step=R1 order=2
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES ('benchmark_20k_v1', 2, 'R1', 'Regla 1', '02_regla1_unificacion.sql', GETDATE());

/* === INICIO 02_regla1_unificacion.sql === */
-- PASO 1: Materializar insumo en bdm_stage (staging volátil)
DROP TABLE IF EXISTS bdm_stage.stg_regla1_insumo;
CREATE TABLE bdm_stage.stg_regla1_insumo
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, texto_ubicacion)
AS
SELECT
  rpu.cod_dw_persona_ubic,
  rpu.id_buro_persona,
  ubi.texto_ubicacion,
  df.complemento,
  ubi.cod_dw_ciudad,
  rpu.cod_dw_tipo_ubicacion_dir,
  COALESCE(ciiu.cod_act_econo_ciiu_fte, '') AS cod_act_econo_ciiu_fte,
  COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor), 0) AS numero_entidades_reportan,
  tud.descripcion_tipo_ubicacion_dir AS tipo_direccion
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi
  ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df
  ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
JOIN bdm_stage.reporte_relacion_persona_ubica rep
  ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
LEFT JOIN bdm_stage.ciiu_persona ciiu
  ON rpu.id_buro_persona = ciiu.id_buro_persona
LEFT JOIN bdm_stage.tipo_ubicacion_dir tud
  ON rpu.cod_dw_tipo_ubicacion_dir = tud.cod_dw_tipo_ubicacion_dir
WHERE rpu.ind_unificacion IS NULL
GROUP BY 1,2,3,4,5,6,7,9;

ANALYZE bdm_stage.stg_regla1_insumo;

-- PASO 2: Calcular score y ranking por escenario
DROP TABLE IF EXISTS bdm_stage.stg_regla1_scored;
CREATE TABLE bdm_stage.stg_regla1_scored
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, texto_ubicacion)
AS
SELECT *,
  CASE
    WHEN cod_act_econo_ciiu_fte = '10' THEN 'ESC1'
    WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN 'ESC2'
    ELSE 'ESC3'
  END AS escenario,

  CASE
    WHEN cod_act_econo_ciiu_fte = '10' THEN
      CASE WHEN tipo_direccion IN ('LAB','CRR') THEN 100000 ELSE 0 END
      + numero_entidades_reportan
    WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN
      CASE WHEN tipo_direccion IN ('RES','CRR') THEN 100000 ELSE 0 END
      + numero_entidades_reportan
    ELSE
      numero_entidades_reportan
  END AS score,

  ROW_NUMBER() OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_ciudad,
      CASE
        WHEN cod_act_econo_ciiu_fte = '10' THEN 'ESC1'
        WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN 'ESC2'
        ELSE 'ESC3'
      END
    ORDER BY
      CASE
        WHEN cod_act_econo_ciiu_fte = '10' THEN
          CASE WHEN tipo_direccion IN ('LAB','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan
        WHEN cod_act_econo_ciiu_fte IN ('81','82','90') THEN
          CASE WHEN tipo_direccion IN ('RES','CRR') THEN 100000 ELSE 0 END + numero_entidades_reportan
        ELSE numero_entidades_reportan
      END DESC
  ) AS orden
FROM bdm_stage.stg_regla1_insumo;

ANALYZE bdm_stage.stg_regla1_scored;

-- PASO 3: Generar pares padre-hijo
DROP TABLE IF EXISTS bdm_stage.stg_regla1_pares;
CREATE TABLE bdm_stage.stg_regla1_pares
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT
  hijo.cod_dw_persona_ubic        AS cod_dw_persona_ubic,
  padre.cod_dw_persona_ubic       AS cod_dw_direccion_unificada
FROM bdm_stage.stg_regla1_scored padre
JOIN bdm_stage.stg_regla1_scored hijo
  ON padre.id_buro_persona = hijo.id_buro_persona
 AND padre.texto_ubicacion = hijo.texto_ubicacion
 AND padre.cod_dw_ciudad = hijo.cod_dw_ciudad
 AND padre.escenario = hijo.escenario
 AND padre.score > hijo.score
 AND padre.cod_dw_tipo_ubicacion_dir <> hijo.cod_dw_tipo_ubicacion_dir
WHERE padre.orden = 1;

-- PASO 4: Persistir resultado
INSERT INTO bdm_stage.unificacion_direccion
SELECT
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  1 AS unifica_atributos,
  CURRENT_DATE AS fecha_unificacion,
  1 AS lote,
  1 AS severidad,
  CURRENT_USER AS usuario_bd
FROM bdm_stage.stg_regla1_pares;

-- PASO 5: Marcar hijos como unificados
UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla1_pares
);

-- PASO 6: Actualizar estadísticas de tablas modificadas
ANALYZE bdm_stage.unificacion_direccion;
ANALYZE bdm_stage.relacion_persona_ubicacion;

-- PASO 7: Limpiar staging (bdm_stage es volátil)
DROP TABLE IF EXISTS bdm_stage.stg_regla1_insumo;
DROP TABLE IF EXISTS bdm_stage.stg_regla1_scored;
DROP TABLE IF EXISTS bdm_stage.stg_regla1_pares;
/* === FIN 02_regla1_unificacion.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = 'benchmark_20k_v1' AND step_id = 'R1' AND ended_at IS NULL;
-- PERF:END step=R1


-- ============================================================
-- HITO 3 : R2 Escenarios 1 y 2
-- SOURCE: 03_regla2_esc1_2.sql
-- ============================================================

-- PERF:BEGIN step=R2_ESC1_2 order=3
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES ('benchmark_20k_v1', 3, 'R2_ESC1_2', 'R2 Escenarios 1 y 2', '03_regla2_esc1_2.sql', GETDATE());

/* === INICIO 03_regla2_esc1_2.sql === */
-- PASO 1: Materializar insumo de Regla 2
-- Solo registros NO unificados por Regla 1 (ind_unificacion IS NULL)
DROP TABLE IF EXISTS bdm_stage.stg_regla2_insumo;
CREATE TABLE bdm_stage.stg_regla2_insumo
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, texto_ubicacion)
AS
SELECT
  rpu.cod_dw_persona_ubic,
  rpu.cod_pin_persona,
  rpu.id_buro_persona,
  rpu.cod_dw_tipo_ubicacion_dir,
  rpu.cod_dw_ubic,
  ubi.texto_ubicacion,
  rpu.cod_dw_direccion_fisica,
  df.complemento,
  rpu.cod_dw_tipo_ubicacion_dir AS cod_dw_municipio,  -- TODO: confirmar campo municipio real
  COALESCE(COUNT(DISTINCT rep.id_buro_suscriptor), 0) AS numero_entidades_reportan,
  rpu.fecha_relacion_persona_ubicaci
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi
  ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df
  ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
JOIN bdm_stage.reporte_relacion_persona_ubica rep
  ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
WHERE rpu.ind_unificacion IS NULL
GROUP BY 1,2,3,4,5,6,7,8,9,11;

ANALYZE bdm_stage.stg_regla2_insumo;

-- PASO 2: Escenario 1 — Un complemento vacío, otro no
-- A tiene complemento, B no → B es hijo de A
-- A no tiene complemento, B sí → A es hijo de B
DROP TABLE IF EXISTS bdm_stage.stg_regla2_esc1_pares;
CREATE TABLE bdm_stage.stg_regla2_esc1_pares
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT cod_dw_persona_ubic, id_padre
FROM (
  -- Caso 1: B no tiene complemento → B es hijo, A es padre
  SELECT
    b.cod_dw_persona_ubic,
    a.cod_dw_persona_ubic AS id_padre,
    ROW_NUMBER() OVER (PARTITION BY b.cod_dw_persona_ubic ORDER BY a.cod_dw_persona_ubic DESC) AS rn
  FROM bdm_stage.stg_regla2_insumo a
  JOIN bdm_stage.stg_regla2_insumo b
    ON  a.id_buro_persona           = b.id_buro_persona
    AND a.texto_ubicacion            = b.texto_ubicacion
    AND a.cod_dw_tipo_ubicacion_dir  = b.cod_dw_tipo_ubicacion_dir
    AND a.cod_dw_municipio           = b.cod_dw_municipio
    AND a.cod_dw_persona_ubic       <> b.cod_dw_persona_ubic
  WHERE a.complemento IS NOT NULL
    AND b.complemento IS NULL

  UNION ALL

  -- Caso 2: A no tiene complemento → A es hijo, B es padre
  SELECT
    a.cod_dw_persona_ubic,
    b.cod_dw_persona_ubic AS id_padre,
    ROW_NUMBER() OVER (PARTITION BY a.cod_dw_persona_ubic ORDER BY b.cod_dw_persona_ubic DESC) AS rn
  FROM bdm_stage.stg_regla2_insumo a
  JOIN bdm_stage.stg_regla2_insumo b
    ON  a.id_buro_persona           = b.id_buro_persona
    AND a.texto_ubicacion            = b.texto_ubicacion
    AND a.cod_dw_tipo_ubicacion_dir  = b.cod_dw_tipo_ubicacion_dir
    AND a.cod_dw_municipio           = b.cod_dw_municipio
    AND a.cod_dw_persona_ubic       <> b.cod_dw_persona_ubic
  WHERE b.complemento IS NOT NULL
    AND a.complemento IS NULL
)
WHERE rn = 1;

ANALYZE bdm_stage.stg_regla2_esc1_pares;

-- PASO 3: Construir tabla intermedia E1 con marca de unificación
-- Hereda todos los registros del insumo, marcando hijos del Esc 1
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e1;
CREATE TABLE bdm_stage.stg_regla2_e1
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, texto_ubicacion)
AS
SELECT
  a.cod_dw_persona_ubic,
  b.id_padre,
  a.id_buro_persona,
  a.cod_dw_tipo_ubicacion_dir,
  a.cod_dw_ubic,
  a.texto_ubicacion,
  a.cod_dw_direccion_fisica,
  a.complemento,
  a.cod_dw_municipio,
  a.numero_entidades_reportan,
  a.fecha_relacion_persona_ubicaci,
  CASE WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S' ELSE 'N' END AS ind_unificacion,
  CASE WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'H1' END AS n_id,
  ROW_NUMBER() OVER (
    PARTITION BY a.id_buro_persona, a.cod_dw_ubic,
      CASE WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S' ELSE 'N' END,
      a.cod_dw_tipo_ubicacion_dir
    ORDER BY a.complemento
  ) AS row_u
FROM bdm_stage.stg_regla2_insumo a
LEFT JOIN bdm_stage.stg_regla2_esc1_pares b
  ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic;

ANALYZE bdm_stage.stg_regla2_e1;

-- PASO 4: Escenario 2 — Un complemento incluido en otro
-- Solo procesa registros con ind_unificacion='N' (no unificados por Esc 1)
-- A.COMPLEMENTO contiene B.COMPLEMENTO → B es hijo de A
DROP TABLE IF EXISTS bdm_stage.stg_regla2_esc2_pares;
CREATE TABLE bdm_stage.stg_regla2_esc2_pares
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT cod_dw_persona_ubic, id_padre
FROM (
  -- Caso 1: B contenido en A → B es hijo
  SELECT
    b.cod_dw_persona_ubic,
    a.cod_dw_persona_ubic AS id_padre,
    ROW_NUMBER() OVER (PARTITION BY b.cod_dw_persona_ubic ORDER BY b.cod_dw_persona_ubic DESC) AS rn
  FROM bdm_stage.stg_regla2_e1 a
  JOIN bdm_stage.stg_regla2_e1 b
    ON  a.id_buro_persona           = b.id_buro_persona
    AND a.texto_ubicacion            = b.texto_ubicacion
    AND a.cod_dw_tipo_ubicacion_dir  = b.cod_dw_tipo_ubicacion_dir
    AND a.cod_dw_municipio           = b.cod_dw_municipio
    AND a.cod_dw_persona_ubic       <> b.cod_dw_persona_ubic
    AND a.complemento               <> b.complemento
  WHERE a.complemento LIKE '%' || b.complemento || '%'
    AND a.ind_unificacion = 'N'

  UNION ALL

  -- Caso 2: A contenido en B → A es hijo
  SELECT
    a.cod_dw_persona_ubic,
    b.cod_dw_persona_ubic AS id_padre,
    ROW_NUMBER() OVER (PARTITION BY a.cod_dw_persona_ubic ORDER BY a.cod_dw_persona_ubic DESC) AS rn
  FROM bdm_stage.stg_regla2_e1 a
  JOIN bdm_stage.stg_regla2_e1 b
    ON  a.id_buro_persona           = b.id_buro_persona
    AND a.texto_ubicacion            = b.texto_ubicacion
    AND a.cod_dw_tipo_ubicacion_dir  = b.cod_dw_tipo_ubicacion_dir
    AND a.cod_dw_municipio           = b.cod_dw_municipio
    AND a.cod_dw_persona_ubic       <> b.cod_dw_persona_ubic
    AND a.complemento               <> b.complemento
  WHERE b.complemento LIKE '%' || a.complemento || '%'
    AND a.ind_unificacion = 'N'
)
WHERE rn = 1;

ANALYZE bdm_stage.stg_regla2_esc2_pares;

-- PASO 5: Construir tabla E2 acumulada (hereda Esc 1 + agrega Esc 2)
-- Esta tabla será input para escenarios 3-6 en el siguiente script
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e2;
CREATE TABLE bdm_stage.stg_regla2_e2
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, texto_ubicacion)
AS
SELECT
  a.cod_dw_persona_ubic,
  CASE WHEN a.id_padre IS NOT NULL THEN a.id_padre ELSE b.id_padre END AS id_padre,
  a.id_buro_persona,
  a.cod_dw_tipo_ubicacion_dir,
  a.cod_dw_ubic,
  a.texto_ubicacion,
  a.cod_dw_direccion_fisica,
  a.complemento,
  a.cod_dw_municipio,
  a.numero_entidades_reportan,
  a.fecha_relacion_persona_ubicaci,
  CASE
    WHEN a.ind_unificacion = 'S' THEN 'S'
    WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S'
    ELSE 'N'
  END AS ind_unificacion,
  CASE
    WHEN a.n_id IS NOT NULL THEN a.n_id
    WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'K2'
  END AS n_id,
  ROW_NUMBER() OVER (
    PARTITION BY a.id_buro_persona, a.cod_dw_ubic,
      CASE
        WHEN a.ind_unificacion = 'S' THEN 'S'
        WHEN b.cod_dw_persona_ubic IS NOT NULL THEN 'S'
        ELSE 'N'
      END,
      a.cod_dw_tipo_ubicacion_dir
    ORDER BY a.complemento
  ) AS row_u
FROM bdm_stage.stg_regla2_e1 a
LEFT JOIN bdm_stage.stg_regla2_esc2_pares b
  ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic;

ANALYZE bdm_stage.stg_regla2_e2;

-- PASO 6: Persistir pares padre-hijo de Esc 1 y 2 en tabla de unificación
INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT
  e.cod_dw_persona_ubic,
  e.id_padre AS cod_dw_direccion_unificada,
  2 AS unifica_atributos,
  CURRENT_DATE AS fecha_unificacion,
  1 AS lote,
  1 AS severidad,
  LEFT(CURRENT_USER, 30) AS usuario_bd
FROM bdm_stage.stg_regla2_e2 e
WHERE e.ind_unificacion = 'S'
  AND e.id_padre IS NOT NULL;

-- PASO 7: Marcar hijos en relacion_persona_ubicacion
UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic
  FROM bdm_stage.stg_regla2_e2
  WHERE ind_unificacion = 'S'
    AND id_padre IS NOT NULL
);

-- PASO 8: Actualizar estadísticas
ANALYZE bdm_stage.unificacion_direccion;
ANALYZE bdm_stage.relacion_persona_ubicacion;

-- PASO 9: Limpiar staging de escenarios 1-2
-- NOTA: stg_regla2_e2 se mantiene como input para escenarios 3-6
DROP TABLE IF EXISTS bdm_stage.stg_regla2_insumo;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_esc1_pares;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e1;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_esc2_pares;
/* === FIN 03_regla2_esc1_2.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = 'benchmark_20k_v1' AND step_id = 'R2_ESC1_2' AND ended_at IS NULL;
-- PERF:END step=R2_ESC1_2


-- ============================================================
-- HITO 4 : R2 Escenario 4
-- SOURCE: 04_regla2_esc4.sql
-- ============================================================

-- PERF:BEGIN step=R2_ESC4 order=4
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES ('benchmark_20k_v1', 4, 'R2_ESC4', 'R2 Escenario 4', '04_regla2_esc4.sql', GETDATE());

/* === INICIO 04_regla2_esc4.sql === */
-- PASO 1: Filtrar no-unificados con complemento diferente
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04;
CREATE TABLE bdm_stage.stg_regla2_e04
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT A.*
FROM (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') A
JOIN (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.complemento              <> B.complemento;

ANALYZE bdm_stage.stg_regla2_e04;

-- PASO 2: Identificar nomenclaturas de cada complemento
-- NMC1 = nomenclatura al inicio del complemento (ej: "CS" de "CS 312")
-- NMC2 = nomenclatura secundaria en medio del complemento (si existe)
-- COMPLEMENTO2 = complemento sin las nomenclaturas (solo valores numéricos)
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_a;
CREATE TABLE bdm_stage.stg_regla2_e04_a
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT
  A.*,
  NMC1.nomenclatura AS nomenclatura_pri,
  NMC1.nivel_complemento AS nivel_pri,
  NMC2.nomenclatura AS nomenclatura_sec,
  NMC2.nivel_complemento AS nivel_sec,
  TRIM(REPLACE(REPLACE(A.complemento, COALESCE(NMC1.nomenclatura,''), ''), COALESCE(NMC2.nomenclatura,''), '')) AS complemento2
FROM bdm_stage.stg_regla2_e04 A
LEFT JOIN bdm_stage.nomenclatura NMC1
  ON A.complemento LIKE TRIM(NMC1.nomenclatura) || ' %'
LEFT JOIN bdm_stage.nomenclatura NMC2
  ON A.complemento LIKE '% ' || TRIM(NMC2.nomenclatura) || ' %'
  AND NMC2.nomenclatura <> COALESCE(NMC1.nomenclatura, '');

ANALYZE bdm_stage.stg_regla2_e04_a;

-- PASO 3: Filtrar pares donde nomenclaturas están al mismo nivel
-- Caso 1: misma nomenclatura primaria, diferente secundaria, mismo nivel secundario
-- Caso 2: diferente nomenclatura primaria, misma secundaria, mismo nivel primario
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_c;
CREATE TABLE bdm_stage.stg_regla2_e04_c
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT * FROM (
  -- Caso 1: misma nomenclatura primaria, ≠ secundaria, mismo nivel secundario
  SELECT A.*
  FROM bdm_stage.stg_regla2_e04_a A
  JOIN bdm_stage.stg_regla2_e04_a B
    ON  A.id_buro_persona          = B.id_buro_persona
    AND A.texto_ubicacion           = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
    AND A.cod_dw_municipio          = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
    AND A.complemento              <> B.complemento
    AND (A.complemento2 LIKE '%' || B.complemento2 || '%'
         OR B.complemento2 LIKE '%' || A.complemento2 || '%')
    AND A.nomenclatura_pri = B.nomenclatura_pri
    AND COALESCE(A.nomenclatura_sec, 'X') <> COALESCE(B.nomenclatura_sec, 'X')
    AND COALESCE(A.nivel_sec, 0) = COALESCE(B.nivel_sec, 0)

  UNION ALL

  -- Caso 2: ≠ nomenclatura primaria, misma secundaria, mismo nivel primario
  SELECT A.*
  FROM bdm_stage.stg_regla2_e04_a A
  JOIN bdm_stage.stg_regla2_e04_a B
    ON  A.id_buro_persona          = B.id_buro_persona
    AND A.texto_ubicacion           = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
    AND A.cod_dw_municipio          = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
    AND A.complemento              <> B.complemento
    AND (A.complemento2 LIKE '%' || B.complemento2 || '%'
         OR B.complemento2 LIKE '%' || A.complemento2 || '%')
    AND A.nomenclatura_pri <> B.nomenclatura_pri
    AND COALESCE(A.nomenclatura_sec, 'X') = COALESCE(B.nomenclatura_sec, 'X')
    AND A.nivel_pri = B.nivel_pri
) sub;

ANALYZE bdm_stage.stg_regla2_e04_c;

-- PASO 4: Sumar frecuencias del DICCIONARIO_COMPLEMENTOS por persona/ubicación
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_c1;
CREATE TABLE bdm_stage.stg_regla2_e04_c1
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT
  t1.cod_dw_persona_ubic,
  COALESCE(t2.conteo, 0) AS conteo
FROM bdm_stage.stg_regla2_e04_c t1
LEFT JOIN (
  SELECT t1.cod_dw_persona_ubic, SUM(dc.frecuencia) AS conteo
  FROM bdm_stage.stg_regla2_e04_c t1
  LEFT JOIN bdm_stage.diccionario_complementos dc
    ON  t1.cod_dw_ubic = dc.cod_dw_ubic
    AND t1.complemento LIKE '%' || dc.nomenclatura || '%'
    AND t1.id_buro_persona = dc.id_buro_persona
  GROUP BY 1
) t2 ON t1.cod_dw_persona_ubic = t2.cod_dw_persona_ubic;

ANALYZE bdm_stage.stg_regla2_e04_c1;

-- PASO 5: Calcular score y detectar empates
-- Score = (frecuencia_diccionario + 10000000) + fecha_como_entero
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_d;
CREATE TABLE bdm_stage.stg_regla2_e04_d
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  u1.*,
  COUNT(*) OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id
  ) AS count_empate,
  MAX(id) OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio
  ) AS idmax,
  CASE
    WHEN COUNT(*) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id) > 1
         AND MAX(id) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio) > id
    THEN 1
    WHEN COUNT(*) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id) = 1
    THEN 1
    ELSE 0
  END AS empate
FROM (
  SELECT
    a.cod_dw_persona_ubic,
    (COALESCE(b.conteo, 0) + 10000000)
      + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0) AS id,
    a.texto_ubicacion,
    a.fecha_relacion_persona_ubicaci,
    a.numero_entidades_reportan,
    a.id_buro_persona,
    a.cod_dw_tipo_ubicacion_dir,
    a.cod_dw_municipio,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
      ORDER BY (COALESCE(b.conteo, 0) + 10000000)
        + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0)
    ) AS orden,
    a.cod_dw_ubic,
    a.complemento
  FROM bdm_stage.stg_regla2_e04_c a
  LEFT JOIN bdm_stage.stg_regla2_e04_c1 b
    ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
) u1;

ANALYZE bdm_stage.stg_regla2_e04_d;

-- PASO 6: Generar pares padre-hijo (mayor score = padre)
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_e;
CREATE TABLE bdm_stage.stg_regla2_e04_e
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT
  B.cod_dw_persona_ubic,
  A.cod_dw_persona_ubic AS id_padre
FROM bdm_stage.stg_regla2_e04_d A
JOIN bdm_stage.stg_regla2_e04_d B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.id > B.id
JOIN (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio,
         MAX(orden) AS max_orden
  FROM bdm_stage.stg_regla2_e04_d
  GROUP BY 1,2,3,4
) mx
  ON  A.id_buro_persona          = mx.id_buro_persona
  AND A.texto_ubicacion           = mx.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = mx.cod_dw_municipio
  AND A.orden = mx.max_orden;

ANALYZE bdm_stage.stg_regla2_e04_e;

-- PASO 7: Actualizar tabla E2 acumulada con pares del Escenario 4
UPDATE bdm_stage.stg_regla2_e2
SET id_padre = e.id_padre,
    ind_unificacion = 'S',
    n_id = 'B5'
FROM bdm_stage.stg_regla2_e04_e e
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = e.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.id_padre IS NULL;

-- PASO 8: Persistir pares en tabla de unificación
INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT
  e.cod_dw_persona_ubic,
  e.id_padre AS cod_dw_direccion_unificada,
  2 AS unifica_atributos,
  CURRENT_DATE AS fecha_unificacion,
  1 AS lote,
  1 AS severidad,
  LEFT(CURRENT_USER, 30) AS usuario_bd
FROM bdm_stage.stg_regla2_e04_e e;

-- PASO 9: Marcar hijos
UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e04_e
);

-- PASO 10: Estadísticas
ANALYZE bdm_stage.unificacion_direccion;
ANALYZE bdm_stage.relacion_persona_ubicacion;

-- PASO 11: Limpiar staging del escenario 4
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_a;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_c;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_c1;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_d;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e04_e;
/* === FIN 04_regla2_esc4.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = 'benchmark_20k_v1' AND step_id = 'R2_ESC4' AND ended_at IS NULL;
-- PERF:END step=R2_ESC4


-- ============================================================
-- HITO 5 : R2 Esc 3 sin NIT
-- SOURCE: 05_regla2_esc3_sin_nit.sql
-- ============================================================

-- PERF:BEGIN step=R2_ESC3_SIN_NIT order=5
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES ('benchmark_20k_v1', 5, 'R2_ESC3_SIN_NIT', 'R2 Esc 3 sin NIT', '05_regla2_esc3_sin_nit.sql', GETDATE());

/* === INICIO 05_regla2_esc3_sin_nit.sql === */
-- PASO 1: Filtrar no-unificados que NO son NIT
-- En datos mock, Cod_Tipo_Ident_Fte=3 es NIT. Excluimos esos.
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03;
CREATE TABLE bdm_stage.stg_regla2_e03
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT a.*
FROM bdm_stage.stg_regla2_e2 a
WHERE a.ind_unificacion = 'N'
  AND COALESCE(a.cod_dw_tipo_ubicacion_dir, 0) NOT IN (
    SELECT cod_dw_tipo_ubicacion_dir FROM bdm_stage.tipo_ubicacion_dir WHERE 1=0
  )
  -- Filtro NIT: excluir registros con tipo identificación = NIT (cod_tipo_ident_fte = 3)
  -- En Teradata se hace con LEFT JOIN V_Tipo_Identificacion WHERE NOT LIKE '%Nit%'
  -- Aquí usamos el campo cod_tipo_ident_fte directamente del insumo de R2
  -- TODO: cuando exista tabla tipo_identificacion, usar JOIN
;

-- Corrección: el filtro NIT debe venir de relacion_persona_ubicacion.cod_tipo_ident_fte
-- que ya está en stg_regla2_e2 (no se copió). Necesitamos JOINear con RPU.
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03;
CREATE TABLE bdm_stage.stg_regla2_e03
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT a.*
FROM bdm_stage.stg_regla2_e2 a
JOIN bdm_stage.relacion_persona_ubicacion rpu
  ON a.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE a.ind_unificacion = 'N'
  AND COALESCE(rpu.cod_tipo_ident_fte, 0) <> 3;  -- 3 = NIT

ANALYZE bdm_stage.stg_regla2_e03;

-- PASO 2: JOIN por misma nomenclatura, calcular score
-- Score = fecha_como_entero + (entidades + 10000000)
-- Detectar empates
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_a;
CREATE TABLE bdm_stage.stg_regla2_e03_a
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT u1.*,
  COUNT(*) OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, nomenclatura, id
  ) AS count_empate,
  MAX(id) OVER (
    PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, cod_dw_persona_ubic, nomenclatura
  ) AS idmax
FROM (
  SELECT
    a.cod_dw_persona_ubic,
    COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 19000101)
      + (COALESCE(a.numero_entidades_reportan, 0) + 10000000) AS id,
    a.texto_ubicacion,
    a.fecha_relacion_persona_ubicaci,
    nmc1.nomenclatura,
    a.complemento AS complemento1,
    b.complemento AS complemento2,
    a.numero_entidades_reportan,
    a.id_buro_persona,
    a.cod_dw_tipo_ubicacion_dir,
    a.cod_dw_municipio,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio, nmc1.nomenclatura
      ORDER BY COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 19000101)
        + (COALESCE(a.numero_entidades_reportan, 0) + 10000000)
    ) AS orden
  FROM bdm_stage.stg_regla2_e03 a
  JOIN bdm_stage.stg_regla2_e03 b
    ON  a.id_buro_persona          = b.id_buro_persona
    AND a.texto_ubicacion           = b.texto_ubicacion
    AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
    AND a.cod_dw_municipio          = b.cod_dw_municipio
    AND a.cod_dw_persona_ubic      <> b.cod_dw_persona_ubic
    AND a.complemento              <> b.complemento
  JOIN bdm_stage.nomenclatura nmc1
    ON a.complemento LIKE nmc1.nomenclatura || '%'
  JOIN bdm_stage.nomenclatura nmc2
    ON b.complemento LIKE nmc2.nomenclatura || '%'
  WHERE nmc1.nomenclatura = nmc2.nomenclatura
) u1;

ANALYZE bdm_stage.stg_regla2_e03_a;

-- PASO 3: Generar pares padre-hijo (mayor score = padre)
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_e1;
CREATE TABLE bdm_stage.stg_regla2_e03_e1
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT
  b.cod_dw_persona_ubic,
  a.cod_dw_persona_ubic AS id_padre
FROM bdm_stage.stg_regla2_e03_a a
JOIN bdm_stage.stg_regla2_e03_a b
  ON  a.id_buro_persona          = b.id_buro_persona
  AND a.texto_ubicacion           = b.texto_ubicacion
  AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
  AND a.cod_dw_municipio          = b.cod_dw_municipio
  AND a.nomenclatura              = b.nomenclatura
  AND a.cod_dw_persona_ubic      <> b.cod_dw_persona_ubic
  AND a.id > b.id
JOIN (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, nomenclatura,
         MAX(orden) AS max_orden
  FROM bdm_stage.stg_regla2_e03_a
  GROUP BY 1,2,3,4,5
) mx
  ON  a.id_buro_persona          = mx.id_buro_persona
  AND a.texto_ubicacion           = mx.texto_ubicacion
  AND a.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir
  AND a.cod_dw_municipio          = mx.cod_dw_municipio
  AND a.nomenclatura              = mx.nomenclatura
  AND a.orden = mx.max_orden;

ANALYZE bdm_stage.stg_regla2_e03_e1;

-- PASO 4: UPDATE E2 — marcar hijos del Escenario 3 sin NIT
UPDATE bdm_stage.stg_regla2_e2
SET id_padre = stg.id_padre,
    ind_unificacion = 'S',
    n_id = 'L3'
FROM bdm_stage.stg_regla2_e03_e1 stg
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = stg.cod_dw_persona_ubic;

-- PASO 5: Persistir pares en tabla de unificación
INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT
  cod_dw_persona_ubic,
  id_padre AS cod_dw_direccion_unificada,
  2 AS unifica_atributos,
  CURRENT_DATE AS fecha_unificacion,
  1 AS lote,
  1 AS severidad,
  LEFT(CURRENT_USER, 30) AS usuario_bd
FROM bdm_stage.stg_regla2_e03_e1;

-- PASO 6: Marcar hijos
UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e03_e1
);

-- PASO 7: Estadísticas
ANALYZE bdm_stage.unificacion_direccion;
ANALYZE bdm_stage.relacion_persona_ubicacion;
ANALYZE bdm_stage.stg_regla2_e2;

-- PASO 8: Limpiar staging
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_a;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_e1;
/* === FIN 05_regla2_esc3_sin_nit.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = 'benchmark_20k_v1' AND step_id = 'R2_ESC3_SIN_NIT' AND ended_at IS NULL;
-- PERF:END step=R2_ESC3_SIN_NIT


-- ============================================================
-- HITO 6 : R2 Esc3 NIT preparar
-- SOURCE: 07a_regla2_esc3_nit_prepara.sql
-- ============================================================

-- PERF:BEGIN step=R2_ESC3_NIT_PREP order=6
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES ('benchmark_20k_v1', 6, 'R2_ESC3_NIT_PREP', 'R2 Esc3 NIT preparar', '07a_regla2_esc3_nit_prepara.sql', GETDATE());

/* === INICIO 07a_regla2_esc3_nit_prepara.sql === */
-- PASO 1: Filtrar no-unificados que SÍ son NIT
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e031;
CREATE TABLE bdm_stage.stg_regla2_e031
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT a.*
FROM bdm_stage.stg_regla2_e2 a
JOIN bdm_stage.relacion_persona_ubicacion rpu
  ON a.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic
WHERE a.ind_unificacion = 'N'
  AND rpu.cod_tipo_ident_fte = 3;

ANALYZE bdm_stage.stg_regla2_e031;

-- PASO 2: Encontrar pares con misma nomenclatura, diferente valor
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_nit_pares;
CREATE TABLE bdm_stage.stg_regla2_e03_nit_pares
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT a.cod_dw_persona_ubic
FROM bdm_stage.stg_regla2_e031 a
JOIN bdm_stage.stg_regla2_e031 b
  ON  a.id_buro_persona          = b.id_buro_persona
  AND a.texto_ubicacion           = b.texto_ubicacion
  AND a.cod_dw_tipo_ubicacion_dir = b.cod_dw_tipo_ubicacion_dir
  AND a.cod_dw_municipio          = b.cod_dw_municipio
  AND a.cod_dw_persona_ubic      <> b.cod_dw_persona_ubic
  AND a.complemento              <> b.complemento
JOIN bdm_stage.nomenclatura nmc1
  ON a.complemento LIKE nmc1.nomenclatura || '%'
JOIN bdm_stage.nomenclatura nmc2
  ON b.complemento LIKE nmc2.nomenclatura || '%'
WHERE nmc1.nomenclatura = nmc2.nomenclatura;

ANALYZE bdm_stage.stg_regla2_e03_nit_pares;

-- PASO 3: Preparar stg_motor_input
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
CREATE TABLE bdm_stage.stg_motor_input
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  e.cod_dw_persona_ubic,
  e.cod_dw_ubic,
  e.complemento,
  e.id_buro_persona,
  e.cod_dw_tipo_ubicacion_dir,
  rpu.cod_pin_persona,
  rpu.cod_dw_direccion_fisica,
  e.texto_ubicacion,
  e.fecha_relacion_persona_ubicaci
FROM bdm_stage.stg_regla2_e031 e
JOIN bdm_stage.stg_regla2_e03_nit_pares p
  ON e.cod_dw_persona_ubic = p.cod_dw_persona_ubic
JOIN bdm_stage.relacion_persona_ubicacion rpu
  ON e.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

ANALYZE bdm_stage.stg_motor_input;
/* === FIN 07a_regla2_esc3_nit_prepara.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = 'benchmark_20k_v1' AND step_id = 'R2_ESC3_NIT_PREP' AND ended_at IS NULL;
-- PERF:END step=R2_ESC3_NIT_PREP


-- ============================================================
-- HITO 7 : Motor NIT
-- SOURCE: 06_motor_nuevas_direcciones.sql
-- ============================================================

-- PERF:BEGIN step=R2_ESC3_NIT_MOTOR order=7
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES ('benchmark_20k_v1', 7, 'R2_ESC3_NIT_MOTOR', 'Motor NIT', '06_motor_nuevas_direcciones.sql', GETDATE());

/* === INICIO 06_motor_nuevas_direcciones.sql === */
-- ============================================================
-- PASO 1: Descomponer complementos en nomenclaturas individuales
-- Cada fila = 1 nomenclatura de 1 dirección
-- JOIN con DICCIONARIO_COMPLEMENTOS por LIKE con separadores
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_descomp;
CREATE TABLE bdm_stage.stg_motor_descomp
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  sub.*,
  ROW_NUMBER() OVER (PARTITION BY sub.cod_dw_persona_ubic
    ORDER BY sub.nivel_complemento DESC) AS id_com,
  ROW_NUMBER() OVER (PARTITION BY sub.cod_dw_persona_ubic
    ORDER BY sub.nivel_complemento ASC) AS id_com1
FROM (
  SELECT
    tu.cod_dw_persona_ubic,
    tu.cod_dw_ubic,
    tu.id_buro_persona,
    tu.cod_dw_tipo_ubicacion_dir,
    dc.nomenclatura,
    dc.nomen,
    dc.valor AS valor_original,
    CASE WHEN REGEXP_COUNT(dc.valor, '^[0-9]+$') > 0 THEN CAST(dc.valor AS BIGINT) ELSE 0 END AS valor_num,
    COALESCE(nom.nivel_complemento, 99) AS nivel_complemento,
    COUNT(*) AS cantidad
  FROM bdm_stage.stg_motor_input tu
  JOIN bdm_stage.diccionario_complementos dc
    ON tu.complemento LIKE '%' || dc.nomenclatura || '%'
    AND tu.cod_dw_ubic = dc.cod_dw_ubic
    AND tu.id_buro_persona = dc.id_buro_persona
  LEFT JOIN bdm_stage.nomenclatura nom
    ON nom.nomenclatura = dc.nomen
  GROUP BY 1,2,3,4,5,6,7,8,9
) sub;

ANALYZE bdm_stage.stg_motor_descomp;

-- ============================================================
-- PASO 2: Agrupar nomenclaturas por dirección
-- NOM_AGRUP = concatenación de abreviaturas (ej: "TO|AP")
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_agrup;
CREATE TABLE bdm_stage.stg_motor_agrup
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT
  cod_dw_persona_ubic,
  LISTAGG(nomen, '|') WITHIN GROUP (ORDER BY id_com) AS nom_agrup,
  SUM(cantidad) AS cantidad
FROM bdm_stage.stg_motor_descomp
GROUP BY 1;

ANALYZE bdm_stage.stg_motor_agrup;

-- ============================================================
-- PASO 3: Calcular MDIR (jerarquía de dirección)
-- String ordenable: nivel(3 chars) + valor(6 chars) por nomenclatura
-- MDIR=1 = padre (mayor jerarquía), MDIR>1 = hijos
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_mdir;
CREATE TABLE bdm_stage.stg_motor_mdir
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  sub.cod_dw_persona_ubic,
  sub.cod_dw_ubic,
  sub.id_buro_persona,
  sub.cod_dw_tipo_ubicacion_dir,
  sub.mdir_key,
  ROW_NUMBER() OVER (
    PARTITION BY sub.cod_dw_ubic, sub.id_buro_persona, sub.cod_dw_tipo_ubicacion_dir
    ORDER BY sub.mdir_key, sub.cod_dw_persona_ubic ASC
  ) AS mdir
FROM (
  SELECT
    cod_dw_persona_ubic,
    cod_dw_ubic,
    id_buro_persona,
    cod_dw_tipo_ubicacion_dir,
    RPAD(
      LISTAGG(
        LPAD(CAST(nivel_complemento AS VARCHAR), 3, '0')
        || LPAD(CAST(CASE WHEN valor_num > 999999 THEN 999999 ELSE valor_num END AS VARCHAR), 6, '0'),
        ''
      ) WITHIN GROUP (ORDER BY id_com1),
      54, '099999999'
    ) AS mdir_key
  FROM bdm_stage.stg_motor_descomp
  GROUP BY 1,2,3,4
) sub;

ANALYZE bdm_stage.stg_motor_mdir;

-- ============================================================
-- PASO 4: Identificar padre (MDIR=1) e hijo (MDIR>1)
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_padre;
CREATE TABLE bdm_stage.stg_motor_padre
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  m.cod_dw_persona_ubic,
  m.cod_dw_ubic,
  m.id_buro_persona,
  m.cod_dw_tipo_ubicacion_dir,
  tu.complemento,
  tu.cod_pin_persona,
  tu.cod_dw_direccion_fisica,
  tu.texto_ubicacion,
  tu.fecha_relacion_persona_ubicaci,
  a.nom_agrup,
  a.cantidad
FROM bdm_stage.stg_motor_mdir m
JOIN bdm_stage.stg_motor_input tu
  ON m.cod_dw_persona_ubic = tu.cod_dw_persona_ubic
JOIN bdm_stage.stg_motor_agrup a
  ON m.cod_dw_persona_ubic = a.cod_dw_persona_ubic
WHERE m.mdir = 1;

ANALYZE bdm_stage.stg_motor_padre;

DROP TABLE IF EXISTS bdm_stage.stg_motor_hijo;
CREATE TABLE bdm_stage.stg_motor_hijo
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  m.cod_dw_persona_ubic,
  m.cod_dw_ubic,
  m.id_buro_persona,
  m.cod_dw_tipo_ubicacion_dir,
  tu.complemento,
  m.mdir,
  a.nom_agrup,
  a.cantidad
FROM bdm_stage.stg_motor_mdir m
JOIN bdm_stage.stg_motor_input tu
  ON m.cod_dw_persona_ubic = tu.cod_dw_persona_ubic
JOIN bdm_stage.stg_motor_agrup a
  ON m.cod_dw_persona_ubic = a.cod_dw_persona_ubic
WHERE m.mdir > 1;

ANALYZE bdm_stage.stg_motor_hijo;

-- ============================================================
-- PASO 5: Nomenclaturas del hijo que NO están en el padre
-- Reemplaza cursor + columnas dinámicas C1..CN + código binario
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_diff;
CREATE TABLE bdm_stage.stg_motor_diff
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic_hijo)
AS
SELECT
  h_nom.cod_dw_persona_ubic AS cod_dw_persona_ubic_hijo,
  p.cod_dw_persona_ubic AS cod_dw_persona_ubic_padre,
  h_nom.nomenclatura,
  h_nom.nomen,
  h_nom.valor_original,
  h_nom.id_com
FROM bdm_stage.stg_motor_descomp h_nom
JOIN bdm_stage.stg_motor_hijo h
  ON h_nom.cod_dw_persona_ubic = h.cod_dw_persona_ubic
JOIN bdm_stage.stg_motor_padre p
  ON h.cod_dw_ubic = p.cod_dw_ubic
  AND h.id_buro_persona = p.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = p.cod_dw_tipo_ubicacion_dir
LEFT JOIN bdm_stage.stg_motor_descomp p_nom
  ON p.cod_dw_persona_ubic = p_nom.cod_dw_persona_ubic
  AND h_nom.nomen = p_nom.nomen
  AND TRIM(h_nom.valor_original) = TRIM(p_nom.valor_original)
WHERE p_nom.cod_dw_persona_ubic IS NULL
  AND h.complemento <> p.complemento;

ANALYZE bdm_stage.stg_motor_diff;

-- ============================================================
-- PASO 6: Concatenar diferencias → nueva nomenclatura por par
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_codigo;
CREATE TABLE bdm_stage.stg_motor_codigo
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic_padre)
AS
SELECT
  cod_dw_persona_ubic_padre,
  cod_dw_persona_ubic_hijo,
  LISTAGG(nomenclatura, ' ') WITHIN GROUP (ORDER BY id_com) AS nueva_nomenclatura
FROM bdm_stage.stg_motor_diff
GROUP BY 1,2;

ANALYZE bdm_stage.stg_motor_codigo;

-- ============================================================
-- PASO 7: Construir nueva dirección completa
-- complemento_padre + nuevas nomenclaturas de todos los hijos
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_resultado;
CREATE TABLE bdm_stage.stg_motor_resultado
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  p.cod_dw_persona_ubic AS cod_dw_persona_ubic_padre,
  p.complemento AS complemento_padre,
  p.cod_dw_ubic,
  p.id_buro_persona,
  p.cod_dw_tipo_ubicacion_dir,
  p.cod_pin_persona,
  p.texto_ubicacion,
  p.fecha_relacion_persona_ubicaci,
  LEFT(
    TRIM(p.complemento) || ' ' || TRIM(LISTAGG(c.nueva_nomenclatura, ' ')
      WITHIN GROUP (ORDER BY h.mdir)),
    100
  ) AS nuevo_complemento,
  LISTAGG(CAST(c.cod_dw_persona_ubic_hijo AS VARCHAR), ',')
    WITHIN GROUP (ORDER BY h.mdir) AS hijos_ids
FROM bdm_stage.stg_motor_padre p
JOIN bdm_stage.stg_motor_codigo c
  ON p.cod_dw_persona_ubic = c.cod_dw_persona_ubic_padre
JOIN bdm_stage.stg_motor_hijo h
  ON c.cod_dw_persona_ubic_hijo = h.cod_dw_persona_ubic
GROUP BY 1,2,3,4,5,6,7,8;

ANALYZE bdm_stage.stg_motor_resultado;

-- ============================================================
-- PASO 8: Verificar existencia y generar IDs
-- Si la dirección combinada ya existe → reusar ID
-- Si no → MAX(id) + ROW_NUMBER() (sandbox; producción usa tabla de secuencias)
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_max_ids;
CREATE TABLE bdm_stage.stg_motor_max_ids AS
SELECT
  COALESCE((SELECT MAX(cod_dw_direccion_fisica) FROM bdm_stage.direccion_fisica), 0) AS max_df,
  COALESCE((SELECT MAX(cod_dw_persona_ubic) FROM bdm_stage.relacion_persona_ubicacion), 0) AS max_rpu;

DROP TABLE IF EXISTS bdm_stage.stg_motor_final;
CREATE TABLE bdm_stage.stg_motor_final
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  r.*,
  CASE WHEN df.cod_dw_direccion_fisica IS NOT NULL
    THEN df.cod_dw_direccion_fisica
    ELSE mx.max_df + ROW_NUMBER() OVER (
      PARTITION BY CASE WHEN df.cod_dw_direccion_fisica IS NULL THEN 1 ELSE 0 END
      ORDER BY r.cod_dw_persona_ubic_padre
    )
  END AS new_cod_dw_direccion_fisica,
  CASE WHEN df.cod_dw_direccion_fisica IS NULL THEN 1 ELSE 0 END AS es_nueva_df,
  mx.max_rpu + ROW_NUMBER() OVER (ORDER BY r.cod_dw_persona_ubic_padre) AS new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_resultado r
CROSS JOIN bdm_stage.stg_motor_max_ids mx
LEFT JOIN bdm_stage.direccion_fisica df
  ON df.cod_dw_ubic = r.cod_dw_ubic
  AND TRIM(df.complemento) = TRIM(r.nuevo_complemento);

ANALYZE bdm_stage.stg_motor_final;

-- ============================================================
-- PASO 9: INSERT en DIRECCION_FISICA (solo nuevas)
-- Generada_Enriquecida=1 marca que fue generada por el motor
-- ============================================================
INSERT INTO bdm_stage.direccion_fisica (
  cod_dw_direccion_fisica, complemento, cod_dw_ubic, generada_enriquecida
)
SELECT DISTINCT
  new_cod_dw_direccion_fisica,
  nuevo_complemento,
  cod_dw_ubic,
  1
FROM bdm_stage.stg_motor_final
WHERE es_nueva_df = 1;

-- ============================================================
-- PASO 10: INSERT en RELACION_PERSONA_UBICACION (nueva relación padre)
-- ============================================================
INSERT INTO bdm_stage.relacion_persona_ubicacion (
  cod_dw_persona_ubic,
  id_buro_persona,
  cod_pin_persona,
  cod_dw_ubic,
  cod_dw_direccion_fisica,
  cod_dw_tipo_ubicacion_dir,
  ind_unificacion,
  fecha_relacion_persona_ubicaci,
  lote
)
SELECT
  new_cod_dw_persona_ubic,
  id_buro_persona,
  cod_pin_persona,
  cod_dw_ubic,
  new_cod_dw_direccion_fisica,
  cod_dw_tipo_ubicacion_dir,
  NULL,
  CURRENT_DATE,
  1
FROM bdm_stage.stg_motor_final;

-- ============================================================
-- PASO 11: INSERT en UNIFICACION_DIRECCION (pares padre-hijo)
-- Cada hijo original apunta al nuevo cod_dw_persona_ubic del padre generado
-- En escenarios con motor, el padre MDIR original TAMBIÉN es hijo del nuevo padre
-- ============================================================
INSERT INTO bdm_stage.unificacion_direccion (
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  unifica_atributos,
  fecha_unificacion,
  lote,
  severidad,
  usuario_bd
)
SELECT
  h.cod_dw_persona_ubic,
  f.new_cod_dw_persona_ubic,
  2,
  CURRENT_DATE,
  1,
  1,
  LEFT(CURRENT_USER, 30)
FROM bdm_stage.stg_motor_final f
JOIN bdm_stage.stg_motor_hijo h
  ON h.cod_dw_ubic = f.cod_dw_ubic
  AND h.id_buro_persona = f.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = f.cod_dw_tipo_ubicacion_dir;

-- Padre MDIR original también es hijo del nuevo padre generado
INSERT INTO bdm_stage.unificacion_direccion (
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  unifica_atributos,
  fecha_unificacion,
  lote,
  severidad,
  usuario_bd
)
SELECT
  f.cod_dw_persona_ubic_padre,
  f.new_cod_dw_persona_ubic,
  2,
  CURRENT_DATE,
  1,
  1,
  LEFT(CURRENT_USER, 30)
FROM bdm_stage.stg_motor_final f;

-- ============================================================
-- PASO 12: UPDATE Ind_Unificacion=1 en TODAS las originales (hijos + padre MDIR)
-- ============================================================
UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_motor_hijo
  UNION ALL
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_motor_padre
);

-- ============================================================
-- PASO 13: ANALYZE en todas las tablas modificadas
-- ============================================================
ANALYZE bdm_stage.direccion_fisica;
ANALYZE bdm_stage.relacion_persona_ubicacion;
ANALYZE bdm_stage.unificacion_direccion;

-- ============================================================
-- Limpieza de tablas staging del motor
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_max_ids;
DROP TABLE IF EXISTS bdm_stage.stg_motor_descomp;
DROP TABLE IF EXISTS bdm_stage.stg_motor_agrup;
DROP TABLE IF EXISTS bdm_stage.stg_motor_mdir;
DROP TABLE IF EXISTS bdm_stage.stg_motor_diff;
DROP TABLE IF EXISTS bdm_stage.stg_motor_codigo;
DROP TABLE IF EXISTS bdm_stage.stg_motor_resultado;
-- Nota: stg_motor_input, stg_motor_final, stg_motor_padre y stg_motor_hijo
--       NO se borran aquí — los limpia el script *b que invoca al motor (07b/08b/09b)
/* === FIN 06_motor_nuevas_direcciones.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = 'benchmark_20k_v1' AND step_id = 'R2_ESC3_NIT_MOTOR' AND ended_at IS NULL;
-- PERF:END step=R2_ESC3_NIT_MOTOR


-- ============================================================
-- HITO 8 : R2 Esc3 NIT cerrar
-- SOURCE: 07b_regla2_esc3_nit_finaliza.sql
-- ============================================================

-- PERF:BEGIN step=R2_ESC3_NIT_FIN order=8
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES ('benchmark_20k_v1', 8, 'R2_ESC3_NIT_FIN', 'R2 Esc3 NIT cerrar', '07b_regla2_esc3_nit_finaliza.sql', GETDATE());

/* === INICIO 07b_regla2_esc3_nit_finaliza.sql === */
-- PASO 5: Actualizar stg_regla2_e2 con los hijos NIT
UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S',
    n_id = 'X4',
    id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
JOIN bdm_stage.stg_motor_hijo h
  ON h.cod_dw_ubic = f.cod_dw_ubic
  AND h.id_buro_persona = f.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = f.cod_dw_tipo_ubicacion_dir
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = h.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N';

-- Padre MDIR original también es hijo del nuevo padre generado
UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S',
    n_id = 'X4',
    id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = f.cod_dw_persona_ubic_padre
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N';

-- PASO 6: Insertar nueva dirección generada en E2
INSERT INTO bdm_stage.stg_regla2_e2 (
  cod_dw_persona_ubic, id_padre, id_buro_persona,
  cod_dw_tipo_ubicacion_dir, cod_dw_ubic, texto_ubicacion,
  cod_dw_direccion_fisica, complemento,
  ind_unificacion, n_id
)
SELECT
  f.new_cod_dw_persona_ubic,
  NULL,
  f.id_buro_persona,
  f.cod_dw_tipo_ubicacion_dir,
  f.cod_dw_ubic,
  f.texto_ubicacion,
  f.new_cod_dw_direccion_fisica,
  f.nuevo_complemento,
  'N',
  NULL
FROM bdm_stage.stg_motor_final f;

-- PASO 7: Estadísticas
ANALYZE bdm_stage.stg_regla2_e2;

-- PASO 8: Limpiar staging del escenario
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e031;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e03_nit_pares;
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
DROP TABLE IF EXISTS bdm_stage.stg_motor_final;
DROP TABLE IF EXISTS bdm_stage.stg_motor_padre;
DROP TABLE IF EXISTS bdm_stage.stg_motor_hijo;
/* === FIN 07b_regla2_esc3_nit_finaliza.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = 'benchmark_20k_v1' AND step_id = 'R2_ESC3_NIT_FIN' AND ended_at IS NULL;
-- PERF:END step=R2_ESC3_NIT_FIN


-- ============================================================
-- HITO 9 : R2 Esc5 preparar
-- SOURCE: 08a_regla2_esc5_prepara.sql
-- ============================================================

-- PERF:BEGIN step=R2_ESC5_PREP order=9
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES ('benchmark_20k_v1', 9, 'R2_ESC5_PREP', 'R2 Esc5 preparar', '08a_regla2_esc5_prepara.sql', GETDATE());

/* === INICIO 08a_regla2_esc5_prepara.sql === */
-- ============================================================
-- 08a_regla2_esc5_prepara.sql
-- Regla 2 Escenario 5: PARTE 1 — Prepara stg_motor_input
-- Ejecutar ANTES del motor (06_motor_nuevas_direcciones.sql)
-- ============================================================
-- Prerequisito: 07b_regla2_esc3_nit_finaliza.sql ejecutado
--
-- Subcaso 1: Valores diferentes → MOTOR genera nueva dirección
--   Persona 2006: TO 3 (nivel 4) + AP 504 (nivel 7) → "TO 3 AP 504"
-- Subcaso 2: Valores iguales → diccionario (procesado en 08b)
--   Persona 2008: TO 5 (nivel 4) + PI 5 (nivel 5) → gana TO por frecuencia
-- ============================================================

-- PASO 1: Filtrar no-unificados con complemento diferente
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05;
CREATE TABLE bdm_stage.stg_regla2_e05
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') A
JOIN (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.complemento              <> B.complemento;

ANALYZE bdm_stage.stg_regla2_e05;

-- PASO 2: Identificar nomenclaturas de cada complemento
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_a;
CREATE TABLE bdm_stage.stg_regla2_e05_a
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT
  A.*,
  NMC1.nomenclatura AS nomenclatura_pri,
  NMC1.nivel_complemento AS nivel_pri,
  NMC2.nomenclatura AS nomenclatura_sec,
  NMC2.nivel_complemento AS nivel_sec,
  TRIM(REPLACE(REPLACE(A.complemento, COALESCE(NMC1.nomenclatura,''), ''), COALESCE(NMC2.nomenclatura,''), '')) AS complemento2
FROM bdm_stage.stg_regla2_e05 A
LEFT JOIN bdm_stage.nomenclatura NMC1
  ON A.complemento LIKE TRIM(NMC1.nomenclatura) || ' %'
LEFT JOIN bdm_stage.nomenclatura NMC2
  ON A.complemento LIKE '% ' || TRIM(NMC2.nomenclatura) || ' %'
  AND NMC2.nomenclatura <> COALESCE(NMC1.nomenclatura, '');

ANALYZE bdm_stage.stg_regla2_e05_a;

-- PASO 3: Filtrar pares donde nomenclaturas están en DIFERENTE nivel
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_c;
CREATE TABLE bdm_stage.stg_regla2_e05_c
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT * FROM (
  SELECT DISTINCT A.*
  FROM bdm_stage.stg_regla2_e05_a A
  JOIN bdm_stage.stg_regla2_e05_a B
    ON  A.id_buro_persona          = B.id_buro_persona
    AND A.texto_ubicacion           = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
    AND A.cod_dw_municipio          = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
    AND A.complemento              <> B.complemento
    AND (A.complemento2 NOT LIKE '%' || B.complemento2 || '%'
         OR B.complemento2 NOT LIKE '%' || A.complemento2 || '%')
    AND A.nomenclatura_pri = B.nomenclatura_pri
    AND COALESCE(A.nomenclatura_sec, 'X') <> COALESCE(B.nomenclatura_sec, 'X')
    AND COALESCE(A.nivel_sec, 0) <> COALESCE(B.nivel_sec, 0)

  UNION

  SELECT DISTINCT A.*
  FROM bdm_stage.stg_regla2_e05_a A
  JOIN bdm_stage.stg_regla2_e05_a B
    ON  A.id_buro_persona          = B.id_buro_persona
    AND A.texto_ubicacion           = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
    AND A.cod_dw_municipio          = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
    AND A.complemento              <> B.complemento
    AND (A.complemento2 NOT LIKE '%' || B.complemento2 || '%'
         OR B.complemento2 NOT LIKE '%' || A.complemento2 || '%')
    AND A.nomenclatura_pri <> B.nomenclatura_pri
    AND COALESCE(A.nomenclatura_sec, 'X') = COALESCE(B.nomenclatura_sec, 'X')
    AND A.nivel_pri <> B.nivel_pri
) sub;

ANALYZE bdm_stage.stg_regla2_e05_c;

-- PASO 4: Subcaso 1 — pares con valores diferentes → motor
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub1;
CREATE TABLE bdm_stage.stg_regla2_e05_sub1
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM bdm_stage.stg_regla2_e05_c A
JOIN bdm_stage.stg_regla2_e05_c B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.complemento              <> B.complemento
  AND TRIM(A.complemento2) <> TRIM(B.complemento2);

ANALYZE bdm_stage.stg_regla2_e05_sub1;

-- PASO 5: Preparar stg_motor_input
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
CREATE TABLE bdm_stage.stg_motor_input
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  e.cod_dw_persona_ubic, e.cod_dw_ubic, e.complemento, e.id_buro_persona,
  e.cod_dw_tipo_ubicacion_dir, rpu.cod_pin_persona, rpu.cod_dw_direccion_fisica,
  e.texto_ubicacion, e.fecha_relacion_persona_ubicaci
FROM bdm_stage.stg_regla2_e05_sub1 e
JOIN bdm_stage.relacion_persona_ubicacion rpu
  ON e.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

ANALYZE bdm_stage.stg_motor_input;
/* === FIN 08a_regla2_esc5_prepara.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = 'benchmark_20k_v1' AND step_id = 'R2_ESC5_PREP' AND ended_at IS NULL;
-- PERF:END step=R2_ESC5_PREP


-- ============================================================
-- HITO 10 : Motor Esc5
-- SOURCE: 06_motor_nuevas_direcciones.sql
-- ============================================================

-- PERF:BEGIN step=R2_ESC5_MOTOR order=10
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES ('benchmark_20k_v1', 10, 'R2_ESC5_MOTOR', 'Motor Esc5', '06_motor_nuevas_direcciones.sql', GETDATE());

/* === INICIO 06_motor_nuevas_direcciones.sql === */
-- ============================================================
-- PASO 1: Descomponer complementos en nomenclaturas individuales
-- Cada fila = 1 nomenclatura de 1 dirección
-- JOIN con DICCIONARIO_COMPLEMENTOS por LIKE con separadores
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_descomp;
CREATE TABLE bdm_stage.stg_motor_descomp
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  sub.*,
  ROW_NUMBER() OVER (PARTITION BY sub.cod_dw_persona_ubic
    ORDER BY sub.nivel_complemento DESC) AS id_com,
  ROW_NUMBER() OVER (PARTITION BY sub.cod_dw_persona_ubic
    ORDER BY sub.nivel_complemento ASC) AS id_com1
FROM (
  SELECT
    tu.cod_dw_persona_ubic,
    tu.cod_dw_ubic,
    tu.id_buro_persona,
    tu.cod_dw_tipo_ubicacion_dir,
    dc.nomenclatura,
    dc.nomen,
    dc.valor AS valor_original,
    CASE WHEN REGEXP_COUNT(dc.valor, '^[0-9]+$') > 0 THEN CAST(dc.valor AS BIGINT) ELSE 0 END AS valor_num,
    COALESCE(nom.nivel_complemento, 99) AS nivel_complemento,
    COUNT(*) AS cantidad
  FROM bdm_stage.stg_motor_input tu
  JOIN bdm_stage.diccionario_complementos dc
    ON tu.complemento LIKE '%' || dc.nomenclatura || '%'
    AND tu.cod_dw_ubic = dc.cod_dw_ubic
    AND tu.id_buro_persona = dc.id_buro_persona
  LEFT JOIN bdm_stage.nomenclatura nom
    ON nom.nomenclatura = dc.nomen
  GROUP BY 1,2,3,4,5,6,7,8,9
) sub;

ANALYZE bdm_stage.stg_motor_descomp;

-- ============================================================
-- PASO 2: Agrupar nomenclaturas por dirección
-- NOM_AGRUP = concatenación de abreviaturas (ej: "TO|AP")
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_agrup;
CREATE TABLE bdm_stage.stg_motor_agrup
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT
  cod_dw_persona_ubic,
  LISTAGG(nomen, '|') WITHIN GROUP (ORDER BY id_com) AS nom_agrup,
  SUM(cantidad) AS cantidad
FROM bdm_stage.stg_motor_descomp
GROUP BY 1;

ANALYZE bdm_stage.stg_motor_agrup;

-- ============================================================
-- PASO 3: Calcular MDIR (jerarquía de dirección)
-- String ordenable: nivel(3 chars) + valor(6 chars) por nomenclatura
-- MDIR=1 = padre (mayor jerarquía), MDIR>1 = hijos
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_mdir;
CREATE TABLE bdm_stage.stg_motor_mdir
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  sub.cod_dw_persona_ubic,
  sub.cod_dw_ubic,
  sub.id_buro_persona,
  sub.cod_dw_tipo_ubicacion_dir,
  sub.mdir_key,
  ROW_NUMBER() OVER (
    PARTITION BY sub.cod_dw_ubic, sub.id_buro_persona, sub.cod_dw_tipo_ubicacion_dir
    ORDER BY sub.mdir_key, sub.cod_dw_persona_ubic ASC
  ) AS mdir
FROM (
  SELECT
    cod_dw_persona_ubic,
    cod_dw_ubic,
    id_buro_persona,
    cod_dw_tipo_ubicacion_dir,
    RPAD(
      LISTAGG(
        LPAD(CAST(nivel_complemento AS VARCHAR), 3, '0')
        || LPAD(CAST(CASE WHEN valor_num > 999999 THEN 999999 ELSE valor_num END AS VARCHAR), 6, '0'),
        ''
      ) WITHIN GROUP (ORDER BY id_com1),
      54, '099999999'
    ) AS mdir_key
  FROM bdm_stage.stg_motor_descomp
  GROUP BY 1,2,3,4
) sub;

ANALYZE bdm_stage.stg_motor_mdir;

-- ============================================================
-- PASO 4: Identificar padre (MDIR=1) e hijo (MDIR>1)
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_padre;
CREATE TABLE bdm_stage.stg_motor_padre
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  m.cod_dw_persona_ubic,
  m.cod_dw_ubic,
  m.id_buro_persona,
  m.cod_dw_tipo_ubicacion_dir,
  tu.complemento,
  tu.cod_pin_persona,
  tu.cod_dw_direccion_fisica,
  tu.texto_ubicacion,
  tu.fecha_relacion_persona_ubicaci,
  a.nom_agrup,
  a.cantidad
FROM bdm_stage.stg_motor_mdir m
JOIN bdm_stage.stg_motor_input tu
  ON m.cod_dw_persona_ubic = tu.cod_dw_persona_ubic
JOIN bdm_stage.stg_motor_agrup a
  ON m.cod_dw_persona_ubic = a.cod_dw_persona_ubic
WHERE m.mdir = 1;

ANALYZE bdm_stage.stg_motor_padre;

DROP TABLE IF EXISTS bdm_stage.stg_motor_hijo;
CREATE TABLE bdm_stage.stg_motor_hijo
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  m.cod_dw_persona_ubic,
  m.cod_dw_ubic,
  m.id_buro_persona,
  m.cod_dw_tipo_ubicacion_dir,
  tu.complemento,
  m.mdir,
  a.nom_agrup,
  a.cantidad
FROM bdm_stage.stg_motor_mdir m
JOIN bdm_stage.stg_motor_input tu
  ON m.cod_dw_persona_ubic = tu.cod_dw_persona_ubic
JOIN bdm_stage.stg_motor_agrup a
  ON m.cod_dw_persona_ubic = a.cod_dw_persona_ubic
WHERE m.mdir > 1;

ANALYZE bdm_stage.stg_motor_hijo;

-- ============================================================
-- PASO 5: Nomenclaturas del hijo que NO están en el padre
-- Reemplaza cursor + columnas dinámicas C1..CN + código binario
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_diff;
CREATE TABLE bdm_stage.stg_motor_diff
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic_hijo)
AS
SELECT
  h_nom.cod_dw_persona_ubic AS cod_dw_persona_ubic_hijo,
  p.cod_dw_persona_ubic AS cod_dw_persona_ubic_padre,
  h_nom.nomenclatura,
  h_nom.nomen,
  h_nom.valor_original,
  h_nom.id_com
FROM bdm_stage.stg_motor_descomp h_nom
JOIN bdm_stage.stg_motor_hijo h
  ON h_nom.cod_dw_persona_ubic = h.cod_dw_persona_ubic
JOIN bdm_stage.stg_motor_padre p
  ON h.cod_dw_ubic = p.cod_dw_ubic
  AND h.id_buro_persona = p.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = p.cod_dw_tipo_ubicacion_dir
LEFT JOIN bdm_stage.stg_motor_descomp p_nom
  ON p.cod_dw_persona_ubic = p_nom.cod_dw_persona_ubic
  AND h_nom.nomen = p_nom.nomen
  AND TRIM(h_nom.valor_original) = TRIM(p_nom.valor_original)
WHERE p_nom.cod_dw_persona_ubic IS NULL
  AND h.complemento <> p.complemento;

ANALYZE bdm_stage.stg_motor_diff;

-- ============================================================
-- PASO 6: Concatenar diferencias → nueva nomenclatura por par
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_codigo;
CREATE TABLE bdm_stage.stg_motor_codigo
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic_padre)
AS
SELECT
  cod_dw_persona_ubic_padre,
  cod_dw_persona_ubic_hijo,
  LISTAGG(nomenclatura, ' ') WITHIN GROUP (ORDER BY id_com) AS nueva_nomenclatura
FROM bdm_stage.stg_motor_diff
GROUP BY 1,2;

ANALYZE bdm_stage.stg_motor_codigo;

-- ============================================================
-- PASO 7: Construir nueva dirección completa
-- complemento_padre + nuevas nomenclaturas de todos los hijos
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_resultado;
CREATE TABLE bdm_stage.stg_motor_resultado
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  p.cod_dw_persona_ubic AS cod_dw_persona_ubic_padre,
  p.complemento AS complemento_padre,
  p.cod_dw_ubic,
  p.id_buro_persona,
  p.cod_dw_tipo_ubicacion_dir,
  p.cod_pin_persona,
  p.texto_ubicacion,
  p.fecha_relacion_persona_ubicaci,
  LEFT(
    TRIM(p.complemento) || ' ' || TRIM(LISTAGG(c.nueva_nomenclatura, ' ')
      WITHIN GROUP (ORDER BY h.mdir)),
    100
  ) AS nuevo_complemento,
  LISTAGG(CAST(c.cod_dw_persona_ubic_hijo AS VARCHAR), ',')
    WITHIN GROUP (ORDER BY h.mdir) AS hijos_ids
FROM bdm_stage.stg_motor_padre p
JOIN bdm_stage.stg_motor_codigo c
  ON p.cod_dw_persona_ubic = c.cod_dw_persona_ubic_padre
JOIN bdm_stage.stg_motor_hijo h
  ON c.cod_dw_persona_ubic_hijo = h.cod_dw_persona_ubic
GROUP BY 1,2,3,4,5,6,7,8;

ANALYZE bdm_stage.stg_motor_resultado;

-- ============================================================
-- PASO 8: Verificar existencia y generar IDs
-- Si la dirección combinada ya existe → reusar ID
-- Si no → MAX(id) + ROW_NUMBER() (sandbox; producción usa tabla de secuencias)
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_max_ids;
CREATE TABLE bdm_stage.stg_motor_max_ids AS
SELECT
  COALESCE((SELECT MAX(cod_dw_direccion_fisica) FROM bdm_stage.direccion_fisica), 0) AS max_df,
  COALESCE((SELECT MAX(cod_dw_persona_ubic) FROM bdm_stage.relacion_persona_ubicacion), 0) AS max_rpu;

DROP TABLE IF EXISTS bdm_stage.stg_motor_final;
CREATE TABLE bdm_stage.stg_motor_final
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  r.*,
  CASE WHEN df.cod_dw_direccion_fisica IS NOT NULL
    THEN df.cod_dw_direccion_fisica
    ELSE mx.max_df + ROW_NUMBER() OVER (
      PARTITION BY CASE WHEN df.cod_dw_direccion_fisica IS NULL THEN 1 ELSE 0 END
      ORDER BY r.cod_dw_persona_ubic_padre
    )
  END AS new_cod_dw_direccion_fisica,
  CASE WHEN df.cod_dw_direccion_fisica IS NULL THEN 1 ELSE 0 END AS es_nueva_df,
  mx.max_rpu + ROW_NUMBER() OVER (ORDER BY r.cod_dw_persona_ubic_padre) AS new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_resultado r
CROSS JOIN bdm_stage.stg_motor_max_ids mx
LEFT JOIN bdm_stage.direccion_fisica df
  ON df.cod_dw_ubic = r.cod_dw_ubic
  AND TRIM(df.complemento) = TRIM(r.nuevo_complemento);

ANALYZE bdm_stage.stg_motor_final;

-- ============================================================
-- PASO 9: INSERT en DIRECCION_FISICA (solo nuevas)
-- Generada_Enriquecida=1 marca que fue generada por el motor
-- ============================================================
INSERT INTO bdm_stage.direccion_fisica (
  cod_dw_direccion_fisica, complemento, cod_dw_ubic, generada_enriquecida
)
SELECT DISTINCT
  new_cod_dw_direccion_fisica,
  nuevo_complemento,
  cod_dw_ubic,
  1
FROM bdm_stage.stg_motor_final
WHERE es_nueva_df = 1;

-- ============================================================
-- PASO 10: INSERT en RELACION_PERSONA_UBICACION (nueva relación padre)
-- ============================================================
INSERT INTO bdm_stage.relacion_persona_ubicacion (
  cod_dw_persona_ubic,
  id_buro_persona,
  cod_pin_persona,
  cod_dw_ubic,
  cod_dw_direccion_fisica,
  cod_dw_tipo_ubicacion_dir,
  ind_unificacion,
  fecha_relacion_persona_ubicaci,
  lote
)
SELECT
  new_cod_dw_persona_ubic,
  id_buro_persona,
  cod_pin_persona,
  cod_dw_ubic,
  new_cod_dw_direccion_fisica,
  cod_dw_tipo_ubicacion_dir,
  NULL,
  CURRENT_DATE,
  1
FROM bdm_stage.stg_motor_final;

-- ============================================================
-- PASO 11: INSERT en UNIFICACION_DIRECCION (pares padre-hijo)
-- Cada hijo original apunta al nuevo cod_dw_persona_ubic del padre generado
-- En escenarios con motor, el padre MDIR original TAMBIÉN es hijo del nuevo padre
-- ============================================================
INSERT INTO bdm_stage.unificacion_direccion (
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  unifica_atributos,
  fecha_unificacion,
  lote,
  severidad,
  usuario_bd
)
SELECT
  h.cod_dw_persona_ubic,
  f.new_cod_dw_persona_ubic,
  2,
  CURRENT_DATE,
  1,
  1,
  LEFT(CURRENT_USER, 30)
FROM bdm_stage.stg_motor_final f
JOIN bdm_stage.stg_motor_hijo h
  ON h.cod_dw_ubic = f.cod_dw_ubic
  AND h.id_buro_persona = f.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = f.cod_dw_tipo_ubicacion_dir;

-- Padre MDIR original también es hijo del nuevo padre generado
INSERT INTO bdm_stage.unificacion_direccion (
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  unifica_atributos,
  fecha_unificacion,
  lote,
  severidad,
  usuario_bd
)
SELECT
  f.cod_dw_persona_ubic_padre,
  f.new_cod_dw_persona_ubic,
  2,
  CURRENT_DATE,
  1,
  1,
  LEFT(CURRENT_USER, 30)
FROM bdm_stage.stg_motor_final f;

-- ============================================================
-- PASO 12: UPDATE Ind_Unificacion=1 en TODAS las originales (hijos + padre MDIR)
-- ============================================================
UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_motor_hijo
  UNION ALL
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_motor_padre
);

-- ============================================================
-- PASO 13: ANALYZE en todas las tablas modificadas
-- ============================================================
ANALYZE bdm_stage.direccion_fisica;
ANALYZE bdm_stage.relacion_persona_ubicacion;
ANALYZE bdm_stage.unificacion_direccion;

-- ============================================================
-- Limpieza de tablas staging del motor
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_max_ids;
DROP TABLE IF EXISTS bdm_stage.stg_motor_descomp;
DROP TABLE IF EXISTS bdm_stage.stg_motor_agrup;
DROP TABLE IF EXISTS bdm_stage.stg_motor_mdir;
DROP TABLE IF EXISTS bdm_stage.stg_motor_diff;
DROP TABLE IF EXISTS bdm_stage.stg_motor_codigo;
DROP TABLE IF EXISTS bdm_stage.stg_motor_resultado;
-- Nota: stg_motor_input, stg_motor_final, stg_motor_padre y stg_motor_hijo
--       NO se borran aquí — los limpia el script *b que invoca al motor (07b/08b/09b)
/* === FIN 06_motor_nuevas_direcciones.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = 'benchmark_20k_v1' AND step_id = 'R2_ESC5_MOTOR' AND ended_at IS NULL;
-- PERF:END step=R2_ESC5_MOTOR


-- ============================================================
-- HITO 11 : R2 Esc5 cerrar
-- SOURCE: 08b_regla2_esc5_finaliza.sql
-- ============================================================

-- PERF:BEGIN step=R2_ESC5_FIN order=11
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES ('benchmark_20k_v1', 11, 'R2_ESC5_FIN', 'R2 Esc5 cerrar', '08b_regla2_esc5_finaliza.sql', GETDATE());

/* === INICIO 08b_regla2_esc5_finaliza.sql === */
-- ============================================================
-- 08b_regla2_esc5_finaliza.sql
-- Regla 2 Escenario 5: PARTE 2 — Usa resultado del motor + subcaso 2
-- Ejecutar DESPUÉS del motor (06_motor_nuevas_direcciones.sql)
-- ============================================================
-- Prerequisito: 08a_regla2_esc5_prepara.sql + 06_motor_nuevas_direcciones.sql
-- Persona 2006: post-motor (subcaso 1)
-- Persona 2008: diccionario D5 (subcaso 2 — TO 5 vs PI 5, mismo valor)
-- ============================================================

-- PASO 6: Post-motor — actualizar E2 para subcaso 1
UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'M5', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
JOIN bdm_stage.stg_motor_hijo h
  ON h.cod_dw_ubic = f.cod_dw_ubic AND h.id_buro_persona = f.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = f.cod_dw_tipo_ubicacion_dir
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = h.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N';

UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'M5', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = f.cod_dw_persona_ubic_padre
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N';

INSERT INTO bdm_stage.stg_regla2_e2 (
  cod_dw_persona_ubic, id_padre, id_buro_persona, cod_dw_tipo_ubicacion_dir,
  cod_dw_ubic, texto_ubicacion, cod_dw_direccion_fisica, complemento,
  ind_unificacion, n_id
)
SELECT f.new_cod_dw_persona_ubic, NULL, f.id_buro_persona, f.cod_dw_tipo_ubicacion_dir,
  f.cod_dw_ubic, f.texto_ubicacion, f.new_cod_dw_direccion_fisica, f.nuevo_complemento,
  'N', NULL
FROM bdm_stage.stg_motor_final f;

-- PASO 7: SUBCASO 2 — Valores iguales, diccionario decide padre
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2;
CREATE TABLE bdm_stage.stg_regla2_e05_sub2
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM bdm_stage.stg_regla2_e05_a A
JOIN bdm_stage.stg_regla2_e05_a B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.complemento              <> B.complemento
  AND TRIM(A.complemento2) = TRIM(B.complemento2)
  AND A.nivel_pri <> B.nivel_pri
WHERE A.cod_dw_persona_ubic NOT IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e05_sub1);

ANALYZE bdm_stage.stg_regla2_e05_sub2;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_freq;
CREATE TABLE bdm_stage.stg_regla2_e05_sub2_freq
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT t1.cod_dw_persona_ubic, COALESCE(t2.conteo, 0) AS conteo
FROM bdm_stage.stg_regla2_e05_sub2 t1
LEFT JOIN (
  SELECT t1.cod_dw_persona_ubic, SUM(dc.frecuencia) AS conteo
  FROM bdm_stage.stg_regla2_e05_sub2 t1
  LEFT JOIN bdm_stage.diccionario_complementos dc
    ON t1.cod_dw_ubic = dc.cod_dw_ubic
    AND t1.complemento LIKE '%' || dc.nomenclatura || '%'
    AND t1.id_buro_persona = dc.id_buro_persona
  GROUP BY 1
) t2 ON t1.cod_dw_persona_ubic = t2.cod_dw_persona_ubic;

ANALYZE bdm_stage.stg_regla2_e05_sub2_freq;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_d;
CREATE TABLE bdm_stage.stg_regla2_e05_sub2_d
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT u1.*,
  COUNT(*) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id) AS count_empate,
  MAX(id) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio) AS idmax
FROM (
  SELECT a.cod_dw_persona_ubic,
    (COALESCE(b.conteo, 0) + 10000000)
      + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0) AS id,
    a.texto_ubicacion, a.id_buro_persona, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio,
    a.cod_dw_ubic, a.complemento,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
      ORDER BY (COALESCE(b.conteo, 0) + 10000000)
        + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0)
    ) AS orden
  FROM bdm_stage.stg_regla2_e05_sub2 a
  LEFT JOIN bdm_stage.stg_regla2_e05_sub2_freq b ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
) u1;

ANALYZE bdm_stage.stg_regla2_e05_sub2_d;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_e;
CREATE TABLE bdm_stage.stg_regla2_e05_sub2_e
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT B.cod_dw_persona_ubic, A.cod_dw_persona_ubic AS id_padre
FROM bdm_stage.stg_regla2_e05_sub2_d A
JOIN bdm_stage.stg_regla2_e05_sub2_d B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.id > B.id
JOIN (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, MAX(orden) AS max_orden
  FROM bdm_stage.stg_regla2_e05_sub2_d GROUP BY 1,2,3,4
) mx ON A.id_buro_persona = mx.id_buro_persona AND A.texto_ubicacion = mx.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = mx.cod_dw_municipio
  AND A.orden = mx.max_orden;

ANALYZE bdm_stage.stg_regla2_e05_sub2_e;

UPDATE bdm_stage.stg_regla2_e2
SET id_padre = e.id_padre, ind_unificacion = 'S', n_id = 'D5'
FROM bdm_stage.stg_regla2_e05_sub2_e e
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = e.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.id_padre IS NULL;

INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT e.cod_dw_persona_ubic, e.id_padre AS cod_dw_direccion_unificada,
  2, CURRENT_DATE, 1, 1, LEFT(CURRENT_USER, 30)
FROM bdm_stage.stg_regla2_e05_sub2_e e;

UPDATE bdm_stage.relacion_persona_ubicacion SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e05_sub2_e);

-- PASO 8: Estadísticas y limpieza
ANALYZE bdm_stage.unificacion_direccion;
ANALYZE bdm_stage.relacion_persona_ubicacion;
ANALYZE bdm_stage.stg_regla2_e2;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_a;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_c;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub1;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_freq;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_d;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e05_sub2_e;
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
DROP TABLE IF EXISTS bdm_stage.stg_motor_final;
DROP TABLE IF EXISTS bdm_stage.stg_motor_padre;
DROP TABLE IF EXISTS bdm_stage.stg_motor_hijo;
/* === FIN 08b_regla2_esc5_finaliza.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = 'benchmark_20k_v1' AND step_id = 'R2_ESC5_FIN' AND ended_at IS NULL;
-- PERF:END step=R2_ESC5_FIN


-- ============================================================
-- HITO 12 : R2 Esc6 preparar
-- SOURCE: 09a_regla2_esc6_prepara.sql
-- ============================================================

-- PERF:BEGIN step=R2_ESC6_PREP order=12
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES ('benchmark_20k_v1', 12, 'R2_ESC6_PREP', 'R2 Esc6 preparar', '09a_regla2_esc6_prepara.sql', GETDATE());

/* === INICIO 09a_regla2_esc6_prepara.sql === */
-- ============================================================
-- 09a_regla2_esc6_prepara.sql
-- Regla 2 Escenario 6: PARTE 1 — Prepara stg_motor_input
-- Ejecutar ANTES del motor (06_motor_nuevas_direcciones.sql)
-- ============================================================
-- Prerequisito: 08b_regla2_esc5_finaliza.sql ejecutado
--
-- Subcaso 1: ≠ nivel → MOTOR genera nueva dirección
--   Persona 2007: ED 2 OF 301 + OF 302 (cruzadas, sin Esc2) → dirección combinada
-- Subcaso 3: = nivel → diccionario (procesado en 09b)
--   Persona 2009: LC 10 OF 200 + OF 200 (cruzadas, mismo nivel) → gana LC por frecuencia
-- ============================================================

-- PASO 1: Filtrar no-unificados con complemento diferente
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06;
CREATE TABLE bdm_stage.stg_regla2_e06
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') A
JOIN (SELECT * FROM bdm_stage.stg_regla2_e2 WHERE ind_unificacion = 'N') B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.complemento              <> B.complemento;

ANALYZE bdm_stage.stg_regla2_e06;

-- PASO 2: Identificar nomenclaturas (primaria y secundaria)
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_a;
CREATE TABLE bdm_stage.stg_regla2_e06_a
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*,
  NMC1.nomenclatura AS nomenclatura_pri,
  NMC1.nivel_complemento AS nivel_pri,
  NMC2.nomenclatura AS nomenclatura_sec,
  NMC2.nivel_complemento AS nivel_sec
FROM bdm_stage.stg_regla2_e06 A
LEFT JOIN bdm_stage.nomenclatura NMC1
  ON A.complemento LIKE TRIM(NMC1.nomenclatura) || ' %'
LEFT JOIN bdm_stage.nomenclatura NMC2
  ON A.complemento LIKE '% ' || TRIM(NMC2.nomenclatura) || ' %'
  AND NMC2.nomenclatura <> COALESCE(NMC1.nomenclatura, '');

ANALYZE bdm_stage.stg_regla2_e06_a;

-- PASO 3: Filtrar pares donde nomenclaturas están "cruzadas"
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_c;
CREATE TABLE bdm_stage.stg_regla2_e06_c
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT * FROM (
  SELECT DISTINCT A.*
  FROM bdm_stage.stg_regla2_e06_a A
  JOIN bdm_stage.stg_regla2_e06_a B
    ON  A.id_buro_persona          = B.id_buro_persona
    AND A.texto_ubicacion           = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
    AND A.cod_dw_municipio          = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
    AND A.complemento              <> B.complemento
    AND COALESCE(A.nomenclatura_pri, 'A') = COALESCE(B.nomenclatura_sec, 'B')

  UNION

  SELECT DISTINCT A.*
  FROM bdm_stage.stg_regla2_e06_a A
  JOIN bdm_stage.stg_regla2_e06_a B
    ON  A.id_buro_persona          = B.id_buro_persona
    AND A.texto_ubicacion           = B.texto_ubicacion
    AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
    AND A.cod_dw_municipio          = B.cod_dw_municipio
    AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
    AND A.complemento              <> B.complemento
    AND COALESCE(A.nomenclatura_sec, 'A') = COALESCE(B.nomenclatura_pri, 'B')
) sub;

ANALYZE bdm_stage.stg_regla2_e06_c;

-- PASO 4: Subcaso 1 — pares con diferente nivel → motor
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub1;
CREATE TABLE bdm_stage.stg_regla2_e06_sub1
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM bdm_stage.stg_regla2_e06_c A
JOIN bdm_stage.stg_regla2_e06_c B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.complemento              <> B.complemento
  AND COALESCE(A.nivel_pri, 0) <> COALESCE(B.nivel_pri, 0);

ANALYZE bdm_stage.stg_regla2_e06_sub1;

-- PASO 5: Preparar stg_motor_input
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
CREATE TABLE bdm_stage.stg_motor_input
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT e.cod_dw_persona_ubic, e.cod_dw_ubic, e.complemento, e.id_buro_persona,
  e.cod_dw_tipo_ubicacion_dir, rpu.cod_pin_persona, rpu.cod_dw_direccion_fisica,
  e.texto_ubicacion, e.fecha_relacion_persona_ubicaci
FROM bdm_stage.stg_regla2_e06_sub1 e
JOIN bdm_stage.relacion_persona_ubicacion rpu
  ON e.cod_dw_persona_ubic = rpu.cod_dw_persona_ubic;

ANALYZE bdm_stage.stg_motor_input;
/* === FIN 09a_regla2_esc6_prepara.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = 'benchmark_20k_v1' AND step_id = 'R2_ESC6_PREP' AND ended_at IS NULL;
-- PERF:END step=R2_ESC6_PREP


-- ============================================================
-- HITO 13 : Motor Esc6
-- SOURCE: 06_motor_nuevas_direcciones.sql
-- ============================================================

-- PERF:BEGIN step=R2_ESC6_MOTOR order=13
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES ('benchmark_20k_v1', 13, 'R2_ESC6_MOTOR', 'Motor Esc6', '06_motor_nuevas_direcciones.sql', GETDATE());

/* === INICIO 06_motor_nuevas_direcciones.sql === */
-- ============================================================
-- PASO 1: Descomponer complementos en nomenclaturas individuales
-- Cada fila = 1 nomenclatura de 1 dirección
-- JOIN con DICCIONARIO_COMPLEMENTOS por LIKE con separadores
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_descomp;
CREATE TABLE bdm_stage.stg_motor_descomp
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  sub.*,
  ROW_NUMBER() OVER (PARTITION BY sub.cod_dw_persona_ubic
    ORDER BY sub.nivel_complemento DESC) AS id_com,
  ROW_NUMBER() OVER (PARTITION BY sub.cod_dw_persona_ubic
    ORDER BY sub.nivel_complemento ASC) AS id_com1
FROM (
  SELECT
    tu.cod_dw_persona_ubic,
    tu.cod_dw_ubic,
    tu.id_buro_persona,
    tu.cod_dw_tipo_ubicacion_dir,
    dc.nomenclatura,
    dc.nomen,
    dc.valor AS valor_original,
    CASE WHEN REGEXP_COUNT(dc.valor, '^[0-9]+$') > 0 THEN CAST(dc.valor AS BIGINT) ELSE 0 END AS valor_num,
    COALESCE(nom.nivel_complemento, 99) AS nivel_complemento,
    COUNT(*) AS cantidad
  FROM bdm_stage.stg_motor_input tu
  JOIN bdm_stage.diccionario_complementos dc
    ON tu.complemento LIKE '%' || dc.nomenclatura || '%'
    AND tu.cod_dw_ubic = dc.cod_dw_ubic
    AND tu.id_buro_persona = dc.id_buro_persona
  LEFT JOIN bdm_stage.nomenclatura nom
    ON nom.nomenclatura = dc.nomen
  GROUP BY 1,2,3,4,5,6,7,8,9
) sub;

ANALYZE bdm_stage.stg_motor_descomp;

-- ============================================================
-- PASO 2: Agrupar nomenclaturas por dirección
-- NOM_AGRUP = concatenación de abreviaturas (ej: "TO|AP")
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_agrup;
CREATE TABLE bdm_stage.stg_motor_agrup
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT
  cod_dw_persona_ubic,
  LISTAGG(nomen, '|') WITHIN GROUP (ORDER BY id_com) AS nom_agrup,
  SUM(cantidad) AS cantidad
FROM bdm_stage.stg_motor_descomp
GROUP BY 1;

ANALYZE bdm_stage.stg_motor_agrup;

-- ============================================================
-- PASO 3: Calcular MDIR (jerarquía de dirección)
-- String ordenable: nivel(3 chars) + valor(6 chars) por nomenclatura
-- MDIR=1 = padre (mayor jerarquía), MDIR>1 = hijos
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_mdir;
CREATE TABLE bdm_stage.stg_motor_mdir
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  sub.cod_dw_persona_ubic,
  sub.cod_dw_ubic,
  sub.id_buro_persona,
  sub.cod_dw_tipo_ubicacion_dir,
  sub.mdir_key,
  ROW_NUMBER() OVER (
    PARTITION BY sub.cod_dw_ubic, sub.id_buro_persona, sub.cod_dw_tipo_ubicacion_dir
    ORDER BY sub.mdir_key, sub.cod_dw_persona_ubic ASC
  ) AS mdir
FROM (
  SELECT
    cod_dw_persona_ubic,
    cod_dw_ubic,
    id_buro_persona,
    cod_dw_tipo_ubicacion_dir,
    RPAD(
      LISTAGG(
        LPAD(CAST(nivel_complemento AS VARCHAR), 3, '0')
        || LPAD(CAST(CASE WHEN valor_num > 999999 THEN 999999 ELSE valor_num END AS VARCHAR), 6, '0'),
        ''
      ) WITHIN GROUP (ORDER BY id_com1),
      54, '099999999'
    ) AS mdir_key
  FROM bdm_stage.stg_motor_descomp
  GROUP BY 1,2,3,4
) sub;

ANALYZE bdm_stage.stg_motor_mdir;

-- ============================================================
-- PASO 4: Identificar padre (MDIR=1) e hijo (MDIR>1)
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_padre;
CREATE TABLE bdm_stage.stg_motor_padre
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  m.cod_dw_persona_ubic,
  m.cod_dw_ubic,
  m.id_buro_persona,
  m.cod_dw_tipo_ubicacion_dir,
  tu.complemento,
  tu.cod_pin_persona,
  tu.cod_dw_direccion_fisica,
  tu.texto_ubicacion,
  tu.fecha_relacion_persona_ubicaci,
  a.nom_agrup,
  a.cantidad
FROM bdm_stage.stg_motor_mdir m
JOIN bdm_stage.stg_motor_input tu
  ON m.cod_dw_persona_ubic = tu.cod_dw_persona_ubic
JOIN bdm_stage.stg_motor_agrup a
  ON m.cod_dw_persona_ubic = a.cod_dw_persona_ubic
WHERE m.mdir = 1;

ANALYZE bdm_stage.stg_motor_padre;

DROP TABLE IF EXISTS bdm_stage.stg_motor_hijo;
CREATE TABLE bdm_stage.stg_motor_hijo
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  m.cod_dw_persona_ubic,
  m.cod_dw_ubic,
  m.id_buro_persona,
  m.cod_dw_tipo_ubicacion_dir,
  tu.complemento,
  m.mdir,
  a.nom_agrup,
  a.cantidad
FROM bdm_stage.stg_motor_mdir m
JOIN bdm_stage.stg_motor_input tu
  ON m.cod_dw_persona_ubic = tu.cod_dw_persona_ubic
JOIN bdm_stage.stg_motor_agrup a
  ON m.cod_dw_persona_ubic = a.cod_dw_persona_ubic
WHERE m.mdir > 1;

ANALYZE bdm_stage.stg_motor_hijo;

-- ============================================================
-- PASO 5: Nomenclaturas del hijo que NO están en el padre
-- Reemplaza cursor + columnas dinámicas C1..CN + código binario
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_diff;
CREATE TABLE bdm_stage.stg_motor_diff
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic_hijo)
AS
SELECT
  h_nom.cod_dw_persona_ubic AS cod_dw_persona_ubic_hijo,
  p.cod_dw_persona_ubic AS cod_dw_persona_ubic_padre,
  h_nom.nomenclatura,
  h_nom.nomen,
  h_nom.valor_original,
  h_nom.id_com
FROM bdm_stage.stg_motor_descomp h_nom
JOIN bdm_stage.stg_motor_hijo h
  ON h_nom.cod_dw_persona_ubic = h.cod_dw_persona_ubic
JOIN bdm_stage.stg_motor_padre p
  ON h.cod_dw_ubic = p.cod_dw_ubic
  AND h.id_buro_persona = p.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = p.cod_dw_tipo_ubicacion_dir
LEFT JOIN bdm_stage.stg_motor_descomp p_nom
  ON p.cod_dw_persona_ubic = p_nom.cod_dw_persona_ubic
  AND h_nom.nomen = p_nom.nomen
  AND TRIM(h_nom.valor_original) = TRIM(p_nom.valor_original)
WHERE p_nom.cod_dw_persona_ubic IS NULL
  AND h.complemento <> p.complemento;

ANALYZE bdm_stage.stg_motor_diff;

-- ============================================================
-- PASO 6: Concatenar diferencias → nueva nomenclatura por par
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_codigo;
CREATE TABLE bdm_stage.stg_motor_codigo
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic_padre)
AS
SELECT
  cod_dw_persona_ubic_padre,
  cod_dw_persona_ubic_hijo,
  LISTAGG(nomenclatura, ' ') WITHIN GROUP (ORDER BY id_com) AS nueva_nomenclatura
FROM bdm_stage.stg_motor_diff
GROUP BY 1,2;

ANALYZE bdm_stage.stg_motor_codigo;

-- ============================================================
-- PASO 7: Construir nueva dirección completa
-- complemento_padre + nuevas nomenclaturas de todos los hijos
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_resultado;
CREATE TABLE bdm_stage.stg_motor_resultado
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  p.cod_dw_persona_ubic AS cod_dw_persona_ubic_padre,
  p.complemento AS complemento_padre,
  p.cod_dw_ubic,
  p.id_buro_persona,
  p.cod_dw_tipo_ubicacion_dir,
  p.cod_pin_persona,
  p.texto_ubicacion,
  p.fecha_relacion_persona_ubicaci,
  LEFT(
    TRIM(p.complemento) || ' ' || TRIM(LISTAGG(c.nueva_nomenclatura, ' ')
      WITHIN GROUP (ORDER BY h.mdir)),
    100
  ) AS nuevo_complemento,
  LISTAGG(CAST(c.cod_dw_persona_ubic_hijo AS VARCHAR), ',')
    WITHIN GROUP (ORDER BY h.mdir) AS hijos_ids
FROM bdm_stage.stg_motor_padre p
JOIN bdm_stage.stg_motor_codigo c
  ON p.cod_dw_persona_ubic = c.cod_dw_persona_ubic_padre
JOIN bdm_stage.stg_motor_hijo h
  ON c.cod_dw_persona_ubic_hijo = h.cod_dw_persona_ubic
GROUP BY 1,2,3,4,5,6,7,8;

ANALYZE bdm_stage.stg_motor_resultado;

-- ============================================================
-- PASO 8: Verificar existencia y generar IDs
-- Si la dirección combinada ya existe → reusar ID
-- Si no → MAX(id) + ROW_NUMBER() (sandbox; producción usa tabla de secuencias)
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_max_ids;
CREATE TABLE bdm_stage.stg_motor_max_ids AS
SELECT
  COALESCE((SELECT MAX(cod_dw_direccion_fisica) FROM bdm_stage.direccion_fisica), 0) AS max_df,
  COALESCE((SELECT MAX(cod_dw_persona_ubic) FROM bdm_stage.relacion_persona_ubicacion), 0) AS max_rpu;

DROP TABLE IF EXISTS bdm_stage.stg_motor_final;
CREATE TABLE bdm_stage.stg_motor_final
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  r.*,
  CASE WHEN df.cod_dw_direccion_fisica IS NOT NULL
    THEN df.cod_dw_direccion_fisica
    ELSE mx.max_df + ROW_NUMBER() OVER (
      PARTITION BY CASE WHEN df.cod_dw_direccion_fisica IS NULL THEN 1 ELSE 0 END
      ORDER BY r.cod_dw_persona_ubic_padre
    )
  END AS new_cod_dw_direccion_fisica,
  CASE WHEN df.cod_dw_direccion_fisica IS NULL THEN 1 ELSE 0 END AS es_nueva_df,
  mx.max_rpu + ROW_NUMBER() OVER (ORDER BY r.cod_dw_persona_ubic_padre) AS new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_resultado r
CROSS JOIN bdm_stage.stg_motor_max_ids mx
LEFT JOIN bdm_stage.direccion_fisica df
  ON df.cod_dw_ubic = r.cod_dw_ubic
  AND TRIM(df.complemento) = TRIM(r.nuevo_complemento);

ANALYZE bdm_stage.stg_motor_final;

-- ============================================================
-- PASO 9: INSERT en DIRECCION_FISICA (solo nuevas)
-- Generada_Enriquecida=1 marca que fue generada por el motor
-- ============================================================
INSERT INTO bdm_stage.direccion_fisica (
  cod_dw_direccion_fisica, complemento, cod_dw_ubic, generada_enriquecida
)
SELECT DISTINCT
  new_cod_dw_direccion_fisica,
  nuevo_complemento,
  cod_dw_ubic,
  1
FROM bdm_stage.stg_motor_final
WHERE es_nueva_df = 1;

-- ============================================================
-- PASO 10: INSERT en RELACION_PERSONA_UBICACION (nueva relación padre)
-- ============================================================
INSERT INTO bdm_stage.relacion_persona_ubicacion (
  cod_dw_persona_ubic,
  id_buro_persona,
  cod_pin_persona,
  cod_dw_ubic,
  cod_dw_direccion_fisica,
  cod_dw_tipo_ubicacion_dir,
  ind_unificacion,
  fecha_relacion_persona_ubicaci,
  lote
)
SELECT
  new_cod_dw_persona_ubic,
  id_buro_persona,
  cod_pin_persona,
  cod_dw_ubic,
  new_cod_dw_direccion_fisica,
  cod_dw_tipo_ubicacion_dir,
  NULL,
  CURRENT_DATE,
  1
FROM bdm_stage.stg_motor_final;

-- ============================================================
-- PASO 11: INSERT en UNIFICACION_DIRECCION (pares padre-hijo)
-- Cada hijo original apunta al nuevo cod_dw_persona_ubic del padre generado
-- En escenarios con motor, el padre MDIR original TAMBIÉN es hijo del nuevo padre
-- ============================================================
INSERT INTO bdm_stage.unificacion_direccion (
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  unifica_atributos,
  fecha_unificacion,
  lote,
  severidad,
  usuario_bd
)
SELECT
  h.cod_dw_persona_ubic,
  f.new_cod_dw_persona_ubic,
  2,
  CURRENT_DATE,
  1,
  1,
  LEFT(CURRENT_USER, 30)
FROM bdm_stage.stg_motor_final f
JOIN bdm_stage.stg_motor_hijo h
  ON h.cod_dw_ubic = f.cod_dw_ubic
  AND h.id_buro_persona = f.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = f.cod_dw_tipo_ubicacion_dir;

-- Padre MDIR original también es hijo del nuevo padre generado
INSERT INTO bdm_stage.unificacion_direccion (
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  unifica_atributos,
  fecha_unificacion,
  lote,
  severidad,
  usuario_bd
)
SELECT
  f.cod_dw_persona_ubic_padre,
  f.new_cod_dw_persona_ubic,
  2,
  CURRENT_DATE,
  1,
  1,
  LEFT(CURRENT_USER, 30)
FROM bdm_stage.stg_motor_final f;

-- ============================================================
-- PASO 12: UPDATE Ind_Unificacion=1 en TODAS las originales (hijos + padre MDIR)
-- ============================================================
UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_motor_hijo
  UNION ALL
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_motor_padre
);

-- ============================================================
-- PASO 13: ANALYZE en todas las tablas modificadas
-- ============================================================
ANALYZE bdm_stage.direccion_fisica;
ANALYZE bdm_stage.relacion_persona_ubicacion;
ANALYZE bdm_stage.unificacion_direccion;

-- ============================================================
-- Limpieza de tablas staging del motor
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_motor_max_ids;
DROP TABLE IF EXISTS bdm_stage.stg_motor_descomp;
DROP TABLE IF EXISTS bdm_stage.stg_motor_agrup;
DROP TABLE IF EXISTS bdm_stage.stg_motor_mdir;
DROP TABLE IF EXISTS bdm_stage.stg_motor_diff;
DROP TABLE IF EXISTS bdm_stage.stg_motor_codigo;
DROP TABLE IF EXISTS bdm_stage.stg_motor_resultado;
-- Nota: stg_motor_input, stg_motor_final, stg_motor_padre y stg_motor_hijo
--       NO se borran aquí — los limpia el script *b que invoca al motor (07b/08b/09b)
/* === FIN 06_motor_nuevas_direcciones.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = 'benchmark_20k_v1' AND step_id = 'R2_ESC6_MOTOR' AND ended_at IS NULL;
-- PERF:END step=R2_ESC6_MOTOR


-- ============================================================
-- HITO 14 : R2 Esc6 cerrar
-- SOURCE: 09b_regla2_esc6_finaliza.sql
-- ============================================================

-- PERF:BEGIN step=R2_ESC6_FIN order=14
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES ('benchmark_20k_v1', 14, 'R2_ESC6_FIN', 'R2 Esc6 cerrar', '09b_regla2_esc6_finaliza.sql', GETDATE());

/* === INICIO 09b_regla2_esc6_finaliza.sql === */
-- ============================================================
-- 09b_regla2_esc6_finaliza.sql
-- Regla 2 Escenario 6: PARTE 2 — Usa resultado del motor + subcaso 3
-- Ejecutar DESPUÉS del motor (06_motor_nuevas_direcciones.sql)
-- ============================================================
-- Prerequisito: 09a_regla2_esc6_prepara.sql + 06_motor_nuevas_direcciones.sql
-- Persona 2007: post-motor (subcaso 1)
-- Persona 2009: diccionario D6 (subcaso 3 — LC 10 OF 200 vs OF 200)
-- ============================================================

-- PASO 6: Post-motor — actualizar E2
UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'M6', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
JOIN bdm_stage.stg_motor_hijo h
  ON h.cod_dw_ubic = f.cod_dw_ubic AND h.id_buro_persona = f.id_buro_persona
  AND h.cod_dw_tipo_ubicacion_dir = f.cod_dw_tipo_ubicacion_dir
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = h.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N';

UPDATE bdm_stage.stg_regla2_e2
SET ind_unificacion = 'S', n_id = 'M6', id_padre = f.new_cod_dw_persona_ubic
FROM bdm_stage.stg_motor_final f
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = f.cod_dw_persona_ubic_padre
  AND bdm_stage.stg_regla2_e2.ind_unificacion = 'N';

INSERT INTO bdm_stage.stg_regla2_e2 (
  cod_dw_persona_ubic, id_padre, id_buro_persona, cod_dw_tipo_ubicacion_dir,
  cod_dw_ubic, texto_ubicacion, cod_dw_direccion_fisica, complemento,
  ind_unificacion, n_id
)
SELECT f.new_cod_dw_persona_ubic, NULL, f.id_buro_persona, f.cod_dw_tipo_ubicacion_dir,
  f.cod_dw_ubic, f.texto_ubicacion, f.new_cod_dw_direccion_fisica, f.nuevo_complemento,
  'N', NULL
FROM bdm_stage.stg_motor_final f;

-- PASO 7: SUBCASO 3 — Mismo nivel, diccionario decide padre
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3;
CREATE TABLE bdm_stage.stg_regla2_e06_sub3
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT DISTINCT A.*
FROM bdm_stage.stg_regla2_e06_c A
JOIN bdm_stage.stg_regla2_e06_c B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.complemento              <> B.complemento
  AND COALESCE(A.nivel_pri, 0) = COALESCE(B.nivel_pri, 0)
WHERE A.cod_dw_persona_ubic NOT IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e06_sub1);

ANALYZE bdm_stage.stg_regla2_e06_sub3;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_freq;
CREATE TABLE bdm_stage.stg_regla2_e06_sub3_freq
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT t1.cod_dw_persona_ubic, COALESCE(t2.conteo, 0) AS conteo
FROM bdm_stage.stg_regla2_e06_sub3 t1
LEFT JOIN (
  SELECT t1.cod_dw_persona_ubic, SUM(dc.frecuencia) AS conteo
  FROM bdm_stage.stg_regla2_e06_sub3 t1
  LEFT JOIN bdm_stage.diccionario_complementos dc
    ON t1.cod_dw_ubic = dc.cod_dw_ubic AND t1.complemento LIKE '%' || dc.nomenclatura || '%'
    AND t1.id_buro_persona = dc.id_buro_persona
  GROUP BY 1
) t2 ON t1.cod_dw_persona_ubic = t2.cod_dw_persona_ubic;

ANALYZE bdm_stage.stg_regla2_e06_sub3_freq;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_d;
CREATE TABLE bdm_stage.stg_regla2_e06_sub3_d
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT u1.*,
  COUNT(*) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, id) AS count_empate,
  MAX(id) OVER (PARTITION BY id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio) AS idmax
FROM (
  SELECT a.cod_dw_persona_ubic,
    (COALESCE(b.conteo, 0) + 10000000)
      + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0) AS id,
    a.texto_ubicacion, a.id_buro_persona, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio,
    ROW_NUMBER() OVER (
      PARTITION BY a.id_buro_persona, a.texto_ubicacion, a.cod_dw_tipo_ubicacion_dir, a.cod_dw_municipio
      ORDER BY (COALESCE(b.conteo, 0) + 10000000)
        + COALESCE(CAST(REPLACE(CAST(a.fecha_relacion_persona_ubicaci AS VARCHAR), '-', '') AS BIGINT), 0)
    ) AS orden
  FROM bdm_stage.stg_regla2_e06_sub3 a
  LEFT JOIN bdm_stage.stg_regla2_e06_sub3_freq b ON a.cod_dw_persona_ubic = b.cod_dw_persona_ubic
) u1;

ANALYZE bdm_stage.stg_regla2_e06_sub3_d;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_e;
CREATE TABLE bdm_stage.stg_regla2_e06_sub3_e
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
SELECT DISTINCT B.cod_dw_persona_ubic, A.cod_dw_persona_ubic AS id_padre
FROM bdm_stage.stg_regla2_e06_sub3_d A
JOIN bdm_stage.stg_regla2_e06_sub3_d B
  ON  A.id_buro_persona          = B.id_buro_persona
  AND A.texto_ubicacion           = B.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = B.cod_dw_tipo_ubicacion_dir
  AND A.cod_dw_municipio          = B.cod_dw_municipio
  AND A.cod_dw_persona_ubic      <> B.cod_dw_persona_ubic
  AND A.id > B.id
JOIN (
  SELECT id_buro_persona, texto_ubicacion, cod_dw_tipo_ubicacion_dir, cod_dw_municipio, MAX(orden) AS max_orden
  FROM bdm_stage.stg_regla2_e06_sub3_d GROUP BY 1,2,3,4
) mx ON A.id_buro_persona = mx.id_buro_persona AND A.texto_ubicacion = mx.texto_ubicacion
  AND A.cod_dw_tipo_ubicacion_dir = mx.cod_dw_tipo_ubicacion_dir AND A.cod_dw_municipio = mx.cod_dw_municipio
  AND A.orden = mx.max_orden;

ANALYZE bdm_stage.stg_regla2_e06_sub3_e;

UPDATE bdm_stage.stg_regla2_e2
SET id_padre = e.id_padre, ind_unificacion = 'S', n_id = 'D6'
FROM bdm_stage.stg_regla2_e06_sub3_e e
WHERE bdm_stage.stg_regla2_e2.cod_dw_persona_ubic = e.cod_dw_persona_ubic
  AND bdm_stage.stg_regla2_e2.id_padre IS NULL;

INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT e.cod_dw_persona_ubic, e.id_padre AS cod_dw_direccion_unificada,
  2, CURRENT_DATE, 1, 1, LEFT(CURRENT_USER, 30)
FROM bdm_stage.stg_regla2_e06_sub3_e e;

UPDATE bdm_stage.relacion_persona_ubicacion SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla2_e06_sub3_e);

-- PASO 8: Estadísticas y limpieza
ANALYZE bdm_stage.unificacion_direccion;
ANALYZE bdm_stage.relacion_persona_ubicacion;
ANALYZE bdm_stage.stg_regla2_e2;

DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_a;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_c;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub1;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_freq;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_d;
DROP TABLE IF EXISTS bdm_stage.stg_regla2_e06_sub3_e;
DROP TABLE IF EXISTS bdm_stage.stg_motor_input;
DROP TABLE IF EXISTS bdm_stage.stg_motor_final;
DROP TABLE IF EXISTS bdm_stage.stg_motor_padre;
DROP TABLE IF EXISTS bdm_stage.stg_motor_hijo;
/* === FIN 09b_regla2_esc6_finaliza.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = 'benchmark_20k_v1' AND step_id = 'R2_ESC6_FIN' AND ended_at IS NULL;
-- PERF:END step=R2_ESC6_FIN


-- ============================================================
-- HITO 15 : Regla 3
-- SOURCE: 10_regla3_geo.sql
-- ============================================================

-- PERF:BEGIN step=R3 order=15
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES ('benchmark_20k_v1', 15, 'R3', 'Regla 3', '10_regla3_geo.sql', GETDATE());

/* === INICIO 10_regla3_geo.sql === */
-- ============================================================
-- PASO 1: Materializar insumo de Regla 3
-- Solo registros NO unificados, tipo vía, sin modificadores
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_regla3_insumo;
CREATE TABLE bdm_stage.stg_regla3_insumo
DISTSTYLE KEY DISTKEY(id_buro_persona)
SORTKEY(id_buro_persona, tipo_via_principal, via_principal)
AS
SELECT
  rpu.cod_dw_persona_ubic,
  rpu.id_buro_persona,
  ubi.texto_ubicacion,
  df.tipo_via_principal,
  df.via_principal,
  df.via_generadora,
  df.numero_puerta,
  ubi.cod_dw_ciudad AS cod_dw_municipio,
  ubi.latitud,
  ubi.longitud,
  COALESCE(cnt.numero_entidades_reportan, 0) AS numero_entidades_reportan,
  COALESCE(MAX(rep.fecha_reporte), '1900-01-01') AS fecha_ultima_actualizacion
FROM bdm_stage.relacion_persona_ubicacion rpu
JOIN bdm_stage.ubicacion_estandarizada ubi ON rpu.cod_dw_ubic = ubi.cod_dw_ubic
LEFT JOIN bdm_stage.direccion_fisica df ON rpu.cod_dw_direccion_fisica = df.cod_dw_direccion_fisica
LEFT JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
LEFT JOIN (
  SELECT cod_dw_persona_ubic, COUNT(DISTINCT id_buro_suscriptor) AS numero_entidades_reportan
  FROM bdm_stage.reporte_relacion_persona_ubica GROUP BY 1
) cnt ON rpu.cod_dw_persona_ubic = cnt.cod_dw_persona_ubic
WHERE rpu.ind_unificacion IS NULL
  -- Excluir modificadores de vía (B, C, F, BIS, etc.) y cuadrantes
  AND ubi.texto_ubicacion !~ '[0-9]{1,3}[A-Z]{1,5}| OE$| E$| NE$| SE$| O$| S$| N$| SOE$'
GROUP BY 1,2,3,4,5,6,7,8,9,10,11;

ANALYZE bdm_stage.stg_regla3_insumo;

-- ============================================================
-- PASO 2: Identificar pares candidatos
-- ID_U=1: misma persona+municipio+tipo_via+via_principal+puerta, ≠ vía generadora
-- ID_U=2: misma persona+municipio+tipo_via+via_principal+via_gen, ≠ puerta (±2)
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_regla3_pares;
CREATE TABLE bdm_stage.stg_regla3_pares
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
-- Escenario 1: ≠ vía generadora
SELECT T1.*, 1 AS id_u
FROM bdm_stage.stg_regla3_insumo T1
JOIN bdm_stage.stg_regla3_insumo T2
  ON  T1.id_buro_persona     = T2.id_buro_persona
  AND T1.cod_dw_municipio    = T2.cod_dw_municipio
  AND T1.tipo_via_principal  = T2.tipo_via_principal
  AND T1.via_principal       = T2.via_principal
  AND T1.numero_puerta       = T2.numero_puerta
  AND T1.via_generadora     <> T2.via_generadora
GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12

UNION ALL

-- Escenario 2: ≠ número de puerta (±2)
SELECT T1.*, 2 AS id_u
FROM bdm_stage.stg_regla3_insumo T1
JOIN bdm_stage.stg_regla3_insumo T2
  ON  T1.id_buro_persona     = T2.id_buro_persona
  AND T1.cod_dw_municipio    = T2.cod_dw_municipio
  AND T1.tipo_via_principal  = T2.tipo_via_principal
  AND T1.via_principal       = T2.via_principal
  AND T1.via_generadora      = T2.via_generadora
  AND ABS(T1.numero_puerta - T2.numero_puerta) = 2
  AND T1.numero_puerta      <> T2.numero_puerta
GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12;

ANALYZE bdm_stage.stg_regla3_pares;

-- ============================================================
-- PASO 3: Construir diccionario de vía (frecuencias)
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_regla3_diccionario_via;
CREATE TABLE bdm_stage.stg_regla3_diccionario_via
DISTSTYLE ALL
AS
-- Via_Generadora: llave = tipo_via + via_principal + numero_puerta
SELECT
  'Via_Generadora' AS tipo,
  df.tipo_via_principal || ' ' || df.via_principal || ' ' || CAST(df.numero_puerta AS VARCHAR) AS llave,
  df.via_generadora,
  p.cod_dw_municipio,
  COUNT(rep.cod_dw_persona_ubic) AS conteo
FROM bdm_stage.direccion_fisica df
JOIN bdm_stage.ubicacion_estandarizada ue ON df.cod_dw_ubic = ue.cod_dw_ubic
JOIN bdm_stage.stg_regla3_pares p ON p.texto_ubicacion = ue.texto_ubicacion AND p.id_u = 1
JOIN bdm_stage.relacion_persona_ubicacion rpu ON df.cod_dw_ubic = rpu.cod_dw_ubic AND df.cod_dw_direccion_fisica = rpu.cod_dw_direccion_fisica
JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
GROUP BY 1,2,3,4

UNION ALL

-- Numero_Puerta: llave = tipo_via + via_principal + via_generadora
SELECT
  'Numero_Puerta' AS tipo,
  df.tipo_via_principal || ' ' || df.via_principal || ' ' || CAST(df.via_generadora AS VARCHAR) AS llave,
  df.numero_puerta AS via_generadora,
  p.cod_dw_municipio,
  COUNT(rep.cod_dw_persona_ubic) AS conteo
FROM bdm_stage.direccion_fisica df
JOIN bdm_stage.ubicacion_estandarizada ue ON df.cod_dw_ubic = ue.cod_dw_ubic
JOIN bdm_stage.stg_regla3_pares p ON p.texto_ubicacion = ue.texto_ubicacion AND p.id_u = 2
JOIN bdm_stage.relacion_persona_ubicacion rpu ON df.cod_dw_ubic = rpu.cod_dw_ubic AND df.cod_dw_direccion_fisica = rpu.cod_dw_direccion_fisica
JOIN bdm_stage.reporte_relacion_persona_ubica rep ON rpu.cod_dw_persona_ubic = rep.cod_dw_persona_ubic
GROUP BY 1,2,3,4;

ANALYZE bdm_stage.stg_regla3_diccionario_via;

-- Persistir diccionario en bdm_stage para referencia
DELETE FROM bdm_stage.diccionario_via;
INSERT INTO bdm_stage.diccionario_via SELECT * FROM bdm_stage.stg_regla3_diccionario_via;
ANALYZE bdm_stage.diccionario_via;

-- ============================================================
-- PASO 4: Calcular score unificado (combina los 3 subcasos)
-- Score = geo_component + fecha_component + entidades
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_regla3_scored;
CREATE TABLE bdm_stage.stg_regla3_scored
DISTSTYLE KEY DISTKEY(id_buro_persona)
AS
SELECT
  v.*,
  CASE
    -- Escenario 1: ≠ vía generadora
    WHEN v.id_u = 1 THEN
      CASE WHEN NULLIF(v.latitud, 0) IS NOT NULL AND NULLIF(v.longitud, 0) IS NOT NULL
        THEN 100000000 + COALESCE(dvv.conteo, 0) ELSE 0 END
      + CASE WHEN NULLIF(v.latitud, 0) IS NULL OR NULLIF(v.longitud, 0) IS NULL
        THEN COALESCE(CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR), '-', '') AS BIGINT), 0) ELSE 0 END
      + COALESCE(v.numero_entidades_reportan, 0)
    -- Escenario 2: ≠ número de puerta
    WHEN v.id_u = 2 THEN
      CASE WHEN NULLIF(v.latitud, 0) IS NOT NULL AND NULLIF(v.longitud, 0) IS NOT NULL
        THEN 100000000 + COALESCE(dvp.conteo, 0) ELSE 0 END
      + CASE WHEN NULLIF(v.latitud, 0) IS NULL AND NULLIF(v.longitud, 0) IS NULL
        THEN COALESCE(CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR), '-', '') AS BIGINT), 0) ELSE 0 END
      + COALESCE(v.numero_entidades_reportan, 0)
    ELSE 0
  END AS id_unificacion,

  -- Rankings por escenario
  ROW_NUMBER() OVER (PARTITION BY v.tipo_via_principal, v.via_principal, v.via_generadora,
    v.id_buro_persona, v.cod_dw_municipio
    ORDER BY CASE WHEN v.id_u=1 THEN
      CASE WHEN NULLIF(v.latitud,0) IS NOT NULL AND NULLIF(v.longitud,0) IS NOT NULL THEN 100000000+COALESCE(dvv.conteo,0) ELSE 0 END
      + CASE WHEN NULLIF(v.latitud,0) IS NULL OR NULLIF(v.longitud,0) IS NULL THEN COALESCE(CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR),'-','') AS BIGINT),0) ELSE 0 END
      + COALESCE(v.numero_entidades_reportan,0) ELSE 0 END DESC) AS id1,

  ROW_NUMBER() OVER (PARTITION BY v.tipo_via_principal, v.via_principal, v.numero_puerta,
    v.id_buro_persona, v.cod_dw_municipio
    ORDER BY CASE WHEN v.id_u=2 THEN
      CASE WHEN NULLIF(v.latitud,0) IS NOT NULL AND NULLIF(v.longitud,0) IS NOT NULL THEN 100000000+COALESCE(dvp.conteo,0) ELSE 0 END
      + CASE WHEN NULLIF(v.latitud,0) IS NULL AND NULLIF(v.longitud,0) IS NULL THEN COALESCE(CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR),'-','') AS BIGINT),0) ELSE 0 END
      + COALESCE(v.numero_entidades_reportan,0) ELSE 0 END DESC) AS id2,

  -- Detectar empates
  COUNT(*) OVER (PARTITION BY v.tipo_via_principal, v.via_principal, v.via_generadora,
    v.id_buro_persona, v.cod_dw_municipio,
    CASE WHEN v.id_u=1 THEN
      CASE WHEN NULLIF(v.latitud,0) IS NOT NULL AND NULLIF(v.longitud,0) IS NOT NULL THEN 100000000+COALESCE(dvv.conteo,0) ELSE 0 END
      + CASE WHEN NULLIF(v.latitud,0) IS NULL OR NULLIF(v.longitud,0) IS NULL THEN COALESCE(CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR),'-','') AS BIGINT),0) ELSE 0 END
      + COALESCE(v.numero_entidades_reportan,0) ELSE 0 END) AS cantidad1,

  COUNT(*) OVER (PARTITION BY v.tipo_via_principal, v.via_principal, v.numero_puerta,
    v.id_buro_persona, v.cod_dw_municipio,
    CASE WHEN v.id_u=2 THEN
      CASE WHEN NULLIF(v.latitud,0) IS NOT NULL AND NULLIF(v.longitud,0) IS NOT NULL THEN 100000000+COALESCE(dvp.conteo,0) ELSE 0 END
      + CASE WHEN NULLIF(v.latitud,0) IS NULL AND NULLIF(v.longitud,0) IS NULL THEN COALESCE(CAST(REPLACE(CAST(v.fecha_ultima_actualizacion AS VARCHAR),'-','') AS BIGINT),0) ELSE 0 END
      + COALESCE(v.numero_entidades_reportan,0) ELSE 0 END) AS cantidad2

FROM bdm_stage.stg_regla3_pares v
-- Diccionario vía generadora
LEFT JOIN bdm_stage.stg_regla3_diccionario_via dvv
  ON v.tipo_via_principal || ' ' || v.via_principal || ' ' || CAST(v.numero_puerta AS VARCHAR) = dvv.llave
  AND v.via_generadora = dvv.via_generadora
  AND v.cod_dw_municipio = dvv.cod_dw_municipio
  AND dvv.tipo = 'Via_Generadora'
-- Diccionario número puerta
LEFT JOIN bdm_stage.stg_regla3_diccionario_via dvp
  ON v.tipo_via_principal || ' ' || v.via_principal || ' ' || CAST(v.via_generadora AS VARCHAR) = dvp.llave
  AND v.numero_puerta = dvp.via_generadora
  AND dvp.tipo = 'Numero_Puerta';

ANALYZE bdm_stage.stg_regla3_scored;

-- ============================================================
-- PASO 5: Generar pares padre-hijo
-- Escenario 1 (ID_U=1): partición por tipo_via+via_principal+puerta
-- Escenario 2 (ID_U=2): partición por tipo_via+via_principal+via_gen
-- Empate (cantidad>1) → no unifica
-- ============================================================
DROP TABLE IF EXISTS bdm_stage.stg_regla3_resultado;
CREATE TABLE bdm_stage.stg_regla3_resultado
DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic)
AS
-- Escenario 1: ≠ vía generadora
SELECT T1.cod_dw_persona_ubic, T2.cod_dw_persona_ubic AS cod_dw_direccion_unificada
FROM bdm_stage.stg_regla3_scored T1
JOIN (
  SELECT cod_dw_persona_ubic, id_buro_persona, cod_dw_municipio, tipo_via_principal, via_principal, numero_puerta, via_generadora, id_unificacion
  FROM bdm_stage.stg_regla3_scored
  WHERE cantidad1 = 1 AND id_u = 1 AND id1 = 1
) T2
  ON  T1.id_buro_persona    = T2.id_buro_persona
  AND T1.cod_dw_municipio   = T2.cod_dw_municipio
  AND T1.tipo_via_principal  = T2.tipo_via_principal
  AND T1.via_principal       = T2.via_principal
  AND T1.numero_puerta       = T2.numero_puerta
  AND T1.via_generadora     <> T2.via_generadora
  AND T1.id_unificacion     <= T2.id_unificacion
  AND T1.cod_dw_persona_ubic <> T2.cod_dw_persona_ubic
WHERE T1.id_u = 1

UNION ALL

-- Escenario 2: ≠ número de puerta
SELECT T1.cod_dw_persona_ubic, T2.cod_dw_persona_ubic AS cod_dw_direccion_unificada
FROM bdm_stage.stg_regla3_scored T1
JOIN (
  SELECT cod_dw_persona_ubic, id_buro_persona, cod_dw_municipio, tipo_via_principal, via_principal, via_generadora, numero_puerta, id_unificacion
  FROM bdm_stage.stg_regla3_scored
  WHERE cantidad2 = 1 AND id_u = 2 AND id2 = 1
) T2
  ON  T1.id_buro_persona    = T2.id_buro_persona
  AND T1.cod_dw_municipio   = T2.cod_dw_municipio
  AND T1.tipo_via_principal  = T2.tipo_via_principal
  AND T1.via_principal       = T2.via_principal
  AND T1.via_generadora      = T2.via_generadora
  AND T1.numero_puerta      <> T2.numero_puerta
  AND T1.id_unificacion     <= T2.id_unificacion
  AND T1.cod_dw_persona_ubic <> T2.cod_dw_persona_ubic
WHERE T1.id_u = 2;

ANALYZE bdm_stage.stg_regla3_resultado;

-- ============================================================
-- PASO 6: Persistir
-- ============================================================
INSERT INTO bdm_stage.unificacion_direccion
SELECT DISTINCT
  cod_dw_persona_ubic,
  cod_dw_direccion_unificada,
  1 AS unifica_atributos,
  CURRENT_DATE AS fecha_unificacion,
  1 AS lote,
  1 AS severidad,
  LEFT(CURRENT_USER, 30) AS usuario_bd
FROM bdm_stage.stg_regla3_resultado;

UPDATE bdm_stage.relacion_persona_ubicacion
SET ind_unificacion = 1
WHERE cod_dw_persona_ubic IN (
  SELECT cod_dw_persona_ubic FROM bdm_stage.stg_regla3_resultado
);

-- ============================================================
-- PASO 7: Estadísticas y limpieza
-- ============================================================
ANALYZE bdm_stage.unificacion_direccion;
ANALYZE bdm_stage.relacion_persona_ubicacion;

DROP TABLE IF EXISTS bdm_stage.stg_regla3_insumo;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_pares;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_diccionario_via;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_scored;
DROP TABLE IF EXISTS bdm_stage.stg_regla3_resultado;
/* === FIN 10_regla3_geo.sql === */

UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = 'benchmark_20k_v1' AND step_id = 'R3' AND ended_at IS NULL;
-- PERF:END step=R3


-- HITO 16 : VALIDATION


-- PERF:BEGIN step=VALIDATION order=16
INSERT INTO bdm_stage.perf_timings (run_id, step_order, step_id, label, script_source, started_at)
VALUES ('benchmark_20k_v1', 16, 'VALIDATION', 'Validacion post-run', 'inc_validation.sql', GETDATE());

-- ============================================================
-- VALIDATION — conteos post-run sobre lote completo
-- ============================================================

SELECT 'VAL personas' AS metric, COUNT(DISTINCT id_buro_persona) AS val FROM bdm_stage.relacion_persona_ubicacion;
SELECT 'VAL rpu_total' AS metric, COUNT(*) AS val FROM bdm_stage.relacion_persona_ubicacion;
SELECT 'VAL rpu_vigentes' AS metric, COUNT(*) AS val FROM bdm_stage.relacion_persona_ubicacion WHERE ind_unificacion IS NULL;
SELECT 'VAL rpu_hijas' AS metric, COUNT(*) AS val FROM bdm_stage.relacion_persona_ubicacion WHERE ind_unificacion = 1;
SELECT 'VAL unificaciones' AS metric, COUNT(*) AS val FROM bdm_stage.unificacion_direccion;
SELECT 'VAL generada_enriquecida' AS metric, COUNT(*) AS val FROM bdm_stage.direccion_fisica WHERE generada_enriquecida = 1;

SELECT m.scenario_code, COUNT(DISTINCT m.id_buro_persona) AS personas,
  SUM(CASE WHEN u.cod_dw_persona_ubic IS NOT NULL THEN 1 ELSE 0 END) AS rpu_unificadas
FROM bdm_stage.perf_persona_meta m
LEFT JOIN bdm_stage.relacion_persona_ubicacion r ON r.id_buro_persona = m.id_buro_persona
LEFT JOIN bdm_stage.unificacion_direccion u ON u.cod_dw_persona_ubic = r.cod_dw_persona_ubic
GROUP BY 1 ORDER BY 1;

-- Invariante: padre (destino) no debe ser hijo
SELECT 'INV padre_no_hijo' AS check_name, COUNT(*) AS violaciones
FROM bdm_stage.unificacion_direccion u
JOIN bdm_stage.relacion_persona_ubicacion r ON r.cod_dw_persona_ubic = u.cod_dw_direccion_unificada
WHERE r.ind_unificacion = 1;

-- CONTROL: deben quedar 2 vigentes por persona
SELECT 'INV control_vigentes' AS check_name, COUNT(*) AS violaciones
FROM bdm_stage.perf_persona_meta m
WHERE m.scenario_code = 'CONTROL'
  AND (
    SELECT COUNT(*) FROM bdm_stage.relacion_persona_ubicacion r
    WHERE r.id_buro_persona = m.id_buro_persona AND r.ind_unificacion IS NULL
  ) <> 2;


UPDATE bdm_stage.perf_timings
SET ended_at = GETDATE(),
    duration_sec = DATEDIFF(second, started_at, GETDATE()),
    status = 'OK'
WHERE run_id = 'benchmark_20k_v1' AND step_id = 'VALIDATION' AND ended_at IS NULL;
-- PERF:END step=VALIDATION


-- ============================================================
-- REPORTE â€” tiempos por hito
-- ============================================================
SELECT step_order, step_id, label, duration_sec, started_at, ended_at, status, script_source
FROM bdm_stage.perf_timings
WHERE run_id = 'benchmark_20k_v1'
ORDER BY step_order;

SELECT step_id, label, duration_sec
FROM bdm_stage.perf_timings
WHERE run_id = 'benchmark_20k_v1'
ORDER BY step_order;

-- CLEANUP opcional (descomentar):
-- SOURCE: 03_demo_cleanup.sql
