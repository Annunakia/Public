# Validación DBeaver — SP_R1 / SP_R2 / SP_R3

Conexión esperada: **`dba_batch_DEV`** (o QA). Esquema: **`bdm_stage`**.

No hay credenciales Redshift en este workspace; la corrida debe hacerse en tu DBeaver.

---

## Opción A — Smoke (rápido, ~1 min)

Solo crea tablas/vistas + los 3 procedimientos. **No** carga 20K ni hace `CALL`.

1. Abrir: `Benchmark_20K/00_smoke_create_sp_r1_r2_r3.sql`
2. `Alt+Shift+X`
3. Debe devolver filas: `sp_r1`, `sp_r2`, `sp_r3`

Si falla el `CREATE PROCEDURE`, el error de Redshift sale en el log de DBeaver (revisar tamaño SP_R2 / sintaxis PL/pgSQL).

---

## Opción B — Validación completa (recomendado)

Crea STRCT + PGM + ejecuta orquestador (carga 20K + `CALL` cascada).

1. Abrir: `Benchmark_20K/00_validate_sp_r1_r2_r3_dbeaver.sql`
2. Confirmar `run_id` = `benchmark_20k_batch_qa_v1` (o cámbialo en todo el archivo)
3. Query timeout alto / desactivado
4. `Alt+Shift+X` — esperar fin (~2–3 min en QA según corrida previa)
5. Revisar el `SELECT` final de `perf_timings`:

| Esperado | Valor |
|----------|-------|
| Filas | 10 hitos |
| `status` | todos `OK` |
| `sp_exists` | 3 filas |
| Personas distintas | ~20.000 |

```sql
SELECT step_order, step_id, label, duration_sec, status
FROM bdm_stage.perf_timings
WHERE run_id = 'benchmark_20k_batch_qa_v1'
ORDER BY step_order;
```

---

## Si el CALL falla a mitad

- Los hitos ya cerrados quedan en `perf_timings` con `OK`
- Corregir el SP que falló en `_pgm`, volver a ejecutar solo ese `CREATE OR REPLACE PROCEDURE`
- Nuevo `run_id` o `DELETE` del run parcial antes de reintentar el orquestador

---

## Orden manual por archivo (si prefieres por partes)

1. `_strct` → `01_tables` → `02_catalog` → `03_views`
2. `_pgm` → `sp_r1` → `sp_r2` → `sp_r3`
3. `_dt` → `…_orchestrator.sql`
4. Query de `perf_timings` arriba
