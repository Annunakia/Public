-- ============================================================
-- DATA_LOAD — Benchmark @PERSONA_COUNT@ personas
-- Genera ~@PERSONA_COUNT@ personas x 2 RPU = ~@RPU_COUNT@ filas
-- ============================================================

-- Catálogos (igual que 01_demo_setup.sql)
DROP TABLE IF EXISTS bdm_stage.tipo_ubicacion_dir;
CREATE TABLE bdm_stage.tipo_ubicacion_dir (
  cod_dw_tipo_ubicacion_dir INTEGER ENCODE AZ64,
  descripcion_tipo_ubicacion_dir VARCHAR(20) ENCODE BYTEDICT
) DISTSTYLE ALL;
INSERT INTO bdm_stage.tipo_ubicacion_dir VALUES
(1, 'RES'), (2, 'LAB'), (3, 'CRR'), (4, 'JUD'), (5, 'CCL');

DROP TABLE IF EXISTS bdm_stage.nomenclatura;
CREATE TABLE bdm_stage.nomenclatura (
  nomenclatura VARCHAR(10) ENCODE ZSTD,
  nivel_complemento INTEGER ENCODE AZ64
) DISTSTYLE ALL;
INSERT INTO bdm_stage.nomenclatura VALUES
('BR',1),('UR',1),('CJ',1),('UN',1),
('ED',2),('ZN',2),('SEC',2),
('MZ',3),('ET',3),
('TO',4),('BQ',4),
('PI',5),('CS',5),('IN',5),('BL',5),
('LC',6),('OF',6),('PL',6),
('AP',7),('GJ',7),('DP',7),('ST',7);

DROP TABLE IF EXISTS bdm_stage.ubicacion_estandarizada;
CREATE TABLE bdm_stage.ubicacion_estandarizada (
  cod_dw_ubic BIGINT ENCODE AZ64,
  texto_ubicacion VARCHAR(200) ENCODE ZSTD,
  cod_dw_ciudad INTEGER ENCODE AZ64,
  latitud DECIMAL(10,7),
  longitud DECIMAL(10,7)
) DISTSTYLE KEY DISTKEY(cod_dw_ubic) SORTKEY(cod_dw_ubic);

DROP TABLE IF EXISTS bdm_stage.direccion_fisica;
CREATE TABLE bdm_stage.direccion_fisica (
  cod_dw_direccion_fisica BIGINT ENCODE AZ64,
  complemento VARCHAR(100) ENCODE ZSTD,
  cod_dw_ubic BIGINT ENCODE AZ64,
  tipo_via_principal VARCHAR(5) ENCODE ZSTD,
  via_principal VARCHAR(10) ENCODE ZSTD,
  via_generadora VARCHAR(10) ENCODE ZSTD,
  numero_puerta VARCHAR(10) ENCODE ZSTD,
  generada_enriquecida INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(cod_dw_direccion_fisica) SORTKEY(cod_dw_direccion_fisica);

DROP TABLE IF EXISTS bdm_stage.relacion_persona_ubicacion;
CREATE TABLE bdm_stage.relacion_persona_ubicacion (
  cod_dw_persona_ubic BIGINT ENCODE AZ64,
  id_buro_persona INTEGER ENCODE AZ64,
  cod_pin_persona INTEGER ENCODE AZ64,
  cod_dw_ubic BIGINT ENCODE AZ64,
  cod_dw_direccion_fisica BIGINT ENCODE AZ64,
  cod_dw_tipo_ubicacion_dir INTEGER ENCODE AZ64,
  ind_unificacion INTEGER ENCODE AZ64,
  orden_prioridad INTEGER ENCODE AZ64,
  fecha_relacion_persona_ubicaci DATE ENCODE AZ64,
  lote INTEGER ENCODE AZ64,
  cod_tipo_ident_fte INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(id_buro_persona) SORTKEY(id_buro_persona, cod_dw_persona_ubic);

DROP TABLE IF EXISTS bdm_stage.ciiu_persona;
CREATE TABLE bdm_stage.ciiu_persona (
  id_buro_persona INTEGER ENCODE AZ64,
  cod_act_econo_ciiu_fte VARCHAR(10) ENCODE BYTEDICT
) DISTSTYLE KEY DISTKEY(id_buro_persona);

DROP TABLE IF EXISTS bdm_stage.reporte_relacion_persona_ubica;
CREATE TABLE bdm_stage.reporte_relacion_persona_ubica (
  cod_dw_persona_ubic BIGINT ENCODE AZ64,
  id_buro_suscriptor INTEGER ENCODE AZ64,
  fecha_reporte DATE ENCODE AZ64,
  lote INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic) SORTKEY(cod_dw_persona_ubic);

DROP TABLE IF EXISTS bdm_stage.unificacion_direccion;
CREATE TABLE bdm_stage.unificacion_direccion (
  cod_dw_persona_ubic BIGINT ENCODE AZ64,
  cod_dw_direccion_unificada BIGINT ENCODE AZ64,
  unifica_atributos INTEGER ENCODE AZ64,
  fecha_unificacion DATE ENCODE AZ64,
  lote INTEGER ENCODE AZ64,
  severidad INTEGER ENCODE AZ64,
  usuario_bd VARCHAR(100) ENCODE ZSTD
) DISTSTYLE KEY DISTKEY(cod_dw_persona_ubic) SORTKEY(cod_dw_persona_ubic);

DROP TABLE IF EXISTS bdm_stage.diccionario_complementos;
CREATE TABLE bdm_stage.diccionario_complementos (
  cod_dw_ubic BIGINT ENCODE AZ64,
  id_buro_persona INTEGER ENCODE AZ64,
  nomenclatura VARCHAR(50) ENCODE ZSTD,
  nomen VARCHAR(10) ENCODE ZSTD,
  valor VARCHAR(50) ENCODE ZSTD,
  frecuencia INTEGER ENCODE AZ64
) DISTSTYLE KEY DISTKEY(cod_dw_ubic) SORTKEY(cod_dw_ubic, id_buro_persona);

DROP TABLE IF EXISTS bdm_stage.diccionario_via;
CREATE TABLE bdm_stage.diccionario_via (
  tipo VARCHAR(20) ENCODE ZSTD,
  llave VARCHAR(100) ENCODE ZSTD,
  via_generadora VARCHAR(10) ENCODE ZSTD,
  cod_dw_municipio INTEGER ENCODE AZ64,
  conteo INTEGER ENCODE AZ64
) DISTSTYLE ALL;

DROP TABLE IF EXISTS bdm_stage.relacion_ubicac_estandar_geo;
CREATE TABLE bdm_stage.relacion_ubicac_estandar_geo (
  cod_dw_ubic BIGINT ENCODE AZ64,
  latitud DECIMAL(10,7),
  longitud DECIMAL(10,7)
) DISTSTYLE ALL;

DROP TABLE IF EXISTS bdm_stage.bloqueo;
CREATE TABLE bdm_stage.bloqueo (
  id_buro_persona INTEGER ENCODE AZ64
) DISTSTYLE ALL;

-- Secuencia 1..N personas
DROP TABLE IF EXISTS bdm_stage.perf_digit;
CREATE TABLE bdm_stage.perf_digit (d INT) DISTSTYLE ALL;
INSERT INTO bdm_stage.perf_digit
SELECT 0 UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4
UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9;

DROP TABLE IF EXISTS bdm_stage.perf_nums;
CREATE TABLE bdm_stage.perf_nums AS
SELECT persona_seq
FROM (
  SELECT ROW_NUMBER() OVER (ORDER BY d1.d, d2.d, d3.d, d4.d, d5.d) AS persona_seq
  FROM bdm_stage.perf_digit d1
  CROSS JOIN bdm_stage.perf_digit d2
  CROSS JOIN bdm_stage.perf_digit d3
  CROSS JOIN bdm_stage.perf_digit d4
  CROSS JOIN bdm_stage.perf_digit d5
) seq
WHERE persona_seq <= @PERSONA_COUNT@;

-- Plantillas de escenario (patrones del demo 1001-3004)
DROP TABLE IF EXISTS bdm_stage.perf_scenario_seed;
CREATE TABLE bdm_stage.perf_scenario_seed (
  bucket_lo INT,
  bucket_hi INT,
  scenario_code VARCHAR(32),
  ciiu VARCHAR(10),
  tipo_a INT,
  tipo_b INT,
  comp_a VARCHAR(100),
  comp_b VARCHAR(100),
  same_ubic INT,
  tipo_via VARCHAR(5),
  via_base INT,
  gen_a INT,
  gen_b INT,
  puerta_a INT,
  puerta_b INT,
  lat_a DECIMAL(10,7),
  lon_a DECIMAL(10,7),
  lat_b DECIMAL(10,7),
  lon_b DECIMAL(10,7),
  nit_flag INT,
  hijo_a INT,
  rep_a INT,
  rep_b INT,
  needs_dic INT
) DISTSTYLE ALL;

INSERT INTO bdm_stage.perf_scenario_seed VALUES
-- R1 (0-11)
(0,2,'R1_ESC1','10',1,2,'','',1,'CL',45,12,12,'33','33',NULL,NULL,NULL,NULL,1,0,2,5),
(3,4,'R1_ESC2','81',2,1,'','',1,'KR',7,80,80,'22','22',NULL,NULL,NULL,NULL,1,0,1,4),
(5,6,'R1_ESC3','55',1,3,'','',1,'AK',57,63,63,'45','45',NULL,NULL,NULL,NULL,1,0,2,6),
(7,8,'R1_EMPATE','10',2,3,'','',1,'KR',7,80,80,'22','22',NULL,NULL,NULL,NULL,1,0,3,3),
(9,11,'R1_HIJA','82',1,3,'','',1,'AK',57,63,63,'45','45',NULL,NULL,NULL,NULL,1,1,2,3),
-- R2 directa (12-29)
(12,14,'R2_ESC1','10',1,1,'','AP 802',1,'DG',50,30,30,'10','10',NULL,NULL,NULL,NULL,1,0,2,3),
(15,17,'R2_ESC2','10',1,1,'AP 702','ED GALICIA AP 702',1,'TV',20,15,15,'40','40',NULL,NULL,NULL,NULL,1,0,2,4),
(18,20,'R2_ESC3_SIN_NIT','55',1,1,'AP 105','AP 404',1,'CL',22,27,27,'45','45',NULL,NULL,NULL,NULL,1,0,2,6),
(21,23,'R2_ESC4','10',1,1,'CS 5','PI 5',1,'CL',80,55,55,'18','18',NULL,NULL,NULL,NULL,1,0,3,2),
(24,29,'R2_EMPATE','10',1,1,'CS 8','PI 8',1,'CL',95,18,18,'42','42',NULL,NULL,NULL,NULL,1,0,2,2),
-- R2 motor (30-39)
(30,32,'R2_ESC3_NIT','10',1,1,'LC 101','LC 205',1,'KR',10,20,20,'30','30',NULL,NULL,NULL,NULL,3,0,3,3),
(33,36,'R2_ESC5_MOTOR','10',1,1,'TO 3','AP 504',1,'KR',30,45,45,'12','12',NULL,NULL,NULL,NULL,1,0,2,3),
(37,39,'R2_ESC6_MOTOR','10',1,1,'ED 2 OF 301','OF 302',1,'DG',70,25,25,'88','88',NULL,NULL,NULL,NULL,1,0,3,2),
-- R2 diccionario (40-47)
(40,42,'R2_ESC4_DIC','10',1,1,'CS 5','PI 5',1,'CL',80,55,55,'18','18',NULL,NULL,NULL,NULL,1,0,3,2),
(43,44,'R2_ESC5_DIC','10',1,1,'TO 5','PI 5',1,'CL',91,12,12,'34','34',NULL,NULL,NULL,NULL,1,0,3,2),
(45,47,'R2_ESC6_DIC','10',1,1,'LC 10 OF 200','OF 200',1,'KR',55,33,33,'22','22',NULL,NULL,NULL,NULL,1,0,4,2),
-- R3 (48-59)
(48,50,'R3_GEO','10',1,1,'','',0,'CL',34,78,80,'52','52',4.6097100,-74.0817500,NULL,NULL,1,0,3,2),
(51,53,'R3_FECHA','10',1,1,'','',0,'KR',15,45,45,'33','35',NULL,NULL,NULL,NULL,1,0,2,4),
(54,56,'R3_DICC_VIA','10',1,1,'','',0,'TV',60,20,22,'44','44',4.6200000,-74.0900000,4.6201000,-74.0901000,1,0,3,8),
(57,59,'R3_FUERA','10',1,1,'','',0,'DG',90,10,10,'50','55',NULL,NULL,NULL,NULL,1,0,2,3),
-- Control (60-99) — calles distintas por dirección
(60,99,'CONTROL','10',1,1,'','',0,'CL',100,10,20,'30','40',NULL,NULL,NULL,NULL,1,0,1,1);

DROP TABLE IF EXISTS bdm_stage.perf_persona;
CREATE TABLE bdm_stage.perf_persona AS
SELECT
  n.persona_seq,
  100000 + n.persona_seq AS id_buro_persona,
  (n.persona_seq % 100) AS bucket,
  s.scenario_code,
  s.ciiu,
  s.tipo_a,
  s.tipo_b,
  s.comp_a,
  s.comp_b,
  s.same_ubic,
  s.tipo_via,
  s.via_base + (n.persona_seq % 500) AS via_num,
  s.gen_a,
  s.gen_b,
  s.puerta_a,
  s.puerta_b,
  s.lat_a,
  s.lon_a,
  s.lat_b,
  s.lon_b,
  s.nit_flag,
  s.hijo_a,
  s.rep_a,
  s.rep_b,
  s.needs_dic
FROM bdm_stage.perf_nums n
JOIN bdm_stage.perf_scenario_seed s
  ON (n.persona_seq % 100) BETWEEN s.bucket_lo AND s.bucket_hi;

-- Ubicaciones (2 por persona)
INSERT INTO bdm_stage.ubicacion_estandarizada (cod_dw_ubic, texto_ubicacion, cod_dw_ciudad, latitud, longitud)
SELECT
  p.id_buro_persona * 1000 + 1,
  CASE
    WHEN p.scenario_code = 'CONTROL' THEN
      p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR) || ' ' || CAST(p.gen_a AS VARCHAR) || ' ' || CAST(p.puerta_a AS VARCHAR)
    WHEN p.same_ubic = 1 THEN
      p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR) || ' ' || CAST(p.gen_a AS VARCHAR) || ' ' || CAST(p.puerta_a AS VARCHAR)
    ELSE
      p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR) || ' ' || CAST(p.gen_a AS VARCHAR) || ' ' || CAST(p.puerta_a AS VARCHAR)
  END,
  1,
  p.lat_a,
  p.lon_a
FROM bdm_stage.perf_persona p;

INSERT INTO bdm_stage.ubicacion_estandarizada (cod_dw_ubic, texto_ubicacion, cod_dw_ciudad, latitud, longitud)
SELECT
  p.id_buro_persona * 1000 + 2,
  CASE
    WHEN p.scenario_code = 'CONTROL' THEN
      p.tipo_via || ' ' || CAST(p.via_num + 50 AS VARCHAR) || ' ' || CAST(p.gen_b AS VARCHAR) || ' ' || CAST(p.puerta_b AS VARCHAR)
    WHEN p.same_ubic = 1 THEN
      p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR) || ' ' || CAST(p.gen_a AS VARCHAR) || ' ' || CAST(p.puerta_a AS VARCHAR)
    WHEN p.scenario_code IN ('R3_GEO','R3_FECHA','R3_DICC_VIA','R3_FUERA') THEN
      p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR) || ' ' || CAST(p.gen_b AS VARCHAR) || ' ' || CAST(p.puerta_b AS VARCHAR)
    ELSE
      p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR) || ' ' || CAST(p.gen_a AS VARCHAR) || ' ' || CAST(p.puerta_a AS VARCHAR)
  END,
  1,
  p.lat_b,
  p.lon_b
FROM bdm_stage.perf_persona p;

-- Direcciones físicas
INSERT INTO bdm_stage.direccion_fisica
SELECT p.id_buro_persona * 1000 + 101, p.comp_a,
  CASE WHEN p.same_ubic = 1 THEN p.id_buro_persona * 1000 + 1 ELSE p.id_buro_persona * 1000 + 1 END,
  p.tipo_via, CAST(p.via_num AS VARCHAR), CAST(p.gen_a AS VARCHAR), CAST(p.puerta_a AS VARCHAR), NULL
FROM bdm_stage.perf_persona p;

INSERT INTO bdm_stage.direccion_fisica
SELECT p.id_buro_persona * 1000 + 102, p.comp_b,
  CASE WHEN p.same_ubic = 1 THEN p.id_buro_persona * 1000 + 1 ELSE p.id_buro_persona * 1000 + 2 END,
  p.tipo_via,
  CAST(CASE WHEN p.scenario_code = 'CONTROL' THEN p.via_num + 50 ELSE p.via_num END AS VARCHAR),
  CAST(CASE WHEN p.same_ubic = 1 THEN p.gen_a ELSE p.gen_b END AS VARCHAR),
  CAST(CASE WHEN p.same_ubic = 1 THEN p.puerta_a ELSE p.puerta_b END AS VARCHAR),
  NULL
FROM bdm_stage.perf_persona p;

-- CIIU
INSERT INTO bdm_stage.ciiu_persona
SELECT id_buro_persona, ciiu FROM bdm_stage.perf_persona;

-- RPU fila A
INSERT INTO bdm_stage.relacion_persona_ubicacion
SELECT
  p.id_buro_persona * 1000 + 1,
  p.id_buro_persona,
  900000 + p.persona_seq,
  CASE WHEN p.same_ubic = 1 THEN p.id_buro_persona * 1000 + 1 ELSE p.id_buro_persona * 1000 + 1 END,
  p.id_buro_persona * 1000 + 101,
  p.tipo_a,
  CASE WHEN p.hijo_a = 1 THEN 1 ELSE NULL END,
  NULL,
  DATEADD(day, -(p.persona_seq % 30), DATE '2025-06-01'),
  1,
  p.nit_flag
FROM bdm_stage.perf_persona p;

-- RPU fila B
INSERT INTO bdm_stage.relacion_persona_ubicacion
SELECT
  p.id_buro_persona * 1000 + 2,
  p.id_buro_persona,
  900000 + p.persona_seq,
  CASE WHEN p.same_ubic = 1 THEN p.id_buro_persona * 1000 + 1 ELSE p.id_buro_persona * 1000 + 2 END,
  p.id_buro_persona * 1000 + 102,
  p.tipo_b,
  NULL,
  NULL,
  DATEADD(day, p.persona_seq % 60, DATE '2025-03-01'),
  1,
  p.nit_flag
FROM bdm_stage.perf_persona p;

-- Reportes (simplificado: rep_a entidades en A, rep_b en B)
INSERT INTO bdm_stage.reporte_relacion_persona_ubica
SELECT p.id_buro_persona * 1000 + 1, 900 + (s.n % 20), DATE '2025-05-01', 1
FROM bdm_stage.perf_persona p
CROSS JOIN (SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8) s
WHERE s.n <= p.rep_a;

INSERT INTO bdm_stage.reporte_relacion_persona_ubica
SELECT p.id_buro_persona * 1000 + 2, 900 + (s.n % 20), DATE '2025-06-01', 1
FROM bdm_stage.perf_persona p
CROSS JOIN (SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8) s
WHERE s.n <= p.rep_b;

-- R3_DICC_VIA: más reportes en A que B
INSERT INTO bdm_stage.reporte_relacion_persona_ubica
SELECT p.id_buro_persona * 1000 + 1, 910 + s.n, DATE '2025-05-01', 1
FROM bdm_stage.perf_persona p
CROSS JOIN (SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3) s
WHERE p.scenario_code = 'R3_DICC_VIA';

-- Diccionario complementos (personas que lo requieren)
INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, 'CS 5', 'CS', '5', 10
FROM bdm_stage.perf_persona p WHERE p.scenario_code IN ('R2_ESC4','R2_ESC4_DIC');
INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, 'PI 5', 'PI', '5', 4
FROM bdm_stage.perf_persona p WHERE p.scenario_code IN ('R2_ESC4','R2_ESC4_DIC');

INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, p.comp_a, 'LC', '101', 8
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC3_NIT';
INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, p.comp_b, 'LC', '205', 4
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC3_NIT';

INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, p.comp_a, 'TO', '3', 8
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC5_MOTOR';
INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, p.comp_b, 'AP', '504', 4
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC5_MOTOR';

INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, 'ED 2 OF 301', 'ED', '2', 6
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC6_MOTOR';
INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, 'ED 2 OF 301', 'OF', '301', 4
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC6_MOTOR';
INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, p.comp_b, 'OF', '302', 4
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC6_MOTOR';

INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, p.comp_a, 'TO', '5', 15
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC5_DIC';
INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, p.comp_b, 'PI', '5', 6
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC5_DIC';

INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, 'LC', 'LC', '10', 20
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC6_DIC';
INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, 'OF', 'OF', '200', 8
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_ESC6_DIC';

INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, p.comp_a, 'CS', '8', 10
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_EMPATE';
INSERT INTO bdm_stage.diccionario_complementos
SELECT p.id_buro_persona * 1000 + 1, p.id_buro_persona, p.comp_b, 'PI', '8', 10
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R2_EMPATE';

-- Metadata escenario por persona (validación)
DROP TABLE IF EXISTS bdm_stage.perf_persona_meta;
CREATE TABLE bdm_stage.perf_persona_meta AS
SELECT id_buro_persona, persona_seq, scenario_code FROM bdm_stage.perf_persona;

-- Diccionario vía seed R3
INSERT INTO bdm_stage.diccionario_via
SELECT 'Via_Generadora',
  p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR) || ' ' || CAST(p.puerta_a AS VARCHAR),
  CAST(p.gen_a AS VARCHAR), 1, 15
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R3_DICC_VIA';
INSERT INTO bdm_stage.diccionario_via
SELECT 'Via_Generadora',
  p.tipo_via || ' ' || CAST(p.via_num AS VARCHAR) || ' ' || CAST(p.puerta_a AS VARCHAR),
  CAST(p.gen_b AS VARCHAR), 1, 8
FROM bdm_stage.perf_persona p WHERE p.scenario_code = 'R3_DICC_VIA';

ANALYZE bdm_stage.relacion_persona_ubicacion;
ANALYZE bdm_stage.ubicacion_estandarizada;
ANALYZE bdm_stage.direccion_fisica;
ANALYZE bdm_stage.ciiu_persona;
ANALYZE bdm_stage.reporte_relacion_persona_ubica;
ANALYZE bdm_stage.diccionario_complementos;

-- Verificación post-carga
SELECT 'CHECK personas' AS chk, COUNT(DISTINCT id_buro_persona) AS cnt FROM bdm_stage.relacion_persona_ubicacion;
SELECT 'CHECK rpu' AS chk, COUNT(*) AS cnt FROM bdm_stage.relacion_persona_ubicacion;
SELECT scenario_code, COUNT(*) AS personas FROM bdm_stage.perf_persona_meta GROUP BY 1 ORDER BY 1;

DROP TABLE IF EXISTS bdm_stage.perf_digit;
DROP TABLE IF EXISTS bdm_stage.perf_nums;
