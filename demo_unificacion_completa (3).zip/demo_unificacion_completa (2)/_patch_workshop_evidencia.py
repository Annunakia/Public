# -*- coding: utf-8 -*-
"""Workshop: tono 'ya lo corrimos / evidenciamos', no instrucciones al presentador."""
from __future__ import annotations

import json
import re
import shutil
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
]

# Narrativa por pack: recorrido ya ejecutado
WS = {
    "INSUMO-CT": {
        "_dev": (
            "Ya armamos el insumo de contactos. Entramos al mapa contactType → canal "
            "y evidenciamos quién entra: DIR con tipos de dirección, TEL/CEL/EMA solo "
            "si la persona tiene dirección ganadora, y el email sin @ queda fuera. "
            "Con la consulta del caso se ve el cruce persona–canal del seed."
        ),
        "_conclusion_regla": (
            "Evidencia: el canal lo define el tipo de contacto; sin DIR ganadora no entran TEL/CEL/EMA."
        ),
        "_ejemplo_label": "Evidencia · mapa de entrada (ya materializado en el seed)",
    },
    "RPU-STG": {
        "_dev": (
            "Ya cruzamos Unificación con las RPUs. Entramos a la persona 20011: "
            "el padre 91018 quedó con score y orden; la hija 91019 no tiene filas. "
            "Ahí evidenciamos la regla de solo ganadoras — no es un paso pendiente, "
            "es el resultado que ya obtuvimos en el seed."
        ),
        "_conclusion_regla": (
            "Evidencia 20011: padre compite; hija fuera de score y de orden_prioridad."
        ),
        "_ejemplo_label": "Evidencia · persona 20011 padre/hija",
    },
    "BETAS": {
        "_dev": (
            "Ya dejamos aplicado el catálogo RITM (47 coeficientes). "
            "Entramos al conteo por canal y evidenciamos que los pesos están cargados: "
            "el scoring no inventa betas; usa los del catálogo que ya revisamos."
        ),
        "_conclusion_regla": (
            "Evidencia: 47 betas RITM en catálogo; Redshift solo los aplica."
        ),
        "_ejemplo_label": "Evidencia · catálogo betas RITM (47)",
    },
    "DIR-RANK": {
        "_dev": (
            "Ya corrimos el ranking DIR sobre el seed. Entramos a la persona 20001: "
            "casa (91001) con 850 quedó lugar 1; oficina (91002) con 700 quedó lugar 2. "
            "Con esa misma consulta evidenciamos cuál calle contactamos primero."
        ),
        "_conclusion_regla": (
            "Evidencia 20001: casa primero, oficina segundo — RANK-01 cumplido."
        ),
        "_ejemplo_label": "Evidencia · 20001 casa vs oficina",
    },
    "ELEG-HIJA": {
        "_dev": (
            "Ya validamos F3-02 en el seed. Entramos a 20011 otra vez desde elegibilidad: "
            "el padre tiene DIR/TEL/EMA; la hija no aparece en score ni en orden. "
            "Eso es la evidencia de que la hija unificada no compite."
        ),
        "_conclusion_regla": (
            "Evidencia 20011: hija sin score ni orden; padre con lugar 1."
        ),
        "_ejemplo_label": "Evidencia · F3-02 hija excluida",
    },
    "ELEG-BLOQ": {
        "_dev": (
            "Ya revisamos datos no válidos en TEL. Entramos a 20004: "
            "el fijo válido quedó lugar 1 (420) y el no válido lugar 2 (210). "
            "Evidenciamos que el bloqueo/no válido no gana el primer intento."
        ),
        "_conclusion_regla": (
            "Evidencia 20004: NO VÁLIDO pierde frente a VÁLIDO en el mismo canal."
        ),
        "_ejemplo_label": "Evidencia · TEL válido vs no válido",
    },
    "DIR-EMPATE": {
        "_dev": (
            "Ya generamos el caso de empate. Entramos a 20010: ambas direcciones con score 777; "
            "quedaron lugar 1 y 2 por ROW_NUMBER. Evidenciamos que no inventamos un desempate "
            "de negocio nuevo — solo el orden técnico del motor."
        ),
        "_conclusion_regla": (
            "Evidencia 20010: empate 777/777 → lugares 1 y 2 sin tie-break de negocio."
        ),
        "_ejemplo_label": "Evidencia · empate DIR",
    },
    "TEL-RANK": {
        "_dev": (
            "Ya corrimos el ranking TEL aparte de DIR. Entramos a 20004: "
            "válido 420 lugar 1, no válido 210 lugar 2. "
            "Evidenciamos el primer fijo a intentar — y que no se mezcla con el ranking de calle."
        ),
        "_conclusion_regla": (
            "Evidencia 20004: TEL independiente; válido primero."
        ),
        "_ejemplo_label": "Evidencia · ranking TEL",
    },
    "TEL-02": {
        "_dev": (
            "Ya aislamos TEL020 en el seed. Entramos a 20013: tel_base y tel_solo_tel020 "
            "quedaron con el mismo score 376.5. Evidenciamos que esa variable no mueve el ranking "
            "(trazabilidad, no sumatoria)."
        ),
        "_conclusion_regla": (
            "Evidencia 20013: mismo score pese a TEL020 — fuera de suma."
        ),
        "_ejemplo_label": "Evidencia · TEL020 no mueve score",
    },
    "CEL-02": {
        "_dev": (
            "Ya dejamos el caso de prefijo desconocido. Entramos a 20012: prefijo 999, "
            "score CEL 220 lugar 1. Evidenciamos el default 0.22 acordado cuando no hay operador en catálogo."
        ),
        "_conclusion_regla": (
            "Evidencia 20012: prefijo sin catálogo → default 0.22 → score 220."
        ),
        "_ejemplo_label": "Evidencia · CEL default 0.22",
    },
    "EMA-03": {
        "_dev": (
            "Ya aislamos las variables EMA fuera de suma. Entramos a 20014: "
            "ambos emails con score 281.7705. Evidenciamos que EMA003/007 no empujan el lugar."
        ),
        "_conclusion_regla": (
            "Evidencia 20014: mismo score pese a variables excluidas."
        ),
        "_ejemplo_label": "Evidencia · EMA excluidas",
    },
    "CONSOL": {
        "_dev": (
            "Ya consolidamos la salida. Volvemos a 20001: orden_prioridad casa=1, oficina=2 — "
            "igual que el lugar DIR. Evidenciamos que el orden de intento en calle ya quedó persistido."
        ),
        "_conclusion_regla": (
            "Evidencia 20001: orden_prioridad alineado al ranking DIR."
        ),
        "_ejemplo_label": "Evidencia · orden_prioridad",
    },
}


def rewrite_query(q: str) -> str:
    if not q:
        return q
    q = q.replace(
        "-- Primero carga el mismo seed del SP:\n",
        "-- Seed ya materializado (misma corrida de evidencia).\n",
    )
    q = q.replace(
        "-- Seed validado (mismas filas del HTML):\n",
        "-- Seed ya materializado (mismas filas del HTML).\n",
    )
    q = q.replace(
        "-- (equivale a cargar_seed_mock + validar_mock)\n",
        "-- (ejecucion_mock = seed + validación; ya corrido para la demo).\n",
    )
    q = q.replace(
        "-- Ejemplo SP mock",
        "-- Evidencia seed",
    )
    q = q.replace(
        "-- Primero carga el mismo seed del SP:",
        "-- Seed ya materializado:",
    )
    # Keep CALL as the query they show — but comment as already done path
    if "CALL bdm_stage.sp_ordenamiento_ejecucion_mock()" in q:
        q = q.replace(
            "CALL bdm_stage.sp_ordenamiento_ejecucion_mock();\n",
            "-- Ya ejecutamos: CALL bdm_stage.sp_ordenamiento_ejecucion_mock();\n"
            "-- Consulta de evidencia:\n",
            1,
        )
    return q


def extract_json_object(html: str, start: int):
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    return json.loads(unescape(html[start:j])), start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return escape(raw, quote=True).replace("&#x27;", "'")


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    assert len(positions) >= 2
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)

    n = 0
    for row in data.get("rows") or []:
        code = row.get("_pack_code")
        if code in WS:
            for k, v in WS[code].items():
                row[k] = v
            if "_conclusion_regla" in WS[code]:
                row["_conclusion"] = WS[code]["_conclusion_regla"]
            n += 1
        qk = "Query validación (copiar en dba_rncr_batch)"
        if row.get(qk):
            row[qk] = rewrite_query(row[qk])
        # id ejemplo tone
        if row.get("_id_ejemplo") and "SEED ·" in str(row["_id_ejemplo"]):
            row["_id_ejemplo"] = str(row["_id_ejemplo"]).replace("SEED ·", "Evidencia ·")

    html = html[:start] + to_html_json(data) + html[end:]

    # Workshop landing copy
    old_land = (
        "&lt;div class=&quot;frame-title&quot;&gt;Workshop — queries y casos por canal&lt;/div&gt;\n"
        "      &lt;div class=&quot;frame-sub&quot;&gt;Elige un bloque. Cada tarjeta trae regla, ejemplo seed y query para DBeaver.&lt;/div&gt;\n"
        "      &lt;div class=&quot;ws-subnav&quot; id=&quot;wsSubnav&quot;&gt;&lt;/div&gt;\n"
        "      &lt;div class=&quot;presentacion-block&quot; style=&quot;margin-top:0.75rem&quot;&gt;\n"
        "        &lt;h4&gt;Cómo usar el Workshop&lt;/h4&gt;\n"
        "        &lt;p&gt;1) En DBeaver: &lt;code&gt;CALL bdm_stage.sp_ordenamiento_ejecucion_mock();&lt;/code&gt;\n"
        "        2) Entra a Insumos / DIR / TEL / CEL / EMA / Salida.\n"
        "        3) Abre &lt;strong&gt;Ver query&lt;/strong&gt; y compara con la tabla del ejemplo (HTML = seed).&lt;/p&gt;\n"
        "      &lt;/div&gt;"
    )
    new_land = (
        "&lt;div class=&quot;frame-title&quot;&gt;Workshop — evidencia por canal&lt;/div&gt;\n"
        "      &lt;div class=&quot;frame-sub&quot;&gt;Recorrido ya ejecutado sobre el seed. Cada bloque muestra qué entramos a mirar y qué evidenciamos.&lt;/div&gt;\n"
        "      &lt;div class=&quot;ws-subnav&quot; id=&quot;wsSubnav&quot;&gt;&lt;/div&gt;\n"
        "      &lt;div class=&quot;presentacion-block&quot; style=&quot;margin-top:0.75rem&quot;&gt;\n"
        "        &lt;h4&gt;Qué ya dejamos listo&lt;/h4&gt;\n"
        "        &lt;p&gt;Ya materializamos el seed mock (&lt;code&gt;sp_ordenamiento_ejecucion_mock&lt;/code&gt;) "
        "y validamos los criterios. En cada pestaña entramos al caso, "
        "mostramos la consulta con la que evidenciamos el resultado y contrastamos con la tabla del ejemplo. "
        "No es una guía de pasos pendientes: es el recorrido que ya corrimos.&lt;/p&gt;\n"
        "      &lt;/div&gt;"
    )
    if old_land in html:
        html = html.replace(old_land, new_land, 1)
        print("  landing ok")
    else:
        # looser replace pieces
        html = html.replace(
            "Workshop — queries y casos por canal",
            "Workshop — evidencia por canal",
            1,
        )
        html = html.replace(
            "Elige un bloque. Cada tarjeta trae regla, ejemplo seed y query para DBeaver.",
            "Recorrido ya ejecutado sobre el seed. Cada bloque: qué miramos y qué evidenciamos.",
            1,
        )
        html = html.replace("Cómo usar el Workshop", "Qué ya dejamos listo", 1)
        print("  landing partial")

    # SEED disclaimer instructional → evidencia
    html = html.replace(
        "SEED (bdm_stage): CALL sp_ordenamiento_ejecucion_mock(); la query debe devolver exactamente las filas de esta tabla.",
        "Evidencia seed (bdm_stage): con el seed ya materializado, esta consulta devuelve las filas de la tabla.",
    )
    html = html.replace(
        "SEED (bdm_stage): CALL sp_ordenamiento_ejecucion_mock(); la query debe devolver exactamente las filas de esta tabla.",
        "Evidencia seed (bdm_stage): con el seed ya materializado, esta consulta devuelve las filas de la tabla.",
    )
    # escaped variant
    html = html.replace(
        "&#x27;SEED (bdm_stage): CALL sp_ordenamiento_ejecucion_mock(); la query debe devolver exactamente las filas de esta tabla.&#x27;",
        "&#x27;Evidencia seed (bdm_stage): con el seed ya materializado, esta consulta devuelve las filas de la tabla.&#x27;",
    )

    # Button label Ver query → Query de evidencia (ord scenario cards)
    html = html.replace(
        "&gt;Ver query&lt;/button&gt;` : &#x27;&#x27;;\n  const tblPasos = wrapTblBlock",
        "&gt;Query de evidencia&lt;/button&gt;` : &#x27;&#x27;;\n  const tblPasos = wrapTblBlock",
        1,
    )
    # Also btn-card-query text in renderScenarioCard - search
    if "Ver query&lt;/button&gt;` : &#x27;&#x27;;\n  const tblPasos" not in html:
        # try the head query button pattern in ord renderScenarioCard
        old_btn = "Ver query&lt;/button&gt;` : &#x27;&#x27;;\n  const tblPasos = wrapTblBlock"
        if old_btn not in html:
            c = html.count("Ver query")
            # replace only in ord half - last few Ver query for scenario
            # Change modal subtitle default
            pass
        print("  Ver query count", html.count("Ver query"))

    # Label Fuente SEED → Evidencia when not REAL
    html = html.replace(
        "Fuente · ${fuente === &#x27;REAL&#x27; ? &#x27;REAL&#x27; : &#x27;SEED&#x27;}",
        "Fuente · ${fuente === &#x27;REAL&#x27; ? &#x27;REAL&#x27; : &#x27;Evidencia&#x27;}",
    )
    html = html.replace(
        "Fuente · ${fuente === 'REAL' ? 'REAL' : 'SEED'}",
        "Fuente · ${fuente === 'REAL' ? 'REAL' : 'Evidencia'}",
    )

    # sec-label Caso → Recorrido (if still Caso)
    html = html.replace(
        "&lt;span class=&quot;sec-label&quot;&gt;Caso&lt;/span&gt;",
        "&lt;span class=&quot;sec-label&quot;&gt;Recorrido (ya ejecutado)&lt;/span&gt;",
        1,
    )

    # Modal subtitle
    html = html.replace(
        "title || &#x27;Validación en dba_rncr_batch&#x27;",
        "title || &#x27;Consulta de evidencia&#x27;",
    )

    bak = path.with_suffix(path.suffix + ".bak_ws_evid")
    if not bak.exists():
        shutil.copy2(path, bak)
    path.write_text(html, encoding="utf-8")
    print(f"OK {path.name}: {n} escenarios")


def main():
    for p in PATHS:
        if p.exists():
            patch_file(p)


if __name__ == "__main__":
    main()
