# -*- coding: utf-8 -*-
"""Reescribe guión + ejemplos del HTML #ord al estilo workshop (texto para decir)."""
from __future__ import annotations

import json
import re
import shutil
from html import escape, unescape
from pathlib import Path

PATHS = [
    Path(
        r"C:\Users\C32525E\Downloads\PAQUETE_UNIFICACION_BDM_STAGE_2026-07-23"
        r"\PAQUETE_UNIFICACION_BDM_STAGE\Documentacion\RECONOCER_TODO_EN_UNO.html"
    ),
    Path(
        r"C:\Users\C32525E\Downloads\demo_unificacion_completa (2)"
        r"\db_rcncr_btch_rdshft_dt\docs\RECONOCER_TODO_EN_UNO.html"
    ),
]

GUION = [
    {
        "paso": "0",
        "titulo": "Abrir con el id en la mano",
        "decir": (
            "Hoy no vamos a hablar de ‘el sistema en abstracto’. "
            "Vamos a tomar personas del SP mock —ids 20001 a 20014— "
            "y en cada pestaña decimos: esta es la persona, esta es la regla, "
            "¿qué deberíamos ver?, corremos la query, y cerramos si la regla se cumple. "
            "Antes de cada ejemplo: CALL bdm_stage.sp_ordenamiento_ejecucion_mock();"
        ),
    },
    {
        "paso": "1",
        "titulo": "Unificación vs Ordenamiento",
        "decir": (
            "Unificación ya respondió: ¿estas direcciones son la misma? "
            "Si sí, hay un padre ganador y una hija que deja de competir. "
            "Ordenamiento responde otra pregunta: si la persona tiene varias "
            "direcciones/teléfonos/celulares/emails vigentes, ¿cuál intento primero? "
            "No mezclamos canales: DIR, TEL, CEL y EMA se rankean aparte."
        ),
    },
    {
        "paso": "2",
        "titulo": "Regla de oro — solo ganadoras",
        "decir": (
            "Antes de mirar el score, miramos si la RPU es ganadora. "
            "Si ind_unificacion = 1 (hija), la regla dice: no score, no orden. "
            "Si es ganadora, recién ahí calculamos score con betas del catálogo RITM "
            "y el mayor score del canal se lleva el lugar 1."
        ),
    },
    {
        "paso": "3",
        "titulo": "Cómo leer cada tarjeta",
        "decir": (
            "En cada escenario verás: (1) el id_buro del SP, (2) la regla de negocio "
            "en lenguaje de mesa, (3) los pasos ‘qué digo / qué miro’, "
            "(4) la tablita del ejemplo, (5) el guión para decir en voz alta, "
            "y (6) la conclusión. La query del botón Ver query es exactamente "
            "el mismo seed del SP."
        ),
    },
    {
        "paso": "4",
        "titulo": "Recorrido de la demo (5 minutos)",
        "decir": (
            "Orden sugerido: 20001 casa vs oficina (RANK-01) → 20011 padre/hija (F3) → "
            "20010 empate → 20004 TEL válido vs no válido → 20013 TEL020 no mueve → "
            "20012 CEL default → 20014 EMA excluidas → salida orden_prioridad en 20001."
        ),
    },
    {
        "paso": "5",
        "titulo": "Qué ya cerramos en DEV",
        "decir": (
            "Opción A EDF, 47 betas RITM, 0 hijas mal ordenadas, fórmulas TEL/EMA/CEL "
            "alineadas a Características. El mock SPA cubre CA-O01…CA-O12 para que "
            "el workshop no dependa de que el datashare traiga el Caso A/B histórico."
        ),
    },
    {
        "paso": "6",
        "titulo": "Cierre — qué pedimos a la mesa",
        "decir": (
            "Validar con la query de cada tarjeta que el ejemplo del SP se ve igual "
            "en bdm_stage. Si el veredicto del validar_mock es PASSED_ALL, el paquete "
            "mock está listo para QA. Paridad numérica Teradata (MIG-01) queda aparte."
        ),
    },
]


def pasos_decir(title: str, rows: list[list[str]]) -> dict:
    return {
        "title": title,
        "headers": ["Paso", "Qué dices en la mesa", "Qué miras en la query"],
        "rows": rows,
    }


# Narrativas por _pack_code
NARR = {
    "RESUMEN": {
        "_busca": (
            "Después de R1/R2/R3, el negocio necesita saber qué contacto intentar primero. "
            "Ordenamiento solo trabaja sobre ganadoras y rankea cada canal por separado "
            "con un score relativo (suma de características × beta), no una probabilidad."
        ),
        "_dev": (
            "Abrimos así: ‘Unificación ya unió lo que era la misma dirección. "
            "Ahora tomamos solo las ganadoras y preguntamos: si María tiene casa y oficina, "
            "¿cuál llamo primero?’. Mostramos el catálogo del SP: personas 20001–20014. "
            "Decimos que cada tarjeta del workshop usa exactamente esos ids."
        ),
        "_conclusion_regla": (
            "Conclusión para la mesa: unificación decide quién compite; "
            "ordenamiento decide el orden de intento. El seed mock es la verdad del demo."
        ),
        "_tabla_pasos": pasos_decir(
            "Guión corto — cómo abrir el tema",
            [
                [
                    "1",
                    "¿Son la misma dirección? → eso ya lo resolvió Unificación.",
                    "Padre ganador / hija ind_unificacion=1",
                ],
                [
                    "2",
                    "Si hay varias ganadoras, ¿cuál contacto primero?",
                    "Scores y lugar por canal (DIR/TEL/CEL/EMA)",
                ],
                [
                    "3",
                    "Los canales no se mezclan: un lugar 1 de TEL no pelea con DIR.",
                    "mock_ord_score filtrado por canal",
                ],
            ],
        ),
        "Qué espera (negocio)": (
            "Priorizar contactos por canal con score relativo, solo sobre ganadoras."
        ),
        "Qué encontramos DEV": (
            "Catálogo SP mock 20001–20014 listo; en DEV real hay cientos de miles de ganadoras."
        ),
        "Ejemplo verificable (reporte + ID + query)": (
            "SP mock: SELECT * FROM bdm_stage.mock_ord_escenario WHERE es_html_ejemplo=1;"
        ),
    },
    "DIR-RANK": {
        "_busca": (
            "RANK-01: si una persona tiene varias direcciones ganadoras, "
            "la de mayor score DIR debe quedar en lugar 1 y alimentar orden_prioridad."
        ),
        "_dev": (
            "Tomamos a la persona id_buro_persona = 20001. "
            "La regla nos pide: entre sus direcciones ganadoras, ¿cuál es la ganadora del ranking? "
            "Miramos mock_ord_score canal DIR: la etiqueta ‘casa’ (RPU 91001) tiene score 850 → lugar 1; "
            "‘oficina’ (RPU 91002) tiene 700 → lugar 2. "
            "Entonces sí: la regla se cumple — casa es la que contactamos primero. "
            "Además notamos que la misma persona puede tener TEL/EMA lugar 1; eso no compite con DIR."
        ),
        "_conclusion_regla": (
            "Persona 20001: casa gana (850/lugar 1), oficina segundo (700/lugar 2). "
            "RANK-01 OK · mismo seed del SP · CA-O04."
        ),
        "_tabla_pasos": pasos_decir(
            "RANK-01 — cómo lo explicas (persona 20001)",
            [
                [
                    "1",
                    "Tenemos la persona 20001 con dos direcciones vigentes: casa y oficina.",
                    "mock_ord_rpu WHERE id_buro_persona=20001",
                ],
                [
                    "2",
                    "La regla dice: gana la de mayor score DIR.",
                    "mock_ord_score canal='DIR'",
                ],
                [
                    "3",
                    "Vemos casa=850 lugar 1 y oficina=700 lugar 2 → casa es la primera a contactar.",
                    "lugar ASC",
                ],
                [
                    "4",
                    "Ese lugar 1 debe quedar persistido en orden_prioridad (salida).",
                    "mock_ord_prioridad RPU 91001=1",
                ],
            ],
        ),
        "_tabla_ejemplo": {
            "title": "Persona 20001 — casa vs oficina (mismo seed del SP)",
            "headers": ["Etiqueta", "RPU", "Score DIR", "Lugar", "orden_prioridad", "¿Gana?"],
            "rows": [
                ["casa", "91001", "850.0000", "1", "1", "Sí — contactar primero"],
                ["oficina", "91002", "700.0000", "2", "2", "Segundo intento"],
            ],
        },
        "Qué espera (negocio)": (
            "Mayor score DIR → lugar 1 → orden_prioridad = 1."
        ),
        "Qué encontramos DEV": (
            "SP mock 20001: casa 850/1 · oficina 700/2."
        ),
        "Ejemplo verificable (reporte + ID + query)": (
            "id_buro_persona=20001 · casa RPU 91001 score 850 lugar 1; oficina 91002 score 700 lugar 2."
        ),
    },
    "ELEG-HIJA": {
        "_busca": (
            "F3-02: si una RPU es hija de unificación (ind_unificacion=1), "
            "no recibe score ni orden_prioridad. Solo el padre ganador compite."
        ),
        "_dev": (
            "Tomamos la persona id_buro_persona = 20011. "
            "Aquí Unificación ya marcó: RPU 91018 es el padre ganador y RPU 91019 es la hija. "
            "La regla de ordenamiento nos pide revisar: ¿la hija aparece con score o con orden? "
            "Abrimos mock_ord_score y mock_ord_prioridad filtrando 20011: "
            "el padre tiene DIR 639.7849 lugar 1 y orden_prioridad=1; "
            "la hija no tiene ninguna fila. "
            "Entonces la regla se cumple: la hija no compite; el negocio contacta al padre."
        ),
        "_conclusion_regla": (
            "Persona 20011: padre 91018 con score y orden; hija 91019 sin score ni orden. "
            "F3-02 OK · CA-O05 / CA-O03."
        ),
        "_tabla_pasos": pasos_decir(
            "F3-02 — cómo lo explicas (persona 20011)",
            [
                [
                    "1",
                    "Esta persona unificó dos direcciones: hay padre y hay hija.",
                    "mock_ord_rpu: 91018 ind NULL · 91019 ind=1",
                ],
                [
                    "2",
                    "Antes de hablar de score, la regla pregunta: ¿es ganadora?",
                    "Solo ind_unificacion IS NULL (o ≠1) compite",
                ],
                [
                    "3",
                    "Vemos que la hija NO tiene filas de score ni de orden → correcta exclusión.",
                    "COUNT(*) hija = 0 en score y prioridad",
                ],
                [
                    "4",
                    "El padre sí tiene lugar 1: es a quien contactamos.",
                    "91018 orden_prioridad=1",
                ],
            ],
        ),
        "_tabla_ejemplo": {
            "title": "Persona 20011 — padre gana / hija fuera",
            "headers": ["Rol", "RPU", "ind_unificacion", "Score DIR", "orden_prioridad", "¿Compite?"],
            "rows": [
                ["padre_ganador", "91018", "NULL", "639.7849", "1", "Sí"],
                ["hija_unif", "91019", "1", "(sin fila)", "(sin fila)", "No"],
            ],
        },
        "Qué espera (negocio)": (
            "Hija ind_unificacion=1 sin score ni orden; solo el padre."
        ),
        "Qué encontramos DEV": (
            "SP mock 20011: padre con score/orden; hija 0 filas."
        ),
        "Ejemplo verificable (reporte + ID + query)": (
            "id_buro=20011 · padre 91018 DIR=639.7849 orden=1 · hija 91019 sin filas."
        ),
    },
    "DIR-EMPATE": {
        "_busca": (
            "RANK-02: si dos direcciones quedan con el mismo score, "
            "no inventamos un desempate de negocio nuevo; usamos ROW_NUMBER del motor "
            "y cualquier diferencia vs baseline se registra como hallazgo de certificación."
        ),
        "_dev": (
            "Tomamos la persona id_buro_persona = 20010. "
            "Tiene dos direcciones, empate_a (91016) y empate_b (91017), "
            "ambas con score DIR = 777.0000. "
            "La regla nos pide: ¿cómo se asignan los lugares cuando el score empató? "
            "Vemos lugar 1 y lugar 2 aunque el score sea idéntico — eso es el ROW_NUMBER. "
            "En la mesa decimos: ‘no hay criterio funcional nuevo de desempate en esta migración; "
            "si Teradata y Redshift difieren solo por empate, lo documentamos’."
        ),
        "_conclusion_regla": (
            "Persona 20010: score empatado 777/777 → lugares 1 y 2 por ROW_NUMBER. "
            "RANK-02 OK · CA-O08 · sin inventar desempate."
        ),
        "_tabla_pasos": pasos_decir(
            "Empate — cómo lo explicas (persona 20010)",
            [
                [
                    "1",
                    "Misma persona, dos direcciones con el mismo score 777.",
                    "mock_ord_score id=20010",
                ],
                [
                    "2",
                    "La regla no pide un ‘tie-break’ de negocio nuevo.",
                    "Doc v2.0 / baseline",
                ],
                [
                    "3",
                    "Aun así el ranking entrega lugar 1 y 2 (ROW_NUMBER).",
                    "lugar 1 en 91016 · lugar 2 en 91017",
                ],
                [
                    "4",
                    "Si en paridad TD↔RS solo cambia el empate → hallazgo, no bug de fórmula.",
                    "Registrar en certificación",
                ],
            ],
        ),
        "_tabla_ejemplo": {
            "title": "Persona 20010 — empate de score",
            "headers": ["Etiqueta", "RPU", "Score DIR", "Lugar", "Nota"],
            "rows": [
                ["empate_a", "91016", "777.0000", "1", "Mismo score — ROW_NUMBER"],
                ["empate_b", "91017", "777.0000", "2", "Mismo score — segundo"],
            ],
        },
        "Qué espera (negocio)": (
            "Empate: sin desempate funcional nuevo; ROW_NUMBER del motor."
        ),
        "Qué encontramos DEV": (
            "SP mock 20010: ambos score 777 → lugares 1 y 2."
        ),
        "Ejemplo verificable (reporte + ID + query)": (
            "id_buro=20010 · 91016 y 91017 score 777 · lugares 1 y 2."
        ),
    },
    "TEL-RANK": {
        "_busca": (
            "Canal TEL es independiente de DIR: se agrupa por número/contacto fijo, "
            "se rankea solo entre TEL, y no escribe orden_prioridad en la RPU "
            "(eso es exclusivo del canal DIR)."
        ),
        "_dev": (
            "Tomamos la persona id_buro_persona = 20004. "
            "Tiene dos teléfonos fijos: uno marcado VÁLIDO (score 420, lugar 1) "
            "y otro NO VÁLIDO (score 210, lugar 2). "
            "La regla nos pide: ¿cuál fijo intento primero? "
            "Claramente el válido. "
            "Y subrayamos: esta persona también puede tener un DIR lugar 1; "
            "eso no se compara con el 420 del TEL — son rankings aparte."
        ),
        "_conclusion_regla": (
            "Persona 20004: TEL válido 420/lugar 1 · NO VÁLIDO 210/lugar 2. "
            "Canal independiente de DIR · CA-O06."
        ),
        "_tabla_pasos": pasos_decir(
            "TEL — cómo lo explicas (persona 20004)",
            [
                [
                    "1",
                    "Persona 20004 con dos fijos: uno válido y uno no válido.",
                    "mock_ord_score canal='TEL' id=20004",
                ],
                [
                    "2",
                    "La regla rankea solo dentro de TEL: mayor score → lugar 1.",
                    "420 vs 210",
                ],
                [
                    "3",
                    "El válido gana; es el primer fijo a intentar.",
                    "lugar 1 en tel_valida_dir",
                ],
                [
                    "4",
                    "No mezclar con DIR: el orden_prioridad de la RPU viene de DIR, no de TEL.",
                    "Separar canales en la explicación",
                ],
            ],
        ),
        "_tabla_ejemplo": {
            "title": "Persona 20004 — TEL válido vs no válido",
            "headers": ["Etiqueta", "Score TEL", "Lugar", "Lectura en mesa"],
            "rows": [
                ["tel_valida_dir", "420.0000", "1", "Primer fijo a contactar"],
                ["tel_novalida_dir", "210.0000", "2", "Segundo / menor prioridad"],
            ],
        },
        "Qué espera (negocio)": (
            "TEL independiente de DIR; mayor score TEL → lugar 1."
        ),
        "Qué encontramos DEV": (
            "SP mock 20004: 420/1 vs 210/2."
        ),
        "Ejemplo verificable (reporte + ID + query)": (
            "id_buro=20004 · TEL 420 lugar 1 · 210 lugar 2."
        ),
    },
    "TEL-02": {
        "_busca": (
            "TEL-02: la característica TEL020 (coincidencia geo) se puede calcular "
            "para trazabilidad, pero NO debe entrar a la sumatoria del score. "
            "Si solo cambia TEL020, el score final debe ser el mismo."
        ),
        "_dev": (
            "Tomamos la persona id_buro_persona = 20013. "
            "Tiene dos contactos TEL: ‘tel_base’ y ‘tel_solo_tel020’. "
            "La diferencia entre ellos es solo TEL020. "
            "La regla nos pide: ¿el score se movió? "
            "Miramos: ambos quedan en 376.5000. "
            "Entonces sí — TEL020 está fuera de la suma, como en el baseline Teradata. "
            "Los lugares 1 y 2 son solo orden técnico; el punto de negocio es el score idéntico."
        ),
        "_conclusion_regla": (
            "Persona 20013: mismo score 376.5 aunque solo cambie TEL020. "
            "TEL020 fuera de la suma · CA-O09."
        ),
        "_tabla_pasos": pasos_decir(
            "TEL-02 — cómo lo explicas (persona 20013)",
            [
                [
                    "1",
                    "Dos contactos TEL de la persona 20013; uno solo ‘enciende’ TEL020.",
                    "mock_ord_score id=20013",
                ],
                [
                    "2",
                    "La regla de negocio: TEL020 no suma al score final.",
                    "Características / Sumatoria_Score_Tel",
                ],
                [
                    "3",
                    "Vemos score idéntico 376.5 y 376.5 → la regla se cumple.",
                    "Comparar las dos filas",
                ],
                [
                    "4",
                    "Si alguien pide ‘que TEL020 mueva el ranking’, eso sería cambio de baseline, no bug.",
                    "Dejar claro el alcance",
                ],
            ],
        ),
        "_tabla_ejemplo": {
            "title": "Persona 20013 — TEL020 no mueve el score",
            "headers": ["Etiqueta", "Score TEL", "Lugar", "Lectura"],
            "rows": [
                ["tel_base", "376.5000", "1", "Base"],
                ["tel_solo_tel020", "376.5000", "2", "Mismo score pese a TEL020"],
            ],
        },
        "Qué espera (negocio)": (
            "TEL020 fuera de la sumatoria; score invariante si solo cambia TEL020."
        ),
        "Qué encontramos DEV": (
            "SP mock 20013: ambos 376.5."
        ),
        "Ejemplo verificable (reporte + ID + query)": (
            "id_buro=20013 · scores TEL idénticos 376.5."
        ),
    },
    "CEL-02": {
        "_busca": (
            "CEL-02: el operador se toma del prefijo (LEFT celular,3). "
            "Si el prefijo no está en el catálogo, Redshift usa default 0.22 "
            "(doc v2.0), no deja el contacto en cero como el comportamiento viejo de TD."
        ),
        "_dev": (
            "Tomamos la persona id_buro_persona = 20012. "
            "Su celular tiene prefijo 999 — a propósito no está en el catálogo. "
            "La regla nos pide: ¿qué valor de operador aplica? "
            "En Redshift: COALESCE(catálogo, 0.22) → score CEL 220.0000 lugar 1. "
            "En la mesa decimos: ‘prefijo desconocido no se cae a 0; usa el default acordado 0.22’."
        ),
        "_conclusion_regla": (
            "Persona 20012: prefijo 999 sin catálogo → default 0.22 → score 220 lugar 1. "
            "CEL-02 OK · CA-O11."
        ),
        "_tabla_pasos": pasos_decir(
            "CEL-02 — cómo lo explicas (persona 20012)",
            [
                [
                    "1",
                    "Persona 20012 con un celular de prefijo 999 (no mapeado).",
                    "mock_ord_rpu / score id=20012",
                ],
                [
                    "2",
                    "La regla: LEFT(celular,3) → catálogo; si no hay fila, default 0.22.",
                    "catalogo_operador_ord_cel",
                ],
                [
                    "3",
                    "Vemos score 220 lugar 1 → el default se aplicó.",
                    "mock_ord_score canal='CEL'",
                ],
                [
                    "4",
                    "Diferencia consciente vs TD viejo (que podía dejar 0): es doc v2.0.",
                    "Explicar semántica acordada",
                ],
            ],
        ),
        "_tabla_ejemplo": {
            "title": "Persona 20012 — operador no mapeado",
            "headers": ["Etiqueta", "Prefijo", "Score CEL", "Lugar", "Lectura"],
            "rows": [
                ["cel_prefijo_999", "999", "220.0000", "1", "Default 0.22 aplicado"],
            ],
        },
        "Qué espera (negocio)": (
            "Prefijo sin catálogo → COALESCE(..., 0.22)."
        ),
        "Qué encontramos DEV": (
            "SP mock 20012: score CEL 220."
        ),
        "Ejemplo verificable (reporte + ID + query)": (
            "id_buro=20012 · CEL score 220 (default 0.22)."
        ),
    },
    "EMA-03": {
        "_busca": (
            "EMA-03: EMA003 / EMA007 / EMA018 / EMA025 se pueden calcular para trazabilidad, "
            "pero no deben entrar a la sumatoria del score de email. "
            "Si solo cambian esas, el score final debe ser idéntico."
        ),
        "_dev": (
            "Tomamos la persona id_buro_persona = 20014. "
            "Dos emails: ‘ema_base’ y ‘ema_solo_excluidas’ (solo cambian características fuera de suma). "
            "La regla nos pide: ¿el ranking se movió por esas variables? "
            "Miramos: ambos score EMA = 281.7705. "
            "Entonces la regla se cumple — esas variables no empujan el lugar."
        ),
        "_conclusion_regla": (
            "Persona 20014: mismo score 281.7705 aunque solo cambien EMA003/007. "
            "Fuera de suma · CA-O10."
        ),
        "_tabla_pasos": pasos_decir(
            "EMA-03 — cómo lo explicas (persona 20014)",
            [
                [
                    "1",
                    "Persona 20014 con dos emails; el segundo solo enciende variables excluidas.",
                    "mock_ord_score id=20014 canal='EMA'",
                ],
                [
                    "2",
                    "La regla: EMA003/007/018/025 no suman al score final.",
                    "Sumatoria_Score_Email / Características",
                ],
                [
                    "3",
                    "Vemos 281.7705 = 281.7705 → no movieron el ranking.",
                    "Comparar las dos filas",
                ],
                [
                    "4",
                    "Sirven para trazabilidad, no para decidir quién es lugar 1.",
                    "Mensaje claro a negocio/QA",
                ],
            ],
        ),
        "_tabla_ejemplo": {
            "title": "Persona 20014 — excluidas no mueven score",
            "headers": ["Etiqueta", "Score EMA", "Lugar", "Lectura"],
            "rows": [
                ["ema_base", "281.7705", "1", "Base"],
                ["ema_solo_excluidas", "281.7705", "2", "Mismo score pese a EMA003/007"],
            ],
        },
        "Qué espera (negocio)": (
            "EMA003/007/018/025 fuera de suma; score invariante."
        ),
        "Qué encontramos DEV": (
            "SP mock 20014: ambos 281.7705."
        ),
        "Ejemplo verificable (reporte + ID + query)": (
            "id_buro=20014 · scores EMA idénticos 281.7705."
        ),
    },
    "CONSOL": {
        "_busca": (
            "Salida: el lugar del canal DIR de cada RPU ganadora se persiste "
            "como orden_prioridad. Las hijas no reciben fila."
        ),
        "_dev": (
            "Volvemos a la persona id_buro_persona = 20001 — la misma del RANK-01. "
            "Ya vimos que casa quedó lugar 1 y oficina lugar 2. "
            "Ahora la regla de salida nos pide: ¿eso quedó grabado en orden_prioridad? "
            "Abrimos mock_ord_prioridad: RPU 91001 → 1, RPU 91002 → 2. "
            "Cerramos el hilo: ‘el score decide el lugar; el lugar se materializa aquí "
            "para que el consumidor sepa el orden de intento’."
        ),
        "_conclusion_regla": (
            "Persona 20001: orden_prioridad casa=1 · oficina=2. "
            "Salida alineada al ranking DIR · CA-O07."
        ),
        "_tabla_pasos": pasos_decir(
            "Salida — cómo lo explicas (persona 20001)",
            [
                [
                    "1",
                    "Partimos del ranking DIR que ya vimos (casa 1 / oficina 2).",
                    "mock_ord_score canal DIR",
                ],
                [
                    "2",
                    "La regla de salida: persistir ese lugar en orden_prioridad.",
                    "mock_ord_prioridad",
                ],
                [
                    "3",
                    "Confirmamos 91001=1 y 91002=2 — mismo orden que el score.",
                    "JOIN score ↔ prioridad",
                ],
                [
                    "4",
                    "Recordar: hijas no aparecen aquí (ver persona 20011).",
                    "Sin fila para ind_unificacion=1",
                ],
            ],
        ),
        "_tabla_ejemplo": {
            "title": "Persona 20001 — orden_prioridad = lugar DIR",
            "headers": ["RPU", "Score DIR", "Lugar", "orden_prioridad", "¿Cuadra?"],
            "rows": [
                ["91001", "850.0000", "1", "1", "Sí"],
                ["91002", "700.0000", "2", "2", "Sí"],
            ],
        },
        "Qué espera (negocio)": (
            "orden_prioridad = lugar DIR de la RPU ganadora."
        ),
        "Qué encontramos DEV": (
            "SP mock 20001: prioridad 1 y 2 alineadas al ranking."
        ),
        "Ejemplo verificable (reporte + ID + query)": (
            "id_buro=20001 · prioridad 91001=1 · 91002=2."
        ),
    },
    "ELEG-BLOQ": {
        "_busca": (
            "Datos NO VÁLIDOS / bloqueos: no deben quedar como mejor opción de contacto "
            "frente a un contacto válido del mismo canal."
        ),
        "_dev": (
            "Usamos de puente la persona 20004 (TEL): el fijo NO VÁLIDO queda en lugar 2 "
            "con score más bajo. En la mesa: ‘si el dato está bloqueado o no válido, "
            "no es el primero que intento’."
        ),
        "_conclusion_regla": (
            "Referencia SP 20004: NO VÁLIDO pierde contra VÁLIDO en el mismo canal."
        ),
        "_tabla_pasos": pasos_decir(
            "Bloqueos / NO VÁLIDO — lectura en mesa",
            [
                [
                    "1",
                    "Primero identificamos el contacto válido vs el no válido.",
                    "Persona 20004 TEL",
                ],
                [
                    "2",
                    "La regla: el no válido no puede quedar lugar 1 si hay uno válido mejor.",
                    "Scores 420 vs 210",
                ],
                [
                    "3",
                    "Confirmamos lugar 2 para el no válido.",
                    "mock_ord_score",
                ],
            ],
        ),
    },
}


def extract_json_object(html: str, start: int) -> tuple[dict, int, int]:
    """start apunta al primer '{' del objeto JS escapado con &quot;."""
    j = start
    depth = 0
    in_q = False
    while j < len(html):
        if html.startswith("&quot;", j):
            in_q = not in_q
            j += 6
            continue
        ch = html[j]
        if not in_q:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
        j += 1
    raw = html[start:j]
    data = json.loads(unescape(raw))
    return data, start, j


def to_html_json(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    # Escape like the existing DATA blocks (attribute/text with &quot;)
    return escape(raw, quote=True).replace("&#x27;", "'")


def patch_renderer(html: str) -> str:
    """Etiqueta del bloque _dev → Guión workshop."""
    old = (
        "const devBlock = dev ? `&lt;div class=&quot;scenario-section dev-narrative&quot;&gt;"
        "&lt;span class=&quot;sec-label&quot;&gt;Qué encontramos en DEV&lt;/span&gt;"
        "&lt;p&gt;${esc(dev)}&lt;/p&gt;&lt;/div&gt;` : &#x27;&#x27;;"
    )
    new = (
        "const devBlock = dev ? `&lt;div class=&quot;scenario-section dev-narrative&quot;&gt;"
        "&lt;span class=&quot;sec-label&quot;&gt;Guión workshop (leer en voz alta)&lt;/span&gt;"
        "&lt;p&gt;${esc(dev)}&lt;/p&gt;&lt;/div&gt;` : &#x27;&#x27;;"
    )
    if old in html:
        html = html.replace(old, new, 1)
    else:
        # try unescaped form if file is raw
        old2 = (
            'const devBlock = dev ? `<div class="scenario-section dev-narrative">'
            '<span class="sec-label">Qué encontramos en DEV</span>'
            "<p>${esc(dev)}</p></div>` : '';"
        )
        new2 = (
            'const devBlock = dev ? `<div class="scenario-section dev-narrative">'
            '<span class="sec-label">Guión workshop (leer en voz alta)</span>'
            "<p>${esc(dev)}</p></div>` : '';"
        )
        if old2 in html:
            html = html.replace(old2, new2, 1)
        else:
            print("WARN: no se encontró etiqueta devBlock para renombrar")
    # Banner tip
    old_banner = (
        "Empieza por el &lt;strong&gt;guión §0&lt;/strong&gt;; luego pestañas "
        "Fase 1 → DIR → TEL → CEL → EMA → Salida → SPs."
    )
    new_banner = (
        "Empieza por el &lt;strong&gt;guión §0&lt;/strong&gt; (texto para decir). "
        "En cada tarjeta: persona + id → regla → qué miras → conclusión. "
        "Recorrido: 20001 → 20011 → 20010 → 20004 → 20013 → 20012 → 20014 → salida."
    )
    if old_banner in html:
        html = html.replace(old_banner, new_banner, 1)
    return html


def patch_file(path: Path) -> None:
    html = path.read_text(encoding="utf-8")
    positions = [m.end() for m in re.finditer(r"const DATA = ", html)]
    if len(positions) < 2:
        raise SystemExit(f"{path}: se esperaban 2 bloques DATA, hay {len(positions)}")

    # Solo el bloque de ordenamiento (segundo)
    start_scan = positions[1]
    while start_scan < len(html) and html[start_scan] in " \t\n\r":
        start_scan += 1
    data, start, end = extract_json_object(html, start_scan)

    data["guion_sesion"] = GUION
    data["generated"] = "2026-09-24"

    updated = 0
    for row in data.get("rows") or []:
        code = row.get("_pack_code")
        if code not in NARR:
            continue
        patch = NARR[code]
        for k, v in patch.items():
            row[k] = v
        # mantener _conclusion alineada
        if "_conclusion_regla" in patch:
            row["_conclusion"] = patch["_conclusion_regla"]
        updated += 1

    new_json = to_html_json(data)
    html = html[:start] + new_json + html[end:]
    html = patch_renderer(html)

    bak = path.with_suffix(path.suffix + ".bak_workshop_narr")
    if not bak.exists():
        shutil.copy2(path, bak)
    path.write_text(html, encoding="utf-8")
    print(f"OK {path.name}: {updated} escenarios + guión")


def main() -> None:
    for p in PATHS:
        if not p.exists():
            print("SKIP missing", p)
            continue
        patch_file(p)


if __name__ == "__main__":
    main()
