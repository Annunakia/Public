-- Orquestador ejecución — unificación por regla (cada regla llama sus escenarios)
TRUNCATE TABLE bdm_datos.unificacion_direccion;

CALL bdm_datos.sp_unificacion_regla1();
CALL bdm_datos.sp_unificacion_regla2();
CALL bdm_datos.sp_unificacion_regla3();
