-- Orquestador DT — ordenamiento post-unificación (R1/R2/R3 previos)
-- Precondición: vistas edf_views + unificación ya ejecutada
CALL bdm_datos.sp_ordenamiento_ejecucion_edf(TRUE);
