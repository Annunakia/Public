-- ============================================================
-- Criterios de aceptación Ordenamiento — Modo A REAL
-- Par: docs/CRITERIOS_ACEPTACION_ORDENAMIENTO_REAL_Y_MOCK.md
-- Mock equivalente: docs/sql_qa_ordenamiento_mock/03_validar_criterios_mock.sql
-- ============================================================

-- CA-O01 scores por canal
SELECT 'CA-O01' AS criterio_ca, canal, COUNT(*)::BIGINT AS scores
FROM bdm_datos.score_ordenamiento
GROUP BY 1, 2 ORDER BY 2;
-- Esperado: DIR/TEL/EMA > 0; CEL puede ser bajo

-- CA-O02 betas 47
SELECT 'CA-O02' AS criterio_ca, COUNT(*)::BIGINT AS n_betas
FROM bdm_datos.beta_ordenamiento;
-- Esperado: 47

-- CA-O03 hijas con orden = 0
SELECT 'CA-O03' AS criterio_ca, COUNT(*)::BIGINT AS hijas_con_orden_incorrecto
FROM bdm_datos.relacion_persona_ubicacion
WHERE COALESCE(ind_unificacion, 0) = 1
  AND orden_prioridad IS NOT NULL;
-- Esperado: 0

-- CA-O04 RANK-01 (Caso B si existe)
SELECT 'CA-O04' AS criterio_ca, cod_dw_persona_ubic AS rpu, score, lugar
FROM bdm_datos.score_ordenamiento
WHERE id_buro_persona = 2848501447849812647 AND canal = 'DIR'
ORDER BY lugar;
-- Esperado: lugar 1 = score máximo; 2 filas
-- Si 0 filas → N/A en REAL; cubrir con MOCK persona 20001

-- CA-O05 F3-02 (Caso A hija 3)
SELECT 'CA-O05' AS criterio_ca, COUNT(*)::BIGINT AS scores_hija
FROM bdm_datos.score_ordenamiento
WHERE cod_dw_persona_ubic = 3;
-- Esperado: 0

-- CA-O06 canales Caso A
SELECT 'CA-O06' AS criterio_ca, canal, score, lugar
FROM bdm_datos.score_ordenamiento
WHERE id_buro_persona = 3228096126421495389
ORDER BY canal, lugar;

-- CA-O07 orden = lugar DIR Caso B
SELECT 'CA-O07' AS criterio_ca, o.cod_dw_persona_ubic AS rpu,
       o.orden_prioridad, s.lugar, s.score
FROM bdm_datos.rpu_orden_prioridad o
JOIN bdm_datos.score_ordenamiento s
  ON s.cod_dw_persona_ubic = o.cod_dw_persona_ubic
 AND s.id_buro_persona = o.id_buro_persona
 AND s.canal = 'DIR'
WHERE o.id_buro_persona = 2848501447849812647
ORDER BY o.orden_prioridad;

-- CA-O08 empate (puede ser 0 filas en REAL → N/A; MOCK 20010 obligatorio)
SELECT 'CA-O08' AS criterio_ca, id_buro_persona, score, COUNT(*) AS n
FROM bdm_datos.score_ordenamiento
WHERE canal = 'DIR'
GROUP BY 1, 2
HAVING COUNT(*) > 1
LIMIT 20;

-- CA-O09 / CA-O10: en REAL = evidencia de SP + betas (sin contrafactual persona)
SELECT 'CA-O09' AS criterio_ca, codigo_variable, valor_beta
FROM bdm_datos.beta_ordenamiento
WHERE canal = 'TEL' AND codigo_variable ILIKE '%TEL020%';

SELECT 'CA-O10' AS criterio_ca, codigo_variable, valor_beta
FROM bdm_datos.beta_ordenamiento
WHERE canal = 'EMA'
  AND (codigo_variable ILIKE '%EMA003%' OR codigo_variable ILIKE '%EMA007%'
       OR codigo_variable ILIKE '%EMA018%' OR codigo_variable ILIKE '%EMA025%');
-- PASSED de aislamiento persona → MOCK 20013 / 20014

-- CA-O11 CEL cobertura A/B (puede 0 → N/A; MOCK 20012 obligatorio)
SELECT 'CA-O11' AS criterio_ca, id_buro_persona, score, lugar
FROM bdm_datos.score_ordenamiento
WHERE canal = 'CEL'
  AND id_buro_persona IN (3228096126421495389, 2848501447849812647);

-- CA-O12 multi-DIR (Caso B = 2; MOCK 20003 = 3)
SELECT 'CA-O12' AS criterio_ca, COUNT(*)::BIGINT AS n_dir
FROM bdm_datos.score_ordenamiento
WHERE id_buro_persona = 2848501447849812647 AND canal = 'DIR';
