-- ============================================================
-- run_ordenamiento_ejecucion_mock.sql
-- Modo B: CALL mock + lectura veredicto CA
-- Pre: STRCT 05_ddl + PGM SPs mock + betas 47 en bdm_datos
-- ============================================================

CALL bdm_stage.sp_ordenamiento_ejecucion_mock();

SELECT criterio_ca, estado, detalle
FROM bdm_stage.mock_ord_ca_result
ORDER BY criterio_ca;

SELECT
  CASE WHEN SUM(CASE WHEN estado = 'FAILED' THEN 1 ELSE 0 END) = 0
       THEN 'PASSED_ALL' ELSE 'FAILED_SOME' END AS veredicto_mock,
  SUM(CASE WHEN estado = 'PASSED' THEN 1 ELSE 0 END) AS passed,
  SUM(CASE WHEN estado = 'FAILED' THEN 1 ELSE 0 END) AS failed
FROM bdm_stage.mock_ord_ca_result;
