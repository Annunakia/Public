-- ============================================================
-- E2E Reconocer — Unificación (R1→R2→R3) + Ordenamiento EDF
-- Ambiente: consumidor dba_rncr_batch · schemas bdm_datos / bdm_tempo
-- Precondición: deploy STRCT + PGM ya aplicados; Data Sharing OK
-- NO mezclar path mock (bdm_stage) en esta corrida
-- ============================================================

-- 1) Unificación
TRUNCATE TABLE bdm_datos.unificacion_direccion;
CALL bdm_datos.sp_unificacion_regla1();
CALL bdm_datos.sp_unificacion_regla2();
CALL bdm_datos.sp_unificacion_regla3();  -- sin lat/long → 0 filas (N/A, no FAIL)

-- 2) Ordenamiento (solo RPU ganadoras; hijas excluidas en SPs)
CALL bdm_datos.sp_ordenamiento_ejecucion_edf(TRUE);
